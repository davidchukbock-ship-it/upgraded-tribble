/** Ключи и предельные значения игры. Единственный источник для клиента и сервера. */

export const RESOURCE_KEYS = ['gold', 'wood', 'stone', 'food'] as const;
export type ResourceKey = (typeof RESOURCE_KEYS)[number];
/** Премиум-валюта. Нигде не продаётся за реальные деньги (D-11). */
export const GEMS_KEY = 'gems' as const;

export const BUILDING_KEYS = [
  'castle',
  'barracks',
  'farm',
  'sawmill',
  'quarry',
  'goldmine',
  'warehouse',
  'forge',
  'academy',
  'walls',
  'hospital',
  'territory',
  'fishery',
  'diamondmine',
  'magetower',
  'archertower',
  'ballistatower',
  'stormtower',
] as const;
export type BuildingKey = (typeof BUILDING_KEYS)[number];

/** Класс здания: по нему интерфейс группирует список и раскрашивает значки. */
export const BUILDING_CLASSES = ['core', 'economy', 'military', 'magic', 'defense'] as const;
export type BuildingClass = (typeof BUILDING_CLASSES)[number];

export const BUILDING_CLASS: Readonly<Record<BuildingKey, BuildingClass>> = {
  castle: 'core',
  walls: 'core',
  warehouse: 'core',
  territory: 'core',
  farm: 'economy',
  sawmill: 'economy',
  quarry: 'economy',
  goldmine: 'economy',
  fishery: 'economy',
  diamondmine: 'economy',
  barracks: 'military',
  forge: 'military',
  hospital: 'military',
  academy: 'magic',
  magetower: 'magic',
  archertower: 'defense',
  ballistatower: 'defense',
  stormtower: 'defense',
};

/** Уровни «Земель»: 0 — стартовый остров, каждый следующий расширяет остров и открывает новые здания. */
export const MAX_TERRITORY_LEVEL = 4;
/** Уровень Замка, с которого доступен каждый следующий уровень Земель (индекс 0 → уровень 1). */
export const TERRITORY_CASTLE_LEVELS: readonly number[] = [4, 7, 10, 13];

export const UNIT_TYPES = ['infantry', 'archer', 'cavalry', 'siege'] as const;
export type UnitType = (typeof UNIT_TYPES)[number];
export const UNIT_TIERS = [1, 2, 3, 4, 5] as const;
export type UnitTier = (typeof UNIT_TIERS)[number];

export const ROLES = ['PLAYER', 'ADMIN', 'OWNER'] as const;
export type Role = (typeof ROLES)[number];

export const LOCALES = ['ru', 'uk', 'en'] as const;
export type Locale = (typeof LOCALES)[number];

/** Идентификатор живого мира (D-04). */
export const MAIN_WORLD_ID = 'main';

export const MAX_BUILDING_LEVEL = 20;
export const MAX_TECH_LEVEL = 10;
export const MAX_HERO_LEVEL = 50;
export const MAP_SIZE = 400;
export const MAP_TILE_SIZE = 40;
export const NEWBIE_SHIELD_HOURS = 72;

export const START_RESOURCES: Readonly<Record<ResourceKey, number>> = {
  gold: 1000,
  wood: 1000,
  stone: 1000,
  food: 1000,
};
export const START_GEMS = 50;

/** Здания, построенные у нового игрока (уровень 1). */
export const START_BUILDINGS: readonly BuildingKey[] = [
  'castle',
  'farm',
  'sawmill',
  'quarry',
  'goldmine',
  'warehouse',
];

/** Гербы, доступные всем при регистрации (остальные — косметика в магазине). */
export const DEFAULT_CRESTS = ['lion', 'wolf', 'eagle', 'stag'] as const;

/**
 * Коды ошибок API. Сервер отдаёт только коды; тексты — на клиенте (i18n, D-12).
 */
export const ERROR_CODES = {
  VALIDATION: 'ERR_VALIDATION',
  UNAUTHORIZED: 'ERR_UNAUTHORIZED',
  FORBIDDEN: 'ERR_FORBIDDEN',
  NOT_FOUND: 'ERR_NOT_FOUND',
  CONFLICT: 'ERR_CONFLICT',
  RATE_LIMITED: 'ERR_RATE_LIMITED',
  INSUFFICIENT_RESOURCES: 'ERR_INSUFFICIENT_RESOURCES',
  QUEUE_FULL: 'ERR_QUEUE_FULL',
  REQUIREMENT_NOT_MET: 'ERR_REQUIREMENT_NOT_MET',
  SHIELD_ACTIVE: 'ERR_SHIELD_ACTIVE',
  BANNED: 'ERR_BANNED',
  MUTED: 'ERR_MUTED',
  IDEMPOTENCY_MISMATCH: 'ERR_IDEMPOTENCY_MISMATCH',
  EMAIL_TAKEN: 'ERR_EMAIL_TAKEN',
  NICKNAME_TAKEN: 'ERR_NICKNAME_TAKEN',
  INVALID_CREDENTIALS: 'ERR_INVALID_CREDENTIALS',
  INTERNAL: 'ERR_INTERNAL',
} as const;
export type ErrorCode = (typeof ERROR_CODES)[keyof typeof ERROR_CODES];
