import type { CastleDto } from './dto';

/**
 * Магазин донатов (D-62): пакеты кристаллов за реальные деньги. Каталог и цены живут здесь, а сама оплата — за
 * интерфейсом PaymentProvider на сервере. По умолчанию оплата выключена; тестовый режим начисляет кристаллы без денег.
 */

export const DONATE_MODES = ['off', 'test'] as const;
export type DonateMode = (typeof DONATE_MODES)[number];

export type DonateTag = 'popular' | 'best';

export interface DonatePack {
  id: string;
  /** Кристаллы, которые получит игрок. */
  gems: number;
  /** Бонусные кристаллы сверх основных (чем крупнее пакет, тем щедрее). */
  bonus: number;
  /** Цена в центах США: целое число, без дробей. Других валют (в том числе рублей) в игре нет. */
  usdCents: number;
  tag?: DonateTag;
}

export const DONATE_PACKS: readonly DonatePack[] = [
  { id: 'gems_s', gems: 80, bonus: 0, usdCents: 99 },
  { id: 'gems_m', gems: 500, bonus: 50, usdCents: 499 },
  { id: 'gems_l', gems: 1200, bonus: 150, usdCents: 999 },
  { id: 'gems_xl', gems: 2600, bonus: 400, usdCents: 1999, tag: 'popular' },
  { id: 'gems_xxl', gems: 6500, bonus: 1300, usdCents: 4999, tag: 'best' },
  { id: 'gems_max', gems: 14_000, bonus: 3500, usdCents: 9999 },
];

export const findDonatePack = (id: string): DonatePack | undefined =>
  DONATE_PACKS.find((p) => p.id === id);

/** Сколько кристаллов придёт в сумме. */
export const donateTotal = (p: DonatePack): number => p.gems + p.bonus;

/** Кристаллов на доллар — чтобы показать выгоду крупных пакетов. */
export const gemsPerUsd = (p: DonatePack): number =>
  Math.round((donateTotal(p) / p.usdCents) * 100);

export interface DonatePackDto extends DonatePack {
  total: number;
}
export interface DonateDto {
  mode: DonateMode;
  gems: number;
  packs: DonatePackDto[];
}

/** Ответ на покупку: замок с новым балансом и сколько кристаллов начислено. */
export interface DonateBuyDto {
  castle: CastleDto;
  granted: number;
}
