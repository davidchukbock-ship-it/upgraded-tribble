import { EQUIP_SLOTS, RARITIES, type EquipSlot, type Rarity } from './hero';
import type { ResourceAmounts } from './economy';

/** Сундуки и ускорители (docs/GAME_DESIGN.md §9, §12). Таблицы шансов показываются игроку. */

export const CHEST_KINDS = ['wooden', 'silver', 'gold'] as const;
export type ChestKind = (typeof CHEST_KINDS)[number];

export const BOOSTERS = { boost_5m: 300, boost_1h: 3600, boost_8h: 28_800 } as const;
export type BoosterKey = keyof typeof BOOSTERS;
export const BOOSTER_KEYS = Object.keys(BOOSTERS) as BoosterKey[];
export const isBoosterKey = (k: string): k is BoosterKey => k in BOOSTERS;

export type ChestOutcome = 'resources' | 'booster' | 'gems' | 'gear_low' | 'gear_high';

/** Шансы, %: строки в порядке таблицы. Сумма каждой колонки — 100. */
export const CHEST_ODDS: Readonly<Record<ChestKind, Readonly<Record<ChestOutcome, number>>>> = {
  wooden: { resources: 60, booster: 25, gems: 10, gear_low: 5, gear_high: 0 },
  silver: { resources: 45, booster: 25, gems: 15, gear_low: 12, gear_high: 3 },
  gold: { resources: 30, booster: 25, gems: 20, gear_low: 15, gear_high: 10 },
};
export const OUTCOME_ORDER: readonly ChestOutcome[] = [
  'resources',
  'booster',
  'gems',
  'gear_low',
  'gear_high',
];

/** Каждого из четырёх ресурсов в пакете. */
export const RESOURCE_PACK: Readonly<Record<ChestKind, number>> = {
  wooden: 800,
  silver: 2500,
  gold: 7000,
};
export const GEMS_RANGE: Readonly<Record<ChestKind, readonly [number, number]>> = {
  wooden: [5, 10],
  silver: [15, 30],
  gold: [40, 80],
};
/** Доля шанса на большой ускоритель (1 ч) среди ускорителей сундука. */
const BIG_BOOSTER_SHARE: Readonly<Record<ChestKind, number>> = {
  wooden: 0.2,
  silver: 0.4,
  gold: 0.6,
};

export type ChestReward =
  | { type: 'resources'; resources: ResourceAmounts }
  | { type: 'booster'; booster: BoosterKey }
  | { type: 'gems'; gems: number }
  | { type: 'gear'; slot: EquipSlot; rarity: Rarity };

const pick = <T>(list: readonly T[], r: number): T =>
  list[Math.min(list.length - 1, Math.floor(r * list.length))]!;

/** Определяет исход по таблице шансов: r ∈ [0, 1). */
export function rollOutcome(kind: ChestKind, r: number): ChestOutcome {
  let acc = 0;
  for (const o of OUTCOME_ORDER) {
    acc += CHEST_ODDS[kind][o] / 100;
    if (r < acc && CHEST_ODDS[kind][o] > 0) return o;
  }
  return 'resources';
}

/**
 * Содержимое сундука. `rng` — источник случайных чисел [0, 1): на сервере криптографический,
 * в тестах — детерминированный (D-08: сама функция чистая).
 */
export function rollChest(kind: ChestKind, rng: () => number): ChestReward {
  const outcome = rollOutcome(kind, rng());
  switch (outcome) {
    case 'resources': {
      const n = RESOURCE_PACK[kind];
      return { type: 'resources', resources: { gold: n, wood: n, stone: n, food: n } };
    }
    case 'booster':
      return {
        type: 'booster',
        booster: rng() < BIG_BOOSTER_SHARE[kind] ? 'boost_1h' : 'boost_5m',
      };
    case 'gems': {
      const [lo, hi] = GEMS_RANGE[kind];
      return { type: 'gems', gems: lo + Math.floor(rng() * (hi - lo + 1)) };
    }
    case 'gear_low': {
      const r = rng();
      const rarity: Rarity = r < 0.6 ? 1 : r < 0.9 ? 2 : 3;
      return { type: 'gear', slot: pick(EQUIP_SLOTS, rng()), rarity };
    }
    case 'gear_high':
      return { type: 'gear', slot: pick(EQUIP_SLOTS, rng()), rarity: rng() < 0.8 ? 4 : 5 };
  }
}

export { RARITIES };
