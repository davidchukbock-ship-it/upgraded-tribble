import {
  cellAt,
  pickCastleSpotWith,
  terrainAt,
  type MapCell,
  type Point,
  type Terrain,
} from './map';
import { MAP_V2, cellAt2, terrainAt2 } from './map2';

/** Версия карты мира (D-74): 1 — исходная, 2 — биомы, реки, моря, дороги. */
export type MapVersion = 1 | 2;
export const DEFAULT_MAP_VERSION: MapVersion = 1;

export const asMapVersion = (v: number | null | undefined): MapVersion => (v === MAP_V2 ? 2 : 1);

export function cellAtV(version: MapVersion, seed: number, x: number, y: number): MapCell {
  return version === 2 ? cellAt2(seed, x, y) : cellAt(seed, x, y);
}

export function terrainAtV(version: MapVersion, seed: number, x: number, y: number): Terrain {
  return version === 2 ? terrainAt2(seed, x, y) : terrainAt(seed, x, y);
}

export function pickCastleSpotV(
  version: MapVersion,
  seed: number,
  taken: readonly Point[],
): Point | null {
  return pickCastleSpotWith((x, y) => cellAtV(version, seed, x, y), taken);
}
