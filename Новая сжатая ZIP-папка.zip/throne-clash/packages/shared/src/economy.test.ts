import { describe, expect, it } from 'vitest';
import { BUILDING_KEYS, MAX_BUILDING_LEVEL, RESOURCE_KEYS, START_RESOURCES } from './constants';
import {
  advanceResources,
  advanceStock,
  buildSeconds,
  buildSlots,
  buildingCost,
  cancelRefund,
  castleTimeBonus,
  guildHelpSeconds,
  lootableAmount,
  maxBuildingLevel,
  maxLevelFor,
  productionPerHour,
  ratesFor,
  shortfall,
  speedupGems,
  warehouseCap,
} from './economy';

describe('производство (GAME_DESIGN §1)', () => {
  it('образцы для фермы: L1=400, L2=468, L10=1643, L20=7899', () => {
    expect([1, 2, 10, 20].map((l) => productionPerHour('food', l))).toEqual([400, 468, 1643, 7899]);
  });
  it('уровень 0 не производит; скорость мира и бонус множат результат', () => {
    expect(productionPerHour('gold', 0)).toBe(0);
    expect(productionPerHour('gold', 1, 10)).toBe(3000);
    expect(productionPerHour('wood', 1, 1, { production: { wood: 0.25 } })).toBe(500);
  });
  it('базы: золото 300, дерево 400, камень 350, еда 400', () => {
    expect(RESOURCE_KEYS.map((r) => productionPerHour(r, 1))).toEqual([300, 400, 350, 400]);
  });
});

describe('склад', () => {
  it('ёмкость: L1=3000, L10=36499, L20=586173', () => {
    expect([1, 10, 20].map((l) => warehouseCap(l))).toEqual([3000, 36499, 586173]);
  });
  it('бонус технологий увеличивает ёмкость', () => {
    expect(warehouseCap(1, { warehouse: 0.04 })).toBe(3120);
  });
  it('защищено 20% ёмкости; ограбить можно только остальное', () => {
    expect(lootableAmount(3000, 3000)).toBe(2400);
    expect(lootableAmount(500, 3000)).toBe(0);
    expect(lootableAmount(600.9, 3000)).toBe(0);
  });
});

describe('стоимость и время построек (§2)', () => {
  it('образцы: ферма L1 = 80/120/60/0, Замок L20 ≈ 348 000 золота', () => {
    expect(buildingCost('farm', 1)).toEqual({ gold: 80, wood: 120, stone: 60, food: 0 });
    expect(buildingCost('castle', 20).gold).toBeGreaterThan(340_000);
    expect(buildingCost('castle', 20).gold).toBeLessThan(355_000);
  });
  it('стоимость кратна 5 и не убывает с уровнем', () => {
    for (const key of BUILDING_KEYS) {
      let prev = buildingCost(key, 1);
      for (let l = 2; l <= MAX_BUILDING_LEVEL; l++) {
        const c = buildingCost(key, l);
        for (const r of RESOURCE_KEYS) {
          expect(c[r] % 5).toBe(0);
          expect(c[r]).toBeGreaterThanOrEqual(prev[r]);
        }
        prev = c;
      }
    }
  });
  it('ИНВАРИАНТ БАЛАНСА: любая цена любого уровня помещается в склад 20-го уровня', () => {
    const cap = warehouseCap(MAX_BUILDING_LEVEL);
    for (const key of BUILDING_KEYS)
      for (let l = 1; l <= maxBuildingLevel(key); l++)
        for (const r of RESOURCE_KEYS)
          expect(buildingCost(key, l)[r], `${key} ${l}`).toBeLessThanOrEqual(cap);
  });
  it('время: ферма L1=30, L2=45, L20=66505 с при Замке 1', () => {
    expect([1, 2, 20].map((l) => buildSeconds('farm', l, 1))).toEqual([30, 45, 66505]);
  });
  it('Замок сокращает время на 2% за уровень, максимум 40%', () => {
    expect(castleTimeBonus(1)).toBe(0);
    expect(castleTimeBonus(6)).toBeCloseTo(0.1);
    expect(castleTimeBonus(21)).toBe(0.4);
    expect(castleTimeBonus(50)).toBe(0.4);
    expect(buildSeconds('farm', 1, 21)).toBe(18); // 30 · 0.6
  });
  it('минимум 1 секунда; скорость мира ускоряет', () => {
    expect(buildSeconds('farm', 1, 1, 1000)).toBe(1);
    expect(buildSeconds('farm', 2, 1, 5)).toBe(9);
  });
  it('потолок уровня: Замок — 20, остальные — не выше Замка', () => {
    expect(maxLevelFor('castle', 1)).toBe(20);
    expect(maxLevelFor('farm', 3)).toBe(3);
    expect(maxLevelFor('farm', 25)).toBe(20);
  });
});

describe('очередь', () => {
  it('слоты: второй с Замка 8 или за кристаллы', () => {
    expect(buildSlots(1, false)).toBe(1);
    expect(buildSlots(7, false)).toBe(1);
    expect(buildSlots(8, false)).toBe(2);
    expect(buildSlots(1, true)).toBe(2);
  });
  it('ускорение: 1 кристалл за 5 минут остатка, минимум 1', () => {
    expect([0, 1, 300, 301, 3600].map(speedupGems)).toEqual([1, 1, 1, 2, 12]);
  });
  it('отмена возвращает половину, округляя вниз', () => {
    expect(cancelRefund({ gold: 81, wood: 120, stone: 1, food: 0 })).toEqual({
      gold: 40,
      wood: 60,
      stone: 0,
      food: 0,
    });
  });
  it('помощь братства: 1% длительности, не меньше 10 с', () => {
    expect(guildHelpSeconds(600)).toBe(10);
    expect(guildHelpSeconds(10_000)).toBe(100);
  });
  it('shortfall игнорирует дробную часть запаса', () => {
    const have = { gold: 79.99, wood: 200, stone: 60, food: 0 };
    expect(shortfall(have, { gold: 80, wood: 120, stone: 60, food: 0 })).toEqual({ gold: 1 });
  });
});

describe('advanceStock / advanceResources', () => {
  it('накапливает по ставке и упирается в ёмкость', () => {
    expect(advanceStock(0, 3600, 5000, 1800)).toBe(1800);
    expect(advanceStock(4900, 3600, 5000, 3600)).toBe(5000);
  });
  it('запас выше ёмкости не сгорает и не растёт', () => {
    expect(advanceStock(9000, 3600, 5000, 3600)).toBe(9000);
  });
  it('отрицательный приход (содержание) уменьшает запас, но не ниже нуля', () => {
    expect(advanceStock(100, -3600, 5000, 30)).toBe(70);
    expect(advanceStock(100, -3600, 5000, 3600)).toBe(0);
  });
  it('нулевое и отрицательное время ничего не меняют', () => {
    expect(advanceStock(10, 1000, 5000, 0)).toBe(10);
    expect(advanceStock(10, 1000, 5000, -5)).toBe(10);
  });
  it('по всем четырём ресурсам', () => {
    const out = advanceResources(START_RESOURCES, ratesFor({ farm: 1, goldmine: 1 }), 3000, 3600);
    expect(out).toEqual({ gold: 1300, wood: 1000, stone: 1000, food: 1400 });
  });
});
