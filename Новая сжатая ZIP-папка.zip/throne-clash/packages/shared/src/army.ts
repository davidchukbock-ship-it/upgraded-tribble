import { UNIT_TIERS, UNIT_TYPES, type UnitTier, type UnitType } from './constants';
import type { ResourceAmounts } from './economy';
import { getBalance } from './balance';

/**
 * Войска: характеристики, стоимость, время обучения, содержание, лимит армии.
 * Числа — docs/GAME_DESIGN.md §3. Только чистые функции (D-08).
 */

export type UnitId = `${UnitType}_${UnitTier}`;
export const unitId = (type: UnitType, tier: UnitTier): UnitId => `${type}_${tier}`;

export function parseUnitId(id: string): { type: UnitType; tier: UnitTier } | null {
  const [type, tier] = id.split('_');
  const t = Number(tier);
  if (!(UNIT_TYPES as readonly string[]).includes(type ?? '')) return null;
  if (!(UNIT_TIERS as readonly number[]).includes(t)) return null;
  return { type: type as UnitType, tier: t as UnitTier };
}

export const ALL_UNIT_IDS: readonly UnitId[] = UNIT_TYPES.flatMap((type) =>
  UNIT_TIERS.map((tier) => unitId(type, tier)),
);

export interface UnitStack {
  /** Здоровые, в строю. */
  count: number;
  /** Раненые (лечатся в госпитале, этап 5). */
  wounded: number;
}
export type Army = Partial<Record<UnitId, UnitStack>>;

export const UNIT_BASE: Readonly<
  Record<
    UnitType,
    {
      atk: number;
      def: number;
      hp: number;
      /** Секунд на клетку. */
      secPerTile: number;
      cargo: number;
      cost: Readonly<ResourceAmounts>;
      trainSec: number;
    }
  >
> = {
  infantry: {
    atk: 12,
    def: 16,
    hp: 120,
    secPerTile: 60,
    cargo: 20,
    cost: { gold: 30, wood: 20, stone: 0, food: 30 },
    trainSec: 20,
  },
  archer: {
    atk: 18,
    def: 8,
    hp: 80,
    secPerTile: 60,
    cargo: 15,
    cost: { gold: 40, wood: 40, stone: 0, food: 20 },
    trainSec: 25,
  },
  cavalry: {
    atk: 22,
    def: 12,
    hp: 130,
    secPerTile: 30,
    cargo: 40,
    cost: { gold: 70, wood: 30, stone: 0, food: 60 },
    trainSec: 40,
  },
  siege: {
    atk: 30,
    def: 6,
    hp: 150,
    secPerTile: 90,
    cargo: 10,
    cost: { gold: 100, wood: 120, stone: 80, food: 0 },
    trainSec: 60,
  },
};

export const STAT_GROWTH = 1.6;
export const COST_GROWTH_UNIT = 1.9;
export const TRAIN_GROWTH = 1.5;
export const CARGO_GROWTH = 1.3;
export const MAX_TRAIN_QUEUE = 4;

export interface UnitStats {
  atk: number;
  def: number;
  hp: number;
  secPerTile: number;
  cargo: number;
  cost: ResourceAmounts;
  trainSec: number;
  /** Еды в час на одного юнита. */
  upkeep: number;
}

export function unitStats(type: UnitType, tier: UnitTier): UnitStats {
  const b = UNIT_BASE[type];
  const s = STAT_GROWTH ** (tier - 1);
  const c = COST_GROWTH_UNIT ** (tier - 1);
  const r = (n: number) => Math.round(n);
  const bal = getBalance();
  return {
    atk: r(b.atk * s * bal.attack),
    def: r(b.def * s * bal.defense),
    hp: r(b.hp * s * bal.health),
    secPerTile: b.secPerTile,
    cargo: Math.floor(b.cargo * CARGO_GROWTH ** (tier - 1)),
    cost: {
      gold: r(b.cost.gold * c),
      wood: r(b.cost.wood * c),
      stone: r(b.cost.stone * c),
      food: r(b.cost.food * c),
    },
    trainSec: b.trainSec * TRAIN_GROWTH ** (tier - 1) * getBalance().trainTime,
    upkeep: tier,
  };
}

/** Уровень Казармы, с которого открывается тир: 1, 5, 9, 13, 17. */
export const barracksLevelForTier = (tier: UnitTier): number => 4 * (tier - 1) + 1;

/** Высший доступный тир при данном уровне Казармы (0 — Казармы нет). */
export function maxTierFor(barracksLevel: number): number {
  if (barracksLevel < 1) return 0;
  return Math.min(5, Math.floor((barracksLevel - 1) / 4) + 1);
}

/** Лимит армии: в строю + в очереди + в походах. */
export const armyCap = (barracksLevel: number): number =>
  barracksLevel < 1 ? 0 : 100 + 150 * barracksLevel;

/**
 * Время обучения партии, секунды: n · trainSec / (1 + 0.05·(L−1)) · (1 − муштра) / скорость мира.
 * Минимум 1 секунда.
 */
export function trainSeconds(
  type: UnitType,
  tier: UnitTier,
  count: number,
  barracksLevel: number,
  drillBonus = 0,
  worldSpeed = 1,
): number {
  const base =
    (count * unitStats(type, tier).trainSec) / (1 + 0.05 * (Math.max(1, barracksLevel) - 1));
  return Math.max(1, Math.round((base * (1 - drillBonus)) / worldSpeed));
}

export function trainCost(type: UnitType, tier: UnitTier, count: number): ResourceAmounts {
  const c = unitStats(type, tier).cost;
  const k = getBalance().trainCost;
  return {
    gold: Math.round(c.gold * k) * count,
    wood: Math.round(c.wood * k) * count,
    stone: Math.round(c.stone * k) * count,
    food: Math.round(c.food * k) * count,
  };
}

export const armyCount = (army: Army): number =>
  Object.values(army).reduce((sum, s) => sum + (s?.count ?? 0), 0);

/** Еда в час на содержание армии (раненые и очередь не едят). */
export function upkeepPerHour(army: Army): number {
  let total = 0;
  for (const [id, stack] of Object.entries(army)) {
    const parsed = parseUnitId(id);
    if (parsed && stack) total += stack.count * parsed.tier;
  }
  return total;
}

/** Множитель урона: атакующий тип → защищающийся тип (камень-ножницы-бумага). */
export const ATTACK_MULT: Readonly<Record<UnitType, Readonly<Record<UnitType, number>>>> = {
  infantry: { infantry: 1, archer: 0.75, cavalry: 1.5, siege: 1.25 },
  archer: { infantry: 1.5, archer: 1, cavalry: 0.75, siege: 1.25 },
  cavalry: { infantry: 0.75, archer: 1.5, cavalry: 1, siege: 1.5 },
  siege: { infantry: 1.25, archer: 1.25, cavalry: 0.75, siege: 1 },
};

/** Госпиталь: вместимость раненых 100 · L. */
export const hospitalCapacity = (level: number, bonus = 0): number =>
  Math.round(100 * level * (1 + bonus));

/** Лечение раненых: половина цены обучения за юнита, скидка от «Медицины». Мгновенно. */
export function healCost(
  type: UnitType,
  tier: UnitTier,
  count: number,
  discount = 0,
): ResourceAmounts {
  const c = trainCost(type, tier, count);
  const k = 0.5 * (1 - Math.min(0.9, Math.max(0, discount)));
  return {
    gold: Math.ceil(c.gold * k),
    wood: Math.ceil(c.wood * k),
    stone: Math.ceil(c.stone * k),
    food: Math.ceil(c.food * k),
  };
}
