import { describe, expect, it } from 'vitest';
import { FOOTPRINT, PLACEMENT, islandSize, roadCells, type PlacedKey } from './island';
import {
  PROSPERITY_CAP,
  STRUCTURE_DEFS,
  STRUCTURE_GROUPS,
  STRUCTURE_KINDS,
  cityDto,
  freeCells,
  isFreeCell,
  isWaterCell,
  placeError,
  prosperity,
  structureCost,
  structureRefund,
  type PlacedStructure,
} from './structures';

const at = (kind: PlacedStructure['kind'], x: number, y: number): PlacedStructure => ({
  id: `${kind}-${x}-${y}`,
  kind,
  x,
  y,
});

describe('постройки города (D-66)', () => {
  it('цена растёт с каждой постройкой вида, кратна 5', () => {
    for (const k of STRUCTURE_KINDS) {
      const first = structureCost(k, 0);
      const second = structureCost(k, 3);
      expect(first.gold).toBe(STRUCTURE_DEFS[k].cost.gold);
      // дорога стоит одинаково, остальное дорожает
      const grows = STRUCTURE_DEFS[k].growth > 1;
      const total = (c: typeof first) => c.gold + c.wood + c.stone + c.food;
      if (grows) expect(total(second)).toBeGreaterThan(total(first));
      else expect(second).toEqual(first);
      for (const v of Object.values(second)) expect(v % 5).toBe(0);
    }
  });

  it('процветание суммируется и упирается в потолок', () => {
    expect(prosperity([])).toBe(0);
    expect(prosperity([at('house', 1, 1), at('market', 2, 1)])).toBeCloseTo(0.021, 9);
    const many = Array.from({ length: 200 }, (_, i) => at('market', i, 1));
    expect(prosperity(many)).toBe(PROSPERITY_CAP);
  });

  it('каждая постройка даёт немного, а потолок ограничивает сумму', () => {
    for (const k of STRUCTURE_KINDS) expect(STRUCTURE_DEFS[k].bonus).toBeLessThanOrEqual(0.02);
    const all = STRUCTURE_KINDS.flatMap((k) =>
      Array.from({ length: STRUCTURE_DEFS[k].max }, (_, i) => at(k, i, 0)),
    );
    expect(prosperity(all)).toBe(PROSPERITY_CAP);
  });

  it('видов много, они разбиты по разделам, у каждого есть цена и предел', () => {
    expect(STRUCTURE_KINDS.length).toBeGreaterThanOrEqual(40);
    for (const g of STRUCTURE_GROUPS)
      expect(STRUCTURE_KINDS.filter((k) => STRUCTURE_DEFS[k].group === g).length).toBeGreaterThan(
        3,
      );
    for (const k of STRUCTURE_KINDS) {
      expect(STRUCTURE_DEFS[k].max).toBeGreaterThan(0);
      expect(STRUCTURE_DEFS[k].castle).toBeGreaterThanOrEqual(1);
    }
    // с самого начала (Замок 1) доступно достаточно видов, чтобы игрок сразу увидел город
    expect(
      STRUCTURE_KINDS.filter((k) => STRUCTURE_DEFS[k].castle === 1).length,
    ).toBeGreaterThanOrEqual(10);
  });

  it('свободные клетки: внутри острова, не на улицах, не на участках зданий, не заняты', () => {
    const { w, d } = islandSize(0);
    const road = roadCells(w, d);
    const cells = freeCells(0, []);
    expect(cells.length).toBeGreaterThan(20);
    for (const c of cells) {
      expect(c.x).toBeGreaterThanOrEqual(1);
      expect(c.y).toBeGreaterThanOrEqual(1);
      expect(c.x).toBeLessThan(w - 1);
      expect(c.y).toBeLessThan(d - 1);
      expect(road.has(`${c.x}-${c.y}`)).toBe(false);
      for (const key of Object.keys(PLACEMENT) as PlacedKey[]) {
        const p = PLACEMENT[key];
        const f = FOOTPRINT[key];
        const inside =
          c.x + 1 > p.x - 0.25 &&
          c.x < p.x + f.w + 0.25 &&
          c.y + 1 > p.y - 0.25 &&
          c.y < p.y + f.d + 0.25;
        expect(inside).toBe(false);
      }
    }
    const first = cells[0]!;
    expect(isFreeCell(0, first.x, first.y, [])).toBe(true);
    expect(isFreeCell(0, first.x, first.y, [at('house', first.x, first.y)])).toBe(false);
    expect(freeCells(0, [at('house', first.x, first.y)])).toHaveLength(cells.length - 1);
  });

  it('расширение Земель добавляет свободные клетки', () => {
    expect(freeCells(2, []).length).toBeGreaterThan(freeCells(0, []).length);
  });

  it('placeError различает причины', () => {
    const ctx = { castleLevel: 4, territory: 0, structures: [] as PlacedStructure[] };
    const c = freeCells(0, [])[0]!;
    expect(placeError('house', c.x, c.y, ctx)).toBeNull();
    expect(placeError('bank', c.x, c.y, ctx)).toBe('castle_level');
    expect(placeError('house', 0, 0, ctx)).toBe('cell');
    expect(placeError('house', 1.5, 3, ctx)).toBe('cell');
    const full = Array.from({ length: STRUCTURE_DEFS.house.max }, (_, i) => at('house', i, 30));
    expect(placeError('house', c.x, c.y, { ...ctx, structures: full })).toBe('limit');
  });

  it('корабли и пирсы ставятся только на воду за задним краем, пирс — вплотную к берегу', () => {
    const ctx = { castleLevel: 12, territory: 0, structures: [] as PlacedStructure[] };
    const shipCells = freeCells(0, [], 'ship');
    const pierCells = freeCells(0, [], 'pier');
    expect(shipCells.length).toBeGreaterThan(pierCells.length);
    for (const c of shipCells) expect(c.x < 0 || c.y < 0).toBe(true);
    for (const c of pierCells) expect(c.x === -1 || c.y === -1).toBe(true);
    expect(placeError('ship', -2, 3, ctx)).toBeNull();
    expect(placeError('pier', -2, 3, ctx)).toBe('cell');
    expect(placeError('pier', -1, 3, ctx)).toBeNull();
    // на сушу корабль не встанет, а дом — на воду
    const land = freeCells(0, [])[0]!;
    expect(placeError('ship', land.x, land.y, ctx)).toBe('cell');
    expect(placeError('house', -1, 3, ctx)).toBe('cell');
    // клетка воды занимается
    const s = at('ship', -2, 3);
    expect(placeError('ship', -2, 3, { ...ctx, structures: [s] })).toBe('cell');
    // расширение Земель не отнимает воду: клетки за задним краем те же
    expect(isWaterCell(4, -2, 3, [])).toBe(true);
  });

  it('снос возвращает половину, а каталог показывает блокировки', () => {
    expect(structureRefund({ gold: 151, wood: 120, stone: 81, food: 0 })).toEqual({
      gold: 75,
      wood: 60,
      stone: 40,
      food: 0,
    });
    const city = cityDto([at('house', 8, 3)], 1);
    expect(city.catalog.find((k) => k.kind === 'house')).toMatchObject({ owned: 1, blocked: null });
    expect(city.catalog.find((k) => k.kind === 'bank')).toMatchObject({
      owned: 0,
      blocked: 'castle_level',
    });
    expect(city.prosperity).toBeCloseTo(0.006, 9);
  });
});
