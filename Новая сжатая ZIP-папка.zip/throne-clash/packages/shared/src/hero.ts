import { MAX_HERO_LEVEL } from './constants';
import type { ResourceAmounts } from './economy';

/**
 * Герой: один на аккаунт. Опыт, очки навыков, экипировка (docs/GAME_DESIGN.md §8).
 */

export const SKILL_KEYS = ['combat', 'defense', 'economy'] as const;
export type SkillKey = (typeof SKILL_KEYS)[number];
export const MAX_SKILL_LEVEL = 5;

export const EQUIP_SLOTS = ['weapon', 'armor', 'relic'] as const;
export type EquipSlot = (typeof EQUIP_SLOTS)[number];
export const RARITIES = [1, 2, 3, 4, 5] as const;
export type Rarity = (typeof RARITIES)[number];

/** Прибавка навыка за уровень: доля. */
export const SKILL_PER_LEVEL: Readonly<Record<SkillKey, number>> = {
  combat: 0.02,
  defense: 0.02,
  economy: 0.03,
};
/** Бонус предмета = редкость · 1,5%. */
export const ITEM_BONUS_PER_RARITY = 0.015;
/** Уровень героя сам даёт +0,5% к атаке и защите за уровень. */
export const LEVEL_BONUS = 0.005;

export interface HeroItemState {
  id: string;
  slot: EquipSlot;
  rarity: Rarity;
  equipped: boolean;
}

export interface HeroState {
  level: number;
  xp: number;
  skills: Record<SkillKey, number>;
  items: HeroItemState[];
}

export const newHero = (): HeroState => ({
  level: 1,
  xp: 0,
  skills: { combat: 0, defense: 0, economy: 0 },
  items: [],
});

/** Опыт до следующего уровня. */
export const heroXpToNext = (level: number): number => Math.round(100 * level ** 1.6);

/** Очки навыков: по одному за каждый уровень. */
export const heroSkillPoints = (h: Pick<HeroState, 'level' | 'skills'>): number =>
  h.level - SKILL_KEYS.reduce((sum, k) => sum + h.skills[k], 0);

export interface LevelUp {
  level: number;
  xp: number;
}

/** Начисляет опыт; переносит остаток через уровни, на максимуме опыт не копится. */
export function addHeroXp(level: number, xp: number, gain: number): LevelUp {
  let l = level;
  let x = xp + Math.max(0, Math.floor(gain));
  while (l < MAX_HERO_LEVEL && x >= heroXpToNext(l)) {
    x -= heroXpToNext(l);
    l++;
  }
  if (l >= MAX_HERO_LEVEL) x = 0;
  return { level: l, xp: x };
}

export interface HeroBonuses {
  attack: number;
  defense: number;
  production: number;
}

export function heroBonuses(h: HeroState): HeroBonuses {
  const equipped = (slot: EquipSlot): number => {
    const item = h.items.find((i) => i.slot === slot && i.equipped);
    return item ? item.rarity * ITEM_BONUS_PER_RARITY : 0;
  };
  const levelBonus = (h.level - 1) * LEVEL_BONUS;
  return {
    attack: h.skills.combat * SKILL_PER_LEVEL.combat + levelBonus + equipped('weapon'),
    defense: h.skills.defense * SKILL_PER_LEVEL.defense + levelBonus + equipped('armor'),
    production: h.skills.economy * SKILL_PER_LEVEL.economy + equipped('relic'),
  };
}

/** Тренировка героя: плата растёт с уровнем. */
export const HERO_TRAIN_XP = 60;
export function heroTrainCost(level: number): ResourceAmounts {
  return { gold: 100 * level, wood: 0, stone: 0, food: 50 * level };
}
