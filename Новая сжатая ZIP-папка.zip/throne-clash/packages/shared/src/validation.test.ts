import { describe, expect, it } from 'vitest';
import {
  emailSchema,
  isReservedNickname,
  loginBodySchema,
  nicknameKey,
  nicknameSchema,
  passwordSchema,
  registerBodySchema,
  updateProfileBodySchema,
} from './validation';

describe('emailSchema', () => {
  it('нормализует регистр и пробелы', () => {
    expect(emailSchema.parse('  Hero@Example.COM ')).toBe('hero@example.com');
  });
  it.each(['', 'no-at', 'a@', '@b.c', `${'x'.repeat(250)}@a.co`])('отклоняет %j', (v) => {
    expect(emailSchema.safeParse(v).success).toBe(false);
  });
});

describe('passwordSchema', () => {
  it('принимает нормальный пароль', () => {
    expect(passwordSchema.safeParse('Correct horse 42').success).toBe(true);
  });
  it.each(['short7!', 'password', 'PASSWORD123', '12345678', 'aaaaaaaaaaaa', 'x'.repeat(129)])(
    'отклоняет %j',
    (v) => expect(passwordSchema.safeParse(v).success).toBe(false),
  );
});

describe('nicknameSchema', () => {
  it.each(['Артур', 'Sir Lancelot', 'dark_knight-7', 'Кая Вейр', 'abc'])('принимает %j', (v) => {
    expect(nicknameSchema.safeParse(v).success).toBe(true);
  });
  it.each([
    'ab',
    'x'.repeat(21),
    ' _bad',
    'bad_',
    'two  spaces',
    'a__b',
    'emoji😀name',
    '<script>',
    "o'neil",
    'a\u0000b',
  ])('отклоняет %j', (v) => {
    expect(nicknameSchema.safeParse(v).success).toBe(false);
  });
  it('обрезает пробелы по краям', () => {
    expect(nicknameSchema.parse('  Артур  ')).toBe('Артур');
  });
});

describe('nicknameKey и зарезервированные ники', () => {
  it('регистр, разделители и кириллические двойники не создают «другой» ник', () => {
    expect(nicknameKey('Admin')).toBe(nicknameKey('аdmin')); // кириллическая «а»
    expect(nicknameKey('Sir Lancelot')).toBe(nicknameKey('sir_lancelot'));
    expect(nicknameKey('Sir-Lancelot')).toBe(nicknameKey('SIRLANCELOT'));
  });
  it.each(['Admin', 'аdmin', 'ADMINISTRATOR', 'G0D', 'God Mode', 'Owner_1'])(
    'резервирует %j',
    (v) => expect(isReservedNickname(v)).toBe(true),
  );
  it('не режет обычные ники', () => {
    for (const n of ['Admiral', 'Godric', 'Botan', 'Kingmaker'])
      expect(isReservedNickname(n)).toBe(false);
  });
});

describe('registerBodySchema', () => {
  const ok = { email: 'a@b.co', password: 'Correct horse 42', nickname: 'Артур' };
  it('принимает корректное тело', () => {
    expect(registerBodySchema.safeParse(ok).success).toBe(true);
  });
  it('запрещает лишние поля (mass assignment: role, isAdmin)', () => {
    expect(registerBodySchema.safeParse({ ...ok, role: 'OWNER' }).success).toBe(false);
  });
  it('пароль не должен содержать локальную часть email', () => {
    const r = registerBodySchema.safeParse({
      ...ok,
      email: 'dragonslayer@x.co',
      password: 'DragonSlayer!2024',
    });
    expect(r.success).toBe(false);
  });
  it('короткая локальная часть не даёт ложных срабатываний', () => {
    expect(registerBodySchema.safeParse({ ...ok, email: 'a@b.co' }).success).toBe(true);
  });
});

describe('прочие схемы', () => {
  it('login не проверяет сложность пароля (иначе старые пароли не войдут)', () => {
    expect(loginBodySchema.safeParse({ email: 'a@b.co', password: 'x' }).success).toBe(true);
  });
  it('profile: пустое тело и чужой герб отклоняются', () => {
    expect(updateProfileBodySchema.safeParse({}).success).toBe(false);
    expect(updateProfileBodySchema.safeParse({ crest: 'dragon' }).success).toBe(false);
    expect(updateProfileBodySchema.safeParse({ crest: 'wolf', language: 'en' }).success).toBe(true);
  });
});
