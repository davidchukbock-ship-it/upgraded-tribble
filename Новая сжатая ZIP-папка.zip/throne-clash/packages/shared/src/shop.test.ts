import { describe, expect, it } from 'vitest';
import { DEFAULT_CRESTS } from './constants';
import { crestSchema } from './validation';
import {
  ALL_CRESTS,
  CREST_PRICE,
  PREMIUM_CRESTS,
  SHOP_CATALOG,
  boosterSeconds,
  crestBase,
  findShopItem,
  isPremiumCrest,
} from './shop';

describe('магазин', () => {
  it('10 премиум-гербов на базе стандартных рисунков', () => {
    expect(PREMIUM_CRESTS).toHaveLength(10);
    for (const c of PREMIUM_CRESTS) expect(DEFAULT_CRESTS).toContain(crestBase(c));
    expect(crestBase('wolf')).toBe('wolf');
    expect(ALL_CRESTS).toHaveLength(DEFAULT_CRESTS.length + 10);
  });

  it('в каталоге пакеты, три ускорителя, слот и все гербы; id уникальны', () => {
    const ids = SHOP_CATALOG.map((i) => i.id);
    expect(new Set(ids).size).toBe(ids.length);
    expect(SHOP_CATALOG.filter((i) => i.kind === 'pack')).toHaveLength(3);
    expect(SHOP_CATALOG.filter((i) => i.kind === 'booster')).toHaveLength(3);
    expect(SHOP_CATALOG.filter((i) => i.kind === 'slot')).toHaveLength(1);
    expect(SHOP_CATALOG.filter((i) => i.kind === 'crest')).toHaveLength(10);
    for (const i of SHOP_CATALOG.filter((x) => x.kind === 'crest')) {
      expect(i.price).toBe(CREST_PRICE);
      expect(isPremiumCrest(i.crest!)).toBe(true);
    }
  });

  it('пакеты дороже и больше по возрастанию', () => {
    const packs = SHOP_CATALOG.filter((i) => i.kind === 'pack');
    for (let k = 1; k < packs.length; k++) {
      expect(packs[k]!.price).toBeGreaterThan(packs[k - 1]!.price);
      expect(packs[k]!.resources!.gold).toBeGreaterThan(packs[k - 1]!.resources!.gold);
    }
    expect(findShopItem('pack_m')?.price).toBe(90);
    expect(findShopItem('nope')).toBeUndefined();
    expect(boosterSeconds('boost_1h')).toBe(3600);
  });

  it('схема профиля принимает и обычные, и премиум-гербы', () => {
    expect(crestSchema.safeParse('lion').success).toBe(true);
    expect(crestSchema.safeParse('lion-gold').success).toBe(true);
    expect(crestSchema.safeParse('dragon-neon').success).toBe(false);
  });
});
