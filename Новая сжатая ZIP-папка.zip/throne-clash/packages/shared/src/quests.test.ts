import { describe, expect, it } from 'vitest';
import {
  ACHIEVEMENTS,
  ALL_QUESTS,
  DAILY,
  LOGIN_DAYS,
  LOGIN_REWARDS,
  TUTORIAL,
  claimPeriod,
  dayKey,
  findQuest,
  isCounter,
  loginState,
} from './quests';

describe('каталог заданий', () => {
  it('10 шагов туториала, 4 ежедневных, у всех уникальные id', () => {
    expect(TUTORIAL).toHaveLength(10);
    expect(DAILY).toHaveLength(4);
    const ids = ALL_QUESTS.map((q) => q.id);
    expect(new Set(ids).size).toBe(ids.length);
    expect(ACHIEVEMENTS.length).toBeGreaterThanOrEqual(10);
  });

  it('туториал ведёт на экраны; ежедневные награждают деревянным сундуком', () => {
    for (const q of TUTORIAL) expect(q.route).toMatch(/^\//);
    for (const q of DAILY) expect(q.reward.chest).toBe('wooden');
  });

  it('цели положительные, награды непустые', () => {
    for (const q of ALL_QUESTS) {
      expect(q.target).toBeGreaterThan(0);
      const r = q.reward;
      expect(Boolean(r.resources) || Boolean(r.gems) || Boolean(r.chest)).toBe(true);
    }
  });

  it('поиск и период получения', () => {
    expect(findQuest('d_win')?.kind).toBe('daily');
    expect(findQuest('nope')).toBeUndefined();
    expect(claimPeriod({ kind: 'daily' }, '2026-03-10')).toBe('2026-03-10');
    expect(claimPeriod({ kind: 'tutorial' }, '2026-03-10')).toBe('once');
    expect(claimPeriod({ kind: 'achievement' }, '2026-03-10')).toBe('once');
  });

  it('счётчики отличаются от состояний замка', () => {
    expect(isCounter('upgrade')).toBe(true);
    expect(isCounter('castle_level')).toBe(false);
  });
});

describe('ежедневный вход', () => {
  it('7 наград, седьмая — серебряный сундук', () => {
    expect(LOGIN_REWARDS).toHaveLength(LOGIN_DAYS);
    expect(LOGIN_REWARDS[6]).toMatchObject({ chest: 'silver' });
  });

  it('первый вход — день 1', () => {
    expect(loginState(null, '2026-03-10')).toEqual({ claimed: false, day: 1 });
  });

  it('сегодня уже получено', () => {
    expect(loginState({ day: '2026-03-10', streak: 3 }, '2026-03-10')).toEqual({
      claimed: true,
      day: 3,
    });
  });

  it('следующий день продолжает серию, пропуск сбрасывает, после 7-го — заново', () => {
    expect(loginState({ day: '2026-03-10', streak: 3 }, '2026-03-11')).toEqual({
      claimed: false,
      day: 4,
    });
    expect(loginState({ day: '2026-03-10', streak: 3 }, '2026-03-12')).toEqual({
      claimed: false,
      day: 1,
    });
    expect(loginState({ day: '2026-03-10', streak: 7 }, '2026-03-11')).toEqual({
      claimed: false,
      day: 1,
    });
  });

  it('граница месяца и года — это соседние дни', () => {
    expect(loginState({ day: '2026-02-28', streak: 2 }, '2026-03-01').day).toBe(3);
    expect(loginState({ day: '2026-12-31', streak: 5 }, '2027-01-01').day).toBe(6);
  });

  it('ключ дня — по UTC', () => {
    expect(dayKey(new Date('2026-03-10T23:59:59Z'))).toBe('2026-03-10');
    expect(dayKey(new Date('2026-03-11T00:00:00Z'))).toBe('2026-03-11');
  });
});
