import {
  MAX_BUILDING_LEVEL,
  MAX_TERRITORY_LEVEL,
  RESOURCE_KEYS,
  TERRITORY_CASTLE_LEVELS,
  type BuildingKey,
  type ResourceKey,
} from './constants';
import { getBalance } from './balance';

/**
 * Экономика замка: производство, склад, стоимость и время построек, ускорение, отмена.
 * Только чистые функции (D-08): время и случайность приходят параметрами.
 * Числа — из docs/GAME_DESIGN.md §1–2; образцы значений проверяются тестами.
 */

export type ResourceAmounts = Record<ResourceKey, number>;

// ── Производство и склад ────────────────────────────────────────────────────

/** Базовое производство в час на 1-м уровне. */
export const PRODUCTION_BASE: Readonly<ResourceAmounts> = {
  gold: 300,
  wood: 400,
  stone: 350,
  food: 400,
};
export const PRODUCTION_GROWTH = 1.17;

/** Какое здание производит какой ресурс. */
export const PRODUCER_OF: Readonly<Record<ResourceKey, BuildingKey>> = {
  gold: 'goldmine',
  wood: 'sawmill',
  stone: 'quarry',
  food: 'farm',
};

export const WAREHOUSE_BASE = 3000;
export const WAREHOUSE_GROWTH = 1.32;
/** Доля ёмкости склада, защищённая от грабежа. */
export const PROTECTED_SHARE = 0.2;

/** Бонусы технологий и героя (этап 4). Нули по умолчанию: формулы уже принимают их. */
export interface EconomyModifiers {
  /** Множитель производства по ресурсам, например 0.05 = +5%. */
  production?: Partial<Record<ResourceKey, number>>;
  /** Прибавка к ёмкости склада (доля). */
  warehouse?: number;
  /** Сокращение времени стройки (доля). */
  buildTime?: number;
}

/** Производство в час; уровень 0 (здания нет) не производит. */
export function productionPerHour(
  resource: ResourceKey,
  level: number,
  worldSpeed = 1,
  mods: EconomyModifiers = {},
): number {
  if (level < 1) return 0;
  const base = Math.round(PRODUCTION_BASE[resource] * PRODUCTION_GROWTH ** (level - 1));
  return base * (1 + (mods.production?.[resource] ?? 0)) * worldSpeed * getBalance().production;
}

/** Ёмкость склада на каждый из четырёх ресурсов. */
export function warehouseCap(level: number, mods: EconomyModifiers = {}): number {
  const base = Math.round(WAREHOUSE_BASE * WAREHOUSE_GROWTH ** (Math.max(1, level) - 1));
  return Math.round(base * (1 + (mods.warehouse ?? 0)));
}

/** Незащищённая часть запаса — то, что можно ограбить. */
export function lootableAmount(stored: number, cap: number): number {
  return Math.max(0, Math.floor(stored) - Math.floor(cap * PROTECTED_SHARE));
}

/**
 * Продвигает запас на `seconds` секунд.
 * Переполнение не «сгорает»: если запас уже выше ёмкости (награда, возврат), производство
 * просто стоит, а накопленное остаётся. Отрицательный чистый приход (содержание армии) режет запас до 0.
 */
export function advanceStock(
  stored: number,
  ratePerHour: number,
  cap: number,
  seconds: number,
): number {
  if (seconds <= 0) return stored;
  const next = stored + (ratePerHour * seconds) / 3600;
  if (ratePerHour >= 0) return stored >= cap ? stored : Math.min(cap, next);
  return Math.max(0, next);
}

export function advanceResources(
  stored: ResourceAmounts,
  ratesPerHour: ResourceAmounts,
  cap: number,
  seconds: number,
): ResourceAmounts {
  const out = { ...stored };
  for (const r of RESOURCE_KEYS) out[r] = advanceStock(stored[r], ratesPerHour[r], cap, seconds);
  return out;
}

export type BuildingLevels = Partial<Record<BuildingKey, number>>;

export function ratesFor(
  levels: BuildingLevels,
  worldSpeed = 1,
  mods: EconomyModifiers = {},
): ResourceAmounts {
  const rate = (r: ResourceKey) =>
    productionPerHour(r, levels[PRODUCER_OF[r]] ?? 0, worldSpeed, mods);
  return {
    gold: rate('gold'),
    wood: rate('wood'),
    stone: rate('stone'),
    // Рыбацкая пристань добавляет еду к ферме
    food: rate('food') + fisheryFood(levels.fishery ?? 0, worldSpeed, mods),
  };
}

// ── Рыбалка, алмазы ─────────────────────────────────────────────────────────

export const FISHERY_BASE = 260;
export const FISHERY_GROWTH = 1.16;

/** Еда в час от Рыбацкой пристани; уровень 0 не производит. */
export function fisheryFood(level: number, worldSpeed = 1, mods: EconomyModifiers = {}): number {
  if (level < 1) return 0;
  const base = Math.round(FISHERY_BASE * FISHERY_GROWTH ** (level - 1));
  return base * (1 + (mods.production?.food ?? 0)) * worldSpeed * getBalance().production;
}

export const DIAMOND_BASE = 0.4;
export const DIAMOND_GROWTH = 1.14;

/**
 * Кристаллы в час от Алмазной шахты (доли копятся в `gemsCarry`, целые попадают в запас).
 * Скромная ставка: даже на 20-м уровне это меньше 5 кристаллов в час (D-60).
 */
export function gemsPerHour(level: number, worldSpeed = 1): number {
  if (level < 1) return 0;
  return DIAMOND_BASE * DIAMOND_GROWTH ** (level - 1) * worldSpeed;
}

/** Башня магов: быстрее исследования (до −25%) и опыт героя (до +20%). */
export const mageResearchBonus = (level: number): number =>
  Math.min(0.25, 0.0125 * Math.max(0, level));
export const mageHeroXpBonus = (level: number): number => Math.min(0.2, 0.01 * Math.max(0, level));

// ── Здания ──────────────────────────────────────────────────────────────────

export const COST_GROWTH = 1.45;
export const TIME_GROWTH = 1.5;

export const BUILDING_BASE: Readonly<
  Record<BuildingKey, { cost: Readonly<ResourceAmounts>; seconds: number }>
> = {
  castle: { cost: { gold: 300, wood: 300, stone: 300, food: 200 }, seconds: 120 },
  barracks: { cost: { gold: 150, wood: 200, stone: 120, food: 100 }, seconds: 90 },
  farm: { cost: { gold: 80, wood: 120, stone: 60, food: 0 }, seconds: 30 },
  sawmill: { cost: { gold: 80, wood: 60, stone: 120, food: 0 }, seconds: 30 },
  quarry: { cost: { gold: 80, wood: 120, stone: 60, food: 0 }, seconds: 30 },
  goldmine: { cost: { gold: 60, wood: 120, stone: 120, food: 0 }, seconds: 40 },
  warehouse: { cost: { gold: 100, wood: 150, stone: 150, food: 0 }, seconds: 45 },
  forge: { cost: { gold: 200, wood: 200, stone: 200, food: 100 }, seconds: 100 },
  academy: { cost: { gold: 250, wood: 250, stone: 200, food: 150 }, seconds: 100 },
  walls: { cost: { gold: 150, wood: 100, stone: 250, food: 0 }, seconds: 80 },
  hospital: { cost: { gold: 200, wood: 200, stone: 150, food: 100 }, seconds: 80 },
  territory: { cost: { gold: 800, wood: 1200, stone: 1200, food: 400 }, seconds: 1800 },
  fishery: { cost: { gold: 120, wood: 180, stone: 100, food: 0 }, seconds: 60 },
  diamondmine: { cost: { gold: 400, wood: 300, stone: 500, food: 100 }, seconds: 240 },
  magetower: { cost: { gold: 350, wood: 300, stone: 350, food: 150 }, seconds: 200 },
  archertower: { cost: { gold: 220, wood: 260, stone: 300, food: 0 }, seconds: 120 },
  ballistatower: { cost: { gold: 260, wood: 320, stone: 360, food: 50 }, seconds: 150 },
  stormtower: { cost: { gold: 500, wood: 400, stone: 500, food: 150 }, seconds: 260 },
};

const round5 = (n: number): number => Math.round(n / 5) * 5;

/** Стоимость перехода на уровень `level` (1…20). */
export function buildingCost(key: BuildingKey, level: number): ResourceAmounts {
  const base = BUILDING_BASE[key].cost;
  const k = COST_GROWTH ** (level - 1) * getBalance().buildCost;
  return {
    gold: round5(base.gold * k),
    wood: round5(base.wood * k),
    stone: round5(base.stone * k),
    food: round5(base.food * k),
  };
}

/** Доля сокращения времени стройки от уровня Замка: −2% за уровень, не более −40%. */
export const castleTimeBonus = (castleLevel: number): number =>
  Math.min(0.4, 0.02 * (castleLevel - 1));

/** Секунд на постройку уровня `level`. `castleLevel` — уровень Замка на момент старта. */
export function buildSeconds(
  key: BuildingKey,
  level: number,
  castleLevel: number,
  worldSpeed = 1,
  mods: EconomyModifiers = {},
): number {
  const base = BUILDING_BASE[key].seconds * TIME_GROWTH ** (level - 1) * getBalance().buildTime;
  const factor = 1 - castleTimeBonus(castleLevel) - (mods.buildTime ?? 0);
  return Math.max(1, Math.round((base * Math.max(0.1, factor)) / worldSpeed));
}

/** Потолок уровня здания: у Земель он свой (0…4), у остальных — 20. */
export const maxBuildingLevel = (key: BuildingKey): number =>
  key === 'territory' ? MAX_TERRITORY_LEVEL : MAX_BUILDING_LEVEL;

/**
 * Максимальный уровень здания при данном уровне Замка (сам Замок ограничен только потолком).
 * Земли открываются порогами уровня Замка (TERRITORY_CASTLE_LEVELS).
 */
export function maxLevelFor(key: BuildingKey, castleLevel: number): number {
  if (key === 'castle') return MAX_BUILDING_LEVEL;
  if (key === 'territory') return TERRITORY_CASTLE_LEVELS.filter((n) => castleLevel >= n).length;
  return Math.min(MAX_BUILDING_LEVEL, castleLevel);
}

/** Что нужно для первой постройки здания (для последующих уровней не проверяется). */
export interface BuildingRequirement {
  territory?: number;
  castle?: number;
  buildings?: Partial<Record<BuildingKey, number>>;
}

export const BUILDING_REQUIRES: Readonly<Partial<Record<BuildingKey, BuildingRequirement>>> = {
  fishery: { territory: 1 },
  archertower: { territory: 1, buildings: { barracks: 2 } },
  diamondmine: { territory: 2, castle: 6 },
  ballistatower: { territory: 2, buildings: { barracks: 5, forge: 3 } },
  magetower: { territory: 2, buildings: { academy: 3 } },
  stormtower: { territory: 3, buildings: { magetower: 5 } },
};

export type MissingRequirement =
  | { kind: 'territory'; level: number }
  | { kind: 'castle'; level: number }
  | { kind: 'building'; key: BuildingKey; level: number };

/** Невыполненные условия первой постройки. Пустой список — можно строить. */
export function missingRequirements(
  key: BuildingKey,
  levels: BuildingLevels,
  castleLevel: number,
): MissingRequirement[] {
  const req = BUILDING_REQUIRES[key];
  if (!req) return [];
  const out: MissingRequirement[] = [];
  if (req.territory !== undefined && (levels.territory ?? 0) < req.territory)
    out.push({ kind: 'territory', level: req.territory });
  if (req.castle !== undefined && castleLevel < req.castle)
    out.push({ kind: 'castle', level: req.castle });
  for (const [b, need] of Object.entries(req.buildings ?? {}) as Array<[BuildingKey, number]>) {
    if ((levels[b] ?? 0) < need) out.push({ kind: 'building', key: b, level: need });
  }
  return out;
}

// ── Очередь ─────────────────────────────────────────────────────────────────

/** Уровень Замка, с которого второй слот открывается бесплатно. */
export const EXTRA_SLOT_CASTLE_LEVEL = 8;
export const EXTRA_SLOT_GEMS = 250;
/** 1 кристалл за каждые 5 минут остатка, минимум 1. */
export const SPEEDUP_SECONDS_PER_GEM = 300;
export const CANCEL_REFUND_SHARE = 0.5;

export const buildSlots = (castleLevel: number, extraUnlocked: boolean): number =>
  extraUnlocked || castleLevel >= EXTRA_SLOT_CASTLE_LEVEL ? 2 : 1;

export const speedupGems = (remainingSeconds: number): number =>
  Math.max(1, Math.ceil(remainingSeconds / SPEEDUP_SECONDS_PER_GEM));

/** Возврат при отмене: половина потраченного, округление вниз. */
export function cancelRefund(paid: ResourceAmounts): ResourceAmounts {
  const f = (n: number) => Math.floor(n * CANCEL_REFUND_SHARE);
  return { gold: f(paid.gold), wood: f(paid.wood), stone: f(paid.stone), food: f(paid.food) };
}

/** Помощь братства: сокращение остатка (этап 6). */
export const guildHelpSeconds = (totalSeconds: number): number =>
  Math.max(10, Math.floor(totalSeconds * 0.01));

/** Чего не хватает для оплаты; пустой объект — хватает. Дробная часть запаса не считается. */
export function shortfall(have: ResourceAmounts, cost: ResourceAmounts): Partial<ResourceAmounts> {
  const out: Partial<ResourceAmounts> = {};
  for (const r of RESOURCE_KEYS) {
    const missing = cost[r] - Math.floor(have[r]);
    if (missing > 0) out[r] = missing;
  }
  return out;
}

export function subtractCost(have: ResourceAmounts, cost: ResourceAmounts): ResourceAmounts {
  return {
    gold: have.gold - cost.gold,
    wood: have.wood - cost.wood,
    stone: have.stone - cost.stone,
    food: have.food - cost.food,
  };
}

export function addAmounts(a: ResourceAmounts, b: ResourceAmounts): ResourceAmounts {
  return {
    gold: a.gold + b.gold,
    wood: a.wood + b.wood,
    stone: a.stone + b.stone,
    food: a.food + b.food,
  };
}
