import {
  advanceResources,
  gemsPerHour,
  ratesFor,
  warehouseCap,
  type BuildingLevels,
  type EconomyModifiers,
  type ResourceAmounts,
} from './economy';
import { upkeepPerHour, type Army, type UnitId } from './army';
import { techEconomyMods, type TechKey, type TechLevels } from './research';
import type { BuildingKey } from './constants';

/**
 * Ленивый расчёт замка (D-03): приводит запасы, уровни, армию и технологии к моменту `nowMs`.
 * События (стройка, обучение, исследование) применяются по порядку окончания, а производство
 * считается кусками между ними. Поэтому результат не зависит от того, как часто вызывают функцию.
 */

export interface PendingBuild {
  id: string;
  key: BuildingKey;
  toLevel: number;
  finishesAtMs: number;
}
export interface PendingTrain {
  id: string;
  unit: UnitId;
  count: number;
  finishesAtMs: number;
}
export interface PendingResearch {
  id: string;
  tech: TechKey;
  toLevel: number;
  finishesAtMs: number;
}

export interface SettleInput {
  resources: ResourceAmounts;
  updatedAtMs: number;
  levels: BuildingLevels;
  /** Идущие постройки. */
  tasks: readonly PendingBuild[];
  worldSpeed?: number;
  /** Дополнительные модификаторы поверх технологий и героя. */
  mods?: EconomyModifiers;
  army?: Army;
  trains?: readonly PendingTrain[];
  tech?: TechLevels;
  research?: readonly PendingResearch[];
  /** Прибавка героя к производству (навык + реликвия). */
  heroProduction?: number;
  /** Кристаллы и накопленная доля кристалла от Алмазной шахты. */
  gems?: number;
  gemsCarry?: number;
}

export interface SettleResult {
  resources: ResourceAmounts;
  /** Кристаллы после расчёта и остаток доли (0…1). */
  gems: number;
  gemsCarry: number;
  /** Сколько кристаллов добыла шахта за этот расчёт. */
  gemsMined: number;
  updatedAtMs: number;
  levels: BuildingLevels;
  army: Army;
  tech: TechLevels;
  /** Завершённые постройки в порядке окончания. */
  completed: PendingBuild[];
  pending: PendingBuild[];
  completedTrains: PendingTrain[];
  pendingTrains: PendingTrain[];
  completedResearch: PendingResearch[];
  pendingResearch: PendingResearch[];
}

type Event =
  | { kind: 'build'; at: number; order: number; task: PendingBuild }
  | { kind: 'research'; at: number; order: number; task: PendingResearch }
  | { kind: 'train'; at: number; order: number; task: PendingTrain };

/** Итоговые модификаторы: технологии + герой + внешние. */
export function combinedMods(
  tech: TechLevels,
  heroProduction: number,
  extra: EconomyModifiers = {},
): EconomyModifiers {
  const t = techEconomyMods(tech);
  const production: Partial<Record<'gold' | 'wood' | 'stone' | 'food', number>> = {};
  for (const r of ['gold', 'wood', 'stone', 'food'] as const) {
    production[r] = (t.production?.[r] ?? 0) + (extra.production?.[r] ?? 0) + heroProduction;
  }
  return {
    production,
    warehouse: (t.warehouse ?? 0) + (extra.warehouse ?? 0),
    buildTime: extra.buildTime ?? 0,
  };
}

/** Чистые ставки в час: производство минус содержание армии (еда). */
export function netRates(
  levels: BuildingLevels,
  army: Army,
  tech: TechLevels,
  heroProduction: number,
  worldSpeed = 1,
  extra: EconomyModifiers = {},
): ResourceAmounts {
  const rates = ratesFor(levels, worldSpeed, combinedMods(tech, heroProduction, extra));
  return { ...rates, food: rates.food - upkeepPerHour(army) * worldSpeed };
}

export function settleCastle(input: SettleInput, nowMs: number): SettleResult {
  const speed = input.worldSpeed ?? 1;
  const hero = input.heroProduction ?? 0;
  const levels: BuildingLevels = { ...input.levels };
  const army: Army = structuredClone(input.army ?? {});
  const tech: TechLevels = { ...(input.tech ?? {}) };
  let resources = { ...input.resources };
  let cursor = input.updatedAtMs;
  let carry = input.gemsCarry ?? 0;
  let mined = 0;

  const events: Event[] = [
    ...input.tasks.map((task, i): Event => ({
      kind: 'build',
      at: task.finishesAtMs,
      order: i,
      task,
    })),
    ...(input.research ?? []).map((task, i): Event => ({
      kind: 'research',
      at: task.finishesAtMs,
      order: i,
      task,
    })),
    ...(input.trains ?? []).map((task, i): Event => ({
      kind: 'train',
      at: task.finishesAtMs,
      order: i,
      task,
    })),
  ].sort((a, b) => a.at - b.at || a.order - b.order);

  const advanceTo = (t: number): void => {
    if (t <= cursor) return;
    const mods = combinedMods(tech, hero, input.mods);
    const cap = warehouseCap(levels.warehouse ?? 1, mods);
    resources = advanceResources(
      resources,
      netRates(levels, army, tech, hero, speed, input.mods),
      cap,
      (t - cursor) / 1000,
    );
    // Алмазная шахта: доли кристалла копятся, целые уходят в запас
    carry += (gemsPerHour(levels.diamondmine ?? 0, speed) * (t - cursor)) / 3_600_000;
    const whole = Math.floor(carry);
    if (whole > 0) {
      mined += whole;
      carry -= whole;
    }
    cursor = t;
  };

  const completed: PendingBuild[] = [];
  const pending: PendingBuild[] = [];
  const completedTrains: PendingTrain[] = [];
  const pendingTrains: PendingTrain[] = [];
  const completedResearch: PendingResearch[] = [];
  const pendingResearch: PendingResearch[] = [];

  for (const ev of events) {
    if (ev.at > nowMs) {
      if (ev.kind === 'build') pending.push(ev.task);
      else if (ev.kind === 'research') pendingResearch.push(ev.task);
      else pendingTrains.push(ev.task);
      continue;
    }
    advanceTo(ev.at);
    if (ev.kind === 'build') {
      levels[ev.task.key] = Math.max(levels[ev.task.key] ?? 0, ev.task.toLevel);
      completed.push(ev.task);
    } else if (ev.kind === 'research') {
      tech[ev.task.tech] = Math.max(tech[ev.task.tech] ?? 0, ev.task.toLevel);
      completedResearch.push(ev.task);
    } else {
      const cur = army[ev.task.unit] ?? { count: 0, wounded: 0 };
      army[ev.task.unit] = { ...cur, count: cur.count + ev.task.count };
      completedTrains.push(ev.task);
    }
  }
  advanceTo(nowMs);
  return {
    resources,
    gems: (input.gems ?? 0) + mined,
    gemsCarry: carry,
    gemsMined: mined,
    updatedAtMs: Math.max(cursor, input.updatedAtMs),
    levels,
    army,
    tech,
    completed,
    pending,
    completedTrains,
    pendingTrains,
    completedResearch,
    pendingResearch,
  };
}
