/** Чат: каналы, лимиты, фильтр брани (docs/GAME_DESIGN.md §13, D-10). */

export const CHAT_MAX_LEN = 300;
export const CHAT_RATE_MAX = 5;
export const CHAT_RATE_WINDOW_SECONDS = 10;
export const CHAT_HISTORY_LIMIT = 50;
export const CHAT_REPORT_REASON_MAX = 200;

export type ChannelRef = { kind: 'world' } | { kind: 'guild' } | { kind: 'dm'; userId: string };

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/** Каналы в API: `world`, `guild`, `dm:<userId собеседника>`. */
export function parseChannel(raw: string): ChannelRef | null {
  if (raw === 'world') return { kind: 'world' };
  if (raw === 'guild') return { kind: 'guild' };
  if (raw.startsWith('dm:')) {
    const userId = raw.slice(3);
    return UUID_RE.test(userId) ? { kind: 'dm', userId: userId.toLowerCase() } : null;
  }
  return null;
}

/** Хранимое имя канала: для личных — пара id по возрастанию, чтобы у обоих был один канал. */
export function storedChannel(ref: ChannelRef, me: string, guildId: string | null): string | null {
  if (ref.kind === 'world') return 'world';
  if (ref.kind === 'guild') return guildId ? `guild:${guildId}` : null;
  const [a, b] = [me, ref.userId].sort();
  return `dm:${a}:${b}`;
}

// ── Фильтр брани ─────────────────────────────────────────────────────────────

/** Латиница и цифры, похожие на кириллицу: «xуй» и «6лять» не должны проскакивать. */
const LOOK: Readonly<Record<string, string>> = {
  a: 'а',
  b: 'в',
  c: 'с',
  e: 'е',
  h: 'н',
  k: 'к',
  m: 'м',
  o: 'о',
  p: 'р',
  t: 'т',
  x: 'х',
  y: 'у',
  '0': 'о',
  '3': 'з',
  '6': 'б',
  ё: 'е',
};

/** Приведение слова к виду для сравнения: регистр, похожие буквы, повторы («хуууй» → «хуй»). */
export function normalizeWord(word: string): string {
  const lower = word.normalize('NFKC').toLowerCase();
  const mapped = Array.from(lower, (ch) => LOOK[ch] ?? ch).join('');
  return mapped.replace(/(.)\1+/gu, '$1');
}

// Корни, с которых слово считается бранным. Списки нужны фильтру и редактируются здесь (D-10).
const ROOTS_RU = [
  'хуй',
  'хуе',
  'хуя',
  'хуи',
  'пизд',
  'ебан',
  'ебат',
  'ебал',
  'ебну',
  'ебло',
  'блят',
  'бляд',
  'мудак',
  'мудил',
  'пидор',
  'пидар',
  'пидр',
  'гандон',
  'залуп',
  'шлюх',
];
const ROOTS_EN = ['fuck', 'shit', 'bitch', 'cunt', 'whore', 'asshole', 'bastard', 'nigg', 'fagg'];
const EXACT = ['сука', 'суки', 'сучка', 'сучара', 'dick', 'dicks', 'cock', 'pussy', 'slut'];

// Корни хранятся в нормализованном виде (после LOOK и схлопывания повторов)
const ROOTS = [...ROOTS_RU, ...ROOTS_EN].map(normalizeWord);
const EXACT_SET = new Set(EXACT.map(normalizeWord));

export const isProfane = (word: string): boolean => {
  const w = normalizeWord(word);
  return EXACT_SET.has(w) || ROOTS.some((r) => w.startsWith(r));
};

/** Бранные слова заменяются звёздочками; остальной текст не меняется. */
export function filterProfanity(text: string): { text: string; filtered: boolean } {
  let filtered = false;
  const out = text.replace(/[\p{L}\p{N}]+/gu, (word) => {
    if (!isProfane(word)) return word;
    filtered = true;
    return '*'.repeat(word.length);
  });
  return { text: out, filtered };
}

// Управляющие и невидимые символы (в виде строки, чтобы в исходнике не было невидимых знаков)
// eslint-disable-next-line no-control-regex
const CONTROL_CHARS = new RegExp('[\\u0000-\\u001f\\u007f\\u200b-\\u200f\\u202a-\\u202e]', 'g');

/** Текст сообщения: без управляющих символов, с схлопнутыми пробелами; пустой → null. */
export function cleanMessage(raw: string): string | null {
  const text = raw.normalize('NFKC').replace(CONTROL_CHARS, ' ').replace(/\s+/g, ' ').trim();
  return text.length === 0 || text.length > CHAT_MAX_LEN ? null : text;
}
