import { describe, expect, it } from 'vitest';
import { RESOURCE_KEYS, START_RESOURCES } from './constants';
import { warehouseCap, type BuildingLevels } from './economy';
import { settleCastle, type PendingBuild, type SettleInput } from './settle';

const HOUR_ = 3_600_000;

describe('settleCastle', () => {
  const base = {
    resources: { ...START_RESOURCES },
    updatedAtMs: 0,
    levels: {
      castle: 1,
      farm: 1,
      sawmill: 1,
      quarry: 1,
      goldmine: 1,
      warehouse: 1,
    } as BuildingLevels,
    tasks: [] as PendingBuild[],
  };
  const HOUR = HOUR_;

  it('без задач — просто производство', () => {
    const r = settleCastle(base, HOUR / 2);
    expect(r.resources.gold).toBe(1150);
    expect(r.resources.food).toBe(1200);
    expect(r.completed).toEqual([]);
  });

  it('постройка меняет ставку с момента завершения, а не с момента вызова', () => {
    // ферма L2 готова через 30 мин: полчаса по 400/ч, затем полчаса по 468/ч
    const task: PendingBuild = { id: 't', key: 'farm', toLevel: 2, finishesAtMs: HOUR / 2 };
    const r = settleCastle({ ...base, tasks: [task] }, HOUR);
    expect(r.levels.farm).toBe(2);
    expect(r.resources.food).toBeCloseTo(1000 + 200 + 234, 6);
    expect(r.completed).toEqual([task]);
    expect(r.pending).toEqual([]);
  });

  it('незавершённая постройка остаётся в очереди', () => {
    const task: PendingBuild = { id: 't', key: 'farm', toLevel: 2, finishesAtMs: 2 * HOUR };
    const r = settleCastle({ ...base, tasks: [task] }, HOUR);
    expect(r.levels.farm).toBe(1);
    expect(r.pending).toEqual([task]);
  });

  it('несколько построек применяются по порядку окончания, а не по порядку в списке', () => {
    const a: PendingBuild = { id: 'a', key: 'farm', toLevel: 2, finishesAtMs: 40 * 60_000 };
    const b: PendingBuild = { id: 'b', key: 'farm', toLevel: 3, finishesAtMs: 20 * 60_000 };
    // b (L3) раньше a (L2): итоговый уровень не должен «откатиться» на 2
    const r = settleCastle({ ...base, tasks: [a, b] }, HOUR);
    expect(r.completed.map((t) => t.id)).toEqual(['b', 'a']);
    expect(r.levels.farm).toBe(3);
  });

  it('ИНВАРИАНТ: результат не зависит от частоты вызовов (нет «голодания» при частом опросе)', () => {
    const task: PendingBuild = {
      id: 't',
      key: 'goldmine',
      toLevel: 2,
      finishesAtMs: 17 * 60_000 + 123,
    };
    const once = settleCastle({ ...base, tasks: [task] }, 3 * HOUR);
    let state: SettleInput = { ...base, levels: { ...base.levels }, tasks: [task] };
    for (let t = 1000; t <= 3 * HOUR; t += 1000) {
      const step = settleCastle(state, t);
      state = {
        resources: step.resources,
        updatedAtMs: step.updatedAtMs,
        levels: step.levels,
        tasks: step.pending,
      };
    }
    for (const r of RESOURCE_KEYS) expect(state.resources[r]).toBeCloseTo(once.resources[r], 4);
    expect(state.levels.goldmine).toBe(2);
  });

  it('производство идёт по ёмкости склада, обновлённого построенным Складом', () => {
    const start = { ...base, resources: { gold: 2990, wood: 0, stone: 0, food: 0 } };
    const upgrade: PendingBuild = { id: 'w', key: 'warehouse', toLevel: 2, finishesAtMs: 1000 };
    const r = settleCastle({ ...start, tasks: [upgrade] }, HOUR);
    expect(r.resources.gold).toBeGreaterThan(3000); // после расширения склада запас продолжил расти
    expect(r.resources.gold).toBeLessThanOrEqual(warehouseCap(2));
  });

  it('время назад (часы клиента/сервера разошлись) не портит состояние', () => {
    const r = settleCastle({ ...base, updatedAtMs: 10_000 }, 5_000);
    expect(r.resources).toEqual(base.resources);
    expect(r.updatedAtMs).toBe(10_000);
  });

  it('скорость мира ускоряет производство', () => {
    const r = settleCastle({ ...base, worldSpeed: 10 }, HOUR / 10); // 6 минут при x10 = как час
    expect(r.resources.gold).toBe(1000 + 300);
    expect(settleCastle({ ...base, worldSpeed: 10 }, HOUR).resources.gold).toBe(3000); // упёрлось в склад
  });
});

describe('settleCastle: армия, исследования, герой', () => {
  const base: SettleInput = {
    resources: { gold: 0, wood: 0, stone: 0, food: 1000 },
    updatedAtMs: 0,
    levels: {
      castle: 1,
      farm: 1,
      sawmill: 1,
      quarry: 1,
      goldmine: 1,
      warehouse: 1,
    } as BuildingLevels,
    tasks: [],
  };
  const H = 3_600_000;

  it('содержание армии вычитается из выработки еды', () => {
    const r = settleCastle({ ...base, army: { infantry_1: { count: 100, wounded: 0 } } }, H);
    expect(r.resources.food).toBe(1000 + 400 - 100); // ферма 400/ч, армия 100/ч
    expect(r.resources.gold).toBe(300);
  });

  it('еда не уходит ниже нуля, когда армия прожорливее фермы', () => {
    const r = settleCastle({ ...base, army: { siege_5: { count: 1000, wounded: 0 } } }, 10 * H);
    expect(r.resources.food).toBe(0);
  });

  it('обученный отряд начинает есть с момента выхода из казармы, а не раньше и не позже', () => {
    const r = settleCastle(
      {
        ...base,
        resources: { ...base.resources, food: 0 },
        trains: [{ id: 't', unit: 'infantry_1', count: 200, finishesAtMs: H / 2 }],
      },
      H,
    );
    // полчаса +400/ч, затем полчаса 400 − 200 = +200/ч
    expect(r.resources.food).toBeCloseTo(200 + 100, 6);
    expect(r.army.infantry_1?.count).toBe(200);
    expect(r.completedTrains).toHaveLength(1);
  });

  it('исследование ускоряет выработку только после завершения', () => {
    const r = settleCastle(
      { ...base, research: [{ id: 'r', tech: 'mining', toLevel: 2, finishesAtMs: H / 2 }] },
      H,
    );
    // золото: полчаса по 300/ч и полчаса по 300·1.10 = 330/ч
    expect(r.resources.gold).toBeCloseTo(150 + 165, 6);
    expect(r.tech.mining).toBe(2);
    expect(r.completedResearch).toHaveLength(1);
  });

  it('Логистика поднимает ёмкость склада', () => {
    const start = {
      ...base,
      resources: { gold: 2990, wood: 0, stone: 0, food: 0 },
      tech: { logistics: 5 },
    };
    const r = settleCastle(start, 100 * H);
    expect(r.resources.gold).toBe(warehouseCap(1, { warehouse: 0.2 }));
  });

  it('герой: навык хозяйственный увеличивает всю выработку', () => {
    const r = settleCastle({ ...base, heroProduction: 0.15 }, H);
    expect(r.resources.gold).toBeCloseTo(345, 6);
    expect(r.resources.wood).toBeCloseTo(460, 6);
  });

  it('события трёх видов идут по порядку окончания, результат не зависит от частоты вызовов', () => {
    const input: SettleInput = {
      ...base,
      tasks: [{ id: 'b', key: 'goldmine', toLevel: 2, finishesAtMs: 20 * 60_000 }],
      trains: [{ id: 't', unit: 'archer_2', count: 50, finishesAtMs: 35 * 60_000 }],
      research: [{ id: 'r', tech: 'farming', toLevel: 1, finishesAtMs: 10 * 60_000 }],
      heroProduction: 0.03,
    };
    const once = settleCastle(input, 2 * H);
    let state: SettleInput = input;
    for (let t = 30_000; t <= 2 * H; t += 30_000) {
      const s = settleCastle(state, t);
      state = {
        ...state,
        resources: s.resources,
        updatedAtMs: s.updatedAtMs,
        levels: s.levels,
        tasks: s.pending,
        army: s.army,
        trains: s.pendingTrains,
        tech: s.tech,
        research: s.pendingResearch,
      };
    }
    for (const r of RESOURCE_KEYS) expect(state.resources[r]).toBeCloseTo(once.resources[r], 3);
    expect(state.army).toEqual(once.army);
    expect(state.tech).toEqual(once.tech);
  });

  it('старые вызовы без новых полей работают как раньше', () => {
    const r = settleCastle({ ...base, resources: { ...START_RESOURCES } }, H / 2);
    expect(r.army).toEqual({});
    expect(r.tech).toEqual({});
    expect(r.completedTrains).toEqual([]);
  });
});
