import { MAX_TECH_LEVEL, RESOURCE_KEYS, type ResourceKey, type UnitType } from './constants';
import type { EconomyModifiers, ResourceAmounts } from './economy';
import { getBalance } from './balance';

/**
 * Исследования Академии: 14 технологий, уровни 1…10 (docs/GAME_DESIGN.md §7).
 */

export const TECH_KEYS = [
  'farming',
  'forestry',
  'masonry',
  'mining',
  'logistics',
  'swordsmanship',
  'archery',
  'riding',
  'siegecraft',
  'tactics',
  'drill',
  'fortification',
  'armor',
  'medicine',
] as const;
export type TechKey = (typeof TECH_KEYS)[number];
export type TechLevels = Partial<Record<TechKey, number>>;
export type TechBranch = 'economy' | 'military' | 'defense';

interface TechDef {
  branch: TechBranch;
  /** Суммарная цена 1-го уровня (золото и дерево пополам). */
  baseCost: number;
  baseSec: number;
  /** Эффект за уровень (доля). */
  perLevel: number;
}

export const TECHS: Readonly<Record<TechKey, TechDef>> = {
  farming: { branch: 'economy', baseCost: 300, baseSec: 90, perLevel: 0.05 },
  forestry: { branch: 'economy', baseCost: 300, baseSec: 90, perLevel: 0.05 },
  masonry: { branch: 'economy', baseCost: 300, baseSec: 90, perLevel: 0.05 },
  mining: { branch: 'economy', baseCost: 300, baseSec: 90, perLevel: 0.05 },
  logistics: { branch: 'economy', baseCost: 350, baseSec: 100, perLevel: 0.04 },
  swordsmanship: { branch: 'military', baseCost: 400, baseSec: 120, perLevel: 0.05 },
  archery: { branch: 'military', baseCost: 400, baseSec: 120, perLevel: 0.05 },
  riding: { branch: 'military', baseCost: 400, baseSec: 120, perLevel: 0.05 },
  siegecraft: { branch: 'military', baseCost: 400, baseSec: 120, perLevel: 0.05 },
  tactics: { branch: 'military', baseCost: 500, baseSec: 150, perLevel: 0.03 },
  drill: { branch: 'military', baseCost: 500, baseSec: 150, perLevel: 0.03 },
  fortification: { branch: 'defense', baseCost: 400, baseSec: 120, perLevel: 0.05 },
  armor: { branch: 'defense', baseCost: 450, baseSec: 130, perLevel: 0.03 },
  medicine: { branch: 'defense', baseCost: 350, baseSec: 100, perLevel: 0.05 },
};

export const TECH_COST_GROWTH = 1.5;
export const TECH_TIME_GROWTH = 1.6;
export const RESEARCH_QUEUE_MAX = 2;

const round5 = (n: number): number => Math.round(n / 5) * 5;

/** Цена уровня `level` (1…10): золото и дерево поровну. */
export function techCost(key: TechKey, level: number): ResourceAmounts {
  const half = round5(
    (TECHS[key].baseCost / 2) * TECH_COST_GROWTH ** (level - 1) * getBalance().researchCost,
  );
  return { gold: half, wood: half, stone: 0, food: 0 };
}

export function techSeconds(key: TechKey, level: number, worldSpeed = 1, speedBonus = 0): number {
  return Math.max(
    1,
    Math.round(
      (TECHS[key].baseSec *
        TECH_TIME_GROWTH ** (level - 1) *
        getBalance().researchTime *
        (1 - Math.min(0.9, Math.max(0, speedBonus)))) /
        worldSpeed,
    ),
  );
}

/** Уровень Академии, нужный для уровня технологии: 2L − 1, не выше 20. */
export const academyLevelFor = (techLevel: number): number => Math.min(20, 2 * techLevel - 1);

export const isTechKey = (k: string): k is TechKey => (TECH_KEYS as readonly string[]).includes(k);

const PRODUCTION_TECH: Readonly<Record<ResourceKey, TechKey | null>> = {
  food: 'farming',
  wood: 'forestry',
  stone: 'masonry',
  gold: 'mining',
};
const ATTACK_TECH: Readonly<Record<UnitType, TechKey>> = {
  infantry: 'swordsmanship',
  archer: 'archery',
  cavalry: 'riding',
  siege: 'siegecraft',
};

export interface TechEffects {
  production: Record<ResourceKey, number>;
  warehouse: number;
  attack: Record<UnitType, number>;
  /** Общая прибавка к защите всех войск. */
  defense: number;
  /** Сокращение времени в пути. */
  travelTime: number;
  /** Сокращение времени обучения. */
  trainTime: number;
  /** Усиление эффекта Стен. */
  walls: number;
  /** Прибавка к вместимости раненых. */
  woundedCapacity: number;
  /** Скидка на лечение. */
  healDiscount: number;
}

export function techEffects(levels: TechLevels): TechEffects {
  const at = (k: TechKey): number => (levels[k] ?? 0) * TECHS[k].perLevel;
  const production = { gold: 0, wood: 0, stone: 0, food: 0 } as Record<ResourceKey, number>;
  for (const r of RESOURCE_KEYS) {
    const key = PRODUCTION_TECH[r];
    production[r] = key ? at(key) : 0;
  }
  return {
    production,
    warehouse: at('logistics'),
    attack: {
      infantry: at(ATTACK_TECH.infantry),
      archer: at(ATTACK_TECH.archer),
      cavalry: at(ATTACK_TECH.cavalry),
      siege: at(ATTACK_TECH.siege),
    },
    defense: at('armor'),
    travelTime: at('tactics'),
    trainTime: at('drill'),
    walls: at('fortification'),
    woundedCapacity: at('medicine'),
    healDiscount: at('medicine'),
  };
}

/** Часть эффектов, влияющая на экономику замка. */
export function techEconomyMods(levels: TechLevels): EconomyModifiers {
  const e = techEffects(levels);
  return { production: e.production, warehouse: e.warehouse };
}

export const MAX_TECH = MAX_TECH_LEVEL;
