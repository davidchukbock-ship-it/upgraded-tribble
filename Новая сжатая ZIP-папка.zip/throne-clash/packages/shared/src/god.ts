import { z } from 'zod';
import { CHEST_KINDS, BOOSTER_KEYS } from './chests';
import {
  BUILDING_KEYS,
  MAP_SIZE,
  MAX_BUILDING_LEVEL,
  MAX_HERO_LEVEL,
  MAX_TECH_LEVEL,
  UNIT_TIERS,
  UNIT_TYPES,
} from './constants';
import { EQUIP_SLOTS } from './hero';
import { TECH_KEYS } from './research';

/**
 * Действия режима бога над замком игрока (docs/GOD_MODE.md). Схема общая: сервер по ней проверяет тело
 * запроса, а палитра команд Ctrl+K в браузере по ней же разбирает текст.
 */
export const GOD_RESOURCES = ['gold', 'wood', 'stone', 'food', 'gems'] as const;
export const GOD_MAX_AMOUNT = 1_000_000_000;
/** Потолок значения одного ресурса: ограничение целого числа в БД. */
export const GOD_MAX_STOCK = 2_000_000_000;
export const GOD_MAX_TIME_SECONDS = 30 * 86_400;

const int = (min: number, max: number) => z.number().int().min(min).max(max);
const coord = int(0, MAP_SIZE - 1);
const unit = z.string().regex(new RegExp(`^(${UNIT_TYPES.join('|')})_[${UNIT_TIERS.join('')}]$`));

export const godActionSchema = z.discriminatedUnion('type', [
  z.object({
    type: z.literal('resources'),
    op: z.enum(['give', 'take', 'set']),
    resource: z.enum(GOD_RESOURCES),
    amount: int(0, GOD_MAX_AMOUNT),
  }),
  z.object({ type: z.literal('fill') }),
  z.object({
    type: z.literal('building'),
    key: z.enum(BUILDING_KEYS),
    level: int(0, MAX_BUILDING_LEVEL),
  }),
  z.object({ type: z.literal('finish') }),
  z.object({ type: z.literal('army'), unit, count: int(1, 1_000_000) }),
  z.object({ type: z.literal('resurrect') }),
  z.object({ type: z.literal('research'), tech: z.enum(TECH_KEYS), level: int(0, MAX_TECH_LEVEL) }),
  z.object({ type: z.literal('research_all') }),
  z.object({ type: z.literal('hero'), level: int(1, MAX_HERO_LEVEL) }),
  z.object({
    type: z.literal('hero_gear'),
    slot: z.enum(EQUIP_SLOTS),
    rarity: z.union([z.literal(1), z.literal(2), z.literal(3), z.literal(4), z.literal(5)]),
  }),
  z.object({ type: z.literal('time'), seconds: int(1, GOD_MAX_TIME_SECONDS) }),
  z.object({ type: z.literal('teleport'), x: coord, y: coord }),
  z.object({ type: z.literal('shield'), hours: int(0, 720) }),
  z.object({ type: z.literal('chest'), kind: z.enum(CHEST_KINDS), count: int(1, 100) }),
  z.object({
    type: z.literal('booster'),
    booster: z.enum(BOOSTER_KEYS as [string, ...string[]]),
    count: int(1, 100),
  }),
  z.object({ type: z.literal('reset') }),
]);
export type GodAction = z.infer<typeof godActionSchema>;

/** Краткое описание действия для журнала и панели. */
export function describeGodAction(a: GodAction): string {
  switch (a.type) {
    case 'resources':
      return `${a.op} ${a.resource} ${a.amount}`;
    case 'building':
      return `build ${a.key} ${a.level}`;
    case 'army':
      return `spawn army ${a.unit} ${a.count}`;
    case 'research':
      return `research ${a.tech} ${a.level}`;
    case 'hero':
      return `hero ${a.level}`;
    case 'hero_gear':
      return `hero gear ${a.slot} ${a.rarity}`;
    case 'time':
      return `time +${a.seconds}s`;
    case 'teleport':
      return `teleport ${a.x} ${a.y}`;
    case 'shield':
      return `shield ${a.hours}`;
    case 'chest':
      return `chest ${a.kind} ${a.count}`;
    case 'booster':
      return `booster ${a.booster} ${a.count}`;
    default:
      return a.type;
  }
}

// ── Палитра команд (Ctrl+K) ─────────────────────────────────────────────────

const UNIT_ALIASES: Record<string, string> = {
  infantry: 'infantry_1',
  archer: 'archer_1',
  cavalry: 'cavalry_1',
  siege: 'siege_1',
};
const TIME_UNITS: Record<string, number> = { s: 1, m: 60, h: 3600, d: 86_400 };

export type CommandResult = { ok: true; action: GodAction } | { ok: false; error: string };

/**
 * Разбирает строку палитры: `give gold 1000000`, `build barracks 20`, `time +1d`, `teleport 50 50`,
 * `spawn army cavalry 500`, `research all`, `hero 30`, `finish` и т. п. Числа допускают `k`/`m` (1k, 2m).
 */
export function parseGodCommand(input: string): CommandResult {
  const words = input.trim().toLowerCase().split(/\s+/).filter(Boolean);
  const fail = (error: string): CommandResult => ({ ok: false, error });
  const num = (w: string | undefined): number | null => {
    if (!w) return null;
    const m = /^(\d+(?:\.\d+)?)([km])?$/.exec(w);
    if (!m) return null;
    return Math.round(Number(m[1]) * (m[2] === 'k' ? 1e3 : m[2] === 'm' ? 1e6 : 1));
  };
  const finish = (candidate: unknown): CommandResult => {
    const r = godActionSchema.safeParse(candidate);
    return r.success ? { ok: true, action: r.data } : fail('invalid');
  };
  const [cmd, a, b, c] = words;
  if (!cmd) return fail('empty');
  switch (cmd) {
    case 'give':
    case 'take':
    case 'set': {
      const amount = num(b);
      if (!a || amount === null) return fail('usage: give gold 1000000');
      return finish({ type: 'resources', op: cmd, resource: a, amount });
    }
    case 'fill':
    case 'finish':
    case 'resurrect':
    case 'reset':
      return finish({ type: cmd });
    case 'build': {
      const level = num(b);
      if (!a || level === null) return fail('usage: build barracks 20');
      return finish({ type: 'building', key: a, level });
    }
    case 'time': {
      const m = /^\+?(\d+)([smhd])$/.exec(a ?? '');
      if (!m) return fail('usage: time +1d');
      return finish({ type: 'time', seconds: Number(m[1]) * (TIME_UNITS[m[2]!] ?? 0) });
    }
    case 'teleport': {
      const x = num(a);
      const y = num(b);
      if (x === null || y === null) return fail('usage: teleport 50 50');
      return finish({ type: 'teleport', x, y });
    }
    case 'spawn': {
      if (a !== 'army') return fail('usage: spawn army cavalry 500');
      const count = num(c);
      const unitId = b ? (UNIT_ALIASES[b] ?? b) : '';
      if (count === null) return fail('usage: spawn army cavalry 500');
      return finish({ type: 'army', unit: unitId, count });
    }
    case 'research':
      if (a === 'all') return finish({ type: 'research_all' });
      return finish({ type: 'research', tech: a, level: num(b) });
    case 'hero':
      if (a === 'gear') return finish({ type: 'hero_gear', slot: b, rarity: num(c) });
      return finish({ type: 'hero', level: num(a) });
    case 'shield':
      return finish({ type: 'shield', hours: num(a) });
    case 'chest':
      return finish({ type: 'chest', kind: a, count: num(b) ?? 1 });
    default:
      return fail('unknown');
  }
}
