import { describe, expect, it } from 'vitest';
import { FREE_PACKS, findFreePack, packClaimId, packNextAt, packPeriod } from './freepacks';

describe('бесплатные наборы (D-76)', () => {
  it('наборы различимы, награды положительны и без случайности', () => {
    expect(new Set(FREE_PACKS.map((p) => p.id)).size).toBe(FREE_PACKS.length);
    for (const p of FREE_PACKS) {
      const r = p.reward;
      const total =
        Object.values(r.resources ?? {}).reduce((s, v) => s + (v ?? 0), 0) + (r.gems ?? 0);
      expect(total + (r.chest ? 1 : 0)).toBeGreaterThan(0);
    }
    expect(findFreePack('nope')).toBeUndefined();
    expect(packClaimId('breeze')).toBe('pack:breeze');
  });

  it('окно меняется ровно на границе периода, разовый набор — один ключ навсегда', () => {
    const breeze = findFreePack('breeze')!; // 4 часа
    const a = new Date('2026-01-01T03:59:59Z');
    const b = new Date('2026-01-01T04:00:00Z');
    expect(packPeriod(breeze, a)).not.toBe(packPeriod(breeze, b));
    expect(packPeriod(breeze, new Date('2026-01-01T04:00:01Z'))).toBe(packPeriod(breeze, b));
    expect(packNextAt(breeze, a)!.toISOString()).toBe('2026-01-01T04:00:00.000Z');
    const welcome = findFreePack('welcome')!;
    expect(packPeriod(welcome, a)).toBe('once');
    expect(packPeriod(welcome, new Date('2030-05-05T00:00:00Z'))).toBe('once');
    expect(packNextAt(welcome, a)).toBeNull();
  });

  it('щедрость растёт с длиной окна: в час больше даёт короткий набор, но длинный — дороже в сумме', () => {
    const sum = (id: string) => {
      const r = findFreePack(id)!.reward.resources ?? {};
      return Object.values(r).reduce((s, v) => s + (v ?? 0), 0);
    };
    expect(sum('daybreak')).toBeGreaterThan(sum('breeze'));
  });
});
