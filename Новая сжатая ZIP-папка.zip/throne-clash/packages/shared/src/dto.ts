import type { CityDto } from './structures';
import type { Locale, Role } from './constants';
import type { MissingRequirement } from './economy';
import type { RoundLog, UnitCounts } from './battle';
import type { CellKind, Terrain } from './map';
import type { MarchType } from './march';
import type { BoosterKey, ChestKind, ChestOutcome, ChestReward } from './chests';
import type { LeagueMetric, LeagueScope } from './league';
import type { QuestKind, QuestMetric } from './quests';
import type { PremiumCrest, ShopItemKind } from './shop';

/** Профиль игрока, как его видит клиент. Только публичные и собственные поля, без хешей. */
export interface UserDto {
  id: string;
  nickname: string;
  role: Role;
  isGuest: boolean;
  /** Email виден только владельцу аккаунта; у гостя — null. */
  email: string | null;
  language: Locale;
  crest: string;
  createdAt: string;
}

export interface AuthResponse {
  accessToken: string;
  /** Через сколько секунд access-токен истечёт. */
  expiresIn: number;
  user: UserDto;
  serverTime: string;
}

export interface MeResponse {
  user: UserDto;
  serverTime: string;
}

// ── Замок ───────────────────────────────────────────────────────────────────

import type { BuildingKey, ResourceKey } from './constants';
import type { HeroBonuses, EquipSlot, Rarity, SkillKey } from './hero';
import type { TechBranch, TechKey } from './research';
import type { UnitId } from './army';

export type ResourceMap = Record<ResourceKey, number>;

/** Почему здание сейчас нельзя улучшить (без учёта нехватки ресурсов и слотов — их видно по цифрам). */
export type UpgradeBlock = 'max_level' | 'castle_level' | 'in_progress' | 'requires';

export interface BuildingDto {
  key: BuildingKey;
  /** 0 — ещё не построено. */
  level: number;
  /** Уровень, который получится после улучшения; null на максимуме. */
  nextLevel: number | null;
  cost: ResourceMap | null;
  seconds: number | null;
  blocked: UpgradeBlock | null;
  /** Чего не хватает для первой постройки (пусто, если всё выполнено). */
  missing: MissingRequirement[];
}

export interface BuildTaskDto {
  id: string;
  key: BuildingKey;
  toLevel: number;
  startedAt: string;
  finishesAt: string;
  /** Сколько кристаллов стоит ускорить прямо сейчас (на момент serverTime). */
  speedupGems: number;
  /** Что вернётся при отмене. */
  refund: ResourceMap;
}

export interface CastleDto {
  serverTime: string;
  worldSpeed: number;
  /** Запасы на момент serverTime (дробные: клиент показывает целую часть и продолжает счёт сам). */
  resources: ResourceMap;
  caps: ResourceMap;
  ratesPerHour: ResourceMap;
  gems: number;
  shieldUntil: string | null;
  slots: {
    total: number;
    used: number;
    extraUnlocked: boolean;
    /** Можно ли открыть второй слот за кристаллы (иначе он уже есть). */
    canUnlock: boolean;
    unlockCostGems: number;
  };
  buildings: BuildingDto[];
  tasks: BuildTaskDto[];
  army: ArmyDto;
  research: ResearchDto;
  hero: HeroDto;
  /** Координаты замка на карте (null — ещё не размещён). */
  position: { x: number; y: number } | null;
  marches: MarchDto[];
  marchesMax: number;
  /** Мощь замка (Σ войска, здания, технологии, герой). */
  power: number;
  /** Постройки города на свободных клетках острова и их каталог. */
  city: CityDto;
}

// ── Армия, исследования, герой ──────────────────────────────────────────────

export interface UnitStackDto {
  id: UnitId;
  count: number;
  wounded: number;
}

export interface TrainTaskDto {
  id: string;
  unit: UnitId;
  count: number;
  startedAt: string;
  finishesAt: string;
  /** Ускорить можно только идущую партию; для ожидающих — null. */
  speedupGems: number | null;
  refund: ResourceMap;
}

export interface ArmyDto {
  units: UnitStackDto[];
  /** В строю (здоровые). */
  count: number;
  /** В очереди обучения. */
  queued: number;
  /** Лимит армии: в строю + в очереди. */
  cap: number;
  /** Еды в час на содержание. */
  upkeepPerHour: number;
  /** Высший тир, доступный по уровню Казармы (0 — Казармы нет). */
  maxTier: number;
  queue: TrainTaskDto[];
  queueMax: number;
  /** В походах (входят в лимит армии). */
  marching: number;
  /** Свободных мест в Госпитале. */
  woundedRoom: number;
}

export type TechBlock = 'max_level' | 'academy_level' | 'in_progress';

export interface TechDto {
  key: TechKey;
  branch: TechBranch;
  level: number;
  nextLevel: number | null;
  cost: ResourceMap | null;
  seconds: number | null;
  /** Уровень Академии, нужный для следующего уровня. */
  academyRequired: number | null;
  blocked: TechBlock | null;
}

export interface ResearchTaskDto {
  id: string;
  tech: TechKey;
  toLevel: number;
  startedAt: string;
  finishesAt: string;
  speedupGems: number | null;
  refund: ResourceMap;
}

export interface ResearchDto {
  techs: TechDto[];
  queue: ResearchTaskDto[];
  queueMax: number;
  academyLevel: number;
}

export interface HeroItemDto {
  id: string;
  slot: EquipSlot;
  rarity: Rarity;
  equipped: boolean;
}

export interface HeroDto {
  level: number;
  maxLevel: number;
  xp: number;
  xpToNext: number;
  skillPoints: number;
  skills: Record<SkillKey, number>;
  maxSkill: number;
  items: HeroItemDto[];
  bonuses: HeroBonuses;
  train: { cost: ResourceMap; xp: number };
}

// ── Карта, походы, отчёты ───────────────────────────────────────────────────

export type MarchState = 'outbound' | 'returning';

export interface MarchDto {
  id: string;
  type: MarchType;
  target: { x: number; y: number };
  /** Ник владельца замка-цели (для походов на игрока). */
  targetName: string | null;
  units: UnitCounts;
  /** Добыча, которую отряд везёт домой (после боя или сбора). */
  loot: ResourceMap;
  state: MarchState;
  startedAt: string;
  arriveAt: string;
  returnAt: string;
  reportId: string | null;
}

export interface MapCellDto {
  x: number;
  y: number;
  terrain: Terrain;
  kind: CellKind;
  level: number;
  resource: ResourceKey | null;
  /** Дорога (карта v2). */
  road?: boolean | undefined;
  /** Номер региона 0…63 (карта v2). */
  region?: number | undefined;
  castle: { nickname: string; isMe: boolean; shielded: boolean } | null;
  /** Лагерь повержен и возродится в это время. */
  busyUntil: string | null;
  /** Остаток запаса ресурсной точки. */
  remaining: number | null;
}

/** Обзор всего мира для мини-карты: рельеф с шагом `step` клеток, по одному символу на пробу (p, f, m, w; в карте v2 ещё d, s, o, l, r). */
export interface MapOverviewDto {
  step: number;
  cols: number;
  /** Построчно, cols × cols символов. */
  terrain: string;
}

export interface MapTilesDto {
  serverTime: string;
  x: number;
  y: number;
  size: number;
  /** Построчно: сначала весь ряд y, затем y+1. */
  cells: MapCellDto[];
}

export interface MapSearchResultDto {
  x: number;
  y: number;
  /** Ник игрока; для поиска по координатам — null. */
  nickname: string | null;
}

export type ReportKind = 'battle' | 'monster' | 'scout' | 'gather';
export type ReportRole = 'attacker' | 'defender';

export interface ReportSummaryDto {
  id: string;
  kind: ReportKind;
  role: ReportRole;
  /** win/loss — с точки зрения получателя; done — разведка и сбор. */
  outcome: 'win' | 'loss' | 'done';
  createdAt: string;
  target: { x: number; y: number };
  opponent: string | null;
  read: boolean;
}

export interface SideOutcomeDto {
  start: UnitCounts;
  remaining: UnitCounts;
  fallen: UnitCounts;
}

export interface ReportDetailDto {
  rounds: RoundLog[];
  attacker: SideOutcomeDto | null;
  defender: SideOutcomeDto | null;
  loot: ResourceMap;
  heroXp: number;
  /** Мои раненые и погибшие в этом бою. */
  wounded: UnitCounts;
  dead: UnitCounts;
  /** Разведка: состав защиты (±10%) и ресурсы. */
  scout: { units: UnitCounts; resources: ResourceMap } | null;
  /** Сбор: что и сколько добыто. */
  gathered: { resource: ResourceKey; amount: number } | null;
  campLevel: number | null;
}

export interface ReportDto extends ReportSummaryDto {
  detail: ReportDetailDto;
}

export interface ReportPageDto {
  items: ReportSummaryDto[];
  page: number;
  pageSize: number;
  total: number;
  unread: number;
}

// ── Братства, чат, уведомления ──────────────────────────────────────────────

import type { GuildRole } from './guild';

export interface GuildSummaryDto {
  id: string;
  name: string;
  description: string;
  level: number;
  members: number;
  capacity: number;
  leaderName: string;
}

export interface GuildMemberDto {
  userId: string;
  nickname: string;
  role: GuildRole;
  joinedAt: string;
}

export interface GuildApplicationDto {
  id: string;
  userId: string;
  nickname: string;
  createdAt: string;
}

/** Стройка соратника, которой можно помочь. */
export interface HelpRequestDto {
  userId: string;
  nickname: string;
  taskId: string;
  building: BuildingKey;
  toLevel: number;
  finishesAt: string;
  helps: number;
  maxHelps: number;
  /** Секунд, на которые сократит одна помощь. */
  helpSeconds: number;
  canHelp: boolean;
}

export interface GuildDto extends GuildSummaryDto {
  treasury: number;
  myRole: GuildRole;
  memberList: GuildMemberDto[];
  /** Заявки видят глава и офицеры; остальным — пустой список. */
  applications: GuildApplicationDto[];
  helpRequests: HelpRequestDto[];
}

export interface MyGuildDto {
  guild: GuildDto | null;
  /** Поданная заявка, если игрок ещё не в братстве. */
  applications: Array<{ guildId: string; guildName: string }>;
}

export interface GuildListDto {
  items: GuildSummaryDto[];
  page: number;
  pageSize: number;
  total: number;
}

export interface ChatMessageDto {
  id: string;
  /** Как канал виден клиенту: `world`, `guild` или `dm:<собеседник>`. */
  channel: string;
  userId: string;
  nickname: string;
  text: string;
  createdAt: string;
}

export const NOTIFICATION_KINDS = [
  'build.done',
  'train.done',
  'research.done',
  'march.returned',
  'march.attacked',
  'guild.application',
  'guild.accepted',
  'guild.kicked',
  'guild.help',
  'chat.dm',
  'season.reward',
] as const;
export type NotificationKind = (typeof NOTIFICATION_KINDS)[number];

export interface NotificationDto {
  id: string;
  kind: NotificationKind;
  /** Данные для текста: название здания, ник, id отчёта и т. п. */
  payload: Record<string, string | number | boolean | null>;
  read: boolean;
  createdAt: string;
}

export interface NotificationPageDto {
  items: NotificationDto[];
  page: number;
  pageSize: number;
  total: number;
  unread: number;
}

/** Сообщения WebSocket `/ws`. Клиент → сервер. */
export type WsClientMessage =
  | { type: 'auth'; token: string }
  | { type: 'chat.send'; channel: string; text: string }
  | { type: 'ping' };

/** Сервер → клиент. */
export type WsServerMessage =
  | { type: 'ready'; userId: string; online: number }
  | { type: 'chat.message'; message: ChatMessageDto }
  | { type: 'notification'; notification: NotificationDto }
  | { type: 'presence'; online: number }
  | { type: 'error'; code: string; message?: string; retryAfterSeconds?: number }
  | { type: 'pong' };

// ── Задания, сундуки, магазин, лиги ─────────────────────────────────────────

export interface RewardDto {
  resources: ResourceMap | null;
  gems: number;
  chest: ChestKind | null;
}

export interface QuestDto {
  id: string;
  kind: QuestKind;
  metric: QuestMetric;
  target: number;
  /** Прогресс, не больше target. */
  progress: number;
  reward: RewardDto;
  claimed: boolean;
  claimable: boolean;
  /** Экран, куда ведёт подсказка туториала. */
  route: string | null;
}

export interface FreePackDto {
  id: string;
  /** Длина окна в часах; null — разовый набор. */
  everyHours: number | null;
  reward: RewardDto;
  /** Набор уже получен в текущем окне (или разовый — когда-либо). */
  claimed: boolean;
  /** Когда откроется следующее окно; null — набор разовый. */
  nextAt: string | null;
}

export interface FreePacksDto {
  serverTime: string;
  packs: FreePackDto[];
  /** Сколько наборов можно забрать прямо сейчас (для значка). */
  claimable: number;
}

export interface LoginDto {
  /** День серии, который получит игрок сегодня (1…7). */
  day: number;
  claimed: boolean;
  rewards: RewardDto[];
}

export interface QuestsDto {
  tutorial: QuestDto[];
  daily: QuestDto[];
  achievements: QuestDto[];
  login: LoginDto;
  /** Следующий сброс ежедневных заданий (00:00 UTC). */
  dailyResetAt: string;
  /** Сколько наград можно забрать прямо сейчас (для значка в меню). */
  claimable: number;
}

export interface InventoryDto {
  chests: Record<ChestKind, number>;
  boosters: Record<BoosterKey, number>;
  /** Купленные премиум-гербы. */
  crests: PremiumCrest[];
}

export interface ChestOddsDto {
  kind: ChestKind;
  odds: Record<ChestOutcome, number>;
  resourcePack: number;
  gems: [number, number];
}

/** Ответ на действие с наградой: замок после действия, что выпало и инвентарь. */
export interface RewardResultDto {
  castle: CastleDto;
  reward: RewardDto;
  inventory: InventoryDto;
}

export interface ChestOpenDto {
  castle: CastleDto;
  reward: ChestReward;
  inventory: InventoryDto;
}

export interface BoosterUseDto {
  castle: CastleDto;
  inventory: InventoryDto;
}

export interface ShopItemDto {
  id: string;
  kind: ShopItemKind;
  price: number;
  resources: ResourceMap | null;
  booster: BoosterKey | null;
  crest: PremiumCrest | null;
  /** Уже куплено и больше не продаётся (второй слот, герб). */
  owned: boolean;
}

export interface ShopDto {
  items: ShopItemDto[];
  gems: number;
  inventory: InventoryDto;
}

export interface ShopBuyDto {
  castle: CastleDto;
  shop: ShopDto;
}

export interface LeagueEntryDto {
  place: number;
  userId: string;
  nickname: string;
  value: number;
  isMe: boolean;
}

export interface LeaguePrizeDto {
  seasonId: string;
  place: number | null;
  gems: number;
  chest: ChestKind | null;
}

export interface LeagueDto {
  seasonId: string;
  endsAt: string;
  metric: LeagueMetric;
  scope: LeagueScope;
  entries: LeagueEntryDto[];
  /** Мои место и значение (место null — вне таблицы выбранного фильтра). */
  me: { place: number | null; value: number; points: number } | null;
  /** Призы за прошедшие сезоны, которые ещё не получены. */
  pending: LeaguePrizeDto[];
  /** Приз за текущее место (превью). */
  prize: { gems: number; chest: ChestKind | null };
}

// ── Администрирование и режим бога ──────────────────────────────────────────

export interface AdminUserDto {
  id: string;
  nickname: string;
  email: string | null;
  role: Role;
  isGuest: boolean;
  isBot: boolean;
  bannedUntil: string | null;
  banReason: string | null;
  mutedUntil: string | null;
  createdAt: string;
  lastLoginAt: string | null;
}

export interface AdminUserPageDto {
  items: AdminUserDto[];
  page: number;
  pageSize: number;
  total: number;
}

export interface AdminStatsDto {
  users: { total: number; guests: number; bots: number; banned: number; muted: number };
  activity: { new24h: number; new7d: number; active24h: number; online: number };
  /** Экономика за последние 24 часа без действий режима бога: пришло / ушло по ресурсам. */
  economy: {
    gained: Record<ResourceKey | 'gems', number>;
    spent: Record<ResourceKey | 'gems', number>;
  };
  reportsOpen: number;
}

export interface SecurityLogEntryDto {
  kind: string;
  userId: string | null;
  nickname: string | null;
  ip: string | null;
  details: Record<string, unknown> | null;
  createdAt: string;
}

export interface ChatReportDto {
  id: string;
  reason: string;
  createdAt: string;
  reporter: { id: string; nickname: string };
  author: { id: string; nickname: string };
  message: { id: string; channel: string; text: string; createdAt: string };
}

export interface AuditEntryDto {
  id: string;
  scope: 'admin' | 'god';
  actor: { id: string; nickname: string } | null;
  action: string;
  target: { id: string; nickname: string } | null;
  params: unknown;
  before: unknown;
  after: unknown;
  ip: string | null;
  createdAt: string;
}

export interface AuditPageDto {
  items: AuditEntryDto[];
  page: number;
  pageSize: number;
  total: number;
}

/** Ответ действия режима бога: замок цели после действия. */
export interface GodActResultDto {
  castle: CastleDto;
}

export interface GodPlayerDto {
  user: AdminUserDto;
  castle: CastleDto;
  inventory: InventoryDto;
  /** Замок помечен как тронутый режимом бога: исключён из рейтингов и экономики. */
  godTouched: boolean;
  snapshots: Array<{ id: string; label: string; createdAt: string }>;
}

export interface GodSessionDto {
  expiresAt: string;
  totpRequired: boolean;
}

export interface BalanceDto {
  balance: Record<string, number>;
  updatedAt: string | null;
  revisions: Array<{
    id: string;
    createdAt: string;
    note: string | null;
    balance: Record<string, number>;
  }>;
}

export interface GodDebugDto {
  uptimeSeconds: number;
  memoryMb: number;
  online: number;
  counts: { users: number; castles: number; marches: number; guilds: number; chatMessages: number };
  redis: 'ok' | 'off' | 'error';
  serverTime: string;
}
