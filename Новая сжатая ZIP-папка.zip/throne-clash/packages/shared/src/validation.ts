import { z } from 'zod';
import { DEFAULT_CRESTS, LOCALES } from './constants';
import { PREMIUM_CRESTS as PREMIUM_CRESTS_LIST } from './shop';

/**
 * Правила полей аккаунта. Один источник для сервера и форм клиента:
 * клиент подсвечивает ошибки сразу, но решает всегда сервер.
 */

export const EMAIL_MAX = 254;
export const PASSWORD_MIN = 8;
export const PASSWORD_MAX = 128; // верхняя граница защищает argon2 от гигантских входов
export const NICKNAME_MIN = 3;
export const NICKNAME_MAX = 20;

/** Приводит email к каноничному виду: NFKC, обрезка пробелов, нижний регистр. */
export const normalizeEmail = (raw: string): string => raw.normalize('NFKC').trim().toLowerCase();

export const emailSchema = z
  .string()
  .max(EMAIL_MAX)
  .transform(normalizeEmail)
  .pipe(z.string().email().max(EMAIL_MAX));

/** Самые частые пароли: полный список не нужен, отсекаем очевидное. */
const COMMON_PASSWORDS = new Set([
  '12345678',
  '123456789',
  '1234567890',
  '87654321',
  '11111111',
  '00000000',
  'password',
  'password1',
  'password123',
  'qwertyui',
  'qwerty123',
  'qwertyuiop',
  '1q2w3e4r',
  '1q2w3e4r5t',
  'iloveyou',
  'admin123',
  'letmein1',
  'welcome1',
  'abc12345',
  'zaq12wsx',
  'qazwsxedc',
  'йцукенгш',
  'пароль123',
  'привет123',
  'throneclash',
  'битвазатрон',
]);

export const isCommonPassword = (password: string): boolean =>
  COMMON_PASSWORDS.has(password.toLowerCase());

export const passwordSchema = z
  .string()
  .min(PASSWORD_MIN)
  .max(PASSWORD_MAX)
  .refine((p) => !isCommonPassword(p), { message: 'common_password' })
  .refine((p) => new Set(p).size >= 4, { message: 'too_repetitive' });

// ── Ник ────────────────────────────────────────────────────────────────────

/** Кириллица → визуально совпадающая латиница: «Аdmin» и «Admin» — один ник. */
const LOOKALIKES: Readonly<Record<string, string>> = {
  а: 'a',
  в: 'b',
  е: 'e',
  ё: 'e',
  з: '3',
  и: 'u',
  й: 'u',
  к: 'k',
  м: 'm',
  н: 'h',
  о: 'o',
  р: 'p',
  с: 'c',
  т: 't',
  у: 'y',
  х: 'x',
  і: 'i',
  ѕ: 's',
  ј: 'j',
  0: 'o',
};

/**
 * Ключ уникальности ника: регистр, разделители и похожие буквы не делают ник «другим».
 * Хранится в БД под уникальным индексом.
 */
export function nicknameKey(nickname: string): string {
  const base = nickname
    .normalize('NFKC')
    .toLowerCase()
    .replace(/[\s_-]+/g, '');
  return Array.from(base, (ch) => LOOKALIKES[ch] ?? ch).join('');
}

/** Ники, которые нельзя занять: имитация персонала и служебных ролей. */
const RESERVED_KEYS: readonly string[] = [
  'admin',
  'administrator',
  'moderator',
  'support',
  'system',
  'server',
  'owner',
  'god',
  'godmode',
  'gamemaster',
  'throneclash',
  'staff',
  'bot',
].map(nicknameKey);

export const isReservedNickname = (nickname: string): boolean => {
  const key = nicknameKey(nickname);
  return RESERVED_KEYS.some((r) => key === r || (r.length >= 5 && key.startsWith(r)));
};

// Буквы/цифры по краям, внутри допустимы пробел, «_» и «-»; без двойных разделителей
const NICKNAME_RE = /^[\p{L}\p{N}](?:[\p{L}\p{N}]|[ _-](?=[\p{L}\p{N}]))*$/u;

export const nicknameSchema = z
  .string()
  .transform((s) => s.normalize('NFKC').trim())
  .pipe(
    z
      .string()
      .min(NICKNAME_MIN)
      .max(NICKNAME_MAX)
      .regex(NICKNAME_RE, { message: 'bad_chars' })
      .refine((n) => !isReservedNickname(n), { message: 'reserved' }),
  );

// Профиль допускает и премиум-гербы; владение ими проверяет сервер
export const crestSchema = z.enum([...DEFAULT_CRESTS, ...PREMIUM_CRESTS_LIST]);
export const localeSchema = z.enum(LOCALES);

// ── Тела запросов ──────────────────────────────────────────────────────────

export const registerBodySchema = z
  .object({
    email: emailSchema,
    password: passwordSchema,
    nickname: nicknameSchema,
    language: localeSchema.optional(),
  })
  .strict()
  .refine(
    (b) => {
      // Короткие локальные части («a@…») встречаются в любом пароле — их не сравниваем
      const local = b.email.split('@')[0] ?? '';
      return local.length < 4 || !b.password.toLowerCase().includes(local);
    },
    { path: ['password'], message: 'contains_email' },
  );

export const loginBodySchema = z
  .object({ email: emailSchema, password: z.string().min(1).max(PASSWORD_MAX) })
  .strict();

export const upgradeGuestBodySchema = z
  .object({ email: emailSchema, password: passwordSchema })
  .strict();

export const updateProfileBodySchema = z
  .object({
    nickname: nicknameSchema.optional(),
    crest: crestSchema.optional(),
    language: localeSchema.optional(),
  })
  .strict()
  .refine((b) => Object.keys(b).length > 0, { message: 'empty' });

export type RegisterBody = z.infer<typeof registerBodySchema>;
export type LoginBody = z.infer<typeof loginBodySchema>;
export type UpdateProfileBody = z.infer<typeof updateProfileBodySchema>;
