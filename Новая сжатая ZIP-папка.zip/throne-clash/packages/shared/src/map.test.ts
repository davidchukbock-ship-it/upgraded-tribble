import { describe, expect, it } from 'vitest';
import { MAP_SIZE } from './constants';
import {
  MAP_CENTER,
  MIN_CASTLE_GAP,
  cellAt,
  distance,
  inBounds,
  isPassableTerrain,
  pickCastleSpot,
  terrainAt,
  type Point,
} from './map';

const SEED = 20260101;

describe('карта мира', () => {
  it('детерминирована: тот же seed и клетка дают ту же клетку, другой seed — другую карту', () => {
    expect(cellAt(SEED, 12, 34)).toEqual(cellAt(SEED, 12, 34));
    let differ = 0;
    for (let i = 0; i < 400; i++) {
      const x = i % 20;
      const y = Math.floor(i / 20);
      if (terrainAt(SEED, x, y) !== terrainAt(SEED + 1, x, y)) differ++;
    }
    expect(differ).toBeGreaterThan(20);
  });

  it('доли рельефа и объектов разумны, а точки и лагеря не стоят на воде и горах', () => {
    const count = { water: 0, mountain: 0, resource: 0, camp: 0, passable: 0 };
    for (let y = 0; y < MAP_SIZE; y++) {
      for (let x = 0; x < MAP_SIZE; x++) {
        const c = cellAt(SEED, x, y);
        if (c.terrain === 'water') count.water++;
        if (c.terrain === 'mountain') count.mountain++;
        if (isPassableTerrain(c.terrain)) count.passable++;
        else expect(c.kind).toBe('empty');
        if (c.kind === 'resource') {
          count.resource++;
          expect(c.level).toBeGreaterThanOrEqual(1);
          expect(c.level).toBeLessThanOrEqual(5);
          expect(c.resource).not.toBeNull();
        }
        if (c.kind === 'camp') {
          count.camp++;
          expect(c.level).toBeGreaterThanOrEqual(1);
          expect(c.level).toBeLessThanOrEqual(10);
        }
      }
    }
    const total = MAP_SIZE * MAP_SIZE;
    expect(count.water / total).toBeGreaterThan(0.05);
    expect(count.water / total).toBeLessThan(0.3);
    expect(count.mountain / total).toBeGreaterThan(0.05);
    expect(count.passable / total).toBeGreaterThan(0.5);
    expect(count.resource / count.passable).toBeGreaterThan(0.03);
    expect(count.resource / count.passable).toBeLessThan(0.07);
    expect(count.camp / count.passable).toBeGreaterThan(0.015);
    expect(count.camp / count.passable).toBeLessThan(0.035);
  });

  it('лагеря сильнее вдали от центра', () => {
    const levels = { near: [] as number[], far: [] as number[] };
    for (let y = 0; y < MAP_SIZE; y++) {
      for (let x = 0; x < MAP_SIZE; x++) {
        const c = cellAt(SEED, x, y);
        if (c.kind !== 'camp') continue;
        (distance(c, MAP_CENTER) < 25 ? levels.near : levels.far).push(c.level);
      }
    }
    const avg = (a: number[]): number => a.reduce((s, n) => s + n, 0) / a.length;
    expect(avg(levels.far)).toBeGreaterThan(avg(levels.near) + 2);
  });

  it('центр карты свободен от точек и лагерей', () => {
    for (let dy = -5; dy <= 5; dy++)
      for (let dx = -5; dx <= 5; dx++)
        expect(cellAt(SEED, MAP_CENTER.x + dx, MAP_CENTER.y + dy).kind).toBe('empty');
  });

  it('inBounds отвергает выход за карту и нецелые координаты', () => {
    expect(inBounds(0, 0)).toBe(true);
    expect(inBounds(MAP_SIZE - 1, MAP_SIZE - 1)).toBe(true);
    expect(inBounds(-1, 0)).toBe(false);
    expect(inBounds(0, MAP_SIZE)).toBe(false);
    expect(inBounds(1.5, 2)).toBe(false);
  });
});

describe('размещение замков', () => {
  it('первый замок — ближе всего к центру', () => {
    expect(pickCastleSpot(SEED, [])).toEqual(MAP_CENTER);
  });

  it('каждый следующий не ближе зазора к остальным и стоит на проходимой пустой клетке', () => {
    const taken: Point[] = [];
    for (let i = 0; i < 60; i++) {
      const spot = pickCastleSpot(SEED, taken);
      expect(spot).not.toBeNull();
      const s = spot!;
      for (const t of taken)
        expect(Math.max(Math.abs(t.x - s.x), Math.abs(t.y - s.y))).toBeGreaterThanOrEqual(
          MIN_CASTLE_GAP,
        );
      const cell = cellAt(SEED, s.x, s.y);
      expect(isPassableTerrain(cell.terrain)).toBe(true);
      expect(cell.kind).toBe('empty');
      taken.push(s);
    }
  });

  it('поселенцы расходятся от центра по спирали, а не улетают на край', () => {
    const taken: Point[] = [];
    for (let i = 0; i < 30; i++) taken.push(pickCastleSpot(SEED, taken)!);
    expect(Math.max(...taken.map((p) => distance(p, MAP_CENTER)))).toBeLessThan(20);
  });

  it('детерминировано: те же замки → то же место', () => {
    const taken = [{ x: 50, y: 50 }];
    expect(pickCastleSpot(SEED, taken)).toEqual(pickCastleSpot(SEED, taken));
  });

  it('на заполненной карте возвращает null', () => {
    const everywhere: Point[] = [];
    for (let y = 0; y < MAP_SIZE; y += MIN_CASTLE_GAP)
      for (let x = 0; x < MAP_SIZE; x += MIN_CASTLE_GAP) everywhere.push({ x, y });
    // сетка с шагом в зазор закрывает любую клетку (расстояние до ближайшего узла < зазора)
    const spot = pickCastleSpot(SEED, everywhere);
    expect(spot === null || everywhere.every((t) => t.x !== spot.x || t.y !== spot.y)).toBe(true);
  });
});
