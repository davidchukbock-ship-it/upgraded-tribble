import { describe, expect, it } from 'vitest';
import {
  BUILDING_CLASS,
  BUILDING_KEYS,
  BUILDING_CLASSES,
  MAX_TERRITORY_LEVEL,
  TERRITORY_CASTLE_LEVELS,
} from './constants';
import {
  BUILDING_BASE,
  BUILDING_REQUIRES,
  buildingCost,
  buildSeconds,
  fisheryFood,
  gemsPerHour,
  mageHeroXpBonus,
  mageResearchBonus,
  maxBuildingLevel,
  maxLevelFor,
  missingRequirements,
  ratesFor,
} from './economy';
import { cavalryShare, towersBonus, TOWER_CAP } from './battle';
import { settleCastle } from './settle';
import { techSeconds } from './research';
import { START_RESOURCES } from './constants';

describe('новые здания и земли (D-59…D-61)', () => {
  it('каждое здание имеет класс и стоимость; классы известны', () => {
    for (const k of BUILDING_KEYS) {
      expect(BUILDING_CLASSES).toContain(BUILDING_CLASS[k]);
      expect(BUILDING_BASE[k].seconds).toBeGreaterThan(0);
      expect(buildingCost(k, 1).gold).toBeGreaterThanOrEqual(0);
    }
    expect(BUILDING_CLASS.archertower).toBe('defense');
    expect(BUILDING_CLASS.magetower).toBe('magic');
    expect(BUILDING_CLASS.fishery).toBe('economy');
  });

  it('Земли: потолок 4, уровни открываются порогами уровня Замка', () => {
    expect(maxBuildingLevel('territory')).toBe(MAX_TERRITORY_LEVEL);
    expect(maxBuildingLevel('farm')).toBe(20);
    expect(maxLevelFor('territory', 1)).toBe(0);
    expect(maxLevelFor('territory', TERRITORY_CASTLE_LEVELS[0]!)).toBe(1);
    expect(maxLevelFor('territory', 9)).toBe(2);
    expect(maxLevelFor('territory', 13)).toBe(4);
    expect(maxLevelFor('territory', 20)).toBe(4);
    // остальные здания — по-прежнему не выше уровня Замка
    expect(maxLevelFor('archertower', 7)).toBe(7);
  });

  it('требования: пока нет Земель и нужных зданий, строить нельзя; список говорит, чего не хватает', () => {
    expect(missingRequirements('farm', {}, 1)).toEqual([]);
    expect(missingRequirements('fishery', {}, 5)).toEqual([{ kind: 'territory', level: 1 }]);
    expect(missingRequirements('fishery', { territory: 1 }, 5)).toEqual([]);
    expect(missingRequirements('stormtower', { territory: 3 }, 12)).toEqual([
      { kind: 'building', key: 'magetower', level: 5 },
    ]);
    expect(missingRequirements('diamondmine', { territory: 2 }, 5)).toEqual([
      { kind: 'castle', level: 6 },
    ]);
    const all = missingRequirements('ballistatower', {}, 1);
    expect(all).toHaveLength(3);
    // граф требований без циклов: у каждого требуемого здания есть собственные условия глубже, но не обратно
    for (const [k, req] of Object.entries(BUILDING_REQUIRES)) {
      for (const dep of Object.keys(req.buildings ?? {})) expect(dep).not.toBe(k);
    }
  });

  it('Рыбацкая пристань добавляет еду к ферме', () => {
    const base = ratesFor({ farm: 5 });
    const withFish = ratesFor({ farm: 5, fishery: 5 });
    expect(withFish.food - base.food).toBe(fisheryFood(5));
    expect(fisheryFood(0)).toBe(0);
    expect(fisheryFood(10)).toBeGreaterThan(fisheryFood(5));
    expect(withFish.gold).toBe(base.gold);
  });

  it('Алмазная шахта: доли копятся между расчётами и не теряются', () => {
    expect(gemsPerHour(0)).toBe(0);
    expect(gemsPerHour(20)).toBeLessThan(6);
    const input = {
      resources: { ...START_RESOURCES },
      updatedAtMs: 0,
      levels: { castle: 5, warehouse: 1, diamondmine: 5 },
      tasks: [],
    };
    // один расчёт за 10 часов и десять расчётов по часу дают одно и то же
    const once = settleCastle({ ...input, gems: 0, gemsCarry: 0 }, 10 * 3_600_000);
    let gems = 0;
    let carry = 0;
    let updated = 0;
    for (let h = 1; h <= 10; h++) {
      const r = settleCastle(
        { ...input, updatedAtMs: updated, gems, gemsCarry: carry },
        h * 3_600_000,
      );
      gems = r.gems;
      carry = r.gemsCarry;
      updated = r.updatedAtMs;
    }
    expect(gems).toBe(once.gems);
    expect(carry).toBeCloseTo(once.gemsCarry, 9);
    expect(once.gems).toBeGreaterThan(0);
    expect(once.gemsCarry).toBeGreaterThanOrEqual(0);
    expect(once.gemsCarry).toBeLessThan(1);
    // без шахты кристаллов нет
    expect(
      settleCastle({ ...input, levels: { castle: 5, warehouse: 1 }, gems: 7 }, 10 * 3_600_000).gems,
    ).toBe(7);
  });

  it('Башня магов ускоряет исследования и растит опыт героя, с потолком', () => {
    expect(mageResearchBonus(0)).toBe(0);
    expect(mageResearchBonus(4)).toBeCloseTo(0.05);
    expect(mageResearchBonus(99)).toBe(0.25);
    expect(mageHeroXpBonus(10)).toBeCloseTo(0.1);
    expect(mageHeroXpBonus(99)).toBe(0.2);
    expect(techSeconds('farming', 3, 1, 0.2)).toBeLessThan(techSeconds('farming', 3, 1, 0));
    expect(techSeconds('farming', 3, 1, 5)).toBeGreaterThan(0);
  });

  it('оборонительные башни: у каждой свой характер, суммарный бонус ограничен', () => {
    expect(towersBonus({}, 0)).toBe(0);
    expect(towersBonus({ archertower: 10 }, 0)).toBeCloseTo(0.1);
    // Баллиста работает только по коннице
    expect(towersBonus({ ballistatower: 10 }, 0)).toBe(0);
    expect(towersBonus({ ballistatower: 10 }, 1)).toBeCloseTo(0.16);
    expect(towersBonus({ ballistatower: 10 }, 0.5)).toBeCloseTo(0.08);
    // осада ослабляет лучников, но не бурю
    expect(towersBonus({ archertower: 10 }, 0, 1)).toBeLessThan(0.1);
    expect(towersBonus({ stormtower: 10 }, 0, 1)).toBeCloseTo(0.09);
    expect(towersBonus({ archertower: 20, ballistatower: 20, stormtower: 20 }, 1)).toBe(TOWER_CAP);
    expect(cavalryShare({ cavalry_1: 30, infantry_1: 70 })).toBeCloseTo(0.3);
    expect(cavalryShare({})).toBe(0);
  });

  it('время стройки Земель растёт, но остаётся в разумных пределах', () => {
    const t1 = buildSeconds('territory', 1, 4);
    const t4 = buildSeconds('territory', 4, 13);
    expect(t1).toBeGreaterThan(1000);
    expect(t4).toBeGreaterThan(t1);
    expect(t4).toBeLessThan(24 * 3600);
  });
});
