import { describe, expect, it } from 'vitest';
import { UNIT_TIERS, UNIT_TYPES } from './constants';
import { warehouseCap } from './economy';
import {
  ALL_UNIT_IDS,
  ATTACK_MULT,
  armyCap,
  armyCount,
  barracksLevelForTier,
  hospitalCapacity,
  maxTierFor,
  parseUnitId,
  trainCost,
  trainSeconds,
  unitId,
  unitStats,
  upkeepPerHour,
} from './army';

describe('характеристики войск (GAME_DESIGN §3)', () => {
  it('тир 1 совпадает с таблицей', () => {
    expect(unitStats('infantry', 1)).toMatchObject({
      atk: 12,
      def: 16,
      hp: 120,
      cargo: 20,
      trainSec: 20,
      upkeep: 1,
    });
    expect(unitStats('cavalry', 1)).toMatchObject({
      atk: 22,
      def: 12,
      hp: 130,
      secPerTile: 30,
      cargo: 40,
    });
    expect(unitStats('siege', 1).cost).toEqual({ gold: 100, wood: 120, stone: 80, food: 0 });
  });

  it('тир t: характеристики ×1.6^(t−1), цена ×1.9^(t−1), обучение ×1.5^(t−1), содержание = t', () => {
    const t3 = unitStats('infantry', 3);
    expect(t3.atk).toBe(Math.round(12 * 1.6 ** 2));
    expect(t3.hp).toBe(Math.round(120 * 1.6 ** 2));
    expect(t3.cost.gold).toBe(Math.round(30 * 1.9 ** 2));
    expect(t3.trainSec).toBeCloseTo(20 * 1.5 ** 2);
    expect(t3.upkeep).toBe(3);
    expect(unitStats('archer', 5).cargo).toBe(Math.floor(15 * 1.3 ** 4));
  });

  it('старшие тиры строго сильнее, дороже и дольше обучаются', () => {
    for (const type of UNIT_TYPES) {
      for (const tier of UNIT_TIERS.slice(1)) {
        const a = unitStats(type, (tier - 1) as 1);
        const b = unitStats(type, tier);
        expect(b.atk).toBeGreaterThan(a.atk);
        expect(b.hp).toBeGreaterThan(a.hp);
        expect(b.cost.gold + b.cost.wood + b.cost.food).toBeGreaterThan(
          a.cost.gold + a.cost.wood + a.cost.food,
        );
        expect(b.trainSec).toBeGreaterThan(a.trainSec);
      }
    }
  });

  it('ИНВАРИАНТ: партия из одного юнита любого вида и тира помещается в склад 20-го уровня', () => {
    const cap = warehouseCap(20);
    for (const type of UNIT_TYPES)
      for (const tier of UNIT_TIERS) {
        const c = unitStats(type, tier).cost;
        for (const v of Object.values(c)) expect(v).toBeLessThan(cap);
      }
  });
});

describe('доступ и лимиты', () => {
  it('тир открывается с Казармы 1, 5, 9, 13, 17', () => {
    expect(UNIT_TIERS.map(barracksLevelForTier)).toEqual([1, 5, 9, 13, 17]);
    expect([0, 1, 4, 5, 8, 9, 17, 20].map(maxTierFor)).toEqual([0, 1, 1, 2, 2, 3, 5, 5]);
  });
  it('лимит армии 100 + 150·L; без Казармы армии нет', () => {
    expect([0, 1, 10, 20].map(armyCap)).toEqual([0, 250, 1600, 3100]);
  });
  it('вместимость госпиталя 100·L, бонус медицины увеличивает', () => {
    expect(hospitalCapacity(3)).toBe(300);
    expect(hospitalCapacity(3, 0.5)).toBe(450);
  });
});

describe('обучение', () => {
  it('время партии: n·t/(1+0.05·(L−1))·(1−муштра), минимум 1 с', () => {
    expect(trainSeconds('infantry', 1, 10, 1)).toBe(200);
    expect(trainSeconds('infantry', 1, 10, 21)).toBe(100); // Казарма 21: делитель 2
    expect(trainSeconds('infantry', 1, 10, 1, 0.3)).toBe(140);
    expect(trainSeconds('infantry', 1, 1, 1, 0, 1000)).toBe(1);
  });
  it('цена партии — цена юнита × количество', () => {
    expect(trainCost('archer', 1, 10)).toEqual({ gold: 400, wood: 400, stone: 0, food: 200 });
  });
});

describe('армия и содержание', () => {
  it('идентификаторы: сборка и разбор, мусор отклоняется', () => {
    expect(unitId('siege', 4)).toBe('siege_4');
    expect(parseUnitId('siege_4')).toEqual({ type: 'siege', tier: 4 });
    for (const bad of ['', 'siege', 'siege_9', 'dragon_1', 'siege_0', '__proto__'])
      expect(parseUnitId(bad)).toBeNull();
    expect(ALL_UNIT_IDS).toHaveLength(20);
  });
  it('содержание: юнит тира t ест t еды в час; раненые не едят', () => {
    expect(
      upkeepPerHour({ infantry_1: { count: 10, wounded: 5 }, cavalry_3: { count: 4, wounded: 0 } }),
    ).toBe(10 + 12);
    expect(upkeepPerHour({})).toBe(0);
    expect(
      armyCount({ infantry_1: { count: 10, wounded: 5 }, archer_2: { count: 3, wounded: 0 } }),
    ).toBe(13);
  });
});

describe('камень-ножницы-бумага', () => {
  it('пехота бьёт кавалерию, кавалерия — лучников, лучники — пехоту', () => {
    expect(ATTACK_MULT.infantry.cavalry).toBe(1.5);
    expect(ATTACK_MULT.cavalry.archer).toBe(1.5);
    expect(ATTACK_MULT.archer.infantry).toBe(1.5);
  });
  it('в цикле каждый бьёт следующего сильнее, чем тот его', () => {
    expect(ATTACK_MULT.infantry.cavalry).toBeGreaterThan(ATTACK_MULT.cavalry.infantry);
    expect(ATTACK_MULT.cavalry.archer).toBeGreaterThan(ATTACK_MULT.archer.cavalry);
    expect(ATTACK_MULT.archer.infantry).toBeGreaterThan(ATTACK_MULT.infantry.archer);
  });
  it('осадные пробивают всех, кроме конницы', () => {
    expect(ATTACK_MULT.siege.cavalry).toBeLessThan(1);
    expect(ATTACK_MULT.cavalry.siege).toBeGreaterThan(1);
  });
});
