import type { ChestKind } from './chests';
import type { ResourceAmounts } from './economy';

/** Задания, достижения и ежедневный вход (docs/GAME_DESIGN.md §9). */

export type QuestKind = 'tutorial' | 'daily' | 'achievement';

/** Что измеряет задание. Счётчики копятся при действиях, остальное выводится из состояния замка. */
export type QuestMetric =
  | 'upgrade' // начатых улучшений (счётчик)
  | 'train' // обученных юнитов (счётчик)
  | 'win' // выигранных боёв (счётчик)
  | 'gather' // завершённых сборов (счётчик)
  | 'march' // отправленных походов (счётчик)
  | 'chat' // сообщений в мировой чат (счётчик)
  | 'chest' // открытых сундуков (счётчик)
  | 'castle_level'
  | 'barracks_level'
  | 'academy_level'
  | 'tech_total'
  | 'hero_skills'
  | 'power'
  | 'army'
  | 'guild'
  | 'wins_total';

export interface QuestReward {
  resources?: Partial<ResourceAmounts>;
  gems?: number;
  chest?: ChestKind;
}

export interface QuestDef {
  id: string;
  kind: QuestKind;
  metric: QuestMetric;
  target: number;
  reward: QuestReward;
  /** Экран, куда ведёт подсказка туториала. */
  route?: string;
}

const res = (n: number): Partial<ResourceAmounts> => ({ gold: n, wood: n, stone: n, food: n });

export const TUTORIAL: readonly QuestDef[] = [
  {
    id: 't1_upgrade',
    kind: 'tutorial',
    metric: 'upgrade',
    target: 1,
    route: '/castle',
    reward: { resources: res(300), gems: 5 },
  },
  {
    id: 't2_barracks',
    kind: 'tutorial',
    metric: 'barracks_level',
    target: 1,
    route: '/castle',
    reward: { resources: res(400), gems: 5 },
  },
  {
    id: 't3_train',
    kind: 'tutorial',
    metric: 'train',
    target: 10,
    route: '/army',
    reward: { resources: res(500), gems: 5 },
  },
  {
    id: 't4_academy',
    kind: 'tutorial',
    metric: 'academy_level',
    target: 1,
    route: '/castle',
    reward: { resources: res(500), gems: 5 },
  },
  {
    id: 't5_research',
    kind: 'tutorial',
    metric: 'tech_total',
    target: 1,
    route: '/academy',
    reward: { resources: res(600), gems: 10 },
  },
  {
    id: 't6_hero',
    kind: 'tutorial',
    metric: 'hero_skills',
    target: 1,
    route: '/hero',
    reward: { resources: res(300), gems: 5 },
  },
  {
    id: 't7_march',
    kind: 'tutorial',
    metric: 'march',
    target: 1,
    route: '/map',
    reward: { resources: res(600), gems: 10 },
  },
  {
    id: 't8_chat',
    kind: 'tutorial',
    metric: 'chat',
    target: 1,
    route: '/chat',
    reward: { resources: res(300), gems: 5 },
  },
  {
    id: 't9_guild',
    kind: 'tutorial',
    metric: 'guild',
    target: 1,
    route: '/guild',
    reward: { resources: res(800), gems: 15 },
  },
  {
    id: 't10_chest',
    kind: 'tutorial',
    metric: 'chest',
    target: 1,
    route: '/chests',
    reward: { gems: 20, chest: 'silver' },
  },
];

export const DAILY: readonly QuestDef[] = [
  {
    id: 'd_upgrade',
    kind: 'daily',
    metric: 'upgrade',
    target: 1,
    reward: { resources: res(400), chest: 'wooden' },
  },
  {
    id: 'd_train',
    kind: 'daily',
    metric: 'train',
    target: 20,
    reward: { resources: res(400), chest: 'wooden' },
  },
  {
    id: 'd_win',
    kind: 'daily',
    metric: 'win',
    target: 1,
    reward: { resources: res(400), chest: 'wooden' },
  },
  {
    id: 'd_gather',
    kind: 'daily',
    metric: 'gather',
    target: 1,
    reward: { resources: res(400), chest: 'wooden' },
  },
];

const ach = (id: string, metric: QuestMetric, target: number, gems: number): QuestDef => ({
  id,
  kind: 'achievement',
  metric,
  target,
  reward: { gems },
});

export const ACHIEVEMENTS: readonly QuestDef[] = [
  ach('a_power_1k', 'power', 1_000, 10),
  ach('a_power_10k', 'power', 10_000, 30),
  ach('a_power_50k', 'power', 50_000, 80),
  ach('a_castle_5', 'castle_level', 5, 20),
  ach('a_castle_10', 'castle_level', 10, 50),
  ach('a_castle_20', 'castle_level', 20, 150),
  ach('a_army_100', 'army', 100, 10),
  ach('a_army_1k', 'army', 1_000, 40),
  ach('a_army_5k', 'army', 5_000, 100),
  ach('a_wins_10', 'wins_total', 10, 20),
  ach('a_wins_50', 'wins_total', 50, 60),
  ach('a_wins_200', 'wins_total', 200, 150),
];

export const ALL_QUESTS: readonly QuestDef[] = [...TUTORIAL, ...DAILY, ...ACHIEVEMENTS];
export const findQuest = (id: string): QuestDef | undefined => ALL_QUESTS.find((q) => q.id === id);

/** Период, к которому относится получение награды: ежедневное — день, остальное — разовое. */
export const claimPeriod = (q: Pick<QuestDef, 'kind'>, day: string): string =>
  q.kind === 'daily' ? day : 'once';

export const COUNTER_METRICS: readonly QuestMetric[] = [
  'upgrade',
  'train',
  'win',
  'gather',
  'march',
  'chat',
  'chest',
];
export const isCounter = (m: QuestMetric): boolean => COUNTER_METRICS.includes(m);

// ── Ежедневный вход ─────────────────────────────────────────────────────────

export const LOGIN_DAYS = 7;

export const LOGIN_REWARDS: readonly QuestReward[] = [
  { resources: res(300) },
  { resources: res(500), gems: 2 },
  { resources: res(800) },
  { resources: res(1200), gems: 5 },
  { resources: res(1800) },
  { resources: res(2500), gems: 10 },
  { gems: 20, chest: 'silver' },
];

export const dayKey = (at: Date): string => at.toISOString().slice(0, 10);

const daysBetween = (a: string, b: string): number =>
  Math.round((Date.parse(`${b}T00:00:00Z`) - Date.parse(`${a}T00:00:00Z`)) / 86_400_000);

/**
 * Какая серия у игрока сегодня: подряд идущие дни (UTC); пропуск дня сбрасывает на 1;
 * после 7-го дня серия начинается заново. `claimed` — сегодня уже получено.
 */
export function loginState(
  last: { day: string; streak: number } | null,
  today: string,
): { claimed: boolean; day: number } {
  if (!last) return { claimed: false, day: 1 };
  const gap = daysBetween(last.day, today);
  if (gap <= 0) return { claimed: true, day: last.streak };
  if (gap === 1) return { claimed: false, day: last.streak >= LOGIN_DAYS ? 1 : last.streak + 1 };
  return { claimed: false, day: 1 };
}
