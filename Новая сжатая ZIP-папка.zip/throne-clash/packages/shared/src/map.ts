import { MAP_SIZE, RESOURCE_KEYS, type ResourceKey } from './constants';
import { hashSeed, mulberry32 } from './rng';

/**
 * Карта мира: сетка MAP_SIZE × MAP_SIZE, целиком выводится из seed мира (docs/GAME_DESIGN.md §6).
 * В БД карта не хранится: рельеф, ресурсные точки и лагеря — чистые функции от (seed, x, y);
 * в БД лежит только изменяемое — замки, кулдауны лагерей, остатки ресурсных точек.
 */

/** Рельеф. Карта v1 знает первые четыре вида; остальные даёт генератор v2 (D-74). */
export type Terrain =
  'plain' | 'forest' | 'mountain' | 'water' | 'desert' | 'swamp' | 'sea' | 'lake' | 'river';
export type CellKind = 'empty' | 'resource' | 'camp';

export interface Point {
  x: number;
  y: number;
}

export interface MapCell extends Point {
  terrain: Terrain;
  kind: CellKind;
  /** Ресурсная точка 1…5, лагерь 1…10; у пустой клетки 0. */
  level: number;
  /** Что добывается на ресурсной точке. */
  resource: ResourceKey | null;
  /** Дорога (карта v2): по ней идут быстрее, через реки, озёра и горы — мост или тоннель. */
  road?: boolean;
  /** Номер региона 0…63 (карта v2). */
  region?: number;
}

export const MAP_CENTER: Point = { x: Math.floor(MAP_SIZE / 2), y: Math.floor(MAP_SIZE / 2) };
/** Минимальное расстояние (по клеткам, по большей из осей) между замками. */
export const MIN_CASTLE_GAP = 3;
/** Вокруг центра карты нет точек и лагерей — там селятся первые игроки. */
const CLEAR_RADIUS = 5;
const RESOURCE_CHANCE = 0.05;
const CAMP_CHANCE = 0.025;

/** Число в [0, 1) — одно и то же для одной четвёрки (seed, x, y, salt). */
function cellRand(seed: number, x: number, y: number, salt: number): number {
  return mulberry32(hashSeed(`${seed}:${x}:${y}:${salt}`))();
}

const smooth = (t: number): number => t * t * (3 - 2 * t);

/** Значение-шум: случайные значения в узлах решётки, между ними плавная интерполяция. */
function valueNoise(seed: number, x: number, y: number, salt: number): number {
  const x0 = Math.floor(x);
  const y0 = Math.floor(y);
  const fx = smooth(x - x0);
  const fy = smooth(y - y0);
  const v = (ix: number, iy: number): number => cellRand(seed, ix, iy, salt);
  const top = v(x0, y0) * (1 - fx) + v(x0 + 1, y0) * fx;
  const bottom = v(x0, y0 + 1) * (1 - fx) + v(x0 + 1, y0 + 1) * fx;
  return top * (1 - fy) + bottom * fy;
}

export const inBounds = (x: number, y: number): boolean =>
  Number.isInteger(x) && Number.isInteger(y) && x >= 0 && y >= 0 && x < MAP_SIZE && y < MAP_SIZE;

export function terrainAt(seed: number, x: number, y: number): Terrain {
  const n = 0.65 * valueNoise(seed, x / 9, y / 9, 11) + 0.35 * valueNoise(seed, x / 4, y / 4, 12);
  if (n < 0.34) return 'water';
  if (n > 0.66) return 'mountain';
  if (n > 0.56) return 'forest';
  return 'plain';
}

/** Рельеф, по которому можно ходить пешком (без учёта дорог). */
export const isPassableTerrain = (t: Terrain): boolean =>
  t === 'plain' || t === 'forest' || t === 'desert' || t === 'swamp';

export function cellAt(seed: number, x: number, y: number): MapCell {
  const terrain = terrainAt(seed, x, y);
  const empty: MapCell = { x, y, terrain, kind: 'empty', level: 0, resource: null };
  if (!isPassableTerrain(terrain)) return empty;
  if (Math.max(Math.abs(x - MAP_CENTER.x), Math.abs(y - MAP_CENTER.y)) <= CLEAR_RADIUS)
    return empty;

  const r = cellRand(seed, x, y, 2);
  const detail = cellRand(seed, x, y, 3);
  if (r < RESOURCE_CHANCE) {
    return {
      x,
      y,
      terrain,
      kind: 'resource',
      level: 1 + Math.floor(detail * 5),
      resource: RESOURCE_KEYS[Math.floor(cellRand(seed, x, y, 4) * RESOURCE_KEYS.length)] ?? 'gold',
    };
  }
  if (r < RESOURCE_CHANCE + CAMP_CHANCE) {
    // Чем дальше от центра, тем сильнее лагеря
    const far = Math.min(1, distance({ x, y }, MAP_CENTER) / (MAP_SIZE * 0.7));
    const base = 1 + Math.floor(far * 9);
    const level = Math.min(10, Math.max(1, base + (detail < 0.25 ? -1 : detail > 0.75 ? 1 : 0)));
    return { x, y, terrain, kind: 'camp', level, resource: null };
  }
  return empty;
}

export const distance = (a: Point, b: Point): number => Math.hypot(a.x - b.x, a.y - b.y);

/**
 * Место для нового замка: ближайшая к центру подходящая клетка (по спирали из колец),
 * не ближе MIN_CASTLE_GAP к другим замкам. null — карта заполнена.
 */
export function pickCastleSpot(seed: number, taken: readonly Point[]): Point | null {
  return pickCastleSpotWith((x, y) => cellAt(seed, x, y), taken);
}

/** То же для любой версии карты: `cellOf` возвращает клетку по координатам. */
export function pickCastleSpotWith(
  cellOf: (x: number, y: number) => MapCell,
  taken: readonly Point[],
): Point | null {
  // Замки раскладываем по ячейкам размером с зазор: соседей ищем в 3×3 ячейках, а не перебором всех
  const bucket = (v: number): number => Math.floor(v / MIN_CASTLE_GAP);
  const grid = new Map<string, Point[]>();
  for (const t of taken) {
    const k = `${bucket(t.x)}:${bucket(t.y)}`;
    const list = grid.get(k);
    if (list) list.push(t);
    else grid.set(k, [t]);
  }
  const farEnough = (x: number, y: number): boolean => {
    for (let by = bucket(y) - 1; by <= bucket(y) + 1; by++)
      for (let bx = bucket(x) - 1; bx <= bucket(x) + 1; bx++)
        for (const t of grid.get(`${bx}:${by}`) ?? [])
          if (Math.max(Math.abs(t.x - x), Math.abs(t.y - y)) < MIN_CASTLE_GAP) return false;
    return true;
  };
  const ok = (x: number, y: number): boolean => {
    if (!inBounds(x, y) || !farEnough(x, y)) return false;
    const cell = cellOf(x, y);
    return isPassableTerrain(cell.terrain) && cell.kind === 'empty';
  };
  // Кольца вокруг центра: обходим только периметр кольца (а не весь квадрат)
  for (let ring = 0; ring <= MAP_SIZE; ring++) {
    for (let dy = -ring; dy <= ring; dy++) {
      const edge = Math.abs(dy) === ring;
      const step = edge || ring === 0 ? 1 : 2 * ring;
      for (let dx = -ring; dx <= ring; dx += step) {
        const x = MAP_CENTER.x + dx;
        const y = MAP_CENTER.y + dy;
        if (ok(x, y)) return { x, y };
      }
    }
  }
  return null;
}
