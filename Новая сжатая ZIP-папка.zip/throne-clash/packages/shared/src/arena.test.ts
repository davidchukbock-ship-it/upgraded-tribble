import { describe, expect, it } from 'vitest';
import {
  ARENA_LOCATIONS,
  ARENA_PACK,
  PACK_COST,
  budgetFor,
  emptyPacks,
  enemyPacks,
  fightArena,
  packsToUnits,
  spent,
} from './arena';

describe('арена (D-67)', () => {
  it('бюджет растёт с волной, стоимость пачек считается', () => {
    expect(budgetFor(1)).toBeLessThan(budgetFor(5));
    expect(spent({ infantry: 2, archer: 1, cavalry: 1, siege: 1 })).toBe(
      2 * PACK_COST.infantry + PACK_COST.archer + PACK_COST.cavalry + PACK_COST.siege,
    );
    expect(packsToUnits({ ...emptyPacks(), archer: 3 })).toEqual({ archer_2: 3 * ARENA_PACK });
  });

  it('противник детерминирован по волне и зерну и укладывается в очки', () => {
    for (const wave of [1, 4, 12]) {
      const a = enemyPacks(wave, 5);
      expect(enemyPacks(wave, 5)).toEqual(a);
      expect(spent(a)).toBeLessThanOrEqual(budgetFor(wave) * 1.5 + 3);
      expect(spent(a)).toBeGreaterThan(0);
    }
    expect(enemyPacks(1, 5)).not.toEqual(enemyPacks(1, 6));
  });

  it('бой воспроизводим; лучники сильнее в лесу, чем на лавовом поле', () => {
    const mine = { ...emptyPacks(), archer: budgetFor(3) };
    const a = fightArena({ mine, wave: 3, location: 'forest', seed: 9 });
    const b = fightArena({ mine, wave: 3, location: 'forest', seed: 9 });
    expect(a).toEqual(b);
    let forest = 0;
    let volcano = 0;
    for (let seed = 1; seed <= 30; seed++) {
      forest += fightArena({ mine, wave: 6, location: 'forest', seed }).won ? 1 : 0;
      volcano += fightArena({ mine, wave: 6, location: 'volcano', seed }).won ? 1 : 0;
    }
    expect(forest).toBeGreaterThan(volcano);
  });

  it('первая волна проходима любым разумным набором на любой локации', () => {
    for (const loc of ARENA_LOCATIONS) {
      let wins = 0;
      for (let seed = 1; seed <= 20; seed++) {
        const mine = { ...emptyPacks(), archer: 4, infantry: budgetFor(1) - 4 };
        wins += fightArena({ mine, wave: 1, location: loc, seed }).won ? 1 : 0;
      }
      expect(wins).toBeGreaterThanOrEqual(15);
    }
  });
});
