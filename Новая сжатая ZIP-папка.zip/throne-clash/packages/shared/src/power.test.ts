import { describe, expect, it } from 'vitest';
import { castlePower, unitPower } from './power';
import { unitStats } from './army';

const levels = { castle: 2, farm: 1 };

describe('мощь', () => {
  it('юнит: атака + защита + здоровье/10', () => {
    const s = unitStats('infantry', 1);
    expect(unitPower('infantry_1')).toBe(s.atk + s.def + s.hp / 10);
    expect(unitPower('junk')).toBe(0);
  });

  it('пустой замок: здания·100 + герой·200', () => {
    expect(castlePower({ army: {}, levels, tech: {}, heroLevel: 1 })).toBe(300 + 200);
  });

  it('войска, раненые и отряды в походе считаются; технологии — по 50 за уровень', () => {
    const base = castlePower({ army: {}, levels, tech: {}, heroLevel: 1 });
    const withArmy = castlePower({
      army: { infantry_1: { count: 10, wounded: 5 } },
      marching: { infantry_1: 5 },
      levels,
      tech: { farming: 2 },
      heroLevel: 1,
    });
    expect(withArmy - base).toBe(Math.round(20 * unitPower('infantry_1')) + 100);
  });

  it('уровень героя не может быть отрицательным', () => {
    expect(castlePower({ army: {}, levels: {}, tech: {}, heroLevel: -5 })).toBe(0);
  });
});
