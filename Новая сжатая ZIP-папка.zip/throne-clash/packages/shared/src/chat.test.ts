import { describe, expect, it } from 'vitest';
import {
  CHAT_MAX_LEN,
  cleanMessage,
  filterProfanity,
  isProfane,
  normalizeWord,
  parseChannel,
  storedChannel,
} from './chat';

const A = '11111111-1111-4111-8111-111111111111';
const B = '22222222-2222-4222-8222-222222222222';

describe('каналы', () => {
  it('разбор: мировой, братство, личный; мусор отвергается', () => {
    expect(parseChannel('world')).toEqual({ kind: 'world' });
    expect(parseChannel('guild')).toEqual({ kind: 'guild' });
    expect(parseChannel(`dm:${B}`)).toEqual({ kind: 'dm', userId: B });
    expect(parseChannel('dm:nope')).toBeNull();
    expect(parseChannel('guild:1')).toBeNull();
    expect(parseChannel('')).toBeNull();
  });

  it('хранимое имя: личный канал одинаков для обоих собеседников; братство требует членства', () => {
    expect(storedChannel({ kind: 'dm', userId: B }, A, null)).toBe(`dm:${A}:${B}`);
    expect(storedChannel({ kind: 'dm', userId: A }, B, null)).toBe(`dm:${A}:${B}`);
    expect(storedChannel({ kind: 'world' }, A, null)).toBe('world');
    expect(storedChannel({ kind: 'guild' }, A, null)).toBeNull();
    expect(storedChannel({ kind: 'guild' }, A, 'g1')).toBe('guild:g1');
  });
});

describe('фильтр брани', () => {
  it('маскирует бранные слова, остальное не трогает', () => {
    expect(filterProfanity('привет, мир')).toEqual({ text: 'привет, мир', filtered: false });
    const r = filterProfanity('ты мудак и всё');
    expect(r).toEqual({ text: 'ты ***** и всё', filtered: true });
    expect(filterProfanity('what the FUCK').text).toBe('what the ****');
  });

  it('ловит подмену букв, повторы и латиницу-кириллицу', () => {
    expect(isProfane('xуй')).toBe(true); // латинская x
    expect(isProfane('хуууй')).toBe(true);
    expect(isProfane('ПИЗДЕЦ')).toBe(true);
    expect(isProfane('fuuuck')).toBe(true);
    expect(isProfane('6лять')).toBe(true);
  });

  it('не режет невинные слова с похожими началами (сукно, класс, shipment)', () => {
    for (const w of [
      'сукно',
      'класс',
      'ассамблея',
      'shipment',
      'hello',
      'Скунс',
      'дикий',
      'Мудрость',
    ]) {
      expect(isProfane(w)).toBe(false);
    }
  });

  it('нормализация слова', () => {
    expect(normalizeWord('ХУУУЙ')).toBe('хуй');
    expect(normalizeWord('Ёлка')).toBe('елка');
  });
});

describe('cleanMessage', () => {
  it('схлопывает пробелы, вырезает управляющие символы', () => {
    expect(cleanMessage('  привет \n\n  мир\t')).toBe('привет мир');
    expect(cleanMessage('a\u0000b​c')).toBe('a b c');
  });
  it('пустое и слишком длинное отвергается', () => {
    expect(cleanMessage('   ')).toBeNull();
    expect(cleanMessage('x'.repeat(CHAT_MAX_LEN))).not.toBeNull();
    expect(cleanMessage('x'.repeat(CHAT_MAX_LEN + 1))).toBeNull();
  });
});
