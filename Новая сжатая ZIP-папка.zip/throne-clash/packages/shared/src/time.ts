/** «1д 2ч 3м 4с»; нули старших разрядов не выводятся, 0 → «0с». */
export function formatDuration(totalSeconds: number): string {
  const s = Math.max(0, Math.floor(totalSeconds));
  if (s === 0) return '0с';
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return [d && `${d}д`, h && `${h}ч`, m && `${m}м`, sec && `${sec}с`].filter(Boolean).join(' ');
}

/** Секунды между двумя моментами, не меньше 0. Время передаётся параметрами — без Date.now() (D-08). */
export function secondsBetween(from: Date, to: Date): number {
  return Math.max(0, Math.floor((to.getTime() - from.getTime()) / 1000));
}
