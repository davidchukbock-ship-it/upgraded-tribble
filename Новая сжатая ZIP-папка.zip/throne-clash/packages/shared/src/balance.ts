import { z } from 'zod';

/**
 * Конструктор баланса (режим бога, D-50): глобальные множители к ценам, времени, производству и
 * характеристикам юнитов. Единица — значения из docs/GAME_DESIGN.md. Хранится в БД (ревизии), на сервере
 * применяется на лету; клиент формулами не пользуется — цены и время приходят в DTO.
 */
export const BALANCE_KEYS = [
  'buildCost',
  'buildTime',
  'trainCost',
  'trainTime',
  'researchCost',
  'researchTime',
  'production',
  'attack',
  'defense',
  'health',
] as const;
export type BalanceKey = (typeof BALANCE_KEYS)[number];
export type Balance = Record<BalanceKey, number>;

export const BALANCE_MIN = 0.1;
export const BALANCE_MAX = 10;

export const DEFAULT_BALANCE: Readonly<Balance> = Object.freeze({
  buildCost: 1,
  buildTime: 1,
  trainCost: 1,
  trainTime: 1,
  researchCost: 1,
  researchTime: 1,
  production: 1,
  attack: 1,
  defense: 1,
  health: 1,
});

const mult = z.number().min(BALANCE_MIN).max(BALANCE_MAX);
export const balanceSchema = z.object(
  Object.fromEntries(BALANCE_KEYS.map((k) => [k, mult])) as Record<BalanceKey, typeof mult>,
);

/** Действующий баланс процесса. Меняется только через setBalance (сервер, режим бога). */
let current: Balance = { ...DEFAULT_BALANCE };

export const getBalance = (): Readonly<Balance> => current;
export const setBalance = (b: Balance): void => {
  current = { ...b };
};
export const resetBalance = (): void => setBalance({ ...DEFAULT_BALANCE });
