import type { UnitTier } from './constants';
import { mulberry32 } from './rng';
import { parseUnitId, unitId, unitStats, type UnitId } from './army';
import type { ResourceAmounts } from './economy';
import { cargoOf, type UnitCounts } from './battle';
import { distance, type Point } from './map';

/** Походы: время в пути, лагеря монстров, сбор ресурсов, разведка (docs/GAME_DESIGN.md §5). */

export const MARCH_TYPES = ['attack', 'monster', 'scout', 'gather'] as const;
export type MarchType = (typeof MARCH_TYPES)[number];

export const MIN_TRAVEL_SECONDS = 30;
/** Одновременных походов на замок. */
export const MAX_MARCHES = 5;
export const CAMP_RESPAWN_SECONDS = 30 * 60;
export const NODE_RESPAWN_SECONDS = 60 * 60;
export const SCOUT_ERROR = 0.1;

/** Самый медленный юнит определяет скорость отряда. */
export function slowestSecPerTile(units: UnitCounts): number {
  let slowest = 0;
  for (const [id, n] of Object.entries(units)) {
    const p = parseUnitId(id);
    if (p && n && n > 0) slowest = Math.max(slowest, unitStats(p.type, p.tier).secPerTile);
  }
  return slowest;
}

/** Время в один конец, секунды: не меньше 30 (на скорости мира 1), с учётом «Тактики». */
export function travelSeconds(
  from: Point,
  to: Point,
  units: UnitCounts,
  tacticsBonus = 0,
  worldSpeed = 1,
): number {
  const raw = Math.ceil(distance(from, to)) * slowestSecPerTile(units) * (1 - tacticsBonus);
  return Math.max(1, Math.ceil(Math.max(MIN_TRAVEL_SECONDS, raw) / worldSpeed));
}

/** Защитники лагеря: пехота и лучники тира ceil(level/2), по 20·level штук каждого. */
export function campForces(level: number): UnitCounts {
  const tier = Math.min(5, Math.max(1, Math.ceil(level / 2))) as UnitTier;
  const n = 20 * level;
  return { [unitId('infantry', tier)]: n, [unitId('archer', tier)]: n };
}

export interface CampReward {
  resources: ResourceAmounts;
  heroXp: number;
  /** Шанс сундука (сундуки — этап 7). */
  chestChance: number;
}

export function campReward(level: number): CampReward {
  return {
    resources: { gold: 400 * level, wood: 300 * level, stone: 150 * level, food: 300 * level },
    heroXp: 25 * level,
    chestChance: Math.min(0.5, 0.05 * level),
  };
}

/** Запас ресурсной точки. */
export const nodeCapacity = (level: number): number => 5000 * level;

/** Сколько отряд соберёт: груз, но не больше остатка на точке. */
export const gatherAmount = (units: UnitCounts, remaining: number): number =>
  Math.max(0, Math.min(cargoOf(units), Math.floor(remaining)));

/** Время сбора: 1 минута на каждую начатую 1000 груза. */
export const gatherSeconds = (load: number): number => Math.max(1, Math.ceil(load / 1000)) * 60;

/** Разведка показывает состав с погрешностью ±10%, одинаковой для одного seed отчёта. */
export function fuzzUnits(units: UnitCounts, seed: number): UnitCounts {
  const rng = mulberry32(seed);
  const out: UnitCounts = {};
  for (const id of Object.keys(units).sort()) {
    const n = units[id as UnitId] ?? 0;
    if (n <= 0) continue;
    out[id as UnitId] = Math.max(1, Math.round(n * (1 - SCOUT_ERROR + 2 * SCOUT_ERROR * rng())));
  }
  return out;
}

export function isOnlyCavalry(units: UnitCounts): boolean {
  const entries = Object.entries(units).filter(([, n]) => (n ?? 0) > 0);
  return entries.length > 0 && entries.every(([id]) => parseUnitId(id)?.type === 'cavalry');
}
