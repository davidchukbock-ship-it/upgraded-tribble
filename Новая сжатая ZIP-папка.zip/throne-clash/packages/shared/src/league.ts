import type { ChestKind } from './chests';

/** Лиги и сезоны (docs/GAME_DESIGN.md §11). Сезон — неделя, понедельник 00:00 UTC → воскресенье 23:59:59. */

export const LEAGUE_METRICS = ['points', 'power', 'wins', 'kills'] as const;
export type LeagueMetric = (typeof LEAGUE_METRICS)[number];
export const LEAGUE_SCOPES = ['me', 'guild', 'top100'] as const;
export type LeagueScope = (typeof LEAGUE_SCOPES)[number];
export const TOP_SIZE = 100;
export const ME_WINDOW = 5;

const DAY = 86_400_000;

/** Начало сезона (понедельник 00:00 UTC), в который попадает момент `at`. */
export function seasonStart(at: Date): Date {
  const d = new Date(Date.UTC(at.getUTCFullYear(), at.getUTCMonth(), at.getUTCDate()));
  const sinceMonday = (d.getUTCDay() + 6) % 7;
  return new Date(d.getTime() - sinceMonday * DAY);
}

/** Идентификатор сезона — дата его начала: `2026-01-05`. */
export const seasonId = (at: Date): string => seasonStart(at).toISOString().slice(0, 10);

export const seasonEnd = (at: Date): Date => new Date(seasonStart(at).getTime() + 7 * DAY);

/** Начало сезона по его идентификатору; null — не идентификатор. */
export function seasonStartOf(id: string): Date | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(id)) return null;
  const d = new Date(`${id}T00:00:00.000Z`);
  return Number.isNaN(d.getTime()) ? null : d;
}

/** Очки сезона: мощь/100 + 50·победы + убийства/10. */
export const leaguePoints = (v: { power: number; wins: number; kills: number }): number =>
  Math.floor(v.power / 100 + 50 * v.wins + v.kills / 10);

export interface SeasonPrize {
  gems: number;
  chest: ChestKind | null;
}

/** Приз за место (без деревянного сундука участника, который получают все). */
export function placePrize(place: number): SeasonPrize {
  if (place === 1) return { gems: 100, chest: 'gold' };
  if (place >= 2 && place <= 10) return { gems: 50, chest: 'silver' };
  if (place >= 11 && place <= 100) return { gems: 20, chest: null };
  return { gems: 0, chest: null };
}

export function metricValue(
  m: LeagueMetric,
  v: { power: number; wins: number; kills: number },
): number {
  return m === 'points'
    ? leaguePoints(v)
    : m === 'power'
      ? v.power
      : m === 'wins'
        ? v.wins
        : v.kills;
}
