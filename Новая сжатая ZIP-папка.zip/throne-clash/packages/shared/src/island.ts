import type { BuildingKey } from './constants';

/**
 * Геометрия острова замка (общая для клиента и сервера): размеры, участки зданий, улицы.
 * Клетки острова, не занятые зданиями и улицами, можно застраивать своими постройками (structures.ts).
 */

/** Здания, которые стоят на участке острова (Стены и Земли рисуются отдельно). */
export type PlacedKey = Exclude<BuildingKey, 'walls' | 'territory'>;

/** Стартовый остров замка в клетках; каждый уровень Земель прибавляет по 4 клетки в обе стороны. */
export const ISLAND = { w: 20, d: 19 } as const;
export const TERRITORY_STEP = 4;
export const MAX_TERRITORY = 4;

export const islandSize = (territory: number): { w: number; d: number } => ({
  w: ISLAND.w + TERRITORY_STEP * territory,
  d: ISLAND.d + TERRITORY_STEP * territory,
});

/** Где стоит каждое здание (левый дальний угол участка, клетки). Новые — на расширенных землях. */
export const PLACEMENT: Readonly<Record<PlacedKey, { x: number; y: number }>> = {
  farm: { x: 1.6, y: 0.9 },
  goldmine: { x: 8.6, y: 0.7 },
  quarry: { x: 14.4, y: 1.2 },
  sawmill: { x: 1.2, y: 6.6 },
  academy: { x: 1.2, y: 10.2 },
  warehouse: { x: 1.2, y: 13.9 },
  castle: { x: 6.5, y: 6.4 },
  forge: { x: 14.6, y: 6.6 },
  hospital: { x: 14.6, y: 10.2 },
  barracks: { x: 6.6, y: 13.6 },
  // Земли 1 (24×23)
  fishery: { x: 20.7, y: 8.4 },
  archertower: { x: 20.9, y: 2.6 },
  // Земли 2 (28×27)
  diamondmine: { x: 24.6, y: 3.2 },
  ballistatower: { x: 24.9, y: 10.6 },
  magetower: { x: 8.6, y: 23.6 },
  // Земли 3 (32×31)
  stormtower: { x: 28.9, y: 6.8 },
};

/** Размер участка здания в клетках. */
export const FOOTPRINT: Readonly<Record<PlacedKey, { w: number; d: number }>> = {
  castle: { w: 5, d: 4 },
  farm: { w: 4, d: 4 },
  goldmine: { w: 4, d: 4 },
  sawmill: { w: 3, d: 3 },
  quarry: { w: 3, d: 3 },
  warehouse: { w: 3, d: 2 },
  forge: { w: 3, d: 3 },
  academy: { w: 3, d: 3 },
  hospital: { w: 3, d: 3 },
  barracks: { w: 4, d: 3 },
  fishery: { w: 3, d: 3 },
  diamondmine: { w: 3, d: 3 },
  magetower: { w: 2, d: 2 },
  archertower: { w: 2, d: 2 },
  ballistatower: { w: 2, d: 2 },
  stormtower: { w: 2, d: 2 },
};

/** Ворота в передней стене (по оси x). */
export const GATE_X = 12.5;

/** Мощёные улицы: строки и столбцы клеток. */
export const ROAD_ROWS: readonly number[] = [5, 11];
export const ROAD_COLS: readonly number[] = [5, 12];

/** Клетки улиц (`x-y`) для острова заданного размера. */
export function roadCells(W: number, D: number): Set<string> {
  const road = new Set<string>();
  for (const y of ROAD_ROWS) for (let x = 1; x < W - 1; x++) road.add(`${x}-${y}`);
  for (const x of ROAD_COLS) for (let y = ROAD_ROWS[0]!; y < D; y++) road.add(`${x}-${y}`);
  return road;
}

/** Клетка (gx, gy) лежит на участке какого-либо здания (с зазором в четверть клетки). */
export function onBuildingPlot(gx: number, gy: number): boolean {
  const pad = 0.25;
  return (Object.keys(PLACEMENT) as PlacedKey[]).some((k) => {
    const p = PLACEMENT[k];
    const f = FOOTPRINT[k];
    return gx + 1 > p.x - pad && gx < p.x + f.w + pad && gy + 1 > p.y - pad && gy < p.y + f.d + pad;
  });
}
