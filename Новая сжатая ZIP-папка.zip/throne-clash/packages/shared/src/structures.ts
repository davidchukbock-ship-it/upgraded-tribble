import type { ResourceAmounts } from './economy';
import { islandSize, onBuildingPlot, roadCells } from './island';

/**
 * Постройки города (D-66): свободные клетки острова игрок застраивает за ресурсы.
 * Они не в очереди стройки, ставятся сразу и дают «процветание» — процентную прибавку ко всему производству.
 * Каталог данных: новый вид добавляется строкой в `STRUCTURE_DEFS`.
 */
export const STRUCTURE_KINDS = [
  'house',
  'cottage',
  'townhouse',
  'manor',
  'apartment',
  'road',
  'plaza',
  'lamp',
  'bench',
  'signpost',
  'garden',
  'flowerbed',
  'grove',
  'orchard',
  'vineyard',
  'pond',
  'well',
  'bakery',
  'workshop',
  'tavern',
  'inn',
  'bathhouse',
  'school',
  'clinic',
  'guardpost',
  'stall',
  'market',
  'warehouse',
  'bank',
  'chapel',
  'temple',
  'theatre',
  'library',
  'statue',
  'obelisk',
  'fountain',
  'lighthouse',
  'park',
  'playground',
  'campfire',
  'tent',
  'pier',
  'dock',
  'rowboat',
  'fishboat',
  'ship',
  'ferry',
  'galleon',
  'buoy',
] as const;
export type StructureKind = (typeof STRUCTURE_KINDS)[number];

/** Разделы каталога: в интерфейсе виды сгруппированы по ним. */
export const STRUCTURE_GROUPS = [
  'housing',
  'road',
  'nature',
  'service',
  'trade',
  'culture',
  'leisure',
  'sea',
] as const;
export type StructureGroup = (typeof STRUCTURE_GROUPS)[number];

export interface StructureDef {
  group: StructureGroup;
  /** Цена первой постройки; каждая следующая того же вида дороже в `growth` раз. */
  cost: ResourceAmounts;
  growth: number;
  /** Прибавка к производству одной постройки (доля: 0,006 = +0,6 %). */
  bonus: number;
  /** Сколько таких построек можно иметь. */
  max: number;
  /** Нужный уровень Замка. */
  castle: number;
  /** Ставится не на остров, а на воду за его задним краем (пирс, корабли). */
  sea?: boolean;
  /** Морской вид, который ставится только вплотную к берегу (пирс, док). */
  coast?: boolean;
}

export const STRUCTURE_DEFS: Readonly<Record<StructureKind, StructureDef>> = {
  house: {
    group: 'housing',
    cost: { gold: 150, wood: 120, stone: 80, food: 0 },
    growth: 1.1,
    bonus: 0.006,
    max: 12,
    castle: 1,
  },
  cottage: {
    group: 'housing',
    cost: { gold: 110, wood: 140, stone: 40, food: 0 },
    growth: 1.1,
    bonus: 0.005,
    max: 10,
    castle: 2,
  },
  townhouse: {
    group: 'housing',
    cost: { gold: 260, wood: 200, stone: 180, food: 0 },
    growth: 1.14,
    bonus: 0.008,
    max: 8,
    castle: 4,
  },
  manor: {
    group: 'housing',
    cost: { gold: 700, wood: 450, stone: 500, food: 80 },
    growth: 1.22,
    bonus: 0.014,
    max: 4,
    castle: 8,
  },
  apartment: {
    group: 'housing',
    cost: { gold: 1000, wood: 500, stone: 800, food: 100 },
    growth: 1.25,
    bonus: 0.016,
    max: 4,
    castle: 11,
  },
  road: {
    group: 'road',
    cost: { gold: 0, wood: 0, stone: 15, food: 0 },
    growth: 1.0,
    bonus: 0,
    max: 80,
    castle: 1,
  },
  plaza: {
    group: 'road',
    cost: { gold: 20, wood: 0, stone: 60, food: 0 },
    growth: 1.03,
    bonus: 0.001,
    max: 20,
    castle: 2,
  },
  lamp: {
    group: 'road',
    cost: { gold: 30, wood: 20, stone: 10, food: 0 },
    growth: 1.04,
    bonus: 0.001,
    max: 30,
    castle: 1,
  },
  bench: {
    group: 'road',
    cost: { gold: 10, wood: 30, stone: 0, food: 0 },
    growth: 1.03,
    bonus: 0.0005,
    max: 20,
    castle: 1,
  },
  signpost: {
    group: 'road',
    cost: { gold: 10, wood: 20, stone: 0, food: 0 },
    growth: 1.05,
    bonus: 0,
    max: 6,
    castle: 1,
  },
  garden: {
    group: 'nature',
    cost: { gold: 60, wood: 100, stone: 20, food: 0 },
    growth: 1.08,
    bonus: 0.004,
    max: 12,
    castle: 1,
  },
  flowerbed: {
    group: 'nature',
    cost: { gold: 20, wood: 30, stone: 0, food: 0 },
    growth: 1.04,
    bonus: 0.002,
    max: 20,
    castle: 1,
  },
  grove: {
    group: 'nature',
    cost: { gold: 30, wood: 60, stone: 0, food: 0 },
    growth: 1.05,
    bonus: 0.003,
    max: 12,
    castle: 1,
  },
  orchard: {
    group: 'nature',
    cost: { gold: 120, wood: 200, stone: 40, food: 0 },
    growth: 1.1,
    bonus: 0.006,
    max: 8,
    castle: 3,
  },
  vineyard: {
    group: 'nature',
    cost: { gold: 220, wood: 260, stone: 60, food: 0 },
    growth: 1.14,
    bonus: 0.008,
    max: 6,
    castle: 5,
  },
  pond: {
    group: 'nature',
    cost: { gold: 60, wood: 20, stone: 120, food: 0 },
    growth: 1.08,
    bonus: 0.004,
    max: 6,
    castle: 3,
  },
  well: {
    group: 'service',
    cost: { gold: 40, wood: 60, stone: 60, food: 0 },
    growth: 1.1,
    bonus: 0.003,
    max: 4,
    castle: 1,
  },
  bakery: {
    group: 'service',
    cost: { gold: 180, wood: 200, stone: 100, food: 0 },
    growth: 1.15,
    bonus: 0.008,
    max: 4,
    castle: 3,
  },
  workshop: {
    group: 'service',
    cost: { gold: 260, wood: 260, stone: 160, food: 0 },
    growth: 1.15,
    bonus: 0.008,
    max: 4,
    castle: 5,
  },
  tavern: {
    group: 'service',
    cost: { gold: 300, wood: 220, stone: 120, food: 80 },
    growth: 1.18,
    bonus: 0.01,
    max: 4,
    castle: 6,
  },
  inn: {
    group: 'service',
    cost: { gold: 400, wood: 320, stone: 220, food: 60 },
    growth: 1.2,
    bonus: 0.011,
    max: 3,
    castle: 6,
  },
  bathhouse: {
    group: 'service',
    cost: { gold: 350, wood: 300, stone: 300, food: 0 },
    growth: 1.2,
    bonus: 0.01,
    max: 3,
    castle: 7,
  },
  school: {
    group: 'service',
    cost: { gold: 450, wood: 300, stone: 350, food: 0 },
    growth: 1.22,
    bonus: 0.012,
    max: 3,
    castle: 6,
  },
  clinic: {
    group: 'service',
    cost: { gold: 500, wood: 300, stone: 400, food: 80 },
    growth: 1.22,
    bonus: 0.012,
    max: 3,
    castle: 8,
  },
  guardpost: {
    group: 'service',
    cost: { gold: 140, wood: 180, stone: 220, food: 0 },
    growth: 1.12,
    bonus: 0.005,
    max: 6,
    castle: 4,
  },
  stall: {
    group: 'trade',
    cost: { gold: 50, wood: 90, stone: 10, food: 0 },
    growth: 1.06,
    bonus: 0.003,
    max: 12,
    castle: 2,
  },
  market: {
    group: 'trade',
    cost: { gold: 500, wood: 300, stone: 300, food: 100 },
    growth: 1.2,
    bonus: 0.015,
    max: 4,
    castle: 4,
  },
  warehouse: {
    group: 'trade',
    cost: { gold: 200, wood: 300, stone: 200, food: 0 },
    growth: 1.15,
    bonus: 0.006,
    max: 4,
    castle: 4,
  },
  bank: {
    group: 'trade',
    cost: { gold: 1200, wood: 400, stone: 900, food: 0 },
    growth: 1.3,
    bonus: 0.02,
    max: 2,
    castle: 10,
  },
  chapel: {
    group: 'culture',
    cost: { gold: 240, wood: 220, stone: 300, food: 0 },
    growth: 1.15,
    bonus: 0.008,
    max: 4,
    castle: 5,
  },
  temple: {
    group: 'culture',
    cost: { gold: 900, wood: 400, stone: 1000, food: 0 },
    growth: 1.3,
    bonus: 0.016,
    max: 2,
    castle: 10,
  },
  theatre: {
    group: 'culture',
    cost: { gold: 800, wood: 500, stone: 600, food: 0 },
    growth: 1.28,
    bonus: 0.014,
    max: 2,
    castle: 9,
  },
  library: {
    group: 'culture',
    cost: { gold: 600, wood: 300, stone: 400, food: 0 },
    growth: 1.25,
    bonus: 0.012,
    max: 3,
    castle: 9,
  },
  statue: {
    group: 'culture',
    cost: { gold: 400, wood: 100, stone: 600, food: 0 },
    growth: 1.2,
    bonus: 0.01,
    max: 4,
    castle: 6,
  },
  obelisk: {
    group: 'culture',
    cost: { gold: 300, wood: 80, stone: 500, food: 0 },
    growth: 1.15,
    bonus: 0.008,
    max: 4,
    castle: 6,
  },
  fountain: {
    group: 'culture',
    cost: { gold: 120, wood: 0, stone: 180, food: 0 },
    growth: 1.1,
    bonus: 0.003,
    max: 8,
    castle: 2,
  },
  lighthouse: {
    group: 'culture',
    cost: { gold: 800, wood: 200, stone: 900, food: 0 },
    growth: 1.3,
    bonus: 0.014,
    max: 2,
    castle: 8,
  },
  park: {
    group: 'leisure',
    cost: { gold: 200, wood: 150, stone: 150, food: 0 },
    growth: 1.12,
    bonus: 0.008,
    max: 6,
    castle: 3,
  },
  playground: {
    group: 'leisure',
    cost: { gold: 120, wood: 220, stone: 60, food: 0 },
    growth: 1.1,
    bonus: 0.005,
    max: 4,
    castle: 4,
  },
  campfire: {
    group: 'leisure',
    cost: { gold: 10, wood: 50, stone: 0, food: 0 },
    growth: 1.05,
    bonus: 0.002,
    max: 4,
    castle: 1,
  },
  tent: {
    group: 'leisure',
    cost: { gold: 40, wood: 80, stone: 0, food: 10 },
    growth: 1.06,
    bonus: 0.002,
    max: 6,
    castle: 1,
  },
  pier: {
    group: 'sea',
    cost: { gold: 90, wood: 220, stone: 30, food: 0 },
    growth: 1.08,
    bonus: 0.003,
    max: 8,
    castle: 3,
    sea: true,
    coast: true,
  },
  dock: {
    group: 'sea',
    cost: { gold: 350, wood: 450, stone: 250, food: 0 },
    growth: 1.18,
    bonus: 0.009,
    max: 3,
    castle: 6,
    sea: true,
    coast: true,
  },
  rowboat: {
    group: 'sea',
    cost: { gold: 40, wood: 110, stone: 0, food: 0 },
    growth: 1.06,
    bonus: 0.002,
    max: 8,
    castle: 2,
    sea: true,
  },
  fishboat: {
    group: 'sea',
    cost: { gold: 90, wood: 180, stone: 10, food: 20 },
    growth: 1.1,
    bonus: 0.005,
    max: 6,
    castle: 3,
    sea: true,
  },
  ship: {
    group: 'sea',
    cost: { gold: 350, wood: 450, stone: 80, food: 60 },
    growth: 1.2,
    bonus: 0.006,
    max: 6,
    castle: 5,
    sea: true,
  },
  ferry: {
    group: 'sea',
    cost: { gold: 300, wood: 500, stone: 120, food: 0 },
    growth: 1.18,
    bonus: 0.008,
    max: 4,
    castle: 6,
    sea: true,
  },
  galleon: {
    group: 'sea',
    cost: { gold: 900, wood: 900, stone: 300, food: 100 },
    growth: 1.28,
    bonus: 0.012,
    max: 3,
    castle: 10,
    sea: true,
  },
  buoy: {
    group: 'sea',
    cost: { gold: 20, wood: 40, stone: 0, food: 0 },
    growth: 1.03,
    bonus: 0.001,
    max: 10,
    castle: 1,
    sea: true,
  },
};

/** Потолок процветания: сколько бы ни построили, рост производства не превысит +50 %. */
export const PROSPERITY_CAP = 0.5;

export interface PlacedStructure {
  id: string;
  kind: StructureKind;
  /** Клетка острова (целые координаты). */
  x: number;
  y: number;
}

const round5 = (n: number): number => Math.round(n / 5) * 5;

/** Цена следующей постройки вида `kind`, если таких уже `owned`. */
export function structureCost(kind: StructureKind, owned: number): ResourceAmounts {
  const d = STRUCTURE_DEFS[kind];
  const k = d.growth ** owned;
  return {
    gold: round5(d.cost.gold * k),
    wood: round5(d.cost.wood * k),
    stone: round5(d.cost.stone * k),
    food: round5(d.cost.food * k),
  };
}

/** Прибавка ко всему производству от построек. */
export function prosperity(list: readonly Pick<PlacedStructure, 'kind'>[]): number {
  let sum = 0;
  for (const s of list) sum += STRUCTURE_DEFS[s.kind].bonus;
  return Math.min(PROSPERITY_CAP, sum);
}

export type PlaceError = 'kind' | 'castle_level' | 'limit' | 'cell';

/** Можно ли поставить постройку в клетку; null — можно. */
export function placeError(
  kind: StructureKind,
  gx: number,
  gy: number,
  ctx: { castleLevel: number; territory: number; structures: readonly PlacedStructure[] },
): PlaceError | null {
  const d = STRUCTURE_DEFS[kind];
  if (!d) return 'kind';
  if (ctx.castleLevel < d.castle) return 'castle_level';
  if (ctx.structures.filter((s) => s.kind === kind).length >= d.max) return 'limit';
  const ok = d.sea
    ? isWaterCell(ctx.territory, gx, gy, ctx.structures, d.coast === true)
    : isFreeCell(ctx.territory, gx, gy, ctx.structures);
  return ok ? null : 'cell';
}

/** Свободна ли клетка: внутри острова, не на улице, не на участке здания, не занята другой постройкой. */
export function isFreeCell(
  territory: number,
  gx: number,
  gy: number,
  structures: readonly PlacedStructure[],
): boolean {
  if (!Number.isInteger(gx) || !Number.isInteger(gy)) return false;
  const { w, d } = islandSize(territory);
  if (gx < 1 || gy < 1 || gx >= w - 1 || gy >= d - 1) return false;
  if (roadCells(w, d).has(`${gx}-${gy}`)) return false;
  if (onBuildingPlot(gx, gy)) return false;
  return !structures.some((s) => s.x === gx && s.y === gy);
}

/**
 * Вода за задним краем острова (клетки x или y = −2…−1): расширение Земель растёт в +x/+y,
 * поэтому эти клетки остаются водой всегда. Пирс — только вплотную к берегу (−1).
 */
export function isWaterCell(
  territory: number,
  gx: number,
  gy: number,
  structures: readonly PlacedStructure[],
  adjacentOnly = false,
): boolean {
  if (!Number.isInteger(gx) || !Number.isInteger(gy)) return false;
  const { w, d } = islandSize(territory);
  const lo = adjacentOnly ? -1 : -2;
  const onEdge =
    (gx >= lo && gx <= -1 && gy >= lo && gy < d + 2) ||
    (gy >= lo && gy <= -1 && gx >= lo && gx < w + 2);
  return onEdge && !structures.some((s) => s.x === gx && s.y === gy);
}

/** Все свободные клетки (для подсветки при расстановке). Для морских видов — клетки воды. */
export function freeCells(
  territory: number,
  structures: readonly PlacedStructure[],
  kind?: StructureKind,
): Array<{ x: number; y: number }> {
  if (kind && STRUCTURE_DEFS[kind].sea) {
    const { w, d } = islandSize(territory);
    const out: Array<{ x: number; y: number }> = [];
    for (let y = -2; y < d + 2; y++)
      for (let x = -2; x < w + 2; x++)
        if (isWaterCell(territory, x, y, structures, STRUCTURE_DEFS[kind].coast === true))
          out.push({ x, y });
    return out;
  }
  const { w, d } = islandSize(territory);
  const out: Array<{ x: number; y: number }> = [];
  const road = roadCells(w, d);
  const taken = new Set(structures.map((s) => `${s.x}-${s.y}`));
  for (let y = 1; y < d - 1; y++)
    for (let x = 1; x < w - 1; x++) {
      if (road.has(`${x}-${y}`) || taken.has(`${x}-${y}`) || onBuildingPlot(x, y)) continue;
      out.push({ x, y });
    }
  return out;
}

export const structureRefund = (paid: ResourceAmounts): ResourceAmounts => ({
  gold: Math.floor(paid.gold / 2),
  wood: Math.floor(paid.wood / 2),
  stone: Math.floor(paid.stone / 2),
  food: Math.floor(paid.food / 2),
});

// ── DTO ─────────────────────────────────────────────────────────────────────

export interface StructureKindDto {
  kind: StructureKind;
  owned: number;
  max: number;
  cost: ResourceAmounts;
  bonus: number;
  castleRequired: number;
  /** Причина, по которой строить нельзя (кроме нехватки ресурсов). */
  blocked: 'castle_level' | 'limit' | null;
}

export interface CityDto {
  structures: PlacedStructure[];
  catalog: StructureKindDto[];
  prosperity: number;
  cap: number;
}

export function cityDto(structures: readonly PlacedStructure[], castleLevel: number): CityDto {
  return {
    structures: structures.map((s) => ({ ...s })),
    catalog: STRUCTURE_KINDS.map((kind) => {
      const d = STRUCTURE_DEFS[kind];
      const owned = structures.filter((s) => s.kind === kind).length;
      return {
        kind,
        owned,
        max: d.max,
        cost: structureCost(kind, owned),
        bonus: d.bonus,
        castleRequired: d.castle,
        blocked: castleLevel < d.castle ? 'castle_level' : owned >= d.max ? 'limit' : null,
      };
    }),
    prosperity: prosperity(structures),
    cap: PROSPERITY_CAP,
  };
}
