import { describe, expect, it } from 'vitest';
import { MAX_TECH_LEVEL } from './constants';
import { warehouseCap } from './economy';
import {
  RESEARCH_QUEUE_MAX,
  TECHS,
  TECH_KEYS,
  academyLevelFor,
  isTechKey,
  techCost,
  techEconomyMods,
  techEffects,
  techSeconds,
} from './research';

describe('исследования (GAME_DESIGN §7)', () => {
  it('14 технологий в трёх ветках', () => {
    expect(TECH_KEYS).toHaveLength(14);
    const count = (b: string) => TECH_KEYS.filter((k) => TECHS[k].branch === b).length;
    expect([count('economy'), count('military'), count('defense')]).toEqual([5, 6, 3]);
  });
  it('цена: золото и дерево поровну, ×1.5 за уровень, кратно 5', () => {
    expect(techCost('farming', 1)).toEqual({ gold: 150, wood: 150, stone: 0, food: 0 });
    const c = techCost('farming', 2);
    expect(c.gold).toBe(225);
    expect(c.gold).toBe(c.wood);
    for (const k of TECH_KEYS)
      for (let l = 1; l <= MAX_TECH_LEVEL; l++) expect(techCost(k, l).gold % 5).toBe(0);
  });
  it('время ×1.6 за уровень; скорость мира ускоряет', () => {
    expect(techSeconds('farming', 1)).toBe(90);
    expect(techSeconds('farming', 2)).toBe(144);
    expect(techSeconds('farming', 2, 4)).toBe(36);
  });
  it('уровень технологии требует Академию 2L−1, но не выше 20', () => {
    expect([1, 2, 3, 10].map(academyLevelFor)).toEqual([1, 3, 5, 19]);
    expect(academyLevelFor(11)).toBe(20);
  });
  it('ИНВАРИАНТ: любая цена помещается в склад 20-го уровня', () => {
    const cap = warehouseCap(20);
    for (const k of TECH_KEYS) expect(techCost(k, MAX_TECH_LEVEL).gold).toBeLessThan(cap);
  });
  it('очередь — 2 записи', () => expect(RESEARCH_QUEUE_MAX).toBe(2));
  it('isTechKey отсекает мусор', () => {
    expect(isTechKey('drill')).toBe(true);
    for (const bad of ['', 'DRILL', 'constructor', '__proto__']) expect(isTechKey(bad)).toBe(false);
  });
});

describe('эффекты технологий', () => {
  it('без исследований — нули', () => {
    const e = techEffects({});
    expect(e.production).toEqual({ gold: 0, wood: 0, stone: 0, food: 0 });
    expect([e.warehouse, e.defense, e.travelTime, e.trainTime, e.walls]).toEqual([0, 0, 0, 0, 0]);
  });
  it('уровень умножает шаг ветки: земледелие 3 → +15% еды; Логистика 5 → +20% склада', () => {
    const e = techEffects({
      farming: 3,
      logistics: 5,
      drill: 2,
      riding: 4,
      armor: 10,
      medicine: 2,
    });
    expect(e.production.food).toBeCloseTo(0.15);
    expect(e.production.gold).toBe(0);
    expect(e.warehouse).toBeCloseTo(0.2);
    expect(e.trainTime).toBeCloseTo(0.06);
    expect(e.attack.cavalry).toBeCloseTo(0.2);
    expect(e.attack.infantry).toBe(0);
    expect(e.defense).toBeCloseTo(0.3);
    expect(e.woundedCapacity).toBeCloseTo(0.1);
  });
  it('экономическая часть отдаётся в модификаторы производства и склада', () => {
    const m = techEconomyMods({ mining: 2, logistics: 1 });
    expect(m.production?.gold).toBeCloseTo(0.1);
    expect(m.warehouse).toBeCloseTo(0.04);
  });
});
