import { describe, expect, it } from 'vitest';
import { mulberry32 } from './rng';
import {
  BOOSTERS,
  CHEST_KINDS,
  CHEST_ODDS,
  GEMS_RANGE,
  OUTCOME_ORDER,
  RESOURCE_PACK,
  isBoosterKey,
  rollChest,
  rollOutcome,
} from './chests';

describe('таблицы сундуков', () => {
  it('шансы каждого сундука в сумме дают 100%', () => {
    for (const k of CHEST_KINDS) {
      expect(OUTCOME_ORDER.reduce((s, o) => s + CHEST_ODDS[k][o], 0)).toBe(100);
    }
  });

  it('деревянный не даёт редкую экипировку, золотой даёт чаще серебряного', () => {
    expect(CHEST_ODDS.wooden.gear_high).toBe(0);
    expect(CHEST_ODDS.gold.gear_high).toBeGreaterThan(CHEST_ODDS.silver.gear_high);
  });

  it('ускорители: 5 минут, 1 час, 8 часов', () => {
    expect(BOOSTERS).toEqual({ boost_5m: 300, boost_1h: 3600, boost_8h: 28_800 });
    expect(isBoosterKey('boost_1h')).toBe(true);
    expect(isBoosterKey('boost_9h')).toBe(false);
  });
});

describe('rollOutcome', () => {
  it('границы шансов: деревянный', () => {
    expect(rollOutcome('wooden', 0)).toBe('resources');
    expect(rollOutcome('wooden', 0.5999)).toBe('resources');
    expect(rollOutcome('wooden', 0.6)).toBe('booster');
    expect(rollOutcome('wooden', 0.85)).toBe('gems');
    expect(rollOutcome('wooden', 0.95)).toBe('gear_low');
    // 0% шанс не выпадает никогда, даже на верхней границе
    expect(rollOutcome('wooden', 0.99999)).toBe('gear_low');
  });

  it('золотой: верхние 10% — редкая экипировка', () => {
    expect(rollOutcome('gold', 0.89)).toBe('gear_low');
    expect(rollOutcome('gold', 0.9)).toBe('gear_high');
  });
});

describe('rollChest', () => {
  it('детерминирован при одном источнике случайных чисел', () => {
    const a = Array.from({ length: 50 }, (_, i) => rollChest('silver', mulberry32(i)));
    const b = Array.from({ length: 50 }, (_, i) => rollChest('silver', mulberry32(i)));
    expect(a).toEqual(b);
  });

  it('содержимое соответствует виду и диапазонам', () => {
    for (const kind of CHEST_KINDS) {
      const rng = mulberry32(kind.length * 977);
      for (let i = 0; i < 400; i++) {
        const r = rollChest(kind, rng);
        switch (r.type) {
          case 'resources': {
            const n = RESOURCE_PACK[kind];
            expect(r.resources).toEqual({ gold: n, wood: n, stone: n, food: n });
            break;
          }
          case 'booster':
            expect(['boost_5m', 'boost_1h']).toContain(r.booster);
            break;
          case 'gems':
            expect(r.gems).toBeGreaterThanOrEqual(GEMS_RANGE[kind][0]);
            expect(r.gems).toBeLessThanOrEqual(GEMS_RANGE[kind][1]);
            break;
          case 'gear':
            expect([1, 2, 3, 4, 5]).toContain(r.rarity);
            if (kind === 'wooden') expect(r.rarity).toBeLessThanOrEqual(3);
            break;
        }
      }
    }
  });

  it('частоты близки к таблице (10 000 бросков)', () => {
    const rng = mulberry32(2026);
    const count: Record<string, number> = {};
    const N = 10_000;
    for (let i = 0; i < N; i++) {
      const t = rollChest('gold', rng).type;
      count[t] = (count[t] ?? 0) + 1;
    }
    const pct = (t: string) => ((count[t] ?? 0) / N) * 100;
    expect(pct('resources')).toBeGreaterThan(27);
    expect(pct('resources')).toBeLessThan(33);
    expect(pct('gems')).toBeGreaterThan(17);
    expect(pct('gems')).toBeLessThan(23);
    expect(pct('gear')).toBeGreaterThan(22);
    expect(pct('gear')).toBeLessThan(28);
  });
});
