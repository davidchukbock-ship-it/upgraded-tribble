import { describe, expect, it } from 'vitest';
import {
  BUILDING_KEYS,
  ERROR_CODES,
  RESOURCE_KEYS,
  ROLES,
  START_BUILDINGS,
  START_RESOURCES,
  UNIT_TYPES,
} from './constants';

describe('константы', () => {
  it('в игре 18 зданий, 4 ресурса, 4 типа войск, 3 роли', () => {
    expect(BUILDING_KEYS).toHaveLength(18);
    expect(RESOURCE_KEYS).toHaveLength(4);
    expect(UNIT_TYPES).toHaveLength(4);
    expect(ROLES).toEqual(['PLAYER', 'ADMIN', 'OWNER']);
  });
  it('стартовые здания существуют, ключи уникальны', () => {
    for (const b of START_BUILDINGS) expect(BUILDING_KEYS).toContain(b);
    expect(new Set(BUILDING_KEYS).size).toBe(BUILDING_KEYS.length);
  });
  it('старт — по 1000 каждого ресурса', () => {
    for (const r of RESOURCE_KEYS) expect(START_RESOURCES[r]).toBe(1000);
  });
  it('коды ошибок уникальны и начинаются с ERR_', () => {
    const codes = Object.values(ERROR_CODES);
    expect(new Set(codes).size).toBe(codes.length);
    for (const c of codes) expect(c).toMatch(/^ERR_[A-Z_]+$/);
  });
});
