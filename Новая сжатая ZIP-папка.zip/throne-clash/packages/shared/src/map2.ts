import { MAP_SIZE, RESOURCE_KEYS, type ResourceKey } from './constants';
import { MAP_CENTER, distance, type MapCell, type Point, type Terrain } from './map';

/**
 * Карта мира v2 (D-74): материки и архипелаги, моря и озёра, реки, биомы (равнины, леса, горы, пустыни,
 * болота), региональные столицы и дороги между ними. Всё — чистые функции от (seed, x, y): в БД ничего не лежит.
 * Хеш целочисленный (без строк), поэтому в разы быстрее v1. Единственное состояние — кэш дорог по seed
 * (детерминированная мемоизация, результат от неё не зависит).
 */

export const MAP_V2 = 2;
export const REGION_SIZE = 50;
export const REGIONS_PER_SIDE = Math.ceil(MAP_SIZE / REGION_SIZE);
const SEA_LEVEL = 0.47;
const ELEVATION_OFFSET = 0.12;
const MOUNTAIN_LEVEL = 0.76;
/** Вокруг центра нет точек и лагерей — там селятся первые игроки (как в v1). */
const CLEAR_RADIUS = 5;
const RESOURCE_CHANCE = 0.05;
const CAMP_CHANCE = 0.025;

/** Число в [0, 1): одно и то же для одной четвёрки (seed, x, y, salt). */
export function hash01(seed: number, x: number, y: number, salt: number): number {
  let h =
    (seed ^ Math.imul(x, 0x27d4eb2d) ^ Math.imul(y, 0x165667b1) ^ Math.imul(salt, 0x9e3779b1)) >>>
    0;
  h = Math.imul(h ^ (h >>> 15), 0x85ebca6b);
  h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

const smooth = (t: number): number => t * t * (3 - 2 * t);

function valueNoise(seed: number, x: number, y: number, salt: number): number {
  const x0 = Math.floor(x);
  const y0 = Math.floor(y);
  const fx = smooth(x - x0);
  const fy = smooth(y - y0);
  const a = hash01(seed, x0, y0, salt);
  const b = hash01(seed, x0 + 1, y0, salt);
  const c = hash01(seed, x0, y0 + 1, salt);
  const d = hash01(seed, x0 + 1, y0 + 1, salt);
  return (a * (1 - fx) + b * fx) * (1 - fy) + (c * (1 - fx) + d * fx) * fy;
}

/** Фрактальный шум: сумма октав, нормированная в [0, 1]. */
function fbm(seed: number, x: number, y: number, salt: number, octaves: number): number {
  let sum = 0;
  let amp = 1;
  let norm = 0;
  let f = 1;
  for (let o = 0; o < octaves; o++) {
    sum += amp * valueNoise(seed, x * f, y * f, salt + o * 7);
    norm += amp;
    amp *= 0.5;
    f *= 2;
  }
  return sum / norm;
}

/** Высота 0…1: материк вокруг центра, архипелаги и острова ближе к краям, океан у границы. */
function elevation(seed: number, x: number, y: number): number {
  const base = fbm(seed, x / 70, y / 70, 11, 4);
  const islands = fbm(seed, x / 22, y / 22, 13, 2);
  const d = distance({ x, y }, MAP_CENTER);
  const centre = Math.max(0, 1 - d / 95) * 0.22;
  const edge = Math.max(0, (d - 130) / 110) * 0.35;
  const e = base * 0.78 + islands * 0.22 + ELEVATION_OFFSET + centre - edge;
  // Вокруг центра — ровная суша: там селятся первые игроки
  return d < 34 ? Math.min(Math.max(e, SEA_LEVEL + 0.05), MOUNTAIN_LEVEL - 0.05) : e;
}

export type Biome = 'sea' | 'lake' | 'river' | 'mountain' | 'desert' | 'swamp' | 'forest' | 'plain';

function biomeAt(seed: number, x: number, y: number): Biome {
  const e = elevation(seed, x, y);
  const d = distance({ x, y }, MAP_CENTER);
  if (e < SEA_LEVEL) {
    // Внутренние впадины — озёра, остальное — море
    const inland = fbm(seed, x / 150, y / 150, 15, 2);
    return d < 130 && inland > 0.52 && e > SEA_LEVEL - 0.07 ? 'lake' : 'sea';
  }
  if (e > MOUNTAIN_LEVEL) return 'mountain';
  const moisture = fbm(seed, x / 55, y / 55, 21, 3);
  const heat = fbm(seed, x / 95, y / 95, 31, 2);
  // Реки — линии уровня шума; горы и побережье не пересекают
  const r = fbm(seed, x / 42, y / 42, 41, 2);
  if (Math.abs(r - 0.5) < 0.011 && e > SEA_LEVEL + 0.02) return 'river';
  // У центра пустынь и болот нет: там стартовые земли
  const start = d < 30;
  if (!start && moisture < 0.42 && heat > 0.5) return 'desert';
  if (!start && moisture > 0.6 && e < SEA_LEVEL + 0.12) return 'swamp';
  if (moisture > 0.5) return 'forest';
  return 'plain';
}

const BIOME_TERRAIN: Readonly<Record<Biome, Terrain>> = {
  sea: 'sea',
  lake: 'lake',
  river: 'river',
  mountain: 'mountain',
  desert: 'desert',
  swamp: 'swamp',
  forest: 'forest',
  plain: 'plain',
};

const inBounds = (x: number, y: number): boolean =>
  Number.isInteger(x) && Number.isInteger(y) && x >= 0 && y >= 0 && x < MAP_SIZE && y < MAP_SIZE;

/** Рельеф клетки без учёта дорог. */
export function terrainAt2(seed: number, x: number, y: number): Terrain {
  return BIOME_TERRAIN[biomeAt(seed, x, y)];
}

const isLand = (t: Terrain): boolean =>
  t === 'plain' || t === 'forest' || t === 'desert' || t === 'swamp';

// ── Регионы и дороги ───────────────────────────────────────────────────────

export const regionOf = (x: number, y: number): number =>
  Math.floor(y / REGION_SIZE) * REGIONS_PER_SIDE + Math.floor(x / REGION_SIZE);

/** Столица региона: случайная точка у центра региона, сдвинутая на ближайшую сушу (null — региона нет на суше). */
export function regionCapital(seed: number, region: number): Point | null {
  const rx = region % REGIONS_PER_SIDE;
  const ry = Math.floor(region / REGIONS_PER_SIDE);
  const cx = Math.round(rx * REGION_SIZE + REGION_SIZE / 2 + (hash01(seed, rx, ry, 51) - 0.5) * 20);
  const cy = Math.round(ry * REGION_SIZE + REGION_SIZE / 2 + (hash01(seed, rx, ry, 52) - 0.5) * 20);
  for (let r = 0; r <= 14; r++) {
    for (let dy = -r; dy <= r; dy++) {
      for (let dx = -r; dx <= r; dx++) {
        if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
        const x = cx + dx;
        const y = cy + dy;
        if (inBounds(x, y) && isLand(terrainAt2(seed, x, y))) return { x, y };
      }
    }
  }
  return null;
}

function* lineCells(a: Point, b: Point): Generator<Point> {
  const n = Math.max(Math.abs(b.x - a.x), Math.abs(b.y - a.y));
  for (let i = 0; i <= n; i++) {
    const t = n === 0 ? 0 : i / n;
    yield { x: Math.round(a.x + (b.x - a.x) * t), y: Math.round(a.y + (b.y - a.y) * t) };
  }
}

const roadCache = new Map<number, ReadonlySet<number>>();

/** Множество клеток-дорог мира (ключ y * MAP_SIZE + x); кэшируется по seed. */
export function roadCells2(seed: number): ReadonlySet<number> {
  const cached = roadCache.get(seed);
  if (cached) return cached;
  const caps: Array<Point | null> = [];
  for (let i = 0; i < REGIONS_PER_SIDE * REGIONS_PER_SIDE; i++) caps.push(regionCapital(seed, i));
  const cells = new Set<number>();
  const link = (a: Point | null, b: Point | null, salt: number): void => {
    if (!a || !b) return;
    // Путь ломаной через смещённую середину — дорога не прямая
    const mid = {
      x: Math.round((a.x + b.x) / 2 + (hash01(seed, a.x, a.y, salt) - 0.5) * 12),
      y: Math.round((a.y + b.y) / 2 + (hash01(seed, b.x, b.y, salt + 1) - 0.5) * 12),
    };
    const pts: Point[] = [];
    for (const seg of [
      [a, mid],
      [mid, b],
    ] as const)
      for (const p of lineCells(seg[0], seg[1])) if (inBounds(p.x, p.y)) pts.push(p);
    // Море дорогой не пересечь: такой отрезок не строим (туда ходят кораблями)
    if (pts.some((p) => terrainAt2(seed, p.x, p.y) === 'sea')) return;
    for (const p of pts) cells.add(p.y * MAP_SIZE + p.x);
  };
  for (let ry = 0; ry < REGIONS_PER_SIDE; ry++) {
    for (let rx = 0; rx < REGIONS_PER_SIDE; rx++) {
      const i = ry * REGIONS_PER_SIDE + rx;
      if (rx + 1 < REGIONS_PER_SIDE) link(caps[i]!, caps[i + 1]!, 61);
      if (ry + 1 < REGIONS_PER_SIDE) link(caps[i]!, caps[i + REGIONS_PER_SIDE]!, 71);
    }
  }
  if (roadCache.size >= 8) roadCache.clear();
  roadCache.set(seed, cells);
  return cells;
}

export const isRoad2 = (seed: number, x: number, y: number): boolean =>
  roadCells2(seed).has(y * MAP_SIZE + x);

// ── Клетка ────────────────────────────────────────────────────────────────

const BIOME_RESOURCES: Readonly<Partial<Record<Terrain, readonly ResourceKey[]>>> = {
  plain: ['food', 'gold', 'food'],
  forest: ['wood', 'wood', 'food'],
  desert: ['stone', 'gold', 'stone'],
  swamp: ['food', 'wood'],
};

export function cellAt2(seed: number, x: number, y: number): MapCell {
  const terrain = terrainAt2(seed, x, y);
  const road = isRoad2(seed, x, y);
  const region = regionOf(x, y);
  const base: MapCell = { x, y, terrain, kind: 'empty', level: 0, resource: null, region };
  if (road) base.road = true;
  if (!isLand(terrain) || road) return base;
  if (Math.max(Math.abs(x - MAP_CENTER.x), Math.abs(y - MAP_CENTER.y)) <= CLEAR_RADIUS) return base;

  const r = hash01(seed, x, y, 2);
  const detail = hash01(seed, x, y, 3);
  if (r < RESOURCE_CHANCE) {
    const pool = BIOME_RESOURCES[terrain] ?? RESOURCE_KEYS;
    return {
      ...base,
      kind: 'resource',
      level: 1 + Math.floor(detail * 5),
      resource: pool[Math.floor(hash01(seed, x, y, 4) * pool.length)] ?? 'gold',
    };
  }
  if (r < RESOURCE_CHANCE + CAMP_CHANCE) {
    const far = Math.min(1, distance({ x, y }, MAP_CENTER) / (MAP_SIZE * 0.7));
    const level = Math.min(
      10,
      Math.max(1, 1 + Math.floor(far * 9) + (detail < 0.25 ? -1 : detail > 0.75 ? 1 : 0)),
    );
    return { ...base, kind: 'camp', level };
  }
  return base;
}

/** Цена клетки пути (1 — равнина). Дорога ускоряет; null — пешком не пройти. */
export const TERRAIN_COST: Readonly<Record<Terrain, number | null>> = {
  plain: 1,
  forest: 1.4,
  desert: 1.3,
  swamp: 1.8,
  mountain: null,
  water: null,
  sea: null,
  lake: null,
  river: null,
};
export const ROAD_COST = 0.6;

/** Цена шага по клетке для пешего отряда; null — непроходимо. */
export function stepCost(cell: Pick<MapCell, 'terrain' | 'road'>): number | null {
  if (cell.road) return ROAD_COST;
  return TERRAIN_COST[cell.terrain];
}
