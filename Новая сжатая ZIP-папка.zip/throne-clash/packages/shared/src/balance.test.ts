import { afterEach, describe, expect, it } from 'vitest';
import { unitStats, trainCost, trainSeconds } from './army';
import {
  BALANCE_KEYS,
  BALANCE_MAX,
  BALANCE_MIN,
  DEFAULT_BALANCE,
  balanceSchema,
  getBalance,
  resetBalance,
  setBalance,
} from './balance';
import { buildSeconds, buildingCost, productionPerHour } from './economy';
import { techCost, techSeconds } from './research';

afterEach(() => resetBalance());

describe('конструктор баланса', () => {
  it('по умолчанию все множители равны 1 и формулы дают значения из GAME_DESIGN', () => {
    expect(getBalance()).toEqual(DEFAULT_BALANCE);
    expect(BALANCE_KEYS).toHaveLength(10);
    const base = buildingCost('farm', 1);
    setBalance({ ...DEFAULT_BALANCE, buildCost: 3 });
    resetBalance();
    expect(buildingCost('farm', 1)).toEqual(base);
    expect(unitStats('infantry', 1).atk).toBeGreaterThan(0);
  });

  it('стоимость и время построек масштабируются', () => {
    const base = buildingCost('barracks', 3);
    const baseSec = buildSeconds('barracks', 3, 3);
    setBalance({ ...DEFAULT_BALANCE, buildCost: 2, buildTime: 0.5 });
    const cost = buildingCost('barracks', 3);
    expect(cost.gold).toBeGreaterThanOrEqual(base.gold * 2 - 5);
    expect(cost.gold).toBeLessThanOrEqual(base.gold * 2 + 5);
    expect(buildSeconds('barracks', 3, 3)).toBeLessThan(baseSec);
  });

  it('обучение: цена, время; характеристики юнитов', () => {
    const cost = trainCost('archer', 2, 10);
    const sec = trainSeconds('archer', 2, 10, 5);
    const stats = unitStats('archer', 2);
    setBalance({
      ...DEFAULT_BALANCE,
      trainCost: 3,
      trainTime: 2,
      attack: 2,
      defense: 0.5,
      health: 4,
    });
    expect(trainCost('archer', 2, 10).gold).toBe(cost.gold * 3);
    expect(trainSeconds('archer', 2, 10, 5)).toBeGreaterThan(sec);
    const s = unitStats('archer', 2);
    expect(s.atk).toBe(stats.atk * 2);
    expect(s.hp).toBe(stats.hp * 4);
    expect(Math.abs(s.def - stats.def * 0.5)).toBeLessThanOrEqual(1);
  });

  it('исследования и производство', () => {
    const c = techCost('farming', 3);
    const t = techSeconds('farming', 3);
    const p = productionPerHour('gold', 5);
    setBalance({ ...DEFAULT_BALANCE, researchCost: 2, researchTime: 3, production: 1.5 });
    expect(techCost('farming', 3).gold).toBeGreaterThan(c.gold);
    expect(techSeconds('farming', 3)).toBeGreaterThan(t * 2.9);
    expect(productionPerHour('gold', 5)).toBeCloseTo(p * 1.5, 5);
  });

  it('сброс возвращает исходные значения; setBalance копирует объект', () => {
    const b = { ...DEFAULT_BALANCE, buildCost: 5 };
    setBalance(b);
    b.buildCost = 9;
    expect(getBalance().buildCost).toBe(5);
    resetBalance();
    expect(getBalance()).toEqual(DEFAULT_BALANCE);
  });

  it('схема проверяет границы', () => {
    expect(balanceSchema.safeParse(DEFAULT_BALANCE).success).toBe(true);
    expect(balanceSchema.safeParse({ ...DEFAULT_BALANCE, attack: BALANCE_MAX + 1 }).success).toBe(
      false,
    );
    expect(balanceSchema.safeParse({ ...DEFAULT_BALANCE, attack: BALANCE_MIN / 2 }).success).toBe(
      false,
    );
    expect(balanceSchema.safeParse({ ...DEFAULT_BALANCE, attack: 'x' }).success).toBe(false);
  });
});
