import { DEFAULT_CRESTS } from './constants';
import { BOOSTERS, type BoosterKey } from './chests';
import type { ResourceAmounts } from './economy';

/** Магазин за кристаллы (docs/GAME_DESIGN.md §12, D-11): реальных денег нет. */

export const PREMIUM_CRESTS = [
  'lion-gold',
  'lion-azure',
  'lion-ink',
  'wolf-night',
  'wolf-frost',
  'eagle-gold',
  'eagle-crimson',
  'eagle-emerald',
  'stag-royal',
  'stag-autumn',
] as const;
export type PremiumCrest = (typeof PREMIUM_CRESTS)[number];
export const ALL_CRESTS = [...DEFAULT_CRESTS, ...PREMIUM_CRESTS] as const;
export const CREST_PRICE = 50;

export const isPremiumCrest = (c: string): c is PremiumCrest =>
  (PREMIUM_CRESTS as readonly string[]).includes(c);

/** Базовый рисунок герба: премиум-гербы — тот же щит в другой палитре. */
export const crestBase = (c: string): string => (isPremiumCrest(c) ? c.split('-')[0]! : c);

export type ShopItemKind = 'pack' | 'booster' | 'slot' | 'crest';

export interface ShopItem {
  id: string;
  kind: ShopItemKind;
  price: number;
  resources?: ResourceAmounts;
  booster?: BoosterKey;
  crest?: PremiumCrest;
}

const pack = (n: number): ResourceAmounts => ({ gold: n, wood: n, stone: n, food: n });

export const SHOP_CATALOG: readonly ShopItem[] = [
  { id: 'pack_s', kind: 'pack', price: 20, resources: pack(2000) },
  { id: 'pack_m', kind: 'pack', price: 90, resources: pack(10_000) },
  { id: 'pack_l', kind: 'pack', price: 350, resources: pack(50_000) },
  { id: 'boost_5m', kind: 'booster', price: 5, booster: 'boost_5m' },
  { id: 'boost_1h', kind: 'booster', price: 25, booster: 'boost_1h' },
  { id: 'boost_8h', kind: 'booster', price: 150, booster: 'boost_8h' },
  { id: 'slot', kind: 'slot', price: 250 },
  ...PREMIUM_CRESTS.map((c): ShopItem => ({
    id: `crest_${c}`,
    kind: 'crest',
    price: CREST_PRICE,
    crest: c,
  })),
];

export const findShopItem = (id: string): ShopItem | undefined =>
  SHOP_CATALOG.find((i) => i.id === id);

export const boosterSeconds = (b: BoosterKey): number => BOOSTERS[b];
