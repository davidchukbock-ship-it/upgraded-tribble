import { describe, expect, it } from 'vitest';
import { describeGodAction, godActionSchema, parseGodCommand } from './god';

const ok = (input: string) => {
  const r = parseGodCommand(input);
  if (!r.ok) throw new Error(`не разобрано: ${input} → ${r.error}`);
  return r.action;
};

describe('палитра команд', () => {
  it('ресурсы: give / take / set, суффиксы k и m', () => {
    expect(ok('give gold 1000000')).toEqual({
      type: 'resources',
      op: 'give',
      resource: 'gold',
      amount: 1_000_000,
    });
    expect(ok('give gems 5k')).toEqual({
      type: 'resources',
      op: 'give',
      resource: 'gems',
      amount: 5000,
    });
    expect(ok('take wood 2m')).toMatchObject({ op: 'take', resource: 'wood', amount: 2_000_000 });
    expect(ok('  SET   food  10  ')).toMatchObject({ op: 'set', resource: 'food', amount: 10 });
    expect(ok('fill')).toEqual({ type: 'fill' });
  });

  it('здания, время, телепорт, армия', () => {
    expect(ok('build barracks 20')).toEqual({ type: 'building', key: 'barracks', level: 20 });
    expect(ok('time +1d')).toEqual({ type: 'time', seconds: 86_400 });
    expect(ok('time 90m')).toEqual({ type: 'time', seconds: 5400 });
    expect(ok('time +7d')).toEqual({ type: 'time', seconds: 7 * 86_400 });
    expect(ok('teleport 50 50')).toEqual({ type: 'teleport', x: 50, y: 50 });
    expect(ok('spawn army cavalry 500')).toEqual({ type: 'army', unit: 'cavalry_1', count: 500 });
    expect(ok('spawn army siege_4 10')).toEqual({ type: 'army', unit: 'siege_4', count: 10 });
    expect(ok('finish')).toEqual({ type: 'finish' });
    expect(ok('resurrect')).toEqual({ type: 'resurrect' });
    expect(ok('reset')).toEqual({ type: 'reset' });
  });

  it('исследования, герой, щит, сундуки', () => {
    expect(ok('research all')).toEqual({ type: 'research_all' });
    expect(ok('research farming 7')).toEqual({ type: 'research', tech: 'farming', level: 7 });
    expect(ok('hero 30')).toEqual({ type: 'hero', level: 30 });
    expect(ok('hero gear weapon 5')).toEqual({ type: 'hero_gear', slot: 'weapon', rarity: 5 });
    expect(ok('shield 0')).toEqual({ type: 'shield', hours: 0 });
    expect(ok('chest gold 3')).toEqual({ type: 'chest', kind: 'gold', count: 3 });
    expect(ok('chest silver')).toEqual({ type: 'chest', kind: 'silver', count: 1 });
  });

  it('ошибки: пустая, неизвестная, неполная, вне пределов', () => {
    for (const bad of [
      '',
      'dance',
      'give gold',
      'give unobtainium 5',
      'give gold -5',
      'give gold 5000000000',
      'build barracks 21',
      'build castle x',
      'time tomorrow',
      'time +0s',
      'teleport 400 5',
      'teleport 5',
      'spawn cavalry 5',
      'spawn army dragon 5',
      'spawn army cavalry_9 5',
      'hero 51',
      'hero gear helmet 3',
      'hero gear weapon 6',
      'chest wood 1',
      'time +31d',
    ]) {
      expect(parseGodCommand(bad).ok, bad).toBe(false);
    }
  });

  it('всё, что разобрала палитра, проходит серверную схему', () => {
    for (const cmd of [
      'give gold 5',
      'build farm 3',
      'time +1h',
      'teleport 0 99',
      'spawn army archer_5 1',
    ]) {
      expect(godActionSchema.safeParse(ok(cmd)).success).toBe(true);
    }
  });

  it('описание действия для журнала', () => {
    expect(describeGodAction(ok('give gold 1000'))).toBe('give gold 1000');
    expect(describeGodAction(ok('build farm 3'))).toBe('build farm 3');
    expect(describeGodAction(ok('spawn army cavalry 5'))).toBe('spawn army cavalry_1 5');
    expect(describeGodAction(ok('research farming 2'))).toBe('research farming 2');
    expect(describeGodAction(ok('hero 5'))).toBe('hero 5');
    expect(describeGodAction(ok('hero gear relic 2'))).toBe('hero gear relic 2');
    expect(describeGodAction(ok('time +1m'))).toBe('time +60s');
    expect(describeGodAction(ok('teleport 1 2'))).toBe('teleport 1 2');
    expect(describeGodAction(ok('shield 5'))).toBe('shield 5');
    expect(describeGodAction(ok('chest gold 2'))).toBe('chest gold 2');
    expect(describeGodAction({ type: 'booster', booster: 'boost_1h', count: 1 })).toBe(
      'booster boost_1h 1',
    );
    expect(describeGodAction(ok('reset'))).toBe('reset');
  });

  it('схема отвергает лишнее и неверное', () => {
    expect(
      godActionSchema.safeParse({ type: 'resources', op: 'give', resource: 'gold', amount: 1.5 })
        .success,
    ).toBe(false);
    expect(godActionSchema.safeParse({ type: 'army', unit: 'infantry_9', count: 1 }).success).toBe(
      false,
    );
    expect(godActionSchema.safeParse({ type: 'army', unit: 'evil', count: 1 }).success).toBe(false);
    expect(godActionSchema.safeParse({ type: 'time', seconds: 0 }).success).toBe(false);
    expect(
      godActionSchema.safeParse({ type: 'booster', booster: 'boost_9h', count: 1 }).success,
    ).toBe(false);
  });
});
