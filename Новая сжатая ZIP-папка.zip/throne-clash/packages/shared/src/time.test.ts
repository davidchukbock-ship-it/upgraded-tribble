import { describe, expect, it } from 'vitest';
import { formatDuration, secondsBetween } from './time';

describe('formatDuration', () => {
  it.each([
    [0, '0с'],
    [59, '59с'],
    [60, '1м'],
    [3661, '1ч 1м 1с'],
    [86400, '1д'],
    [90061, '1д 1ч 1м 1с'],
    [-5, '0с'],
    [12.9, '12с'],
  ])('%s → %s', (input, expected) => {
    expect(formatDuration(input)).toBe(expected);
  });
});

describe('secondsBetween', () => {
  it('считает секунды и не уходит в минус', () => {
    const a = new Date('2026-01-01T00:00:00Z');
    expect(secondsBetween(a, new Date('2026-01-01T00:01:30Z'))).toBe(90);
    expect(secondsBetween(new Date('2026-01-01T00:01:30Z'), a)).toBe(0);
  });
});
