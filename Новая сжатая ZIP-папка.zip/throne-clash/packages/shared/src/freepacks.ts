import type { QuestReward } from './quests';

/**
 * Бесплатные наборы: чистая награда за время, без случайности и без покупок (D-76).
 * Окно набора считается по UTC от начала эпохи: внутри одного окна набор забирается один раз,
 * следующее окно открывается само. Разовые наборы забираются один раз за всё время.
 */
export interface FreePackDef {
  id: string;
  /** Длина окна в часах; null — разовый набор. */
  everyHours: number | null;
  reward: QuestReward;
}

export const FREE_PACKS: readonly FreePackDef[] = [
  {
    id: 'welcome',
    everyHours: null,
    reward: {
      resources: { gold: 1500, wood: 1500, stone: 1000, food: 1500 },
      gems: 10,
      chest: 'wooden',
    },
  },
  {
    id: 'breeze',
    everyHours: 4,
    reward: { resources: { gold: 150, wood: 150, stone: 100, food: 150 } },
  },
  {
    id: 'builder',
    everyHours: 12,
    reward: { resources: { wood: 400, stone: 400 }, chest: 'wooden' },
  },
  {
    id: 'daybreak',
    everyHours: 24,
    reward: { resources: { gold: 600, wood: 600, stone: 400, food: 600 }, gems: 3 },
  },
  { id: 'harvest', everyHours: 48, reward: { resources: { gold: 500, food: 1200 }, gems: 5 } },
  { id: 'weekly', everyHours: 168, reward: { gems: 25, chest: 'silver' } },
] as const;

export const findFreePack = (id: string): FreePackDef | undefined =>
  FREE_PACKS.find((p) => p.id === id);

const HOUR_MS = 3_600_000;

/** Ключ окна набора: по нему в журнале наград различаются повторные получения. */
export function packPeriod(def: FreePackDef, now: Date): string {
  if (def.everyHours === null) return 'once';
  return `w${Math.floor(now.getTime() / (def.everyHours * HOUR_MS))}`;
}

/** Когда откроется следующее окно (null — набор разовый). */
export function packNextAt(def: FreePackDef, now: Date): Date | null {
  if (def.everyHours === null) return null;
  const len = def.everyHours * HOUR_MS;
  return new Date((Math.floor(now.getTime() / len) + 1) * len);
}

/** Идентификатор записи в журнале наград. */
export const packClaimId = (id: string): string => `pack:${id}`;
