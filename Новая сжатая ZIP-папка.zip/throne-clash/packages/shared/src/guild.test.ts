import { describe, expect, it } from 'vitest';
import {
  GUILD_NAME_MAX,
  canHandleApplications,
  canManage,
  guildCapacity,
  guildLevel,
  guildNameKey,
  guildNameSchema,
} from './guild';

describe('братство', () => {
  it('уровень растёт с казной: 1 + ⌊вклад / 50 000⌋, максимум 10', () => {
    expect(guildLevel(0)).toBe(1);
    expect(guildLevel(49_999)).toBe(1);
    expect(guildLevel(50_000)).toBe(2);
    expect(guildLevel(275_000)).toBe(6);
    expect(guildLevel(10_000_000)).toBe(10);
    expect(guildLevel(-5)).toBe(1);
  });

  it('вместимость 20 + 2·уровень', () => {
    expect(guildCapacity(1)).toBe(22);
    expect(guildCapacity(10)).toBe(40);
  });

  it('название: длина, символы, обрезка пробелов', () => {
    expect(guildNameSchema.safeParse('  Волки Севера ').data).toBe('Волки Севера');
    expect(guildNameSchema.safeParse('ab').success).toBe(false);
    expect(guildNameSchema.safeParse('a'.repeat(GUILD_NAME_MAX + 1)).success).toBe(false);
    expect(guildNameSchema.safeParse('Клан <b>').success).toBe(false);
    expect(guildNameSchema.safeParse("Дом О'Нил").success).toBe(true);
    expect(guildNameSchema.safeParse('Двойной  пробел').success).toBe(false);
  });

  it('ключ названия не различает регистр, разделители и похожие буквы', () => {
    expect(guildNameKey('Волки Севера')).toBe(guildNameKey('волки-севера'));
    expect(guildNameKey('Pex')).toBe(guildNameKey('Реx'));
    expect(guildNameKey('Волки')).not.toBe(guildNameKey('Волк'));
  });

  it('права: глава управляет всеми, офицер — рядовыми, участник — никем', () => {
    expect(canManage('leader', 'officer')).toBe(true);
    expect(canManage('leader', 'member')).toBe(true);
    expect(canManage('leader', 'leader')).toBe(false);
    expect(canManage('officer', 'member')).toBe(true);
    expect(canManage('officer', 'officer')).toBe(false);
    expect(canManage('member', 'member')).toBe(false);
    expect(canHandleApplications('officer')).toBe(true);
    expect(canHandleApplications('member')).toBe(false);
  });
});
