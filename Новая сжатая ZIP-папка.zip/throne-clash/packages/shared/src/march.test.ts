import { describe, expect, it } from 'vitest';
import { unitStats } from './army';
import {
  CAMP_RESPAWN_SECONDS,
  MIN_TRAVEL_SECONDS,
  campForces,
  campReward,
  fuzzUnits,
  gatherAmount,
  gatherSeconds,
  isOnlyCavalry,
  nodeCapacity,
  slowestSecPerTile,
  travelSeconds,
} from './march';

describe('время в пути', () => {
  it('самый медленный юнит определяет скорость', () => {
    expect(slowestSecPerTile({ cavalry_1: 5 })).toBe(30);
    expect(slowestSecPerTile({ cavalry_1: 5, infantry_1: 1 })).toBe(60);
    expect(slowestSecPerTile({ siege_1: 1, cavalry_1: 5 })).toBe(90);
    expect(slowestSecPerTile({})).toBe(0);
  });

  it('расстояние округляется вверх, есть минимум 30 секунд', () => {
    // (0,0)→(3,4): 5 клеток × 60 с
    expect(travelSeconds({ x: 0, y: 0 }, { x: 3, y: 4 }, { infantry_1: 1 })).toBe(300);
    expect(travelSeconds({ x: 0, y: 0 }, { x: 1, y: 0 }, { cavalry_1: 1 })).toBe(
      MIN_TRAVEL_SECONDS,
    );
    // (0,0)→(1,1): √2 → 2 клетки
    expect(travelSeconds({ x: 0, y: 0 }, { x: 1, y: 1 }, { infantry_1: 1 })).toBe(120);
  });

  it('«Тактика» сокращает путь, скорость мира ускоряет', () => {
    const from = { x: 0, y: 0 };
    const to = { x: 10, y: 0 };
    expect(travelSeconds(from, to, { infantry_1: 1 }, 0.3)).toBe(420);
    expect(travelSeconds(from, to, { infantry_1: 1 }, 0, 2)).toBe(300);
  });
});

describe('лагеря, точки, разведка', () => {
  it('состав лагеря: пехота и лучники тира ceil(level/2) по 20·level', () => {
    expect(campForces(1)).toEqual({ infantry_1: 20, archer_1: 20 });
    expect(campForces(5)).toEqual({ infantry_3: 100, archer_3: 100 });
    expect(campForces(10)).toEqual({ infantry_5: 200, archer_5: 200 });
  });

  it('награда растёт с уровнем; шанс сундука ограничен', () => {
    expect(campReward(2).resources.gold).toBe(2 * campReward(1).resources.gold);
    expect(campReward(1).heroXp).toBeLessThan(campReward(10).heroXp);
    expect(campReward(10).chestChance).toBeLessThanOrEqual(0.5);
    expect(CAMP_RESPAWN_SECONDS).toBe(1800);
  });

  it('сбор: не больше груза и не больше остатка; время — минута на 1000 груза', () => {
    const units = { infantry_1: 100 }; // груз 2000
    expect(gatherAmount(units, 50_000)).toBe(2000);
    expect(gatherAmount(units, 700)).toBe(700);
    expect(gatherAmount(units, -5)).toBe(0);
    expect(gatherSeconds(2000)).toBe(120);
    expect(gatherSeconds(2001)).toBe(180);
    expect(gatherSeconds(0)).toBe(60);
    expect(nodeCapacity(3)).toBe(15_000);
    expect(unitStats('infantry', 1).cargo).toBe(20);
  });

  it('погрешность разведки в пределах ±10% и повторяема для одного seed', () => {
    const real = { infantry_1: 200, archer_2: 50 };
    const a = fuzzUnits(real, 42);
    expect(fuzzUnits(real, 42)).toEqual(a);
    expect(a.infantry_1).toBeGreaterThanOrEqual(180);
    expect(a.infantry_1).toBeLessThanOrEqual(220);
    expect(a.archer_2).toBeGreaterThanOrEqual(45);
    expect(a.archer_2).toBeLessThanOrEqual(55);
    expect(fuzzUnits({ infantry_1: 1 }, 7).infantry_1).toBeGreaterThanOrEqual(1);
  });

  it('разведчики — только кавалерия', () => {
    expect(isOnlyCavalry({ cavalry_1: 1 })).toBe(true);
    expect(isOnlyCavalry({ cavalry_1: 1, infantry_1: 1 })).toBe(false);
    expect(isOnlyCavalry({})).toBe(false);
    expect(isOnlyCavalry({ cavalry_1: 0 })).toBe(false);
  });
});
