import { z } from 'zod';
import { nicknameKey } from './validation';

/** Братства (docs/GAME_DESIGN.md §10). Только чистые функции и правила. */

export const GUILD_ROLES = ['leader', 'officer', 'member'] as const;
export type GuildRole = (typeof GUILD_ROLES)[number];

export const GUILD_MIN_CASTLE = 5;
export const GUILD_CREATE_COST = 1000;
export const MAX_GUILD_LEVEL = 10;
export const TREASURY_PER_LEVEL = 50_000;
export const GUILD_NAME_MIN = 3;
export const GUILD_NAME_MAX = 24;
export const GUILD_DESC_MAX = 200;
/** Сколько раз одной стройке можно помочь. */
export const MAX_HELPS_PER_TASK = 10;
export const MIN_DONATION = 10;

/** Уровень братства: 1 + ⌊вклад / 50 000⌋, не выше 10. */
export const guildLevel = (treasuryTotal: number): number =>
  Math.min(MAX_GUILD_LEVEL, 1 + Math.floor(Math.max(0, treasuryTotal) / TREASURY_PER_LEVEL));

export const guildCapacity = (level: number): number => 20 + 2 * level;

const NAME_RE = /^[\p{L}\p{N}](?:[\p{L}\p{N}]|[ '_-](?=[\p{L}\p{N}]))*$/u;

export const guildNameSchema = z
  .string()
  .transform((s) => s.normalize('NFKC').trim())
  .pipe(
    z.string().min(GUILD_NAME_MIN).max(GUILD_NAME_MAX).regex(NAME_RE, { message: 'bad_chars' }),
  );

export const guildDescriptionSchema = z
  .string()
  .transform((s) => s.normalize('NFKC').trim())
  .pipe(z.string().max(GUILD_DESC_MAX));

/** Ключ уникальности названия: как у ника — регистр, разделители и похожие буквы не делают имя «другим». */
export const guildNameKey = (name: string): string => nicknameKey(name.replace(/'/g, ''));

/** Кто может управлять участником с ролью target: глава — любым, офицер — только рядовыми. */
export function canManage(actor: GuildRole, target: GuildRole): boolean {
  if (actor === 'leader') return target !== 'leader';
  if (actor === 'officer') return target === 'member';
  return false;
}

export const canHandleApplications = (role: GuildRole): boolean => role !== 'member';
