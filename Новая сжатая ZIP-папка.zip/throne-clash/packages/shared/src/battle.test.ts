import { describe, expect, it } from 'vitest';
import {
  BATTLE_ROUNDS,
  NO_ATTACK_BONUS,
  cargoOf,
  plunder,
  simulateBattle,
  siegeShare,
  splitCasualties,
  totalUnits,
  wallsBonus,
  type BattleSide,
  type UnitCounts,
} from './battle';

const side = (units: UnitCounts, over: Partial<BattleSide> = {}): BattleSide => ({
  units,
  attackBonus: NO_ATTACK_BONUS,
  defenseBonus: 0,
  ...over,
});

describe('simulateBattle', () => {
  it('детерминирован: одинаковый вход и seed → одинаковый результат', () => {
    const input = {
      attacker: side({ infantry_1: 120, archer_1: 60 }),
      defender: side({ infantry_1: 100, cavalry_1: 40 }),
      seed: 777,
    };
    expect(simulateBattle(input)).toEqual(simulateBattle(input));
  });

  it('не зависит от порядка ключей во входе', () => {
    const a = simulateBattle({
      attacker: side({ infantry_1: 100, archer_1: 50 }),
      defender: side({ cavalry_1: 80 }),
      seed: 5,
    });
    const b = simulateBattle({
      attacker: side({ archer_1: 50, infantry_1: 100 }),
      defender: side({ cavalry_1: 80 }),
      seed: 5,
    });
    expect(a).toEqual(b);
  });

  it('подавляющее превосходство побеждает; потери слабой стороны больше', () => {
    const r = simulateBattle({
      attacker: side({ infantry_3: 400 }),
      defender: side({ infantry_1: 50 }),
      seed: 1,
    });
    expect(r.winner).toBe('attacker');
    expect(totalUnits(r.defender.remaining)).toBe(0);
    expect(totalUnits(r.attacker.fallen)).toBeLessThan(totalUnits(r.defender.fallen));
  });

  it('пустая обороня: побеждает нападающий, при пустом нападении — обороняющийся', () => {
    expect(
      simulateBattle({ attacker: side({ infantry_1: 10 }), defender: side({}), seed: 1 }).winner,
    ).toBe('attacker');
    expect(
      simulateBattle({ attacker: side({}), defender: side({ infantry_1: 10 }), seed: 1 }).winner,
    ).toBe('defender');
  });

  it('сохранение численности: осталось + павших = было', () => {
    const r = simulateBattle({
      attacker: side({ infantry_2: 90, archer_2: 70 }),
      defender: side({ infantry_2: 80, cavalry_2: 60 }),
      seed: 9,
    });
    for (const o of [r.attacker, r.defender]) {
      for (const [id, n] of Object.entries(o.start)) {
        const key = id as keyof UnitCounts;
        expect((o.remaining[key] ?? 0) + (o.fallen[key] ?? 0)).toBe(n);
      }
    }
  });

  it('раундов не больше восьми; ничья по раундам — победа обороняющегося', () => {
    const r = simulateBattle({
      attacker: side({ infantry_1: 1000 }, {}),
      defender: side({ infantry_1: 1000 }),
      seed: 3,
    });
    expect(r.rounds.length).toBeLessThanOrEqual(BATTLE_ROUNDS);
    if (totalUnits(r.defender.remaining) > 0) expect(r.winner).toBe('defender');
  });

  it('камень-ножницы-бумага: пехота выигрывает у конницы, а конница у пехоты — нет', () => {
    const infantryVsCav = simulateBattle({
      attacker: side({ infantry_1: 100 }),
      defender: side({ cavalry_1: 100 }),
      seed: 4,
    });
    const cavVsInfantry = simulateBattle({
      attacker: side({ cavalry_1: 100 }),
      defender: side({ infantry_1: 100 }),
      seed: 4,
    });
    expect(totalUnits(infantryVsCav.defender.fallen)).toBeGreaterThan(
      totalUnits(cavVsInfantry.defender.fallen),
    );
  });

  it('бонусы работают: атака и защита меняют потери', () => {
    const base = {
      attacker: side({ infantry_1: 200 }),
      defender: side({ infantry_1: 200 }),
      seed: 12,
    };
    const plain = simulateBattle(base);
    const boostedAttack = simulateBattle({
      ...base,
      attacker: side({ infantry_1: 200 }, { attackBonus: { ...NO_ATTACK_BONUS, infantry: 0.5 } }),
    });
    const walled = simulateBattle({
      ...base,
      defender: side({ infantry_1: 200 }, { defenseBonus: 0.5 }),
    });
    expect(totalUnits(boostedAttack.defender.fallen)).toBeGreaterThan(
      totalUnits(plain.defender.fallen),
    );
    expect(totalUnits(walled.defender.fallen)).toBeLessThan(totalUnits(plain.defender.fallen));
  });

  it('игнорирует неизвестные ключи и нулевые количества', () => {
    const r = simulateBattle({
      attacker: side({ infantry_1: 0, ghost_9: 10 } as unknown as UnitCounts),
      defender: side({ infantry_1: 5 }),
      seed: 2,
    });
    expect(r.winner).toBe('defender');
  });
});

describe('стены, потери, добыча', () => {
  it('стены: 2% за уровень, с технологией сильнее, осада вдвое ослабляет их в пределе', () => {
    expect(wallsBonus(10, 0, 0)).toBeCloseTo(0.2, 10);
    expect(wallsBonus(10, 0.5, 0)).toBeCloseTo(0.3, 10);
    expect(wallsBonus(10, 0, 1)).toBeCloseTo(0.1, 10);
    expect(wallsBonus(10, 0, 5)).toBeCloseTo(0.1, 10);
    expect(wallsBonus(0, 0, 0)).toBe(0);
  });

  it('доля осадных', () => {
    expect(siegeShare({})).toBe(0);
    expect(siegeShare({ infantry_1: 60, siege_1: 40 })).toBeCloseTo(0.4, 10);
  });

  it('30% павших ранены в пределах госпиталя, остальные гибнут', () => {
    const c = splitCasualties({ infantry_1: 100, archer_1: 10 }, 1000);
    expect(c.wounded).toEqual({ archer_1: 3, infantry_1: 30 });
    expect(c.dead).toEqual({ archer_1: 7, infantry_1: 70 });
  });

  it('нехватка места в госпитале: лишние раненые гибнут', () => {
    const c = splitCasualties({ infantry_1: 100 }, 10);
    expect(c.wounded).toEqual({ infantry_1: 10 });
    expect(c.dead).toEqual({ infantry_1: 90 });
    expect(splitCasualties({ infantry_1: 100 }, 0).wounded).toEqual({});
  });

  it('груз считается по выжившим', () => {
    expect(cargoOf({})).toBe(0);
    expect(cargoOf({ infantry_1: 10 })).toBe(200);
    expect(cargoOf({ infantry_1: 10, cavalry_1: 5 })).toBe(400);
  });

  it('добыча: не больше 40% незащищённого и равной доли груза; защищённые 20% склада не трогаем', () => {
    const stored = { gold: 3000, wood: 1000, stone: 500, food: 100 };
    const caps = { gold: 3000, wood: 3000, stone: 3000, food: 3000 };
    // защищено 600; gold: (3000−600)·0.4 = 960; wood: 400·0.4 = 160; stone/food ниже защиты → 0
    expect(plunder(stored, caps, 100_000)).toEqual({ gold: 960, wood: 160, stone: 0, food: 0 });
    // груз 400 → по 100 на ресурс
    expect(plunder(stored, caps, 400)).toEqual({ gold: 100, wood: 100, stone: 0, food: 0 });
    expect(plunder(stored, caps, 0)).toEqual({ gold: 0, wood: 0, stone: 0, food: 0 });
  });
});
