import { describe, expect, it } from 'vitest';
import {
  leaguePoints,
  metricValue,
  placePrize,
  seasonEnd,
  seasonId,
  seasonStart,
  seasonStartOf,
} from './league';

describe('сезон: неделя с понедельника 00:00 UTC', () => {
  it('середина недели относится к понедельнику', () => {
    expect(seasonId(new Date('2026-03-11T12:00:00Z'))).toBe('2026-03-09');
    expect(seasonStart(new Date('2026-03-11T12:00:00Z')).toISOString()).toBe(
      '2026-03-09T00:00:00.000Z',
    );
  });

  it('границы: воскресенье 23:59:59 ещё старый сезон, понедельник 00:00:00 — новый', () => {
    expect(seasonId(new Date('2026-03-15T23:59:59Z'))).toBe('2026-03-09');
    expect(seasonId(new Date('2026-03-16T00:00:00Z'))).toBe('2026-03-16');
    expect(seasonId(new Date('2026-03-09T00:00:00Z'))).toBe('2026-03-09');
  });

  it('конец сезона — следующий понедельник', () => {
    expect(seasonEnd(new Date('2026-03-11T12:00:00Z')).toISOString()).toBe(
      '2026-03-16T00:00:00.000Z',
    );
  });

  it('переход через границу месяца и года', () => {
    expect(seasonId(new Date('2027-01-01T05:00:00Z'))).toBe('2026-12-28');
    expect(seasonEnd(new Date('2027-01-01T05:00:00Z')).toISOString()).toBe(
      '2027-01-04T00:00:00.000Z',
    );
  });

  it('разбор идентификатора', () => {
    expect(seasonStartOf('2026-03-09')?.toISOString()).toBe('2026-03-09T00:00:00.000Z');
    expect(seasonStartOf('garbage')).toBeNull();
    expect(seasonStartOf('2026-13-45')).toBeNull();
  });
});

describe('очки и призы', () => {
  it('очки = мощь/100 + 50·победы + убийства/10', () => {
    expect(leaguePoints({ power: 1000, wins: 2, kills: 30 })).toBe(10 + 100 + 3);
    expect(leaguePoints({ power: 99, wins: 0, kills: 0 })).toBe(0);
  });

  it('значение метрики', () => {
    const v = { power: 5000, wins: 3, kills: 40 };
    expect(metricValue('points', v)).toBe(leaguePoints(v));
    expect(metricValue('power', v)).toBe(5000);
    expect(metricValue('wins', v)).toBe(3);
    expect(metricValue('kills', v)).toBe(40);
  });

  it('призы по местам', () => {
    expect(placePrize(1)).toEqual({ gems: 100, chest: 'gold' });
    expect(placePrize(2)).toEqual({ gems: 50, chest: 'silver' });
    expect(placePrize(10)).toEqual({ gems: 50, chest: 'silver' });
    expect(placePrize(11)).toEqual({ gems: 20, chest: null });
    expect(placePrize(100)).toEqual({ gems: 20, chest: null });
    expect(placePrize(101)).toEqual({ gems: 0, chest: null });
  });
});
