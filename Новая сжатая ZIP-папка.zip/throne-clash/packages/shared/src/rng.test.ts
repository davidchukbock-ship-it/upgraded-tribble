import { describe, expect, it } from 'vitest';
import { hashSeed, mulberry32 } from './rng';

describe('mulberry32', () => {
  it('один seed → одна последовательность', () => {
    const a = mulberry32(42);
    const b = mulberry32(42);
    expect(Array.from({ length: 5 }, a)).toEqual(Array.from({ length: 5 }, b));
  });
  it('разные seed → разные последовательности', () => {
    expect(mulberry32(1)()).not.toBe(mulberry32(2)());
  });
  it('значения в [0, 1)', () => {
    const r = mulberry32(7);
    for (let i = 0; i < 1000; i++) {
      const v = r();
      expect(v).toBeGreaterThanOrEqual(0);
      expect(v).toBeLessThan(1);
    }
  });
  it('распределение примерно равномерное', () => {
    const r = mulberry32(2026);
    const n = 20000;
    let sum = 0;
    for (let i = 0; i < n; i++) sum += r();
    expect(sum / n).toBeGreaterThan(0.48);
    expect(sum / n).toBeLessThan(0.52);
  });
});

describe('hashSeed', () => {
  it('стабилен и различает строки', () => {
    expect(hashSeed('main')).toBe(hashSeed('main'));
    expect(hashSeed('main')).not.toBe(hashSeed('sandbox'));
    expect(hashSeed('')).toBeTypeOf('number');
  });
});
