import { BUILDING_KEYS } from './constants';
import { parseUnitId, unitStats, type Army } from './army';
import type { BuildingLevels } from './economy';
import { TECH_KEYS, type TechLevels } from './research';

/**
 * Мощь (docs/GAME_DESIGN.md §4): Σ юниты · (атака + защита + здоровье/10) + Σ уровни зданий · 100
 * + Σ уровни технологий · 50 + уровень героя · 200. Войска в походах тоже считаются (передаются в `marching`).
 */
export function unitPower(unitId: string): number {
  const p = parseUnitId(unitId);
  if (!p) return 0;
  const s = unitStats(p.type, p.tier);
  return s.atk + s.def + s.hp / 10;
}

export function castlePower(input: {
  army: Army;
  marching?: Partial<Record<string, number>>;
  levels: BuildingLevels;
  tech: TechLevels;
  heroLevel: number;
}): number {
  let power = 0;
  const add = (id: string, n: number) => {
    power += n * unitPower(id);
  };
  for (const [id, s] of Object.entries(input.army)) if (s) add(id, s.count + s.wounded);
  for (const [id, n] of Object.entries(input.marching ?? {})) add(id, n ?? 0);
  for (const k of BUILDING_KEYS) power += (input.levels[k] ?? 0) * 100;
  for (const k of TECH_KEYS) power += (input.tech[k] ?? 0) * 50;
  power += Math.max(0, input.heroLevel) * 200;
  return Math.round(power);
}
