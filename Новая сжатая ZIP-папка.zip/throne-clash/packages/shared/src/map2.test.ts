import { describe, expect, it } from 'vitest';
import { MAP_SIZE } from './constants';
import { MAP_CENTER, isPassableTerrain } from './map';
import {
  ROAD_COST,
  cellAt2,
  hash01,
  regionCapital,
  regionOf,
  roadCells2,
  stepCost,
  terrainAt2,
} from './map2';
import { cellAtV, pickCastleSpotV } from './world-map';

const SEEDS = [20260101, 7, 123456, 99999, 31337, 2024, 1, 2];

describe('карта v2 (D-74)', () => {
  it('хеш детерминирован и лежит в [0, 1)', () => {
    expect(hash01(5, 10, 20, 3)).toBe(hash01(5, 10, 20, 3));
    expect(hash01(5, 10, 20, 3)).not.toBe(hash01(5, 10, 20, 4));
    for (let i = 0; i < 500; i++) {
      const v = hash01(i, i * 7, i * 13, 9);
      expect(v).toBeGreaterThanOrEqual(0);
      expect(v).toBeLessThan(1);
    }
  });

  it('одна и та же клетка при одном seed, разные миры — разные', () => {
    for (let i = 0; i < 200; i++) {
      const x = (i * 37) % MAP_SIZE;
      const y = (i * 91) % MAP_SIZE;
      expect(cellAt2(42, x, y)).toEqual(cellAt2(42, x, y));
    }
    let diff = 0;
    for (let i = 0; i < 400; i++) {
      const x = (i * 37) % MAP_SIZE;
      const y = (i * 91) % MAP_SIZE;
      if (terrainAt2(1, x, y) !== terrainAt2(2, x, y)) diff++;
    }
    expect(diff).toBeGreaterThan(40);
  });

  it('в каждом мире есть суша, море и несколько видов рельефа; центр — ровная суша', () => {
    for (const seed of SEEDS) {
      const seen = new Set<string>();
      let land = 0;
      let total = 0;
      for (let y = 0; y < MAP_SIZE; y += 4)
        for (let x = 0; x < MAP_SIZE; x += 4) {
          const t = terrainAt2(seed, x, y);
          seen.add(t);
          total++;
          if (isPassableTerrain(t)) land++;
        }
      expect(land / total, `seed ${seed}: доля суши`).toBeGreaterThan(0.3);
      expect(land / total, `seed ${seed}: доля суши`).toBeLessThan(0.8);
      expect(seen.has('sea'), `seed ${seed}: море`).toBe(true);
      expect(seen.size, `seed ${seed}: видов рельефа`).toBeGreaterThanOrEqual(4);
      for (let dy = -8; dy <= 8; dy++)
        for (let dx = -8; dx <= 8; dx++) {
          const t = terrainAt2(seed, MAP_CENTER.x + dx, MAP_CENTER.y + dy);
          expect(['plain', 'forest', 'river']).toContain(t);
        }
    }
  });

  it('новые замки находят место у центра на обеих версиях; занятые клетки обходятся', () => {
    const first = pickCastleSpotV(2, 20260101, []);
    expect(first).not.toBeNull();
    expect(Math.hypot(first!.x - MAP_CENTER.x, first!.y - MAP_CENTER.y)).toBeLessThan(5);
    const cell = cellAtV(2, 20260101, first!.x, first!.y);
    expect(isPassableTerrain(cell.terrain)).toBe(true);
    expect(cell.kind).toBe('empty');
    const second = pickCastleSpotV(2, 20260101, [first!]);
    expect(second).not.toEqual(first);
  });

  it('дороги: есть, не на море, соединяют столицы регионов; по дороге идут быстрее', () => {
    for (const seed of SEEDS) {
      const roads = roadCells2(seed);
      expect(roads.size, `seed ${seed}`).toBeGreaterThan(200);
      for (const key of roads) {
        const x = key % MAP_SIZE;
        const y = Math.floor(key / MAP_SIZE);
        expect(terrainAt2(seed, x, y)).not.toBe('sea');
        expect(cellAt2(seed, x, y).road).toBe(true);
      }
    }
    const seed = 20260101;
    const cap = regionCapital(seed, regionOf(MAP_CENTER.x, MAP_CENTER.y))!;
    expect(cap).not.toBeNull();
    const sample = [...roadCells2(seed)][10]!;
    const cell = cellAt2(seed, sample % MAP_SIZE, Math.floor(sample / MAP_SIZE));
    expect(stepCost(cell)).toBe(ROAD_COST);
    expect(stepCost({ terrain: 'swamp' })).toBeGreaterThan(stepCost({ terrain: 'plain' })!);
    expect(stepCost({ terrain: 'mountain' })).toBeNull();
    expect(stepCost({ terrain: 'sea' })).toBeNull();
  });

  it('ресурсные точки и лагеря стоят только на свободной суше вне дорог', () => {
    let res = 0;
    let camps = 0;
    for (let y = 0; y < MAP_SIZE; y += 2)
      for (let x = 0; x < MAP_SIZE; x += 2) {
        const c = cellAt2(123456, x, y);
        if (c.kind === 'empty') continue;
        expect(isPassableTerrain(c.terrain)).toBe(true);
        expect(c.road).toBeUndefined();
        if (c.kind === 'resource') {
          res++;
          expect(c.resource).not.toBeNull();
          expect(c.level).toBeGreaterThanOrEqual(1);
        } else {
          camps++;
          expect(c.level).toBeLessThanOrEqual(10);
        }
      }
    expect(res).toBeGreaterThan(50);
    expect(camps).toBeGreaterThan(20);
  });

  it('генерация всего мира укладывается в разумное время', () => {
    const t0 = performance.now();
    for (let y = 0; y < MAP_SIZE; y++) for (let x = 0; x < MAP_SIZE; x++) cellAt2(9, x, y);
    expect(performance.now() - t0).toBeLessThan(3000);
  });
});
