import type { ResourceKey, UnitType } from './constants';
import { ATTACK_MULT, parseUnitId, unitStats, type UnitId } from './army';
import { lootableAmount, type ResourceAmounts } from './economy';
import { mulberry32 } from './rng';

/**
 * Бой (docs/GAME_DESIGN.md §4). Детерминирован: тот же вход и seed дают тот же результат.
 * Обе стороны бьют одновременно; раундов не больше BATTLE_ROUNDS.
 */

export const BATTLE_ROUNDS = 8;
/** Доля павших, которые могут выжить ранеными (в пределах Госпиталя). */
export const WOUNDED_SHARE = 0.3;
export const LOOT_SHARE = 0.4;
export const WALLS_PER_LEVEL = 0.02;

export type UnitCounts = Partial<Record<UnitId, number>>;

export interface BattleSide {
  units: UnitCounts;
  /** Прибавка к атаке по типам войск (Кузница, технологии, герой), доля. */
  attackBonus: Readonly<Record<UnitType, number>>;
  /** Прибавка к защите (технологии, герой, у обороняющегося ещё Стены), доля. */
  defenseBonus: number;
}

export interface RoundLog {
  round: number;
  attackerLosses: number;
  defenderLosses: number;
  attackerAlive: number;
  defenderAlive: number;
}

export interface SideOutcome {
  start: UnitCounts;
  remaining: UnitCounts;
  /** Павшие юниты (будущие погибшие + раненые). */
  fallen: UnitCounts;
}

export interface BattleResult {
  winner: 'attacker' | 'defender';
  rounds: RoundLog[];
  attacker: SideOutcome;
  defender: SideOutcome;
}

export const NO_ATTACK_BONUS: Readonly<Record<UnitType, number>> = {
  infantry: 0,
  archer: 0,
  cavalry: 0,
  siege: 0,
};

export const totalUnits = (u: UnitCounts): number =>
  Object.values(u).reduce((s, n) => s + (n ?? 0), 0);

interface Group {
  id: UnitId;
  type: UnitType;
  atk: number;
  def: number;
  hp: number;
  count: number;
}

function toGroups(units: UnitCounts): Group[] {
  const groups: Group[] = [];
  for (const [id, count] of Object.entries(units)) {
    const parsed = parseUnitId(id);
    if (!parsed || !count || count <= 0) continue;
    const s = unitStats(parsed.type, parsed.tier);
    groups.push({
      id: id as UnitId,
      type: parsed.type,
      atk: s.atk,
      def: s.def,
      hp: s.hp,
      count: Math.floor(count),
    });
  }
  // Порядок фиксируем: результат не должен зависеть от порядка ключей во входе
  return groups.sort((a, b) => (a.id < b.id ? -1 : 1));
}

/** Потери каждой группы цели за раунд от атакующей стороны. */
function roundLosses(
  attackers: readonly Group[],
  targets: readonly Group[],
  attackBonus: Readonly<Record<UnitType, number>>,
  targetDefenseBonus: number,
  jitter: number,
): number[] {
  const targetHp = targets.reduce((s, g) => s + g.count * g.hp, 0);
  if (targetHp <= 0) return targets.map(() => 0);
  return targets.map((g) => {
    if (g.count <= 0) return 0;
    const hpShare = (g.count * g.hp) / targetHp;
    let dmg = 0;
    for (const a of attackers) {
      if (a.count <= 0) continue;
      const power = a.count * a.atk * (1 + attackBonus[a.type]) * jitter;
      dmg +=
        (power * ATTACK_MULT[a.type][g.type] * hpShare * 100) /
        (100 + g.def * (1 + targetDefenseBonus));
    }
    return Math.min(g.count, Math.floor(dmg / g.hp));
  });
}

export function simulateBattle(input: {
  attacker: BattleSide;
  defender: BattleSide;
  seed: number;
}): BattleResult {
  const rng = mulberry32(input.seed);
  const att = toGroups(input.attacker.units);
  const def = toGroups(input.defender.units);
  const attStart = Object.fromEntries(att.map((g) => [g.id, g.count])) as UnitCounts;
  const defStart = Object.fromEntries(def.map((g) => [g.id, g.count])) as UnitCounts;
  const alive = (gs: readonly Group[]): number => gs.reduce((s, g) => s + g.count, 0);
  const rounds: RoundLog[] = [];

  for (let round = 1; round <= BATTLE_ROUNDS && alive(att) > 0 && alive(def) > 0; round++) {
    const jitterA = 0.95 + 0.1 * rng();
    const jitterD = 0.95 + 0.1 * rng();
    const lossOnDef = roundLosses(
      att,
      def,
      input.attacker.attackBonus,
      input.defender.defenseBonus,
      jitterA,
    );
    const lossOnAtt = roundLosses(
      def,
      att,
      input.defender.attackBonus,
      input.attacker.defenseBonus,
      jitterD,
    );
    def.forEach((g, i) => (g.count -= lossOnDef[i] ?? 0));
    att.forEach((g, i) => (g.count -= lossOnAtt[i] ?? 0));
    rounds.push({
      round,
      attackerLosses: lossOnAtt.reduce((s, n) => s + n, 0),
      defenderLosses: lossOnDef.reduce((s, n) => s + n, 0),
      attackerAlive: alive(att),
      defenderAlive: alive(def),
    });
  }

  const outcome = (start: UnitCounts, groups: readonly Group[]): SideOutcome => {
    const remaining: UnitCounts = {};
    const fallen: UnitCounts = {};
    for (const g of groups) {
      if (g.count > 0) remaining[g.id] = g.count;
      const lost = (start[g.id] ?? 0) - g.count;
      if (lost > 0) fallen[g.id] = lost;
    }
    return { start, remaining, fallen };
  };
  const attacker = outcome(attStart, att);
  const defender = outcome(defStart, def);
  // Побеждает тот, у кого остались юниты; если остались обе стороны (или ни одной) — обороняющийся
  const winner = alive(def) === 0 && alive(att) > 0 ? 'attacker' : 'defender';
  return { winner, rounds, attacker, defender };
}

/** Бонус Стен обороняющегося: 2% за уровень, слабее против осады (до −50% при одних осадных). */
export function wallsBonus(level: number, techWalls: number, siegeShare: number): number {
  const s = Math.min(1, Math.max(0, siegeShare));
  return WALLS_PER_LEVEL * level * (1 + techWalls) * (1 - 0.5 * s);
}

/**
 * Бонус оборонительных башен (D-61): Башня лучников — стабильная защита; Баллиста-башня сильна против
 * конницы (по доле конницы в войске нападающего); Башня бурь — магия, которой осада почти не мешает.
 * Итог ограничен +60%.
 */
export const TOWER_CAP = 0.6;
export function towersBonus(
  levels: { archertower?: number; ballistatower?: number; stormtower?: number },
  cavalryShare: number,
  siegeShareValue = 0,
): number {
  const c = Math.min(1, Math.max(0, cavalryShare));
  const s = Math.min(1, Math.max(0, siegeShareValue));
  const archer = 0.01 * (levels.archertower ?? 0) * (1 - 0.3 * s);
  const ballista = 0.016 * (levels.ballistatower ?? 0) * c;
  const storm = 0.009 * (levels.stormtower ?? 0);
  return Math.min(TOWER_CAP, archer + ballista + storm);
}

export function cavalryShare(units: UnitCounts): number {
  const total = totalUnits(units);
  if (total === 0) return 0;
  let cav = 0;
  for (const [id, n] of Object.entries(units)) {
    if (parseUnitId(id)?.type === 'cavalry') cav += n ?? 0;
  }
  return cav / total;
}

export function siegeShare(units: UnitCounts): number {
  const total = totalUnits(units);
  if (total === 0) return 0;
  let siege = 0;
  for (const [id, n] of Object.entries(units)) {
    if (parseUnitId(id)?.type === 'siege') siege += n ?? 0;
  }
  return siege / total;
}

export interface Casualties {
  dead: UnitCounts;
  wounded: UnitCounts;
}

/** Из павших 70% гибнут, 30% ранены — но не больше свободного места в Госпитале (лишние гибнут). */
export function splitCasualties(fallen: UnitCounts, woundedRoom: number): Casualties {
  const dead: UnitCounts = {};
  const wounded: UnitCounts = {};
  let room = Math.max(0, Math.floor(woundedRoom));
  for (const id of Object.keys(fallen).sort()) {
    const n = fallen[id as UnitId] ?? 0;
    const w = Math.min(Math.floor(n * WOUNDED_SHARE), room);
    room -= w;
    if (w > 0) wounded[id as UnitId] = w;
    if (n - w > 0) dead[id as UnitId] = n - w;
  }
  return { dead, wounded };
}

export const cargoOf = (units: UnitCounts): number => {
  let total = 0;
  for (const [id, n] of Object.entries(units)) {
    const p = parseUnitId(id);
    if (p && n) total += n * unitStats(p.type, p.tier).cargo;
  }
  return total;
};

/**
 * Добыча нападающего: с каждого ресурса не больше 40% незащищённого запаса и равной доли груза.
 * Защищена часть запаса, равная 20% ёмкости склада.
 */
export function plunder(
  stored: ResourceAmounts,
  caps: ResourceAmounts,
  cargo: number,
): ResourceAmounts {
  const keys = Object.keys(stored) as ResourceKey[];
  const share = Math.floor(Math.max(0, cargo) / keys.length);
  const loot = { gold: 0, wood: 0, stone: 0, food: 0 } as ResourceAmounts;
  for (const k of keys) {
    loot[k] = Math.min(Math.floor(lootableAmount(stored[k], caps[k]) * LOOT_SHARE), share);
  }
  return loot;
}
