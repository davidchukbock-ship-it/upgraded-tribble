import { describe, expect, it } from 'vitest';
import { MAX_HERO_LEVEL } from './constants';
import {
  addHeroXp,
  heroBonuses,
  heroSkillPoints,
  heroTrainCost,
  heroXpToNext,
  newHero,
  type HeroState,
} from './hero';

const hero = (over: Partial<HeroState> = {}): HeroState => ({ ...newHero(), ...over });

describe('герой (GAME_DESIGN §8)', () => {
  it('опыт до следующего уровня: round(100·L^1.6)', () => {
    expect([1, 2, 10].map(heroXpToNext)).toEqual([100, 303, 3981]);
  });
  it('очки навыков: одно за уровень минус потраченные', () => {
    expect(heroSkillPoints(newHero())).toBe(1);
    expect(heroSkillPoints(hero({ level: 5, skills: { combat: 2, defense: 1, economy: 0 } }))).toBe(
      2,
    );
  });

  describe('addHeroXp', () => {
    it('копит опыт внутри уровня', () => expect(addHeroXp(1, 0, 60)).toEqual({ level: 1, xp: 60 }));
    it('переносит остаток и проходит несколько уровней за раз', () => {
      const r = addHeroXp(1, 0, 100 + 303 + 50);
      expect(r).toEqual({ level: 3, xp: 50 });
    });
    it('отрицательное и дробное начисление безопасно', () => {
      expect(addHeroXp(2, 10, -500)).toEqual({ level: 2, xp: 10 });
      expect(addHeroXp(2, 10, 5.9)).toEqual({ level: 2, xp: 15 });
    });
    it('на максимальном уровне опыт не копится', () => {
      expect(addHeroXp(MAX_HERO_LEVEL, 0, 1e9)).toEqual({ level: MAX_HERO_LEVEL, xp: 0 });
      expect(addHeroXp(MAX_HERO_LEVEL - 1, 0, 1e9).level).toBe(MAX_HERO_LEVEL);
    });
  });

  describe('heroBonuses', () => {
    it('новый герой без бонусов', () => {
      expect(heroBonuses(newHero())).toEqual({ attack: 0, defense: 0, production: 0 });
    });
    it('навыки, уровень и надетые предметы складываются', () => {
      const h = hero({
        level: 11,
        skills: { combat: 3, defense: 1, economy: 5 },
        items: [
          { id: 'w', slot: 'weapon', rarity: 4, equipped: true },
          { id: 'a', slot: 'armor', rarity: 5, equipped: false }, // в сумке — не считается
          { id: 'r', slot: 'relic', rarity: 2, equipped: true },
        ],
      });
      const b = heroBonuses(h);
      expect(b.attack).toBeCloseTo(3 * 0.02 + 10 * 0.005 + 4 * 0.015);
      expect(b.defense).toBeCloseTo(1 * 0.02 + 10 * 0.005);
      expect(b.production).toBeCloseTo(5 * 0.03 + 2 * 0.015);
    });
  });

  it('плата за тренировку растёт с уровнем', () => {
    expect(heroTrainCost(1)).toEqual({ gold: 100, wood: 0, stone: 0, food: 50 });
    expect(heroTrainCost(10).gold).toBe(1000);
  });
});
