import { mulberry32 } from './rng';
import { UNIT_TYPES, type UnitType } from './constants';
import { simulateBattle, type BattleResult, type UnitCounts } from './battle';
import { unitId } from './army';

/**
 * Одиночная «Арена» (D-67): волны противников на разных локациях, без сервера и без влияния на экономику.
 * Бой считается тем же детерминированным движком, что и настоящие походы, поэтому баланс единый.
 */
export const ARENA_LOCATIONS = ['meadow', 'forest', 'ruins', 'snow', 'volcano'] as const;
export type ArenaLocation = (typeof ARENA_LOCATIONS)[number];

/** Локация усиливает и ослабляет типы войск у обеих сторон (доля к атаке) и даёт прибавку к защите. */
export const LOCATION_MODS: Readonly<
  Record<ArenaLocation, { attack: Readonly<Record<UnitType, number>>; defense: number }>
> = {
  meadow: { attack: { infantry: 0, archer: 0, cavalry: 0.15, siege: 0 }, defense: 0 },
  forest: { attack: { infantry: 0, archer: 0.25, cavalry: -0.2, siege: -0.1 }, defense: 0.05 },
  ruins: { attack: { infantry: 0.15, archer: 0, cavalry: -0.1, siege: 0.1 }, defense: 0.1 },
  snow: { attack: { infantry: 0.1, archer: -0.1, cavalry: -0.25, siege: -0.1 }, defense: 0.05 },
  volcano: { attack: { infantry: -0.1, archer: -0.15, cavalry: 0, siege: 0.3 }, defense: 0 },
};

/** В отряде-«пачке» столько бойцов; уровень войск на арене одинаковый. */
export const ARENA_PACK = 10;
export const ARENA_TIER = 2;
export const PACK_COST: Readonly<Record<UnitType, number>> = {
  infantry: 1,
  archer: 1,
  cavalry: 2,
  siege: 3,
};

export type Packs = Record<UnitType, number>;
export const emptyPacks = (): Packs => ({ infantry: 0, archer: 0, cavalry: 0, siege: 0 });

/** Очки командования на волне: первая волна скромная, дальше растут. */
export const budgetFor = (wave: number): number => 6 + 2 * Math.max(1, wave);

export const spent = (p: Packs): number => UNIT_TYPES.reduce((s, t) => s + p[t] * PACK_COST[t], 0);

export function packsToUnits(p: Packs): UnitCounts {
  const out: UnitCounts = {};
  for (const t of UNIT_TYPES) if (p[t] > 0) out[unitId(t, ARENA_TIER)] = p[t] * ARENA_PACK;
  return out;
}

/** Противник волны: случайный состав на нескольких очках; чем дальше волна, тем он крепче. */
export function enemyPacks(wave: number, seed: number): Packs {
  const rng = mulberry32(seed * 7919 + wave);
  const strength = Math.min(1.5, 0.5 + 0.045 * wave);
  let points = Math.round(budgetFor(wave) * strength);
  const p = emptyPacks();
  // Состав задают весами: пехота и лучники чаще, осада реже
  const bag: UnitType[] = ['infantry', 'infantry', 'archer', 'archer', 'cavalry', 'siege'];
  while (points > 0) {
    const t = bag[Math.floor(rng() * bag.length)]!;
    if (PACK_COST[t] > points) {
      if (points >= 1) {
        p.infantry += 1;
        points -= 1;
      }
      continue;
    }
    p[t] += 1;
    points -= PACK_COST[t];
  }
  return p;
}

export function fightArena(input: {
  mine: Packs;
  wave: number;
  location: ArenaLocation;
  seed: number;
}): { result: BattleResult; enemy: Packs; won: boolean } {
  const m = LOCATION_MODS[input.location];
  const enemy = enemyPacks(input.wave, input.seed);
  const result = simulateBattle({
    attacker: { units: packsToUnits(input.mine), attackBonus: m.attack, defenseBonus: m.defense },
    defender: { units: packsToUnits(enemy), attackBonus: m.attack, defenseBonus: m.defense },
    seed: input.seed * 31 + input.wave,
  });
  return { result, enemy, won: result.winner === 'attacker' };
}
