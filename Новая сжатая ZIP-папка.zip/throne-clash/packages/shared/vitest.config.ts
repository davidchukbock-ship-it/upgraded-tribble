import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    include: ['src/**/*.test.ts'],
    coverage: {
      provider: 'v8',
      include: ['src/**/*.ts'],
      exclude: ['src/**/*.test.ts', 'src/index.ts'],
      // Порог для ядра (D-15): сборка падает, если формулы недопокрыты
      thresholds: { lines: 80, functions: 80, branches: 80, statements: 80 },
    },
  },
});
