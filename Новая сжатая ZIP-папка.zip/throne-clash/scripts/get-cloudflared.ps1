# Скачивает cloudflared.exe (публичная ссылка на игру) в %USERPROFILE%\tc-tools — без установщика.
$ErrorActionPreference = 'Stop'
$dir = Join-Path $env:USERPROFILE 'tc-tools'
New-Item -ItemType Directory -Force $dir | Out-Null
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Write-Host 'Downloading cloudflared ...'
Invoke-WebRequest 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe' -OutFile (Join-Path $dir 'cloudflared.exe')
Write-Host "cloudflared saved to $dir"
