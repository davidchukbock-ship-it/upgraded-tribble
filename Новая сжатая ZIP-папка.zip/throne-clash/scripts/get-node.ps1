# Скачивает портативный Node.js (zip, без MSI и без прав администратора) в %USERPROFILE%\node-portable.
$ErrorActionPreference = 'Stop'
$v = '22.11.0'
$target = Join-Path $env:USERPROFILE 'node-portable'
$zip = Join-Path $env:TEMP "node-$v.zip"
$tmp = Join-Path $env:TEMP "node-$v-unpacked"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Write-Host "Downloading Node.js $v ..."
Invoke-WebRequest "https://nodejs.org/dist/v$v/node-v$v-win-x64.zip" -OutFile $zip
if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
Expand-Archive $zip $tmp -Force
if (Test-Path $target) { Remove-Item $target -Recurse -Force }
Move-Item (Join-Path $tmp "node-v$v-win-x64") $target
Remove-Item $zip -Force
Write-Host "Node.js unpacked to $target"
