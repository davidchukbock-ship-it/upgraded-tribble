#!/usr/bin/env node
// Сборка и запуск игры на Node.js-хостинге с MySQL (Hostinger и подобные). Подробно — docs/HOSTINGER.md.
//   node scripts/hostinger.mjs build   — схема и клиент Prisma под MySQL, сборка сайта и сервера
//   node scripts/hostinger.mjs start   — миграции MySQL и запуск сервера, который сам отдаёт сайт
import { execSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import { delimiter, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const server = join(root, 'apps', 'server');
const run = (cmd, cwd = root, env = {}) => {
  console.log(`\n▶ ${cmd}`);
  // В PATH первой идёт папка текущего node: на хостинге «node» и «npx» дочерних команд должны быть те же
  const PATH = `${dirname(process.execPath)}${delimiter}${process.env.PATH ?? ''}`;
  execSync(cmd, { cwd, stdio: 'inherit', env: { ...process.env, PATH, ...env } });
};
const hasPnpm = () => {
  try {
    execSync('pnpm --version', { stdio: 'ignore' });
    return true;
  } catch {
    return false;
  }
};
const pnpm = process.env.PNPM_CMD ?? (hasPnpm() ? 'pnpm' : 'npx -y pnpm@10.33.0');
const schema = '--schema prisma/mysql/schema.prisma';

const mode = process.argv[2];
if (mode === 'build') {
  run('node scripts/gen-mysql-schema.mjs', server);
  // Для generate адрес БД не нужен, но Prisma требует, чтобы переменная была задана
  run(`${pnpm} exec prisma generate ${schema}`, server, {
    DATABASE_URL: process.env.DATABASE_URL ?? 'mysql://u:p@localhost:3306/x',
  });
  run(`${pnpm} -r build`);
  if (!existsSync(join(root, 'apps', 'web', 'dist', 'index.html'))) {
    console.error('Сайт не собрался: нет apps/web/dist/index.html');
    process.exit(1);
  }
  console.log('\n✅ Сборка готова');
} else if (mode === 'start') {
  if (!process.env.DATABASE_URL?.startsWith('mysql:')) {
    console.error('Задайте DATABASE_URL вида mysql://пользователь:пароль@хост:3306/база');
    process.exit(1);
  }
  // Клиент Prisma под MySQL создаётся и здесь: так запуск работает, даже если сборка шла обычной командой `build`
  run('node scripts/gen-mysql-schema.mjs', server);
  run(`${pnpm} exec prisma generate ${schema}`, server);
  run(`${pnpm} exec prisma migrate deploy ${schema}`, server);
  // Хостинг может запустить приложение без отдельного шага сборки — тогда собираем здесь
  if (
    !existsSync(join(server, 'dist', 'main.js')) ||
    !existsSync(join(root, 'apps', 'web', 'dist', 'index.html'))
  ) {
    console.log('Сборки нет — собираю проект при запуске');
    run(`${pnpm} -r build`);
  }
  process.env.WEB_DIST ??= join(root, 'apps', 'web', 'dist');
  process.env.NODE_ENV ??= 'production';
  process.env.REDIS_URL ??= 'none';
  await import(join(server, 'dist', 'main.js'));
} else {
  console.error('Использование: node scripts/hostinger.mjs build|start');
  process.exit(1);
}
