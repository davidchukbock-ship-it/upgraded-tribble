#!/usr/bin/env bash
# Установка «Битвы за трон» на сервер одной командой (Ubuntu/Debian, нужен root или sudo).
#   ./scripts/install.sh game.example.com [owner@mail.com]
# Что делает: ставит Docker (если нет), создаёт .env с случайными секретами, открывает порты 80/443,
# проверяет, что домен указывает на этот сервер, собирает и запускает игру с HTTPS.
# Повторный запуск безопасен: существующий .env и пароли не перезаписываются.
#   --env-only   только создать .env и выйти (для проверки)
set -euo pipefail

ENV_ONLY=0
ARGS=()
for a in "$@"; do
  case "$a" in
    --env-only) ENV_ONLY=1 ;;
    *) ARGS+=("$a") ;;
  esac
done
DOMAIN="${ARGS[0]:-}"
OWNER="${ARGS[1]:-}"

cd "$(dirname "${BASH_SOURCE[0]}")/.."
SUDO=""
[ "$(id -u)" -ne 0 ] && SUDO="sudo"

say() { printf '\n\033[1;33m▶ %s\033[0m\n' "$*"; }
die() { printf '\n\033[1;31m✖ %s\033[0m\n' "$*" >&2; exit 1; }

if [ -z "$DOMAIN" ]; then
  read -r -p "Ваш домен (например game.example.com, без https://): " DOMAIN
fi
DOMAIN="$(printf "%s" "$DOMAIN" | tr "[:upper:]" "[:lower:]")"
DOMAIN="${DOMAIN#http://}"; DOMAIN="${DOMAIN#https://}"; DOMAIN="${DOMAIN%/}"
[ -n "$DOMAIN" ] || die "Домен не указан"
if [ -z "$OWNER" ] && [ -t 0 ] && [ ! -f .env ]; then
  read -r -p "Ваш e-mail (будущий владелец игры, можно пропустить): " OWNER || true
fi

rand() { openssl rand -hex "$1" 2>/dev/null || head -c "$1" /dev/urandom | od -An -tx1 | tr -d ' \n'; }

# Записывает KEY=VALUE в .env: заменяет строку (в том числе закомментированную) или добавляет новую
set_var() {
  local key="$1" val="$2"
  if grep -qE "^#? ?${key}=" .env; then
    sed -i -E "s|^#? ?${key}=.*|${key}=${val}|" .env
  else
    printf '%s=%s\n' "$key" "$val" >> .env
  fi
}
get_var() { grep -E "^${1}=" .env | head -1 | cut -d= -f2-; }

say "Готовлю настройки (.env)"
if [ ! -f .env ]; then
  cp .env.example .env
  set_var JWT_ACCESS_SECRET "$(rand 32)"
  set_var POSTGRES_PASSWORD "$(rand 16)"
  set_var WORLD_SEED "$(( (RANDOM * 32768 + RANDOM) % 900000000 + 100000000 ))"
  echo "Создан новый .env со случайными секретами."
else
  echo "Найден готовый .env — секреты не трогаю."
fi
set_var NODE_ENV production
set_var DOMAIN "$DOMAIN"
[ -n "$OWNER" ] && set_var OWNER_EMAIL "$OWNER"
chmod 600 .env
[ "$ENV_ONLY" -eq 1 ] && { echo ".env готов."; exit 0; }

if ! command -v docker >/dev/null 2>&1; then
  say "Ставлю Docker"
  curl -fsSL https://get.docker.com | $SUDO sh
fi
docker compose version >/dev/null 2>&1 || die "Не найден «docker compose». Обновите Docker."

# Мало памяти — сборка может упасть: добавляем файл подкачки
MEM_MB=$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)
if [ "$MEM_MB" -lt 1800 ] && ! swapon --show | grep -q .; then
  say "Памяти мало (${MEM_MB} МБ) — добавляю подкачку 2 ГБ"
  $SUDO fallocate -l 2G /swapfile && $SUDO chmod 600 /swapfile && $SUDO mkswap /swapfile >/dev/null && $SUDO swapon /swapfile || true
fi

say "Открываю порты 80 и 443"
if command -v ufw >/dev/null 2>&1 && $SUDO ufw status | grep -q "Status: active"; then
  $SUDO ufw allow 80/tcp >/dev/null; $SUDO ufw allow 443/tcp >/dev/null
fi
# В образах Oracle Cloud порты закрыты правилами iptables — добавляем разрешения (если iptables есть)
if command -v iptables >/dev/null 2>&1; then
  for p in 80 443; do
    $SUDO iptables -C INPUT -p tcp --dport "$p" -j ACCEPT 2>/dev/null || $SUDO iptables -I INPUT 1 -p tcp --dport "$p" -j ACCEPT || true
  done
  command -v netfilter-persistent >/dev/null 2>&1 && $SUDO netfilter-persistent save >/dev/null 2>&1 || true
fi

say "Проверяю, что домен указывает на этот сервер"
MYIP="$(curl -fsS https://api.ipify.org 2>/dev/null || true)"
DOMIP="$(getent hosts "$DOMAIN" 2>/dev/null | awk '{print $1; exit}' || true)"
if [ -n "$MYIP" ] && [ "$MYIP" = "$DOMIP" ]; then
  echo "Всё верно: $DOMAIN → $MYIP"
else
  printf '\033[1;31m⚠ Домен %s сейчас указывает на «%s», а IP этого сервера «%s».\033[0m\n' "$DOMAIN" "${DOMIP:-ничего}" "${MYIP:-неизвестен}"
  echo "Создайте у регистратора A-запись $DOMAIN → ${MYIP:-IP сервера}. HTTPS заработает, когда запись обновится (до часа)."
fi

COMPOSE="$SUDO docker compose -f docker-compose.yml -f docker-compose.prod.yml"
say "Собираю и запускаю игру (первый раз 5–10 минут)"
$COMPOSE up -d --build

say "Жду, пока игра ответит"
ok=0
for _ in $(seq 1 40); do
  if $COMPOSE exec -T server node -e "fetch('http://127.0.0.1:3000/health').then(r=>process.exit(r.ok?0:1)).catch(()=>process.exit(1))" >/dev/null 2>&1; then ok=1; break; fi
  sleep 3
done
[ "$ok" -eq 1 ] || { $COMPOSE logs --tail=40 server; die "Сервер не запустился, лог выше."; }

cat <<MSG

✅ Готово! Откройте https://$DOMAIN
   (если сертификат ещё не выдан — подождите пару минут: Caddy получает его сам).

Дальше:
  1) Зарегистрируйтесь в игре${OWNER:+ под e-mail $OWNER}.
  2) Станьте владельцем:  $COMPOSE exec server node dist/owner-grant.js
  3) Обновление:  ./scripts/update.sh      Резервная копия:  ./scripts/backup.sh
Пароли и секреты лежат в файле .env (никому не показывайте, в git он не попадает).
MSG
