#!/usr/bin/env bash
# Резервная копия БД в backups/throne-ДАТА.sql.gz (хранятся последние 14). Можно поставить в cron:
#   0 4 * * *  cd /путь/к/throne-clash && ./scripts/backup.sh
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
[ "$(id -u)" -ne 0 ] && SUDO="sudo" || SUDO=""
mkdir -p backups
USER_DB="$(grep -E '^POSTGRES_USER=' .env | cut -d= -f2- || true)"; USER_DB="${USER_DB:-throne}"
NAME_DB="$(grep -E '^POSTGRES_DB=' .env | cut -d= -f2- || true)"; NAME_DB="${NAME_DB:-throne}"
OUT="backups/throne-$(date +%Y%m%d-%H%M).sql.gz"
$SUDO docker compose -f docker-compose.yml -f docker-compose.prod.yml exec -T postgres pg_dump -U "$USER_DB" "$NAME_DB" | gzip > "$OUT"
ls -1t backups/throne-*.sql.gz | tail -n +15 | xargs -r rm --
echo "Готово: $OUT"
