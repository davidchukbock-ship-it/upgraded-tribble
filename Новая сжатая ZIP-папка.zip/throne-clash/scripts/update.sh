#!/usr/bin/env bash
# Обновление игры на сервере: забирает новый код и пересобирает контейнеры. Данные (БД) сохраняются.
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
[ "$(id -u)" -ne 0 ] && SUDO="sudo" || SUDO=""
git pull --ff-only
$SUDO docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d --build
$SUDO docker image prune -f >/dev/null
echo "Обновлено."
