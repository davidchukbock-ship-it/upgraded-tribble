// Устанавливает git-хуки только если эта папка сама является корнем git-репозитория.
// Внутри родительского репозитория (throne-clash/ как подпапка) хуки не трогаем,
// чтобы не менять core.hooksPath у остальных проектов.
import { existsSync } from 'node:fs';
import { execSync } from 'node:child_process';

if (existsSync('.git') && process.env.CI !== 'true') {
  try {
    execSync('husky', { stdio: 'inherit' });
  } catch {
    console.warn('husky не установлен — пропускаем настройку git-хуков');
  }
}
