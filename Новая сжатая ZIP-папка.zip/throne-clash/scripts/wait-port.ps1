# Ждёт, пока порт localhost начнёт принимать соединения (до ~3 минут). Код 0 — порт открыт.
param([int]$Port = 5432, [int]$Seconds = 180)
$deadline = (Get-Date).AddSeconds($Seconds)
while ((Get-Date) -lt $deadline) {
  try {
    $c = New-Object Net.Sockets.TcpClient
    $c.Connect('127.0.0.1', $Port)
    $c.Close()
    exit 0
  } catch { Start-Sleep -Seconds 2 }
}
exit 1
