# API

Базовый префикс `/api`. Формат — JSON, время — ISO-8601 UTC, каждый успешный ответ содержит `serverTime`.
Интерактивная документация: **`/docs`** (Swagger UI, генерируется из Zod-схем; `/docs/json` — OpenAPI).

## Соглашения

| Тема            | Правило                                                                                                                 |
| --------------- | ----------------------------------------------------------------------------------------------------------------------- |
| Аутентификация  | `Authorization: Bearer <access>`; refresh — httpOnly cookie на `/api/auth`                                              |
| Ошибки          | `{ "error": { "code": "ERR_…", "message": "…", "details": … }, "requestId": "…" }`; коды стабильны, тексты — на клиенте |
| Идемпотентность | `Idempotency-Key: <uuid>` обязателен для POST, тратящих ресурсы; повтор возвращает прежний ответ                        |
| CSRF            | для cookie-эндпоинтов (`/auth/refresh`, `/auth/logout`, `/god/*`): заголовок `X-CSRF-Token` = значение cookie `csrf`    |
| Rate limit      | 429 + `Retry-After`; лимиты по группам маршрутов                                                                        |
| Пагинация       | `?page=1&pageSize=20`, ответ `{ items, page, pageSize, total }`                                                         |

Коды ошибок (основные): `ERR_VALIDATION`, `ERR_UNAUTHORIZED`, `ERR_FORBIDDEN`, `ERR_NOT_FOUND`, `ERR_CONFLICT`, `ERR_RATE_LIMITED`, `ERR_INSUFFICIENT_RESOURCES`, `ERR_QUEUE_FULL`, `ERR_REQUIREMENT_NOT_MET`, `ERR_SHIELD_ACTIVE`, `ERR_BANNED`, `ERR_MUTED`, `ERR_IDEMPOTENCY_MISMATCH`.

## Маршруты по модулям

Обозначения: 🔒 — нужен access-токен, 👑 — роль ADMIN, ⚡ — Idempotency-Key.

### auth

| Метод | Путь                  | Описание                                                                                         |
| ----- | --------------------- | ------------------------------------------------------------------------------------------------ |
| POST  | `/auth/register`      | `{ email, password, nickname, language? }` → `201` access-токен + cookie `tc_refresh`, `tc_csrf` |
| POST  | `/auth/login`         | `{ email, password }` → `200` (неверные данные — единый `401 ERR_INVALID_CREDENTIALS`)           |
| POST  | `/auth/guest`         | `{ language? }` (тело необязательно) → `201`; ник `Гость-XXXXX`                                  |
| POST  | `/auth/refresh`       | ротация refresh (cookie `tc_refresh` + заголовок `X-CSRF-Token` = cookie `tc_csrf`)              |
| POST  | `/auth/logout`        | `204`; отзывает цепочку этого устройства (cookie + CSRF)                                         |
| POST  | `/auth/logout-all` 🔒 | `204`; отзывает все устройства                                                                   |
| POST  | `/auth/upgrade` 🔒    | `{ email, password }` — гость становится полноценным аккаунтом                                   |
| GET   | `/auth/me` 🔒         | `{ user, serverTime }`                                                                           |
| PATCH | `/profile` 🔒         | `{ nickname?, crest?, language? }` (ник — раз в сутки; лишние поля отклоняются)                  |

Коды: `400 ERR_VALIDATION` (детали по полям), `401 ERR_INVALID_CREDENTIALS | ERR_UNAUTHORIZED`, `403 ERR_BANNED | ERR_FORBIDDEN` (CSRF/Origin), `409 ERR_EMAIL_TAKEN | ERR_NICKNAME_TAKEN | ERR_CONFLICT`, `422 ERR_REQUIREMENT_NOT_MET` (`details.reason = nickname_cooldown`, `retryAfterSeconds`), `429 ERR_RATE_LIMITED` (`Retry-After`; при блокировке входа `details.retryAfterSeconds`).

Cookie: `tc_refresh` — `HttpOnly; SameSite=Strict; Path=/api/auth` (+`Secure` в production); `tc_csrf` — `SameSite=Strict; Path=/`, читается клиентом. Access-токен хранится только в памяти клиента. Правила полей (пароль 8–128 без частых паролей, ник 3–20) — в `packages/shared/src/validation.ts`, одни и те же на клиенте и сервере.

### castle

Все изменяющие запросы требуют `Idempotency-Key: <8–64 символа [A-Za-z0-9_-]>` (клиент шлёт новый UUID на каждое намерение). Повтор с тем же ключом возвращает сохранённый ответ с заголовком `Idempotent-Replay: true` и не выполняет действие второй раз; тот же ключ для другого действия — `422 ERR_IDEMPOTENCY_MISMATCH`. Ключ хранится 24 часа. Все ответы — актуальный `CastleDto`.

| Метод | Путь                                  | Описание                                                                                                                           |
| ----- | ------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------- |
| GET   | `/castle` 🔒                          | ресурсы на `serverTime`, ёмкость, ставки/час, кристаллы, слоты, 18 зданий (у не построенных — `missing[]` условий), идущие стройки |
| POST  | `/castle/buildings/:key/upgrade` 🔒⚡ | поставить постройку/улучшение; `:key` из 18 ключей зданий (в т. ч. `territory` — расширение острова)                               |
| POST  | `/castle/queue/:taskId/speedup` 🔒⚡  | ускорить за кристаллы (1 за каждые 5 мин остатка, минимум 1)                                                                       |
| POST  | `/castle/queue/:taskId/cancel` 🔒⚡   | отменить, вернуть 50% потраченного                                                                                                 |
| POST  | `/castle/slots/unlock` 🔒⚡           | открыть второй слот за 250 кристаллов (не нужен при Замке ≥ 8)                                                                     |

Ошибки: `422 ERR_INSUFFICIENT_RESOURCES` (`details.missing` — сколько чего не хватает, в т. ч. `gems`), `422 ERR_QUEUE_FULL`, `422 ERR_REQUIREMENT_NOT_MET` (`details.reason`: `in_progress` | `max_level` | `castle_level` | `requires`; для `requires` — `details.missing[]`), `404` (нет такой задачи у вас), `409 ERR_CONFLICT` (второй слот уже есть).

`CastleDto` (ответ каждого маршрута замка, армии, исследований и героя) кроме ресурсов и зданий содержит:
`army` — `{ units[], count, queued, cap, upkeepPerHour, maxTier, queue[], queueMax }`;
`research` — `{ academyLevel, queueMax, queue[], techs[14] }` (у технологии: `level`, `nextLevel`, `cost`, `seconds`, `academyRequired`, `blocked`);
`hero` — `{ level, xp, xpToNext, skillPoints, skills, items[], bonuses, train }`.
`GET /castle` остаётся главным способом получить всё разом; отдельные `GET` ниже отдают только свою часть.

#### Постройки города

| Метод  | Путь                          | Описание                                                                                                                                                                                      |
| ------ | ----------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| POST   | `/castle/structures` 🔒⚡     | `{ kind, x, y }` — построить на свободной клетке (вода для `pier`/`ship`); `409` клетка занята/не подходит, `422` нет ресурсов, `422 requirement_not_met` (`castle_level`, `structure_limit`) |
| DELETE | `/castle/structures/:id` 🔒⚡ | снести, вернуть 50%                                                                                                                                                                           |

`CastleDto.city` — `{ structures[], catalog[], prosperity, cap }`.

### army

| Метод | Путь                               | Описание                                                                                              |
| ----- | ---------------------------------- | ----------------------------------------------------------------------------------------------------- |
| GET   | `/army` 🔒                         | `ArmyDto`: войска по видам и ступеням, раненые, очередь обучения, лимит, содержание                   |
| POST  | `/army/train` 🔒⚡                 | `{ type, tier, count }`; ресурсы списываются сразу, партия встаёт в конец цепочки                     |
| POST  | `/army/queue/:taskId/cancel` 🔒⚡  | отмена: возврат 50%, следующие партии сдвигаются раньше                                               |
| POST  | `/army/queue/:taskId/speedup` 🔒⚡ | ускорение первой партии за кристаллы (1 за 5 минут остатка)                                           |
| POST  | `/army/heal` 🔒⚡                  | `{ unit, count }` — вылечить раненых в Госпитале: платно (50% цены, −5% за ур. «Медицины»), мгновенно |

Ошибки: `422 ERR_REQUIREMENT_NOT_MET` (`details.reason`: `no_barracks` | `tier_locked` | `army_cap`; для ускорения не первой партии — `not_active`), `422 ERR_QUEUE_FULL` (4 партии), `422 ERR_INSUFFICIENT_RESOURCES`, `404` (нет такой партии), `422 ERR_VALIDATION`.

### research

| Метод | Путь                                   | Описание                                                           |
| ----- | -------------------------------------- | ------------------------------------------------------------------ |
| GET   | `/research` 🔒                         | `ResearchDto`: 14 технологий, очередь (2 записи), уровень Академии |
| POST  | `/research/:key/start` 🔒⚡            | начать следующий уровень технологии (1–10)                         |
| POST  | `/research/queue/:taskId/cancel` 🔒⚡  | отмена: возврат 50%                                                |
| POST  | `/research/queue/:taskId/speedup` 🔒⚡ | ускорение первой записи за кристаллы                               |

Ошибки: `422 ERR_REQUIREMENT_NOT_MET` (`details.reason`: `academy_level` | `max_level` | `in_progress`; для ускорения не первой записи — `not_active`), `422 ERR_QUEUE_FULL`, `422 ERR_INSUFFICIENT_RESOURCES`. Для уровня `L` нужна Академия `2L−1` (не выше 20).

### hero

| Метод | Путь                     | Описание                                                                     |
| ----- | ------------------------ | ---------------------------------------------------------------------------- |
| GET   | `/hero` 🔒               | `HeroDto`; у нового аккаунта герой создаётся при первом чтении               |
| POST  | `/hero/skills/:key` 🔒⚡ | вложить очко навыка (`combat` \| `defense` \| `economy`), максимум 5 уровней |
| POST  | `/hero/equip` 🔒⚡       | `{ itemId }` — надеть предмет; прежний в этом слоте остаётся в сумке         |
| POST  | `/hero/train` 🔒⚡       | тренировка: золото и еда за 60 опыта; на максимальном уровне отклоняется     |

Ошибки: `422 ERR_REQUIREMENT_NOT_MET` (`details.reason`: `no_points` | `max_level` — у навыка или у героя), `422 ERR_INSUFFICIENT_RESOURCES`, `404` (нет такого предмета).

### map

Карта 400 × 400 целиком выводится из seed мира (рельеф, ресурсные точки, лагеря); в БД лежат только замки и изменяемое состояние клеток.

| Метод | Путь                        | Описание                                                                                                                                                                                                                                                      |
| ----- | --------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| GET   | `/map/tiles?x=&y=&size=` 🔒 | участок `size × size` (1…40, по умолчанию 40) от `x,y`; прижимается к границам; клетки построчно; у клетки `terrain` ∈ plain · forest · mountain · water (карта v1) или desert · swamp · sea · lake · river (карта v2), а также `road` и `region` (только v2) |
| GET   | `/map/overview` 🔒          | грубый рельеф всего мира для мини-карты: `{ step, cols, terrain }`                                                                                                                                                                                            |
| GET   | `/map/cell/:x/:y` 🔒        | одна клетка (`400`/`404` вне карты)                                                                                                                                                                                                                           |
| GET   | `/map/search?q=` 🔒         | ник (часть, без учёта регистра, ≥ 2 символов) или координаты `x,y`; до 10 результатов                                                                                                                                                                         |

Клетка: `terrain` (`plain|forest|mountain|water`), `kind` (`empty|resource|camp`), `level`, `resource`, `castle {nickname,isMe,shielded}`, `busyUntil` (лагерь повержен), `remaining` (остаток запаса точки).

### battle

| Метод | Путь              | Описание                                                                                                  |
| ----- | ----------------- | --------------------------------------------------------------------------------------------------------- |
| POST  | `/marches` 🔒⚡   | `{ type: attack\|scout\|monster\|gather, target: {x,y}, units: {"infantry_1": 20} }` → полный `CastleDto` |
| GET   | `/marches` 🔒     | мои походы (`outbound` — идёт к цели, `returning` — возвращается с добычей)                               |
| GET   | `/reports` 🔒     | `?page=&pageSize=` (≤ 50) → `{ items, page, pageSize, total, unread }`                                    |
| GET   | `/reports/:id` 🔒 | отчёт с подробностями; чтение помечает его прочитанным; чужой — `404`                                     |

Ошибки отправки: `422 ERR_REQUIREMENT_NOT_MET` (`details.reason`: `own_castle` | `not_enough_units` | `no_target` | `scout_needs_cavalry` | `camp_respawning`), `422 ERR_SHIELD_ACTIVE` (цель под щитом), `422 ERR_QUEUE_FULL` (уже 5 походов), `400 ERR_VALIDATION`.
`CastleDto` содержит `position {x,y}`, `marches[]`, `marchesMax`; `army.marching` (в походах, входят в лимит армии), `army.woundedRoom`.

### guild

Гостям братства недоступны (`422 ERR_REQUIREMENT_NOT_MET`, `reason: guest`). Создание — Замок ≥ 5 и 1 000 золота.

| Метод  | Путь                                         | Описание                                                                                          |
| ------ | -------------------------------------------- | ------------------------------------------------------------------------------------------------- |
| GET    | `/guilds?q=&page=&pageSize=` 🔒              | список и поиск по названию (по ключу, без учёта регистра и похожих букв)                          |
| GET    | `/guilds/mine` 🔒                            | моё братство (`guild`: состав, заявки для главы/офицеров, стройки соратников) или поданные заявки |
| POST   | `/guilds` 🔒⚡                               | `{ name, description? }` → `MyGuildDto`; занятое имя — `409`, золото не списывается               |
| POST   | `/guilds/:id/apply` 🔒                       | заявка (до 5 одновременно) → `204`; глава и офицеры получают уведомление                          |
| DELETE | `/guilds/:id/apply` 🔒                       | отозвать заявку                                                                                   |
| POST   | `/guilds/applications/:id/accept\|reject` 🔒 | глава и офицеры; при полном братстве `reason: guild_full`                                         |
| POST   | `/guilds/members/:userId/role` 🔒            | `{ role: officer\|member\|leader }` — только глава; `leader` передаёт главенство                  |
| DELETE | `/guilds/members/:userId` 🔒                 | исключить: глава — любого, офицер — рядового                                                      |
| POST   | `/guilds/leave` 🔒                           | выйти; глава с соратниками — `reason: leader_must_transfer`; последний участник распускает        |
| POST   | `/guilds/treasury/donate` 🔒⚡               | `{ amount ≥ 10 }` → `CastleDto`; уровень братства `1 + ⌊вклад / 50 000⌋` ≤ 10                     |
| POST   | `/guilds/help/:ownerId/:taskId` 🔒           | помочь со стройкой соратника: −`max(10 с, 1%)`; одна помощь от игрока, не больше 10 на стройку    |

### chat

Каналы: `world`, `guild`, `dm:<userId собеседника>`. Сообщение — до 300 символов, брань маскируется `*`, не больше 5 сообщений за 10 секунд (`429`, `details.retryAfterSeconds`). Заглушённые игроки получают `403 ERR_MUTED`.

| Метод | Путь                         | Описание                                                                         |
| ----- | ---------------------------- | -------------------------------------------------------------------------------- |
| GET   | `/chat/:channel/history` 🔒  | последние 50 сообщений, старые первыми; `?before=<ISO>` листает назад            |
| POST  | `/chat/:channel/messages` 🔒 | `{ text }` — запасной путь, если WebSocket недоступен                            |
| POST  | `/chat/report` 🔒            | `{ messageId, reason }`; на своё и на невидимое сообщение нельзя; повтор — `409` |

### notifications

Виды: `build.done`, `train.done`, `research.done`, `march.returned`, `march.attacked`, `guild.application`, `guild.accepted`, `guild.kicked`, `guild.help`, `chat.dm`, `season.reward`. Хранятся 30 дней.

| Метод | Путь                                | Описание                                                 |
| ----- | ----------------------------------- | -------------------------------------------------------- |
| GET   | `/notifications?page=&pageSize=` 🔒 | `{ items, page, pageSize, total, unread }`, новые сверху |
| POST  | `/notifications/read` 🔒            | `{ ids? }` — отметить прочитанными (без `ids` — все)     |

### WebSocket `/ws`

Соединение анонимно, пока первым сообщением не придёт `{ "type": "auth", "token": <access> }` (10 секунд, иначе закрытие `4001`; неверный токен — `4003`). Повторная `auth` тем же игроком допустима (обновление токена). Сообщение не больше 4 КБ (иначе `1009`).

| Направление     | Сообщение                                                                                                                                                    |
| --------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| клиент → сервер | `auth`, `chat.send { channel, text }`, `ping`                                                                                                                |
| сервер → клиент | `ready { userId, online }`, `chat.message { message }`, `notification { notification }`, `presence { online }`, `error { code, retryAfterSeconds? }`, `pong` |

### quests

Прогресс считает сервер. Счётчики (`upgrade`, `train`, `win`, `gather`, `march`, `chat`, `chest`) растут только при **удавшемся** действии; остальное выводится из состояния замка (уровни зданий, мощь, армия, навыки героя, братство). Ежедневные задания и их награды сбрасываются в 00:00 UTC, туториал и достижения — разовые. Награда за одно задание выдаётся один раз (`409` при повторе), а невыполненное — `422 reason: not_done`.

| Метод | Путь                         | Описание                                                                                                                                         |
| ----- | ---------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------ |
| GET   | `/quests` 🔒                 | `{ tutorial[10], daily[4], achievements[], login { day, claimed, rewards[7] }, dailyResetAt, claimable }`; у каждого задания `progress ≤ target` |
| POST  | `/quests/:id/claim` 🔒⚡     | `{ castle, reward, inventory }`; неизвестное задание — `404`                                                                                     |
| POST  | `/daily/claim` 🔒⚡          | награда ежедневного входа (серия 1…7, пропуск дня сбрасывает, день 7 — серебряный сундук); повтор в тот же день — `409`                          |
| GET   | `/free-packs` 🔒             | `{ serverTime, packs[{ id, everyHours, reward, claimed, nextAt }], claimable }`; окна считаются по UTC                                           |
| POST  | `/free-packs/:id/claim` 🔒⚡ | `{ castle, reward, inventory }`; повтор в том же окне — `409`, неизвестный набор — `404`                                                         |

### chests / inventory

Инвентарь хранит сундуки, ускорители и купленные гербы. Таблицу шансов видно без входа — она та же, что использует сервер.

| Метод | Путь                           | Описание                                                                                                                                                   |
| ----- | ------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------- |
| GET   | `/chests/odds`                 | публично: для каждого вида `odds` (%, сумма 100), размер пакета ресурсов, диапазон кристаллов                                                              |
| GET   | `/inventory` 🔒                | `{ chests{wooden,silver,gold}, boosters{boost_5m,boost_1h,boost_8h}, crests[] }`                                                                           |
| POST  | `/chests/:kind/open` 🔒⚡      | `{ castle, reward, inventory }`; `reward` — `resources` \| `booster` \| `gems` \| `gear`; нет сундука — `422 reason: no_chest`; результат пишется в журнал |
| POST  | `/inventory/boosters/use` 🔒⚡ | `{ booster, target: build\|train\|research, taskId }` → `{ castle, inventory }`; сокращает время, в цепочках — только идущей первой (`not_active`)         |

### shop

Всё за кристаллы; реальных денег нет (D-11).

| Метод | Путь                | Описание                                                                                                                                           |
| ----- | ------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------- |
| GET   | `/shop` 🔒          | `{ items[], gems, inventory }`: пакеты ресурсов (20/90/350), ускорители (5/25/150), второй слот (250), 10 гербов по 50; `owned` для слота и гербов |
| POST  | `/shop/buy` 🔒⚡    | `{ itemId }` → `{ castle, shop }`; не хватает кристаллов — `422`, уже куплено — `409`, неизвестный товар — `404`                                   |
| POST  | `/shop/checkout` 🔒 | `{ packId }` — покупка кристаллов за деньги: всегда `403 reason: payments_disabled` (`NullPaymentProvider`)                                        |

Премиум-герб выбирается через `PATCH /profile { crest }`; неприобретённый — `422 reason: crest_not_owned`.

### donate

Пакеты кристаллов за реальные деньги (D-62). Режим задаёт `PAYMENTS_MODE`: `off` (по умолчанию) или `test`.

| Метод | Путь               | Описание                                                                                                                                         |
| ----- | ------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------ |
| GET   | `/donate` 🔒       | `{ mode, gems, packs[] }`: id, кристаллы, бонус, итог, цены в центах и копейках, метка `popular`/`best`                                          |
| POST  | `/donate/buy` 🔒⚡ | `{ packId }` → `{ castle, granted }`; при `mode=off` — `403 payments_disabled`, неизвестный пакет — `404`; в `test` кристаллы выдаются бесплатно |

### leagues

Сезон — неделя, понедельник 00:00 UTC → воскресенье 23:59:59 (id сезона — дата начала). Очки: `мощь/100 + 50·победы + убийства/10`. Победы и убийства копятся в бою (у обеих сторон), замки режима бога в таблицы не попадают.

| Метод | Путь                                                  | Описание                                                                                                                                        |
| ----- | ----------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------- |
| GET   | `/leagues/current?scope=me\|guild\|top100&metric=` 🔒 | `metric`: `points` \| `power` \| `wins` \| `kills`. `{ seasonId, endsAt, entries[], me, pending[], prize }`; `me` — окно ±5, `guild` — братство |
| POST  | `/leagues/rewards/claim` 🔒⚡                         | забрать призы за закрытые сезоны: кристаллы, сундук места и деревянный сундук участника; нечего забирать — `422`                                |

Приз: 1 место — 100 кристаллов + золотой сундук; 2–10 — 50 + серебряный; 11–100 — 20; всем участникам — деревянный сундук. Сезон закрывается по таймеру и при чтении таблицы; участник — тот, кто за сезон воевал.

### admin (👑 ADMIN и OWNER)

Права проверяются на сервере при каждом запросе (роль читается из БД, D-20). Отказ обычному игроку — `403` и запись `admin_denied` в журнале безопасности. Модерировать нельзя себя и владельца; администратора — только владелец. Изменяющие действия пишутся в аудит (`scope: admin`).

| Метод | Путь                            | Описание                                                                                                                                                            |
| ----- | ------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| GET   | `/admin/stats` 👑               | игроки (всего, гости, боты, в бане, без чата), активность (новые за сутки/неделю, активные, онлайн), экономика за 24 часа **без** действий режима бога, число жалоб |
| GET   | `/admin/users?q=&page=` 👑      | поиск по нику (по ключу), почте или точному id; новые сверху                                                                                                        |
| POST  | `/admin/users/:id/ban` 👑       | `{ hours: 1…8760 \| null, reason }` — `null` навсегда; сессии отзываются, WebSocket закрывается                                                                     |
| POST  | `/admin/users/:id/unban` 👑     | снять бан                                                                                                                                                           |
| POST  | `/admin/users/:id/mute` 👑      | `{ minutes, reason }` — запрет чата (`403 ERR_MUTED`)                                                                                                               |
| POST  | `/admin/users/:id/unmute` 👑    | снять запрет                                                                                                                                                        |
| POST  | `/admin/users/:id/grant` 👑⚡   | `{ amount 1…10000, reason }` → `CastleDto`; кристаллы поддержки, пишется в аудит и в экономику (не режим бога)                                                      |
| GET   | `/admin/logs?kind=&userId=` 👑  | журнал подозрительных действий (см. docs/SECURITY.md → виды событий)                                                                                                |
| GET   | `/admin/reports` 👑             | жалобы на сообщения чата с текстом и участниками                                                                                                                    |
| GET   | `/admin/audit?targetUserId=` 👑 | аудит действий администраторов                                                                                                                                      |

### служебные

`GET /health` — `{ status, db, redis }`; `GET /docs` — Swagger.

### god (`/api/god/*`, скрыт за флагом)

Подробно — в `docs/GOD_MODE.md`. Допуск в три слоя: флаг `GOD_MODE_ENABLED` (выключен → любой путь `404`, неотличимый от несуществующего), действующая роль `OWNER` (иначе тоже `404`), сессия режима бога в httpOnly-cookie (иначе `401`). Каждый запрос требует и Bearer-токен, и cookie. Все ответы: `X-Robots-Tag: noindex`, `Cache-Control: no-store`.

| Метод   | Путь                                               | Описание                                                                                                                         |
| ------- | -------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------- |
| POST    | `/god/login` 🔒 (OWNER)                            | `{ password, totp? }` → cookie сессии (30 минут скользящее окно); 5 неудач с пары IP+аккаунт → `429` на 15 минут                 |
| GET     | `/god/session`                                     | текущая сессия (продлевает срок)                                                                                                 |
| POST    | `/god/logout`                                      | закрыть сессию                                                                                                                   |
| GET     | `/god/players?q=` · `/god/players/:id`             | поиск; карточка: профиль, замок, инвентарь, снимки, метка «тронут режимом бога»                                                  |
| POST    | `/god/players/:id/act` ⚡                          | действие (`godActionSchema`): ресурсы, склады, здания, очереди, армия, исследования, герой, время, телепорт, щит, сундуки, сброс |
| POST    | `/god/players/:id/snapshots` · `…/:sid/restore` ⚡ | сохранить / восстановить замок (песочница)                                                                                       |
| POST    | `/god/players/:id/ban\|unban\|mute\|unmute\|role`  | модерация; `role`: `PLAYER` или `ADMIN` (владельца назначает только CLI, D-19)                                                   |
| POST    | `/god/players/:id/impersonate`                     | токен на 10 минут от имени игрока (claim `act`); действия под ним пишутся в аудит                                                |
| POST    | `/god/map/cell-reset`                              | `{ x, y }` — лагерь возрождается, ресурсная точка наполняется                                                                    |
| POST    | `/god/simulate`                                    | два произвольных отряда, бонусы, seed, `force` → результат боя; данные игры не меняются                                          |
| DELETE  | `/god/guilds/:id` · POST `/god/chat/announce`      | распустить братство; объявление в мировой чат                                                                                    |
| GET/PUT | `/god/balance` · POST `/god/balance/rollback`      | конструктор баланса: множители 0,1–10, ревизии, откат; GET — он же экспорт JSON                                                  |
| GET     | `/god/audit`                                       | аудит: и админка, и режим бога                                                                                                   |
| GET     | `/god/debug` · POST `/god/debug/reseed`            | состояние сервера; досоздание ботов                                                                                              |
