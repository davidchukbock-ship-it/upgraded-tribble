# Пакет промтов для графики, анимации и персонажей

Этот документ — задание для генератора изображений / ИИ-ассистента (Antigravity или любого другого). Результаты загружайте в чат по группам (A, B, C, …): я подключу их к игре, сделаю атласы и анимации.

> **Права.** Используйте только те инструменты и режимы, условия которых разрешают коммерческое использование результатов. Не ссылайтесь в промтах на существующие игры, студии, художников и персонажей (в каждый промт уже включён запрет). Храните рядом с файлами запись: инструмент, дата, режим лицензии.

## 1. Единый стиль («библия стиля»)

Вставляйте этот блок **в начало каждого промта**:

```
STYLE: polished 2D vector-style illustration for a medieval strategy mobile/web game.
Clean smooth shapes, soft gradients, gentle cel-shading with a clear top-left light source,
rim light on the lit edge, subtle ambient occlusion at the base, slightly exaggerated
"chibi-heroic" proportions (large head ~1/3 of body height for characters), rounded friendly forms.
Outline: 2-3 px medium-dark warm brown line (#2a1a0e at 70%), never pure black, consistent weight.
Palette: rich but harmonious, saturated greens (#6fbf4a), warm wood browns (#8a5a2c), stone greys (#a39d8d),
royal blue (#2e5fa8), crimson (#b32626), gold (#f2cf6b). Bright, readable at small size.
NOT pixel art, NOT low-resolution, NOT photorealistic, NOT 3D render, no blur, no noise, no text, no watermark,
no signature, no logos. Transparent background. Original design, not resembling any existing game, franchise,
studio, film or artist.
```

**Негативный промт** (если инструмент его поддерживает):

```
pixel art, pixelated, low-res, blurry, noisy, photo, 3d render, text, letters, watermark, signature, logo,
copyrighted character, existing franchise, frame, border, background scene, cropped, extra limbs, deformed hands
```

## 2. Технические требования к файлам

| Параметр         | Значение                                                                                                                                  |
| ---------------- | ----------------------------------------------------------------------------------------------------------------------------------------- |
| Формат           | PNG или WebP с прозрачностью; векторные — SVG (предпочтительно для иконок и зданий)                                                       |
| Фон              | полностью прозрачный, без теней на фоне (тень — отдельным слоем, если возможно)                                                           |
| Размер персонажа | 512 × 512 px, фигура по центру, ноги на линии y = 440 (запас сверху под оружие/шлем)                                                      |
| Размер здания    | 512 × 512 px (малые) или 768 × 768 px (замок, храм, собор), основание ромбом 2:1 внизу, центр ромба в (256, 420)                          |
| Иконка           | 256 × 256 px (и SVG, если удаётся)                                                                                                        |
| Плитка местности | ромб 2:1, 256 × 128 px, бесшовная по краям                                                                                                |
| Анимация         | спрайт-лист: кадры слева направо, одной строкой; размер кадра = 512 × 512 (персонажи) или 256 × 256 (эффекты); указать число кадров и fps |
| Имена файлов     | строчные латиница, цифры, `_`: `hero_knight_epic.png`, `bld_barracks_l1_medieval.png`, `anim_knight_attack_8f.png`                        |
| Сопровождение    | `manifest.json`: для каждого файла `name`, `frames`, `fps`, `anchor` (x, y), `loop`                                                       |

Папки для передачи: `characters/`, `heroes/`, `enemies/`, `buildings/`, `city/`, `ships/`, `terrain/`, `mapobjects/`, `ui/`, `vfx/`, `backgrounds/`.

## 3. Группа A — персонажи

### A1. Армия игрока (4 типа × 5 ступеней = 20 фигур)

Типы: пехота, лучники, кавалерия, осадные орудия. Ступени 1–5 отличаются снаряжением (кожа → железо → сталь → золотая отделка → парадные доспехи королевской гвардии).

Шаблон:

```
[STYLE]
Medieval {TYPE} soldier, tier {N} of 5: {GEAR}. Three-quarter front view facing right-down,
full body, dynamic confident idle pose, weapon held ready. Clear silhouette. Tier {N} must look clearly
stronger than tier {N-1} (more armor, plume, cape, gold trim), same face and proportions across tiers.
```

`{GEAR}`: пехота — «round shield, spear, leather cap → iron helmet → steel plate with crest → gold-trimmed heavy armor → royal guard with tabard»; лучники — «short bow, hood → longbow, quiver, leather vest → ranger cloak, bracers → elite archer with feathered hat → royal marksman»; кавалерия — «light horseman, small pennant → lancer with barding → heavy knight on armored horse → golden-caparisoned charger → royal cavalry»; осадные — «wooden catapult → ballista → trebuchet → fire-bolt engine with crew → royal siege tower».

Файлы: `unit_{type}_t{1..5}.png`.

### A2. Анимации армии (для каждого типа и ступени 1, 3, 5 — остальные соберу сам)

Анимации: `idle` (6 кадров, 8 fps, цикл), `walk` (8 кадров, 10 fps, цикл), `attack` (8 кадров, 12 fps, без цикла), `hurt` (4 кадра), `death` (8 кадров, без цикла), `cheer` (8 кадров, цикл).

```
[STYLE]
Sprite sheet, single row of {N} frames, each 512x512, same character, same scale, feet locked on the same
baseline, smooth in-between motion, anticipation-action-follow-through, {ANIMATION}.
Consistent costume and proportions in every frame. Transparent background.
```

Файлы: `anim_unit_{type}_t{tier}_{anim}_{N}f.png`.

### A3. Герои (коллекция)

8 классов: **воин, маг, лучник, паладин, убийца, некромант, друид, бард**. Каждый — 6 редкостей (обычный, необычный, редкий, эпический, легендарный, мифический). Редкость выражается костюмом и эффектами: обычный — простая одежда; необычный — зелёные акценты; редкий — синие, детали; эпический — фиолетовые, парящие элементы; легендарный — золотое сияние, плащ; мифический — радужный/космический ореол, уникальный силуэт. **Лицо и пропорции одного класса одинаковы во всех редкостях.**

Шаблон:

```
[STYLE]
Fantasy hero, class: {CLASS}, rarity: {RARITY} ({RARITY_LOOK}). Heroic confident pose, three-quarter view,
full body, signature weapon and class silhouette readable at 64 px. Expressive face, detailed but clean costume,
rarity shown by costume richness, glowing accents and aura color: {AURA}. Same face as other rarities of this class.
```

Ауры: обычный — нет; необычный — зелёная; редкий — синяя; эпический — фиолетовая; легендарный — золотая; мифический — красно-золотая с искрами.

Файлы: `hero_{class}_{rarity}.png` (48 изображений). Анимации для каждого класса (на эпическую редкость, остальные перекрашу): `idle` 8 кадров, `attack` 8, `skill` 10, `ultimate` 12, `victory` 8, `defeat` 6.

### A4. Портреты героев (круглые, для карточек)

```
[STYLE]
Bust portrait of the {CLASS} hero, rarity {RARITY}, face and shoulders, looking slightly left, framed for a circular crop,
soft rim light, transparent background.
```

Размер 256 × 256. Файлы: `portrait_{class}_{rarity}.png`.

### A5. Враги и жители

Враги лагерей: бандит, вор, налётчик, шаман, полководец, огр; боссы: «Костяной король», «Болотная ведьма», «Каменный великан», «Повелитель бурь». Жители: фермер, лесоруб, шахтёр, кузнец, учёный, стражник, торговец, ребёнок, рыбак, монах (по 2 варианта одежды, `idle` и `walk`).

```
[STYLE]
{NAME}, original fantasy enemy/character for a medieval strategy game, readable silhouette, menacing or friendly as fits,
three-quarter view, full body.
```

## 4. Группа B — здания (две эпохи)

Для каждого здания — **средневековая** и **современная** версии, уровни 1, 4, 8, 12, 16, 20 (выглядят всё богаче; остальные уровни я интерполирую добавлением украшений).

Список: замок, казарма, ферма, лесопилка, каменоломня, золотой рудник, склад, кузница, академия, стены и башни, госпиталь, рыбацкая пристань, алмазная шахта, башня магов, башня лучников, баллиста-башня, башня бурь, верфь и порт.

```
[STYLE]
Isometric 2:1 {BUILDING}, {ERA} version, level {L}/20. Whole building on a small diamond-shaped ground patch (grass and soil edge),
soft contact shadow on the ground to the bottom-right, warm window lights, chimneys with gentle smoke space,
small props (barrels, crates, banners) that increase with level. Medieval: timber, stone, thatch or slate roofs.
Modern: concrete, glass, steel, flat roofs, antennas, solar panels, neon signs without text.
Clear silhouette, readable at 128 px, no characters.
```

Файлы: `bld_{key}_l{L}_{era}.png`.

### B2. Город (49 видов застройки)

Жильё (5), дороги и улицы (5), сады и природа (8), услуги (8), торговля (6), культура (6), отдых (5), море и порт (6). Список названий — `docs/GAME_DESIGN.md`, §2.1. По два варианта эпохи на вид; размер 256 × 256, основание ромб 2:1.
Файлы: `city_{kind}_{era}.png`.

## 5. Группа C — карта мира

### C1. Плитки местности

Равнина (3 вариации), лес (3), горы (3), пустыня (3), болото (3), море (3), озеро (2), река (прямая, угол, развилка), дорога (прямая, угол, развилка, мост, тоннель), берег (пена по 4 сторонам и углам), снег (опционально).

```
[STYLE]
Seamless isometric 2:1 terrain tile 256x128, {TERRAIN}, painterly vector look, subtle texture, no objects,
edges match neighbouring tiles of the same type, top-left light.
```

Файлы: `tile_{terrain}_{n}.png`.

### C2. Объекты карты

Лагеря (3 ступени × 2 варианта: шатёр, частокол, крепость), ресурсные точки (золото, дерево, камень, еда × 5 уровней богатства), деревья (дуб, сосна, пальма, мёртвое), скалы, кусты, цветы, кактусы, камыши, руины, маяк, порт, город-ориентир, портал события, мировой босс (4), сундук на карте, караван, корабли на карте.

```
[STYLE]
Isometric map marker: {OBJECT}. Sits on its own small ground shadow, readable at 96 px, charming and clear.
```

Файлы: `map_{name}.png`.

### C3. Мини-карта и иконки карты

Значки: замок, лагерь, ресурс, щит, караван, корабль, порт, босс, событие, туман; 128 × 128.

## 6. Группа D — корабли

Классы: разведчик (лёгкая шхуна), транспорт (торговая каракка), боевой (галера с тараном), облоговый (корабль с катапультой), флагман (галеон с золотой отделкой). Для каждого: 3 уровня (1, 2, 3), вид с 4 сторон (NE, SE, SW, NW), 512 × 512. Анимации: `sail` (плавание, 8 кадров, цикл), `fire` (выстрел, 8), `sink` (затопление, 10), `dock` (швартовка, 8).

```
[STYLE]
{SHIP CLASS}, level {L}, isometric view from {DIRECTION}, floating on a transparent background with a soft foam wake ring,
sails with original heraldry (no text), detailed rigging, readable at 128 px.
```

Файлы: `ship_{class}_l{L}_{dir}.png`, `anim_ship_{class}_{anim}_{N}f.png`.

## 7. Группа E — интерфейс

Иконки (256 × 256, SVG при возможности): ресурсы (золото, дерево, камень, еда, кристалл), разделы меню (замок, карта, армия, академия, герой, задания, братство, лиги, магазин, профиль, чат, отчёты, донат, приключения, флот, режимы), действия (построить, улучшить, ускорить, исследовать, обучить, напасть, разведка, сбор, лечение, щит), статусы (таймер, замок-запрет, новое, успех, ошибка).
Рамки и панели: деревянная рамка, пергаментная панель, золотая рамка героев по редкостям (6), кнопки (обычная/нажатая/неактивная) в 9-slice, ленты-заголовки, бейджи уровня, шкалы прогресса, подсветка «можно забрать».

```
[STYLE]
Game UI element: {ELEMENT}. Layered, glossy but clean, warm wood and parchment with gold trim, crisp at small size,
9-slice friendly (corners intact), transparent background, no text.
```

## 8. Группа F — эффекты (VFX), 256 × 256, спрайт-листы

Удар меча, стрела/полёт, взрыв, магия огня/льда/молнии/тени/света, исцеление, щит, яд, кровотечение (без крови — стилизованные красные искры), повышение уровня, открытие сундука (по качеству), аура редкостей (6, цикл 12 кадров), искры, дым, вода (брызги, рябь, волна), пыль, падающие листья, снег, дождь, молния, костёр, факел, фейерверк победы.

```
[STYLE]
Sprite sheet, single row of {N} frames, 256x256 each, additive-friendly bright core with soft falloff,
{EFFECT}, loops seamlessly if a loop, transparent background.
```

## 9. Группа G — фоны и сцены

Фоны мини-игр и боя (1920 × 1080, без персонажей): луга, тёмный лес, руины, снежный перевал, вулкан, закат на море (рыбалка), зал рун, арена, башня, подземелье, пустыня, болото, замок ночью, порт. Параллакс-слои (дальний, средний, ближний) по 2560 × 1080 с прозрачностью.

```
[STYLE]
Background illustration {SCENE}, layered parallax (far, mid, near), painterly vector look, atmospheric perspective,
warm light, empty center for gameplay, no characters, no text.
```

## 10. Группа H — музыка и звук (по желанию)

Если есть генератор музыки: петли 60–90 с, без вокала, без узнаваемых мелодий; темы — замок (спокойная), карта (путешествие), бой (напряжённая), победа, поражение, порт/море, пустыня, лес, меню. Форматы OGG/MP3 + WAV, 44.1 кГц, бесшовные петли. Звуки UI и боя — короткие WAV (до 2 с).

## 11. Как передавать

1. По одной группе за раз (A1 → A2 → …), в чат — архивом (`.zip`) или папкой с `manifest.json`.
2. Если какие-то кадры не совпадают по масштабу или позе — укажите это, я подгоню (выровняю опорные точки, обрежу, соберу атлас).
3. Для каждого файла, сделанного с помощью ИИ, сохраните запись о лицензии (инструмент + условия).
4. Порядок важности: **B (здания) и A3/A4 (герои)** → A1/A2 (армия) → C (карта) → D (корабли) → E (интерфейс) → F, G, H.

## 12. Что сделаю я после загрузки

- Подключу изображения через атлас спрайтов и ленивую загрузку; векторные файлы — прямо в интерфейс.
- Включу анимации (idle/walk/attack/…) в сцене замка, на карте и в боях; эффекты редкости и VFX — поверх.
- Сохраню текущую векторную графику как запасной вариант, если файла нет или слабое устройство (режим «экономия»).
- Обновлю `docs/ASSETS.md` и `CREDITS.md` записями о происхождении и лицензии ваших файлов.
