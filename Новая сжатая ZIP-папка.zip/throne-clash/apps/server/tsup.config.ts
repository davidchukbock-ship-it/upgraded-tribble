import { defineConfig } from 'tsup';

export default defineConfig({
  // Кроме сервера собираем служебные команды: в Docker-образе исходников нет,
  // а seed и назначение владельца нужны и там (docker compose exec server node dist/seed.js)
  entry: {
    main: 'src/main.ts',
    seed: 'prisma/seed.ts',
    'owner-grant': 'src/cli/owner-grant.ts',
    'god-hash': 'src/cli/god-hash.ts',
  },
  format: ['esm'],
  target: 'node20',
  outDir: 'dist',
  clean: true,
  sourcemap: true,
  // Пакет shared лежит как TS-исходники: вшиваем его в бандл сервера
  noExternal: ['@tc/shared'],
});
