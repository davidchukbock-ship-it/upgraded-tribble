-- Постройки города на свободных клетках острова
ALTER TABLE "Castle" ADD COLUMN "structures" JSONB NOT NULL DEFAULT '[]';
