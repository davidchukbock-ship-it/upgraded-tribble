-- CreateTable
CREATE TABLE "ChestLog" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "kind" TEXT NOT NULL,
    "reward" JSONB NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ChestLog_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "ChestLog_userId_createdAt_idx" ON "ChestLog"("userId", "createdAt" DESC);

-- AddForeignKey
ALTER TABLE "ChestLog" ADD CONSTRAINT "ChestLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
