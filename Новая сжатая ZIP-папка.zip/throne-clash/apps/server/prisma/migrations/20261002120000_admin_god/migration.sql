-- CreateTable
CREATE TABLE "AuditLog" (
    "id" TEXT NOT NULL,
    "scope" TEXT NOT NULL,
    "actorId" TEXT,
    "action" TEXT NOT NULL,
    "targetUserId" TEXT,
    "params" JSONB,
    "before" JSONB,
    "after" JSONB,
    "ip" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "AuditLog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "GodSession" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "tokenHash" TEXT NOT NULL,
    "ip" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL,
    "lastSeenAt" TIMESTAMP(3) NOT NULL,
    "expiresAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "GodSession_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "GodSnapshot" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "label" TEXT NOT NULL,
    "takenBy" TEXT NOT NULL,
    "data" JSONB NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "GodSnapshot_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "BalanceRevision" (
    "id" TEXT NOT NULL,
    "config" JSONB NOT NULL,
    "actorId" TEXT,
    "note" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "BalanceRevision_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "AuditLog_scope_createdAt_idx" ON "AuditLog"("scope", "createdAt" DESC);

-- CreateIndex
CREATE INDEX "AuditLog_targetUserId_createdAt_idx" ON "AuditLog"("targetUserId", "createdAt" DESC);

-- CreateIndex
CREATE UNIQUE INDEX "GodSession_tokenHash_key" ON "GodSession"("tokenHash");

-- CreateIndex
CREATE INDEX "GodSession_userId_idx" ON "GodSession"("userId");

-- CreateIndex
CREATE INDEX "GodSession_expiresAt_idx" ON "GodSession"("expiresAt");

-- CreateIndex
CREATE INDEX "GodSnapshot_userId_createdAt_idx" ON "GodSnapshot"("userId", "createdAt" DESC);

-- CreateIndex
CREATE INDEX "BalanceRevision_createdAt_idx" ON "BalanceRevision"("createdAt" DESC);
