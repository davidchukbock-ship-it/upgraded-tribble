-- AlterTable
ALTER TABLE "Castle" ADD COLUMN     "x" INTEGER,
ADD COLUMN     "y" INTEGER;

-- CreateTable
CREATE TABLE "March" (
    "id" TEXT NOT NULL,
    "castleId" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "targetX" INTEGER NOT NULL,
    "targetY" INTEGER NOT NULL,
    "targetCastleId" TEXT,
    "targetName" TEXT,
    "units" JSONB NOT NULL,
    "wounded" JSONB NOT NULL,
    "loot" JSONB NOT NULL,
    "heroXp" INTEGER NOT NULL DEFAULT 0,
    "state" TEXT NOT NULL,
    "startedAt" TIMESTAMP(3) NOT NULL,
    "arriveAt" TIMESTAMP(3) NOT NULL,
    "returnAt" TIMESTAMP(3) NOT NULL,
    "reportId" TEXT,

    CONSTRAINT "March_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CellState" (
    "worldId" TEXT NOT NULL,
    "x" INTEGER NOT NULL,
    "y" INTEGER NOT NULL,
    "remaining" INTEGER,
    "resetAt" TIMESTAMP(3),

    CONSTRAINT "CellState_pkey" PRIMARY KEY ("worldId","x","y")
);

-- CreateTable
CREATE TABLE "Report" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "worldId" TEXT NOT NULL,
    "kind" TEXT NOT NULL,
    "role" TEXT NOT NULL,
    "outcome" TEXT NOT NULL,
    "targetX" INTEGER NOT NULL,
    "targetY" INTEGER NOT NULL,
    "opponent" TEXT,
    "payload" JSONB NOT NULL,
    "read" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Report_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "March_state_arriveAt_idx" ON "March"("state", "arriveAt");

-- CreateIndex
CREATE INDEX "March_castleId_idx" ON "March"("castleId");

-- CreateIndex
CREATE INDEX "March_targetCastleId_idx" ON "March"("targetCastleId");

-- CreateIndex
CREATE INDEX "Report_userId_createdAt_idx" ON "Report"("userId", "createdAt" DESC);

-- CreateIndex
CREATE UNIQUE INDEX "Castle_worldId_x_y_key" ON "Castle"("worldId", "x", "y");

-- AddForeignKey
ALTER TABLE "March" ADD CONSTRAINT "March_castleId_fkey" FOREIGN KEY ("castleId") REFERENCES "Castle"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Report" ADD CONSTRAINT "Report_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

