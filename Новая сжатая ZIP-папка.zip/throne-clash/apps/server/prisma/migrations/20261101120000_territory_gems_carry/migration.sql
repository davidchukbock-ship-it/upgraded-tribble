-- Алмазная шахта копит доли кристалла между расчётами замка
ALTER TABLE "Castle" ADD COLUMN "gemsCarry" DOUBLE PRECISION NOT NULL DEFAULT 0;
