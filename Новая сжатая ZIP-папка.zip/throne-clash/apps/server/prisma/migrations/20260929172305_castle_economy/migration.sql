-- AlterTable
ALTER TABLE "Castle" ADD COLUMN     "extraBuildSlot" BOOLEAN NOT NULL DEFAULT false;

-- CreateTable
CREATE TABLE "BuildTask" (
    "id" TEXT NOT NULL,
    "castleId" TEXT NOT NULL,
    "buildingKey" TEXT NOT NULL,
    "toLevel" INTEGER NOT NULL,
    "startedAt" TIMESTAMP(3) NOT NULL,
    "finishesAt" TIMESTAMP(3) NOT NULL,
    "paidGold" INTEGER NOT NULL,
    "paidWood" INTEGER NOT NULL,
    "paidStone" INTEGER NOT NULL,
    "paidFood" INTEGER NOT NULL,
    "isGodAction" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "BuildTask_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "IdempotencyKey" (
    "userId" TEXT NOT NULL,
    "key" TEXT NOT NULL,
    "route" TEXT NOT NULL,
    "requestHash" TEXT NOT NULL,
    "status" INTEGER NOT NULL,
    "body" JSONB NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "IdempotencyKey_pkey" PRIMARY KEY ("userId","key")
);

-- CreateTable
CREATE TABLE "EconomyEvent" (
    "id" TEXT NOT NULL,
    "worldId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "kind" TEXT NOT NULL,
    "resource" TEXT NOT NULL,
    "amount" INTEGER NOT NULL,
    "isGodAction" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "EconomyEvent_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "BuildTask_castleId_idx" ON "BuildTask"("castleId");

-- CreateIndex
CREATE INDEX "BuildTask_finishesAt_idx" ON "BuildTask"("finishesAt");

-- CreateIndex
CREATE INDEX "IdempotencyKey_createdAt_idx" ON "IdempotencyKey"("createdAt");

-- CreateIndex
CREATE INDEX "EconomyEvent_worldId_kind_createdAt_idx" ON "EconomyEvent"("worldId", "kind", "createdAt");

-- CreateIndex
CREATE INDEX "EconomyEvent_userId_createdAt_idx" ON "EconomyEvent"("userId", "createdAt");

-- AddForeignKey
ALTER TABLE "BuildTask" ADD CONSTRAINT "BuildTask_castleId_fkey" FOREIGN KEY ("castleId") REFERENCES "Castle"("id") ON DELETE CASCADE ON UPDATE CASCADE;
