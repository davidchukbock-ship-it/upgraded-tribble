-- CreateTable
CREATE TABLE "ArmyUnit" (
    "castleId" TEXT NOT NULL,
    "unitId" TEXT NOT NULL,
    "count" INTEGER NOT NULL DEFAULT 0,
    "wounded" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "ArmyUnit_pkey" PRIMARY KEY ("castleId","unitId")
);

-- CreateTable
CREATE TABLE "TrainTask" (
    "id" TEXT NOT NULL,
    "castleId" TEXT NOT NULL,
    "unitId" TEXT NOT NULL,
    "count" INTEGER NOT NULL,
    "startedAt" TIMESTAMP(3) NOT NULL,
    "finishesAt" TIMESTAMP(3) NOT NULL,
    "paidGold" INTEGER NOT NULL,
    "paidWood" INTEGER NOT NULL,
    "paidStone" INTEGER NOT NULL,
    "paidFood" INTEGER NOT NULL,
    "isGodAction" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "TrainTask_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TechLevel" (
    "castleId" TEXT NOT NULL,
    "tech" TEXT NOT NULL,
    "level" INTEGER NOT NULL,

    CONSTRAINT "TechLevel_pkey" PRIMARY KEY ("castleId","tech")
);

-- CreateTable
CREATE TABLE "ResearchTask" (
    "id" TEXT NOT NULL,
    "castleId" TEXT NOT NULL,
    "tech" TEXT NOT NULL,
    "toLevel" INTEGER NOT NULL,
    "startedAt" TIMESTAMP(3) NOT NULL,
    "finishesAt" TIMESTAMP(3) NOT NULL,
    "paidGold" INTEGER NOT NULL,
    "paidWood" INTEGER NOT NULL,
    "paidStone" INTEGER NOT NULL,
    "paidFood" INTEGER NOT NULL,
    "isGodAction" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "ResearchTask_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Hero" (
    "castleId" TEXT NOT NULL,
    "level" INTEGER NOT NULL DEFAULT 1,
    "xp" INTEGER NOT NULL DEFAULT 0,
    "skillCombat" INTEGER NOT NULL DEFAULT 0,
    "skillDefense" INTEGER NOT NULL DEFAULT 0,
    "skillEconomy" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "Hero_pkey" PRIMARY KEY ("castleId")
);

-- CreateTable
CREATE TABLE "HeroItem" (
    "id" TEXT NOT NULL,
    "castleId" TEXT NOT NULL,
    "slot" TEXT NOT NULL,
    "rarity" INTEGER NOT NULL,
    "equipped" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "HeroItem_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "TrainTask_castleId_idx" ON "TrainTask"("castleId");

-- CreateIndex
CREATE INDEX "TrainTask_finishesAt_idx" ON "TrainTask"("finishesAt");

-- CreateIndex
CREATE INDEX "ResearchTask_castleId_idx" ON "ResearchTask"("castleId");

-- CreateIndex
CREATE INDEX "ResearchTask_finishesAt_idx" ON "ResearchTask"("finishesAt");

-- CreateIndex
CREATE INDEX "HeroItem_castleId_idx" ON "HeroItem"("castleId");

-- AddForeignKey
ALTER TABLE "ArmyUnit" ADD CONSTRAINT "ArmyUnit_castleId_fkey" FOREIGN KEY ("castleId") REFERENCES "Castle"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TrainTask" ADD CONSTRAINT "TrainTask_castleId_fkey" FOREIGN KEY ("castleId") REFERENCES "Castle"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TechLevel" ADD CONSTRAINT "TechLevel_castleId_fkey" FOREIGN KEY ("castleId") REFERENCES "Castle"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ResearchTask" ADD CONSTRAINT "ResearchTask_castleId_fkey" FOREIGN KEY ("castleId") REFERENCES "Castle"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Hero" ADD CONSTRAINT "Hero_castleId_fkey" FOREIGN KEY ("castleId") REFERENCES "Castle"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "HeroItem" ADD CONSTRAINT "HeroItem_castleId_fkey" FOREIGN KEY ("castleId") REFERENCES "Castle"("id") ON DELETE CASCADE ON UPDATE CASCADE;
