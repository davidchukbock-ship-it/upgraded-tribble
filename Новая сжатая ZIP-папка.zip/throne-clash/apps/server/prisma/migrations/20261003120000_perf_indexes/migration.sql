-- CreateIndex
CREATE INDEX "EconomyEvent_worldId_createdAt_idx" ON "EconomyEvent"("worldId", "createdAt");

-- CreateIndex
CREATE INDEX "ChatReport_createdAt_idx" ON "ChatReport"("createdAt" DESC);
