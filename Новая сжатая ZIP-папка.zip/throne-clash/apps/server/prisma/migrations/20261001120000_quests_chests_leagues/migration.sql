-- AlterTable
ALTER TABLE "Castle" ADD COLUMN "power" INTEGER NOT NULL DEFAULT 0;

-- CreateTable
CREATE TABLE "InventoryItem" (
    "userId" TEXT NOT NULL,
    "key" TEXT NOT NULL,
    "count" INTEGER NOT NULL,

    CONSTRAINT "InventoryItem_pkey" PRIMARY KEY ("userId","key"),
    CONSTRAINT "InventoryItem_count_nonneg" CHECK ("count" >= 0)
);

-- CreateTable
CREATE TABLE "QuestCounter" (
    "userId" TEXT NOT NULL,
    "period" TEXT NOT NULL,
    "metric" TEXT NOT NULL,
    "value" INTEGER NOT NULL,

    CONSTRAINT "QuestCounter_pkey" PRIMARY KEY ("userId","period","metric")
);

-- CreateTable
CREATE TABLE "QuestClaim" (
    "userId" TEXT NOT NULL,
    "questId" TEXT NOT NULL,
    "period" TEXT NOT NULL,
    "claimedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "QuestClaim_pkey" PRIMARY KEY ("userId","questId","period")
);

-- CreateTable
CREATE TABLE "LoginStreak" (
    "userId" TEXT NOT NULL,
    "day" TEXT NOT NULL,
    "streak" INTEGER NOT NULL,

    CONSTRAINT "LoginStreak_pkey" PRIMARY KEY ("userId")
);

-- CreateTable
CREATE TABLE "SeasonStat" (
    "seasonId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "wins" INTEGER NOT NULL DEFAULT 0,
    "kills" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "SeasonStat_pkey" PRIMARY KEY ("seasonId","userId")
);

-- CreateTable
CREATE TABLE "Season" (
    "id" TEXT NOT NULL,
    "closedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Season_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SeasonReward" (
    "seasonId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "place" INTEGER,
    "gems" INTEGER NOT NULL,
    "chest" TEXT,
    "claimedAt" TIMESTAMP(3),

    CONSTRAINT "SeasonReward_pkey" PRIMARY KEY ("seasonId","userId")
);

-- CreateIndex
CREATE INDEX "SeasonStat_seasonId_idx" ON "SeasonStat"("seasonId");

-- CreateIndex
CREATE INDEX "SeasonReward_userId_claimedAt_idx" ON "SeasonReward"("userId", "claimedAt");

-- AddForeignKey
ALTER TABLE "InventoryItem" ADD CONSTRAINT "InventoryItem_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "QuestCounter" ADD CONSTRAINT "QuestCounter_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "QuestClaim" ADD CONSTRAINT "QuestClaim_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LoginStreak" ADD CONSTRAINT "LoginStreak_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SeasonStat" ADD CONSTRAINT "SeasonStat_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SeasonReward" ADD CONSTRAINT "SeasonReward_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
