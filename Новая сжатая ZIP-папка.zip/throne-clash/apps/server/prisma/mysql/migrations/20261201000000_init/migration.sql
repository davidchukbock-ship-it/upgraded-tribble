-- CreateTable
CREATE TABLE `World` (
    `id` VARCHAR(191) NOT NULL,
    `name` VARCHAR(191) NOT NULL,
    `seed` INTEGER NOT NULL,
    `speed` DOUBLE NOT NULL DEFAULT 1,
    `isSandbox` BOOLEAN NOT NULL DEFAULT false,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `User` (
    `id` VARCHAR(191) NOT NULL,
    `email` VARCHAR(255) NULL,
    `passwordHash` VARCHAR(191) NULL,
    `nickname` VARCHAR(191) NOT NULL,
    `nicknameKey` VARCHAR(191) NOT NULL,
    `role` ENUM('PLAYER', 'ADMIN', 'OWNER') NOT NULL DEFAULT 'PLAYER',
    `isGuest` BOOLEAN NOT NULL DEFAULT false,
    `isBot` BOOLEAN NOT NULL DEFAULT false,
    `language` VARCHAR(191) NOT NULL DEFAULT 'ru',
    `crest` VARCHAR(191) NOT NULL DEFAULT 'lion',
    `nicknameChangedAt` DATETIME(3) NULL,
    `bannedUntil` DATETIME(3) NULL,
    `banReason` TEXT NULL,
    `mutedUntil` DATETIME(3) NULL,
    `failedLogins` INTEGER NOT NULL DEFAULT 0,
    `lockedUntil` DATETIME(3) NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `lastLoginAt` DATETIME(3) NULL,

    UNIQUE INDEX `User_email_key`(`email`),
    UNIQUE INDEX `User_nicknameKey_key`(`nicknameKey`),
    INDEX `User_role_idx`(`role`),
    INDEX `User_createdAt_idx`(`createdAt`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `RefreshToken` (
    `id` VARCHAR(191) NOT NULL,
    `userId` VARCHAR(191) NOT NULL,
    `family` VARCHAR(191) NOT NULL,
    `tokenHash` VARCHAR(191) NOT NULL,
    `expiresAt` DATETIME(3) NOT NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `revokedAt` DATETIME(3) NULL,
    `userAgent` TEXT NULL,
    `ip` VARCHAR(191) NULL,

    UNIQUE INDEX `RefreshToken_tokenHash_key`(`tokenHash`),
    INDEX `RefreshToken_userId_idx`(`userId`),
    INDEX `RefreshToken_family_idx`(`family`),
    INDEX `RefreshToken_expiresAt_idx`(`expiresAt`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Castle` (
    `id` VARCHAR(191) NOT NULL,
    `worldId` VARCHAR(191) NOT NULL,
    `userId` VARCHAR(191) NOT NULL,
    `gold` INTEGER NOT NULL DEFAULT 0,
    `wood` INTEGER NOT NULL DEFAULT 0,
    `stone` INTEGER NOT NULL DEFAULT 0,
    `food` INTEGER NOT NULL DEFAULT 0,
    `gems` INTEGER NOT NULL DEFAULT 0,
    `gemsCarry` DOUBLE NOT NULL DEFAULT 0,
    `structures` JSON NOT NULL,
    `resourcesUpdatedAt` DATETIME(3) NOT NULL,
    `shieldUntil` DATETIME(3) NULL,
    `extraBuildSlot` BOOLEAN NOT NULL DEFAULT false,
    `version` INTEGER NOT NULL DEFAULT 1,
    `isGodAction` BOOLEAN NOT NULL DEFAULT false,
    `power` INTEGER NOT NULL DEFAULT 0,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `x` INTEGER NULL,
    `y` INTEGER NULL,

    INDEX `Castle_userId_idx`(`userId`),
    UNIQUE INDEX `Castle_worldId_userId_key`(`worldId`, `userId`),
    UNIQUE INDEX `Castle_worldId_x_y_key`(`worldId`, `x`, `y`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Building` (
    `id` VARCHAR(191) NOT NULL,
    `castleId` VARCHAR(191) NOT NULL,
    `key` VARCHAR(191) NOT NULL,
    `level` INTEGER NOT NULL DEFAULT 1,

    UNIQUE INDEX `Building_castleId_key_key`(`castleId`, `key`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `SecurityLog` (
    `id` VARCHAR(191) NOT NULL,
    `userId` VARCHAR(191) NULL,
    `kind` VARCHAR(191) NOT NULL,
    `ip` VARCHAR(191) NULL,
    `details` JSON NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    INDEX `SecurityLog_userId_createdAt_idx`(`userId`, `createdAt`),
    INDEX `SecurityLog_kind_createdAt_idx`(`kind`, `createdAt`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `BuildTask` (
    `id` VARCHAR(191) NOT NULL,
    `castleId` VARCHAR(191) NOT NULL,
    `buildingKey` VARCHAR(191) NOT NULL,
    `toLevel` INTEGER NOT NULL,
    `startedAt` DATETIME(3) NOT NULL,
    `finishesAt` DATETIME(3) NOT NULL,
    `paidGold` INTEGER NOT NULL,
    `paidWood` INTEGER NOT NULL,
    `paidStone` INTEGER NOT NULL,
    `paidFood` INTEGER NOT NULL,
    `isGodAction` BOOLEAN NOT NULL DEFAULT false,

    INDEX `BuildTask_castleId_idx`(`castleId`),
    INDEX `BuildTask_finishesAt_idx`(`finishesAt`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `IdempotencyKey` (
    `userId` VARCHAR(191) NOT NULL,
    `key` VARCHAR(191) NOT NULL,
    `route` VARCHAR(191) NOT NULL,
    `requestHash` VARCHAR(191) NOT NULL,
    `status` INTEGER NOT NULL,
    `body` JSON NOT NULL,
    `createdAt` DATETIME(3) NOT NULL,

    INDEX `IdempotencyKey_createdAt_idx`(`createdAt`),
    PRIMARY KEY (`userId`, `key`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `EconomyEvent` (
    `id` VARCHAR(191) NOT NULL,
    `worldId` VARCHAR(191) NOT NULL,
    `userId` VARCHAR(191) NOT NULL,
    `kind` VARCHAR(191) NOT NULL,
    `resource` VARCHAR(191) NOT NULL,
    `amount` INTEGER NOT NULL,
    `isGodAction` BOOLEAN NOT NULL DEFAULT false,
    `createdAt` DATETIME(3) NOT NULL,

    INDEX `EconomyEvent_worldId_kind_createdAt_idx`(`worldId`, `kind`, `createdAt`),
    INDEX `EconomyEvent_worldId_createdAt_idx`(`worldId`, `createdAt`),
    INDEX `EconomyEvent_userId_createdAt_idx`(`userId`, `createdAt`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `ArmyUnit` (
    `castleId` VARCHAR(191) NOT NULL,
    `unitId` VARCHAR(191) NOT NULL,
    `count` INTEGER NOT NULL DEFAULT 0,
    `wounded` INTEGER NOT NULL DEFAULT 0,

    PRIMARY KEY (`castleId`, `unitId`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `TrainTask` (
    `id` VARCHAR(191) NOT NULL,
    `castleId` VARCHAR(191) NOT NULL,
    `unitId` VARCHAR(191) NOT NULL,
    `count` INTEGER NOT NULL,
    `startedAt` DATETIME(3) NOT NULL,
    `finishesAt` DATETIME(3) NOT NULL,
    `paidGold` INTEGER NOT NULL,
    `paidWood` INTEGER NOT NULL,
    `paidStone` INTEGER NOT NULL,
    `paidFood` INTEGER NOT NULL,
    `isGodAction` BOOLEAN NOT NULL DEFAULT false,

    INDEX `TrainTask_castleId_idx`(`castleId`),
    INDEX `TrainTask_finishesAt_idx`(`finishesAt`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `TechLevel` (
    `castleId` VARCHAR(191) NOT NULL,
    `tech` VARCHAR(191) NOT NULL,
    `level` INTEGER NOT NULL,

    PRIMARY KEY (`castleId`, `tech`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `ResearchTask` (
    `id` VARCHAR(191) NOT NULL,
    `castleId` VARCHAR(191) NOT NULL,
    `tech` VARCHAR(191) NOT NULL,
    `toLevel` INTEGER NOT NULL,
    `startedAt` DATETIME(3) NOT NULL,
    `finishesAt` DATETIME(3) NOT NULL,
    `paidGold` INTEGER NOT NULL,
    `paidWood` INTEGER NOT NULL,
    `paidStone` INTEGER NOT NULL,
    `paidFood` INTEGER NOT NULL,
    `isGodAction` BOOLEAN NOT NULL DEFAULT false,

    INDEX `ResearchTask_castleId_idx`(`castleId`),
    INDEX `ResearchTask_finishesAt_idx`(`finishesAt`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Hero` (
    `castleId` VARCHAR(191) NOT NULL,
    `level` INTEGER NOT NULL DEFAULT 1,
    `xp` INTEGER NOT NULL DEFAULT 0,
    `skillCombat` INTEGER NOT NULL DEFAULT 0,
    `skillDefense` INTEGER NOT NULL DEFAULT 0,
    `skillEconomy` INTEGER NOT NULL DEFAULT 0,

    PRIMARY KEY (`castleId`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `HeroItem` (
    `id` VARCHAR(191) NOT NULL,
    `castleId` VARCHAR(191) NOT NULL,
    `slot` VARCHAR(191) NOT NULL,
    `rarity` INTEGER NOT NULL,
    `equipped` BOOLEAN NOT NULL DEFAULT false,

    INDEX `HeroItem_castleId_idx`(`castleId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `March` (
    `id` VARCHAR(191) NOT NULL,
    `castleId` VARCHAR(191) NOT NULL,
    `type` VARCHAR(191) NOT NULL,
    `targetX` INTEGER NOT NULL,
    `targetY` INTEGER NOT NULL,
    `targetCastleId` VARCHAR(191) NULL,
    `targetName` VARCHAR(191) NULL,
    `units` JSON NOT NULL,
    `wounded` JSON NOT NULL,
    `loot` JSON NOT NULL,
    `heroXp` INTEGER NOT NULL DEFAULT 0,
    `state` VARCHAR(191) NOT NULL,
    `startedAt` DATETIME(3) NOT NULL,
    `arriveAt` DATETIME(3) NOT NULL,
    `returnAt` DATETIME(3) NOT NULL,
    `reportId` VARCHAR(191) NULL,

    INDEX `March_state_arriveAt_idx`(`state`, `arriveAt`),
    INDEX `March_castleId_idx`(`castleId`),
    INDEX `March_targetCastleId_idx`(`targetCastleId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `CellState` (
    `worldId` VARCHAR(191) NOT NULL,
    `x` INTEGER NOT NULL,
    `y` INTEGER NOT NULL,
    `remaining` INTEGER NULL,
    `resetAt` DATETIME(3) NULL,

    PRIMARY KEY (`worldId`, `x`, `y`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Report` (
    `id` VARCHAR(191) NOT NULL,
    `userId` VARCHAR(191) NOT NULL,
    `worldId` VARCHAR(191) NOT NULL,
    `kind` VARCHAR(191) NOT NULL,
    `role` VARCHAR(191) NOT NULL,
    `outcome` VARCHAR(191) NOT NULL,
    `targetX` INTEGER NOT NULL,
    `targetY` INTEGER NOT NULL,
    `opponent` VARCHAR(191) NULL,
    `payload` JSON NOT NULL,
    `read` BOOLEAN NOT NULL DEFAULT false,
    `createdAt` DATETIME(3) NOT NULL,

    INDEX `Report_userId_createdAt_idx`(`userId`, `createdAt` DESC),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Guild` (
    `id` VARCHAR(191) NOT NULL,
    `worldId` VARCHAR(191) NOT NULL,
    `name` VARCHAR(191) NOT NULL,
    `nameKey` VARCHAR(191) NOT NULL,
    `description` VARCHAR(1000) NOT NULL DEFAULT '',
    `treasury` INTEGER NOT NULL DEFAULT 0,
    `createdAt` DATETIME(3) NOT NULL,

    UNIQUE INDEX `Guild_worldId_nameKey_key`(`worldId`, `nameKey`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `GuildMember` (
    `guildId` VARCHAR(191) NOT NULL,
    `userId` VARCHAR(191) NOT NULL,
    `worldId` VARCHAR(191) NOT NULL,
    `role` VARCHAR(191) NOT NULL,
    `joinedAt` DATETIME(3) NOT NULL,

    UNIQUE INDEX `GuildMember_worldId_userId_key`(`worldId`, `userId`),
    PRIMARY KEY (`guildId`, `userId`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `GuildApplication` (
    `id` VARCHAR(191) NOT NULL,
    `guildId` VARCHAR(191) NOT NULL,
    `userId` VARCHAR(191) NOT NULL,
    `createdAt` DATETIME(3) NOT NULL,

    INDEX `GuildApplication_userId_idx`(`userId`),
    UNIQUE INDEX `GuildApplication_guildId_userId_key`(`guildId`, `userId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `GuildHelp` (
    `taskId` VARCHAR(191) NOT NULL,
    `userId` VARCHAR(191) NOT NULL,
    `createdAt` DATETIME(3) NOT NULL,

    INDEX `GuildHelp_createdAt_idx`(`createdAt`),
    PRIMARY KEY (`taskId`, `userId`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `ChatMessage` (
    `id` VARCHAR(191) NOT NULL,
    `worldId` VARCHAR(191) NOT NULL,
    `channel` VARCHAR(191) NOT NULL,
    `userId` VARCHAR(191) NOT NULL,
    `text` TEXT NOT NULL,
    `createdAt` DATETIME(3) NOT NULL,

    INDEX `ChatMessage_channel_createdAt_idx`(`channel`, `createdAt` DESC),
    INDEX `ChatMessage_createdAt_idx`(`createdAt`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `ChatReport` (
    `id` VARCHAR(191) NOT NULL,
    `messageId` VARCHAR(191) NOT NULL,
    `reporterId` VARCHAR(191) NOT NULL,
    `reason` TEXT NOT NULL,
    `createdAt` DATETIME(3) NOT NULL,

    INDEX `ChatReport_createdAt_idx`(`createdAt` DESC),
    UNIQUE INDEX `ChatReport_messageId_reporterId_key`(`messageId`, `reporterId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Notification` (
    `id` VARCHAR(191) NOT NULL,
    `userId` VARCHAR(191) NOT NULL,
    `kind` VARCHAR(191) NOT NULL,
    `payload` JSON NOT NULL,
    `read` BOOLEAN NOT NULL DEFAULT false,
    `createdAt` DATETIME(3) NOT NULL,

    INDEX `Notification_userId_createdAt_idx`(`userId`, `createdAt` DESC),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `InventoryItem` (
    `userId` VARCHAR(191) NOT NULL,
    `key` VARCHAR(191) NOT NULL,
    `count` INTEGER NOT NULL,

    PRIMARY KEY (`userId`, `key`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `QuestCounter` (
    `userId` VARCHAR(191) NOT NULL,
    `period` VARCHAR(191) NOT NULL,
    `metric` VARCHAR(191) NOT NULL,
    `value` INTEGER NOT NULL,

    PRIMARY KEY (`userId`, `period`, `metric`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `QuestClaim` (
    `userId` VARCHAR(191) NOT NULL,
    `questId` VARCHAR(191) NOT NULL,
    `period` VARCHAR(191) NOT NULL,
    `claimedAt` DATETIME(3) NOT NULL,

    PRIMARY KEY (`userId`, `questId`, `period`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `LoginStreak` (
    `userId` VARCHAR(191) NOT NULL,
    `day` VARCHAR(191) NOT NULL,
    `streak` INTEGER NOT NULL,

    PRIMARY KEY (`userId`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `SeasonStat` (
    `seasonId` VARCHAR(191) NOT NULL,
    `userId` VARCHAR(191) NOT NULL,
    `wins` INTEGER NOT NULL DEFAULT 0,
    `kills` INTEGER NOT NULL DEFAULT 0,

    INDEX `SeasonStat_seasonId_idx`(`seasonId`),
    PRIMARY KEY (`seasonId`, `userId`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Season` (
    `id` VARCHAR(191) NOT NULL,
    `closedAt` DATETIME(3) NOT NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `SeasonReward` (
    `seasonId` VARCHAR(191) NOT NULL,
    `userId` VARCHAR(191) NOT NULL,
    `place` INTEGER NULL,
    `gems` INTEGER NOT NULL,
    `chest` VARCHAR(191) NULL,
    `claimedAt` DATETIME(3) NULL,

    INDEX `SeasonReward_userId_claimedAt_idx`(`userId`, `claimedAt`),
    PRIMARY KEY (`seasonId`, `userId`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `ChestLog` (
    `id` VARCHAR(191) NOT NULL,
    `userId` VARCHAR(191) NOT NULL,
    `kind` VARCHAR(191) NOT NULL,
    `reward` JSON NOT NULL,
    `createdAt` DATETIME(3) NOT NULL,

    INDEX `ChestLog_userId_createdAt_idx`(`userId`, `createdAt` DESC),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `AuditLog` (
    `id` VARCHAR(191) NOT NULL,
    `scope` VARCHAR(191) NOT NULL,
    `actorId` VARCHAR(191) NULL,
    `action` VARCHAR(191) NOT NULL,
    `targetUserId` VARCHAR(191) NULL,
    `params` JSON NULL,
    `before` JSON NULL,
    `after` JSON NULL,
    `ip` VARCHAR(191) NULL,
    `createdAt` DATETIME(3) NOT NULL,

    INDEX `AuditLog_scope_createdAt_idx`(`scope`, `createdAt` DESC),
    INDEX `AuditLog_targetUserId_createdAt_idx`(`targetUserId`, `createdAt` DESC),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `GodSession` (
    `id` VARCHAR(191) NOT NULL,
    `userId` VARCHAR(191) NOT NULL,
    `tokenHash` VARCHAR(191) NOT NULL,
    `ip` VARCHAR(191) NULL,
    `createdAt` DATETIME(3) NOT NULL,
    `lastSeenAt` DATETIME(3) NOT NULL,
    `expiresAt` DATETIME(3) NOT NULL,

    UNIQUE INDEX `GodSession_tokenHash_key`(`tokenHash`),
    INDEX `GodSession_userId_idx`(`userId`),
    INDEX `GodSession_expiresAt_idx`(`expiresAt`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `GodSnapshot` (
    `id` VARCHAR(191) NOT NULL,
    `userId` VARCHAR(191) NOT NULL,
    `label` VARCHAR(191) NOT NULL,
    `takenBy` VARCHAR(191) NOT NULL,
    `data` JSON NOT NULL,
    `createdAt` DATETIME(3) NOT NULL,

    INDEX `GodSnapshot_userId_createdAt_idx`(`userId`, `createdAt` DESC),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `BalanceRevision` (
    `id` VARCHAR(191) NOT NULL,
    `config` JSON NOT NULL,
    `actorId` VARCHAR(191) NULL,
    `note` TEXT NULL,
    `createdAt` DATETIME(3) NOT NULL,

    INDEX `BalanceRevision_createdAt_idx`(`createdAt` DESC),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `RefreshToken` ADD CONSTRAINT `RefreshToken_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Castle` ADD CONSTRAINT `Castle_worldId_fkey` FOREIGN KEY (`worldId`) REFERENCES `World`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Castle` ADD CONSTRAINT `Castle_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Building` ADD CONSTRAINT `Building_castleId_fkey` FOREIGN KEY (`castleId`) REFERENCES `Castle`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `SecurityLog` ADD CONSTRAINT `SecurityLog_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `BuildTask` ADD CONSTRAINT `BuildTask_castleId_fkey` FOREIGN KEY (`castleId`) REFERENCES `Castle`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `ArmyUnit` ADD CONSTRAINT `ArmyUnit_castleId_fkey` FOREIGN KEY (`castleId`) REFERENCES `Castle`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `TrainTask` ADD CONSTRAINT `TrainTask_castleId_fkey` FOREIGN KEY (`castleId`) REFERENCES `Castle`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `TechLevel` ADD CONSTRAINT `TechLevel_castleId_fkey` FOREIGN KEY (`castleId`) REFERENCES `Castle`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `ResearchTask` ADD CONSTRAINT `ResearchTask_castleId_fkey` FOREIGN KEY (`castleId`) REFERENCES `Castle`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Hero` ADD CONSTRAINT `Hero_castleId_fkey` FOREIGN KEY (`castleId`) REFERENCES `Castle`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `HeroItem` ADD CONSTRAINT `HeroItem_castleId_fkey` FOREIGN KEY (`castleId`) REFERENCES `Castle`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `March` ADD CONSTRAINT `March_castleId_fkey` FOREIGN KEY (`castleId`) REFERENCES `Castle`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Report` ADD CONSTRAINT `Report_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `GuildMember` ADD CONSTRAINT `GuildMember_guildId_fkey` FOREIGN KEY (`guildId`) REFERENCES `Guild`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `GuildMember` ADD CONSTRAINT `GuildMember_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `GuildApplication` ADD CONSTRAINT `GuildApplication_guildId_fkey` FOREIGN KEY (`guildId`) REFERENCES `Guild`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `GuildApplication` ADD CONSTRAINT `GuildApplication_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `ChatMessage` ADD CONSTRAINT `ChatMessage_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `ChatReport` ADD CONSTRAINT `ChatReport_reporterId_fkey` FOREIGN KEY (`reporterId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Notification` ADD CONSTRAINT `Notification_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `InventoryItem` ADD CONSTRAINT `InventoryItem_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `QuestCounter` ADD CONSTRAINT `QuestCounter_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `QuestClaim` ADD CONSTRAINT `QuestClaim_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `LoginStreak` ADD CONSTRAINT `LoginStreak_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `SeasonStat` ADD CONSTRAINT `SeasonStat_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `SeasonReward` ADD CONSTRAINT `SeasonReward_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `ChestLog` ADD CONSTRAINT `ChestLog_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

