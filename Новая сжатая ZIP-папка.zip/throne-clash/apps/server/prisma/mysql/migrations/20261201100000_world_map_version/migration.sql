-- Версия генератора карты мира (D-74): существующий мир остаётся на карте v1
ALTER TABLE `World` ADD COLUMN `mapVersion` INTEGER NOT NULL DEFAULT 1;
