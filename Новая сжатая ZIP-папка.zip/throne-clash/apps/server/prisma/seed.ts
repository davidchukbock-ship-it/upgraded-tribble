import { PrismaClient } from '@prisma/client';
import { randomBytes } from 'node:crypto';
import { loadConfig } from '../src/config/env';
import { seedDatabase } from '../src/db/seed';

for (const path of ['.env', '../../.env']) {
  try {
    process.loadEnvFile(path);
    break;
  } catch {
    /* нет файла — идём дальше */
  }
}

/**
 * Запуск:  pnpm seed
 * Демо-игроки (demo1..3@example.com) создаются в development/test; в production — только с SEED_DEMO=true.
 * Пароль берётся из SEED_DEMO_PASSWORD, иначе генерируется случайный и печатается один раз.
 */
async function main(): Promise<void> {
  const config = loadConfig();
  const prisma = new PrismaClient({ datasourceUrl: config.databaseUrl });
  try {
    const wantDemo = process.env['SEED_DEMO'] === 'true' || !config.isProduction;
    const generated = randomBytes(9).toString('base64url');
    const password = process.env['SEED_DEMO_PASSWORD'] ?? generated;
    const result = await seedDatabase(prisma, {
      seed: config.worldSeed,
      demoPlayers: wantDemo ? { password } : null,
    });
    console.log(`Seed: создано ботов — ${result.bots}, демо-игроков — ${result.demos}.`);
    if (result.demos > 0) {
      console.log(`Демо-аккаунты: demo1@example.com … demo3@example.com`);
      console.log(
        process.env['SEED_DEMO_PASSWORD']
          ? 'Пароль: значение SEED_DEMO_PASSWORD.'
          : `Пароль (показан один раз): ${password}`,
      );
    }
  } finally {
    await prisma.$disconnect();
  }
}

main().catch((e: unknown) => {
  console.error(e instanceof Error ? e.message : e);
  process.exit(1);
});
