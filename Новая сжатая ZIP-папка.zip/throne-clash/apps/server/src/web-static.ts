import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import fastifyStatic from '@fastify/static';
import type { FastifyInstance } from 'fastify';

/** Политика содержимого для страниц игры (та же, что в nginx-конфиге: пока только отчёты). */
const CSP_REPORT_ONLY =
  "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; font-src 'self'; connect-src 'self' ws: wss:; frame-ancestors 'none'; base-uri 'self'; form-action 'self'";

const API_PREFIXES = ['/api/', '/ws', '/health', '/docs'];

/**
 * Отдаёт собранный сайт (apps/web/dist) с того же адреса, что и API. Нужен там, где нет nginx
 * (например, Node.js-хостинг). Включается переменной WEB_DIST; возвращает false, если каталога нет.
 */
export async function registerWeb(app: FastifyInstance, dir: string): Promise<boolean> {
  const root = resolve(dir);
  if (!existsSync(resolve(root, 'index.html'))) return false;

  await app.register(async (web) => {
    // У API строгая политика «ничего нельзя» (helmet), для страниц она заменяется своей
    web.addHook('onSend', async (_req, reply) => {
      reply.removeHeader('content-security-policy');
      reply.header('content-security-policy-report-only', CSP_REPORT_ONLY);
      reply.header('x-frame-options', 'DENY');
      reply.header('referrer-policy', 'strict-origin-when-cross-origin');
      reply.header('permissions-policy', 'camera=(), microphone=(), geolocation=()');
    });
    // wildcard: false — файлы известны заранее (сайт собран до запуска); свой обработчик 404 у корня уже занят
    await web.register(fastifyStatic, {
      root,
      wildcard: false,
      index: 'index.html',
      cacheControl: false,
      setHeaders: (res, path) => {
        res.setHeader(
          'cache-control',
          path.includes('/assets/') ? 'public, max-age=31536000, immutable' : 'no-cache',
        );
      },
    });
    // Любой другой адрес страницы (не API) отдаёт приложение — маршруты react-router
    web.get('/*', async (req, reply) => {
      const path = req.url.split('?')[0] ?? '/';
      const isApi = API_PREFIXES.some((p) => path === p.replace(/\/$/, '') || path.startsWith(p));
      if (isApi) {
        return reply.code(404).send({ statusCode: 404, error: 'Not Found', message: 'Not found' });
      }
      return reply
        .type('text/html; charset=utf-8')
        .header('cache-control', 'no-cache')
        .sendFile('index.html');
    });
  });
  return true;
}
