import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import type { Role } from '@tc/shared';
import { Errors } from '../lib/errors';
import type { AccessTokenService } from '../lib/tokens';
import { effectiveRole } from '../modules/auth/auth.service';
import type { UserRecord, UserRepository } from '../modules/auth/auth.types';
import type { Clock } from '../lib/clock';

export interface AuthContext {
  user: UserRecord;
  /** Роль с учётом OWNER_EMAIL (см. effectiveRole). Права проверяем по ней, не по user.role. */
  role: Role;
  /** Владелец, действующий от имени этого игрока (вход из режима бога); действия пишутся в аудит. */
  impersonatedBy?: string;
}

declare module 'fastify' {
  interface FastifyRequest {
    auth?: AuthContext;
  }
}

const RANK: Record<Role, number> = { PLAYER: 0, ADMIN: 1, OWNER: 2 };

export interface AuthenticateDeps {
  tokens: AccessTokenService;
  users: UserRepository;
  clock: Clock;
  ownerEmail: string;
  /** Вызывается на каждый изменяющий запрос после проверки токена; может бросить (ограничение частоты). */
  onMutation?: (req: FastifyRequest, user: UserRecord) => void;
}

export type PreHandler = (req: FastifyRequest, reply: FastifyReply) => Promise<void>;

/**
 * Проверка access-токена. Пользователя каждый раз читаем из БД (по первичному ключу):
 * бан и понижение роли действуют немедленно, а не когда истечёт токен (D-20).
 */
export function createAuthGuards(deps: AuthenticateDeps): {
  authenticate: PreHandler;
  requireRole: (min: Role) => PreHandler;
} {
  const authenticate: PreHandler = async (req) => {
    const header = req.headers.authorization;
    const match =
      typeof header === 'string' ? /^Bearer ([\w-]+\.[\w-]+\.[\w-]+)$/.exec(header) : null;
    if (!match?.[1]) throw Errors.unauthorized();

    const now = deps.clock.now();
    const claims = await deps.tokens.verify(match[1], now);
    if (!claims) throw Errors.unauthorized();

    const user = await deps.users.findById(claims.userId);
    if (!user) throw Errors.unauthorized();
    if (user.bannedUntil && user.bannedUntil > now) {
      throw Errors.banned({ until: user.bannedUntil.toISOString(), reason: user.banReason });
    }
    req.auth = {
      user,
      role: effectiveRole(user, deps.ownerEmail),
      ...(claims.actorId && { impersonatedBy: claims.actorId }),
    };
    if (req.method !== 'GET' && req.method !== 'HEAD' && req.method !== 'OPTIONS')
      deps.onMutation?.(req, user);
  };

  const requireRole =
    (min: Role): PreHandler =>
    async (req, reply) => {
      await authenticate(req, reply);
      if (!req.auth || RANK[req.auth.role] < RANK[min]) throw Errors.forbidden();
    };

  return { authenticate, requireRole };
}

/** Регистрирует guards как декораторы приложения — доступны в модулях как app.authenticate. */
export function decorateAuth(app: FastifyInstance, deps: AuthenticateDeps): void {
  const guards = createAuthGuards(deps);
  app.decorate('authenticate', guards.authenticate);
  app.decorate('requireRole', guards.requireRole);
}

declare module 'fastify' {
  interface FastifyInstance {
    authenticate: PreHandler;
    requireRole: (min: Role) => PreHandler;
  }
}
