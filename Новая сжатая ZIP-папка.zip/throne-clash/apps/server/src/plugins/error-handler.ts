import type { FastifyError, FastifyInstance, FastifyRequest } from 'fastify';
import { hasZodFastifySchemaValidationErrors } from 'fastify-type-provider-zod';
import { ZodError } from 'zod';
import { ERROR_CODES } from '@tc/shared';
import { AppError, type ErrorBody } from '../lib/errors';

/** Единый формат ошибок: { error: { code, message, details? }, requestId }. Внутренности клиенту не отдаём. */
export interface ErrorHooks {
  /** Событие для журнала безопасности: превышение лимита плагином и повтор ключа идемпотентности с другим телом. */
  onSecurity?: (kind: 'rate_limited' | 'idempotency_mismatch', req: FastifyRequest) => void;
}

export function registerErrorHandling(app: FastifyInstance, hooks: ErrorHooks = {}): void {
  app.setNotFoundHandler((req, reply) => {
    const body: ErrorBody = {
      error: { code: ERROR_CODES.NOT_FOUND, message: 'Route not found' },
      requestId: req.id,
    };
    return reply.code(404).send(body);
  });

  app.setErrorHandler((err: FastifyError | Error, req, reply) => {
    let status = 500;
    let code: ErrorBody['error']['code'] = ERROR_CODES.INTERNAL;
    let message = 'Internal server error';
    let details: unknown;

    if (err instanceof AppError) {
      status = err.statusCode;
      code = err.code;
      message = err.message;
      details = err.details;
      if (code === ERROR_CODES.IDEMPOTENCY_MISMATCH)
        hooks.onSecurity?.('idempotency_mismatch', req);
    } else if (hasZodFastifySchemaValidationErrors(err)) {
      status = 400;
      code = ERROR_CODES.VALIDATION;
      message = 'Validation failed';
      details = err.validation.map((v) => ({ path: v.instancePath || '/', message: v.message }));
    } else if (err instanceof ZodError) {
      status = 400;
      code = ERROR_CODES.VALIDATION;
      message = 'Validation failed';
      details = err.issues.map((i) => ({ path: i.path.join('.'), message: i.message }));
    } else if ('statusCode' in err && err.statusCode === 429) {
      status = 429;
      code = ERROR_CODES.RATE_LIMITED;
      message = 'Too many requests';
      hooks.onSecurity?.('rate_limited', req);
    } else if (
      'statusCode' in err &&
      typeof err.statusCode === 'number' &&
      err.statusCode >= 400 &&
      err.statusCode < 500
    ) {
      // Ошибки разбора запроса (битый JSON, слишком большое тело и т. п.)
      status = err.statusCode;
      code = ERROR_CODES.VALIDATION;
      message = 'Bad request';
    }

    if (status >= 500) req.log.error({ err }, 'unhandled error');
    else req.log.info({ code, status }, 'request rejected');

    const body: ErrorBody = {
      error: { code, message, ...(details !== undefined ? { details } : {}) },
      requestId: req.id,
    };
    return reply.code(status).send(body);
  });
}
