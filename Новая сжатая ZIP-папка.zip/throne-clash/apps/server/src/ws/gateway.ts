import websocket from '@fastify/websocket';
import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import type { WsServerMessage } from '@tc/shared';
import type { Clock } from '../lib/clock';
import { AppError } from '../lib/errors';
import type { AccessTokenService } from '../lib/tokens';
import type { UserRepository } from '../modules/auth/auth.types';
import type { ChatService } from '../modules/social/chat.service';
import type { Hub } from '../modules/social/hub';

const AUTH_TIMEOUT_MS = 10_000;
const HEARTBEAT_MS = 30_000;
export const WS_MAX_PAYLOAD = 4096;

const clientMessage = z.discriminatedUnion('type', [
  z.object({ type: z.literal('auth'), token: z.string().max(2048) }),
  z.object({
    type: z.literal('chat.send'),
    channel: z.string().max(80),
    text: z.string().max(2000),
  }),
  z.object({ type: z.literal('ping') }),
]);

export interface GatewayDeps {
  hub: Hub;
  chat: ChatService;
  tokens: AccessTokenService;
  users: UserRepository;
  clock: Clock;
  /** Интервалы можно сократить в тестах. */
  authTimeoutMs?: number;
  heartbeatMs?: number;
}

/**
 * WebSocket `/ws` (D-10, D-42). Соединение анонимно, пока первым сообщением не придёт `{type:'auth', token}`;
 * cookie не используются, поэтому подделать запрос со стороннего сайта нельзя. Не прошедшее аутентификацию
 * соединение закрывается через 10 секунд. Размер сообщения — не больше 4 КБ.
 */
export async function registerGateway(app: FastifyInstance, deps: GatewayDeps): Promise<void> {
  await app.register(websocket, { options: { maxPayload: WS_MAX_PAYLOAD } });

  app.get('/ws', { websocket: true }, (socket) => {
    let userId: string | null = null;
    let unsubscribe: (() => void) | null = null;
    let alive = true;

    const send = (msg: WsServerMessage): void => {
      if (socket.readyState === socket.OPEN) socket.send(JSON.stringify(msg));
    };
    const fail = (err: unknown): void => {
      if (err instanceof AppError) {
        const d = err.details as { retryAfterSeconds?: number } | undefined;
        send({
          type: 'error',
          code: err.code,
          ...(d?.retryAfterSeconds ? { retryAfterSeconds: d.retryAfterSeconds } : {}),
        });
      } else {
        send({ type: 'error', code: 'ERR_INTERNAL' });
      }
    };

    const authTimer = setTimeout(() => {
      if (!userId) socket.close(4001, 'auth timeout');
    }, deps.authTimeoutMs ?? AUTH_TIMEOUT_MS);
    const heartbeat = setInterval(() => {
      if (!alive) return socket.terminate();
      alive = false;
      socket.ping();
    }, deps.heartbeatMs ?? HEARTBEAT_MS);
    socket.on('pong', () => {
      alive = true;
    });

    const authenticate = async (token: string): Promise<void> => {
      const now = deps.clock.now();
      const claims = await deps.tokens.verify(token, now);
      const user = claims ? await deps.users.findById(claims.userId) : null;
      if (!user || (user.bannedUntil && user.bannedUntil > now)) {
        send({ type: 'error', code: 'ERR_UNAUTHORIZED' });
        return socket.close(4003, 'unauthorized');
      }
      // Повторная аутентификация (после обновления токена) допустима только для того же игрока
      if (userId && userId !== user.id) {
        send({ type: 'error', code: 'ERR_FORBIDDEN' });
        return;
      }
      if (!userId) {
        userId = user.id;
        unsubscribe = deps.hub.add(user.id, send, () => socket.close(4003, 'banned'));
        clearTimeout(authTimer);
        deps.hub.toAll({ type: 'presence', online: deps.hub.online });
      }
      send({ type: 'ready', userId: user.id, online: deps.hub.online });
    };

    socket.on('message', (raw: Buffer) => {
      void (async () => {
        let msg: z.infer<typeof clientMessage>;
        try {
          msg = clientMessage.parse(JSON.parse(raw.toString('utf8')));
        } catch {
          return send({ type: 'error', code: 'ERR_VALIDATION' });
        }
        try {
          if (msg.type === 'ping') return send({ type: 'pong' });
          if (msg.type === 'auth') return await authenticate(msg.token);
          if (!userId) {
            send({ type: 'error', code: 'ERR_UNAUTHORIZED' });
            return;
          }
          await deps.chat.send(userId, msg.channel, msg.text);
        } catch (err) {
          fail(err);
        }
      })();
    });

    socket.on('close', () => {
      clearTimeout(authTimer);
      clearInterval(heartbeat);
      if (unsubscribe) {
        unsubscribe();
        deps.hub.toAll({ type: 'presence', online: deps.hub.online });
      }
    });
    socket.on('error', () => socket.terminate());
  });
}
