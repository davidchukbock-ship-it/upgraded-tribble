import { randomUUID } from 'node:crypto';
import cookie from '@fastify/cookie';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import { registerWeb } from './web-static';
import rateLimit from '@fastify/rate-limit';
import swagger from '@fastify/swagger';
import swaggerUi from '@fastify/swagger-ui';
import Fastify, { type FastifyInstance } from 'fastify';
import {
  jsonSchemaTransform,
  serializerCompiler,
  validatorCompiler,
} from 'fastify-type-provider-zod';
import type { Redis } from 'ioredis';
import type { AppConfig } from './config/env';
import type { Clock } from './lib/clock';
import { AccessTokenService } from './lib/tokens';
import { registerAuthRoutes } from './modules/auth/auth.controller';
import { AuthService } from './modules/auth/auth.service';
import { registerCastleRoutes } from './modules/castle/castle.controller';
import { CastleService } from './modules/castle/castle.service';
import { ArmyService } from './modules/army/army.service';
import { registerArmyRoutes } from './modules/army/army.controller';
import { ResearchService } from './modules/research/research.service';
import { registerResearchRoutes } from './modules/research/research.controller';
import { HeroService } from './modules/hero/hero.service';
import { registerHeroRoutes } from './modules/hero/hero.controller';
import { ChestService } from './modules/progress/chest.service';
import { LeagueService } from './modules/progress/league.service';
import { registerProgressRoutes } from './modules/progress/progress.controller';
import { crestKey } from './modules/progress/progress.types';
import { FreePackService } from './modules/progress/freepack.service';
import { QuestService } from './modules/progress/quest.service';
import { DonateService } from './modules/progress/donate.service';
import { ShopService } from './modules/progress/shop.service';
import { MutationGuard, SecurityLogger } from './modules/abuse/abuse';
import { registerAdminRoutes } from './modules/admin/admin.controller';
import { AdminService } from './modules/admin/admin.service';
import { argonHasher } from './modules/auth/auth.service';
import { BalanceService } from './modules/god/balance.service';
import { GodAuth } from './modules/god/god.auth';
import { registerGodRoutes } from './modules/god/god.controller';
import { GodService } from './modules/god/god.service';
import { registerGateway } from './ws/gateway';
import { ChatService } from './modules/social/chat.service';
import { GuildService } from './modules/social/guild.service';
import { Hub } from './modules/social/hub';
import { NotificationService } from './modules/social/notification.service';
import { registerSocialRoutes } from './modules/social/social.controller';
import { registerMarchRoutes } from './modules/march/march.controller';
import { MapService } from './modules/march/map.service';
import { MarchResolver } from './modules/march/march.resolver';
import { MarchService } from './modules/march/march.service';
import { ReportService } from './modules/march/report.service';
import type { Repositories } from './repositories';
import { decorateAuth } from './plugins/authenticate';
import { registerHealthRoutes } from './modules/health/health.controller';
import { HealthService, type Probe } from './modules/health/health.service';
import { registerErrorHandling } from './plugins/error-handler';

export interface AppDeps {
  clock: Clock;
  probes: Probe[];
  /** Redis для лимитов запросов; без него лимиты считаются в памяти процесса (тесты, dev). */
  redis?: Redis;
  /** Доступ к данным: Prisma в боевом запуске, in-memory в юнит-тестах (D-07). */
  repos: Repositories;
  /** Реестр WebSocket-соединений; создаётся в приложении, если не передан (main.ts делит его с фоновыми задачами). */
  hub?: Hub;
  /** Пересоздание ботов и демо-игроков для панели отладки режима бога (боевой запуск подключает Prisma). */
  reseed?: () => Promise<{ bots: number; demos: number }>;
  /** Сокращённые интервалы шлюза для тестов. */
  ws?: { authTimeoutMs?: number; heartbeatMs?: number };
}

const REQUEST_ID_RE = /^[\w-]{8,64}$/;

export interface AppServices {
  hub: Hub;
  castle: CastleService;
  resolver: MarchResolver;
  leagues: LeagueService;
  balance: BalanceService;
  logger: SecurityLogger;
}

declare module 'fastify' {
  interface FastifyInstance {
    services: AppServices;
  }
}

export async function buildApp(config: AppConfig, deps: AppDeps): Promise<FastifyInstance> {
  const app = Fastify({
    logger:
      config.logLevel === 'silent'
        ? false
        : {
            level: config.logLevel,
            redact: [
              'req.headers.authorization',
              'req.headers.cookie',
              'res.headers["set-cookie"]',
            ],
            ...(config.isProduction
              ? {}
              : {
                  transport: {
                    target: 'pino-pretty',
                    options: { translateTime: 'SYS:HH:MM:ss', ignore: 'pid,hostname' },
                  },
                }),
          },
    trustProxy: config.trustProxy,
    bodyLimit: 64 * 1024,
    // requestId: принимаем от прокси только безопасный формат, иначе генерируем свой
    genReqId: (req) => {
      const incoming = req.headers['x-request-id'];
      return typeof incoming === 'string' && REQUEST_ID_RE.test(incoming) ? incoming : randomUUID();
    },
  });

  app.setValidatorCompiler(validatorCompiler);
  app.setSerializerCompiler(serializerCompiler);

  await app.register(helmet, {
    // API отдаёт только JSON — запрещаем всё; страницу /docs Swagger UI настраивает сам
    contentSecurityPolicy: { directives: { defaultSrc: ["'none'"], frameAncestors: ["'none'"] } },
    crossOriginResourcePolicy: { policy: 'same-site' },
  });
  await app.register(cors, {
    origin: config.corsOrigins,
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: [
      'Authorization',
      'Content-Type',
      'Idempotency-Key',
      'X-CSRF-Token',
      'X-Request-Id',
    ],
    exposedHeaders: ['X-Request-Id', 'X-Server-Time', 'Retry-After'],
    maxAge: 600,
  });
  await app.register(cookie);
  await app.register(rateLimit, {
    global: true,
    max: config.rateLimitMax,
    timeWindow: config.rateLimitWindow,
    ...(deps.redis ? { redis: deps.redis, nameSpace: 'tc:rl:' } : {}),
    // Сбой Redis не должен останавливать игру: лимитер «открывается»
    skipOnError: true,
    errorResponseBuilder: (_req, ctx) =>
      Object.assign(new Error('Too many requests'), { statusCode: 429, retryAfter: ctx.after }),
  });

  if (config.swaggerEnabled) {
    await app.register(swagger, {
      openapi: {
        info: {
          title: 'Throne Clash API',
          version: '0.1.0',
          description: 'Серверно-авторитетная стратегия. Ошибки — по кодам ERR_*.',
        },
        components: {
          securitySchemes: { bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' } },
        },
      },
      transform: jsonSchemaTransform,
    });
    await app.register(swaggerUi, { routePrefix: '/docs' });
  }

  const logger = new SecurityLogger(deps.repos.security, deps.clock, (err) =>
    app.log.error({ err }, 'security log failed'),
  );
  registerErrorHandling(app, {
    onSecurity: (kind, req) =>
      logger.log(kind, { userId: req.auth?.user.id, ip: req.ip }, { path: req.url.split('?')[0] }),
  });

  app.addHook('onSend', async (req, reply) => {
    reply.header('X-Request-Id', req.id);
    reply.header('X-Server-Time', deps.clock.now().toISOString());
  });

  registerHealthRoutes(app, new HealthService(deps.probes, deps.clock));

  const mutations = new MutationGuard(config.actionRateMax, 10, deps.clock, logger);
  const tokens = new AccessTokenService(config.jwtAccessSecret, config.jwtAccessTtlSeconds);
  decorateAuth(app, {
    tokens,
    users: deps.repos.users,
    clock: deps.clock,
    ownerEmail: config.ownerEmail,
    onMutation: (req, user) => mutations.check(req, user),
  });
  const auth = new AuthService({
    repos: deps.repos,
    tokens,
    clock: deps.clock,
    refreshTtlDays: config.refreshTtlDays,
    ownerEmail: config.ownerEmail,
    crestOwned: (userId, crest) =>
      deps.repos.castles.transaction(
        async (tx) => ((await tx.progress.inventory(userId))[crestKey(crest)] ?? 0) > 0,
      ),
  });
  const hub = deps.hub ?? new Hub();
  const notifications = new NotificationService({ repo: deps.repos.castles, hub });
  // Прибывшие походы разрешаются перед любым чтением и изменением замка, которого они касаются
  const resolver = new MarchResolver({
    repo: deps.repos.castles,
    clock: deps.clock,
    onNotify: (userId, notes) => notifications.deliver(userId, notes),
    log: (msg, err) => app.log.error({ err }, msg),
  });
  const castle = new CastleService({
    repo: deps.repos.castles,
    clock: deps.clock,
    before: async (userId) => void (await resolver.resolveFor(userId)),
    onNotify: (userId, notes) => notifications.deliver(userId, notes),
  });
  const chat = new ChatService({
    repo: deps.repos.castles,
    users: deps.repos.users,
    clock: deps.clock,
    hub,
    notifications,
    logger,
  });
  const progressDeps = { runner: castle.runner, repo: deps.repos.castles, clock: deps.clock };
  const leagues = new LeagueService({
    ...progressDeps,
    cacheMs: config.leagueCacheSeconds * 1000,
    onNotify: (userId, notes) => notifications.deliver(userId, notes),
  });
  const balance = new BalanceService({ repo: deps.repos.castles, clock: deps.clock });
  app.decorate('services', { hub, castle, resolver, leagues, balance, logger });

  const admin = new AdminService({
    repo: deps.repos.castles,
    users: deps.repos.users,
    sessions: deps.repos.sessions,
    security: deps.repos.security,
    runner: castle.runner,
    hub,
    clock: deps.clock,
    ownerEmail: config.ownerEmail,
  });
  const godAuth = new GodAuth({
    repo: deps.repos.castles,
    security: deps.repos.security,
    logger,
    hasher: argonHasher,
    clock: deps.clock,
    passwordHash: config.godMode.passwordHash,
    totpSecret: config.godMode.totpSecret,
    sessionMinutes: config.godMode.sessionMinutes,
  });
  const god = new GodService({
    repo: deps.repos.castles,
    runner: castle.runner,
    users: deps.repos.users,
    tokens,
    chat,
    hub,
    clock: deps.clock,
    ownerEmail: config.ownerEmail,
    redis: async () =>
      deps.redis
        ? await deps.redis.ping().then(
            () => 'ok' as const,
            () => 'error' as const,
          )
        : 'off',
    ...(deps.reseed && { reseed: deps.reseed }),
  });

  // Действия, совершённые под чужим аккаунтом (вход из режима бога), пишутся в аудит после ответа
  app.addHook('onResponse', async (req, reply) => {
    const by = req.auth?.impersonatedBy;
    if (!by || req.method === 'GET' || req.method === 'HEAD' || req.method === 'OPTIONS') return;
    try {
      await deps.repos.castles.transaction((tx) =>
        tx.admin.addAudit({
          id: randomUUID(),
          scope: 'god',
          actorId: by,
          action: 'impersonated_request',
          targetUserId: req.auth!.user.id,
          params: { method: req.method, path: req.url.split('?')[0], status: reply.statusCode },
          before: null,
          after: null,
          ip: req.ip,
          createdAt: deps.clock.now(),
        }),
      );
    } catch (err) {
      app.log.error({ err }, 'impersonation audit failed');
    }
  });

  await registerGateway(app, {
    hub,
    chat,
    tokens,
    users: deps.repos.users,
    clock: deps.clock,
    ...deps.ws,
  });

  await app.register(
    async (api) => {
      registerAuthRoutes(api, { service: auth, config, clock: deps.clock });
      registerCastleRoutes(api, castle);
      registerArmyRoutes(api, new ArmyService(castle.runner), castle);
      registerResearchRoutes(api, new ResearchService(castle.runner), castle);
      registerHeroRoutes(api, new HeroService(castle.runner), castle);
      const shared = { repo: deps.repos.castles, clock: deps.clock };
      registerMarchRoutes(api, {
        march: new MarchService({ runner: castle.runner, ...shared }),
        map: new MapService(shared),
        reports: new ReportService(shared),
        castle,
        before: async (userId) => void (await resolver.resolveFor(userId)),
      });
      registerProgressRoutes(api, {
        quests: new QuestService({
          ...progressDeps,
          before: async (userId) => void (await resolver.resolveFor(userId)),
        }),
        freePacks: new FreePackService(progressDeps),
        chests: new ChestService(progressDeps),
        shop: new ShopService(progressDeps),
        donate: new DonateService({
          runner: progressDeps.runner,
          repo: progressDeps.repo,
          clock: progressDeps.clock,
          mode: config.paymentsMode,
        }),
        leagues,
      });
      registerAdminRoutes(api, {
        service: admin,
        hub,
        onDenied: (req) =>
          logger.log(
            'admin_denied',
            { userId: req.auth?.user.id, ip: req.ip },
            {
              path: req.url.split('?')[0],
            },
          ),
      });
      registerGodRoutes(api, {
        config,
        clock: deps.clock,
        auth: godAuth,
        service: god,
        admin,
        balance,
      });
      registerSocialRoutes(api, {
        guilds: new GuildService({ runner: castle.runner, notifications, ...shared }),
        chat,
        notifications,
      });
    },
    { prefix: '/api' },
  );

  if (config.webDist) await registerWeb(app, config.webDist);
  return app;
}
