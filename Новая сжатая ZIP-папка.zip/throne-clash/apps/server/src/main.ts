import { PrismaClient } from '@prisma/client';
import { Redis } from 'ioredis';
import { buildApp } from './app';
import { loadConfig } from './config/env';
import { systemClock } from './lib/clock';
import { scheduleMaintenance } from './lib/maintenance';
import { createPrismaRepositories } from './modules/auth/auth.repository';
import { ensureMainWorld } from './db/bootstrap';
import { seedDatabase } from './db/seed';
import { MarchResolver } from './modules/march/march.resolver';

/** Подхватывает .env при локальном запуске (в Docker переменные приходят из compose). */
function loadDotEnv(): void {
  for (const path of ['.env', '../../.env']) {
    try {
      process.loadEnvFile(path);
      return;
    } catch {
      /* файла нет — идём дальше */
    }
  }
}

async function main(): Promise<void> {
  loadDotEnv();
  const config = loadConfig();
  const prisma = new PrismaClient({ datasourceUrl: config.databaseUrl });
  // REDIS_URL=none — работа без Redis (локальная разработка без Docker): лимиты запросов хранятся в памяти
  const useRedis = config.redisUrl !== 'none';
  // lazyConnect + ограниченные повторы: недоступный Redis не должен подвешивать запросы
  const redis = useRedis
    ? new Redis(config.redisUrl, {
        lazyConnect: true,
        maxRetriesPerRequest: 1,
        enableOfflineQueue: false,
      })
    : null;
  redis?.on('error', () => undefined); // ошибки видны через /health, не роняем процесс
  await redis?.connect().catch(() => undefined);

  await ensureMainWorld(prisma, config.worldSeed, config.mapVersion);

  const repos = createPrismaRepositories(prisma);
  const app = await buildApp(config, {
    clock: systemClock,
    repos,
    reseed: () => seedDatabase(prisma, { seed: config.worldSeed }),
    ...(redis ? { redis } : {}),
    probes: [
      { name: 'db', check: async () => void (await prisma.$queryRaw`SELECT 1`) },
      ...(redis ? [{ name: 'redis' as const, check: async () => void (await redis.ping()) }] : []),
    ],
  });

  // Походы разрешаются и по таймеру: игрок, чью защиту атаковали, может не заходить в игру
  const resolver = new MarchResolver({
    repo: repos.castles,
    clock: systemClock,
    log: (msg, err) => app.log.error({ err }, msg),
  });
  const marchTimer = setInterval(() => void resolver.resolveAll().catch(() => undefined), 5000);
  marchTimer.unref();

  // Офлайн-игрокам тоже приходят уведомления о завершённых стройках: раз в 5 секунд «читаем» замки с достроенным
  const dueTimer = setInterval(
    () => void app.services.castle.runner.settleDue().catch(() => undefined),
    5000,
  );
  dueTimer.unref();

  // Баланс из режима бога: подхватываем при старте и по таймеру (ревизию мог изменить другой экземпляр)
  await app.services.balance
    .reload()
    .catch((err: unknown) => app.log.error({ err }, 'balance load failed'));
  const balanceTimer = setInterval(
    () => void app.services.balance.reload().catch(() => undefined),
    30_000,
  );
  balanceTimer.unref();

  // Сезоны лиг закрываются по расписанию (пн 00:00 UTC): раз в минуту проверяем, не пора ли раздать призы
  const seasonTimer = setInterval(
    () => void app.services.leagues.closeDue().catch(() => undefined),
    60_000,
  );
  seasonTimer.unref();

  const stopMaintenance = scheduleMaintenance(repos, systemClock, (msg, err) =>
    err ? app.log.error({ err }, msg) : app.log.info(msg),
  );

  const shutdown = async (signal: string): Promise<void> => {
    app.log.info({ signal }, 'shutting down');
    stopMaintenance();
    clearInterval(marchTimer);
    clearInterval(dueTimer);
    clearInterval(seasonTimer);
    clearInterval(balanceTimer);
    await app.close();
    await prisma.$disconnect();
    redis?.disconnect();
    process.exit(0);
  };
  process.on('SIGINT', () => void shutdown('SIGINT'));
  process.on('SIGTERM', () => void shutdown('SIGTERM'));

  await app.listen({ host: config.host, port: config.port });
}

main().catch((err: unknown) => {
  console.error(err instanceof Error ? err.message : err);
  process.exit(1);
});
