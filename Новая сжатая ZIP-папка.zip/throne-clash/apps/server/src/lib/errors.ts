import { ERROR_CODES, type ErrorCode } from '@tc/shared';

/** Ожидаемая ошибка игры: код + HTTP-статус. Всё остальное — 500 без подробностей клиенту. */
export class AppError extends Error {
  constructor(
    readonly code: ErrorCode,
    readonly statusCode: number,
    message?: string,
    readonly details?: unknown,
  ) {
    super(message ?? code);
    this.name = 'AppError';
  }
}

export const Errors = {
  validation: (details?: unknown) =>
    new AppError(ERROR_CODES.VALIDATION, 400, 'Validation failed', details),
  unauthorized: () => new AppError(ERROR_CODES.UNAUTHORIZED, 401, 'Authentication required'),
  forbidden: () => new AppError(ERROR_CODES.FORBIDDEN, 403, 'Forbidden'),
  notFound: (what = 'Resource') => new AppError(ERROR_CODES.NOT_FOUND, 404, `${what} not found`),
  conflict: (message = 'Conflict') => new AppError(ERROR_CODES.CONFLICT, 409, message),
  insufficientResources: (details?: unknown) =>
    new AppError(ERROR_CODES.INSUFFICIENT_RESOURCES, 422, 'Insufficient resources', details),
  queueFull: () => new AppError(ERROR_CODES.QUEUE_FULL, 422, 'Queue is full'),
  invalidCredentials: () =>
    new AppError(ERROR_CODES.INVALID_CREDENTIALS, 401, 'Invalid email or password'),
  banned: (details?: unknown) =>
    new AppError(ERROR_CODES.BANNED, 403, 'Account is banned', details),
  emailTaken: () => new AppError(ERROR_CODES.EMAIL_TAKEN, 409, 'Email is already registered'),
  nicknameTaken: () => new AppError(ERROR_CODES.NICKNAME_TAKEN, 409, 'Nickname is already taken'),
  /** Временная блокировка (подбор пароля и т. п.): клиенту сообщаем, сколько ждать. */
  locked: (retryAfterSeconds: number) =>
    new AppError(ERROR_CODES.RATE_LIMITED, 429, 'Too many attempts', { retryAfterSeconds }),
  idempotencyMismatch: () =>
    new AppError(
      ERROR_CODES.IDEMPOTENCY_MISMATCH,
      422,
      'Idempotency-Key was used for another request',
    ),
  shieldActive: (details?: unknown) =>
    new AppError(ERROR_CODES.SHIELD_ACTIVE, 422, 'Target is under a shield', details),
  requirementNotMet: (details?: unknown) =>
    new AppError(ERROR_CODES.REQUIREMENT_NOT_MET, 422, 'Requirement not met', details),
};

export interface ErrorBody {
  error: { code: ErrorCode; message: string; details?: unknown };
  requestId: string;
}
