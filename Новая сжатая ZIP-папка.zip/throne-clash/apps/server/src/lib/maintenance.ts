import type { Repositories } from '../repositories';
import type { Clock } from './clock';

const DAY_MS = 24 * 3600_000;

/** Уборка устаревших данных: истёкшие refresh-токены и ключи идемпотентности старше 24 часов. */
export async function runMaintenance(
  repos: Pick<Repositories, 'sessions' | 'castles'>,
  clock: Clock,
): Promise<{
  sessions: number;
  idempotencyKeys: number;
  chat: number;
  notifications: number;
  godSessions: number;
}> {
  const now = clock.now();
  const [sessions, idempotencyKeys, social] = await Promise.all([
    repos.sessions.deleteExpired(now),
    repos.castles.deleteExpiredIdempotency(new Date(now.getTime() - DAY_MS)),
    // Чат хранится неделю, уведомления — месяц, отметки помощи — неделю
    repos.castles.transaction(async (tx) => {
      const week = new Date(now.getTime() - 7 * DAY_MS);
      await tx.guilds.deleteHelpsBefore(week);
      return {
        godSessions: await tx.admin.deleteExpiredGodSessions(now),
        chat: await tx.chat.deleteBefore(week),
        notifications: await tx.notifications.deleteBefore(new Date(now.getTime() - 30 * DAY_MS)),
      };
    }),
  ]);
  return { sessions, idempotencyKeys, ...social };
}

/** Запускает уборку раз в час; ошибки логируются и не роняют процесс. */
export function scheduleMaintenance(
  repos: Pick<Repositories, 'sessions' | 'castles'>,
  clock: Clock,
  log: (msg: string, err?: unknown) => void,
): () => void {
  const run = () =>
    runMaintenance(repos, clock).then(
      (r) => {
        if (r.sessions + r.idempotencyKeys + r.chat + r.notifications + r.godSessions > 0)
          log(`maintenance: ${JSON.stringify(r)}`);
      },
      (err: unknown) => log('maintenance failed', err),
    );
  const timer = setInterval(() => void run(), 3600_000);
  timer.unref();
  void run();
  return () => clearInterval(timer);
}
