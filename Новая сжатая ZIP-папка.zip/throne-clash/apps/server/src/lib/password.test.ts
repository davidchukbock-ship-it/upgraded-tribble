import { describe, expect, it } from 'vitest';
import { hashPassword, verifyPassword } from './password';

describe('password', () => {
  it('хеш argon2id проверяется верным паролем и отвергает неверный', async () => {
    const hash = await hashPassword('correct horse battery staple');
    expect(hash).toMatch(/^\$argon2id\$v=19\$m=19456,t=2,p=1\$/);
    expect(await verifyPassword(hash, 'correct horse battery staple')).toBe(true);
    expect(await verifyPassword(hash, 'wrong password')).toBe(false);
  });

  it('одинаковые пароли дают разные хеши (соль)', async () => {
    expect(await hashPassword('same-password-123')).not.toBe(
      await hashPassword('same-password-123'),
    );
  });

  it('мусорный хеш и пустые значения не бросают исключений', async () => {
    expect(await verifyPassword('not-a-hash', 'x')).toBe(false);
    expect(await verifyPassword('', 'x')).toBe(false);
    expect(await verifyPassword('$argon2id$broken', 'x')).toBe(false);
    const hash = await hashPassword('abc-def-ghi-jkl');
    expect(await verifyPassword(hash, '')).toBe(false);
  });
});
