import argon2 from 'argon2';

/** Параметры argon2id по рекомендации OWASP (память 19 МиБ, 2 прохода, 1 поток). */
export const ARGON2_OPTIONS = {
  type: argon2.argon2id,
  memoryCost: 19456,
  timeCost: 2,
  parallelism: 1,
} as const;

export function hashPassword(password: string): Promise<string> {
  return argon2.hash(password, ARGON2_OPTIONS);
}

/** Любая ошибка (битый хеш, пустая строка) = «не подходит», а не исключение наружу. */
export async function verifyPassword(hash: string, password: string): Promise<boolean> {
  if (!hash || !password) return false;
  try {
    return await argon2.verify(hash, password);
  } catch {
    return false;
  }
}
