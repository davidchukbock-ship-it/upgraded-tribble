import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import { jwtVerify, SignJWT } from 'jose';
import type { Role } from '@tc/shared';

const ISSUER = 'throne-clash';
const AUDIENCE = 'throne-clash-web';

/** SHA-256 в hex: в БД хранятся только хеши refresh-токенов, сами токены — никогда. */
export const sha256 = (value: string): string => createHash('sha256').update(value).digest('hex');

/** Случайная строка на 256 бит (base64url) — refresh-токены и CSRF. */
export const randomToken = (bytes = 32): string => randomBytes(bytes).toString('base64url');

/** Сравнение секретов за постоянное время. Разная длина = не равны (без утечки по времени). */
export function safeEqual(a: string, b: string): boolean {
  const ba = Buffer.from(a);
  const bb = Buffer.from(b);
  return ba.length === bb.length && timingSafeEqual(ba, bb);
}

export interface AccessClaims {
  userId: string;
  role: Role;
}

export class AccessTokenService {
  private readonly key: Uint8Array;

  constructor(
    secret: string,
    private readonly ttlSeconds: number,
  ) {
    this.key = new TextEncoder().encode(secret);
  }

  /** `actorId` — владелец, действующий от имени игрока (заходит под ним из режима бога); срок можно сократить. */
  async sign(
    claims: AccessClaims,
    now: Date,
    opts: { actorId?: string; ttlSeconds?: number } = {},
  ): Promise<string> {
    const iat = Math.floor(now.getTime() / 1000);
    const ttl = opts.ttlSeconds ?? this.ttlSeconds;
    return new SignJWT({ role: claims.role, ...(opts.actorId && { act: { sub: opts.actorId } }) })
      .setProtectedHeader({ alg: 'HS256', typ: 'JWT' })
      .setSubject(claims.userId)
      .setIssuer(ISSUER)
      .setAudience(AUDIENCE)
      .setIssuedAt(iat)
      .setExpirationTime(iat + ttl)
      .sign(this.key);
  }

  /** null — токен недействителен по любой причине (подпись, срок, издатель). Причину наружу не выдаём. */
  async verify(token: string, now: Date): Promise<{ userId: string; actorId?: string } | null> {
    try {
      const { payload } = await jwtVerify(token, this.key, {
        issuer: ISSUER,
        audience: AUDIENCE,
        algorithms: ['HS256'],
        currentDate: now,
      });
      if (typeof payload.sub !== 'string') return null;
      const act = (payload as { act?: { sub?: unknown } }).act;
      return typeof act?.sub === 'string'
        ? { userId: payload.sub, actorId: act.sub }
        : { userId: payload.sub };
    } catch {
      return null;
    }
  }

  get ttl(): number {
    return this.ttlSeconds;
  }
}
