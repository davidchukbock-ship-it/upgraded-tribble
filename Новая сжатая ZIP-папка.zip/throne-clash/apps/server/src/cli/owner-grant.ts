/**
 * Назначение владельца:  pnpm owner:grant
 * Берёт email из OWNER_EMAIL, спрашивает пароль этого аккаунта (ввод скрыт) и выдаёт роль OWNER.
 * Сначала зарегистрируйтесь в игре под этим email. Пароль можно передать через stdin: echo "..." | pnpm owner:grant -- --stdin
 */
import { PrismaClient } from '@prisma/client';
import { createInterface } from 'node:readline';
import { loadConfig } from '../config/env';
import { createPrismaRepositories } from '../modules/auth/auth.repository';
import { argonHasher } from '../modules/auth/auth.service';
import { grantOwner, OwnerGrantFailure } from '../modules/auth/owner';

const MESSAGES: Record<OwnerGrantFailure['reason'], string> = {
  owner_email_not_set: 'В .env не задан OWNER_EMAIL.',
  user_not_found: 'Аккаунта с таким email нет. Сначала зарегистрируйтесь в игре под этим email.',
  wrong_password: 'Неверный пароль аккаунта.',
  other_owner_exists:
    'В БД уже есть аккаунт с ролью OWNER. Добавьте --force, чтобы выдать роль и этому аккаунту (действует только аккаунт с OWNER_EMAIL).',
};

function loadDotEnv(): void {
  for (const path of ['.env', '../../.env']) {
    try {
      process.loadEnvFile(path);
      return;
    } catch {
      /* нет файла — пробуем следующий */
    }
  }
}

/** Читает пароль без отображения символов (TTY) или строкой из stdin (скрипты). */
async function readPassword(fromStdin: boolean): Promise<string> {
  if (fromStdin || !process.stdin.isTTY) {
    const rl = createInterface({ input: process.stdin });
    for await (const line of rl) return line.trim();
    return '';
  }
  process.stdout.write('Пароль аккаунта владельца: ');
  return new Promise((resolve) => {
    let value = '';
    process.stdin.setRawMode(true);
    process.stdin.resume();
    process.stdin.setEncoding('utf8');
    const onData = (ch: string): void => {
      for (const c of ch) {
        if (c === '\r' || c === '\n' || c === '\u0004') {
          process.stdin.setRawMode(false);
          process.stdin.pause();
          process.stdin.off('data', onData);
          process.stdout.write('\n');
          resolve(value);
          return;
        }
        if (c === '\u0003') process.exit(130); // Ctrl+C
        if (c === '\u007f') value = value.slice(0, -1);
        else value += c;
      }
    };
    process.stdin.on('data', onData);
  });
}

async function main(): Promise<void> {
  loadDotEnv();
  const args = process.argv.slice(2);
  const config = loadConfig();
  const prisma = new PrismaClient({ datasourceUrl: config.databaseUrl });
  try {
    const password = await readPassword(args.includes('--stdin'));
    const result = await grantOwner(
      {
        users: createPrismaRepositories(prisma).users,
        hasher: argonHasher,
        ownerEmail: config.ownerEmail,
      },
      password,
      { force: args.includes('--force') },
    );
    console.log(
      result === 'granted'
        ? `Роль OWNER выдана аккаунту ${config.ownerEmail}.`
        : 'Этот аккаунт уже является владельцем.',
    );
  } catch (err) {
    console.error(err instanceof OwnerGrantFailure ? MESSAGES[err.reason] : err);
    process.exitCode = 1;
  } finally {
    await prisma.$disconnect();
  }
}

void main();
