/**
 * Генерация argon2-хеша пароля режима бога:  pnpm god:hash "ваш пароль"
 * Пароль нигде не сохраняется: выводится только хеш. Впишите его в .env как GOD_MODE_PASSWORD_HASH.
 */
import { createInterface } from 'node:readline';
import { hashPassword } from '../lib/password';

async function readStdin(): Promise<string> {
  const rl = createInterface({ input: process.stdin });
  const lines: string[] = [];
  for await (const line of rl) lines.push(line);
  return lines.join('\n');
}

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  const password = args.includes('--stdin')
    ? (await readStdin()).trim()
    : args.find((a) => !a.startsWith('--'));

  if (!password) {
    console.error(
      'Использование:  pnpm god:hash "пароль"\n           или:  echo "пароль" | pnpm god:hash -- --stdin  (пароль не попадёт в историю shell)',
    );
    process.exit(1);
  }
  if (password.length < 12) {
    console.error('Пароль режима бога должен быть не короче 12 символов.');
    process.exit(1);
  }

  const hash = await hashPassword(password);
  console.log('\nДобавьте в .env (одинарные кавычки обязательны: в хеше есть символы $):\n');
  console.log(`GOD_MODE_PASSWORD_HASH='${hash}'\n`);
  console.log('Сам пароль нигде не сохранён. Не коммитьте .env.');
}

main().catch((e: unknown) => {
  console.error(e instanceof Error ? e.message : e);
  process.exit(1);
});
