/**
 * Создаёт секрет TOTP для режима бога:  pnpm god:totp
 * Добавьте строку в .env и отсканируйте ссылку otpauth:// в приложении-аутентификаторе.
 * Секрет выводится только сюда, в консоль; в репозиторий он не попадает.
 */
import { generateTotpSecret } from '../lib/totp';

const secret = generateTotpSecret();
console.log('\nДобавьте в .env:\n');
console.log(`GOD_MODE_TOTP_SECRET=${secret}\n`);
console.log('Ссылка для приложения-аутентификатора (Google Authenticator, Aegis, 2FAS):\n');
console.log(`otpauth://totp/Throne%20Clash:god?secret=${secret}&issuer=Throne%20Clash\n`);
