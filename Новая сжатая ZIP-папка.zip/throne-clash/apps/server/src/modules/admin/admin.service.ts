import { randomUUID } from 'node:crypto';
import {
  MAIN_WORLD_ID,
  type AdminStatsDto,
  type AdminUserDto,
  type AdminUserPageDto,
  type AuditEntryDto,
  type AuditPageDto,
  type ChatReportDto,
  type Role,
  type SecurityLogEntryDto,
} from '@tc/shared';
import type { Clock } from '../../lib/clock';
import { Errors } from '../../lib/errors';
import { effectiveRole } from '../auth/auth.service';
import type {
  SecurityLogRepository,
  SessionRepository,
  UserRecord,
  UserRepository,
} from '../auth/auth.types';
import { gemEvent, type CastleResult, type RealmRunner } from '../castle/castle.runner';
import type { CastleRepository } from '../castle/castle.types';
import type { Hub } from '../social/hub';
import type { AuditRecord, AuditScope } from './admin.types';

const DAY_MS = 86_400_000;
/** «Навсегда»: бан без срока хранится как далёкая дата. */
const FOREVER = new Date('2100-01-01T00:00:00.000Z');
export const MAX_GRANT_GEMS = 10_000;

export const toAdminUser = (u: UserRecord): AdminUserDto => ({
  id: u.id,
  nickname: u.nickname,
  email: u.email,
  role: u.role,
  isGuest: u.isGuest,
  isBot: u.isBot,
  bannedUntil: u.bannedUntil?.toISOString() ?? null,
  banReason: u.banReason,
  mutedUntil: u.mutedUntil?.toISOString() ?? null,
  createdAt: u.createdAt.toISOString(),
  lastLoginAt: u.lastLoginAt?.toISOString() ?? null,
});

export interface Actor {
  user: UserRecord;
  role: Role;
  ip: string;
}

export interface AdminDeps {
  repo: CastleRepository;
  users: UserRepository;
  sessions: SessionRepository;
  security: SecurityLogRepository;
  runner: RealmRunner;
  hub: Hub;
  clock: Clock;
  ownerEmail: string;
  worldId?: string;
}

/** Панель администратора: поиск игроков, модерация, журналы, статистика. Всё изменяющее пишется в аудит. */
export class AdminService {
  private readonly worldId: string;

  constructor(private readonly deps: AdminDeps) {
    this.worldId = deps.worldId ?? MAIN_WORLD_ID;
  }

  async listUsers(query: string, page: number, pageSize: number): Promise<AdminUserPageDto> {
    const r = await this.deps.users.list({ query, page, pageSize });
    return { items: r.items.map(toAdminUser), page, pageSize, total: r.total };
  }

  async stats(online: number): Promise<AdminStatsDto> {
    const now = this.deps.clock.now();
    const [users, active, economy, reports] = await Promise.all([
      this.deps.users.stats(now),
      this.deps.sessions.countActiveUsers(new Date(now.getTime() - DAY_MS)),
      this.deps.repo.transaction((tx) =>
        tx.admin.economyFlow(this.worldId, new Date(now.getTime() - DAY_MS)),
      ),
      this.deps.repo.transaction((tx) => tx.admin.listChatReports(1, 1)),
    ]);
    const { new24h, new7d, ...counts } = users;
    return {
      users: counts,
      activity: { new24h, new7d, active24h: active, online },
      economy,
      reportsOpen: reports.total,
    };
  }

  async logs(
    filter: { kind?: string; userId?: string },
    page: number,
    pageSize: number,
  ): Promise<{ items: SecurityLogEntryDto[]; page: number; pageSize: number; total: number }> {
    const r = await this.deps.security.page(filter, page, pageSize);
    const names = await this.names(r.items.map((e) => e.userId));
    return {
      items: r.items.map((e) => ({
        kind: e.kind,
        userId: e.userId ?? null,
        nickname: e.userId ? (names.get(e.userId) ?? null) : null,
        ip: e.ip ?? null,
        details: e.details ?? null,
        createdAt: e.createdAt.toISOString(),
      })),
      page,
      pageSize,
      total: r.total,
    };
  }

  async reports(page: number, pageSize: number) {
    const r = await this.deps.repo.transaction((tx) => tx.admin.listChatReports(page, pageSize));
    const names = await this.names(r.items.flatMap((x) => [x.reporterId, x.authorId]));
    const items: ChatReportDto[] = r.items.map((x) => ({
      id: x.id,
      reason: x.reason,
      createdAt: x.createdAt.toISOString(),
      reporter: { id: x.reporterId, nickname: names.get(x.reporterId) ?? '?' },
      author: { id: x.authorId, nickname: names.get(x.authorId) ?? '?' },
      message: {
        id: x.messageId,
        channel: x.channel.startsWith('dm:') ? 'dm' : x.channel.split(':')[0]!,
        text: x.text,
        createdAt: x.messageCreatedAt.toISOString(),
      },
    }));
    return { items, page, pageSize, total: r.total };
  }

  async audit(
    filter: { scope?: AuditScope; targetUserId?: string },
    page: number,
    pageSize: number,
  ): Promise<AuditPageDto> {
    const r = await this.deps.repo.transaction((tx) => tx.admin.listAudit(filter, page, pageSize));
    const names = await this.names(r.items.flatMap((x) => [x.actorId, x.targetUserId]));
    const who = (id: string | null) => (id ? { id, nickname: names.get(id) ?? '?' } : null);
    const items: AuditEntryDto[] = r.items.map((x) => ({
      id: x.id,
      scope: x.scope,
      actor: who(x.actorId),
      action: x.action,
      target: who(x.targetUserId),
      params: x.params,
      before: x.before,
      after: x.after,
      ip: x.ip,
      createdAt: x.createdAt.toISOString(),
    }));
    return { items, page, pageSize, total: r.total };
  }

  // ── Модерация ──────────────────────────────────────────────────────────────

  /**
   * Кого можно модерировать: не себя, не владельца; администратора — только владелец.
   * Через API роль изменить нельзя (D-19), поэтому эта проверка не обходится.
   */
  private async target(actor: Actor, targetId: string): Promise<UserRecord> {
    const target = await this.deps.users.findById(targetId);
    if (!target) throw Errors.notFound('Player');
    if (target.id === actor.user.id) throw Errors.requirementNotMet({ reason: 'self' });
    const targetRole = effectiveRole(target, this.deps.ownerEmail);
    if (targetRole === 'OWNER') throw Errors.forbidden();
    if (targetRole === 'ADMIN' && actor.role !== 'OWNER') throw Errors.forbidden();
    return target;
  }

  private async record(
    actor: Actor,
    action: string,
    target: UserRecord,
    params: unknown,
    before?: unknown,
    after?: unknown,
  ): Promise<void> {
    const rec: AuditRecord = {
      id: randomUUID(),
      scope: 'admin',
      actorId: actor.user.id,
      action,
      targetUserId: target.id,
      params,
      before: before ?? null,
      after: after ?? null,
      ip: actor.ip,
      createdAt: this.deps.clock.now(),
    };
    await this.deps.repo.transaction((tx) => tx.admin.addAudit(rec));
  }

  async ban(actor: Actor, targetId: string, hours: number | null, reason: string) {
    const target = await this.target(actor, targetId);
    const now = this.deps.clock.now();
    const until = hours === null ? FOREVER : new Date(now.getTime() + hours * 3600_000);
    const updated = await this.deps.users.update(target.id, {
      bannedUntil: until,
      banReason: reason,
    });
    // Бан действует сразу: сессии отзываются, открытые соединения закрываются
    await this.deps.sessions.revokeAllForUser(target.id, now);
    this.deps.hub.kick(target.id);
    await this.record(
      actor,
      'ban',
      target,
      { hours, reason },
      { bannedUntil: target.bannedUntil?.toISOString() ?? null },
      { bannedUntil: until.toISOString() },
    );
    return toAdminUser(updated);
  }

  async unban(actor: Actor, targetId: string) {
    const target = await this.target(actor, targetId);
    const updated = await this.deps.users.update(target.id, { bannedUntil: null, banReason: null });
    await this.record(actor, 'unban', target, null, {
      bannedUntil: target.bannedUntil?.toISOString() ?? null,
    });
    return toAdminUser(updated);
  }

  async mute(actor: Actor, targetId: string, minutes: number, reason: string) {
    const target = await this.target(actor, targetId);
    const until = new Date(this.deps.clock.now().getTime() + minutes * 60_000);
    const updated = await this.deps.users.update(target.id, { mutedUntil: until });
    await this.record(actor, 'mute', target, { minutes, reason }, null, {
      mutedUntil: until.toISOString(),
    });
    return toAdminUser(updated);
  }

  async unmute(actor: Actor, targetId: string) {
    const target = await this.target(actor, targetId);
    const updated = await this.deps.users.update(target.id, { mutedUntil: null });
    await this.record(actor, 'unmute', target, null);
    return toAdminUser(updated);
  }

  /** Поддержка: начислить кристаллы (например, компенсация). Это не режим бога — рейтинги не затрагиваются. */
  async grantGems(
    actor: Actor,
    targetId: string,
    amount: number,
    reason: string,
    idemKey: string,
  ): Promise<CastleResult> {
    const target = await this.target(actor, targetId);
    let before = 0;
    return this.deps.runner.mutate(
      target.id,
      `admin-grant:${amount}`,
      idemKey,
      (draft, now) => {
        before = draft.gems;
        draft.gems += amount;
        return [gemEvent(draft, now, 'admin_grant', amount)];
      },
      async (tx, draft, now) => {
        await tx.admin.addAudit({
          id: randomUUID(),
          scope: 'admin',
          actorId: actor.user.id,
          action: 'grant_gems',
          targetUserId: target.id,
          params: { amount, reason },
          before: { gems: before },
          after: { gems: draft.gems },
          ip: actor.ip,
          createdAt: now,
        });
      },
    );
  }

  private async names(ids: Array<string | null | undefined>): Promise<Map<string, string>> {
    const map = new Map<string, string>();
    for (const id of new Set(ids.filter((x): x is string => !!x))) {
      const u = await this.deps.users.findById(id);
      if (u) map.set(id, u.nickname);
    }
    return map;
  }
}
