import type {
  AdminStore,
  AuditFilter,
  AuditRecord,
  BalanceRevisionRecord,
  ChatReportRow,
  Flow,
  GodSessionRecord,
  SnapshotRecord,
} from './admin.types';

const zeroFlow = (): Flow => ({ gold: 0, wood: 0, stone: 0, food: 0, gems: 0 });

interface State {
  audit: AuditRecord[];
  sessions: Map<string, GodSessionRecord>;
  snapshots: SnapshotRecord[];
  balance: BalanceRevisionRecord[];
}

/** Источники данных из соседних in-memory хранилищ (замки, экономика, чат). */
export interface AdminSource {
  economy(worldId: string, since: Date): Array<{ resource: keyof Flow; amount: number }>;
  counts(worldId: string): ReturnType<AdminStore['counts']>;
  reports(): Promise<ChatReportRow[]>;
}

/**
 * In-memory хранилище администрирования. Записи применяются сразу; откат транзакции — журналом
 * обратных операций (как у прогресса, D-44).
 */
export class MemoryAdmin implements AdminStore {
  private readonly undo: Array<() => void> = [];

  constructor(
    private readonly source: AdminSource,
    private readonly state: State = { audit: [], sessions: new Map(), snapshots: [], balance: [] },
  ) {}

  begin(): MemoryAdmin {
    return new MemoryAdmin(this.source, this.state);
  }

  rollback(): void {
    while (this.undo.length > 0) this.undo.pop()!();
  }

  get audit(): readonly AuditRecord[] {
    return this.state.audit;
  }

  async addAudit(rec: AuditRecord): Promise<void> {
    this.state.audit.push(structuredClone(rec));
    this.undo.push(() => {
      this.state.audit = this.state.audit.filter((r) => r.id !== rec.id);
    });
  }

  async listAudit(filter: AuditFilter, page: number, pageSize: number) {
    const all = this.state.audit
      .filter(
        (r) =>
          (!filter.scope || r.scope === filter.scope) &&
          (!filter.actorId || r.actorId === filter.actorId) &&
          (!filter.targetUserId || r.targetUserId === filter.targetUserId),
      )
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    return {
      items: structuredClone(all.slice((page - 1) * pageSize, page * pageSize)),
      total: all.length,
    };
  }

  async createGodSession(rec: GodSessionRecord): Promise<void> {
    this.state.sessions.set(rec.id, { ...rec });
    this.undo.push(() => this.state.sessions.delete(rec.id));
  }

  async findGodSession(tokenHash: string): Promise<GodSessionRecord | null> {
    const s = [...this.state.sessions.values()].find((x) => x.tokenHash === tokenHash);
    return s ? { ...s } : null;
  }

  async slideGodSession(id: string, lastSeenAt: Date, expiresAt: Date): Promise<void> {
    const s = this.state.sessions.get(id);
    if (s) {
      s.lastSeenAt = lastSeenAt;
      s.expiresAt = expiresAt;
    }
  }

  async deleteGodSession(id: string): Promise<void> {
    this.state.sessions.delete(id);
  }

  async deleteGodSessionsOf(userId: string): Promise<void> {
    for (const [id, s] of this.state.sessions)
      if (s.userId === userId) this.state.sessions.delete(id);
  }

  async deleteExpiredGodSessions(before: Date): Promise<number> {
    let n = 0;
    for (const [id, s] of this.state.sessions)
      if (s.expiresAt < before) {
        this.state.sessions.delete(id);
        n++;
      }
    return n;
  }

  async saveSnapshot(rec: SnapshotRecord): Promise<void> {
    this.state.snapshots.push(structuredClone(rec));
    this.undo.push(() => {
      this.state.snapshots = this.state.snapshots.filter((r) => r.id !== rec.id);
    });
  }

  async listSnapshots(userId: string): Promise<SnapshotRecord[]> {
    return structuredClone(
      this.state.snapshots
        .filter((s) => s.userId === userId)
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime()),
    );
  }

  async getSnapshot(id: string): Promise<SnapshotRecord | null> {
    const s = this.state.snapshots.find((x) => x.id === id);
    return s ? structuredClone(s) : null;
  }

  async addBalanceRevision(rec: BalanceRevisionRecord): Promise<void> {
    this.state.balance.push(structuredClone(rec));
    this.undo.push(() => {
      this.state.balance = this.state.balance.filter((r) => r.id !== rec.id);
    });
  }

  async listBalanceRevisions(limit: number): Promise<BalanceRevisionRecord[]> {
    return structuredClone(
      [...this.state.balance]
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
        .slice(0, limit),
    );
  }

  async listChatReports(page: number, pageSize: number) {
    const all = (await this.source.reports()).sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime(),
    );
    return { items: all.slice((page - 1) * pageSize, page * pageSize), total: all.length };
  }

  async economyFlow(worldId: string, since: Date) {
    const gained = zeroFlow();
    const spent = zeroFlow();
    for (const e of this.source.economy(worldId, since)) {
      if (e.amount >= 0) gained[e.resource] += e.amount;
      else spent[e.resource] += -e.amount;
    }
    return { gained, spent };
  }

  counts(worldId: string) {
    return this.source.counts(worldId);
  }
}
