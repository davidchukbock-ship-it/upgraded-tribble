import { z } from 'zod';
import { ROLES } from '@tc/shared';

const iso = z.string();
const flow = z.object({
  gold: z.number(),
  wood: z.number(),
  stone: z.number(),
  food: z.number(),
  gems: z.number(),
});

export const adminUserSchema = z.object({
  id: z.string(),
  nickname: z.string(),
  email: z.string().nullable(),
  role: z.enum(ROLES),
  isGuest: z.boolean(),
  isBot: z.boolean(),
  bannedUntil: iso.nullable(),
  banReason: z.string().nullable(),
  mutedUntil: iso.nullable(),
  createdAt: iso,
  lastLoginAt: iso.nullable(),
});

const page = (item: z.ZodTypeAny) =>
  z.object({ items: z.array(item), page: z.number(), pageSize: z.number(), total: z.number() });

export const adminUserPageSchema = page(adminUserSchema);

export const statsSchema = z.object({
  users: z.object({
    total: z.number(),
    guests: z.number(),
    bots: z.number(),
    banned: z.number(),
    muted: z.number(),
  }),
  activity: z.object({
    new24h: z.number(),
    new7d: z.number(),
    active24h: z.number(),
    online: z.number(),
  }),
  economy: z.object({ gained: flow, spent: flow }),
  reportsOpen: z.number(),
});

export const logsSchema = page(
  z.object({
    kind: z.string(),
    userId: z.string().nullable(),
    nickname: z.string().nullable(),
    ip: z.string().nullable(),
    details: z.record(z.unknown()).nullable(),
    createdAt: iso,
  }),
);

export const reportsSchema = page(
  z.object({
    id: z.string(),
    reason: z.string(),
    createdAt: iso,
    reporter: z.object({ id: z.string(), nickname: z.string() }),
    author: z.object({ id: z.string(), nickname: z.string() }),
    message: z.object({ id: z.string(), channel: z.string(), text: z.string(), createdAt: iso }),
  }),
);

const who = z.object({ id: z.string(), nickname: z.string() }).nullable();
export const auditSchema = page(
  z.object({
    id: z.string(),
    scope: z.enum(['admin', 'god']),
    actor: who,
    action: z.string(),
    target: who,
    params: z.unknown(),
    before: z.unknown(),
    after: z.unknown(),
    ip: z.string().nullable(),
    createdAt: iso,
  }),
);

export const idParams = z.object({ id: z.string().uuid() });
export const pageQuery = z.object({
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(25),
});
export const usersQuery = pageQuery.extend({ q: z.string().max(60).default('') });
export const logsQuery = pageQuery.extend({
  kind: z.string().max(40).optional(),
  userId: z.string().uuid().optional(),
});
export const auditQuery = pageQuery.extend({
  scope: z.enum(['admin', 'god']).optional(),
  targetUserId: z.string().uuid().optional(),
});

const reason = z.string().trim().min(3).max(200);
export const banBody = z
  .object({ hours: z.number().int().min(1).max(8760).nullable(), reason })
  .strict();
export const muteBody = z.object({ minutes: z.number().int().min(1).max(43_200), reason }).strict();
export const grantBody = z.object({ amount: z.number().int().min(1).max(10_000), reason }).strict();
