import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import type { ZodTypeProvider } from 'fastify-type-provider-zod';
import { sendResult } from '../castle/castle.controller';
import { castleSchema, errorSchema, failures, idempotencyHeaders } from '../castle/castle.schema';
import type { Hub } from '../social/hub';
import type { AdminService, Actor } from './admin.service';
import {
  adminUserPageSchema,
  adminUserSchema,
  auditQuery,
  auditSchema,
  banBody,
  grantBody,
  idParams,
  logsQuery,
  logsSchema,
  muteBody,
  reportsSchema,
  statsSchema,
  pageQuery,
  usersQuery,
} from './admin.schema';

export const actorOf = (req: FastifyRequest): Actor => ({
  user: req.auth!.user,
  role: req.auth!.role,
  ip: req.ip,
});

/** Панель администратора `/api/admin/*` (роль ADMIN или OWNER). Права проверяются на сервере при каждом запросе. */
export function registerAdminRoutes(
  app: FastifyInstance,
  deps: { service: AdminService; hub: Hub; onDenied: (req: FastifyRequest) => void },
): void {
  const r = app.withTypeProvider<ZodTypeProvider>();
  const tags = ['admin'];
  const security = [{ bearerAuth: [] }];
  // Отказ обычному игроку фиксируется в журнале безопасности, а для клиента выглядит как обычный 403
  const admin = {
    preHandler: async (req: FastifyRequest, reply: FastifyReply) => {
      try {
        await app.requireRole('ADMIN')(req, reply);
      } catch (err) {
        if (req.auth) deps.onDenied(req);
        throw err;
      }
    },
  };
  const read = { 401: errorSchema, 403: errorSchema };

  r.get(
    '/admin/stats',
    {
      ...admin,
      schema: {
        tags,
        summary: 'Сводка: игроки, активность, экономика за сутки',
        security,
        response: { 200: statsSchema, ...read },
      },
    },
    async () => deps.service.stats(deps.hub.online),
  );

  r.get(
    '/admin/users',
    {
      ...admin,
      schema: {
        tags,
        summary: 'Поиск игроков по нику, почте или id',
        security,
        querystring: usersQuery,
        response: { 200: adminUserPageSchema, ...read },
      },
    },
    async (req) => deps.service.listUsers(req.query.q, req.query.page, req.query.pageSize),
  );

  r.post(
    '/admin/users/:id/ban',
    {
      ...admin,
      schema: {
        tags,
        summary: 'Заблокировать игрока (hours: null — навсегда)',
        security,
        params: idParams,
        body: banBody,
        response: { 200: adminUserSchema, ...read, 404: errorSchema },
      },
    },
    async (req) => deps.service.ban(actorOf(req), req.params.id, req.body.hours, req.body.reason),
  );

  r.post(
    '/admin/users/:id/unban',
    {
      ...admin,
      schema: {
        tags,
        summary: 'Снять блокировку',
        security,
        params: idParams,
        response: { 200: adminUserSchema, ...read, 404: errorSchema },
      },
    },
    async (req) => deps.service.unban(actorOf(req), req.params.id),
  );

  r.post(
    '/admin/users/:id/mute',
    {
      ...admin,
      schema: {
        tags,
        summary: 'Запретить писать в чат',
        security,
        params: idParams,
        body: muteBody,
        response: { 200: adminUserSchema, ...read, 404: errorSchema },
      },
    },
    async (req) =>
      deps.service.mute(actorOf(req), req.params.id, req.body.minutes, req.body.reason),
  );

  r.post(
    '/admin/users/:id/unmute',
    {
      ...admin,
      schema: {
        tags,
        summary: 'Снять запрет на чат',
        security,
        params: idParams,
        response: { 200: adminUserSchema, ...read, 404: errorSchema },
      },
    },
    async (req) => deps.service.unmute(actorOf(req), req.params.id),
  );

  r.post(
    '/admin/users/:id/grant',
    {
      ...admin,
      schema: {
        tags,
        summary: 'Начислить кристаллы (поддержка); пишется в аудит',
        security,
        headers: idempotencyHeaders,
        params: idParams,
        body: grantBody,
        response: { 200: castleSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await deps.service.grantGems(
          actorOf(req),
          req.params.id,
          req.body.amount,
          req.body.reason,
          req.headers['idempotency-key'],
        ),
      ),
  );

  r.get(
    '/admin/logs',
    {
      ...admin,
      schema: {
        tags,
        summary: 'Журнал подозрительных действий',
        security,
        querystring: logsQuery,
        response: { 200: logsSchema, ...read },
      },
    },
    async (req) => {
      const { page, pageSize, ...filter } = req.query;
      return deps.service.logs(filter, page, pageSize);
    },
  );

  r.get(
    '/admin/reports',
    {
      ...admin,
      schema: {
        tags,
        summary: 'Жалобы на сообщения чата',
        security,
        querystring: pageQuery,
        response: { 200: reportsSchema, ...read },
      },
    },
    async (req) => deps.service.reports(req.query.page, req.query.pageSize),
  );

  r.get(
    '/admin/audit',
    {
      ...admin,
      schema: {
        tags,
        summary: 'Аудит действий администраторов',
        security,
        querystring: auditQuery,
        response: { 200: auditSchema, ...read },
      },
    },
    // Действия режима бога видны только в его панели
    async (req) =>
      deps.service.audit(
        { scope: 'admin', ...(req.query.targetUserId && { targetUserId: req.query.targetUserId }) },
        req.query.page,
        req.query.pageSize,
      ),
  );
}
