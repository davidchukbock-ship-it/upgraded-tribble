import type { ResourceKey } from '@tc/shared';

export type AuditScope = 'admin' | 'god';

export interface AuditRecord {
  id: string;
  scope: AuditScope;
  actorId: string | null;
  action: string;
  targetUserId: string | null;
  params: unknown;
  before: unknown;
  after: unknown;
  ip: string | null;
  createdAt: Date;
}

export interface AuditFilter {
  scope?: AuditScope;
  actorId?: string;
  targetUserId?: string;
}

export interface GodSessionRecord {
  id: string;
  userId: string;
  tokenHash: string;
  ip: string | null;
  createdAt: Date;
  lastSeenAt: Date;
  expiresAt: Date;
}

export interface SnapshotRecord {
  id: string;
  userId: string;
  label: string;
  takenBy: string;
  data: unknown;
  createdAt: Date;
}

export interface BalanceRevisionRecord {
  id: string;
  config: Record<string, number>;
  actorId: string | null;
  note: string | null;
  createdAt: Date;
}

export interface ChatReportRow {
  id: string;
  reason: string;
  createdAt: Date;
  reporterId: string;
  messageId: string;
  authorId: string;
  channel: string;
  text: string;
  messageCreatedAt: Date;
}

export type Flow = Record<ResourceKey | 'gems', number>;

/**
 * Хранилище администрирования и режима бога (D-48). Живёт в транзакции замка: действие над замком
 * и запись в журнал фиксируются вместе — не бывает изменения без следа.
 */
export interface AdminStore {
  addAudit(rec: AuditRecord): Promise<void>;
  listAudit(
    filter: AuditFilter,
    page: number,
    pageSize: number,
  ): Promise<{ items: AuditRecord[]; total: number }>;

  createGodSession(rec: GodSessionRecord): Promise<void>;
  findGodSession(tokenHash: string): Promise<GodSessionRecord | null>;
  slideGodSession(id: string, lastSeenAt: Date, expiresAt: Date): Promise<void>;
  deleteGodSession(id: string): Promise<void>;
  deleteGodSessionsOf(userId: string): Promise<void>;
  deleteExpiredGodSessions(before: Date): Promise<number>;

  saveSnapshot(rec: SnapshotRecord): Promise<void>;
  listSnapshots(userId: string): Promise<SnapshotRecord[]>;
  getSnapshot(id: string): Promise<SnapshotRecord | null>;

  addBalanceRevision(rec: BalanceRevisionRecord): Promise<void>;
  /** Новые сверху. */
  listBalanceRevisions(limit: number): Promise<BalanceRevisionRecord[]>;

  listChatReports(
    page: number,
    pageSize: number,
  ): Promise<{ items: ChatReportRow[]; total: number }>;

  /** Экономика без действий режима бога с момента `since`. */
  economyFlow(worldId: string, since: Date): Promise<{ gained: Flow; spent: Flow }>;
  counts(worldId: string): Promise<{
    users: number;
    castles: number;
    marches: number;
    guilds: number;
    chatMessages: number;
  }>;
}
