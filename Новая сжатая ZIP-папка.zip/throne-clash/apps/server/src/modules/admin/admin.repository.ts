import { Prisma } from '@prisma/client';
import type {
  AdminStore,
  AuditFilter,
  AuditRecord,
  AuditScope,
  BalanceRevisionRecord,
  ChatReportRow,
  Flow,
  GodSessionRecord,
  SnapshotRecord,
} from './admin.types';

type Client = Prisma.TransactionClient;
const json = (v: unknown) =>
  v === undefined || v === null ? Prisma.JsonNull : (v as Prisma.InputJsonValue);
const zeroFlow = (): Flow => ({ gold: 0, wood: 0, stone: 0, food: 0, gems: 0 });

const toAudit = (r: {
  id: string;
  scope: string;
  actorId: string | null;
  action: string;
  targetUserId: string | null;
  params: unknown;
  before: unknown;
  after: unknown;
  ip: string | null;
  createdAt: Date;
}): AuditRecord => ({ ...r, scope: r.scope as AuditScope });

/** Хранилище администрирования на Prisma; работает внутри транзакции замка. */
export class PrismaAdmin implements AdminStore {
  constructor(private readonly db: Client) {}

  async addAudit(rec: AuditRecord): Promise<void> {
    await this.db.auditLog.create({
      data: {
        ...rec,
        params: json(rec.params),
        before: json(rec.before),
        after: json(rec.after),
      },
    });
  }

  async listAudit(filter: AuditFilter, page: number, pageSize: number) {
    const where = {
      ...(filter.scope && { scope: filter.scope }),
      ...(filter.actorId && { actorId: filter.actorId }),
      ...(filter.targetUserId && { targetUserId: filter.targetUserId }),
    };
    const [rows, total] = await Promise.all([
      this.db.auditLog.findMany({
        where,
        orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      this.db.auditLog.count({ where }),
    ]);
    return { items: rows.map(toAudit), total };
  }

  async createGodSession(rec: GodSessionRecord): Promise<void> {
    await this.db.godSession.create({ data: rec });
  }

  findGodSession(tokenHash: string): Promise<GodSessionRecord | null> {
    return this.db.godSession.findUnique({ where: { tokenHash } });
  }

  async slideGodSession(id: string, lastSeenAt: Date, expiresAt: Date): Promise<void> {
    await this.db.godSession.updateMany({ where: { id }, data: { lastSeenAt, expiresAt } });
  }

  async deleteGodSession(id: string): Promise<void> {
    await this.db.godSession.deleteMany({ where: { id } });
  }

  async deleteGodSessionsOf(userId: string): Promise<void> {
    await this.db.godSession.deleteMany({ where: { userId } });
  }

  async deleteExpiredGodSessions(before: Date): Promise<number> {
    return (await this.db.godSession.deleteMany({ where: { expiresAt: { lt: before } } })).count;
  }

  async saveSnapshot(rec: SnapshotRecord): Promise<void> {
    await this.db.godSnapshot.create({ data: { ...rec, data: json(rec.data) } });
  }

  async listSnapshots(userId: string): Promise<SnapshotRecord[]> {
    return this.db.godSnapshot.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
  }

  getSnapshot(id: string): Promise<SnapshotRecord | null> {
    return this.db.godSnapshot.findUnique({ where: { id } });
  }

  async addBalanceRevision(rec: BalanceRevisionRecord): Promise<void> {
    await this.db.balanceRevision.create({ data: { ...rec, config: json(rec.config) } });
  }

  async listBalanceRevisions(limit: number): Promise<BalanceRevisionRecord[]> {
    const rows = await this.db.balanceRevision.findMany({
      orderBy: { createdAt: 'desc' },
      take: limit,
    });
    return rows.map((r) => ({ ...r, config: r.config as Record<string, number> }));
  }

  async listChatReports(page: number, pageSize: number) {
    const [reports, total] = await Promise.all([
      this.db.chatReport.findMany({
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      this.db.chatReport.count(),
    ]);
    const messages = await this.db.chatMessage.findMany({
      where: { id: { in: reports.map((r) => r.messageId) } },
    });
    const byId = new Map(messages.map((m) => [m.id, m]));
    const items: ChatReportRow[] = [];
    for (const r of reports) {
      const m = byId.get(r.messageId);
      // Сообщение уже удалено уборкой (неделя): жалоба остаётся без текста и не показывается
      if (!m) continue;
      items.push({
        id: r.id,
        reason: r.reason,
        createdAt: r.createdAt,
        reporterId: r.reporterId,
        messageId: m.id,
        authorId: m.userId,
        channel: m.channel,
        text: m.text,
        messageCreatedAt: m.createdAt,
      });
    }
    return { items, total };
  }

  async economyFlow(worldId: string, since: Date) {
    const base = { worldId, isGodAction: false, createdAt: { gte: since } };
    const [plus, minus] = await Promise.all([
      this.db.economyEvent.groupBy({
        by: ['resource'],
        where: { ...base, amount: { gt: 0 } },
        _sum: { amount: true },
      }),
      this.db.economyEvent.groupBy({
        by: ['resource'],
        where: { ...base, amount: { lt: 0 } },
        _sum: { amount: true },
      }),
    ]);
    const gained = zeroFlow();
    const spent = zeroFlow();
    for (const r of plus)
      if (r.resource in gained) gained[r.resource as keyof Flow] += r._sum.amount ?? 0;
    for (const r of minus)
      if (r.resource in spent) spent[r.resource as keyof Flow] += -(r._sum.amount ?? 0);
    return { gained, spent };
  }

  async counts(worldId: string) {
    const [users, castles, marches, guilds, chatMessages] = await Promise.all([
      this.db.user.count(),
      this.db.castle.count({ where: { worldId } }),
      this.db.march.count(),
      this.db.guild.count({ where: { worldId } }),
      this.db.chatMessage.count({ where: { worldId } }),
    ]);
    return { users, castles, marches, guilds, chatMessages };
  }
}
