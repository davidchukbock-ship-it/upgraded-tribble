import { randomUUID } from 'node:crypto';
import {
  BOOSTERS,
  CHEST_KINDS,
  CHEST_ODDS,
  GEMS_RANGE,
  RESOURCE_PACK,
  addAmounts,
  rollChest,
  type BoosterKey,
  type BoosterUseDto,
  type ChestKind,
  type ChestOddsDto,
  type ChestOpenDto,
  type ChestReward,
  type InventoryDto,
} from '@tc/shared';
import type { Clock } from '../../lib/clock';
import { Errors } from '../../lib/errors';
import { rechain, settleAggregate, starterHero } from '../castle/castle.realm';
import {
  gemEvent,
  resourceEvents,
  type CastleResult,
  type RealmRunner,
} from '../castle/castle.runner';
import type { CastleAggregate, CastleRepository, CastleTx } from '../castle/castle.types';
import { inventoryDto, secureRandom } from './progress.logic';
import { boostKey, chestKey } from './progress.types';

export type BoosterTarget = 'build' | 'train' | 'research';

/** Публичная таблица шансов: её видит игрок до открытия (docs/GAME_DESIGN.md §9). */
export const chestOdds = (): ChestOddsDto[] =>
  CHEST_KINDS.map((kind) => ({
    kind,
    odds: { ...CHEST_ODDS[kind] },
    resourcePack: RESOURCE_PACK[kind],
    gems: [...GEMS_RANGE[kind]] as [number, number],
  }));

/** Сундуки и ускорители в инвентаре. */
export class ChestService {
  constructor(
    private readonly deps: {
      runner: RealmRunner;
      repo: CastleRepository;
      clock: Clock;
      /** Источник случайных чисел; в тестах подменяется детерминированным. */
      random?: () => number;
    },
  ) {}

  async inventory(userId: string): Promise<InventoryDto> {
    return this.deps.repo.transaction(async (tx) =>
      inventoryDto(await tx.progress.inventory(userId)),
    );
  }

  /** Открывает сундук: списывает его, бросает кости серверным RNG, выдаёт награду и пишет журнал. */
  open(userId: string, kind: ChestKind, idemKey: string): Promise<CastleResult<ChestOpenDto>> {
    let reward: ChestReward | null = null;
    let inventory = inventoryDto({});
    const rng = this.deps.random ?? secureRandom;
    return this.deps.runner.mutate<ChestOpenDto>(
      userId,
      `chest-open:${kind}`,
      idemKey,
      async (draft, now, _emit, tx) => {
        if (!(await tx.progress.addItem(userId, chestKey(kind), -1)))
          throw Errors.requirementNotMet({ reason: 'no_chest' });
        const rolled = rollChest(kind, rng);
        reward = rolled;
        await tx.progress.logChest({
          id: randomUUID(),
          userId,
          kind,
          reward: rolled,
          createdAt: now,
        });
        return this.apply(draft, tx, rolled, now);
      },
      async (tx) => {
        inventory = inventoryDto(await tx.progress.inventory(userId));
      },
      { wrap: (castle) => ({ castle, reward: reward!, inventory }), bump: { chest: 1 } },
    );
  }

  private async apply(draft: CastleAggregate, tx: CastleTx, r: ChestReward, now: Date) {
    switch (r.type) {
      case 'resources':
        draft.resources = addAmounts(draft.resources, r.resources);
        return resourceEvents(draft, now, 'chest_open', r.resources);
      case 'gems':
        draft.gems += r.gems;
        return [gemEvent(draft, now, 'chest_open', r.gems)];
      case 'booster':
        await tx.progress.addItem(draft.userId, boostKey(r.booster), 1);
        return [];
      case 'gear':
        draft.hero ??= starterHero();
        draft.hero.items.push({
          id: randomUUID(),
          slot: r.slot,
          rarity: r.rarity,
          equipped: false,
        });
        return [];
    }
  }

  /**
   * Ускоритель из инвентаря сокращает выбранную задачу. Как и кристальное ускорение, действует
   * на постройку, а в цепочках обучения и исследований — на идущую первой.
   */
  useBooster(
    userId: string,
    booster: BoosterKey,
    target: BoosterTarget,
    taskId: string,
    idemKey: string,
  ): Promise<CastleResult<BoosterUseDto>> {
    let inventory = inventoryDto({});
    return this.deps.runner.mutate<BoosterUseDto>(
      userId,
      `boost:${booster}:${target}:${taskId}`,
      idemKey,
      async (draft, now, emit, tx) => {
        const tasks =
          target === 'build' ? draft.tasks : target === 'train' ? draft.trains : draft.research;
        const task = tasks.find((t) => t.id === taskId);
        if (!task) throw Errors.notFound('Task');
        if (target !== 'build') {
          const first = [...tasks].sort(
            (a, b) => a.finishesAt.getTime() - b.finishesAt.getTime(),
          )[0];
          if (first?.id !== taskId) throw Errors.requirementNotMet({ reason: 'not_active' });
        }
        if (!(await tx.progress.addItem(userId, boostKey(booster), -1)))
          throw Errors.requirementNotMet({ reason: 'no_booster' });
        const cut = BOOSTERS[booster] * 1000;
        task.finishesAt = new Date(Math.max(now.getTime(), task.finishesAt.getTime() - cut));
        const settled = settleAggregate(draft, now);
        emit(settled.events);
        Object.assign(draft, settled.draft);
        if (target === 'train') rechain(draft.trains, now);
        if (target === 'research') rechain(draft.research, now);
        return [];
      },
      async (tx) => {
        inventory = inventoryDto(await tx.progress.inventory(userId));
      },
      { wrap: (castle) => ({ castle, inventory }) },
    );
  }
}
