import { Prisma } from '@prisma/client';
import { CHEST_KINDS, type ChestKind, type ChestReward } from '@tc/shared';
import type { LeagueRow, LoginRecord, ProgressStore, SeasonRewardRecord } from './progress.types';

type Client = Prisma.TransactionClient;

const isUnique = (err: unknown): boolean =>
  err instanceof Prisma.PrismaClientKnownRequestError && err.code === 'P2002';

const asChest = (v: string | null): ChestKind | null =>
  v !== null && (CHEST_KINDS as readonly string[]).includes(v) ? (v as ChestKind) : null;

/** Прогресс на Prisma; работает внутри транзакции замка. */
export class PrismaProgress implements ProgressStore {
  constructor(private readonly db: Client) {}

  async inventory(userId: string): Promise<Record<string, number>> {
    const rows = await this.db.inventoryItem.findMany({ where: { userId, count: { gt: 0 } } });
    return Object.fromEntries(rows.map((r) => [r.key, r.count]));
  }

  async addItem(userId: string, key: string, delta: number): Promise<boolean> {
    if (delta >= 0) {
      await this.db.inventoryItem.upsert({
        where: { userId_key: { userId, key } },
        update: { count: { increment: delta } },
        create: { userId, key, count: delta },
      });
      return true;
    }
    // Условное списание одним запросом: гонка двух вычитаний не уведёт остаток ниже нуля
    const done = await this.db.inventoryItem.updateMany({
      where: { userId, key, count: { gte: -delta } },
      data: { count: { increment: delta } },
    });
    return done.count === 1;
  }

  async logChest(rec: {
    id: string;
    userId: string;
    kind: ChestKind;
    reward: ChestReward;
    createdAt: Date;
  }): Promise<void> {
    await this.db.chestLog.create({
      data: { ...rec, reward: rec.reward as unknown as Prisma.InputJsonValue },
    });
  }

  async counters(
    userId: string,
    periods: readonly string[],
  ): Promise<Record<string, Record<string, number>>> {
    const out: Record<string, Record<string, number>> = {};
    for (const p of periods) out[p] = {};
    const rows = await this.db.questCounter.findMany({
      where: { userId, period: { in: [...periods] } },
    });
    for (const r of rows) out[r.period]![r.metric] = r.value;
    return out;
  }

  async bump(userId: string, periods: readonly string[], metric: string, n: number): Promise<void> {
    for (const period of periods) {
      await this.db.questCounter.upsert({
        where: { userId_period_metric: { userId, period, metric } },
        update: { value: { increment: n } },
        create: { userId, period, metric, value: n },
      });
    }
  }

  async claims(
    userId: string,
    periods: readonly string[],
  ): Promise<Array<{ questId: string; period: string }>> {
    const rows = await this.db.questClaim.findMany({
      where: { userId, period: { in: [...periods] } },
      select: { questId: true, period: true },
    });
    return rows;
  }

  async addClaim(userId: string, questId: string, period: string, at: Date): Promise<boolean> {
    try {
      await this.db.questClaim.create({ data: { userId, questId, period, claimedAt: at } });
      return true;
    } catch (err) {
      if (isUnique(err)) return false;
      throw err;
    }
  }

  async login(userId: string): Promise<LoginRecord | null> {
    const r = await this.db.loginStreak.findUnique({ where: { userId } });
    return r ? { day: r.day, streak: r.streak } : null;
  }

  async setLogin(userId: string, rec: LoginRecord): Promise<void> {
    await this.db.loginStreak.upsert({
      where: { userId },
      update: { day: rec.day, streak: rec.streak },
      create: { userId, day: rec.day, streak: rec.streak },
    });
  }

  async addSeasonStat(
    seasonId: string,
    userId: string,
    delta: { wins: number; kills: number },
  ): Promise<void> {
    await this.db.seasonStat.upsert({
      where: { seasonId_userId: { seasonId, userId } },
      update: { wins: { increment: delta.wins }, kills: { increment: delta.kills } },
      create: { seasonId, userId, wins: delta.wins, kills: delta.kills },
    });
  }

  async leagueRows(worldId: string, seasonId: string): Promise<LeagueRow[]> {
    const castles = await this.db.castle.findMany({
      where: { worldId, isGodAction: false },
      select: { userId: true, power: true, user: { select: { nickname: true } } },
    });
    const [stats, members] = await Promise.all([
      this.db.seasonStat.findMany({ where: { seasonId } }),
      this.db.guildMember.findMany({ where: { worldId }, select: { userId: true, guildId: true } }),
    ]);
    const statOf = new Map(stats.map((s) => [s.userId, s]));
    const guildOf = new Map(members.map((m) => [m.userId, m.guildId]));
    return castles.map((c) => ({
      userId: c.userId,
      nickname: c.user.nickname,
      power: c.power,
      wins: statOf.get(c.userId)?.wins ?? 0,
      kills: statOf.get(c.userId)?.kills ?? 0,
      guildId: guildOf.get(c.userId) ?? null,
    }));
  }

  async unclosedSeasons(before: string): Promise<string[]> {
    const rows = await this.db.seasonStat.findMany({
      where: { seasonId: { lt: before } },
      distinct: ['seasonId'],
      select: { seasonId: true },
    });
    const ids = rows.map((r) => r.seasonId);
    if (ids.length === 0) return [];
    const closed = await this.db.season.findMany({
      where: { id: { in: ids } },
      select: { id: true },
    });
    const done = new Set(closed.map((c) => c.id));
    return ids.filter((id) => !done.has(id)).sort();
  }

  async closeSeason(
    seasonId: string,
    closedAt: Date,
    rewards: SeasonRewardRecord[],
  ): Promise<boolean> {
    try {
      await this.db.season.create({ data: { id: seasonId, closedAt } });
    } catch (err) {
      if (isUnique(err)) return false;
      throw err;
    }
    if (rewards.length > 0) {
      await this.db.seasonReward.createMany({
        data: rewards.map((r) => ({
          seasonId: r.seasonId,
          userId: r.userId,
          place: r.place,
          gems: r.gems,
          chest: r.chest,
          claimedAt: r.claimedAt,
        })),
      });
    }
    return true;
  }

  async unclaimedRewards(userId: string): Promise<SeasonRewardRecord[]> {
    const rows = await this.db.seasonReward.findMany({
      where: { userId, claimedAt: null },
      orderBy: { seasonId: 'asc' },
    });
    return rows.map((r) => ({ ...r, chest: asChest(r.chest) }));
  }

  async claimReward(seasonId: string, userId: string, at: Date): Promise<boolean> {
    const done = await this.db.seasonReward.updateMany({
      where: { seasonId, userId, claimedAt: null },
      data: { claimedAt: at },
    });
    return done.count === 1;
  }
}
