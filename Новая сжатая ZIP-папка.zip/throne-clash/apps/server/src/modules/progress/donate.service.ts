import {
  DONATE_PACKS,
  MAIN_WORLD_ID,
  donateTotal,
  findDonatePack,
  type CastleDto,
  type DonateDto,
  type DonateMode,
} from '@tc/shared';
import { AppError, Errors } from '../../lib/errors';
import { settleAggregate, toCastleDto } from '../castle/castle.realm';
import { gemEvent, type CastleResult, type RealmRunner } from '../castle/castle.runner';
import type { CastleRepository } from '../castle/castle.types';
import type { Clock } from '../../lib/clock';

export interface DonateBuyResult {
  castle: CastleDto;
  granted: number;
}

/**
 * Магазин донатов (D-62). Режим `off`: покупать нельзя (по умолчанию, и в production). Режим `test`:
 * кристаллы начисляются без денег, чтобы проверить весь путь от кнопки до баланса; в журнале экономики
 * такая выдача помечена `donate_test`. Реальный провайдер подключается через PaymentProvider.
 */
export class DonateService {
  private readonly worldId: string;

  constructor(
    private readonly deps: {
      runner: RealmRunner;
      repo: CastleRepository;
      clock: Clock;
      mode: DonateMode;
      worldId?: string;
    },
  ) {
    this.worldId = deps.worldId ?? MAIN_WORLD_ID;
  }

  async catalog(userId: string): Promise<DonateDto> {
    const now = this.deps.clock.now();
    const gems = await this.deps.repo.transaction(async (tx) => {
      const agg = await tx.load(userId, this.worldId);
      if (!agg) throw Errors.notFound('Castle');
      return toCastleDto(settleAggregate(agg, now).draft, now).gems;
    });
    return {
      mode: this.deps.mode,
      gems,
      packs: DONATE_PACKS.map((p) => ({ ...p, total: donateTotal(p) })),
    };
  }

  async buy(
    userId: string,
    packId: string,
    idemKey: string,
  ): Promise<CastleResult<DonateBuyResult>> {
    const pack = findDonatePack(packId);
    if (!pack) throw Errors.notFound('Donate pack');
    if (this.deps.mode !== 'test') {
      throw new AppError('ERR_FORBIDDEN', 403, 'Payments are not available', {
        reason: 'payments_disabled',
      });
    }
    const total = donateTotal(pack);
    return this.deps.runner.mutate<DonateBuyResult>(
      userId,
      `donate:${packId}`,
      idemKey,
      (draft, now) => {
        draft.gems += total;
        return [gemEvent(draft, now, 'donate_test', total)];
      },
      undefined,
      { wrap: (castle) => ({ castle, granted: total }) },
    );
  }
}
