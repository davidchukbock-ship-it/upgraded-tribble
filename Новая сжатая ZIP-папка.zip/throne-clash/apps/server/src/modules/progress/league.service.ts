import { randomUUID } from 'node:crypto';
import {
  CHEST_KINDS,
  MAIN_WORLD_ID,
  ME_WINDOW,
  TOP_SIZE,
  leaguePoints,
  metricValue,
  placePrize,
  seasonEnd,
  seasonId,
  seasonStartOf,
  type ChestKind,
  type LeagueDto,
  type LeagueEntryDto,
  type LeagueMetric,
  type LeagueScope,
  type QuestReward,
  type RewardResultDto,
} from '@tc/shared';
import type { Clock } from '../../lib/clock';
import { Errors } from '../../lib/errors';
import type { CastleResult, RealmRunner } from '../castle/castle.runner';
import type { CastleRepository } from '../castle/castle.types';
import type { NotificationRecord } from '../social/social.types';
import { grantReward, mutateWithReward } from './progress.logic';
import { chestKey, type LeagueRow, type SeasonRewardRecord } from './progress.types';

interface Ranked extends LeagueRow {
  value: number;
  points: number;
  place: number;
}

/** Таблица по метрике: убывание значения, при равенстве — по нику и id (порядок стабилен). */
function rank(rows: readonly LeagueRow[], metric: LeagueMetric): Ranked[] {
  return rows
    .map((r) => ({ ...r, value: metricValue(metric, r), points: leaguePoints(r), place: 0 }))
    .sort(
      (a, b) =>
        b.value - a.value || a.nickname.localeCompare(b.nickname) || (a.userId < b.userId ? -1 : 1),
    )
    .map((r, i) => ({ ...r, place: i + 1 }));
}

/** Лига недели: таблицы, закрытие сезона с раздачей призов и получение призов. */
export class LeagueService {
  private readonly worldId: string;

  constructor(
    private readonly deps: {
      runner: RealmRunner;
      repo: CastleRepository;
      clock: Clock;
      onNotify?: (userId: string, notes: NotificationRecord[]) => void;
      /** Сколько миллисекунд держать строки таблицы в памяти (0 — не кэшировать). */
      cacheMs?: number;
      worldId?: string;
    },
  ) {
    this.worldId = deps.worldId ?? MAIN_WORLD_ID;
  }

  private cache: { sid: string; at: number; rows: LeagueRow[] } | null = null;

  /** Строки таблицы: читаются целиком, поэтому короткий кэш снимает основную нагрузку (D-46). */
  private async rows(sid: string, now: Date): Promise<LeagueRow[]> {
    const ttl = this.deps.cacheMs ?? 0;
    const hit = this.cache;
    if (ttl > 0 && hit && hit.sid === sid && now.getTime() - hit.at < ttl) return hit.rows;
    const rows = await this.deps.repo.transaction((tx) =>
      tx.progress.leagueRows(this.worldId, sid),
    );
    this.cache = { sid, at: now.getTime(), rows };
    return rows;
  }

  async standings(userId: string, scope: LeagueScope, metric: LeagueMetric): Promise<LeagueDto> {
    await this.closeDue();
    const now = this.deps.clock.now();
    const sid = seasonId(now);
    const rows = await this.rows(sid, now);
    return this.deps.repo.transaction(async (tx) => {
      const all = rank(rows, metric);
      const mine = all.find((r) => r.userId === userId) ?? null;
      let table = all;
      if (scope === 'guild') {
        table = mine?.guildId ? all.filter((r) => r.guildId === mine.guildId) : [];
        table = table.map((r, i) => ({ ...r, place: i + 1 }));
      }
      const myRow = table.find((r) => r.userId === userId) ?? null;
      const slice =
        scope === 'top100'
          ? table.slice(0, TOP_SIZE)
          : scope === 'me'
            ? myRow
              ? table.slice(Math.max(0, myRow.place - 1 - ME_WINDOW), myRow.place + ME_WINDOW)
              : []
            : table;
      const entries: LeagueEntryDto[] = slice.map((r) => ({
        place: r.place,
        userId: r.userId,
        nickname: r.nickname,
        value: r.value,
        isMe: r.userId === userId,
      }));
      const pending = (await tx.progress.unclaimedRewards(userId)).map((r) => ({
        seasonId: r.seasonId,
        place: r.place,
        gems: r.gems,
        chest: r.chest,
      }));
      // Приз за место — всегда по общей таблице очков, а не по выбранному фильтру
      const overall = (metric === 'points' ? all : rank(rows, 'points')).find(
        (r) => r.userId === userId,
      );
      return {
        seasonId: sid,
        endsAt: seasonEnd(now).toISOString(),
        metric,
        scope,
        entries,
        me: mine ? { place: myRow?.place ?? null, value: mine.value, points: mine.points } : null,
        pending,
        prize: placePrize(overall?.place ?? Infinity),
      };
    });
  }

  /**
   * Закрывает завершившиеся сезоны: место в таблице очков → приз. Приз получают только участники
   * (те, кто воевал за сезон). Очки берут мощь на момент закрытия (D-46).
   * Вызывается по таймеру и при чтении таблицы; повторное закрытие невозможно (Season.id уникален).
   */
  async closeDue(): Promise<number> {
    const now = this.deps.clock.now();
    const current = seasonId(now);
    const open = await this.deps.repo.transaction((tx) => tx.progress.unclosedSeasons(current));
    let closed = 0;
    for (const sid of open) {
      if (!seasonStartOf(sid)) continue;
      const delivered: Array<[string, NotificationRecord[]]> = [];
      const ok = await this.deps.repo.transaction(async (tx) => {
        const rows = await tx.progress.leagueRows(this.worldId, sid);
        const rewards: SeasonRewardRecord[] = [];
        for (const r of rank(rows, 'points')) {
          if (r.wins === 0 && r.kills === 0) continue;
          const prize = placePrize(r.place);
          rewards.push({
            seasonId: sid,
            userId: r.userId,
            place: r.place <= TOP_SIZE ? r.place : null,
            gems: prize.gems,
            chest: prize.chest,
            claimedAt: null,
          });
        }
        if (!(await tx.progress.closeSeason(sid, now, rewards))) return false;
        const notes = rewards.map((r) => ({
          id: randomUUID(),
          userId: r.userId,
          kind: 'season.reward' as const,
          payload: { seasonId: sid, place: r.place, gems: r.gems },
          read: false,
          createdAt: now,
        }));
        await tx.notifications.add(notes);
        for (const n of notes) delivered.push([n.userId, [n]]);
        return true;
      });
      if (ok) {
        closed++;
        for (const [userId, notes] of delivered) this.deps.onNotify?.(userId, notes);
      }
    }
    return closed;
  }

  /** Забирает все призы за прошедшие сезоны: кристаллы, сундук места и деревянный сундук участника. */
  claim(userId: string, idemKey: string): Promise<CastleResult<RewardResultDto>> {
    return mutateWithReward(
      this.deps.runner,
      userId,
      'season-claim',
      idemKey,
      async (draft, now, tx) => {
        const list = await tx.progress.unclaimedRewards(userId);
        if (list.length === 0) throw Errors.requirementNotMet({ reason: 'nothing_to_claim' });
        const events = [];
        let gems = 0;
        let best: ChestKind | null = null;
        for (const r of list) {
          if (!(await tx.progress.claimReward(r.seasonId, userId, now)))
            throw Errors.conflict('Reward already claimed');
          events.push(
            ...(await grantReward(
              draft,
              tx,
              { gems: r.gems, ...(r.chest && { chest: r.chest }) },
              now,
              'season_reward',
            )),
          );
          await tx.progress.addItem(userId, chestKey('wooden'), 1);
          gems += r.gems;
          for (const k of [r.chest, 'wooden' as const]) {
            if (k && (!best || CHEST_KINDS.indexOf(k) > CHEST_KINDS.indexOf(best))) best = k;
          }
        }
        const reward: QuestReward = { gems, ...(best && { chest: best }) };
        return { reward, events };
      },
    );
  }
}
