import { randomInt } from 'node:crypto';
import {
  BOOSTER_KEYS,
  CHEST_KINDS,
  addAmounts,
  armyCount,
  claimPeriod,
  dayKey,
  isCounter,
  isPremiumCrest,
  type BoosterKey,
  type ChestKind,
  type InventoryDto,
  type QuestDef,
  type QuestDto,
  type QuestReward,
  type ResourceAmounts,
  type RewardDto,
  type RewardResultDto,
} from '@tc/shared';
import { aggregatePower, marchingCount } from '../castle/castle.realm';
import {
  gemEvent,
  resourceEvents,
  type CastleResult,
  type RealmRunner,
} from '../castle/castle.runner';
import type { CastleAggregate, CastleTx, EconomyEventRecord } from '../castle/castle.types';
import { boostKey, chestKey } from './progress.types';

/** Криптографический источник [0, 1) для сундуков (D-08: игровая случайность не через Math.random). */
export const secureRandom = (): number => randomInt(0, 0x1_0000_0000) / 0x1_0000_0000;

export const periodsOf = (now: Date): string[] => ['total', dayKey(now)];

const ZERO: ResourceAmounts = { gold: 0, wood: 0, stone: 0, food: 0 };

export function rewardDto(r: QuestReward): RewardDto {
  return {
    resources: r.resources ? { ...ZERO, ...r.resources } : null,
    gems: r.gems ?? 0,
    chest: r.chest ?? null,
  };
}

export function inventoryDto(raw: Record<string, number>): InventoryDto {
  const chests = Object.fromEntries(CHEST_KINDS.map((k) => [k, raw[chestKey(k)] ?? 0])) as Record<
    ChestKind,
    number
  >;
  const boosters = Object.fromEntries(
    BOOSTER_KEYS.map((k) => [k, raw[boostKey(k)] ?? 0]),
  ) as Record<BoosterKey, number>;
  const crests = Object.keys(raw)
    .filter((k) => k.startsWith('crest:'))
    .map((k) => k.slice('crest:'.length))
    .filter(isPremiumCrest)
    .sort();
  return { chests, boosters, crests };
}

/** Выдаёт награду задания/входа/сезона: ресурсы и кристаллы — в замок, сундук — в инвентарь. */
export async function grantReward(
  draft: CastleAggregate,
  tx: CastleTx,
  reward: QuestReward,
  now: Date,
  kind: string,
): Promise<EconomyEventRecord[]> {
  const events: EconomyEventRecord[] = [];
  if (reward.resources) {
    const add = { ...ZERO, ...reward.resources };
    // Награда может поднять запас выше ёмкости склада — лишнее не сгорает (как возврат при отмене)
    draft.resources = addAmounts(draft.resources, add);
    events.push(...resourceEvents(draft, now, kind, add));
  }
  if (reward.gems) {
    draft.gems += reward.gems;
    events.push(gemEvent(draft, now, kind, reward.gems));
  }
  if (reward.chest) await tx.progress.addItem(draft.userId, chestKey(reward.chest), 1);
  return events;
}

// ── Прогресс заданий ────────────────────────────────────────────────────────

export interface QuestContext {
  day: string;
  total: Record<string, number>;
  today: Record<string, number>;
  claimed: Set<string>;
  agg: CastleAggregate;
  inGuild: boolean;
}

export async function loadQuestContext(
  tx: CastleTx,
  agg: CastleAggregate,
  now: Date,
): Promise<QuestContext> {
  const day = dayKey(now);
  const [counters, claims, membership] = await Promise.all([
    tx.progress.counters(agg.userId, ['total', day]),
    tx.progress.claims(agg.userId, ['once', day]),
    tx.guilds.findByUser(agg.userId, agg.worldId),
  ]);
  return {
    day,
    total: counters.total ?? {},
    today: counters[day] ?? {},
    claimed: new Set(claims.map((c) => `${c.questId}|${c.period}`)),
    agg,
    inGuild: membership !== null,
  };
}

const sum = (o: Record<string, number | undefined>): number =>
  Object.values(o).reduce<number>((s, v) => s + (v ?? 0), 0);

export function progressOf(q: QuestDef, c: QuestContext): number {
  if (isCounter(q.metric)) return (q.kind === 'daily' ? c.today : c.total)[q.metric] ?? 0;
  const a = c.agg;
  switch (q.metric) {
    case 'castle_level':
      return a.levels.castle ?? 1;
    case 'barracks_level':
      return a.levels.barracks ?? 0;
    case 'academy_level':
      return a.levels.academy ?? 0;
    case 'tech_total':
      return sum(a.tech);
    case 'hero_skills':
      return a.hero ? sum(a.hero.skills) : 0;
    case 'power':
      return aggregatePower(a);
    case 'army':
      return armyCount(a.army) + marchingCount(a);
    case 'guild':
      return c.inGuild ? 1 : 0;
    case 'wins_total':
      return c.total.win ?? 0;
    default:
      return 0;
  }
}

export function questDto(q: QuestDef, c: QuestContext): QuestDto {
  const raw = progressOf(q, c);
  const claimed = c.claimed.has(`${q.id}|${claimPeriod(q, c.day)}`);
  return {
    id: q.id,
    kind: q.kind,
    metric: q.metric,
    target: q.target,
    progress: Math.min(raw, q.target),
    reward: rewardDto(q.reward),
    claimed,
    claimable: !claimed && raw >= q.target,
    route: q.route ?? null,
  };
}

/**
 * Действие, выдающее награду: ответ содержит замок, награду и инвентарь (для повтора по Idempotency-Key
 * всё это сохраняется вместе с ответом).
 */
export function mutateWithReward(
  runner: RealmRunner,
  userId: string,
  route: string,
  idemKey: string,
  run: (
    draft: CastleAggregate,
    now: Date,
    tx: CastleTx,
  ) => Promise<{ reward: QuestReward; events: EconomyEventRecord[] }>,
): Promise<CastleResult<RewardResultDto>> {
  let given: RewardDto | null = null;
  let inventory = inventoryDto({});
  return runner.mutate<RewardResultDto>(
    userId,
    route,
    idemKey,
    async (draft, now, _emit, tx) => {
      const out = await run(draft, now, tx);
      given = rewardDto(out.reward);
      return out.events;
    },
    async (tx) => {
      inventory = inventoryDto(await tx.progress.inventory(userId));
    },
    { wrap: (castle) => ({ castle, reward: given!, inventory }) },
  );
}
