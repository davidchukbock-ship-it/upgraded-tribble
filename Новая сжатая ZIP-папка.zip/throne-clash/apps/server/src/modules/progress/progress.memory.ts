import type { ChestKind, ChestReward } from '@tc/shared';
import type { LeagueRow, LoginRecord, ProgressStore, SeasonRewardRecord } from './progress.types';

export interface ChestLogRecord {
  id: string;
  userId: string;
  kind: ChestKind;
  reward: ChestReward;
  createdAt: Date;
}

/** Общее состояние; изменяется на месте, чтобы его делили все транзакции. */
class State {
  items = new Map<string, number>();
  counters = new Map<string, number>();
  claims = new Map<string, Date>();
  logins = new Map<string, LoginRecord>();
  stats = new Map<string, { wins: number; kills: number }>();
  closed = new Map<string, Date>();
  rewards: SeasonRewardRecord[] = [];
  chestLog: ChestLogRecord[] = [];
}

/** Источник строк лиги: замки и ники берутся из остальных in-memory хранилищ. */
export interface LeagueSource {
  (worldId: string): Array<Omit<LeagueRow, 'wins' | 'kills'>>;
}

/**
 * In-memory прогресс для юнит-тестов. Записи применяются сразу; откат транзакции — журналом обратных
 * операций (а не снимком): параллельная транзакция, успевшая зафиксироваться, не «воскресает» при чужом откате.
 */
export class MemoryProgress implements ProgressStore {
  private readonly undo: Array<() => void> = [];

  constructor(
    private readonly source: LeagueSource,
    private readonly state: State = new State(),
  ) {}

  /** Хранилище для одной транзакции: общее состояние, свой журнал отката. */
  begin(): MemoryProgress {
    return new MemoryProgress(this.source, this.state);
  }

  rollback(): void {
    while (this.undo.length > 0) this.undo.pop()!();
  }

  get chestLog(): readonly ChestLogRecord[] {
    return this.state.chestLog;
  }

  private add(map: Map<string, number>, k: string, delta: number): void {
    map.set(k, (map.get(k) ?? 0) + delta);
    this.undo.push(() => map.set(k, (map.get(k) ?? 0) - delta));
  }

  async inventory(userId: string): Promise<Record<string, number>> {
    const out: Record<string, number> = {};
    for (const [k, n] of this.state.items) {
      const [u, ...rest] = k.split('|');
      if (u === userId && n > 0) out[rest.join('|')] = n;
    }
    return out;
  }

  async addItem(userId: string, key: string, delta: number): Promise<boolean> {
    const k = `${userId}|${key}`;
    if ((this.state.items.get(k) ?? 0) + delta < 0) return false;
    this.add(this.state.items, k, delta);
    return true;
  }

  async logChest(rec: ChestLogRecord): Promise<void> {
    this.state.chestLog.push(structuredClone(rec));
    this.undo.push(() => {
      this.state.chestLog = this.state.chestLog.filter((r) => r.id !== rec.id);
    });
  }

  async counters(
    userId: string,
    periods: readonly string[],
  ): Promise<Record<string, Record<string, number>>> {
    const out: Record<string, Record<string, number>> = {};
    for (const p of periods) out[p] = {};
    for (const [k, v] of this.state.counters) {
      const [u, period, metric] = k.split('|');
      if (u === userId && period !== undefined && metric !== undefined && period in out) {
        out[period]![metric] = v;
      }
    }
    return out;
  }

  async bump(userId: string, periods: readonly string[], metric: string, n: number): Promise<void> {
    for (const p of periods) this.add(this.state.counters, `${userId}|${p}|${metric}`, n);
  }

  async claims(
    userId: string,
    periods: readonly string[],
  ): Promise<Array<{ questId: string; period: string }>> {
    const out: Array<{ questId: string; period: string }> = [];
    for (const k of this.state.claims.keys()) {
      const [u, questId, period] = k.split('|');
      if (u === userId && questId !== undefined && period !== undefined && periods.includes(period))
        out.push({ questId, period });
    }
    return out;
  }

  async addClaim(userId: string, questId: string, period: string, at: Date): Promise<boolean> {
    const k = `${userId}|${questId}|${period}`;
    if (this.state.claims.has(k)) return false;
    this.state.claims.set(k, at);
    this.undo.push(() => this.state.claims.delete(k));
    return true;
  }

  async login(userId: string): Promise<LoginRecord | null> {
    const r = this.state.logins.get(userId);
    return r ? { ...r } : null;
  }

  async setLogin(userId: string, rec: LoginRecord): Promise<void> {
    const prev = this.state.logins.get(userId);
    this.state.logins.set(userId, { ...rec });
    this.undo.push(() => {
      if (prev) this.state.logins.set(userId, prev);
      else this.state.logins.delete(userId);
    });
  }

  async addSeasonStat(
    seasonId: string,
    userId: string,
    delta: { wins: number; kills: number },
  ): Promise<void> {
    const k = `${seasonId}|${userId}`;
    const cur = this.state.stats.get(k) ?? { wins: 0, kills: 0 };
    this.state.stats.set(k, { wins: cur.wins + delta.wins, kills: cur.kills + delta.kills });
    this.undo.push(() => {
      const now = this.state.stats.get(k) ?? { wins: 0, kills: 0 };
      this.state.stats.set(k, { wins: now.wins - delta.wins, kills: now.kills - delta.kills });
    });
  }

  async leagueRows(worldId: string, seasonId: string): Promise<LeagueRow[]> {
    return this.source(worldId).map((r) => ({
      ...r,
      wins: this.state.stats.get(`${seasonId}|${r.userId}`)?.wins ?? 0,
      kills: this.state.stats.get(`${seasonId}|${r.userId}`)?.kills ?? 0,
    }));
  }

  async unclosedSeasons(before: string): Promise<string[]> {
    const ids = new Set<string>();
    for (const k of this.state.stats.keys()) {
      const id = k.split('|')[0]!;
      if (id < before && !this.state.closed.has(id)) ids.add(id);
    }
    return [...ids].sort();
  }

  async closeSeason(
    seasonId: string,
    closedAt: Date,
    rewards: SeasonRewardRecord[],
  ): Promise<boolean> {
    if (this.state.closed.has(seasonId)) return false;
    this.state.closed.set(seasonId, closedAt);
    this.state.rewards.push(...structuredClone(rewards));
    this.undo.push(() => {
      this.state.closed.delete(seasonId);
      this.state.rewards = this.state.rewards.filter((r) => r.seasonId !== seasonId);
    });
    return true;
  }

  async unclaimedRewards(userId: string): Promise<SeasonRewardRecord[]> {
    return structuredClone(
      this.state.rewards.filter((r) => r.userId === userId && r.claimedAt === null),
    );
  }

  async claimReward(seasonId: string, userId: string, at: Date): Promise<boolean> {
    const r = this.state.rewards.find((x) => x.seasonId === seasonId && x.userId === userId);
    if (!r || r.claimedAt !== null) return false;
    r.claimedAt = at;
    this.undo.push(() => {
      r.claimedAt = null;
    });
    return true;
  }
}
