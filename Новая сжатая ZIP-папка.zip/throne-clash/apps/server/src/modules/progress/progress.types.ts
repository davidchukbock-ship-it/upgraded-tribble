import type { ChestKind, ChestReward } from '@tc/shared';

/** Строка таблицы лиги: игрок с мощью и сезонными победами/убийствами. */
export interface LeagueRow {
  userId: string;
  nickname: string;
  power: number;
  wins: number;
  kills: number;
  guildId: string | null;
}

export interface SeasonRewardRecord {
  seasonId: string;
  userId: string;
  /** Место в таблице очков; null — награда за участие. */
  place: number | null;
  gems: number;
  chest: ChestKind | null;
  claimedAt: Date | null;
}

export interface LoginRecord {
  /** Последний день, за который получена награда (UTC, YYYY-MM-DD). */
  day: string;
  streak: number;
}

/** Ключи инвентаря: `chest:<вид>`, `boost:<ключ>`, `crest:<герб>`. */
export const chestKey = (k: ChestKind): string => `chest:${k}`;
export const boostKey = (k: string): string => `boost:${k}`;
export const crestKey = (k: string): string => `crest:${k}`;

/**
 * Прогресс игрока: инвентарь, счётчики и награды заданий, серия входов, сезоны лиг.
 * Работает в той же транзакции, что и замок (D-44): награда и списание фиксируются вместе.
 */
export interface ProgressStore {
  // ── Инвентарь ──
  inventory(userId: string): Promise<Record<string, number>>;
  /** Меняет количество на delta. false — не хватает, ничего не изменено (ниже нуля не уходим). */
  addItem(userId: string, key: string, delta: number): Promise<boolean>;

  /** Журнал открытия сундуков (что выпало). */
  logChest(rec: {
    id: string;
    userId: string;
    kind: ChestKind;
    reward: ChestReward;
    createdAt: Date;
  }): Promise<void>;

  // ── Задания ──
  /** Счётчики по периодам: период → метрика → значение. */
  counters(
    userId: string,
    periods: readonly string[],
  ): Promise<Record<string, Record<string, number>>>;
  bump(userId: string, periods: readonly string[], metric: string, n: number): Promise<void>;
  claims(
    userId: string,
    periods: readonly string[],
  ): Promise<Array<{ questId: string; period: string }>>;
  /** false — награда за это задание в этом периоде уже получена. */
  addClaim(userId: string, questId: string, period: string, at: Date): Promise<boolean>;
  login(userId: string): Promise<LoginRecord | null>;
  setLogin(userId: string, rec: LoginRecord): Promise<void>;

  // ── Сезоны ──
  addSeasonStat(
    seasonId: string,
    userId: string,
    delta: { wins: number; kills: number },
  ): Promise<void>;
  /** Все игроки мира (без созданных режимом бога) с сезонной статистикой. */
  leagueRows(worldId: string, seasonId: string): Promise<LeagueRow[]>;
  /** Сезоны со статистикой, которые начались раньше `before` и ещё не закрыты. */
  unclosedSeasons(before: string): Promise<string[]>;
  /** Помечает сезон закрытым и раскладывает награды. false — уже закрыт другим процессом. */
  closeSeason(seasonId: string, closedAt: Date, rewards: SeasonRewardRecord[]): Promise<boolean>;
  unclaimedRewards(userId: string): Promise<SeasonRewardRecord[]>;
  /** false — награда уже получена. */
  claimReward(seasonId: string, userId: string, at: Date): Promise<boolean>;
}
