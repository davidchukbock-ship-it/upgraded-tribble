import {
  ACHIEVEMENTS,
  DAILY,
  LOGIN_REWARDS,
  MAIN_WORLD_ID,
  TUTORIAL,
  claimPeriod,
  dayKey,
  findQuest,
  loginState,
  type QuestsDto,
  type RewardResultDto,
} from '@tc/shared';
import type { Clock } from '../../lib/clock';
import { Errors } from '../../lib/errors';
import { settleAggregate } from '../castle/castle.realm';
import type { CastleResult, RealmRunner } from '../castle/castle.runner';
import type { CastleRepository } from '../castle/castle.types';
import {
  grantReward,
  loadQuestContext,
  mutateWithReward,
  questDto,
  rewardDto,
} from './progress.logic';

const DAY_MS = 86_400_000;

/** Задания, достижения, ежедневный вход. Прогресс считается на сервере; награда выдаётся один раз (D-44). */
export class QuestService {
  private readonly worldId: string;

  constructor(
    private readonly deps: {
      runner: RealmRunner;
      repo: CastleRepository;
      clock: Clock;
      before?: (userId: string) => Promise<void>;
      worldId?: string;
    },
  ) {
    this.worldId = deps.worldId ?? MAIN_WORLD_ID;
  }

  async list(userId: string): Promise<QuestsDto> {
    await this.deps.before?.(userId);
    const now = this.deps.clock.now();
    return this.deps.repo.transaction(async (tx) => {
      const agg = await tx.load(userId, this.worldId);
      if (!agg) throw Errors.notFound('Castle');
      const ctx = await loadQuestContext(tx, settleAggregate(agg, now).draft, now);
      const tutorial = TUTORIAL.map((q) => questDto(q, ctx));
      const daily = DAILY.map((q) => questDto(q, ctx));
      const achievements = ACHIEVEMENTS.map((q) => questDto(q, ctx));
      const state = loginState(await tx.progress.login(userId), ctx.day);
      const tomorrow = new Date(Date.parse(`${ctx.day}T00:00:00Z`) + DAY_MS);
      const claimable =
        [...tutorial, ...daily, ...achievements].filter((q) => q.claimable).length +
        (state.claimed ? 0 : 1);
      return {
        tutorial,
        daily,
        achievements,
        login: {
          day: state.day,
          claimed: state.claimed,
          rewards: LOGIN_REWARDS.map(rewardDto),
        },
        dailyResetAt: tomorrow.toISOString(),
        claimable,
      };
    });
  }

  async claim(
    userId: string,
    questId: string,
    idemKey: string,
  ): Promise<CastleResult<RewardResultDto>> {
    const def = findQuest(questId);
    if (!def) throw Errors.notFound('Quest');
    return mutateWithReward(
      this.deps.runner,
      userId,
      `quest:${questId}`,
      idemKey,
      async (draft, now, tx) => {
        const ctx = await loadQuestContext(tx, draft, now);
        const dto = questDto(def, ctx);
        if (dto.claimed) throw Errors.conflict('Reward already claimed');
        if (!dto.claimable) throw Errors.requirementNotMet({ reason: 'not_done' });
        if (!(await tx.progress.addClaim(userId, def.id, claimPeriod(def, ctx.day), now)))
          throw Errors.conflict('Reward already claimed');
        return {
          reward: def.reward,
          events: await grantReward(draft, tx, def.reward, now, `quest_${def.kind}`),
        };
      },
    );
  }

  claimLogin(userId: string, idemKey: string): Promise<CastleResult<RewardResultDto>> {
    return mutateWithReward(
      this.deps.runner,
      userId,
      'login-claim',
      idemKey,
      async (draft, now, tx) => {
        const today = dayKey(now);
        const state = loginState(await tx.progress.login(userId), today);
        if (state.claimed) throw Errors.conflict('Reward already claimed today');
        const reward = LOGIN_REWARDS[state.day - 1]!;
        await tx.progress.setLogin(userId, { day: today, streak: state.day });
        return { reward, events: await grantReward(draft, tx, reward, now, 'login_reward') };
      },
    );
  }
}
