import type { FastifyInstance } from 'fastify';
import type { ZodTypeProvider } from 'fastify-type-provider-zod';
import { z } from 'zod';
import type { BoosterKey } from '@tc/shared';
import { sendResult } from '../castle/castle.controller';
import { errorSchema, failures, idempotencyHeaders } from '../castle/castle.schema';
import { chestOdds, type ChestService } from './chest.service';
import type { LeagueService } from './league.service';
import {
  boosterUseSchema,
  buyBody,
  checkoutBody,
  chestOddsSchema,
  chestOpenSchema,
  inventorySchema,
  kindParams,
  leagueQuery,
  leagueSchema,
  questParams,
  questsSchema,
  freePacksSchema,
  freePackParams,
  rewardResultSchema,
  donateBody,
  donateBuySchema,
  donateSchema,
  shopBuySchema,
  shopSchema,
  useBoosterBody,
} from './progress.schema';
import type { QuestService } from './quest.service';
import type { FreePackService } from './freepack.service';
import type { DonateService } from './donate.service';
import type { ShopService } from './shop.service';

export function registerProgressRoutes(
  app: FastifyInstance,
  deps: {
    quests: QuestService;
    freePacks: FreePackService;
    chests: ChestService;
    shop: ShopService;
    donate: DonateService;
    leagues: LeagueService;
  },
): void {
  const r = app.withTypeProvider<ZodTypeProvider>();
  const security = [{ bearerAuth: [] }];
  const auth = { preHandler: app.authenticate };
  const read = { 401: errorSchema, 404: errorSchema };
  const uid = (req: { auth?: { user: { id: string } } | undefined }) => req.auth!.user.id;

  // ── Задания ──
  r.get(
    '/quests',
    {
      ...auth,
      schema: {
        tags: ['quests'],
        summary: 'Туториал, ежедневные задания, достижения и ежедневный вход',
        security,
        response: { 200: questsSchema, ...read },
      },
    },
    async (req) => deps.quests.list(uid(req)),
  );

  r.post(
    '/quests/:id/claim',
    {
      ...auth,
      schema: {
        tags: ['quests'],
        summary: 'Забрать награду за выполненное задание',
        security,
        headers: idempotencyHeaders,
        params: questParams,
        response: { 200: rewardResultSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await deps.quests.claim(uid(req), req.params.id, req.headers['idempotency-key']),
      ),
  );

  r.post(
    '/daily/claim',
    {
      ...auth,
      schema: {
        tags: ['quests'],
        summary: 'Награда за ежедневный вход',
        security,
        headers: idempotencyHeaders,
        response: { 200: rewardResultSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(reply, await deps.quests.claimLogin(uid(req), req.headers['idempotency-key'])),
  );

  // ── Бесплатные наборы ──
  r.get(
    '/free-packs',
    {
      ...auth,
      schema: {
        tags: ['quests'],
        summary: 'Бесплатные наборы по времени и их состояние',
        security,
        response: { 200: freePacksSchema, ...read },
      },
    },
    async (req) => deps.freePacks.list(uid(req)),
  );

  r.post(
    '/free-packs/:id/claim',
    {
      ...auth,
      schema: {
        tags: ['quests'],
        summary: 'Забрать бесплатный набор (один раз за окно)',
        security,
        headers: idempotencyHeaders,
        params: freePackParams,
        response: { 200: rewardResultSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await deps.freePacks.claim(uid(req), req.params.id, req.headers['idempotency-key']),
      ),
  );

  // ── Сундуки и инвентарь ──
  r.get(
    '/chests/odds',
    {
      schema: {
        tags: ['chests'],
        summary: 'Таблица шансов сундуков (публичная)',
        response: { 200: chestOddsSchema },
      },
    },
    async () => chestOdds(),
  );

  r.get(
    '/inventory',
    {
      ...auth,
      schema: {
        tags: ['chests'],
        summary: 'Инвентарь: сундуки, ускорители, гербы',
        security,
        response: { 200: inventorySchema, 401: errorSchema },
      },
    },
    async (req) => deps.chests.inventory(uid(req)),
  );

  r.post(
    '/chests/:kind/open',
    {
      ...auth,
      schema: {
        tags: ['chests'],
        summary: 'Открыть сундук',
        security,
        headers: idempotencyHeaders,
        params: kindParams,
        response: { 200: chestOpenSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await deps.chests.open(uid(req), req.params.kind, req.headers['idempotency-key']),
      ),
  );

  r.post(
    '/inventory/boosters/use',
    {
      ...auth,
      schema: {
        tags: ['chests'],
        summary: 'Применить ускоритель к постройке, обучению или исследованию',
        security,
        headers: idempotencyHeaders,
        body: useBoosterBody,
        response: { 200: boosterUseSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await deps.chests.useBooster(
          uid(req),
          req.body.booster as BoosterKey,
          req.body.target,
          req.body.taskId,
          req.headers['idempotency-key'],
        ),
      ),
  );

  // ── Магазин ──
  r.get(
    '/shop',
    {
      ...auth,
      schema: {
        tags: ['shop'],
        summary: 'Каталог магазина (цены в кристаллах)',
        security,
        response: { 200: shopSchema, ...read },
      },
    },
    async (req) => deps.shop.catalog(uid(req)),
  );

  r.post(
    '/shop/buy',
    {
      ...auth,
      schema: {
        tags: ['shop'],
        summary: 'Купить товар за кристаллы',
        security,
        headers: idempotencyHeaders,
        body: buyBody,
        response: { 200: shopBuySchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await deps.shop.buy(uid(req), req.body.itemId, req.headers['idempotency-key']),
      ),
  );

  r.post(
    '/shop/checkout',
    {
      ...auth,
      schema: {
        tags: ['shop'],
        summary: 'Покупка кристаллов за реальные деньги: не поддерживается (D-11)',
        security,
        body: checkoutBody,
        response: { 200: z.object({ url: z.string() }), 401: errorSchema, 403: errorSchema },
      },
    },
    async (req) => deps.shop.checkout(uid(req), req.body.packId),
  );

  // ── Донаты (D-62) ──
  r.get(
    '/donate',
    {
      ...auth,
      schema: {
        tags: ['donate'],
        summary: 'Каталог пакетов кристаллов и режим оплаты',
        security,
        response: { 200: donateSchema, ...read },
      },
    },
    async (req) => deps.donate.catalog(uid(req)),
  );

  r.post(
    '/donate/buy',
    {
      ...auth,
      schema: {
        tags: ['donate'],
        summary: 'Купить пакет кристаллов (в режиме off — отказ, в test — без денег)',
        security,
        headers: idempotencyHeaders,
        body: donateBody,
        response: { 200: donateBuySchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await deps.donate.buy(uid(req), req.body.packId, req.headers['idempotency-key']),
      ),
  );

  // ── Лиги ──
  r.get(
    '/leagues/current',
    {
      ...auth,
      schema: {
        tags: ['leagues'],
        summary: 'Таблица недельной лиги',
        security,
        querystring: leagueQuery,
        response: { 200: leagueSchema, ...read },
      },
    },
    async (req) => deps.leagues.standings(uid(req), req.query.scope, req.query.metric),
  );

  r.post(
    '/leagues/rewards/claim',
    {
      ...auth,
      schema: {
        tags: ['leagues'],
        summary: 'Забрать призы за прошедшие сезоны',
        security,
        headers: idempotencyHeaders,
        response: { 200: rewardResultSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(reply, await deps.leagues.claim(uid(req), req.headers['idempotency-key'])),
  );
}
