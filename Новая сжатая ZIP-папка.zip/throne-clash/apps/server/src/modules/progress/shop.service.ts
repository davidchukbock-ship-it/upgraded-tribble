import {
  MAIN_WORLD_ID,
  SHOP_CATALOG,
  addAmounts,
  buildSlots,
  findShopItem,
  type CastleDto,
  type InventoryDto,
  type ShopBuyDto,
  type ShopDto,
  type ShopItem,
} from '@tc/shared';
import type { Clock } from '../../lib/clock';
import { AppError, Errors } from '../../lib/errors';
import { castleLevel, settleAggregate, toCastleDto } from '../castle/castle.realm';
import {
  gemEvent,
  resourceEvents,
  type CastleResult,
  type RealmRunner,
} from '../castle/castle.runner';
import type {
  CastleAggregate,
  CastleRepository,
  CastleTx,
  EconomyEventRecord,
} from '../castle/castle.types';
import { inventoryDto } from './progress.logic';
import { boostKey, crestKey } from './progress.types';

/**
 * Платёжный провайдер (D-11): кристаллы нигде не продаются за реальные деньги.
 * Интерфейс — точка расширения для будущего провайдера; единственная реализация отклоняет всё.
 */
export interface PaymentProvider {
  readonly name: string;
  /** Начинает покупку кристаллов за реальные деньги. Возвращает адрес оплаты или бросает ошибку. */
  createCheckout(userId: string, packId: string): Promise<{ url: string }>;
}

export class NullPaymentProvider implements PaymentProvider {
  readonly name = 'null';

  async createCheckout(): Promise<{ url: string }> {
    throw new AppError('ERR_FORBIDDEN', 403, 'Real-money payments are not available', {
      reason: 'payments_disabled',
    });
  }
}

function shopDto(dto: Pick<CastleDto, 'gems' | 'slots'>, inventory: InventoryDto): ShopDto {
  return {
    gems: dto.gems,
    inventory,
    items: SHOP_CATALOG.map((i) => ({
      id: i.id,
      kind: i.kind,
      price: i.price,
      resources: i.resources ?? null,
      booster: i.booster ?? null,
      crest: i.crest ?? null,
      owned:
        i.kind === 'slot' ? !dto.slots.canUnlock : !!i.crest && inventory.crests.includes(i.crest),
    })),
  };
}

/** Магазин за кристаллы: пакеты ресурсов, ускорители, второй слот, гербы. */
export class ShopService {
  private readonly worldId: string;

  constructor(
    private readonly deps: {
      runner: RealmRunner;
      repo: CastleRepository;
      clock: Clock;
      payments?: PaymentProvider;
      worldId?: string;
    },
  ) {
    this.worldId = deps.worldId ?? MAIN_WORLD_ID;
  }

  async catalog(userId: string): Promise<ShopDto> {
    const now = this.deps.clock.now();
    return this.deps.repo.transaction(async (tx) => {
      const agg = await tx.load(userId, this.worldId);
      if (!agg) throw Errors.notFound('Castle');
      return shopDto(
        toCastleDto(settleAggregate(agg, now).draft, now),
        inventoryDto(await tx.progress.inventory(userId)),
      );
    });
  }

  async buy(userId: string, itemId: string, idemKey: string): Promise<CastleResult<ShopBuyDto>> {
    const item = findShopItem(itemId);
    if (!item) throw Errors.notFound('Shop item');
    let inventory = inventoryDto({});
    return this.deps.runner.mutate<ShopBuyDto>(
      userId,
      `shop:${itemId}`,
      idemKey,
      async (draft, now, _emit, tx) => {
        if (draft.gems < item.price)
          throw Errors.insufficientResources({ missing: { gems: item.price - draft.gems } });
        const events = await this.deliver(item, draft, tx, now);
        draft.gems -= item.price;
        return [gemEvent(draft, now, `shop_${item.kind}`, -item.price), ...events];
      },
      async (tx) => {
        inventory = inventoryDto(await tx.progress.inventory(userId));
      },
      { wrap: (castle) => ({ castle, shop: shopDto(castle, inventory) }) },
    );
  }

  /** Заглушка покупки за реальные деньги: всегда отказ (D-11). */
  checkout(userId: string, packId: string): Promise<{ url: string }> {
    return (this.deps.payments ?? new NullPaymentProvider()).createCheckout(userId, packId);
  }

  private async deliver(
    item: ShopItem,
    draft: CastleAggregate,
    tx: CastleTx,
    now: Date,
  ): Promise<EconomyEventRecord[]> {
    switch (item.kind) {
      case 'pack':
        draft.resources = addAmounts(draft.resources, item.resources!);
        return resourceEvents(draft, now, 'shop_pack', item.resources!);
      case 'booster':
        await tx.progress.addItem(draft.userId, boostKey(item.booster!), 1);
        return [];
      case 'slot':
        if (buildSlots(castleLevel(draft), draft.extraBuildSlot) >= 2)
          throw Errors.conflict('Second slot is already available');
        draft.extraBuildSlot = true;
        return [];
      case 'crest':
        if ((await tx.progress.inventory(draft.userId))[crestKey(item.crest!)])
          throw Errors.conflict('Already owned');
        await tx.progress.addItem(draft.userId, crestKey(item.crest!), 1);
        return [];
    }
  }
}
