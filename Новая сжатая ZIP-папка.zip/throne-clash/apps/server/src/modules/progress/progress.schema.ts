import { z } from 'zod';
import {
  BOOSTER_KEYS,
  CHEST_KINDS,
  LEAGUE_METRICS,
  LEAGUE_SCOPES,
  OUTCOME_ORDER,
  EQUIP_SLOTS,
} from '@tc/shared';
import { castleSchema, resourceMap } from '../castle/castle.schema';

export const chestKind = z.enum(CHEST_KINDS);
export const boosterKey = z.enum(BOOSTER_KEYS as [string, ...string[]]);

const chestRecord = z.object({ wooden: z.number(), silver: z.number(), gold: z.number() });

export const inventorySchema = z.object({
  chests: chestRecord,
  boosters: z.object({ boost_5m: z.number(), boost_1h: z.number(), boost_8h: z.number() }),
  crests: z.array(z.string()),
});

export const rewardSchema = z.object({
  resources: resourceMap.nullable(),
  gems: z.number(),
  chest: chestKind.nullable(),
});

const questSchema = z.object({
  id: z.string(),
  kind: z.enum(['tutorial', 'daily', 'achievement']),
  metric: z.string(),
  target: z.number(),
  progress: z.number(),
  reward: rewardSchema,
  claimed: z.boolean(),
  claimable: z.boolean(),
  route: z.string().nullable(),
});

export const freePacksSchema = z.object({
  serverTime: z.string(),
  packs: z.array(
    z.object({
      id: z.string(),
      everyHours: z.number().nullable(),
      reward: rewardSchema,
      claimed: z.boolean(),
      nextAt: z.string().nullable(),
    }),
  ),
  claimable: z.number(),
});

export const freePackParams = z.object({ id: z.string().min(1).max(40) });

export const questsSchema = z.object({
  tutorial: z.array(questSchema),
  daily: z.array(questSchema),
  achievements: z.array(questSchema),
  login: z.object({
    day: z.number(),
    claimed: z.boolean(),
    rewards: z.array(rewardSchema),
  }),
  dailyResetAt: z.string(),
  claimable: z.number(),
});

export const rewardResultSchema = z.object({
  castle: castleSchema,
  reward: rewardSchema,
  inventory: inventorySchema,
});

export const questParams = z.object({ id: z.string().min(1).max(40) });

const oddsRow = z.object(
  Object.fromEntries(OUTCOME_ORDER.map((o) => [o, z.number()])) as Record<
    (typeof OUTCOME_ORDER)[number],
    z.ZodNumber
  >,
);
export const chestOddsSchema = z.array(
  z.object({
    kind: chestKind,
    odds: oddsRow,
    resourcePack: z.number(),
    gems: z.tuple([z.number(), z.number()]),
  }),
);

const chestReward = z.discriminatedUnion('type', [
  z.object({ type: z.literal('resources'), resources: resourceMap }),
  z.object({ type: z.literal('booster'), booster: boosterKey }),
  z.object({ type: z.literal('gems'), gems: z.number() }),
  z.object({
    type: z.literal('gear'),
    slot: z.enum(EQUIP_SLOTS),
    rarity: z.number().int().min(1).max(5),
  }),
]);
export const chestOpenSchema = z.object({
  castle: castleSchema,
  reward: chestReward,
  inventory: inventorySchema,
});
export const kindParams = z.object({ kind: chestKind });

export const useBoosterBody = z
  .object({
    booster: boosterKey,
    target: z.enum(['build', 'train', 'research']),
    taskId: z.string().uuid(),
  })
  .strict();
export const boosterUseSchema = z.object({ castle: castleSchema, inventory: inventorySchema });

const shopItem = z.object({
  id: z.string(),
  kind: z.enum(['pack', 'booster', 'slot', 'crest']),
  price: z.number(),
  resources: resourceMap.nullable(),
  booster: z.string().nullable(),
  crest: z.string().nullable(),
  owned: z.boolean(),
});
export const shopSchema = z.object({
  items: z.array(shopItem),
  gems: z.number(),
  inventory: inventorySchema,
});
export const shopBuySchema = z.object({ castle: castleSchema, shop: shopSchema });
export const buyBody = z.object({ itemId: z.string().min(1).max(40) }).strict();
export const checkoutBody = z.object({ packId: z.string().min(1).max(40) }).strict();

export const donateSchema = z.object({
  mode: z.enum(['off', 'test']),
  gems: z.number(),
  packs: z.array(
    z.object({
      id: z.string(),
      gems: z.number(),
      bonus: z.number(),
      usdCents: z.number(),
      tag: z.enum(['popular', 'best']).optional(),
      total: z.number(),
    }),
  ),
});
export const donateBuySchema = z.object({ castle: castleSchema, granted: z.number() });
export const donateBody = z.object({ packId: z.string().min(1).max(40) }).strict();

export const leagueQuery = z.object({
  scope: z.enum(LEAGUE_SCOPES).default('top100'),
  metric: z.enum(LEAGUE_METRICS).default('points'),
});
export const leagueSchema = z.object({
  seasonId: z.string(),
  endsAt: z.string(),
  metric: z.enum(LEAGUE_METRICS),
  scope: z.enum(LEAGUE_SCOPES),
  entries: z.array(
    z.object({
      place: z.number(),
      userId: z.string(),
      nickname: z.string(),
      value: z.number(),
      isMe: z.boolean(),
    }),
  ),
  me: z.object({ place: z.number().nullable(), value: z.number(), points: z.number() }).nullable(),
  pending: z.array(
    z.object({
      seasonId: z.string(),
      place: z.number().nullable(),
      gems: z.number(),
      chest: chestKind.nullable(),
    }),
  ),
  prize: z.object({ gems: z.number(), chest: chestKind.nullable() }),
});
