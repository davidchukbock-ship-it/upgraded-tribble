import {
  FREE_PACKS,
  MAIN_WORLD_ID,
  findFreePack,
  packClaimId,
  packNextAt,
  packPeriod,
  type FreePackDto,
  type FreePacksDto,
  type RewardResultDto,
} from '@tc/shared';
import type { Clock } from '../../lib/clock';
import { Errors } from '../../lib/errors';
import type { CastleResult, RealmRunner } from '../castle/castle.runner';
import type { CastleRepository } from '../castle/castle.types';
import { grantReward, mutateWithReward, rewardDto } from './progress.logic';

/** Бесплатные наборы по времени (D-76): награда фиксирована, получение фиксируется в журнале наград. */
export class FreePackService {
  private readonly worldId: string;

  constructor(
    private readonly deps: {
      runner: RealmRunner;
      repo: CastleRepository;
      clock: Clock;
      worldId?: string;
    },
  ) {
    this.worldId = deps.worldId ?? MAIN_WORLD_ID;
  }

  async list(userId: string): Promise<FreePacksDto> {
    const now = this.deps.clock.now();
    const periods = [...new Set(FREE_PACKS.map((p) => packPeriod(p, now)))];
    const claims = await this.deps.repo.transaction(async (tx) => {
      const agg = await tx.load(userId, this.worldId);
      if (!agg) throw Errors.notFound('Castle');
      return tx.progress.claims(userId, periods);
    });
    const done = new Set(claims.map((c) => `${c.questId}:${c.period}`));
    const packs: FreePackDto[] = FREE_PACKS.map((p) => {
      const claimed = done.has(`${packClaimId(p.id)}:${packPeriod(p, now)}`);
      return {
        id: p.id,
        everyHours: p.everyHours,
        reward: rewardDto(p.reward),
        claimed,
        nextAt: packNextAt(p, now)?.toISOString() ?? null,
      };
    });
    return {
      serverTime: now.toISOString(),
      packs,
      claimable: packs.filter((p) => !p.claimed).length,
    };
  }

  claim(userId: string, packId: string, idemKey: string): Promise<CastleResult<RewardResultDto>> {
    const def = findFreePack(packId);
    if (!def) throw Errors.notFound('Free pack');
    return mutateWithReward(
      this.deps.runner,
      userId,
      `free-pack:${packId}`,
      idemKey,
      async (draft, now, tx) => {
        // Окно считает сервер: клиент его не передаёт и не может выбрать чужое
        if (!(await tx.progress.addClaim(userId, packClaimId(def.id), packPeriod(def, now), now)))
          throw Errors.conflict('Free pack already claimed');
        return {
          reward: def.reward,
          events: await grantReward(draft, tx, def.reward, now, 'free_pack'),
        };
      },
    );
  }
}
