import { randomUUID } from 'node:crypto';
import {
  GUILD_CREATE_COST,
  GUILD_MIN_CASTLE,
  MAIN_WORLD_ID,
  MAX_HELPS_PER_TASK,
  MIN_DONATION,
  canHandleApplications,
  canManage,
  guildCapacity,
  guildHelpSeconds,
  guildLevel,
  guildNameKey,
  shortfall,
  subtractCost,
  type GuildDto,
  type GuildListDto,
  type GuildRole,
  type GuildSummaryDto,
  type HelpRequestDto,
  type MyGuildDto,
} from '@tc/shared';
import type { Clock } from '../../lib/clock';
import { Errors } from '../../lib/errors';
import { castleLevel, settleAggregate } from '../castle/castle.realm';
import {
  resourceEvents,
  negate,
  type CastleResult,
  type RealmRunner,
} from '../castle/castle.runner';
import { VersionConflict, type CastleRepository, type CastleTx } from '../castle/castle.types';
import type { NotificationService } from './notification.service';
import {
  AlreadyApplied,
  AlreadyHelped,
  AlreadyInGuild,
  GuildNameTaken,
  type GuildListItem,
  type GuildRecord,
  type NotificationRecord,
} from './social.types';

const MAX_APPLICATIONS = 5;
const MAX_ATTEMPTS = 5;

const summary = (g: GuildRecord, members: number, leaderName: string): GuildSummaryDto => {
  const level = guildLevel(g.treasury);
  return {
    id: g.id,
    name: g.name,
    description: g.description,
    level,
    members,
    capacity: guildCapacity(level),
    leaderName,
  };
};

/** Братства: создание, заявки, роли, казна и помощь с постройками (docs/GAME_DESIGN.md §10). */
export class GuildService {
  private readonly worldId: string;

  constructor(
    private readonly deps: {
      runner: RealmRunner;
      repo: CastleRepository;
      clock: Clock;
      notifications: NotificationService;
      worldId?: string;
    },
  ) {
    this.worldId = deps.worldId ?? MAIN_WORLD_ID;
  }

  // ── Чтение ────────────────────────────────────────────────────────────────

  async list(q: string, page: number, pageSize: number): Promise<GuildListDto> {
    const r = await this.deps.repo.transaction((tx) =>
      tx.guilds.list(this.worldId, q, page, pageSize),
    );
    return {
      items: r.items.map((g: GuildListItem) => summary(g, g.members, g.leaderName)),
      page,
      pageSize,
      total: r.total,
    };
  }

  /** Моё братство (или мои заявки, если братства нет). */
  async mine(userId: string): Promise<MyGuildDto> {
    const now = this.deps.clock.now();
    return this.deps.repo.transaction(async (tx) => {
      const found = await tx.guilds.findByUser(userId, this.worldId);
      if (!found) {
        const apps = await tx.guilds.userApplications(userId);
        return {
          guild: null,
          applications: apps.map((a) => ({ guildId: a.guildId, guildName: a.guildName })),
        };
      }
      const members = await tx.guilds.members(found.guild.id);
      const leader = members.find((m) => m.role === 'leader');
      const applications = canHandleApplications(found.role)
        ? (await tx.guilds.applications(found.guild.id)).map((a) => ({
            id: a.id,
            userId: a.userId,
            nickname: a.nickname,
            createdAt: a.createdAt.toISOString(),
          }))
        : [];
      const guild: GuildDto = {
        ...summary(found.guild, members.length, leader?.nickname ?? ''),
        treasury: found.guild.treasury,
        myRole: found.role,
        memberList: members.map((m) => ({
          userId: m.userId,
          nickname: m.nickname,
          role: m.role,
          joinedAt: m.joinedAt.toISOString(),
        })),
        applications,
        helpRequests: await this.helpRequests(tx, userId, members, now),
      };
      return { guild, applications: [] };
    });
  }

  /** Стройки соратников, которым можно помочь. Данные замков читаем «как есть» — с учётом расчёта на сейчас. */
  private async helpRequests(
    tx: CastleTx,
    me: string,
    members: ReadonlyArray<{ userId: string; nickname: string }>,
    now: Date,
  ): Promise<HelpRequestDto[]> {
    const out: HelpRequestDto[] = [];
    const tasks: Array<{
      owner: { userId: string; nickname: string };
      task: {
        id: string;
        key: HelpRequestDto['building'];
        toLevel: number;
        startedAt: Date;
        finishesAt: Date;
      };
    }> = [];
    for (const m of members) {
      if (m.userId === me) continue;
      const agg = await tx.load(m.userId, this.worldId);
      if (!agg) continue;
      for (const t of settleAggregate(agg, now).draft.tasks) tasks.push({ owner: m, task: t });
    }
    const helps = await tx.guilds.helps(tasks.map((t) => t.task.id));
    for (const { owner, task } of tasks) {
      const forTask = helps.filter((h) => h.taskId === task.id);
      const total = Math.round((task.finishesAt.getTime() - task.startedAt.getTime()) / 1000);
      out.push({
        userId: owner.userId,
        nickname: owner.nickname,
        taskId: task.id,
        building: task.key,
        toLevel: task.toLevel,
        finishesAt: task.finishesAt.toISOString(),
        helps: forTask.length,
        maxHelps: MAX_HELPS_PER_TASK,
        helpSeconds: guildHelpSeconds(total),
        canHelp: forTask.length < MAX_HELPS_PER_TASK && !forTask.some((h) => h.userId === me),
      });
    }
    return out.sort((a, b) => a.finishesAt.localeCompare(b.finishesAt));
  }

  // ── Создание, заявки ──────────────────────────────────────────────────────

  private async requireMember(tx: CastleTx, userId: string) {
    const found = await tx.guilds.findByUser(userId, this.worldId);
    if (!found) throw Errors.requirementNotMet({ reason: 'no_guild' });
    return found;
  }

  private async requireNotGuest(tx: CastleTx, userId: string) {
    const info = await tx.userInfo(userId);
    if (!info) throw Errors.unauthorized();
    if (info.isGuest) throw Errors.requirementNotMet({ reason: 'guest' });
    return info;
  }

  create(
    userId: string,
    name: string,
    description: string,
    idemKey: string,
  ): Promise<CastleResult> {
    return this.deps.runner.mutate(
      userId,
      `guild-create:${guildNameKey(name)}`,
      idemKey,
      (draft, now) => {
        if (castleLevel(draft) < GUILD_MIN_CASTLE)
          throw Errors.requirementNotMet({ reason: 'castle_level', required: GUILD_MIN_CASTLE });
        const cost = { gold: GUILD_CREATE_COST, wood: 0, stone: 0, food: 0 };
        const missing = shortfall(draft.resources, cost);
        if (Object.keys(missing).length > 0) throw Errors.insufficientResources({ missing });
        draft.resources = subtractCost(draft.resources, cost);
        return resourceEvents(draft, now, 'guild_create', negate(cost));
      },
      async (tx, draft, now) => {
        await this.requireNotGuest(tx, userId);
        try {
          await tx.guilds.create(
            {
              id: randomUUID(),
              worldId: this.worldId,
              name,
              nameKey: guildNameKey(name),
              description,
              treasury: 0,
              createdAt: now,
            },
            userId,
          );
        } catch (err) {
          if (err instanceof GuildNameTaken) throw Errors.conflict('Guild name is taken');
          if (err instanceof AlreadyInGuild)
            throw Errors.requirementNotMet({ reason: 'already_in_guild' });
          throw err;
        }
        await tx.guilds.removeUserApplications(draft.userId);
      },
    );
  }

  /** Подать заявку. Оповещает главу и офицеров. */
  async apply(userId: string, guildId: string): Promise<void> {
    const now = this.deps.clock.now();
    const notes = await this.deps.repo.transaction(async (tx) => {
      const me = await this.requireNotGuest(tx, userId);
      if (await tx.guilds.findByUser(userId, this.worldId))
        throw Errors.requirementNotMet({ reason: 'already_in_guild' });
      const guild = await tx.guilds.get(guildId);
      if (!guild) throw Errors.notFound('Guild');
      if ((await tx.guilds.userApplications(userId)).length >= MAX_APPLICATIONS)
        throw Errors.requirementNotMet({ reason: 'too_many_applications' });
      try {
        await tx.guilds.addApplication({ id: randomUUID(), guildId, userId, createdAt: now });
      } catch (err) {
        if (err instanceof AlreadyApplied) throw Errors.conflict('Already applied');
        throw err;
      }
      const staff = (await tx.guilds.members(guildId)).filter((m) => canHandleApplications(m.role));
      const rows: NotificationRecord[] = staff.map((m) => ({
        id: randomUUID(),
        userId: m.userId,
        kind: 'guild.application',
        payload: { nickname: me.nickname, userId, guild: guild.name },
        read: false,
        createdAt: now,
      }));
      await tx.notifications.add(rows);
      return rows;
    });
    this.deliver(notes);
  }

  async withdraw(userId: string, guildId: string): Promise<void> {
    await this.deps.repo.transaction(async (tx) => {
      const mine = (await tx.guilds.userApplications(userId)).find((a) => a.guildId === guildId);
      if (!mine) throw Errors.notFound('Application');
      await tx.guilds.removeApplication(mine.id);
    });
  }

  /** Принять или отклонить заявку: глава и офицеры. */
  async decide(userId: string, applicationId: string, accept: boolean): Promise<void> {
    const now = this.deps.clock.now();
    const notes = await this.deps.repo.transaction(async (tx) => {
      const mine = await this.requireMember(tx, userId);
      if (!canHandleApplications(mine.role)) throw Errors.forbidden();
      const app = await tx.guilds.getApplication(applicationId);
      if (!app || app.guildId !== mine.guild.id) throw Errors.notFound('Application');
      if (!accept) {
        await tx.guilds.removeApplication(app.id);
        return [];
      }
      const members = await tx.guilds.members(mine.guild.id);
      if (members.length >= guildCapacity(guildLevel(mine.guild.treasury)))
        throw Errors.requirementNotMet({ reason: 'guild_full' });
      try {
        await tx.guilds.addMember(mine.guild.id, app.userId, this.worldId, 'member', now);
      } catch (err) {
        if (err instanceof AlreadyInGuild) {
          await tx.guilds.removeApplication(app.id);
          throw Errors.requirementNotMet({ reason: 'applicant_in_guild' });
        }
        throw err;
      }
      await tx.guilds.removeUserApplications(app.userId);
      const row: NotificationRecord = {
        id: randomUUID(),
        userId: app.userId,
        kind: 'guild.accepted',
        payload: { guild: mine.guild.name },
        read: false,
        createdAt: now,
      };
      await tx.notifications.add([row]);
      return [row];
    });
    this.deliver(notes);
  }

  // ── Состав ───────────────────────────────────────────────────────────────

  /** Глава: сделать офицером/участником; role='leader' передаёт главенство (прежний глава становится офицером). */
  async setRole(userId: string, targetId: string, role: GuildRole): Promise<void> {
    await this.deps.repo.transaction(async (tx) => {
      const mine = await this.requireMember(tx, userId);
      if (mine.role !== 'leader') throw Errors.forbidden();
      if (targetId === userId) throw Errors.requirementNotMet({ reason: 'self' });
      const members = await tx.guilds.members(mine.guild.id);
      if (!members.some((m) => m.userId === targetId)) throw Errors.notFound('Member');
      if (role === 'leader') {
        await tx.guilds.setRole(mine.guild.id, targetId, 'leader');
        await tx.guilds.setRole(mine.guild.id, userId, 'officer');
      } else {
        await tx.guilds.setRole(mine.guild.id, targetId, role);
      }
    });
  }

  async kick(userId: string, targetId: string): Promise<void> {
    const now = this.deps.clock.now();
    const notes = await this.deps.repo.transaction(async (tx) => {
      const mine = await this.requireMember(tx, userId);
      const members = await tx.guilds.members(mine.guild.id);
      const target = members.find((m) => m.userId === targetId);
      if (!target) throw Errors.notFound('Member');
      if (!canManage(mine.role, target.role)) throw Errors.forbidden();
      await tx.guilds.removeMember(mine.guild.id, targetId);
      const row: NotificationRecord = {
        id: randomUUID(),
        userId: targetId,
        kind: 'guild.kicked',
        payload: { guild: mine.guild.name },
        read: false,
        createdAt: now,
      };
      await tx.notifications.add([row]);
      return [row];
    });
    this.deliver(notes);
  }

  /** Выйти. Глава уходит, только если он один (братство распускается), иначе сначала передаёт главенство. */
  async leave(userId: string): Promise<void> {
    await this.deps.repo.transaction(async (tx) => {
      const mine = await this.requireMember(tx, userId);
      if (mine.role === 'leader') {
        const members = await tx.guilds.members(mine.guild.id);
        if (members.length > 1) throw Errors.requirementNotMet({ reason: 'leader_must_transfer' });
        await tx.guilds.deleteGuild(mine.guild.id);
        return;
      }
      await tx.guilds.removeMember(mine.guild.id, userId);
    });
  }

  // ── Казна ────────────────────────────────────────────────────────────────

  donate(userId: string, amount: number, idemKey: string): Promise<CastleResult> {
    return this.deps.runner.mutate(
      userId,
      `guild-donate:${amount}`,
      idemKey,
      (draft, now) => {
        if (amount < MIN_DONATION) throw Errors.validation({ field: 'amount' });
        const cost = { gold: amount, wood: 0, stone: 0, food: 0 };
        const missing = shortfall(draft.resources, cost);
        if (Object.keys(missing).length > 0) throw Errors.insufficientResources({ missing });
        draft.resources = subtractCost(draft.resources, cost);
        return resourceEvents(draft, now, 'guild_donate', negate(cost));
      },
      async (tx) => {
        const mine = await this.requireMember(tx, userId);
        await tx.guilds.addTreasury(mine.guild.id, amount);
      },
    );
  }

  // ── Помощь с постройкой ───────────────────────────────────────────────────

  /** Помочь соратнику: его стройка заканчивается раньше на max(10 с, 1% длительности). Одна помощь от игрока на стройку. */
  async help(userId: string, ownerId: string, taskId: string): Promise<{ seconds: number }> {
    for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
      const now = this.deps.clock.now();
      try {
        const done = await this.deps.repo.transaction(async (tx) => {
          const mine = await this.requireMember(tx, userId);
          if (ownerId === userId) throw Errors.requirementNotMet({ reason: 'self' });
          const members = await tx.guilds.members(mine.guild.id);
          const owner = members.find((m) => m.userId === ownerId);
          if (!owner) throw Errors.notFound('Member');
          const agg = await tx.load(ownerId, this.worldId);
          if (!agg) throw Errors.notFound('Castle');
          const settled = settleAggregate(agg, now).draft;
          const task = settled.tasks.find((t) => t.id === taskId);
          if (!task) throw Errors.notFound('Build task');
          const already = (await tx.guilds.helps([taskId])).length;
          if (already >= MAX_HELPS_PER_TASK)
            throw Errors.requirementNotMet({ reason: 'help_limit' });
          const total = Math.round((task.finishesAt.getTime() - task.startedAt.getTime()) / 1000);
          const seconds = guildHelpSeconds(total);
          try {
            await tx.guilds.addHelp(taskId, userId, now);
          } catch (err) {
            if (err instanceof AlreadyHelped) throw Errors.conflict('Already helped');
            throw err;
          }
          task.finishesAt = new Date(
            Math.max(now.getTime(), task.finishesAt.getTime() - seconds * 1000),
          );
          await tx.save(agg, settled);
          const helper = members.find((m) => m.userId === userId);
          const row: NotificationRecord = {
            id: randomUUID(),
            userId: ownerId,
            kind: 'guild.help',
            payload: { helper: helper?.nickname ?? '', building: task.key, seconds },
            read: false,
            createdAt: now,
          };
          await tx.notifications.add([row]);
          return { seconds, row };
        });
        this.deliver([done.row]);
        return { seconds: done.seconds };
      } catch (err) {
        if (err instanceof VersionConflict) continue;
        throw err;
      }
    }
    throw Errors.conflict('Castle is busy, try again');
  }

  private deliver(rows: readonly NotificationRecord[]): void {
    for (const r of rows) this.deps.notifications.deliver(r.userId, [r]);
  }
}
