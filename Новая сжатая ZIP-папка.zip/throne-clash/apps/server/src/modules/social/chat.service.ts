import { randomUUID } from 'node:crypto';
import {
  CHAT_HISTORY_LIMIT,
  CHAT_RATE_MAX,
  CHAT_RATE_WINDOW_SECONDS,
  MAIN_WORLD_ID,
  cleanMessage,
  dayKey,
  filterProfanity,
  parseChannel,
  storedChannel,
  type ChatMessageDto,
} from '@tc/shared';
import type { Clock } from '../../lib/clock';
import { AppError, Errors } from '../../lib/errors';
import type { UserRepository } from '../auth/auth.types';
import type { CastleRepository } from '../castle/castle.types';
import type { Hub } from './hub';
import type { NotificationService } from './notification.service';
import { AlreadyReported, type ChatRecord } from './social.types';
import type { SecurityLogger } from '../abuse/abuse';
import { WindowLimiter } from './window-limiter';

/** Каналы `world`, `guild`, `dm:<userId>`: отправка, история, жалобы. */
export class ChatService {
  private readonly limiter = new WindowLimiter(CHAT_RATE_MAX, CHAT_RATE_WINDOW_SECONDS);
  private readonly worldId: string;

  constructor(
    private readonly deps: {
      repo: CastleRepository;
      users: UserRepository;
      clock: Clock;
      hub: Hub;
      notifications: NotificationService;
      logger?: SecurityLogger;
      worldId?: string;
    },
  ) {
    this.worldId = deps.worldId ?? MAIN_WORLD_ID;
  }

  /** Сообщение так, как его видит получатель viewerId: личный канал называется по собеседнику. */
  private toDto(rec: ChatRecord, viewerId: string): ChatMessageDto {
    let channel = 'world';
    if (rec.channel.startsWith('guild:')) channel = 'guild';
    else if (rec.channel.startsWith('dm:')) {
      const [, a, b] = rec.channel.split(':');
      channel = `dm:${a === viewerId ? b : a}`;
    }
    return {
      id: rec.id,
      channel,
      userId: rec.userId,
      nickname: rec.nickname,
      text: rec.text,
      createdAt: rec.createdAt.toISOString(),
    };
  }

  async send(userId: string, channelRaw: string, textRaw: string): Promise<ChatMessageDto> {
    const ref = parseChannel(channelRaw);
    if (!ref) throw Errors.validation({ field: 'channel' });
    const clean = cleanMessage(textRaw);
    if (clean === null) throw Errors.validation({ field: 'text' });

    const now = this.deps.clock.now();
    const user = await this.deps.users.findById(userId);
    if (!user) throw Errors.unauthorized();
    if (user.mutedUntil && user.mutedUntil > now) {
      throw new AppError('ERR_MUTED', 403, 'You are muted', {
        until: user.mutedUntil.toISOString(),
      });
    }
    const wait = this.limiter.hit(userId, now);
    if (wait > 0) {
      this.deps.logger?.log('chat_flood', { userId });
      throw Errors.locked(wait);
    }

    const { text } = filterProfanity(clean);
    const result = await this.deps.repo.transaction(async (tx) => {
      const membership = await tx.guilds.findByUser(userId, this.worldId);
      const channel = storedChannel(ref, userId, membership?.guild.id ?? null);
      if (!channel) throw Errors.requirementNotMet({ reason: 'no_guild' });
      let recipients: string[];
      if (ref.kind === 'world') recipients = [];
      else if (ref.kind === 'guild')
        recipients = (await tx.guilds.members(membership!.guild.id)).map((m) => m.userId);
      else {
        if (ref.userId === userId) throw Errors.requirementNotMet({ reason: 'self_dm' });
        const other = await tx.userInfo(ref.userId);
        if (!other) throw Errors.notFound('Player');
        recipients = [userId, ref.userId];
      }
      const rec: ChatRecord = {
        id: randomUUID(),
        worldId: this.worldId,
        channel,
        userId,
        nickname: user.nickname,
        text,
        createdAt: now,
      };
      const { nickname: _nickname, ...row } = rec;
      void _nickname;
      await tx.chat.add(row);
      await tx.progress.bump(userId, ['total', dayKey(now)], 'chat', 1);
      return { rec, recipients, dmTo: ref.kind === 'dm' ? ref.userId : null };
    });

    const msgFor = (viewer: string) => ({
      type: 'chat.message' as const,
      message: this.toDto(result.rec, viewer),
    });
    if (ref.kind === 'world') {
      // Мировой чат — всем онлайн; у каждого один и тот же вид сообщения
      this.deps.hub.toAll(msgFor(userId));
    } else {
      for (const id of new Set(result.recipients)) this.deps.hub.toUser(id, msgFor(id));
    }
    // Получатель личного сообщения не в игре — оставляем уведомление
    if (result.dmTo && !this.deps.hub.isOnline(result.dmTo)) {
      const note = {
        id: randomUUID(),
        userId: result.dmTo,
        kind: 'chat.dm' as const,
        payload: { fromId: userId, from: user.nickname, text: text.slice(0, 80) },
        read: false,
        createdAt: now,
      };
      await this.deps.repo.transaction((tx) => tx.notifications.add([note]));
    }
    return this.toDto(result.rec, userId);
  }

  /**
   * Системное объявление в мировой чат от имени владельца (режим бога): без лимита и без фильтра мата.
   * Текст помечается «[System]», чтобы его нельзя было спутать с обычной речью игрока.
   */
  async announce(userId: string, textRaw: string): Promise<ChatMessageDto> {
    const clean = cleanMessage(textRaw);
    if (clean === null) throw Errors.validation({ field: 'text' });
    const user = await this.deps.users.findById(userId);
    if (!user) throw Errors.unauthorized();
    const now = this.deps.clock.now();
    const rec: ChatRecord = {
      id: randomUUID(),
      worldId: this.worldId,
      channel: 'world',
      userId,
      nickname: user.nickname,
      text: `[System] ${clean}`,
      createdAt: now,
    };
    const { nickname: _nickname, ...row } = rec;
    void _nickname;
    await this.deps.repo.transaction((tx) => tx.chat.add(row));
    this.deps.hub.toAll({ type: 'chat.message', message: this.toDto(rec, userId) });
    return this.toDto(rec, userId);
  }

  async history(userId: string, channelRaw: string, before?: Date): Promise<ChatMessageDto[]> {
    const ref = parseChannel(channelRaw);
    if (!ref) throw Errors.validation({ field: 'channel' });
    return this.deps.repo.transaction(async (tx) => {
      const membership = await tx.guilds.findByUser(userId, this.worldId);
      const channel = storedChannel(ref, userId, membership?.guild.id ?? null);
      if (!channel) throw Errors.requirementNotMet({ reason: 'no_guild' });
      const rows = await tx.chat.history(channel, CHAT_HISTORY_LIMIT, before);
      return rows.map((r) => this.toDto(r, userId));
    });
  }

  /** Жалоба на сообщение. Пожаловаться можно только на то, что видел: мировой чат, свои братство и личные. */
  async report(userId: string, messageId: string, reason: string): Promise<void> {
    const now = this.deps.clock.now();
    await this.deps.repo.transaction(async (tx) => {
      const msg = await tx.chat.get(messageId);
      if (!msg) throw Errors.notFound('Message');
      if (msg.userId === userId) throw Errors.requirementNotMet({ reason: 'own_message' });
      const membership = await tx.guilds.findByUser(userId, this.worldId);
      const visible =
        msg.channel === 'world' ||
        (msg.channel.startsWith('guild:') && msg.channel === `guild:${membership?.guild.id}`) ||
        (msg.channel.startsWith('dm:') && msg.channel.split(':').slice(1).includes(userId));
      if (!visible) throw Errors.notFound('Message');
      try {
        await tx.chat.addReport({
          id: randomUUID(),
          messageId,
          reporterId: userId,
          reason,
          createdAt: now,
        });
      } catch (err) {
        if (err instanceof AlreadyReported) throw Errors.conflict('Already reported');
        throw err;
      }
    });
  }
}
