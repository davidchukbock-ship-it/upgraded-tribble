import type { GuildRole, NotificationKind } from '@tc/shared';

export interface GuildRecord {
  id: string;
  worldId: string;
  name: string;
  nameKey: string;
  description: string;
  /** Суммарный вклад золота. */
  treasury: number;
  createdAt: Date;
}

export interface GuildListItem extends GuildRecord {
  members: number;
  leaderName: string;
}

export interface MemberRecord {
  guildId: string;
  userId: string;
  nickname: string;
  role: GuildRole;
  joinedAt: Date;
}

export interface ApplicationRecord {
  id: string;
  guildId: string;
  userId: string;
  nickname: string;
  createdAt: Date;
}

/** Название братства уже занято. */
export class GuildNameTaken extends Error {}
/** Игрок уже состоит в братстве. */
export class AlreadyInGuild extends Error {}
export class AlreadyApplied extends Error {}
export class AlreadyHelped extends Error {}
export class AlreadyReported extends Error {}

export interface GuildStore {
  /** Создаёт братство и первого участника — главу. */
  create(guild: GuildRecord, leaderId: string): Promise<void>;
  get(id: string): Promise<GuildRecord | null>;
  /** Братство игрока и его роль. */
  findByUser(
    userId: string,
    worldId: string,
  ): Promise<{ guild: GuildRecord; role: GuildRole } | null>;
  list(
    worldId: string,
    query: string,
    page: number,
    pageSize: number,
  ): Promise<{ items: GuildListItem[]; total: number }>;
  members(guildId: string): Promise<MemberRecord[]>;
  addMember(
    guildId: string,
    userId: string,
    worldId: string,
    role: GuildRole,
    at: Date,
  ): Promise<void>;
  removeMember(guildId: string, userId: string): Promise<void>;
  setRole(guildId: string, userId: string, role: GuildRole): Promise<void>;
  applications(guildId: string): Promise<ApplicationRecord[]>;
  userApplications(
    userId: string,
  ): Promise<Array<{ id: string; guildId: string; guildName: string }>>;
  getApplication(id: string): Promise<ApplicationRecord | null>;
  addApplication(rec: {
    id: string;
    guildId: string;
    userId: string;
    createdAt: Date;
  }): Promise<void>;
  removeApplication(id: string): Promise<void>;
  removeUserApplications(userId: string): Promise<void>;
  addTreasury(guildId: string, amount: number): Promise<void>;
  deleteGuild(guildId: string): Promise<void>;
  helps(taskIds: readonly string[]): Promise<Array<{ taskId: string; userId: string }>>;
  addHelp(taskId: string, userId: string, at: Date): Promise<void>;
  deleteHelpsBefore(before: Date): Promise<number>;
}

export interface ChatRecord {
  id: string;
  worldId: string;
  /** Хранимое имя: world | guild:<id> | dm:<idA>:<idB>. */
  channel: string;
  userId: string;
  nickname: string;
  text: string;
  createdAt: Date;
}

export interface ChatStore {
  add(msg: Omit<ChatRecord, 'nickname'>): Promise<void>;
  /** Последние `limit` сообщений канала, старые первыми; before — только более ранние. */
  history(channel: string, limit: number, before?: Date): Promise<ChatRecord[]>;
  get(id: string): Promise<ChatRecord | null>;
  addReport(rec: {
    id: string;
    messageId: string;
    reporterId: string;
    reason: string;
    createdAt: Date;
  }): Promise<void>;
  deleteBefore(before: Date): Promise<number>;
}

export interface NotificationRecord {
  id: string;
  userId: string;
  kind: NotificationKind;
  payload: Record<string, string | number | boolean | null>;
  read: boolean;
  createdAt: Date;
}

export interface NotificationStore {
  add(rows: readonly NotificationRecord[]): Promise<void>;
  list(
    userId: string,
    page: number,
    pageSize: number,
  ): Promise<{ items: NotificationRecord[]; total: number; unread: number }>;
  /** Помечает прочитанными указанные (или все) уведомления; возвращает, сколько изменено. */
  markRead(userId: string, ids?: readonly string[]): Promise<number>;
  deleteBefore(before: Date): Promise<number>;
}

export interface UserInfo {
  id: string;
  nickname: string;
  isGuest: boolean;
}

/** Хранилища «социальной» части; доступны из той же транзакции, что и замок (D-41). */
export interface SocialTx {
  guilds: GuildStore;
  chat: ChatStore;
  notifications: NotificationStore;
  userInfo(userId: string): Promise<UserInfo | null>;
}
