import { Prisma } from '@prisma/client';
import { guildNameKey, type GuildRole } from '@tc/shared';
import { NOTIFICATION_KINDS, type NotificationKind } from '@tc/shared';
import {
  AlreadyApplied,
  AlreadyHelped,
  AlreadyInGuild,
  AlreadyReported,
  GuildNameTaken,
  type ChatStore,
  type GuildRecord,
  type GuildStore,
  type NotificationRecord,
  type NotificationStore,
  type SocialTx,
  type UserInfo,
} from './social.types';

type Client = Prisma.TransactionClient;

const isUnique = (err: unknown): err is Prisma.PrismaClientKnownRequestError =>
  err instanceof Prisma.PrismaClientKnownRequestError && err.code === 'P2002';

const toGuild = (g: {
  id: string;
  worldId: string;
  name: string;
  nameKey: string;
  description: string;
  treasury: number;
  createdAt: Date;
}): GuildRecord => ({ ...g });

/** Реализация хранилищ на Prisma; работает внутри транзакции замка. */
export class PrismaSocial implements SocialTx {
  constructor(private readonly db: Client) {}

  async userInfo(userId: string): Promise<UserInfo | null> {
    const u = await this.db.user.findUnique({
      where: { id: userId },
      select: { id: true, nickname: true, isGuest: true },
    });
    return u;
  }

  readonly guilds: GuildStore = {
    create: async (guild, leaderId) => {
      try {
        await this.db.guild.create({ data: { ...guild } });
      } catch (err) {
        if (isUnique(err)) throw new GuildNameTaken();
        throw err;
      }
      await this.guilds.addMember(guild.id, leaderId, guild.worldId, 'leader', guild.createdAt);
    },
    get: async (id) => {
      const g = await this.db.guild.findUnique({ where: { id } });
      return g ? toGuild(g) : null;
    },
    findByUser: async (userId, worldId) => {
      const m = await this.db.guildMember.findUnique({
        where: { worldId_userId: { worldId, userId } },
        include: { guild: true },
      });
      return m ? { guild: toGuild(m.guild), role: m.role as GuildRole } : null;
    },
    list: async (worldId, query, page, pageSize) => {
      const where: Prisma.GuildWhereInput = {
        worldId,
        // По ключу, а не ILIKE: поиск не зависит от локали БД (в локали C регистр кириллицы не различается)
        ...(query.trim() ? { nameKey: { contains: guildNameKey(query) } } : {}),
      };
      const [rows, total] = await Promise.all([
        this.db.guild.findMany({
          where,
          orderBy: { name: 'asc' },
          skip: (page - 1) * pageSize,
          take: pageSize,
          include: {
            _count: { select: { members: true } },
            members: {
              where: { role: 'leader' },
              include: { user: { select: { nickname: true } } },
            },
          },
        }),
        this.db.guild.count({ where }),
      ]);
      return {
        items: rows.map((g) => ({
          ...toGuild(g),
          members: g._count.members,
          leaderName: g.members[0]?.user.nickname ?? '',
        })),
        total,
      };
    },
    members: async (guildId) => {
      const rows = await this.db.guildMember.findMany({
        where: { guildId },
        include: { user: { select: { nickname: true } } },
        orderBy: { joinedAt: 'asc' },
      });
      return rows.map((m) => ({
        guildId: m.guildId,
        userId: m.userId,
        nickname: m.user.nickname,
        role: m.role as GuildRole,
        joinedAt: m.joinedAt,
      }));
    },
    addMember: async (guildId, userId, worldId, role, at) => {
      try {
        await this.db.guildMember.create({
          data: { guildId, userId, worldId, role, joinedAt: at },
        });
      } catch (err) {
        if (isUnique(err)) throw new AlreadyInGuild();
        throw err;
      }
    },
    removeMember: async (guildId, userId) => {
      await this.db.guildMember.deleteMany({ where: { guildId, userId } });
    },
    setRole: async (guildId, userId, role) => {
      await this.db.guildMember.updateMany({ where: { guildId, userId }, data: { role } });
    },
    applications: async (guildId) => {
      const rows = await this.db.guildApplication.findMany({
        where: { guildId },
        include: { user: { select: { nickname: true } } },
        orderBy: { createdAt: 'asc' },
      });
      return rows.map((a) => ({
        id: a.id,
        guildId: a.guildId,
        userId: a.userId,
        nickname: a.user.nickname,
        createdAt: a.createdAt,
      }));
    },
    userApplications: async (userId) => {
      const rows = await this.db.guildApplication.findMany({
        where: { userId },
        include: { guild: { select: { name: true } } },
      });
      return rows.map((a) => ({ id: a.id, guildId: a.guildId, guildName: a.guild.name }));
    },
    getApplication: async (id) => {
      const a = await this.db.guildApplication.findUnique({
        where: { id },
        include: { user: { select: { nickname: true } } },
      });
      return a
        ? {
            id: a.id,
            guildId: a.guildId,
            userId: a.userId,
            nickname: a.user.nickname,
            createdAt: a.createdAt,
          }
        : null;
    },
    addApplication: async (rec) => {
      try {
        await this.db.guildApplication.create({ data: rec });
      } catch (err) {
        if (isUnique(err)) throw new AlreadyApplied();
        throw err;
      }
    },
    removeApplication: async (id) => {
      await this.db.guildApplication.deleteMany({ where: { id } });
    },
    removeUserApplications: async (userId) => {
      await this.db.guildApplication.deleteMany({ where: { userId } });
    },
    addTreasury: async (guildId, amount) => {
      await this.db.guild.update({
        where: { id: guildId },
        data: { treasury: { increment: amount } },
      });
    },
    deleteGuild: async (guildId) => {
      await this.db.guild.deleteMany({ where: { id: guildId } });
    },
    helps: async (taskIds) => {
      if (taskIds.length === 0) return [];
      const rows = await this.db.guildHelp.findMany({ where: { taskId: { in: [...taskIds] } } });
      return rows.map((h) => ({ taskId: h.taskId, userId: h.userId }));
    },
    addHelp: async (taskId, userId, at) => {
      try {
        await this.db.guildHelp.create({ data: { taskId, userId, createdAt: at } });
      } catch (err) {
        if (isUnique(err)) throw new AlreadyHelped();
        throw err;
      }
    },
    deleteHelpsBefore: async (before) =>
      (await this.db.guildHelp.deleteMany({ where: { createdAt: { lt: before } } })).count,
  };

  readonly chat: ChatStore = {
    add: async (msg) => {
      await this.db.chatMessage.create({ data: msg });
    },
    history: async (channel, limit, before) => {
      const rows = await this.db.chatMessage.findMany({
        where: { channel, ...(before ? { createdAt: { lt: before } } : {}) },
        orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
        take: limit,
        include: { user: { select: { nickname: true } } },
      });
      return rows.reverse().map((m) => ({
        id: m.id,
        worldId: m.worldId,
        channel: m.channel,
        userId: m.userId,
        nickname: m.user.nickname,
        text: m.text,
        createdAt: m.createdAt,
      }));
    },
    get: async (id) => {
      const m = await this.db.chatMessage.findUnique({
        where: { id },
        include: { user: { select: { nickname: true } } },
      });
      return m
        ? {
            id: m.id,
            worldId: m.worldId,
            channel: m.channel,
            userId: m.userId,
            nickname: m.user.nickname,
            text: m.text,
            createdAt: m.createdAt,
          }
        : null;
    },
    addReport: async (rec) => {
      try {
        await this.db.chatReport.create({ data: rec });
      } catch (err) {
        if (isUnique(err)) throw new AlreadyReported();
        throw err;
      }
    },
    deleteBefore: async (before) =>
      (await this.db.chatMessage.deleteMany({ where: { createdAt: { lt: before } } })).count,
  };

  private static toNote(n: {
    id: string;
    userId: string;
    kind: string;
    payload: Prisma.JsonValue;
    read: boolean;
    createdAt: Date;
  }): NotificationRecord {
    return {
      id: n.id,
      userId: n.userId,
      kind: ((NOTIFICATION_KINDS as readonly string[]).includes(n.kind)
        ? n.kind
        : 'guild.help') as NotificationKind,
      payload: n.payload as NotificationRecord['payload'],
      read: n.read,
      createdAt: n.createdAt,
    };
  }

  readonly notifications: NotificationStore = {
    add: async (rows) => {
      if (rows.length === 0) return;
      await this.db.notification.createMany({
        data: rows.map((r) => ({ ...r, payload: r.payload as Prisma.InputJsonValue })),
      });
    },
    list: async (userId, page, pageSize) => {
      const [rows, total, unread] = await Promise.all([
        this.db.notification.findMany({
          where: { userId },
          orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
          skip: (page - 1) * pageSize,
          take: pageSize,
        }),
        this.db.notification.count({ where: { userId } }),
        this.db.notification.count({ where: { userId, read: false } }),
      ]);
      return { items: rows.map(PrismaSocial.toNote), total, unread };
    },
    markRead: async (userId, ids) =>
      (
        await this.db.notification.updateMany({
          where: { userId, read: false, ...(ids ? { id: { in: [...ids] } } : {}) },
          data: { read: true },
        })
      ).count,
    deleteBefore: async (before) =>
      (await this.db.notification.deleteMany({ where: { createdAt: { lt: before } } })).count,
  };
}
