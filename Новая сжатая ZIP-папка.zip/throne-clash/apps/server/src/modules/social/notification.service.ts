import type { NotificationDto, NotificationPageDto } from '@tc/shared';
import type { CastleRepository } from '../castle/castle.types';
import type { Hub } from './hub';
import type { NotificationRecord } from './social.types';

export const toNotificationDto = (n: NotificationRecord): NotificationDto => ({
  id: n.id,
  kind: n.kind,
  payload: n.payload,
  read: n.read,
  createdAt: n.createdAt.toISOString(),
});

/** Уведомления: хранение в БД и доставка онлайн-игрокам по WebSocket. */
export class NotificationService {
  constructor(private readonly deps: { repo: CastleRepository; hub: Hub }) {}

  /** Доставка уже сохранённых уведомлений тем, кто сейчас онлайн. Вызывать после фиксации транзакции. */
  deliver(userId: string, notes: readonly NotificationRecord[]): void {
    for (const n of notes)
      this.deps.hub.toUser(userId, { type: 'notification', notification: toNotificationDto(n) });
  }

  async list(userId: string, page: number, pageSize: number): Promise<NotificationPageDto> {
    const r = await this.deps.repo.transaction((tx) =>
      tx.notifications.list(userId, page, pageSize),
    );
    return {
      items: r.items.map(toNotificationDto),
      page,
      pageSize,
      total: r.total,
      unread: r.unread,
    };
  }

  /** Без ids — все непрочитанные. Возвращает, сколько отмечено. */
  markRead(userId: string, ids?: readonly string[]): Promise<number> {
    return this.deps.repo.transaction((tx) => tx.notifications.markRead(userId, ids));
  }
}
