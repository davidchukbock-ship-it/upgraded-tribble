import { z } from 'zod';
import {
  CHAT_REPORT_REASON_MAX,
  GUILD_ROLES,
  NOTIFICATION_KINDS,
  guildDescriptionSchema,
  guildNameSchema,
} from '@tc/shared';

const iso = z.string();

export const guildSummary = z.object({
  id: z.string(),
  name: z.string(),
  description: z.string(),
  level: z.number(),
  members: z.number(),
  capacity: z.number(),
  leaderName: z.string(),
});

export const guildListSchema = z.object({
  items: z.array(guildSummary),
  page: z.number(),
  pageSize: z.number(),
  total: z.number(),
});

export const guildFull = guildSummary.extend({
  treasury: z.number(),
  myRole: z.enum(GUILD_ROLES),
  memberList: z.array(
    z.object({
      userId: z.string(),
      nickname: z.string(),
      role: z.enum(GUILD_ROLES),
      joinedAt: iso,
    }),
  ),
  applications: z.array(
    z.object({ id: z.string(), userId: z.string(), nickname: z.string(), createdAt: iso }),
  ),
  helpRequests: z.array(
    z.object({
      userId: z.string(),
      nickname: z.string(),
      taskId: z.string(),
      building: z.string(),
      toLevel: z.number(),
      finishesAt: iso,
      helps: z.number(),
      maxHelps: z.number(),
      helpSeconds: z.number(),
      canHelp: z.boolean(),
    }),
  ),
});

export const myGuildSchema = z.object({
  guild: guildFull.nullable(),
  applications: z.array(z.object({ guildId: z.string(), guildName: z.string() })),
});

export const listQuery = z.object({
  q: z.string().trim().max(40).default(''),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(50).default(20),
});

export const createGuildBody = z
  .object({ name: guildNameSchema, description: guildDescriptionSchema.default('') })
  .strict();

export const idParams = z.object({ id: z.string().uuid() });
export const userParams = z.object({ userId: z.string().uuid() });
export const helpParams = z.object({ ownerId: z.string().uuid(), taskId: z.string().uuid() });
export const roleBody = z.object({ role: z.enum(GUILD_ROLES) }).strict();
export const donateBody = z.object({ amount: z.number().int().min(1).max(10_000_000) }).strict();

export const chatMessageSchema = z.object({
  id: z.string(),
  channel: z.string(),
  userId: z.string(),
  nickname: z.string(),
  text: z.string(),
  createdAt: iso,
});

export const channelParams = z.object({ channel: z.string().min(1).max(80) });
export const historyQuery = z.object({ before: z.string().datetime().optional() });
export const sendBody = z.object({ text: z.string().max(2000) }).strict();
export const reportBody = z
  .object({
    messageId: z.string().uuid(),
    reason: z.string().trim().min(1).max(CHAT_REPORT_REASON_MAX),
  })
  .strict();

export const notificationSchema = z.object({
  id: z.string(),
  kind: z.enum(NOTIFICATION_KINDS),
  payload: z.record(z.string(), z.union([z.string(), z.number(), z.boolean(), z.null()])),
  read: z.boolean(),
  createdAt: iso,
});
export const notificationPageSchema = z.object({
  items: z.array(notificationSchema),
  page: z.number(),
  pageSize: z.number(),
  total: z.number(),
  unread: z.number(),
});
export const notificationQuery = z.object({
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(50).default(20),
});
export const readBody = z.object({ ids: z.array(z.string().uuid()).max(100).optional() }).strict();
