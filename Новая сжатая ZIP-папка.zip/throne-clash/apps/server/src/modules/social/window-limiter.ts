/**
 * Скользящее окно: не больше `max` событий за `windowSeconds` на ключ. Хранится в памяти процесса
 * (лимит чата на один экземпляр сервера; для нескольких экземпляров нужен Redis — см. D-42).
 */
export class WindowLimiter {
  private readonly hits = new Map<string, number[]>();

  constructor(
    private readonly max: number,
    private readonly windowSeconds: number,
  ) {}

  /** 0 — событие принято; иначе сколько секунд ждать. */
  hit(key: string, now: Date): number {
    const t = now.getTime();
    const from = t - this.windowSeconds * 1000;
    const list = (this.hits.get(key) ?? []).filter((x) => x > from);
    if (list.length >= this.max) {
      this.hits.set(key, list);
      return Math.max(1, Math.ceil((list[0]! + this.windowSeconds * 1000 - t) / 1000));
    }
    list.push(t);
    this.hits.set(key, list);
    if (this.hits.size > 10_000) this.sweep(from);
    return 0;
  }

  private sweep(from: number): void {
    for (const [k, v] of this.hits) if (v.every((x) => x <= from)) this.hits.delete(k);
  }
}
