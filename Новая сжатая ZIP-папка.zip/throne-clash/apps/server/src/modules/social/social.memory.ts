import { guildNameKey, type GuildRole } from '@tc/shared';
import {
  AlreadyApplied,
  AlreadyHelped,
  AlreadyInGuild,
  AlreadyReported,
  GuildNameTaken,
  type ApplicationRecord,
  type ChatRecord,
  type ChatStore,
  type GuildListItem,
  type GuildRecord,
  type GuildStore,
  type MemberRecord,
  type NotificationRecord,
  type NotificationStore,
  type SocialTx,
  type UserInfo,
} from './social.types';

const clone = <T>(v: T): T => structuredClone(v);

interface Snapshot {
  guilds: Array<[string, GuildRecord]>;
  members: Array<MemberRecord & { worldId: string }>;
  applications: Array<Omit<ApplicationRecord, 'nickname'>>;
  helps: Array<{ taskId: string; userId: string; at: Date }>;
  messages: Array<Omit<ChatRecord, 'nickname'>>;
  reports: Array<{ id: string; messageId: string; reporterId: string; reason: string }>;
  notes: NotificationRecord[];
}

/**
 * In-memory братства, чат и уведомления для юнит-тестов. В отличие от PostgreSQL изменения применяются сразу,
 * без отката вместе с транзакцией: сервисы поэтому проверяют всё до записи (D-41).
 */
export class MemorySocial implements SocialTx {
  private readonly guildMap = new Map<string, GuildRecord>();
  private readonly memberList: Array<MemberRecord & { worldId: string }> = [];
  private readonly applicationList: Array<Omit<ApplicationRecord, 'nickname'>> = [];
  private readonly helpList: Array<{ taskId: string; userId: string; at: Date }> = [];
  readonly messages: Array<Omit<ChatRecord, 'nickname'>> = [];
  readonly reports: Array<{ id: string; messageId: string; reporterId: string; reason: string }> =
    [];
  readonly notes: NotificationRecord[] = [];

  constructor(private readonly lookup: (userId: string) => UserInfo | null) {}

  /** Счётчик изменений: транзакция откатывает своё, только если что-то меняла. */
  writes = 0;

  snapshot(): unknown {
    return structuredClone({
      guilds: [...this.guildMap.entries()],
      members: this.memberList,
      applications: this.applicationList,
      helps: this.helpList,
      messages: this.messages,
      reports: this.reports,
      notes: this.notes,
    });
  }

  restore(snap: unknown): void {
    const s = snap as Snapshot;
    this.guildMap.clear();
    for (const [k, v] of s.guilds) this.guildMap.set(k, v);
    const put = <T>(target: T[], src: T[]) => {
      target.length = 0;
      target.push(...src);
    };
    put(this.memberList, s.members);
    put(this.applicationList, s.applications);
    put(this.helpList, s.helps);
    put(this.messages, s.messages);
    put(this.reports, s.reports);
    put(this.notes, s.notes);
  }

  guildCount(worldId: string): number {
    return [...this.guildMap.values()].filter((g) => g.worldId === worldId).length;
  }

  /** Братство игрока (для таблиц лиг). */
  memberGuild(userId: string, worldId: string): string | null {
    return (
      this.memberList.find((m) => m.userId === userId && m.worldId === worldId)?.guildId ?? null
    );
  }

  private nick = (userId: string): string => this.lookup(userId)?.nickname ?? userId;

  async userInfo(userId: string): Promise<UserInfo | null> {
    return this.lookup(userId);
  }

  readonly guilds: GuildStore = {
    create: async (guild, leaderId) => {
      const all = [...this.guildMap.values()];
      if (all.some((g) => g.worldId === guild.worldId && g.nameKey === guild.nameKey))
        throw new GuildNameTaken();
      if (this.memberList.some((m) => m.userId === leaderId && m.worldId === guild.worldId))
        throw new AlreadyInGuild();
      this.guildMap.set(guild.id, clone(guild));
      this.memberList.push({
        guildId: guild.id,
        userId: leaderId,
        worldId: guild.worldId,
        nickname: '',
        role: 'leader',
        joinedAt: guild.createdAt,
      });
    },
    get: async (id) => clone(this.guildMap.get(id) ?? null),
    findByUser: async (userId, worldId) => {
      const m = this.memberList.find((x) => x.userId === userId && x.worldId === worldId);
      const g = m && this.guildMap.get(m.guildId);
      return m && g ? { guild: clone(g), role: m.role } : null;
    },
    list: async (worldId, query, page, pageSize) => {
      const q = query.trim() ? guildNameKey(query) : '';
      const items: GuildListItem[] = [...this.guildMap.values()]
        .filter((g) => g.worldId === worldId && (!q || g.nameKey.includes(q)))
        .sort((a, b) => a.name.localeCompare(b.name))
        .map((g) => ({
          ...clone(g),
          members: this.memberList.filter((m) => m.guildId === g.id).length,
          leaderName: this.nick(
            this.memberList.find((m) => m.guildId === g.id && m.role === 'leader')?.userId ?? '',
          ),
        }));
      return { items: items.slice((page - 1) * pageSize, page * pageSize), total: items.length };
    },
    members: async (guildId) =>
      this.memberList
        .filter((m) => m.guildId === guildId)
        .map((m) => ({
          guildId: m.guildId,
          userId: m.userId,
          role: m.role,
          joinedAt: m.joinedAt,
          nickname: this.nick(m.userId),
        }))
        .sort((a, b) => a.joinedAt.getTime() - b.joinedAt.getTime()),
    addMember: async (guildId, userId, worldId, role, at) => {
      if (this.memberList.some((m) => m.userId === userId && m.worldId === worldId))
        throw new AlreadyInGuild();
      this.memberList.push({ guildId, userId, worldId, nickname: '', role, joinedAt: at });
    },
    removeMember: async (guildId, userId) => {
      const i = this.memberList.findIndex((m) => m.guildId === guildId && m.userId === userId);
      if (i >= 0) this.memberList.splice(i, 1);
    },
    setRole: async (guildId, userId, role: GuildRole) => {
      const m = this.memberList.find((x) => x.guildId === guildId && x.userId === userId);
      if (m) m.role = role;
    },
    applications: async (guildId) =>
      this.applicationList
        .filter((a) => a.guildId === guildId)
        .map((a) => ({ ...clone(a), nickname: this.nick(a.userId) })),
    userApplications: async (userId) =>
      this.applicationList
        .filter((a) => a.userId === userId)
        .map((a) => ({
          id: a.id,
          guildId: a.guildId,
          guildName: this.guildMap.get(a.guildId)?.name ?? '',
        })),
    getApplication: async (id) => {
      const a = this.applicationList.find((x) => x.id === id);
      return a ? { ...clone(a), nickname: this.nick(a.userId) } : null;
    },
    addApplication: async (rec) => {
      if (this.applicationList.some((a) => a.guildId === rec.guildId && a.userId === rec.userId))
        throw new AlreadyApplied();
      this.applicationList.push(clone(rec));
    },
    removeApplication: async (id) => {
      const i = this.applicationList.findIndex((a) => a.id === id);
      if (i >= 0) this.applicationList.splice(i, 1);
    },
    removeUserApplications: async (userId) => {
      for (let i = this.applicationList.length - 1; i >= 0; i--)
        if (this.applicationList[i]!.userId === userId) this.applicationList.splice(i, 1);
    },
    addTreasury: async (guildId, amount) => {
      const g = this.guildMap.get(guildId);
      if (g) g.treasury += amount;
    },
    deleteGuild: async (guildId) => {
      this.guildMap.delete(guildId);
      for (let i = this.memberList.length - 1; i >= 0; i--)
        if (this.memberList[i]!.guildId === guildId) this.memberList.splice(i, 1);
      for (let i = this.applicationList.length - 1; i >= 0; i--)
        if (this.applicationList[i]!.guildId === guildId) this.applicationList.splice(i, 1);
    },
    helps: async (taskIds) =>
      this.helpList
        .filter((h) => taskIds.includes(h.taskId))
        .map((h) => ({ taskId: h.taskId, userId: h.userId })),
    addHelp: async (taskId, userId, at) => {
      if (this.helpList.some((h) => h.taskId === taskId && h.userId === userId))
        throw new AlreadyHelped();
      this.helpList.push({ taskId, userId, at });
    },
    deleteHelpsBefore: async (before) => {
      const keep = this.helpList.filter((h) => h.at >= before);
      const n = this.helpList.length - keep.length;
      this.helpList.length = 0;
      this.helpList.push(...keep);
      return n;
    },
  };

  readonly chat: ChatStore = {
    add: async (msg) => void this.messages.push(clone(msg)),
    history: async (channel, limit, before) => {
      const rows = this.messages
        .filter((m) => m.channel === channel && (!before || m.createdAt < before))
        .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime() || (a.id < b.id ? -1 : 1));
      return rows.slice(-limit).map((m) => ({ ...clone(m), nickname: this.nick(m.userId) }));
    },
    get: async (id) => {
      const m = this.messages.find((x) => x.id === id);
      return m ? { ...clone(m), nickname: this.nick(m.userId) } : null;
    },
    addReport: async (rec) => {
      if (
        this.reports.some((r) => r.messageId === rec.messageId && r.reporterId === rec.reporterId)
      )
        throw new AlreadyReported();
      this.reports.push({
        id: rec.id,
        messageId: rec.messageId,
        reporterId: rec.reporterId,
        reason: rec.reason,
      });
    },
    deleteBefore: async (before) => {
      const keep = this.messages.filter((m) => m.createdAt >= before);
      const n = this.messages.length - keep.length;
      this.messages.length = 0;
      this.messages.push(...keep);
      return n;
    },
  };

  readonly notifications: NotificationStore = {
    add: async (rows) => void this.notes.push(...clone([...rows])),
    list: async (userId, page, pageSize) => {
      const mine = this.notes
        .filter((n) => n.userId === userId)
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime() || (a.id < b.id ? 1 : -1));
      return {
        items: clone(mine.slice((page - 1) * pageSize, page * pageSize)),
        total: mine.length,
        unread: mine.filter((n) => !n.read).length,
      };
    },
    markRead: async (userId, ids) => {
      let n = 0;
      for (const x of this.notes) {
        if (x.userId === userId && !x.read && (!ids || ids.includes(x.id))) {
          x.read = true;
          n++;
        }
      }
      return n;
    },
    deleteBefore: async (before) => {
      const keep = this.notes.filter((n) => n.createdAt >= before);
      const n = this.notes.length - keep.length;
      this.notes.length = 0;
      this.notes.push(...keep);
      return n;
    },
  };
}
