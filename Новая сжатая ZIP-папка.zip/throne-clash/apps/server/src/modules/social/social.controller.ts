import type { FastifyInstance } from 'fastify';
import type { ZodTypeProvider } from 'fastify-type-provider-zod';
import { z } from 'zod';
import { sendResult } from '../castle/castle.controller';
import { castleSchema, errorSchema, failures, idempotencyHeaders } from '../castle/castle.schema';
import type { ChatService } from './chat.service';
import type { GuildService } from './guild.service';
import type { NotificationService } from './notification.service';
import {
  channelParams,
  chatMessageSchema,
  createGuildBody,
  donateBody,
  guildListSchema,
  helpParams,
  historyQuery,
  idParams,
  listQuery,
  myGuildSchema,
  notificationPageSchema,
  notificationQuery,
  readBody,
  reportBody,
  roleBody,
  sendBody,
  userParams,
} from './social.schema';

export function registerSocialRoutes(
  app: FastifyInstance,
  deps: { guilds: GuildService; chat: ChatService; notifications: NotificationService },
): void {
  const r = app.withTypeProvider<ZodTypeProvider>();
  const security = [{ bearerAuth: [] }];
  const auth = { preHandler: app.authenticate };
  const read = { 401: errorSchema, 404: errorSchema };
  const gTags = ['guild'];

  // ── Братства ──
  r.get(
    '/guilds',
    {
      ...auth,
      schema: {
        tags: gTags,
        summary: 'Список и поиск братств',
        security,
        querystring: listQuery,
        response: { 200: guildListSchema, ...read },
      },
    },
    async (req) => deps.guilds.list(req.query.q, req.query.page, req.query.pageSize),
  );

  r.get(
    '/guilds/mine',
    {
      ...auth,
      schema: {
        tags: gTags,
        summary: 'Моё братство или поданные заявки',
        security,
        response: { 200: myGuildSchema, ...read },
      },
    },
    async (req) => deps.guilds.mine(req.auth!.user.id),
  );

  r.post(
    '/guilds',
    {
      ...auth,
      schema: {
        tags: gTags,
        summary: 'Создать братство (Замок ≥ 5, 1 000 золота)',
        security,
        headers: idempotencyHeaders,
        body: createGuildBody,
        response: { 200: myGuildSchema, ...failures },
      },
    },
    async (req, reply) => {
      const res = await deps.guilds.create(
        req.auth!.user.id,
        req.body.name,
        req.body.description,
        req.headers['idempotency-key'],
      );
      if (res.replayed) reply.header('Idempotent-Replay', 'true');
      return deps.guilds.mine(req.auth!.user.id);
    },
  );

  r.post(
    '/guilds/:id/apply',
    {
      ...auth,
      schema: {
        tags: gTags,
        summary: 'Подать заявку',
        security,
        params: idParams,
        response: { 204: z.null(), ...failures },
      },
    },
    async (req, reply) => {
      await deps.guilds.apply(req.auth!.user.id, req.params.id);
      return reply.code(204).send(null);
    },
  );

  r.delete(
    '/guilds/:id/apply',
    {
      ...auth,
      schema: {
        tags: gTags,
        summary: 'Отозвать заявку',
        security,
        params: idParams,
        response: { 204: z.null(), ...failures },
      },
    },
    async (req, reply) => {
      await deps.guilds.withdraw(req.auth!.user.id, req.params.id);
      return reply.code(204).send(null);
    },
  );

  for (const accept of [true, false]) {
    r.post(
      `/guilds/applications/:id/${accept ? 'accept' : 'reject'}`,
      {
        ...auth,
        schema: {
          tags: gTags,
          summary: accept ? 'Принять заявку' : 'Отклонить заявку',
          security,
          params: idParams,
          response: { 204: z.null(), ...failures },
        },
      },
      async (req, reply) => {
        await deps.guilds.decide(req.auth!.user.id, req.params.id, accept);
        return reply.code(204).send(null);
      },
    );
  }

  r.post(
    '/guilds/members/:userId/role',
    {
      ...auth,
      schema: {
        tags: gTags,
        summary: 'Роль участника (глава)',
        security,
        params: userParams,
        body: roleBody,
        response: { 204: z.null(), 403: errorSchema, ...failures },
      },
    },
    async (req, reply) => {
      await deps.guilds.setRole(req.auth!.user.id, req.params.userId, req.body.role);
      return reply.code(204).send(null);
    },
  );

  r.delete(
    '/guilds/members/:userId',
    {
      ...auth,
      schema: {
        tags: gTags,
        summary: 'Исключить участника',
        security,
        params: userParams,
        response: { 204: z.null(), 403: errorSchema, ...failures },
      },
    },
    async (req, reply) => {
      await deps.guilds.kick(req.auth!.user.id, req.params.userId);
      return reply.code(204).send(null);
    },
  );

  r.post(
    '/guilds/leave',
    {
      ...auth,
      schema: {
        tags: gTags,
        summary: 'Выйти из братства',
        security,
        response: { 204: z.null(), ...failures },
      },
    },
    async (req, reply) => {
      await deps.guilds.leave(req.auth!.user.id);
      return reply.code(204).send(null);
    },
  );

  r.post(
    '/guilds/treasury/donate',
    {
      ...auth,
      schema: {
        tags: gTags,
        summary: 'Взнос золота в казну',
        security,
        headers: idempotencyHeaders,
        body: donateBody,
        response: { 200: castleSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await deps.guilds.donate(
          req.auth!.user.id,
          req.body.amount,
          req.headers['idempotency-key'],
        ),
      ),
  );

  r.post(
    '/guilds/help/:ownerId/:taskId',
    {
      ...auth,
      schema: {
        tags: gTags,
        summary: 'Помочь соратнику ускорить стройку',
        security,
        params: helpParams,
        response: { 200: z.object({ seconds: z.number() }), ...failures },
      },
    },
    async (req) => deps.guilds.help(req.auth!.user.id, req.params.ownerId, req.params.taskId),
  );

  // ── Чат ──
  const cTags = ['chat'];
  r.get(
    '/chat/:channel/history',
    {
      ...auth,
      schema: {
        tags: cTags,
        summary: 'Последние сообщения канала (world, guild, dm:<id>)',
        security,
        params: channelParams,
        querystring: historyQuery,
        response: { 200: z.array(chatMessageSchema), ...failures },
      },
    },
    async (req) =>
      deps.chat.history(
        req.auth!.user.id,
        req.params.channel,
        req.query.before ? new Date(req.query.before) : undefined,
      ),
  );

  r.post(
    '/chat/:channel/messages',
    {
      ...auth,
      schema: {
        tags: cTags,
        summary: 'Отправить сообщение (запасной путь на случай, если WebSocket недоступен)',
        security,
        params: channelParams,
        body: sendBody,
        response: { 200: chatMessageSchema, 403: errorSchema, 429: errorSchema, ...failures },
      },
    },
    async (req) => deps.chat.send(req.auth!.user.id, req.params.channel, req.body.text),
  );

  r.post(
    '/chat/report',
    {
      ...auth,
      schema: {
        tags: cTags,
        summary: 'Пожаловаться на сообщение',
        security,
        body: reportBody,
        response: { 204: z.null(), ...failures },
      },
    },
    async (req, reply) => {
      await deps.chat.report(req.auth!.user.id, req.body.messageId, req.body.reason);
      return reply.code(204).send(null);
    },
  );

  // ── Уведомления ──
  const nTags = ['notifications'];
  r.get(
    '/notifications',
    {
      ...auth,
      schema: {
        tags: nTags,
        summary: 'Уведомления (страницами)',
        security,
        querystring: notificationQuery,
        response: { 200: notificationPageSchema, ...read },
      },
    },
    async (req) => deps.notifications.list(req.auth!.user.id, req.query.page, req.query.pageSize),
  );

  r.post(
    '/notifications/read',
    {
      ...auth,
      schema: {
        tags: nTags,
        summary: 'Отметить прочитанными (без ids — все)',
        security,
        body: readBody,
        response: { 200: z.object({ marked: z.number() }), ...read },
      },
    },
    async (req) => ({ marked: await deps.notifications.markRead(req.auth!.user.id, req.body.ids) }),
  );
}
