import type { WsServerMessage } from '@tc/shared';

export type Send = (msg: WsServerMessage) => void;

/**
 * Реестр открытых WebSocket-соединений по игрокам. Рассылка идёт «по игрокам», а не по подпискам на каналы:
 * состав получателей сервер определяет сам при каждой отправке (мировой чат — все онлайн; братство и личные —
 * участники), поэтому клиент не может подписаться на чужой канал (D-42).
 */
export class Hub {
  private readonly conns = new Map<string, Set<Send>>();
  private readonly closers = new Map<Send, () => void>();

  /** Регистрирует соединение; возвращает функцию отписки. */
  add(userId: string, send: Send, close?: () => void): () => void {
    let set = this.conns.get(userId);
    if (!set) this.conns.set(userId, (set = new Set()));
    set.add(send);
    if (close) this.closers.set(send, close);
    return () => {
      this.closers.delete(send);
      const cur = this.conns.get(userId);
      cur?.delete(send);
      if (cur && cur.size === 0) this.conns.delete(userId);
    };
  }

  /** Закрывает все соединения игрока (бан). */
  kick(userId: string): number {
    let n = 0;
    for (const send of [...(this.conns.get(userId) ?? [])]) {
      this.closers.get(send)?.();
      n++;
    }
    return n;
  }

  get online(): number {
    return this.conns.size;
  }

  isOnline(userId: string): boolean {
    return this.conns.has(userId);
  }

  toUser(userId: string, msg: WsServerMessage): void {
    for (const send of this.conns.get(userId) ?? []) send(msg);
  }

  toUsers(userIds: Iterable<string>, msg: WsServerMessage): void {
    for (const id of new Set(userIds)) this.toUser(id, msg);
  }

  toAll(msg: WsServerMessage): void {
    for (const set of this.conns.values()) for (const send of set) send(msg);
  }
}
