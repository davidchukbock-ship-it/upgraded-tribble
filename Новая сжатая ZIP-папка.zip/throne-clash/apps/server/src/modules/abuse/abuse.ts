import type { FastifyRequest } from 'fastify';
import type { Clock } from '../../lib/clock';
import { Errors } from '../../lib/errors';
import type { SecurityLogRepository, UserRecord } from '../auth/auth.types';
import { WindowLimiter } from '../social/window-limiter';

/** Виды событий журнала подозрительных действий (docs/SECURITY.md). */
export const SECURITY_KINDS = [
  'action_flood',
  'idempotency_mismatch',
  'rate_limited',
  'chat_flood',
  'admin_denied',
  'god_login',
  'god_login_failed',
  'god_login_blocked',
  'admin_action',
  'login_locked',
  'login_failed',
  'refresh_reuse',
] as const;

/**
 * Запись в журнал безопасности с ограничением частоты одинаковых записей: атака, вызывающая тысячи
 * одинаковых событий, не должна раздувать таблицу. Ошибка записи никогда не ломает запрос.
 */
export class SecurityLogger {
  private readonly last = new Map<string, number>();

  constructor(
    private readonly repo: SecurityLogRepository,
    private readonly clock: Clock,
    private readonly onError: (err: unknown) => void = () => undefined,
  ) {}

  log(
    kind: string,
    who: { userId?: string | null; ip?: string | undefined },
    details?: Record<string, unknown>,
    throttleMs = 60_000,
  ): void {
    const now = this.clock.now();
    const key = `${kind}|${who.userId ?? ''}|${who.ip ?? ''}`;
    const prev = this.last.get(key);
    if (throttleMs > 0 && prev !== undefined && now.getTime() - prev < throttleMs) return;
    this.last.set(key, now.getTime());
    if (this.last.size > 5000) {
      for (const [k, t] of this.last) if (now.getTime() - t > 3_600_000) this.last.delete(k);
    }
    this.repo
      .add({
        userId: who.userId ?? null,
        kind,
        ip: who.ip,
        ...(details && { details }),
        createdAt: now,
      })
      .catch(this.onError);
  }
}

/**
 * Ограничение частоты изменяющих запросов на игрока (поверх лимита по IP): слишком частые действия — признак
 * бота или подбора. Превышение отвечает 429 и попадает в журнал (`action_flood`).
 */
export class MutationGuard {
  private readonly limiter: WindowLimiter;

  constructor(
    max: number,
    windowSeconds: number,
    private readonly clock: Clock,
    private readonly logger: SecurityLogger,
  ) {
    this.limiter = new WindowLimiter(max, windowSeconds);
  }

  check(req: FastifyRequest, user: UserRecord): void {
    // Служебная зона режима бога не ограничивается: владелец вводит команды подряд
    if (req.url.startsWith('/api/god')) return;
    const wait = this.limiter.hit(user.id, this.clock.now());
    if (wait === 0) return;
    this.logger.log(
      'action_flood',
      { userId: user.id, ip: req.ip },
      { path: req.url.split('?')[0] },
    );
    throw Errors.locked(wait);
  }
}
