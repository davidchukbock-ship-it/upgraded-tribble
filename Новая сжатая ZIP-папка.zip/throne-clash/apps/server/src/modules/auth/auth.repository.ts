import { Prisma, type PrismaClient, type User } from '@prisma/client';
import { nicknameKey, type Locale, type Role } from '@tc/shared';
import type { Repositories } from '../../repositories';
import { PrismaCastleRepository } from '../castle/castle.repository';
import {
  UniqueViolation,
  type NewCastle,
  type NewSession,
  type NewUser,
  type SecurityEvent,
  type SecurityLogRepository,
  type SessionRecord,
  type SessionRepository,
  type UserListOptions,
  type UserPatch,
  type UserRecord,
  type UserRepository,
  type UserStats,
} from './auth.types';

function toRecord(u: User): UserRecord {
  return { ...u, language: u.language as Locale };
}

/** P2002 → UniqueViolation с полем, по которому конфликт. */
function mapUnique(err: unknown): never {
  if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === 'P2002') {
    const target = String(err.meta?.['target'] ?? '');
    throw new UniqueViolation(target.includes('email') ? 'email' : 'nickname');
  }
  throw err;
}

export class PrismaUserRepository implements UserRepository {
  constructor(private readonly db: PrismaClient) {}

  async findById(id: string): Promise<UserRecord | null> {
    const u = await this.db.user.findUnique({ where: { id } });
    return u && toRecord(u);
  }

  async findByEmail(email: string): Promise<UserRecord | null> {
    const u = await this.db.user.findUnique({ where: { email } });
    return u && toRecord(u);
  }

  async createWithCastle(user: NewUser, castle: NewCastle): Promise<UserRecord> {
    try {
      const created = await this.db.user.create({
        data: {
          ...user,
          castles: {
            create: {
              worldId: castle.worldId,
              ...castle.resources,
              gems: castle.gems,
              resourcesUpdatedAt: castle.resourcesUpdatedAt,
              shieldUntil: castle.shieldUntil,
              // Json без значения по умолчанию (MySQL его не поддерживает) — задаём явно
              structures: [],
              buildings: { create: castle.buildings.map((key) => ({ key, level: 1 })) },
            },
          },
        },
      });
      return toRecord(created);
    } catch (err) {
      return mapUnique(err);
    }
  }

  async update(id: string, patch: UserPatch): Promise<UserRecord> {
    try {
      return toRecord(await this.db.user.update({ where: { id }, data: patch }));
    } catch (err) {
      return mapUnique(err);
    }
  }

  async recordLoginFailure(
    id: string,
    now: Date,
    limit: { maxFailures: number; lockMs: number },
  ): Promise<{ failedLogins: number; lockedUntil: Date | null }> {
    // Инкремент атомарен на стороне БД; порог проверяем по возвращённому значению
    const after = await this.db.user.update({
      where: { id },
      data: { failedLogins: { increment: 1 } },
      select: { failedLogins: true },
    });
    if (after.failedLogins < limit.maxFailures)
      return { failedLogins: after.failedLogins, lockedUntil: null };
    const lockedUntil = new Date(now.getTime() + limit.lockMs);
    await this.db.user.update({ where: { id }, data: { failedLogins: 0, lockedUntil } });
    return { failedLogins: after.failedLogins, lockedUntil };
  }

  async recordLoginSuccess(id: string, now: Date): Promise<void> {
    await this.db.user.update({
      where: { id },
      data: { failedLogins: 0, lockedUntil: null, lastLoginAt: now },
    });
  }

  async setRole(id: string, role: Role): Promise<void> {
    await this.db.user.update({ where: { id }, data: { role } });
  }

  countByRole(role: Role): Promise<number> {
    return this.db.user.count({ where: { role } });
  }

  async list(opts: UserListOptions) {
    const q = opts.query?.trim() ?? '';
    const key = q ? nicknameKey(q) : '';
    const where: Prisma.UserWhereInput = {
      ...(opts.role && { role: opts.role }),
      ...(q && {
        OR: [
          { id: q },
          ...(key ? [{ nicknameKey: { contains: key } }] : []),
          { email: { contains: q.toLowerCase() } },
        ],
      }),
    };
    const [rows, total] = await Promise.all([
      this.db.user.findMany({
        where,
        orderBy: [{ createdAt: 'desc' }, { id: 'asc' }],
        skip: (opts.page - 1) * opts.pageSize,
        take: opts.pageSize,
      }),
      this.db.user.count({ where }),
    ]);
    return { items: rows.map(toRecord), total };
  }

  async stats(now: Date): Promise<UserStats> {
    const ago = (ms: number) => new Date(now.getTime() - ms);
    const [total, guests, bots, banned, muted, new24h, new7d] = await Promise.all([
      this.db.user.count(),
      this.db.user.count({ where: { isGuest: true } }),
      this.db.user.count({ where: { isBot: true } }),
      this.db.user.count({ where: { bannedUntil: { gt: now } } }),
      this.db.user.count({ where: { mutedUntil: { gt: now } } }),
      this.db.user.count({ where: { createdAt: { gte: ago(86_400_000) } } }),
      this.db.user.count({ where: { createdAt: { gte: ago(7 * 86_400_000) } } }),
    ]);
    return { total, guests, bots, banned, muted, new24h, new7d };
  }
}

export class PrismaSessionRepository implements SessionRepository {
  constructor(private readonly db: PrismaClient) {}

  create(s: NewSession): Promise<SessionRecord> {
    return this.db.refreshToken.create({
      data: {
        userId: s.userId,
        family: s.family,
        tokenHash: s.tokenHash,
        expiresAt: s.expiresAt,
        createdAt: s.createdAt,
        userAgent: s.userAgent?.slice(0, 300) ?? null,
        ip: s.ip ?? null,
      },
    });
  }

  findByHash(tokenHash: string): Promise<SessionRecord | null> {
    return this.db.refreshToken.findUnique({ where: { tokenHash } });
  }

  async revokeIfActive(id: string, now: Date): Promise<boolean> {
    const r = await this.db.refreshToken.updateMany({
      where: { id, revokedAt: null },
      data: { revokedAt: now },
    });
    return r.count === 1;
  }

  async revokeFamily(family: string, now: Date): Promise<void> {
    await this.db.refreshToken.updateMany({
      where: { family, revokedAt: null },
      data: { revokedAt: now },
    });
  }

  async revokeAllForUser(userId: string, now: Date): Promise<void> {
    await this.db.refreshToken.updateMany({
      where: { userId, revokedAt: null },
      data: { revokedAt: now },
    });
  }

  async countActiveUsers(since: Date): Promise<number> {
    const rows = await this.db.refreshToken.findMany({
      where: { createdAt: { gte: since }, user: { isBot: false } },
      distinct: ['userId'],
      select: { userId: true },
    });
    return rows.length;
  }

  async deleteExpired(before: Date): Promise<number> {
    const r = await this.db.refreshToken.deleteMany({ where: { expiresAt: { lt: before } } });
    return r.count;
  }
}

const toEvent = (r: {
  userId: string | null;
  kind: string;
  ip: string | null;
  details: unknown;
  createdAt: Date;
}): SecurityEvent => ({
  userId: r.userId,
  kind: r.kind,
  ip: r.ip ?? undefined,
  details: (r.details ?? undefined) as Record<string, unknown> | undefined,
  createdAt: r.createdAt,
});

export class PrismaSecurityLogRepository implements SecurityLogRepository {
  constructor(private readonly db: PrismaClient) {}

  async add(e: SecurityEvent): Promise<void> {
    await this.db.securityLog.create({
      data: {
        userId: e.userId ?? null,
        kind: e.kind,
        ip: e.ip ?? null,
        details: (e.details ?? Prisma.JsonNull) as Prisma.InputJsonValue,
        createdAt: e.createdAt,
      },
    });
  }

  async list(filter: { kind?: string; userId?: string }): Promise<SecurityEvent[]> {
    const rows = await this.db.securityLog.findMany({
      where: { kind: filter.kind, userId: filter.userId },
      orderBy: { createdAt: 'desc' },
      take: 200,
    });
    return rows.map(toEvent);
  }

  async page(filter: { kind?: string; userId?: string }, page: number, pageSize: number) {
    const where = { kind: filter.kind, userId: filter.userId };
    const [rows, total] = await Promise.all([
      this.db.securityLog.findMany({
        where,
        orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      this.db.securityLog.count({ where }),
    ]);
    return { items: rows.map(toEvent), total };
  }

  count(filter: { kind: string; since: Date; ip?: string; userId?: string }): Promise<number> {
    return this.db.securityLog.count({
      where: {
        kind: filter.kind,
        createdAt: { gte: filter.since },
        ...(filter.ip !== undefined && { ip: filter.ip }),
        ...(filter.userId !== undefined && { userId: filter.userId }),
      },
    });
  }
}

export function createPrismaRepositories(db: PrismaClient): Repositories {
  return {
    users: new PrismaUserRepository(db),
    sessions: new PrismaSessionRepository(db),
    security: new PrismaSecurityLogRepository(db),
    castles: new PrismaCastleRepository(db),
  };
}
