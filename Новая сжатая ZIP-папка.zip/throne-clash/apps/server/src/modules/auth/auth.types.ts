import type { BuildingKey, Locale, ResourceKey, Role } from '@tc/shared';

/** Запись пользователя так, как её видит слой сервисов (не Prisma-тип: сервисы от Prisma не зависят). */
export interface UserRecord {
  id: string;
  email: string | null;
  passwordHash: string | null;
  nickname: string;
  nicknameKey: string;
  role: Role;
  isGuest: boolean;
  isBot: boolean;
  language: Locale;
  crest: string;
  nicknameChangedAt: Date | null;
  bannedUntil: Date | null;
  banReason: string | null;
  mutedUntil: Date | null;
  failedLogins: number;
  lockedUntil: Date | null;
  createdAt: Date;
  lastLoginAt: Date | null;
}

export interface NewUser {
  email: string | null;
  passwordHash: string | null;
  nickname: string;
  nicknameKey: string;
  role?: Role;
  isGuest?: boolean;
  isBot?: boolean;
  language: Locale;
  crest: string;
  createdAt: Date;
}

/** Начальное состояние замка, создаваемого вместе с аккаунтом. */
export interface NewCastle {
  worldId: string;
  resources: Record<ResourceKey, number>;
  gems: number;
  buildings: readonly BuildingKey[];
  resourcesUpdatedAt: Date;
  shieldUntil: Date | null;
}

export type UserPatch = Partial<
  Pick<
    UserRecord,
    | 'email'
    | 'passwordHash'
    | 'nickname'
    | 'nicknameKey'
    | 'nicknameChangedAt'
    | 'role'
    | 'isGuest'
    | 'language'
    | 'crest'
    | 'bannedUntil'
    | 'banReason'
    | 'mutedUntil'
  >
>;

/** Нарушение уникальности; сервис превращает его в ERR_EMAIL_TAKEN / ERR_NICKNAME_TAKEN. */
export class UniqueViolation extends Error {
  constructor(readonly field: 'email' | 'nickname') {
    super(`Unique violation: ${field}`);
    this.name = 'UniqueViolation';
  }
}

export interface UserRepository {
  findById(id: string): Promise<UserRecord | null>;
  findByEmail(email: string): Promise<UserRecord | null>;
  /** Пользователь + замок + стартовые здания — атомарно: аккаунт без замка невозможен. */
  createWithCastle(user: NewUser, castle: NewCastle): Promise<UserRecord>;
  update(id: string, patch: UserPatch): Promise<UserRecord>;
  /** Атомарно увеличивает счётчик неудач; при достижении порога ставит блокировку. */
  recordLoginFailure(
    id: string,
    now: Date,
    limit: { maxFailures: number; lockMs: number },
  ): Promise<{ failedLogins: number; lockedUntil: Date | null }>;
  recordLoginSuccess(id: string, now: Date): Promise<void>;
  /** Роль OWNER/ADMIN назначается отдельным вызовом (CLI, панель владельца), не через update профиля. */
  setRole(id: string, role: Role): Promise<void>;
  countByRole(role: Role): Promise<number>;
  /** Поиск для админки: по нику (по ключу), почте или точному id; новые сверху. */
  list(opts: UserListOptions): Promise<{ items: UserRecord[]; total: number }>;
  stats(now: Date): Promise<UserStats>;
}

export interface UserListOptions {
  query?: string;
  role?: Role;
  page: number;
  pageSize: number;
}

export interface UserStats {
  total: number;
  guests: number;
  bots: number;
  banned: number;
  muted: number;
  new24h: number;
  new7d: number;
}

export interface SessionRecord {
  id: string;
  userId: string;
  family: string;
  tokenHash: string;
  expiresAt: Date;
  createdAt: Date;
  revokedAt: Date | null;
}

export interface NewSession {
  userId: string;
  family: string;
  tokenHash: string;
  expiresAt: Date;
  createdAt: Date;
  userAgent?: string | undefined;
  ip?: string | undefined;
}

export interface SessionRepository {
  create(session: NewSession): Promise<SessionRecord>;
  findByHash(tokenHash: string): Promise<SessionRecord | null>;
  /** Отзывает токен, только если он ещё активен. true — отозвали мы (защита от гонки двух refresh). */
  revokeIfActive(id: string, now: Date): Promise<boolean>;
  revokeFamily(family: string, now: Date): Promise<void>;
  revokeAllForUser(userId: string, now: Date): Promise<void>;
  deleteExpired(before: Date): Promise<number>;
  /** Сколько разных игроков (не боты) получали сессию с момента `since`. */
  countActiveUsers(since: Date): Promise<number>;
}

export interface SecurityEvent {
  userId?: string | null;
  kind: string;
  ip?: string | undefined;
  details?: Record<string, unknown>;
  createdAt: Date;
}

export interface SecurityLogRepository {
  add(event: SecurityEvent): Promise<void>;
  list(filter: { kind?: string; userId?: string }): Promise<SecurityEvent[]>;
  /** Страница журнала для админки, новые сверху. */
  page(
    filter: { kind?: string; userId?: string },
    page: number,
    pageSize: number,
  ): Promise<{ items: SecurityEvent[]; total: number }>;
  /** Сколько событий вида `kind` с момента `since` (по ip и/или игроку) — для блокировок по числу попыток. */
  count(filter: { kind: string; since: Date; ip?: string; userId?: string }): Promise<number>;
}

export interface Repositories {
  users: UserRepository;
  sessions: SessionRepository;
  security: SecurityLogRepository;
}

export type { Locale };
