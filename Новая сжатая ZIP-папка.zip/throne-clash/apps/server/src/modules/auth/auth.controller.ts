import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import type { ZodTypeProvider } from 'fastify-type-provider-zod';
import { z } from 'zod';
import {
  loginBodySchema,
  localeSchema,
  registerBodySchema,
  updateProfileBodySchema,
  upgradeGuestBodySchema,
  type AuthResponse,
} from '@tc/shared';
import type { AppConfig } from '../../config/env';
import type { Clock } from '../../lib/clock';
import { Errors } from '../../lib/errors';
import { randomToken, safeEqual } from '../../lib/tokens';
import { toUserDto, type AuthService, type IssuedSession } from './auth.service';

export const REFRESH_COOKIE = 'tc_refresh';
export const CSRF_COOKIE = 'tc_csrf';
export const CSRF_HEADER = 'x-csrf-token';

const userSchema = z.object({
  id: z.string(),
  nickname: z.string(),
  role: z.enum(['PLAYER', 'ADMIN', 'OWNER']),
  isGuest: z.boolean(),
  email: z.string().nullable(),
  language: localeSchema,
  crest: z.string(),
  createdAt: z.string(),
});
export const authResponseSchema = z.object({
  accessToken: z.string(),
  expiresIn: z.number(),
  user: userSchema,
  serverTime: z.string(),
});
const meResponseSchema = z.object({ user: userSchema, serverTime: z.string() });
const errorSchema = z.object({
  error: z.object({ code: z.string(), message: z.string(), details: z.unknown().optional() }),
  requestId: z.string(),
});

export interface AuthControllerDeps {
  service: AuthService;
  config: AppConfig;
  clock: Clock;
}

export function registerAuthRoutes(app: FastifyInstance, deps: AuthControllerDeps): void {
  const { service, config, clock } = deps;
  const r = app.withTypeProvider<ZodTypeProvider>();
  const ctxOf = (req: FastifyRequest) => ({ ip: req.ip, userAgent: req.headers['user-agent'] });
  const ttlSeconds = config.refreshTtlDays * 86_400;

  const setSessionCookies = (reply: FastifyReply, refreshToken: string): void => {
    const base = { secure: config.cookieSecure, sameSite: 'strict' as const, maxAge: ttlSeconds };
    reply.setCookie(REFRESH_COOKIE, refreshToken, { ...base, httpOnly: true, path: '/api/auth' });
    // CSRF-cookie читает клиентский JS и дублирует в заголовок (double-submit)
    reply.setCookie(CSRF_COOKIE, randomToken(24), { ...base, httpOnly: false, path: '/' });
  };
  const clearSessionCookies = (reply: FastifyReply): void => {
    reply.clearCookie(REFRESH_COOKIE, { path: '/api/auth' });
    reply.clearCookie(CSRF_COOKIE, { path: '/' });
  };
  const respond = (reply: FastifyReply, s: IssuedSession): AuthResponse => {
    setSessionCookies(reply, s.refreshToken);
    return {
      accessToken: s.accessToken,
      expiresIn: s.expiresIn,
      user: toUserDto(s.user, config.ownerEmail),
      serverTime: clock.now().toISOString(),
    };
  };

  /**
   * Защита cookie-эндпоинтов (D-05): Origin из списка разрешённых (если браузер его прислал)
   * и совпадение csrf-cookie с заголовком. SameSite=Strict — третий слой.
   */
  const assertCsrf = (req: FastifyRequest): void => {
    const origin = req.headers.origin;
    if (origin && !config.corsOrigins.includes(origin)) throw Errors.forbidden();
    const cookie = req.cookies[CSRF_COOKIE];
    const header = req.headers[CSRF_HEADER];
    if (!cookie || typeof header !== 'string' || !safeEqual(cookie, header))
      throw Errors.forbidden();
  };

  const authRate = (max: number, timeWindow: string) => ({ rateLimit: { max, timeWindow } });
  const tag = ['auth'];

  r.post(
    '/auth/register',
    {
      config: authRate(config.authRateLimit.registerPerHour, '1 hour'),
      schema: {
        tags: tag,
        summary: 'Регистрация по email и паролю',
        body: registerBodySchema,
        response: { 201: authResponseSchema, 409: errorSchema },
      },
    },
    async (req, reply) => {
      const session = await service.register(req.body, ctxOf(req));
      return reply.code(201).send(respond(reply, session));
    },
  );

  r.post(
    '/auth/login',
    {
      config: authRate(config.authRateLimit.loginPerMinute, '1 minute'),
      schema: {
        tags: tag,
        summary: 'Вход по email и паролю',
        body: loginBodySchema,
        response: { 200: authResponseSchema, 401: errorSchema, 429: errorSchema },
      },
    },
    async (req, reply) => respond(reply, await service.login(req.body, ctxOf(req))),
  );

  r.post(
    '/auth/guest',
    {
      config: authRate(config.authRateLimit.guestPerHour, '1 hour'),
      schema: {
        tags: tag,
        summary: 'Гостевой аккаунт без email',
        // Тело необязательно: без него Fastify передаёт null
        body: z.object({ language: localeSchema.optional() }).strict().nullish(),
        response: { 201: authResponseSchema },
      },
    },
    async (req, reply) => {
      const session = await service.createGuest(req.body?.language ?? 'ru', ctxOf(req));
      return reply.code(201).send(respond(reply, session));
    },
  );

  r.post(
    '/auth/refresh',
    {
      config: authRate(config.authRateLimit.refreshPerMinute, '1 minute'),
      schema: {
        tags: tag,
        summary: 'Ротация refresh-токена (cookie + X-CSRF-Token)',
        response: { 200: authResponseSchema, 401: errorSchema, 403: errorSchema },
      },
    },
    async (req, reply) => {
      assertCsrf(req);
      const raw = req.cookies[REFRESH_COOKIE];
      if (!raw) throw Errors.unauthorized();
      try {
        return respond(reply, await service.refresh(raw, ctxOf(req)));
      } catch (err) {
        // Токен негоден — убираем cookie, чтобы клиент не повторял запрос
        clearSessionCookies(reply);
        throw err;
      }
    },
  );

  r.post(
    '/auth/logout',
    {
      schema: {
        tags: tag,
        summary: 'Выход с этого устройства',
        response: { 204: z.null(), 403: errorSchema },
      },
    },
    async (req, reply) => {
      assertCsrf(req);
      await service.logout(req.cookies[REFRESH_COOKIE]);
      clearSessionCookies(reply);
      return reply.code(204).send(null);
    },
  );

  r.post(
    '/auth/logout-all',
    {
      preHandler: app.authenticate,
      schema: {
        tags: tag,
        summary: 'Выход на всех устройствах',
        security: [{ bearerAuth: [] }],
        response: { 204: z.null(), 401: errorSchema },
      },
    },
    async (req, reply) => {
      await service.logoutAll(req.auth!.user.id);
      clearSessionCookies(reply);
      return reply.code(204).send(null);
    },
  );

  r.post(
    '/auth/upgrade',
    {
      preHandler: app.authenticate,
      config: authRate(config.authRateLimit.registerPerHour, '1 hour'),
      schema: {
        tags: tag,
        summary: 'Гость привязывает email и пароль',
        security: [{ bearerAuth: [] }],
        body: upgradeGuestBodySchema,
        response: { 200: meResponseSchema, 409: errorSchema },
      },
    },
    async (req) => {
      const user = await service.upgradeGuest(req.auth!.user.id, req.body);
      return { user: toUserDto(user, config.ownerEmail), serverTime: clock.now().toISOString() };
    },
  );

  r.get(
    '/auth/me',
    {
      preHandler: app.authenticate,
      schema: {
        tags: tag,
        summary: 'Текущий пользователь',
        security: [{ bearerAuth: [] }],
        response: { 200: meResponseSchema, 401: errorSchema },
      },
    },
    async (req) => ({
      user: toUserDto(req.auth!.user, config.ownerEmail),
      serverTime: clock.now().toISOString(),
    }),
  );

  r.patch(
    '/profile',
    {
      preHandler: app.authenticate,
      schema: {
        tags: ['profile'],
        summary: 'Ник, герб, язык',
        security: [{ bearerAuth: [] }],
        body: updateProfileBodySchema,
        response: { 200: meResponseSchema, 409: errorSchema, 422: errorSchema },
      },
    },
    async (req) => {
      const user = await service.updateProfile(req.auth!.user.id, req.body);
      return { user: toUserDto(user, config.ownerEmail), serverTime: clock.now().toISOString() };
    },
  );
}
