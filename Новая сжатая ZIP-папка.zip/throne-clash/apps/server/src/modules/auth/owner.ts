import type { PasswordHasher } from './auth.service';
import type { UserRepository } from './auth.types';

export type OwnerGrantError =
  'owner_email_not_set' | 'user_not_found' | 'wrong_password' | 'other_owner_exists';

export class OwnerGrantFailure extends Error {
  constructor(readonly reason: OwnerGrantError) {
    super(reason);
    this.name = 'OwnerGrantFailure';
  }
}

/**
 * Назначает роль OWNER аккаунту с email из OWNER_EMAIL (D-19). Единственный путь получить эту роль.
 * Требуется пароль аккаунта: захватить почту владельца до его регистрации недостаточно —
 * роль получит только тот, кто знает пароль этого аккаунта и имеет доступ к серверу.
 */
export async function grantOwner(
  deps: { users: UserRepository; hasher: PasswordHasher; ownerEmail: string },
  password: string,
  opts: { force?: boolean } = {},
): Promise<'granted' | 'already_owner'> {
  if (!deps.ownerEmail) throw new OwnerGrantFailure('owner_email_not_set');
  const user = await deps.users.findByEmail(deps.ownerEmail);
  if (!user) throw new OwnerGrantFailure('user_not_found');
  if (!user.passwordHash || !(await deps.hasher.verify(user.passwordHash, password))) {
    throw new OwnerGrantFailure('wrong_password');
  }
  if (user.role === 'OWNER') return 'already_owner';
  // Владелец один: второго не назначаем молча
  if ((await deps.users.countByRole('OWNER')) > 0 && !opts.force) {
    throw new OwnerGrantFailure('other_owner_exists');
  }
  await deps.users.setRole(user.id, 'OWNER');
  return 'granted';
}
