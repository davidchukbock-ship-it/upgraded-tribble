import { describe, expect, it } from 'vitest';
import { createMemoryRepositories } from './auth.memory';
import { type PasswordHasher } from './auth.service';
import { grantOwner, OwnerGrantFailure } from './owner';

const hasher: PasswordHasher = {
  hash: async (p) => `h:${p}`,
  verify: async (h, p) => h === `h:${p}`,
};
const OWNER = 'owner@example.com';
const now = new Date('2026-01-01T00:00:00Z');
const castle = {
  worldId: 'main',
  resources: { gold: 1, wood: 1, stone: 1, food: 1 },
  gems: 0,
  buildings: [],
  resourcesUpdatedAt: now,
  shieldUntil: null,
} as const;

async function withUsers() {
  const repos = createMemoryRepositories();
  const owner = await repos.users.createWithCastle(
    {
      email: OWNER,
      passwordHash: 'h:secret-pass-1',
      nickname: 'Владелец',
      nicknameKey: 'vladelec',
      language: 'ru',
      crest: 'lion',
      createdAt: now,
    },
    castle,
  );
  const other = await repos.users.createWithCastle(
    {
      email: 'x@example.com',
      passwordHash: 'h:other-pass-1',
      nickname: 'Чужой',
      nicknameKey: 'chuzhoi',
      language: 'ru',
      crest: 'lion',
      createdAt: now,
    },
    castle,
  );
  return { repos, owner, other };
}

const reason = async (p: Promise<unknown>) =>
  p.then(
    () => 'ok',
    (e: unknown) => (e instanceof OwnerGrantFailure ? e.reason : 'crash'),
  );

describe('grantOwner', () => {
  it('выдаёт OWNER аккаунту из OWNER_EMAIL при верном пароле', async () => {
    const { repos, owner } = await withUsers();
    expect(
      await grantOwner({ users: repos.users, hasher, ownerEmail: OWNER }, 'secret-pass-1'),
    ).toBe('granted');
    expect((await repos.users.findById(owner.id))?.role).toBe('OWNER');
    expect(
      await grantOwner({ users: repos.users, hasher, ownerEmail: OWNER }, 'secret-pass-1'),
    ).toBe('already_owner');
  });

  it('неверный пароль — роль не выдаётся (захват чужого email не помогает)', async () => {
    const { repos, owner } = await withUsers();
    expect(
      await reason(grantOwner({ users: repos.users, hasher, ownerEmail: OWNER }, 'guess')),
    ).toBe('wrong_password');
    expect((await repos.users.findById(owner.id))?.role).toBe('PLAYER');
  });

  it('пустой OWNER_EMAIL и отсутствие аккаунта', async () => {
    const { repos } = await withUsers();
    expect(await reason(grantOwner({ users: repos.users, hasher, ownerEmail: '' }, 'x'))).toBe(
      'owner_email_not_set',
    );
    expect(
      await reason(grantOwner({ users: repos.users, hasher, ownerEmail: 'none@example.com' }, 'x')),
    ).toBe('user_not_found');
  });

  it('аккаунт без пароля (гость/бот) не может стать владельцем', async () => {
    const repos = createMemoryRepositories();
    await repos.users.createWithCastle(
      {
        email: OWNER,
        passwordHash: null,
        nickname: 'Без пароля',
        nicknameKey: 'bezparolya',
        language: 'ru',
        crest: 'lion',
        createdAt: now,
      },
      castle,
    );
    expect(await reason(grantOwner({ users: repos.users, hasher, ownerEmail: OWNER }, ''))).toBe(
      'wrong_password',
    );
  });

  it('второй владелец без --force не назначается', async () => {
    const { repos, other } = await withUsers();
    await repos.users.setRole(other.id, 'OWNER');
    expect(
      await reason(grantOwner({ users: repos.users, hasher, ownerEmail: OWNER }, 'secret-pass-1')),
    ).toBe('other_owner_exists');
    expect(
      await grantOwner({ users: repos.users, hasher, ownerEmail: OWNER }, 'secret-pass-1', {
        force: true,
      }),
    ).toBe('granted');
  });
});
