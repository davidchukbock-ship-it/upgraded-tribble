import { beforeEach, describe, expect, it } from 'vitest';
import { NEWBIE_SHIELD_HOURS, START_BUILDINGS, START_GEMS, START_RESOURCES } from '@tc/shared';
import { FakeClock } from '../../lib/clock';
import { AppError } from '../../lib/errors';
import { AccessTokenService, sha256 } from '../../lib/tokens';
import { createMemoryRepositories } from './auth.memory';
import {
  AuthService,
  LOGIN_LOCK_MS,
  MAX_FAILED_LOGINS,
  NICKNAME_COOLDOWN_MS,
  REFRESH_REUSE_GRACE_MS,
  effectiveRole,
  toUserDto,
  type PasswordHasher,
} from './auth.service';

/** Быстрый хешер: в этих тестах проверяем правила, а не argon2 (он покрыт в password.test). */
const fastHasher: PasswordHasher = {
  hash: async (p) => `h:${p}`,
  verify: async (h, p) => h === `h:${p}`,
};

const SECRET = 'unit-test-secret-unit-test-secret-32';
const OWNER = 'owner@example.com';
const ctx = { ip: '203.0.113.7', userAgent: 'vitest' };

function setup(ownerEmail = OWNER) {
  const repos = createMemoryRepositories();
  const clock = new FakeClock();
  const tokens = new AccessTokenService(SECRET, 900);
  const service = new AuthService({
    repos,
    tokens,
    clock,
    refreshTtlDays: 30,
    ownerEmail,
    hasher: fastHasher,
  });
  return { repos, clock, tokens, service };
}

const newUser = { email: 'hero@example.com', password: 'Correct horse 42', nickname: 'Артур' };

async function expectCode(p: Promise<unknown>, code: string, status?: number): Promise<AppError> {
  const err = await p.then(
    () => undefined,
    (e: unknown) => e,
  );
  expect(err).toBeInstanceOf(AppError);
  expect((err as AppError).code).toBe(code);
  if (status) expect((err as AppError).statusCode).toBe(status);
  return err as AppError;
}

describe('регистрация', () => {
  let s: ReturnType<typeof setup>;
  beforeEach(() => void (s = setup()));

  it('создаёт аккаунт, замок со стартовым набором и сессию', async () => {
    const session = await s.service.register(newUser, ctx);
    expect(session.user).toMatchObject({
      email: 'hero@example.com',
      nickname: 'Артур',
      role: 'PLAYER',
    });
    expect(session.user.isGuest).toBe(false);
    expect(session.user.passwordHash).not.toBe(newUser.password); // в БД уходит хеш, не пароль

    const castle = s.repos.users.castles[0]!;
    expect(castle.resources).toEqual(START_RESOURCES);
    expect(castle.gems).toBe(START_GEMS);
    expect(castle.buildings).toEqual(START_BUILDINGS);
    // щит новичка отсчитывается от момента регистрации
    expect(castle.shieldUntil?.getTime()).toBe(
      s.clock.now().getTime() + NEWBIE_SHIELD_HOURS * 3600_000,
    );

    const claims = await s.tokens.verify(session.accessToken, s.clock.now());
    expect(claims?.userId).toBe(session.user.id);
  });

  it('refresh-токен хранится только в виде хеша', async () => {
    const session = await s.service.register(newUser, ctx);
    const stored = [...s.repos.sessions.sessions.values()][0]!;
    expect(stored.tokenHash).toBe(sha256(session.refreshToken));
    expect(JSON.stringify(stored)).not.toContain(session.refreshToken);
  });

  it('занятый email и занятый ник дают разные коды', async () => {
    await s.service.register(newUser, ctx);
    await expectCode(
      s.service.register({ ...newUser, nickname: 'Другой' }, ctx),
      'ERR_EMAIL_TAKEN',
      409,
    );
    await expectCode(
      s.service.register({ ...newUser, email: 'x@example.com', nickname: 'арТУР' }, ctx),
      'ERR_NICKNAME_TAKEN',
      409,
    );
  });

  it('ник с кириллическим двойником считается занятым', async () => {
    await s.service.register({ ...newUser, nickname: 'Kaya' }, ctx);
    await expectCode(
      s.service.register({ ...newUser, email: 'k@example.com', nickname: 'Кауа' }, ctx),
      'ERR_NICKNAME_TAKEN',
    );
  });

  it('роль всегда PLAYER — даже для OWNER_EMAIL (роль выдаёт только CLI)', async () => {
    const session = await s.service.register({ ...newUser, email: OWNER }, ctx);
    expect(session.user.role).toBe('PLAYER');
  });
});

describe('гость', () => {
  it('получает уникальный ник, замок и может стать полноценным аккаунтом', async () => {
    const { service, repos } = setup();
    const guest = await service.createGuest('ru', ctx);
    expect(guest.user).toMatchObject({ isGuest: true, email: null, passwordHash: null });
    expect(guest.user.nickname).toMatch(/^Гость-[A-Z2-9]{5}$/);
    expect(repos.users.castles).toHaveLength(1);

    const en = await service.createGuest('en', ctx);
    expect(en.user.nickname).toMatch(/^Guest-/);
    expect(en.user.nickname).not.toBe(guest.user.nickname);

    const upgraded = await service.upgradeGuest(guest.user.id, {
      email: 'g@example.com',
      password: 'Correct horse 42',
    });
    expect(upgraded).toMatchObject({ isGuest: false, email: 'g@example.com' });
    await expectCode(
      service.upgradeGuest(guest.user.id, {
        email: 'again@example.com',
        password: 'Correct horse 42',
      }),
      'ERR_CONFLICT',
    );
  });

  it('привязка занятого email отклоняется, гость остаётся гостем', async () => {
    const { service, repos } = setup();
    await service.register(newUser, ctx);
    const guest = await service.createGuest('ru', ctx);
    await expectCode(
      service.upgradeGuest(guest.user.id, { email: newUser.email, password: 'Correct horse 42' }),
      'ERR_EMAIL_TAKEN',
    );
    expect(repos.users.users.get(guest.user.id)?.isGuest).toBe(true);
  });

  it('вход по email для гостя невозможен', async () => {
    const { service } = setup();
    await service.createGuest('ru', ctx);
    await expectCode(
      service.login({ email: 'nobody@example.com', password: 'x' }, ctx),
      'ERR_INVALID_CREDENTIALS',
      401,
    );
  });
});

describe('вход', () => {
  let s: ReturnType<typeof setup>;
  beforeEach(async () => {
    s = setup();
    await s.service.register(newUser, ctx);
  });

  it('верный пароль → сессия, сбрасывает счётчик, ставит lastLoginAt', async () => {
    s.clock.advance(60);
    const session = await s.service.login(
      { email: newUser.email, password: newUser.password },
      ctx,
    );
    expect(session.user.lastLoginAt?.getTime()).toBe(s.clock.now().getTime());
  });

  it('неверный пароль и неизвестный email неотличимы', async () => {
    const wrong = await expectCode(
      s.service.login({ email: newUser.email, password: 'nope' }, ctx),
      'ERR_INVALID_CREDENTIALS',
      401,
    );
    const unknown = await expectCode(
      s.service.login({ email: 'ghost@example.com', password: 'nope' }, ctx),
      'ERR_INVALID_CREDENTIALS',
      401,
    );
    expect(wrong.message).toBe(unknown.message);
    expect(wrong.details).toEqual(unknown.details);
  });

  it(`после ${MAX_FAILED_LOGINS} неудач вход закрыт даже с верным паролем; потом открывается`, async () => {
    for (let i = 0; i < MAX_FAILED_LOGINS; i++) {
      await expectCode(
        s.service.login({ email: newUser.email, password: 'bad' }, ctx),
        'ERR_INVALID_CREDENTIALS',
      );
    }
    const locked = await expectCode(
      s.service.login({ email: newUser.email, password: newUser.password }, ctx),
      'ERR_RATE_LIMITED',
      429,
    );
    expect(locked.details).toMatchObject({ retryAfterSeconds: LOGIN_LOCK_MS / 1000 });
    expect(await s.repos.security.list({ kind: 'login_locked' })).toHaveLength(1);

    s.clock.advance(LOGIN_LOCK_MS / 1000 + 1);
    await expect(
      s.service.login({ email: newUser.email, password: newUser.password }, ctx),
    ).resolves.toBeDefined();
  });

  it('успешный вход посреди серии неудач обнуляет счётчик', async () => {
    for (let i = 0; i < MAX_FAILED_LOGINS - 1; i++)
      await expectCode(
        s.service.login({ email: newUser.email, password: 'bad' }, ctx),
        'ERR_INVALID_CREDENTIALS',
      );
    await s.service.login({ email: newUser.email, password: newUser.password }, ctx);
    for (let i = 0; i < MAX_FAILED_LOGINS - 1; i++)
      await expectCode(
        s.service.login({ email: newUser.email, password: 'bad' }, ctx),
        'ERR_INVALID_CREDENTIALS',
      );
    await expect(
      s.service.login({ email: newUser.email, password: newUser.password }, ctx),
    ).resolves.toBeDefined();
  });

  it('забаненный не входит, причина и срок передаются; бан по времени истекает', async () => {
    const user = [...s.repos.users.users.values()][0]!;
    user.bannedUntil = new Date(s.clock.now().getTime() + 3600_000);
    user.banReason = 'cheating';
    const err = await expectCode(
      s.service.login({ email: newUser.email, password: newUser.password }, ctx),
      'ERR_BANNED',
      403,
    );
    expect(err.details).toMatchObject({ reason: 'cheating' });

    s.clock.advance(3601);
    await expect(
      s.service.login({ email: newUser.email, password: newUser.password }, ctx),
    ).resolves.toBeDefined();
  });

  it('забаненному не раскрываем бан, если пароль неверный', async () => {
    const user = [...s.repos.users.users.values()][0]!;
    user.bannedUntil = new Date(s.clock.now().getTime() + 3600_000);
    await expectCode(
      s.service.login({ email: newUser.email, password: 'bad' }, ctx),
      'ERR_INVALID_CREDENTIALS',
    );
  });
});

describe('refresh', () => {
  let s: ReturnType<typeof setup>;
  let first: Awaited<ReturnType<AuthService['register']>>;
  beforeEach(async () => {
    s = setup();
    first = await s.service.register(newUser, ctx);
  });

  it('ротация: старый токен отзывается, новый живёт в той же цепочке', async () => {
    const second = await s.service.refresh(first.refreshToken, ctx);
    expect(second.refreshToken).not.toBe(first.refreshToken);
    const rows = [...s.repos.sessions.sessions.values()];
    expect(rows).toHaveLength(2);
    expect(new Set(rows.map((r) => r.family)).size).toBe(1);
    expect(rows.filter((r) => r.revokedAt)).toHaveLength(1);
  });

  it('повтор старого токена сразу после ротации — отказ без отзыва цепочки (гонка вкладок)', async () => {
    const second = await s.service.refresh(first.refreshToken, ctx);
    await expectCode(s.service.refresh(first.refreshToken, ctx), 'ERR_UNAUTHORIZED', 401);
    await expect(s.service.refresh(second.refreshToken, ctx)).resolves.toBeDefined();
  });

  it('повтор старого токена спустя время = кража: вся цепочка отзывается и пишется в журнал', async () => {
    const second = await s.service.refresh(first.refreshToken, ctx);
    s.clock.advance(REFRESH_REUSE_GRACE_MS / 1000 + 1);
    await expectCode(s.service.refresh(first.refreshToken, ctx), 'ERR_UNAUTHORIZED');
    // новый токен тоже больше не работает
    await expectCode(s.service.refresh(second.refreshToken, ctx), 'ERR_UNAUTHORIZED');
    const log = await s.repos.security.list({ kind: 'refresh_reuse' });
    expect(log).toHaveLength(1);
    expect(log[0]?.userId).toBe(first.user.id);
  });

  it('просроченный и неизвестный токены отклоняются', async () => {
    s.clock.advance(30 * 86400 + 1);
    await expectCode(s.service.refresh(first.refreshToken, ctx), 'ERR_UNAUTHORIZED');
    await expectCode(s.service.refresh('unknown-token', ctx), 'ERR_UNAUTHORIZED');
  });

  it('бан отзывает сессию при обновлении', async () => {
    [...s.repos.users.users.values()][0]!.bannedUntil = new Date(s.clock.now().getTime() + 1e6);
    await expectCode(s.service.refresh(first.refreshToken, ctx), 'ERR_BANNED', 403);
    expect([...s.repos.sessions.sessions.values()].every((r) => r.revokedAt)).toBe(true);
  });

  it('logout отзывает цепочку устройства и идемпотентен', async () => {
    const second = await s.service.refresh(first.refreshToken, ctx);
    await s.service.logout(second.refreshToken);
    await s.service.logout(second.refreshToken);
    await s.service.logout(undefined);
    await expectCode(s.service.refresh(second.refreshToken, ctx), 'ERR_UNAUTHORIZED');
  });

  it('logoutAll отзывает все устройства', async () => {
    const other = await s.service.login({ email: newUser.email, password: newUser.password }, ctx);
    await s.service.logoutAll(first.user.id);
    await expectCode(s.service.refresh(first.refreshToken, ctx), 'ERR_UNAUTHORIZED');
    await expectCode(s.service.refresh(other.refreshToken, ctx), 'ERR_UNAUTHORIZED');
  });
});

describe('профиль', () => {
  let s: ReturnType<typeof setup>;
  let userId: string;
  beforeEach(async () => {
    s = setup();
    userId = (await s.service.register(newUser, ctx)).user.id;
  });

  it('меняет герб и язык', async () => {
    const u = await s.service.updateProfile(userId, { crest: 'wolf', language: 'en' });
    expect(u).toMatchObject({ crest: 'wolf', language: 'en' });
  });

  it('первая смена ника свободна, следующая — раз в сутки', async () => {
    await s.service.updateProfile(userId, { nickname: 'Новый Ник' });
    const err = await expectCode(
      s.service.updateProfile(userId, { nickname: 'Ещё Ник' }),
      'ERR_REQUIREMENT_NOT_MET',
      422,
    );
    expect(err.details).toMatchObject({ reason: 'nickname_cooldown' });

    s.clock.advance(NICKNAME_COOLDOWN_MS / 1000 + 1);
    const u = await s.service.updateProfile(userId, { nickname: 'Ещё Ник' });
    expect(u.nickname).toBe('Ещё Ник');
  });

  it('смена только регистра не запускает кулдаун', async () => {
    await s.service.updateProfile(userId, { nickname: 'арТУР' });
    await expect(s.service.updateProfile(userId, { nickname: 'АРТУР' })).resolves.toBeDefined();
  });

  it('занятый ник отклоняется, свой прежний ник не ломает запрос', async () => {
    await s.service.register(
      { email: 'b@example.com', password: 'Correct horse 42', nickname: 'Занят' },
      ctx,
    );
    await expectCode(
      s.service.updateProfile(userId, { nickname: 'занят' }),
      'ERR_NICKNAME_TAKEN',
      409,
    );
    await expect(
      s.service.updateProfile(userId, { nickname: 'Артур', crest: 'stag' }),
    ).resolves.toBeDefined();
  });
});

describe('роли', () => {
  it('OWNER действует только при совпадении с OWNER_EMAIL', () => {
    expect(effectiveRole({ role: 'OWNER', email: OWNER }, OWNER)).toBe('OWNER');
    expect(effectiveRole({ role: 'OWNER', email: 'evil@example.com' }, OWNER)).toBe('PLAYER');
    expect(effectiveRole({ role: 'OWNER', email: OWNER }, '')).toBe('PLAYER'); // переменная не задана
    expect(effectiveRole({ role: 'OWNER', email: null }, '')).toBe('PLAYER');
    expect(effectiveRole({ role: 'ADMIN', email: 'a@b.co' }, OWNER)).toBe('ADMIN');
    expect(effectiveRole({ role: 'PLAYER', email: OWNER }, OWNER)).toBe('PLAYER');
  });

  it('DTO не содержит хеша пароля и служебных полей', async () => {
    const { service } = setup();
    const { user } = await service.register(newUser, ctx);
    const dto = toUserDto(user, OWNER);
    expect(Object.keys(dto).sort()).toEqual(
      ['createdAt', 'crest', 'email', 'id', 'isGuest', 'language', 'nickname', 'role'].sort(),
    );
    expect(JSON.stringify(dto)).not.toContain('h:');
  });
});
