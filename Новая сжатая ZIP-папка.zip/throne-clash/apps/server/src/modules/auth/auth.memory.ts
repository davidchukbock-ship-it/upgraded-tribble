import { randomUUID } from 'node:crypto';
import { nicknameKey, type Role } from '@tc/shared';
import type { Repositories } from '../../repositories';
import { MemoryCastleRepository } from '../castle/castle.memory';
import {
  UniqueViolation,
  type NewCastle,
  type NewSession,
  type NewUser,
  type SecurityEvent,
  type SecurityLogRepository,
  type SessionRecord,
  type SessionRepository,
  type UserPatch,
  type UserListOptions,
  type UserRecord,
  type UserRepository,
  type UserStats,
} from './auth.types';

/** In-memory реализации для юнит-тестов (D-07). Контрактные тесты гоняют их и Prisma-версию одинаково. */
export class MemoryUserRepository implements UserRepository {
  readonly users = new Map<string, UserRecord>();
  readonly castles: Array<{ userId: string } & NewCastle> = [];

  async findById(id: string): Promise<UserRecord | null> {
    return this.copy(this.users.get(id));
  }

  async findByEmail(email: string): Promise<UserRecord | null> {
    return this.copy([...this.users.values()].find((u) => u.email === email));
  }

  async createWithCastle(user: NewUser, castle: NewCastle): Promise<UserRecord> {
    const all = [...this.users.values()];
    if (user.email !== null && all.some((u) => u.email === user.email))
      throw new UniqueViolation('email');
    if (all.some((u) => u.nicknameKey === user.nicknameKey)) throw new UniqueViolation('nickname');
    const record: UserRecord = {
      id: randomUUID(),
      email: user.email,
      passwordHash: user.passwordHash,
      nickname: user.nickname,
      nicknameKey: user.nicknameKey,
      role: user.role ?? 'PLAYER',
      isGuest: user.isGuest ?? false,
      isBot: user.isBot ?? false,
      language: user.language,
      crest: user.crest,
      nicknameChangedAt: null,
      bannedUntil: null,
      banReason: null,
      mutedUntil: null,
      failedLogins: 0,
      lockedUntil: null,
      createdAt: user.createdAt,
      lastLoginAt: null,
    };
    this.users.set(record.id, record);
    this.castles.push({ userId: record.id, ...castle });
    return { ...record };
  }

  async update(id: string, patch: UserPatch): Promise<UserRecord> {
    const cur = this.users.get(id);
    if (!cur) throw new Error('user not found');
    const others = [...this.users.values()].filter((u) => u.id !== id);
    if (patch.email && others.some((u) => u.email === patch.email))
      throw new UniqueViolation('email');
    if (patch.nicknameKey && others.some((u) => u.nicknameKey === patch.nicknameKey))
      throw new UniqueViolation('nickname');
    const next = { ...cur, ...definedOnly(patch) };
    this.users.set(id, next);
    return { ...next };
  }

  async recordLoginFailure(
    id: string,
    now: Date,
    limit: { maxFailures: number; lockMs: number },
  ): Promise<{ failedLogins: number; lockedUntil: Date | null }> {
    const cur = this.users.get(id);
    if (!cur) throw new Error('user not found');
    const failedLogins = cur.failedLogins + 1;
    const locked = failedLogins >= limit.maxFailures;
    cur.failedLogins = locked ? 0 : failedLogins;
    cur.lockedUntil = locked ? new Date(now.getTime() + limit.lockMs) : cur.lockedUntil;
    return { failedLogins, lockedUntil: locked ? cur.lockedUntil : null };
  }

  async recordLoginSuccess(id: string, now: Date): Promise<void> {
    const cur = this.users.get(id);
    if (cur) Object.assign(cur, { failedLogins: 0, lockedUntil: null, lastLoginAt: now });
  }

  async setRole(id: string, role: Role): Promise<void> {
    const cur = this.users.get(id);
    if (cur) cur.role = role;
  }

  async countByRole(role: Role): Promise<number> {
    return [...this.users.values()].filter((u) => u.role === role).length;
  }

  async list(opts: UserListOptions) {
    const q = opts.query?.trim() ?? '';
    const key = q ? nicknameKey(q) : '';
    const all = [...this.users.values()]
      .filter(
        (u) =>
          (!opts.role || u.role === opts.role) &&
          (!q ||
            u.id === q ||
            (key !== '' && u.nicknameKey.includes(key)) ||
            (u.email?.includes(q.toLowerCase()) ?? false)),
      )
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime() || (a.id < b.id ? -1 : 1));
    return {
      items: all
        .slice((opts.page - 1) * opts.pageSize, opts.page * opts.pageSize)
        .map((u) => ({ ...u })),
      total: all.length,
    };
  }

  async stats(now: Date): Promise<UserStats> {
    const all = [...this.users.values()];
    const since = (ms: number) =>
      all.filter((u) => u.createdAt.getTime() >= now.getTime() - ms).length;
    return {
      total: all.length,
      guests: all.filter((u) => u.isGuest).length,
      bots: all.filter((u) => u.isBot).length,
      banned: all.filter((u) => u.bannedUntil && u.bannedUntil > now).length,
      muted: all.filter((u) => u.mutedUntil && u.mutedUntil > now).length,
      new24h: since(86_400_000),
      new7d: since(7 * 86_400_000),
    };
  }

  private copy(u: UserRecord | undefined): UserRecord | null {
    return u ? { ...u } : null;
  }
}

export class MemorySessionRepository implements SessionRepository {
  readonly sessions = new Map<string, SessionRecord>();

  async create(s: NewSession): Promise<SessionRecord> {
    const rec: SessionRecord = {
      id: randomUUID(),
      userId: s.userId,
      family: s.family,
      tokenHash: s.tokenHash,
      expiresAt: s.expiresAt,
      createdAt: s.createdAt,
      revokedAt: null,
    };
    this.sessions.set(rec.id, rec);
    return { ...rec };
  }

  async findByHash(tokenHash: string): Promise<SessionRecord | null> {
    const s = [...this.sessions.values()].find((x) => x.tokenHash === tokenHash);
    return s ? { ...s } : null;
  }

  async revokeIfActive(id: string, now: Date): Promise<boolean> {
    const s = this.sessions.get(id);
    if (!s || s.revokedAt) return false;
    s.revokedAt = now;
    return true;
  }

  async revokeFamily(family: string, now: Date): Promise<void> {
    for (const s of this.sessions.values())
      if (s.family === family && !s.revokedAt) s.revokedAt = now;
  }

  async revokeAllForUser(userId: string, now: Date): Promise<void> {
    for (const s of this.sessions.values())
      if (s.userId === userId && !s.revokedAt) s.revokedAt = now;
  }

  async countActiveUsers(since: Date): Promise<number> {
    return new Set(
      [...this.sessions.values()].filter((s) => s.createdAt >= since).map((s) => s.userId),
    ).size;
  }

  async deleteExpired(before: Date): Promise<number> {
    let n = 0;
    for (const [id, s] of this.sessions) {
      if (s.expiresAt < before) {
        this.sessions.delete(id);
        n++;
      }
    }
    return n;
  }
}

export class MemorySecurityLogRepository implements SecurityLogRepository {
  readonly events: SecurityEvent[] = [];

  async add(event: SecurityEvent): Promise<void> {
    this.events.push(event);
  }

  async list(filter: { kind?: string; userId?: string }): Promise<SecurityEvent[]> {
    return this.events.filter(
      (e) =>
        (filter.kind === undefined || e.kind === filter.kind) &&
        (filter.userId === undefined || e.userId === filter.userId),
    );
  }

  async page(filter: { kind?: string; userId?: string }, page: number, pageSize: number) {
    const all = (await this.list(filter)).sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime(),
    );
    return { items: all.slice((page - 1) * pageSize, page * pageSize), total: all.length };
  }

  async count(filter: {
    kind: string;
    since: Date;
    ip?: string;
    userId?: string;
  }): Promise<number> {
    return this.events.filter(
      (e) =>
        e.kind === filter.kind &&
        e.createdAt >= filter.since &&
        (filter.ip === undefined || e.ip === filter.ip) &&
        (filter.userId === undefined || e.userId === filter.userId),
    ).length;
  }
}

export function createMemoryRepositories(): Repositories & {
  users: MemoryUserRepository;
  sessions: MemorySessionRepository;
  security: MemorySecurityLogRepository;
  castles: MemoryCastleRepository;
} {
  const users = new MemoryUserRepository();
  return {
    users,
    sessions: new MemorySessionRepository(),
    security: new MemorySecurityLogRepository(),
    castles: new MemoryCastleRepository(users),
  };
}

/** Prisma игнорирует undefined в update — повторяем это поведение. */
function definedOnly<T extends object>(o: T): Partial<T> {
  return Object.fromEntries(Object.entries(o).filter(([, v]) => v !== undefined)) as Partial<T>;
}
