import { randomInt, randomUUID } from 'node:crypto';
import {
  DEFAULT_CRESTS,
  MAIN_WORLD_ID,
  NEWBIE_SHIELD_HOURS,
  isPremiumCrest,
  START_BUILDINGS,
  START_GEMS,
  START_RESOURCES,
  nicknameKey,
  type Locale,
  type Role,
  type UserDto,
  type UpdateProfileBody,
} from '@tc/shared';
import type { Clock } from '../../lib/clock';
import { Errors } from '../../lib/errors';
import { hashPassword as defaultHash, verifyPassword as defaultVerify } from '../../lib/password';
import { randomToken, sha256, type AccessTokenService } from '../../lib/tokens';
import { UniqueViolation, type NewCastle, type Repositories, type UserRecord } from './auth.types';

/** Пять неверных паролей подряд — вход в аккаунт закрыт на 15 минут. */
export const MAX_FAILED_LOGINS = 5;
export const LOGIN_LOCK_MS = 15 * 60 * 1000;
/** Ник можно менять раз в сутки (первая смена свободна). */
export const NICKNAME_COOLDOWN_MS = 24 * 60 * 60 * 1000;
/**
 * Две вкладки могут одновременно обновить сессию одним токеном. Повтор в течение этого окна
 * считаем гонкой, а не кражей: просто отказываем, не трогая цепочку.
 */
export const REFRESH_REUSE_GRACE_MS = 10_000;

const GUEST_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const GUEST_PREFIX: Record<Locale, string> = { ru: 'Гость', uk: 'Гість', en: 'Guest' };

export interface RequestContext {
  ip?: string | undefined;
  userAgent?: string | undefined;
}

export interface IssuedSession {
  user: UserRecord;
  accessToken: string;
  expiresIn: number;
  /** Отдаётся браузеру только в httpOnly-cookie. */
  refreshToken: string;
}

export interface PasswordHasher {
  hash(password: string): Promise<string>;
  verify(hash: string, password: string): Promise<boolean>;
}

export const argonHasher: PasswordHasher = { hash: defaultHash, verify: defaultVerify };

export interface AuthServiceDeps {
  repos: Repositories;
  tokens: AccessTokenService;
  clock: Clock;
  refreshTtlDays: number;
  ownerEmail: string;
  hasher?: PasswordHasher;
  worldId?: string;
  /** Куплен ли премиум-герб (магазин). Без функции премиум-гербы недоступны. */
  crestOwned?: (userId: string, crest: string) => Promise<boolean>;
}

/**
 * OWNER действует только если email аккаунта совпадает с OWNER_EMAIL из окружения (D-19):
 * даже если роль в БД подменили, без совпадения с окружением она превращается в PLAYER.
 * ADMIN/PLAYER возвращаются как есть.
 */
export function effectiveRole(user: Pick<UserRecord, 'role' | 'email'>, ownerEmail: string): Role {
  if (user.role !== 'OWNER') return user.role;
  return ownerEmail !== '' && user.email === ownerEmail ? 'OWNER' : 'PLAYER';
}

export function toUserDto(user: UserRecord, ownerEmail: string): UserDto {
  return {
    id: user.id,
    nickname: user.nickname,
    role: effectiveRole(user, ownerEmail),
    isGuest: user.isGuest,
    email: user.email,
    language: user.language,
    crest: user.crest,
    createdAt: user.createdAt.toISOString(),
  };
}

export class AuthService {
  private readonly hasher: PasswordHasher;
  private readonly worldId: string;
  private dummyHash: string | undefined;

  constructor(private readonly deps: AuthServiceDeps) {
    this.hasher = deps.hasher ?? argonHasher;
    this.worldId = deps.worldId ?? MAIN_WORLD_ID;
  }

  async register(
    input: { email: string; password: string; nickname: string; language?: Locale | undefined },
    ctx: RequestContext,
  ): Promise<IssuedSession> {
    const now = this.deps.clock.now();
    const passwordHash = await this.hasher.hash(input.password);
    const user = await this.createAccount(
      {
        email: input.email,
        passwordHash,
        nickname: input.nickname,
        isGuest: false,
        language: input.language ?? 'ru',
      },
      now,
    );
    return this.issueSession(user, ctx);
  }

  async createGuest(language: Locale, ctx: RequestContext): Promise<IssuedSession> {
    const now = this.deps.clock.now();
    // Ник случайный; при редком совпадении пробуем другой
    for (let attempt = 0; attempt < 5; attempt++) {
      const nickname = `${GUEST_PREFIX[language]}-${randomSuffix(5)}`;
      try {
        const user = await this.createAccount(
          { email: null, passwordHash: null, nickname, isGuest: true, language },
          now,
        );
        return await this.issueSession(user, ctx);
      } catch (err) {
        if (!(err instanceof UniqueViolation) || attempt === 4) throw err;
      }
    }
    throw Errors.conflict(); // недостижимо: цикл выше либо вернул, либо бросил
  }

  async login(
    input: { email: string; password: string },
    ctx: RequestContext,
  ): Promise<IssuedSession> {
    const now = this.deps.clock.now();
    const { users, security } = this.deps.repos;
    const user = await users.findByEmail(input.email);

    if (!user || !user.passwordHash) {
      // Тратим то же время на хеширование, чтобы ответ не выдавал, есть ли такой email
      await this.hasher.verify(await this.getDummyHash(), input.password);
      throw Errors.invalidCredentials();
    }
    if (user.lockedUntil && user.lockedUntil > now) {
      throw Errors.locked(Math.ceil((user.lockedUntil.getTime() - now.getTime()) / 1000));
    }

    const ok = await this.hasher.verify(user.passwordHash, input.password);
    if (!ok) {
      const res = await users.recordLoginFailure(user.id, now, {
        maxFailures: MAX_FAILED_LOGINS,
        lockMs: LOGIN_LOCK_MS,
      });
      if (res.lockedUntil) {
        await security.add({
          userId: user.id,
          kind: 'login_locked',
          ip: ctx.ip,
          details: { until: res.lockedUntil.toISOString() },
          createdAt: now,
        });
      }
      throw Errors.invalidCredentials();
    }
    this.assertNotBanned(user, now);
    await users.recordLoginSuccess(user.id, now);
    return this.issueSession({ ...user, lastLoginAt: now }, ctx);
  }

  /**
   * Ротация refresh-токена. Старый отзывается, выдаётся новый в той же цепочке.
   * Повторное использование уже отозванного токена — признак кражи: отзываем всю цепочку.
   */
  async refresh(rawToken: string, ctx: RequestContext): Promise<IssuedSession> {
    const now = this.deps.clock.now();
    const { sessions, users, security } = this.deps.repos;
    const session = await sessions.findByHash(sha256(rawToken));
    if (!session) throw Errors.unauthorized();

    if (session.revokedAt) {
      if (now.getTime() - session.revokedAt.getTime() > REFRESH_REUSE_GRACE_MS) {
        await sessions.revokeFamily(session.family, now);
        await security.add({
          userId: session.userId,
          kind: 'refresh_reuse',
          ip: ctx.ip,
          createdAt: now,
        });
      }
      throw Errors.unauthorized();
    }
    if (session.expiresAt <= now) throw Errors.unauthorized();

    const user = await users.findById(session.userId);
    if (!user) throw Errors.unauthorized();
    if (this.isBanned(user, now)) {
      await sessions.revokeFamily(session.family, now);
      throw Errors.banned({ until: user.bannedUntil?.toISOString(), reason: user.banReason });
    }
    // Если параллельный запрос уже забрал этот токен — проигрываем гонку
    if (!(await sessions.revokeIfActive(session.id, now))) throw Errors.unauthorized();
    return this.issueSession(user, ctx, session.family);
  }

  /** Выход: отзывает токен этого устройства. Неизвестный токен — не ошибка (идемпотентно). */
  async logout(rawToken: string | undefined): Promise<void> {
    if (!rawToken) return;
    const session = await this.deps.repos.sessions.findByHash(sha256(rawToken));
    if (session) await this.deps.repos.sessions.revokeFamily(session.family, this.deps.clock.now());
  }

  async logoutAll(userId: string): Promise<void> {
    await this.deps.repos.sessions.revokeAllForUser(userId, this.deps.clock.now());
  }

  /** Гость привязывает email и пароль — аккаунт и замок сохраняются. */
  async upgradeGuest(
    userId: string,
    input: { email: string; password: string },
  ): Promise<UserRecord> {
    const user = await this.requireUser(userId);
    if (!user.isGuest) throw Errors.conflict('Account is not a guest');
    const passwordHash = await this.hasher.hash(input.password);
    try {
      return await this.deps.repos.users.update(userId, {
        email: input.email,
        passwordHash,
        isGuest: false,
      });
    } catch (err) {
      throw mapUnique(err);
    }
  }

  async updateProfile(userId: string, patch: UpdateProfileBody): Promise<UserRecord> {
    const user = await this.requireUser(userId);
    const now = this.deps.clock.now();
    const data: Parameters<Repositories['users']['update']>[1] = {};

    if (patch.nickname !== undefined && patch.nickname !== user.nickname) {
      const key = nicknameKey(patch.nickname);
      // Смена только регистра или разделителей — не «новый ник», кулдаун не нужен
      if (key !== user.nicknameKey && user.nicknameChangedAt) {
        const waitMs = user.nicknameChangedAt.getTime() + NICKNAME_COOLDOWN_MS - now.getTime();
        if (waitMs > 0) {
          throw Errors.requirementNotMet({
            reason: 'nickname_cooldown',
            retryAfterSeconds: Math.ceil(waitMs / 1000),
          });
        }
      }
      data.nickname = patch.nickname;
      data.nicknameKey = key;
      if (key !== user.nicknameKey) data.nicknameChangedAt = now;
    }
    if (patch.crest !== undefined) {
      if (isPremiumCrest(patch.crest) && !(await this.deps.crestOwned?.(userId, patch.crest)))
        throw Errors.requirementNotMet({ reason: 'crest_not_owned' });
      data.crest = patch.crest;
    }
    if (patch.language !== undefined) data.language = patch.language;

    try {
      return await this.deps.repos.users.update(userId, data);
    } catch (err) {
      throw mapUnique(err);
    }
  }

  async requireUser(userId: string): Promise<UserRecord> {
    const user = await this.deps.repos.users.findById(userId);
    if (!user) throw Errors.unauthorized();
    return user;
  }

  isBanned(user: UserRecord, now: Date): boolean {
    return user.bannedUntil !== null && user.bannedUntil > now;
  }

  // ── внутреннее ────────────────────────────────────────────────────────────

  private assertNotBanned(user: UserRecord, now: Date): void {
    if (this.isBanned(user, now)) {
      throw Errors.banned({ until: user.bannedUntil?.toISOString(), reason: user.banReason });
    }
  }

  private async getDummyHash(): Promise<string> {
    this.dummyHash ??= await this.hasher.hash(randomToken(12));
    return this.dummyHash;
  }

  private async createAccount(
    input: {
      email: string | null;
      passwordHash: string | null;
      nickname: string;
      isGuest: boolean;
      language: Locale;
    },
    now: Date,
  ): Promise<UserRecord> {
    const castle: NewCastle = {
      worldId: this.worldId,
      resources: { ...START_RESOURCES },
      gems: START_GEMS,
      buildings: START_BUILDINGS,
      resourcesUpdatedAt: now,
      shieldUntil: new Date(now.getTime() + NEWBIE_SHIELD_HOURS * 3600_000),
    };
    try {
      return await this.deps.repos.users.createWithCastle(
        {
          email: input.email,
          passwordHash: input.passwordHash,
          nickname: input.nickname,
          nicknameKey: nicknameKey(input.nickname),
          isGuest: input.isGuest,
          language: input.language,
          crest: DEFAULT_CRESTS[0],
          createdAt: now,
        },
        castle,
      );
    } catch (err) {
      // Для гостя UniqueViolation пробрасываем как есть: createGuest повторит попытку
      if (input.isGuest) throw err;
      throw mapUnique(err);
    }
  }

  private async issueSession(
    user: UserRecord,
    ctx: RequestContext,
    family: string = randomUUID(),
  ): Promise<IssuedSession> {
    const now = this.deps.clock.now();
    const refreshToken = randomToken();
    await this.deps.repos.sessions.create({
      userId: user.id,
      family,
      tokenHash: sha256(refreshToken),
      expiresAt: new Date(now.getTime() + this.deps.refreshTtlDays * 86_400_000),
      createdAt: now,
      userAgent: ctx.userAgent,
      ip: ctx.ip,
    });
    const accessToken = await this.deps.tokens.sign(
      { userId: user.id, role: effectiveRole(user, this.deps.ownerEmail) },
      now,
    );
    return { user, accessToken, expiresIn: this.deps.tokens.ttl, refreshToken };
  }
}

function mapUnique(err: unknown): unknown {
  if (err instanceof UniqueViolation) {
    return err.field === 'email' ? Errors.emailTaken() : Errors.nicknameTaken();
  }
  return err;
}

function randomSuffix(length: number): string {
  return Array.from({ length }, () => GUEST_ALPHABET[randomInt(GUEST_ALPHABET.length)]).join('');
}
