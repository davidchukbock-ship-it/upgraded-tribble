import { z } from 'zod';
import {
  BUILDING_KEYS,
  MARCH_TYPES,
  EQUIP_SLOTS,
  SKILL_KEYS,
  STRUCTURE_KINDS,
  TECH_KEYS,
  UNIT_TYPES,
} from '@tc/shared';

export const resourceMap = z.object({
  gold: z.number(),
  wood: z.number(),
  stone: z.number(),
  food: z.number(),
});
export const buildingKey = z.enum(BUILDING_KEYS);
export const techKey = z.enum(TECH_KEYS);
export const skillKey = z.enum(SKILL_KEYS);
export const unitType = z.enum(UNIT_TYPES);
export const unitTier = z.union([
  z.literal(1),
  z.literal(2),
  z.literal(3),
  z.literal(4),
  z.literal(5),
]);

const unitIdSchema = z.string().regex(/^(infantry|archer|cavalry|siege)_[1-5]$/);
const isoDate = z.string();

const trainTask = z.object({
  id: z.string(),
  unit: unitIdSchema,
  count: z.number(),
  startedAt: isoDate,
  finishesAt: isoDate,
  speedupGems: z.number().nullable(),
  refund: resourceMap,
});

const researchTask = z.object({
  id: z.string(),
  tech: techKey,
  toLevel: z.number(),
  startedAt: isoDate,
  finishesAt: isoDate,
  speedupGems: z.number().nullable(),
  refund: resourceMap,
});

export const armySchema = z.object({
  units: z.array(z.object({ id: unitIdSchema, count: z.number(), wounded: z.number() })),
  count: z.number(),
  queued: z.number(),
  cap: z.number(),
  upkeepPerHour: z.number(),
  maxTier: z.number(),
  queue: z.array(trainTask),
  queueMax: z.number(),
  marching: z.number(),
  woundedRoom: z.number(),
});

export const researchSchema = z.object({
  academyLevel: z.number(),
  queueMax: z.number(),
  techs: z.array(
    z.object({
      key: techKey,
      branch: z.enum(['economy', 'military', 'defense']),
      level: z.number(),
      nextLevel: z.number().nullable(),
      cost: resourceMap.nullable(),
      seconds: z.number().nullable(),
      academyRequired: z.number().nullable(),
      blocked: z.enum(['max_level', 'academy_level', 'in_progress']).nullable(),
    }),
  ),
  queue: z.array(researchTask),
});

export const heroSchema = z.object({
  level: z.number(),
  maxLevel: z.number(),
  xp: z.number(),
  xpToNext: z.number(),
  skillPoints: z.number(),
  skills: z.object({ combat: z.number(), defense: z.number(), economy: z.number() }),
  maxSkill: z.number(),
  items: z.array(
    z.object({
      id: z.string(),
      slot: z.enum(EQUIP_SLOTS),
      rarity: z.union([z.literal(1), z.literal(2), z.literal(3), z.literal(4), z.literal(5)]),
      equipped: z.boolean(),
    }),
  ),
  bonuses: z.object({ attack: z.number(), defense: z.number(), production: z.number() }),
  train: z.object({ cost: resourceMap, xp: z.number() }),
});

export const unitCounts = z.record(z.string(), z.number());

export const marchSchema = z.object({
  id: z.string(),
  type: z.enum(MARCH_TYPES),
  target: z.object({ x: z.number(), y: z.number() }),
  targetName: z.string().nullable(),
  units: unitCounts,
  loot: resourceMap,
  state: z.enum(['outbound', 'returning']),
  startedAt: isoDate,
  arriveAt: isoDate,
  returnAt: isoDate,
  reportId: z.string().nullable(),
});

export const castleSchema = z.object({
  serverTime: z.string(),
  worldSpeed: z.number(),
  resources: resourceMap,
  caps: resourceMap,
  ratesPerHour: resourceMap,
  gems: z.number(),
  shieldUntil: z.string().nullable(),
  slots: z.object({
    total: z.number(),
    used: z.number(),
    extraUnlocked: z.boolean(),
    canUnlock: z.boolean(),
    unlockCostGems: z.number(),
  }),
  buildings: z.array(
    z.object({
      key: buildingKey,
      level: z.number(),
      nextLevel: z.number().nullable(),
      cost: resourceMap.nullable(),
      seconds: z.number().nullable(),
      blocked: z.enum(['max_level', 'castle_level', 'in_progress', 'requires']).nullable(),
      missing: z.array(
        z.discriminatedUnion('kind', [
          z.object({ kind: z.literal('territory'), level: z.number() }),
          z.object({ kind: z.literal('castle'), level: z.number() }),
          z.object({ kind: z.literal('building'), key: buildingKey, level: z.number() }),
        ]),
      ),
    }),
  ),
  tasks: z.array(
    z.object({
      id: z.string(),
      key: buildingKey,
      toLevel: z.number(),
      startedAt: isoDate,
      finishesAt: isoDate,
      speedupGems: z.number(),
      refund: resourceMap,
    }),
  ),
  army: armySchema,
  research: researchSchema,
  hero: heroSchema,
  position: z.object({ x: z.number(), y: z.number() }).nullable(),
  marches: z.array(marchSchema),
  marchesMax: z.number(),
  power: z.number(),
  city: z.object({
    structures: z.array(
      z.object({ id: z.string(), kind: z.enum(STRUCTURE_KINDS), x: z.number(), y: z.number() }),
    ),
    catalog: z.array(
      z.object({
        kind: z.enum(STRUCTURE_KINDS),
        owned: z.number(),
        max: z.number(),
        cost: resourceMap,
        bonus: z.number(),
        castleRequired: z.number(),
        blocked: z.enum(['castle_level', 'limit']).nullable(),
      }),
    ),
    prosperity: z.number(),
    cap: z.number(),
  }),
});

export const structureBody = z.object({
  kind: z.enum(STRUCTURE_KINDS),
  x: z.number().int().min(-4).max(64),
  y: z.number().int().min(-4).max(64),
});

export const errorSchema = z.object({
  error: z.object({ code: z.string(), message: z.string(), details: z.unknown().optional() }),
  requestId: z.string(),
});

/** Ключ идемпотентности обязателен для всех POST, которые тратят ресурсы (D-06). */
export const idempotencyHeaders = z.object({
  'idempotency-key': z
    .string()
    .regex(/^[\w-]{8,64}$/, 'Idempotency-Key: 8–64 символа [A-Za-z0-9_-]'),
});

export const failures = { 401: errorSchema, 404: errorSchema, 409: errorSchema, 422: errorSchema };
