import {
  ALL_UNIT_IDS,
  BUILDING_KEYS,
  cityDto,
  prosperity,
  EXTRA_SLOT_GEMS,
  MAIN_WORLD_ID,
  MAX_MARCHES,
  addHeroXp,
  hospitalCapacity,
  MAX_HERO_LEVEL,
  MAX_SKILL_LEVEL,
  MAX_TRAIN_QUEUE,
  RESEARCH_QUEUE_MAX,
  TECHS,
  TECH_KEYS,
  academyLevelFor,
  armyCap,
  armyCount,
  buildSeconds,
  buildSlots,
  buildingCost,
  cancelRefund,
  castlePower,
  heroBonuses,
  heroSkillPoints,
  heroTrainCost,
  heroXpToNext,
  HERO_TRAIN_XP,
  maxBuildingLevel,
  maxLevelFor,
  mageHeroXpBonus,
  mageResearchBonus,
  missingRequirements,
  maxTierFor,
  netRates,
  newHero,
  parseUnitId,
  settleCastle,
  speedupGems,
  techCost,
  techEffects,
  techSeconds,
  upkeepPerHour,
  warehouseCap,
  MAX_TECH_LEVEL,
  type ArmyDto,
  type MarchDto,
  type UnitCounts,
  type BuildingDto,
  type CastleDto,
  type HeroDto,
  type HeroState,
  type ResearchDto,
  type TechBlock,
  type UpgradeBlock,
  type ResourceAmounts,
} from '@tc/shared';
import type { CastleAggregate, MarchRecord } from './castle.types';

/** Что завершилось при расчёте: из этого получаются уведомления (D-42). */
export interface SettleEvent {
  kind: 'build.done' | 'train.done' | 'research.done' | 'march.returned';
  payload: Record<string, string | number | boolean | null>;
  at: Date;
}

export { MAIN_WORLD_ID };

/**
 * Стартовый герой: первый уровень, одно очко навыка, сумка пуста — предметы приходят из сундуков (этап 7).
 * Без стартовых бонусов: ставки первого часа игры остаются такими, как в описании (300/400/350/400).
 */
export const starterHero = (): HeroState => newHero();

/** Мощь замка: войска (в строю, раненые и в походах), здания, технологии и герой. */
export function aggregatePower(agg: CastleAggregate): number {
  const marching: Record<string, number> = {};
  for (const m of agg.marches) {
    for (const [id, n] of Object.entries(m.units)) marching[id] = (marching[id] ?? 0) + (n ?? 0);
    for (const [id, n] of Object.entries(m.wounded)) marching[id] = (marching[id] ?? 0) + (n ?? 0);
  }
  return castlePower({
    army: agg.army,
    marching,
    levels: agg.levels,
    tech: agg.tech,
    heroLevel: agg.hero?.level ?? 1,
  });
}

export const castleLevel = (a: Pick<CastleAggregate, 'levels'>): number => a.levels.castle ?? 1;
export const barracksLevel = (a: Pick<CastleAggregate, 'levels'>): number => a.levels.barracks ?? 0;

/**
 * Прибавка к производству: навык и реликвия героя + процветание города (постройки, D-66).
 * Обе идут одним числом во все расчёты производства, поэтому постройки учитываются везде одинаково.
 */
export const heroProduction = (a: Pick<CastleAggregate, 'hero' | 'structures'>): number =>
  (a.hero ? heroBonuses(a.hero).production : 0) + prosperity(a.structures);

/**
 * Приводит замок к моменту now: достраивает здания, выпускает войска, завершает исследования,
 * копит ресурсы с учётом содержания армии. Возвращает копию — исходный агрегат остаётся «образом БД»
 * (для проверки версии и diff при сохранении). `changed` — что-то завершилось и это нужно записать.
 */
function settleBase(
  agg: CastleAggregate,
  now: Date,
): { draft: CastleAggregate; changed: boolean; events: SettleEvent[] } {
  const res = settleCastle(
    {
      resources: agg.resources,
      updatedAtMs: agg.resourcesUpdatedAt.getTime(),
      levels: agg.levels,
      tasks: agg.tasks.map((t) => ({
        id: t.id,
        key: t.key,
        toLevel: t.toLevel,
        finishesAtMs: t.finishesAt.getTime(),
      })),
      worldSpeed: agg.worldSpeed,
      army: agg.army,
      trains: agg.trains.map((t) => ({
        id: t.id,
        unit: t.unit,
        count: t.count,
        finishesAtMs: t.finishesAt.getTime(),
      })),
      tech: agg.tech,
      research: agg.research.map((t) => ({
        id: t.id,
        tech: t.tech,
        toLevel: t.toLevel,
        finishesAtMs: t.finishesAt.getTime(),
      })),
      heroProduction: heroProduction(agg),
      gems: agg.gems,
      gemsCarry: agg.gemsCarry,
    },
    now.getTime(),
  );
  const keep = <T extends { id: string }>(
    list: readonly T[],
    pending: ReadonlyArray<{ id: string }>,
  ): T[] => {
    const ids = new Set(pending.map((p) => p.id));
    return list.filter((t) => ids.has(t.id)).map((t) => structuredClone(t));
  };
  const draft: CastleAggregate = structuredClone(agg);
  draft.resources = res.resources;
  draft.gems = res.gems;
  draft.gemsCarry = res.gemsCarry;
  draft.levels = res.levels;
  draft.army = res.army;
  draft.tech = res.tech;
  draft.resourcesUpdatedAt = new Date(res.updatedAtMs);
  draft.tasks = keep(agg.tasks, res.pending);
  draft.trains = keep(agg.trains, res.pendingTrains);
  draft.research = keep(agg.research, res.pendingResearch);
  const changed =
    res.completed.length + res.completedTrains.length + res.completedResearch.length > 0;
  const events: SettleEvent[] = [
    ...res.completed.map((t) => ({
      kind: 'build.done' as const,
      payload: { building: t.key, level: t.toLevel },
      at: new Date(t.finishesAtMs),
    })),
    ...res.completedTrains.map((t) => ({
      kind: 'train.done' as const,
      payload: { unit: t.unit, count: t.count },
      at: new Date(t.finishesAtMs),
    })),
    ...res.completedResearch.map((t) => ({
      kind: 'research.done' as const,
      payload: { tech: t.tech, level: t.toLevel },
      at: new Date(t.finishesAtMs),
    })),
  ];
  return { draft, changed, events };
}

const sumUnits = (u: UnitCounts): number => Object.values(u).reduce((s, n) => s + (n ?? 0), 0);

/** Сколько юнитов сейчас в походах (входят в лимит армии, не едят и не защищают замок). */
export const marchingCount = (agg: Pick<CastleAggregate, 'marches'>): number =>
  agg.marches.reduce((s, m) => s + sumUnits(m.units) + sumUnits(m.wounded), 0);

/** Раненые: в госпитале и те, что возвращаются из походов. */
export const woundedTotal = (agg: Pick<CastleAggregate, 'army' | 'marches'>): number =>
  Object.values(agg.army).reduce((s, u) => s + (u?.wounded ?? 0), 0) +
  agg.marches.reduce((s, m) => s + sumUnits(m.wounded), 0);

export const woundedRoom = (agg: CastleAggregate): number =>
  Math.max(
    0,
    hospitalCapacity(agg.levels.hospital ?? 0, techEffects(agg.tech).woundedCapacity) -
      woundedTotal(agg),
  );

/** Возвращение отряда: живые — в строй, раненые — в госпиталь, добыча — на склад, опыт — герою. */
function applyReturn(draft: CastleAggregate, m: MarchRecord): void {
  for (const [id, n] of Object.entries(m.units)) {
    if (!n) continue;
    const cur = draft.army[id as keyof typeof draft.army] ?? { count: 0, wounded: 0 };
    draft.army[id as keyof typeof draft.army] = { ...cur, count: cur.count + n };
  }
  for (const [id, n] of Object.entries(m.wounded)) {
    if (!n) continue;
    const cur = draft.army[id as keyof typeof draft.army] ?? { count: 0, wounded: 0 };
    draft.army[id as keyof typeof draft.army] = { ...cur, wounded: cur.wounded + n };
  }
  for (const r of ['gold', 'wood', 'stone', 'food'] as const)
    draft.resources = { ...draft.resources, [r]: draft.resources[r] + m.loot[r] };
  if (draft.hero && m.heroXp > 0) {
    const up = addHeroXp(
      draft.hero.level,
      draft.hero.xp,
      Math.round(m.heroXp * (1 + mageHeroXpBonus(draft.levels.magetower ?? 0))),
    );
    draft.hero = { ...draft.hero, level: up.level, xp: up.xp };
  }
}

/**
 * Приводит замок к моменту now. Вернувшиеся из походов отряды применяются в момент возвращения:
 * расчёт идёт кусками между возвращениями, поэтому результат не зависит от частоты запросов (D-03).
 */
export function settleAggregate(
  agg: CastleAggregate,
  now: Date,
): { draft: CastleAggregate; changed: boolean; events: SettleEvent[] } {
  const due = agg.marches
    .filter((m) => m.state === 'returning' && m.returnAt.getTime() <= now.getTime())
    .sort((a, b) => a.returnAt.getTime() - b.returnAt.getTime());
  let current = agg;
  let changed = false;
  const events: SettleEvent[] = [];
  for (const m of due) {
    const at = new Date(Math.max(m.returnAt.getTime(), current.resourcesUpdatedAt.getTime()));
    const step = settleBase(current, at);
    changed ||= step.changed;
    events.push(...step.events);
    applyReturn(step.draft, m);
    events.push({
      kind: 'march.returned',
      payload: {
        march: m.type,
        x: m.target.x,
        y: m.target.y,
        units: sumUnits(m.units) + sumUnits(m.wounded),
        loot: m.loot.gold + m.loot.wood + m.loot.stone + m.loot.food,
        reportId: m.reportId,
      },
      at: m.returnAt,
    });
    step.draft.marches = step.draft.marches.filter((x) => x.id !== m.id);
    current = step.draft;
    changed = true;
  }
  const last = settleBase(current, now);
  events.push(...last.events);
  return { draft: last.draft, changed: changed || last.changed, events };
}

/**
 * Пересчитывает цепочку задач после удаления или завершения одной из них: следующая начинается,
 * когда закончилась предыдущая (но не раньше now), длительность каждой сохраняется.
 */
export function rechain<T extends { startedAt: Date; finishesAt: Date }>(
  tasks: T[],
  now: Date,
): void {
  tasks.sort((a, b) => a.finishesAt.getTime() - b.finishesAt.getTime());
  let prevFinish: number | null = null;
  for (const t of tasks) {
    const duration = t.finishesAt.getTime() - t.startedAt.getTime();
    const start: number =
      prevFinish === null ? Math.min(t.startedAt.getTime(), now.getTime()) : prevFinish;
    t.startedAt = new Date(start);
    t.finishesAt = new Date(start + duration);
    prevFinish = t.finishesAt.getTime();
  }
}

/** Когда освободится цепочка (для постановки следующей задачи). */
export const chainEnd = (tasks: ReadonlyArray<{ finishesAt: Date }>, now: Date): Date =>
  new Date(Math.max(now.getTime(), ...tasks.map((t) => t.finishesAt.getTime())));

const remainingSeconds = (finishesAt: Date, now: Date): number =>
  Math.max(0, Math.ceil((finishesAt.getTime() - now.getTime()) / 1000));

// ── DTO ────────────────────────────────────────────────────────────────────────

function armyDto(agg: CastleAggregate, now: Date): ArmyDto {
  const barracks = barracksLevel(agg);
  const queued = agg.trains.reduce((s, t) => s + t.count, 0);
  const sorted = [...agg.trains].sort((a, b) => a.finishesAt.getTime() - b.finishesAt.getTime());
  return {
    units: ALL_UNIT_IDS.filter((id) => agg.army[id]).map((id) => ({
      id,
      count: agg.army[id]?.count ?? 0,
      wounded: agg.army[id]?.wounded ?? 0,
    })),
    count: armyCount(agg.army),
    queued,
    cap: armyCap(barracks),
    marching: marchingCount(agg),
    woundedRoom: woundedRoom(agg),
    upkeepPerHour: upkeepPerHour(agg.army),
    maxTier: maxTierFor(barracks),
    queueMax: MAX_TRAIN_QUEUE,
    queue: sorted.map((t, i) => ({
      id: t.id,
      unit: t.unit,
      count: t.count,
      startedAt: t.startedAt.toISOString(),
      finishesAt: t.finishesAt.toISOString(),
      speedupGems: i === 0 ? speedupGems(remainingSeconds(t.finishesAt, now)) : null,
      refund: cancelRefund(t.paid),
    })),
  };
}

function researchDto(agg: CastleAggregate, now: Date): ResearchDto {
  const academy = agg.levels.academy ?? 0;
  const inQueue = new Set(agg.research.map((t) => t.tech));
  const sorted = [...agg.research].sort((a, b) => a.finishesAt.getTime() - b.finishesAt.getTime());
  return {
    academyLevel: academy,
    queueMax: RESEARCH_QUEUE_MAX,
    techs: TECH_KEYS.map((key) => {
      const level = agg.tech[key] ?? 0;
      const next = level < MAX_TECH_LEVEL ? level + 1 : null;
      let blocked: TechBlock | null = null;
      if (inQueue.has(key)) blocked = 'in_progress';
      else if (next === null) blocked = 'max_level';
      else if (academy < academyLevelFor(next)) blocked = 'academy_level';
      return {
        key,
        branch: TECHS[key].branch,
        level,
        nextLevel: next,
        cost: next ? techCost(key, next) : null,
        seconds: next
          ? techSeconds(key, next, agg.worldSpeed, mageResearchBonus(agg.levels.magetower ?? 0))
          : null,
        academyRequired: next ? academyLevelFor(next) : null,
        blocked,
      };
    }),
    queue: sorted.map((t, i) => ({
      id: t.id,
      tech: t.tech,
      toLevel: t.toLevel,
      startedAt: t.startedAt.toISOString(),
      finishesAt: t.finishesAt.toISOString(),
      speedupGems: i === 0 ? speedupGems(remainingSeconds(t.finishesAt, now)) : null,
      refund: cancelRefund(t.paid),
    })),
  };
}

function heroDto(hero: HeroState): HeroDto {
  return {
    level: hero.level,
    maxLevel: MAX_HERO_LEVEL,
    xp: hero.xp,
    xpToNext: hero.level >= MAX_HERO_LEVEL ? 0 : heroXpToNext(hero.level),
    skillPoints: heroSkillPoints(hero),
    skills: { ...hero.skills },
    maxSkill: MAX_SKILL_LEVEL,
    items: hero.items.map((i) => ({ ...i })),
    bonuses: heroBonuses(hero),
    train: { cost: heroTrainCost(hero.level) as ResourceAmounts, xp: HERO_TRAIN_XP },
  };
}

export function toCastleDto(agg: CastleAggregate, now: Date): CastleDto {
  const cLevel = castleLevel(agg);
  const mods = techEffects(agg.tech);
  const cap = warehouseCap(agg.levels.warehouse ?? 1, { warehouse: mods.warehouse });
  const inProgress = new Set(agg.tasks.map((t) => t.key));
  const total = buildSlots(cLevel, agg.extraBuildSlot);
  const hero = agg.hero ?? starterHero();

  const buildings: BuildingDto[] = BUILDING_KEYS.map((key) => {
    const level = agg.levels[key] ?? 0;
    const max = maxLevelFor(key, cLevel);
    let blocked: UpgradeBlock | null = null;
    const ceiling = maxBuildingLevel(key);
    const missing = level === 0 ? missingRequirements(key, agg.levels, cLevel) : [];
    if (inProgress.has(key)) blocked = 'in_progress';
    else if (level >= ceiling) blocked = 'max_level';
    else if (missing.length > 0) blocked = 'requires';
    else if (level >= max) blocked = 'castle_level';
    const next = level < ceiling ? level + 1 : null;
    return {
      key,
      level,
      nextLevel: next,
      cost: next ? buildingCost(key, next) : null,
      seconds: next ? buildSeconds(key, next, cLevel, agg.worldSpeed) : null,
      blocked,
      missing,
    };
  });

  // Ставки: брутто (производство с бонусами); содержание армии показывается отдельно
  const gross = netRates(agg.levels, {}, agg.tech, heroProduction(agg), agg.worldSpeed);

  return {
    serverTime: now.toISOString(),
    worldSpeed: agg.worldSpeed,
    resources: { ...agg.resources },
    caps: { gold: cap, wood: cap, stone: cap, food: cap },
    ratesPerHour: gross,
    gems: agg.gems,
    shieldUntil: agg.shieldUntil?.toISOString() ?? null,
    slots: {
      total,
      used: agg.tasks.length,
      extraUnlocked: agg.extraBuildSlot,
      canUnlock: total === 1,
      unlockCostGems: EXTRA_SLOT_GEMS,
    },
    buildings,
    tasks: agg.tasks
      .map((t) => ({
        id: t.id,
        key: t.key,
        toLevel: t.toLevel,
        startedAt: t.startedAt.toISOString(),
        finishesAt: t.finishesAt.toISOString(),
        speedupGems: speedupGems(remainingSeconds(t.finishesAt, now)),
        refund: cancelRefund(t.paid),
      }))
      .sort((a, b) => a.finishesAt.localeCompare(b.finishesAt)),
    army: armyDto(agg, now),
    research: researchDto(agg, now),
    hero: heroDto(hero),
    position: agg.x !== null && agg.y !== null ? { x: agg.x, y: agg.y } : null,
    marches: agg.marches
      .map((m) => marchDto(m))
      .sort((a, b) => a.arriveAt.localeCompare(b.arriveAt)),
    marchesMax: MAX_MARCHES,
    power: aggregatePower(agg),
    city: cityDto(agg.structures, cLevel),
  };
}

function marchDto(m: MarchRecord): MarchDto {
  return {
    id: m.id,
    type: m.type,
    target: { ...m.target },
    targetName: m.targetName,
    units: { ...m.units },
    loot: { ...m.loot },
    state: m.state,
    startedAt: m.startedAt.toISOString(),
    arriveAt: m.arriveAt.toISOString(),
    returnAt: m.returnAt.toISOString(),
    reportId: m.reportId,
  };
}

export { parseUnitId };
