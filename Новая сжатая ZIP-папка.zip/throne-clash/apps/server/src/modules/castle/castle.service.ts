import { randomUUID } from 'node:crypto';
import {
  EXTRA_SLOT_GEMS,
  STRUCTURE_DEFS,
  placeError,
  structureCost,
  structureRefund,
  type StructureKind,
  addAmounts,
  buildSeconds,
  buildSlots,
  buildingCost,
  cancelRefund,
  maxBuildingLevel,
  maxLevelFor,
  missingRequirements,
  shortfall,
  speedupGems,
  subtractCost,
  type BuildingKey,
  type CastleDto,
} from '@tc/shared';
import type { Clock } from '../../lib/clock';
import { Errors } from '../../lib/errors';
import { castleLevel, settleAggregate, rechain } from './castle.realm';
import { RealmRunner, gemEvent, negate, resourceEvents, type CastleResult } from './castle.runner';
import type { CastleRepository } from './castle.types';
import type { NotificationRecord } from '../social/social.types';

export type { CastleResult };
export { toCastleDto } from './castle.realm';

/** Здания: постройка, ускорение, отмена, второй слот. Остальные части замка — в модулях army, research, hero. */
export class CastleService {
  readonly runner: RealmRunner;

  constructor(deps: {
    repo: CastleRepository;
    clock: Clock;
    worldId?: string;
    before?: (userId: string) => Promise<void>;
    onNotify?: (userId: string, notes: NotificationRecord[]) => void;
  }) {
    this.runner = new RealmRunner(deps);
  }

  view(userId: string): Promise<CastleDto> {
    return this.runner.view(userId);
  }

  upgrade(userId: string, key: BuildingKey, idemKey: string): Promise<CastleResult> {
    return this.runner.mutate(
      userId,
      `upgrade:${key}`,
      idemKey,
      (draft, now) => {
        const cLevel = castleLevel(draft);
        const current = draft.levels[key] ?? 0;
        if (draft.tasks.some((t) => t.key === key)) {
          throw Errors.requirementNotMet({ reason: 'in_progress' });
        }
        const target = current + 1;
        if (target > maxBuildingLevel(key)) throw Errors.requirementNotMet({ reason: 'max_level' });
        // Первая постройка требует Земель и других зданий (D-59)
        if (current === 0) {
          const missing = missingRequirements(key, draft.levels, cLevel);
          if (missing.length > 0) throw Errors.requirementNotMet({ reason: 'requires', missing });
        }
        if (target > maxLevelFor(key, cLevel)) {
          throw Errors.requirementNotMet({ reason: 'castle_level', required: target });
        }
        if (draft.tasks.length >= buildSlots(cLevel, draft.extraBuildSlot))
          throw Errors.queueFull();

        const cost = buildingCost(key, target);
        const missing = shortfall(draft.resources, cost);
        if (Object.keys(missing).length > 0) throw Errors.insufficientResources({ missing });

        draft.resources = subtractCost(draft.resources, cost);
        const seconds = buildSeconds(key, target, cLevel, draft.worldSpeed);
        draft.tasks.push({
          id: randomUUID(),
          key,
          toLevel: target,
          startedAt: now,
          finishesAt: new Date(now.getTime() + seconds * 1000),
          paid: cost,
          isGodAction: draft.isGodAction,
        });
        return resourceEvents(draft, now, 'build_cost', negate(cost));
      },
      undefined,
      { bump: { upgrade: 1 } },
    );
  }

  speedup(userId: string, taskId: string, idemKey: string): Promise<CastleResult> {
    return this.runner.mutate(userId, `speedup:${taskId}`, idemKey, (draft, now, emit) => {
      const task = draft.tasks.find((t) => t.id === taskId);
      if (!task) throw Errors.notFound('Build task');
      const remaining = Math.max(0, Math.ceil((task.finishesAt.getTime() - now.getTime()) / 1000));
      const gems = speedupGems(remaining);
      if (draft.gems < gems)
        throw Errors.insufficientResources({ missing: { gems: gems - draft.gems } });
      draft.gems -= gems;
      task.finishesAt = now;
      // Постройка завершается сразу: применяем её тем же расчётом
      const { draft: done, events } = settleAggregate(draft, now);
      emit(events);
      Object.assign(draft, done);
      rechain(draft.trains, now);
      return [gemEvent(draft, now, 'speedup', -gems)];
    });
  }

  cancel(userId: string, taskId: string, idemKey: string): Promise<CastleResult> {
    return this.runner.mutate(userId, `cancel:${taskId}`, idemKey, (draft, now) => {
      const task = draft.tasks.find((t) => t.id === taskId);
      if (!task) throw Errors.notFound('Build task');
      const refund = cancelRefund(task.paid);
      // Возврат может поднять запас выше ёмкости — это допустимо, лишнее не сгорает
      draft.resources = addAmounts(draft.resources, refund);
      draft.tasks = draft.tasks.filter((t) => t.id !== taskId);
      return resourceEvents(draft, now, 'build_refund', refund);
    });
  }

  /** Постройка города на свободной клетке острова: ставится сразу за ресурсы (D-66). */
  placeStructure(
    userId: string,
    input: { kind: StructureKind; x: number; y: number },
    idemKey: string,
  ): Promise<CastleResult> {
    return this.runner.mutate(
      userId,
      `structure:${input.kind}:${input.x}:${input.y}`,
      idemKey,
      (draft, now) => {
        const err = placeError(input.kind, input.x, input.y, {
          castleLevel: castleLevel(draft),
          territory: draft.levels.territory ?? 0,
          structures: draft.structures,
        });
        if (err === 'castle_level') {
          throw Errors.requirementNotMet({
            reason: 'castle_level',
            required: STRUCTURE_DEFS[input.kind].castle,
          });
        }
        if (err === 'limit') throw Errors.requirementNotMet({ reason: 'structure_limit' });
        if (err === 'cell') throw Errors.conflict('Cell is not free');
        if (err) throw Errors.requirementNotMet({ reason: err });
        const owned = draft.structures.filter((s) => s.kind === input.kind).length;
        const cost = structureCost(input.kind, owned);
        const missing = shortfall(draft.resources, cost);
        if (Object.keys(missing).length > 0) throw Errors.insufficientResources({ missing });
        draft.resources = subtractCost(draft.resources, cost);
        draft.structures.push({ id: randomUUID(), kind: input.kind, x: input.x, y: input.y });
        return resourceEvents(draft, now, 'structure_cost', negate(cost));
      },
    );
  }

  /** Снос постройки города: возвращается половина последней цены вида. */
  removeStructure(userId: string, id: string, idemKey: string): Promise<CastleResult> {
    return this.runner.mutate(userId, `structure-remove:${id}`, idemKey, (draft, now) => {
      const s = draft.structures.find((x) => x.id === id);
      if (!s) throw Errors.notFound('Structure');
      const owned = draft.structures.filter((x) => x.kind === s.kind).length;
      const refund = structureRefund(structureCost(s.kind, owned - 1));
      draft.structures = draft.structures.filter((x) => x.id !== id);
      draft.resources = addAmounts(draft.resources, refund);
      return resourceEvents(draft, now, 'structure_refund', refund);
    });
  }

  unlockSlot(userId: string, idemKey: string): Promise<CastleResult> {
    return this.runner.mutate(userId, 'unlock-slot', idemKey, (draft, now) => {
      if (buildSlots(castleLevel(draft), draft.extraBuildSlot) >= 2) {
        throw Errors.conflict('Second slot is already available');
      }
      if (draft.gems < EXTRA_SLOT_GEMS) {
        throw Errors.insufficientResources({ missing: { gems: EXTRA_SLOT_GEMS - draft.gems } });
      }
      draft.gems -= EXTRA_SLOT_GEMS;
      draft.extraBuildSlot = true;
      return [gemEvent(draft, now, 'slot_unlock', -EXTRA_SLOT_GEMS)];
    });
  }
}
