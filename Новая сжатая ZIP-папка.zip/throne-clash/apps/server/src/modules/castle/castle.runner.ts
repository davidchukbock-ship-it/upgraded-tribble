import { createHash } from 'node:crypto';
import {
  MAIN_WORLD_ID,
  dayKey,
  pickCastleSpotV,
  type CastleDto,
  type QuestMetric,
} from '@tc/shared';
import type { Clock } from '../../lib/clock';
import { Errors } from '../../lib/errors';
import { randomUUID } from 'node:crypto';
import { settleAggregate, starterHero, toCastleDto, type SettleEvent } from './castle.realm';
import type { NotificationRecord } from '../social/social.types';
import {
  IdempotencyRace,
  VersionConflict,
  type CastleAggregate,
  type CastleRepository,
  type CastleTx,
  type EconomyEventRecord,
} from './castle.types';

const IDEMPOTENCY_TTL_MS = 24 * 3600_000;
const MAX_ATTEMPTS = 8;

/** Короткая пауза с разбросом между повторами: так гонки на MySQL (взаимные блокировки) разводятся по времени. */
const backoff = (attempt: number): Promise<void> =>
  new Promise((resolve) => setTimeout(resolve, 2 + Math.random() * 12 * (attempt + 1)));

export interface CastleResult<B = CastleDto> {
  status: number;
  body: B;
  /** true — ответ взят из сохранённого по Idempotency-Key, действие повторно не выполнялось. */
  replayed: boolean;
}

/** `emit` — события, завершённые внутри самого действия (например, ускорение): из них тоже делаются уведомления. */
export type Action = (
  draft: CastleAggregate,
  now: Date,
  emit: (events: readonly SettleEvent[]) => void,
  /** Хранилища той же транзакции: действие может проверить и изменить и их (сундуки, инвентарь). */
  tx: CastleTx,
) => EconomyEventRecord[] | Promise<EconomyEventRecord[]>;

export interface MutateOptions<B> {
  /** Превращает итоговый замок в тело ответа (например, добавляет награду); тело сохраняется для идемпотентного повтора. */
  wrap?: (castle: CastleDto) => B;
  /** Сколько засчитать в счётчики заданий, если действие удалось. */
  bump?: Partial<Record<QuestMetric, number>>;
}

/**
 * Общий каркас чтения и изменения замка (D-06, D-27): расчёт → действие → запись одной транзакцией
 * с оптимистичной блокировкой, идемпотентностью и повтором при конфликте.
 * Через него работают все модули: castle, army, research, hero.
 */
export class RealmRunner {
  private readonly worldId: string;

  constructor(
    private readonly deps: {
      repo: CastleRepository;
      clock: Clock;
      worldId?: string;
      /** Вызывается перед каждым чтением и изменением: разрешает прибывшие походы этого игрока. */
      before?: (userId: string) => Promise<void>;
      /** Вызывается после успешной фиксации: уведомления, которые нужно доставить онлайн. */
      onNotify?: (userId: string, notes: NotificationRecord[]) => void;
    },
  ) {
    this.worldId = deps.worldId ?? MAIN_WORLD_ID;
  }

  /** Записывает уведомления о том, что завершилось при расчёте (в той же транзакции). */
  private async notify(
    tx: CastleTx,
    userId: string,
    events: readonly SettleEvent[],
  ): Promise<NotificationRecord[]> {
    const rows: NotificationRecord[] = events.map((e) => ({
      id: randomUUID(),
      userId,
      kind: e.kind,
      payload: e.payload,
      read: false,
      createdAt: e.at,
    }));
    await tx.notifications.add(rows);
    return rows;
  }

  /**
   * Офлайн-игроки: находит замки, где по расчёту что-то достроилось, и «читает» их — это записывает результат
   * и создаёт уведомления. Вызывается по таймеру.
   */
  async settleDue(limit = 50): Promise<number> {
    const now = this.deps.clock.now();
    const users = await this.deps.repo.transaction((tx) =>
      tx.dueCastleUsers(this.worldId, now, limit),
    );
    let n = 0;
    for (const userId of users) {
      try {
        await this.view(userId);
        n++;
      } catch {
        /* конфликт или сбой одного игрока не должен блокировать остальных */
      }
    }
    return n;
  }

  /** Замок получает место на карте при первом обращении (ближайшая к центру свободная клетка). */
  private async place(tx: CastleTx, draft: CastleAggregate): Promise<boolean> {
    if (draft.x !== null && draft.y !== null) return false;
    const spot = pickCastleSpotV(
      draft.worldMapVersion,
      draft.worldSeed,
      await tx.occupiedSpots(draft.worldId),
    );
    if (!spot) throw Errors.conflict('The world is full');
    draft.x = spot.x;
    draft.y = spot.y;
    return true;
  }

  /** Чтение: расчёт «на лету»; в БД пишем, только если что-то достроилось или создан герой. */
  async view(userId: string): Promise<CastleDto> {
    await this.deps.before?.(userId);
    const now = this.deps.clock.now();
    for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
      let emitted: NotificationRecord[] = [];
      try {
        const dto = await this.deps.repo.transaction(async (tx) => {
          const agg = await tx.load(userId, this.worldId);
          if (!agg) throw Errors.notFound('Castle');
          const { draft, changed, events } = settleAggregate(agg, now);
          const needHero = draft.hero === null;
          if (needHero) draft.hero = starterHero();
          const placed = await this.place(tx, draft);
          if (changed || needHero || placed) await tx.save(agg, draft);
          if (events.length > 0) emitted = await this.notify(tx, userId, events);
          return toCastleDto(draft, now);
        });
        if (emitted.length > 0) this.deps.onNotify?.(userId, emitted);
        return dto;
      } catch (err) {
        if (!(err instanceof VersionConflict)) throw err;
        await backoff(attempt);
      }
    }
    // Замок всё время меняется другим запросом — отдаём расчёт без записи
    return this.deps.repo.transaction(async (tx) => {
      const agg = await tx.load(userId, this.worldId);
      if (!agg) throw Errors.notFound('Castle');
      return toCastleDto(settleAggregate(agg, now).draft, now);
    });
  }

  async mutate<B = CastleDto>(
    userId: string,
    route: string,
    idemKey: string,
    action: Action,
    /** Асинхронная часть в той же транзакции (например, запись в таблицы братства). */
    after?: (tx: CastleTx, draft: CastleAggregate, now: Date) => Promise<void>,
    options: MutateOptions<B> = {},
  ): Promise<CastleResult<B>> {
    const requestHash = createHash('sha256').update(route).digest('hex');
    await this.deps.before?.(userId);
    for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
      const now = this.deps.clock.now();
      let emitted: NotificationRecord[] = [];
      try {
        const result = await this.deps.repo.transaction(async (tx) => {
          const stored = await tx.findIdempotent(
            userId,
            idemKey,
            new Date(now.getTime() - IDEMPOTENCY_TTL_MS),
          );
          if (stored) {
            if (stored.requestHash !== requestHash) throw Errors.idempotencyMismatch();
            return { status: stored.status, body: stored.body as B, replayed: true };
          }
          const agg = await tx.load(userId, this.worldId);
          if (!agg) throw Errors.notFound('Castle');
          const settled = settleAggregate(agg, now);
          const draft = settled.draft;
          draft.hero ??= starterHero();
          await this.place(tx, draft);
          const inline: SettleEvent[] = [];
          const events = await action(draft, now, (e) => inline.push(...e), tx);
          await after?.(tx, draft, now);
          await tx.save(agg, draft);
          const all = [...settled.events, ...inline];
          if (all.length > 0) emitted = await this.notify(tx, userId, all);
          await tx.logEconomy(events);
          for (const [metric, n] of Object.entries(options.bump ?? {})) {
            if (n) await tx.progress.bump(userId, ['total', dayKey(now)], metric, n);
          }
          const dto = toCastleDto(draft, now);
          const body = options.wrap ? options.wrap(dto) : (dto as unknown as B);
          await tx.storeIdempotent(userId, idemKey, {
            route,
            requestHash,
            status: 200,
            body,
            createdAt: now,
          });
          return { status: 200, body, replayed: false };
        });
        if (emitted.length > 0) this.deps.onNotify?.(userId, emitted);
        return result;
      } catch (err) {
        // Параллельный запрос успел раньше: читаем заново (и увидим его сохранённый ответ, если ключ тот же)
        if (err instanceof VersionConflict || err instanceof IdempotencyRace) {
          await backoff(attempt);
          continue;
        }
        throw err;
      }
    }
    throw Errors.conflict('Castle is busy, try again');
  }
}

/** События экономики по списанию/возврату ресурсов. */
export function resourceEvents(
  draft: CastleAggregate,
  now: Date,
  kind: string,
  amounts: Record<'gold' | 'wood' | 'stone' | 'food', number>,
): EconomyEventRecord[] {
  return (['gold', 'wood', 'stone', 'food'] as const)
    .filter((r) => amounts[r] !== 0)
    .map((resource) => ({
      worldId: draft.worldId,
      userId: draft.userId,
      kind,
      resource,
      amount: amounts[resource],
      isGodAction: draft.isGodAction,
      createdAt: now,
    }));
}

export function gemEvent(
  draft: CastleAggregate,
  now: Date,
  kind: string,
  amount: number,
): EconomyEventRecord {
  return {
    worldId: draft.worldId,
    userId: draft.userId,
    kind,
    resource: 'gems',
    amount,
    isGodAction: draft.isGodAction,
    createdAt: now,
  };
}

export const negate = (a: Record<'gold' | 'wood' | 'stone' | 'food', number>) => ({
  gold: -a.gold,
  wood: -a.wood,
  stone: -a.stone,
  food: -a.food,
});
