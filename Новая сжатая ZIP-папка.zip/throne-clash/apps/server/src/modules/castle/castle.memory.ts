import { nicknameKey, type BuildingLevels, type Point } from '@tc/shared';
import type { MemoryUserRepository } from '../auth/auth.memory';
import { MemoryAdmin } from '../admin/admin.memory';
import { MemoryProgress } from '../progress/progress.memory';
import { MemorySocial } from '../social/social.memory';
import { aggregatePower } from './castle.realm';
import {
  IdempotencyRace,
  VersionConflict,
  type CastleAggregate,
  type CastleRepository,
  type CastleSpot,
  type CastleTx,
  type CellStateRecord,
  type ReportRecord,
  type EconomyEventRecord,
  type StoredResponse,
} from './castle.types';

export const IDEMPOTENCY_TTL_MS = 24 * 3600_000;
/** Seed карты в тестах. */
export const TEST_WORLD_SEED = 20260101;

const clone = (a: CastleAggregate): CastleAggregate => structuredClone(a);

/**
 * In-memory замки для юнит-тестов. Транзакция работает на копии и фиксируется атомарно
 * с проверкой версий — параллельные вызовы ведут себя как в PostgreSQL (конфликт версий, гонка ключей).
 */
export class MemoryCastleRepository implements CastleRepository {
  readonly castles = new Map<string, CastleAggregate>();
  readonly idempotency = new Map<string, StoredResponse>();
  readonly economy: EconomyEventRecord[] = [];
  readonly cellStates = new Map<string, CellStateRecord>();
  readonly reports: ReportRecord[] = [];
  /** Братства, чат и уведомления (применяются сразу, вне отката транзакции). */
  readonly social = new MemorySocial((userId) => {
    const u = this.users?.users.get(userId);
    return u ? { id: u.id, nickname: u.nickname, isGuest: u.isGuest } : null;
  });

  /** Журнал аудита, сессии и снимки режима бога, ревизии баланса. */
  readonly admin = new MemoryAdmin({
    economy: (worldId, since) =>
      this.economy
        .filter((e) => e.worldId === worldId && !e.isGodAction && e.createdAt >= since)
        .map((e) => ({ resource: e.resource, amount: e.amount })),
    counts: async (worldId) => {
      this.placedOrAll();
      return {
        users: this.users?.users.size ?? this.castles.size,
        castles: [...this.castles.values()].filter((c) => c.worldId === worldId).length,
        marches: [...this.castles.values()].reduce((s, c) => s + c.marches.length, 0),
        guilds: this.social.guildCount(worldId),
        chatMessages: this.social.messages.filter((m) => m.worldId === worldId).length,
      };
    },
    reports: async () =>
      this.social.reports.flatMap((r) => {
        const m = this.social.messages.find((x) => x.id === r.messageId);
        return m
          ? [
              {
                id: r.id,
                reason: r.reason,
                createdAt: m.createdAt,
                reporterId: r.reporterId,
                messageId: m.id,
                authorId: m.userId,
                channel: m.channel,
                text: m.text,
                messageCreatedAt: m.createdAt,
              },
            ]
          : [];
      }),
  });

  /** Инвентарь, задания, лиги (применяются сразу, вне отката транзакции). */
  readonly progress = new MemoryProgress((worldId) => {
    this.placedOrAll();
    return [...this.castles.values()]
      .filter((c) => c.worldId === worldId && !c.isGodAction)
      .map((c) => ({
        userId: c.userId,
        nickname: this.users?.users.get(c.userId)?.nickname ?? c.userId,
        power: c.power,
        guildId: this.social.memberGuild(c.userId, worldId),
      }));
  });

  /** Материализует замки, созданные регистрацией. */
  private placedOrAll(): void {
    for (const made of this.users?.castles ?? []) {
      if (!this.castles.has(made.userId)) this.materialize(made.userId, made.worldId);
    }
  }

  /** users нужен, чтобы видеть замки, созданные при регистрации (там они лежат в MemoryUserRepository). */
  constructor(private readonly users?: MemoryUserRepository) {}

  seed(castle: CastleAggregate): void {
    this.castles.set(castle.userId, clone(castle));
  }

  /** Материализует замок, созданный регистрацией. */
  private materialize(userId: string, worldId: string): CastleAggregate | null {
    const made = this.users?.castles.find((c) => c.userId === userId && c.worldId === worldId);
    if (!made) return null;
    const levels: BuildingLevels = {};
    for (const key of made.buildings) levels[key] = 1;
    const agg: CastleAggregate = {
      id: `castle-${userId}`,
      userId,
      worldId,
      worldSpeed: 1,
      worldSeed: TEST_WORLD_SEED,
      worldMapVersion: 1,
      x: null,
      y: null,
      resources: { ...made.resources },
      gems: made.gems,
      gemsCarry: 0,
      structures: [],
      resourcesUpdatedAt: made.resourcesUpdatedAt,
      shieldUntil: made.shieldUntil,
      extraBuildSlot: false,
      power: 0,
      version: 1,
      isGodAction: false,
      levels,
      tasks: [],
      army: {},
      trains: [],
      tech: {},
      research: [],
      hero: null,
      marches: [],
    };
    this.castles.set(userId, agg);
    return agg;
  }

  peek(userId: string, worldId = 'main'): CastleAggregate | null {
    const live = this.castles.get(userId) ?? this.materialize(userId, worldId);
    return live ? clone(live) : null;
  }

  async transaction<T>(fn: (tx: CastleTx) => Promise<T>): Promise<T> {
    const saves: Array<{ prev: CastleAggregate; next: CastleAggregate }> = [];
    const events: EconomyEventRecord[] = [];
    const idem = new Map<string, StoredResponse>();
    const cells: Array<{ key: string; st: CellStateRecord }> = [];
    const newReports: ReportRecord[] = [];
    const reads: Array<{ userId: string; id: string }> = [];

    const spotOf = (c: CastleAggregate): CastleSpot => ({
      castleId: c.id,
      userId: c.userId,
      nickname: this.users?.users.get(c.userId)?.nickname ?? c.userId,
      x: c.x ?? 0,
      y: c.y ?? 0,
      shieldUntil: c.shieldUntil,
    });
    const placed = (worldId: string): CastleAggregate[] => {
      // Замки, созданные регистрацией, тоже попадают в выборку
      for (const made of this.users?.castles ?? []) {
        if (!this.castles.has(made.userId)) this.materialize(made.userId, made.worldId);
      }
      return [...this.castles.values()].filter(
        (c) => c.worldId === worldId && c.x !== null && c.y !== null,
      );
    };

    const progressTx = this.progress.begin();
    const adminTx = this.admin.begin();
    const tx: CastleTx = {
      guilds: this.social.guilds,
      chat: this.social.chat,
      notifications: this.social.notifications,
      progress: progressTx,
      admin: adminTx,
      userInfo: (userId) => this.social.userInfo(userId),
      dueCastleUsers: async (worldId, now, limit) =>
        [...this.castles.values()]
          .filter(
            (c) =>
              c.worldId === worldId &&
              [...c.tasks, ...c.trains, ...c.research].some((t) => t.finishesAt <= now),
          )
          .slice(0, limit)
          .map((c) => c.userId),
      load: async (userId, worldId) => {
        const live = this.castles.get(userId) ?? this.materialize(userId, worldId);
        return live ? clone(live) : null;
      },
      loadById: async (castleId) => {
        const live = [...this.castles.values()].find((c) => c.id === castleId);
        return live ? clone(live) : null;
      },
      occupiedSpots: async (worldId) =>
        placed(worldId).map((c): Point => ({ x: c.x ?? 0, y: c.y ?? 0 })),
      spotsIn: async (worldId, x0, y0, x1, y1) =>
        placed(worldId)
          .filter((c) => (c.x ?? 0) >= x0 && (c.x ?? 0) < x1 && (c.y ?? 0) >= y0 && (c.y ?? 0) < y1)
          .map(spotOf),
      spotAt: async (worldId, x, y) => {
        const c = placed(worldId).find((k) => k.x === x && k.y === y);
        return c ? spotOf(c) : null;
      },
      searchSpots: async (worldId, query, limit) =>
        placed(worldId)
          .map(spotOf)
          .filter((s) => nicknameKey(s.nickname).includes(nicknameKey(query)))
          .sort((a, b) => a.nickname.localeCompare(b.nickname))
          .slice(0, limit),
      dueArrivals: async (worldId, now, limit, userId) => {
        const all = [...this.castles.values()].filter((c) => c.worldId === worldId);
        const mine = userId ? all.find((c) => c.userId === userId) : undefined;
        const out: Array<{ marchId: string; attackerUserId: string; at: number }> = [];
        for (const c of all) {
          for (const m of c.marches) {
            if (m.state !== 'outbound' || m.arriveAt.getTime() > now.getTime()) continue;
            if (userId && c.userId !== userId && m.targetCastleId !== mine?.id) continue;
            out.push({ marchId: m.id, attackerUserId: c.userId, at: m.arriveAt.getTime() });
          }
        }
        return out
          .sort((a, b) => a.at - b.at)
          .slice(0, limit)
          .map(({ marchId, attackerUserId }) => ({ marchId, attackerUserId }));
      },
      cellStates: async (worldId, x0, y0, x1, y1) =>
        [...this.cellStates.entries()]
          .filter(
            ([k, v]) =>
              k.startsWith(`${worldId}:`) && v.x >= x0 && v.x < x1 && v.y >= y0 && v.y < y1,
          )
          .map(([, v]) => structuredClone(v)),
      saveCellState: async (worldId, st) => {
        cells.push({ key: `${worldId}:${st.x}:${st.y}`, st: structuredClone(st) });
      },
      addReports: async (rows) => {
        newReports.push(...structuredClone(rows));
      },
      listReports: async (userId, page, pageSize) => {
        const mine = this.reports
          .filter((r) => r.userId === userId)
          .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime() || (a.id < b.id ? 1 : -1));
        return {
          items: structuredClone(mine.slice((page - 1) * pageSize, page * pageSize)),
          total: mine.length,
          unread: mine.filter((r) => !r.read).length,
        };
      },
      getReport: async (userId, id) => {
        const r = this.reports.find((x) => x.id === id && x.userId === userId);
        return r ? structuredClone(r) : null;
      },
      markReportRead: async (userId, id) => {
        reads.push({ userId, id });
      },
      save: async (prev, next) => {
        saves.push({ prev: clone(prev), next: { ...clone(next), power: aggregatePower(next) } });
      },
      logEconomy: async (e) => {
        events.push(...e);
      },
      findIdempotent: async (userId, key, notBefore) => {
        const rec = this.idempotency.get(`${userId}:${key}`);
        return rec && rec.createdAt >= notBefore ? structuredClone(rec) : null;
      },
      storeIdempotent: async (userId, key, response) => {
        idem.set(`${userId}:${key}`, structuredClone(response));
      },
    };

    const snap = this.social.snapshot();
    const rollback = () => {
      this.social.restore(snap);
      progressTx.rollback();
      adminTx.rollback();
    };
    let result: T;
    try {
      result = await fn(tx);
    } catch (err) {
      // Как откат в PostgreSQL: записи братств, чата и уведомлений этой транзакции отменяются
      rollback();
      throw err;
    }

    // Фиксация одним синхронным куском: между проверкой и записью другие транзакции не вклиниваются
    for (const { prev } of saves) {
      if ((this.castles.get(prev.userId)?.version ?? prev.version) !== prev.version) {
        rollback();
        throw new VersionConflict();
      }
    }
    for (const [k, rec] of idem) {
      const existing = this.idempotency.get(k);
      // Просроченная запись (старше 24 ч) не мешает — её перезапишут
      if (existing && existing.createdAt.getTime() > rec.createdAt.getTime() - IDEMPOTENCY_TTL_MS) {
        rollback();
        throw new IdempotencyRace();
      }
    }
    // Уникальность клетки под замок — как индекс в БД
    for (const { next } of saves) {
      if (next.x === null || next.y === null) continue;
      const clash = [...this.castles.values()].some(
        (c) =>
          c.userId !== next.userId &&
          c.worldId === next.worldId &&
          c.x === next.x &&
          c.y === next.y,
      );
      if (
        clash ||
        saves.some(
          (o) => o.next.userId !== next.userId && o.next.x === next.x && o.next.y === next.y,
        )
      ) {
        rollback();
        throw new VersionConflict();
      }
    }
    for (const { next } of saves)
      this.castles.set(next.userId, { ...clone(next), version: next.version + 1 });
    for (const c of cells) this.cellStates.set(c.key, c.st);
    this.reports.push(...newReports);
    for (const r of reads) {
      const found = this.reports.find((x) => x.id === r.id && x.userId === r.userId);
      if (found) found.read = true;
    }
    this.economy.push(...events);
    for (const [k, rec] of idem) this.idempotency.set(k, rec);
    return result;
  }

  async deleteExpiredIdempotency(before: Date): Promise<number> {
    let n = 0;
    for (const [k, rec] of this.idempotency) {
      if (rec.createdAt < before) {
        this.idempotency.delete(k);
        n++;
      }
    }
    return n;
  }
}
