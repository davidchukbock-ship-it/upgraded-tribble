import type { FastifyInstance, FastifyReply } from 'fastify';
import type { ZodTypeProvider } from 'fastify-type-provider-zod';
import { z } from 'zod';
import {
  buildingKey,
  castleSchema,
  errorSchema,
  failures,
  idempotencyHeaders,
  structureBody,
} from './castle.schema';
import type { CastleResult, CastleService } from './castle.service';

/** Ответ мутации: сохранённый повтор помечается заголовком. */
export function sendResult<B>(reply: FastifyReply, res: CastleResult<B>) {
  if (res.replayed) reply.header('Idempotent-Replay', 'true');
  return reply.code(res.status).send(res.body);
}

export function registerCastleRoutes(app: FastifyInstance, service: CastleService): void {
  const r = app.withTypeProvider<ZodTypeProvider>();
  const tags = ['castle'];
  const security = [{ bearerAuth: [] }];

  r.get(
    '/castle',
    {
      preHandler: app.authenticate,
      schema: {
        tags,
        summary: 'Замок: ресурсы, здания, очередь',
        security,
        response: { 200: castleSchema, 401: errorSchema, 404: errorSchema },
      },
    },
    async (req) => service.view(req.auth!.user.id),
  );

  r.post(
    '/castle/buildings/:key/upgrade',
    {
      preHandler: app.authenticate,
      schema: {
        tags,
        summary: 'Поставить постройку или улучшение в очередь',
        security,
        headers: idempotencyHeaders,
        params: z.object({ key: buildingKey }),
        response: { 200: castleSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await service.upgrade(req.auth!.user.id, req.params.key, req.headers['idempotency-key']),
      ),
  );

  r.post(
    '/castle/queue/:taskId/speedup',
    {
      preHandler: app.authenticate,
      schema: {
        tags,
        summary: 'Ускорить постройку за кристаллы',
        security,
        headers: idempotencyHeaders,
        params: z.object({ taskId: z.string().uuid() }),
        response: { 200: castleSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await service.speedup(req.auth!.user.id, req.params.taskId, req.headers['idempotency-key']),
      ),
  );

  r.post(
    '/castle/queue/:taskId/cancel',
    {
      preHandler: app.authenticate,
      schema: {
        tags,
        summary: 'Отменить постройку (возврат 50%)',
        security,
        headers: idempotencyHeaders,
        params: z.object({ taskId: z.string().uuid() }),
        response: { 200: castleSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await service.cancel(req.auth!.user.id, req.params.taskId, req.headers['idempotency-key']),
      ),
  );

  r.post(
    '/castle/structures',
    {
      preHandler: app.authenticate,
      schema: {
        tags,
        summary: 'Построить здание города на свободной клетке острова',
        security,
        headers: idempotencyHeaders,
        body: structureBody,
        response: { 200: castleSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await service.placeStructure(req.auth!.user.id, req.body, req.headers['idempotency-key']),
      ),
  );

  r.delete(
    '/castle/structures/:id',
    {
      preHandler: app.authenticate,
      schema: {
        tags,
        summary: 'Снести здание города (возврат 50%)',
        security,
        headers: idempotencyHeaders,
        params: z.object({ id: z.string().uuid() }),
        response: { 200: castleSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await service.removeStructure(
          req.auth!.user.id,
          req.params.id,
          req.headers['idempotency-key'],
        ),
      ),
  );

  r.post(
    '/castle/slots/unlock',
    {
      preHandler: app.authenticate,
      schema: {
        tags,
        summary: 'Открыть второй слот строительства за кристаллы',
        security,
        headers: idempotencyHeaders,
        response: { 200: castleSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await service.unlockSlot(req.auth!.user.id, req.headers['idempotency-key']),
      ),
  );
}
