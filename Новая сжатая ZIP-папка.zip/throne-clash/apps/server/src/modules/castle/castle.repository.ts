import { Prisma, type PrismaClient } from '@prisma/client';
import {
  nicknameKey,
  BUILDING_KEYS,
  MARCH_TYPES,
  isTechKey,
  parseUnitId,
  type Army,
  type MarchType,
  type Point,
  type ReportDetailDto,
  type UnitCounts,
  type BuildingKey,
  type BuildingLevels,
  type EquipSlot,
  type HeroState,
  type Rarity,
  type TechLevels,
  type UnitId,
  type PlacedStructure,
  asMapVersion,
} from '@tc/shared';
import { PrismaAdmin } from '../admin/admin.repository';
import { PrismaProgress } from '../progress/progress.repository';
import { PrismaSocial } from '../social/social.repository';
import { aggregatePower } from './castle.realm';
import {
  IdempotencyRace,
  VersionConflict,
  type BuildTaskRecord,
  type CastleAggregate,
  type CastleRepository,
  type CastleSpot,
  type CastleTx,
  type CellStateRecord,
  type MarchRecord,
  type ReportRecord,
  type EconomyEventRecord,
  type ResearchTaskRecord,
  type StoredResponse,
  type TrainTaskRecord,
} from './castle.types';

type Client = Prisma.TransactionClient;

class PrismaCastleTx implements CastleTx {
  private readonly social: PrismaSocial;
  readonly guilds: CastleTx['guilds'];
  readonly chat: CastleTx['chat'];
  readonly notifications: CastleTx['notifications'];
  readonly progress: PrismaProgress;
  readonly admin: PrismaAdmin;

  constructor(private readonly db: Client) {
    this.progress = new PrismaProgress(db);
    this.admin = new PrismaAdmin(db);
    this.social = new PrismaSocial(db);
    this.guilds = this.social.guilds;
    this.chat = this.social.chat;
    this.notifications = this.social.notifications;
  }

  userInfo(userId: string) {
    return this.social.userInfo(userId);
  }

  async dueCastleUsers(worldId: string, now: Date, limit: number): Promise<string[]> {
    const due = { finishesAt: { lte: now } };
    const rows = await this.db.castle.findMany({
      where: {
        worldId,
        OR: [
          { buildTasks: { some: due } },
          { trainTasks: { some: due } },
          { researchTasks: { some: due } },
        ],
      },
      select: { userId: true },
      take: limit,
    });
    return rows.map((r) => r.userId);
  }

  async load(userId: string, worldId: string): Promise<CastleAggregate | null> {
    return this.loadWhere({ worldId_userId: { worldId, userId } });
  }

  async loadById(castleId: string): Promise<CastleAggregate | null> {
    return this.loadWhere({ id: castleId });
  }

  private async loadWhere(where: Prisma.CastleWhereUniqueInput): Promise<CastleAggregate | null> {
    const c = await this.db.castle.findUnique({
      where,
      include: {
        marches: true,
        buildings: true,
        buildTasks: true,
        armyUnits: true,
        trainTasks: true,
        techLevels: true,
        researchTasks: true,
        hero: true,
        heroItems: true,
        world: { select: { speed: true, seed: true, mapVersion: true } },
      },
    });
    if (!c) return null;
    const levels: BuildingLevels = {};
    for (const b of c.buildings) {
      if ((BUILDING_KEYS as readonly string[]).includes(b.key))
        levels[b.key as BuildingKey] = b.level;
    }
    const tasks: BuildTaskRecord[] = c.buildTasks.map((t) => ({
      id: t.id,
      key: t.buildingKey as BuildingKey,
      toLevel: t.toLevel,
      startedAt: t.startedAt,
      finishesAt: t.finishesAt,
      paid: { gold: t.paidGold, wood: t.paidWood, stone: t.paidStone, food: t.paidFood },
      isGodAction: t.isGodAction,
    }));
    const army: Army = {};
    for (const u of c.armyUnits)
      if (parseUnitId(u.unitId)) army[u.unitId as UnitId] = { count: u.count, wounded: u.wounded };
    const tech: TechLevels = {};
    for (const t of c.techLevels) if (isTechKey(t.tech)) tech[t.tech] = t.level;
    const paidOf = (r: {
      paidGold: number;
      paidWood: number;
      paidStone: number;
      paidFood: number;
    }) => ({
      gold: r.paidGold,
      wood: r.paidWood,
      stone: r.paidStone,
      food: r.paidFood,
    });
    const trains: TrainTaskRecord[] = c.trainTasks
      .filter((t) => parseUnitId(t.unitId))
      .map((t) => ({
        id: t.id,
        unit: t.unitId as UnitId,
        count: t.count,
        startedAt: t.startedAt,
        finishesAt: t.finishesAt,
        paid: paidOf(t),
        isGodAction: t.isGodAction,
      }));
    const research: ResearchTaskRecord[] = c.researchTasks
      .filter((t) => isTechKey(t.tech))
      .map((t) => ({
        id: t.id,
        tech: t.tech as ResearchTaskRecord['tech'],
        toLevel: t.toLevel,
        startedAt: t.startedAt,
        finishesAt: t.finishesAt,
        paid: paidOf(t),
        isGodAction: t.isGodAction,
      }));
    const hero: HeroState | null = c.hero
      ? {
          level: c.hero.level,
          xp: c.hero.xp,
          skills: {
            combat: c.hero.skillCombat,
            defense: c.hero.skillDefense,
            economy: c.hero.skillEconomy,
          },
          items: c.heroItems.map((i) => ({
            id: i.id,
            slot: i.slot as EquipSlot,
            rarity: i.rarity as Rarity,
            equipped: i.equipped,
          })),
        }
      : null;
    return {
      id: c.id,
      userId: c.userId,
      worldId: c.worldId,
      worldSpeed: c.world.speed,
      worldSeed: c.world.seed,
      worldMapVersion: asMapVersion(c.world.mapVersion),
      x: c.x,
      y: c.y,
      resources: { gold: c.gold, wood: c.wood, stone: c.stone, food: c.food },
      gems: c.gems,
      gemsCarry: c.gemsCarry,
      structures: Array.isArray(c.structures) ? (c.structures as unknown as PlacedStructure[]) : [],
      resourcesUpdatedAt: c.resourcesUpdatedAt,
      shieldUntil: c.shieldUntil,
      extraBuildSlot: c.extraBuildSlot,
      power: c.power,
      version: c.version,
      isGodAction: c.isGodAction,
      levels,
      tasks,
      army,
      trains,
      tech,
      research,
      hero,
      marches: c.marches
        .filter((m) => (MARCH_TYPES as readonly string[]).includes(m.type))
        .map((m) => ({
          id: m.id,
          type: m.type as MarchType,
          target: { x: m.targetX, y: m.targetY },
          targetCastleId: m.targetCastleId,
          targetName: m.targetName,
          units: m.units as UnitCounts,
          wounded: m.wounded as UnitCounts,
          loot: m.loot as MarchRecord['loot'],
          heroXp: m.heroXp,
          state: m.state === 'returning' ? ('returning' as const) : ('outbound' as const),
          startedAt: m.startedAt,
          arriveAt: m.arriveAt,
          returnAt: m.returnAt,
          reportId: m.reportId,
        })),
    };
  }

  async save(prev: CastleAggregate, next: CastleAggregate): Promise<void> {
    let updated: { count: number };
    try {
      updated = await this.db.castle.updateMany({
        where: { id: prev.id, version: prev.version },
        data: {
          gold: next.resources.gold,
          wood: next.resources.wood,
          stone: next.resources.stone,
          food: next.resources.food,
          gems: next.gems,
          gemsCarry: next.gemsCarry,
          structures: next.structures as unknown as Prisma.InputJsonValue,
          resourcesUpdatedAt: next.resourcesUpdatedAt,
          shieldUntil: next.shieldUntil,
          extraBuildSlot: next.extraBuildSlot,
          power: aggregatePower(next),
          isGodAction: next.isGodAction,
          x: next.x,
          y: next.y,
          version: { increment: 1 },
        },
      });
    } catch (err) {
      // Два игрока выбрали одну клетку для замка: проигравший повторит выбор
      if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === 'P2002')
        throw new VersionConflict();
      throw err;
    }
    if (updated.count === 0) throw new VersionConflict();

    for (const key of BUILDING_KEYS) {
      const level = next.levels[key];
      if (level === undefined || level === prev.levels[key]) continue;
      await this.db.building.upsert({
        where: { castleId_key: { castleId: prev.id, key } },
        update: { level },
        create: { castleId: prev.id, key, level },
      });
    }

    const nextIds = new Set(next.tasks.map((t) => t.id));
    const prevIds = new Set(prev.tasks.map((t) => t.id));
    const removed = prev.tasks.filter((t) => !nextIds.has(t.id)).map((t) => t.id);
    if (removed.length > 0) await this.db.buildTask.deleteMany({ where: { id: { in: removed } } });
    const added = next.tasks.filter((t) => !prevIds.has(t.id));
    if (added.length > 0) {
      await this.db.buildTask.createMany({
        data: added.map((t) => ({
          id: t.id,
          castleId: prev.id,
          buildingKey: t.key,
          toLevel: t.toLevel,
          startedAt: t.startedAt,
          finishesAt: t.finishesAt,
          paidGold: t.paid.gold,
          paidWood: t.paid.wood,
          paidStone: t.paid.stone,
          paidFood: t.paid.food,
          isGodAction: t.isGodAction,
        })),
      });
    }
    // Изменённое время окончания (ускорение) у уже существующей задачи
    for (const t of next.tasks) {
      const before = prev.tasks.find((p) => p.id === t.id);
      if (before && before.finishesAt.getTime() !== t.finishesAt.getTime()) {
        await this.db.buildTask.update({ where: { id: t.id }, data: { finishesAt: t.finishesAt } });
      }
    }
    await this.saveRealm(prev, next);
  }

  /** Войска, технологии, очереди обучения и исследований, герой — записываем разницу prev → next. */
  private async saveRealm(prev: CastleAggregate, next: CastleAggregate): Promise<void> {
    const castleId = prev.id;

    // войска
    const unitIds = new Set<string>([...Object.keys(prev.army), ...Object.keys(next.army)]);
    for (const unitId of unitIds) {
      const a = prev.army[unitId as UnitId];
      const b = next.army[unitId as UnitId];
      if (a?.count === b?.count && a?.wounded === b?.wounded) continue;
      if (!b) {
        await this.db.armyUnit.deleteMany({ where: { castleId, unitId } });
        continue;
      }
      await this.db.armyUnit.upsert({
        where: { castleId_unitId: { castleId, unitId } },
        update: { count: b.count, wounded: b.wounded },
        create: { castleId, unitId, count: b.count, wounded: b.wounded },
      });
    }

    // технологии
    for (const [tech, level] of Object.entries(next.tech)) {
      if (prev.tech[tech as keyof TechLevels] === level) continue;
      await this.db.techLevel.upsert({
        where: { castleId_tech: { castleId, tech } },
        update: { level },
        create: { castleId, tech, level },
      });
    }

    // очередь обучения
    await this.syncTasks(
      prev.trains,
      next.trains,
      (ids) => this.db.trainTask.deleteMany({ where: { id: { in: ids } } }),
      (rows) =>
        this.db.trainTask.createMany({
          data: rows.map((t) => ({
            id: t.id,
            castleId,
            unitId: t.unit,
            count: t.count,
            startedAt: t.startedAt,
            finishesAt: t.finishesAt,
            paidGold: t.paid.gold,
            paidWood: t.paid.wood,
            paidStone: t.paid.stone,
            paidFood: t.paid.food,
            isGodAction: t.isGodAction,
          })),
        }),
      (t) =>
        this.db.trainTask.update({
          where: { id: t.id },
          data: { startedAt: t.startedAt, finishesAt: t.finishesAt },
        }),
    );

    // очередь исследований
    await this.syncTasks(
      prev.research,
      next.research,
      (ids) => this.db.researchTask.deleteMany({ where: { id: { in: ids } } }),
      (rows) =>
        this.db.researchTask.createMany({
          data: rows.map((t) => ({
            id: t.id,
            castleId,
            tech: t.tech,
            toLevel: t.toLevel,
            startedAt: t.startedAt,
            finishesAt: t.finishesAt,
            paidGold: t.paid.gold,
            paidWood: t.paid.wood,
            paidStone: t.paid.stone,
            paidFood: t.paid.food,
            isGodAction: t.isGodAction,
          })),
        }),
      (t) =>
        this.db.researchTask.update({
          where: { id: t.id },
          data: { startedAt: t.startedAt, finishesAt: t.finishesAt },
        }),
    );

    // походы
    const jsonOf = (v: unknown): Prisma.InputJsonValue => v as Prisma.InputJsonValue;
    const marchData = (m: MarchRecord) => ({
      type: m.type,
      targetX: m.target.x,
      targetY: m.target.y,
      targetCastleId: m.targetCastleId,
      targetName: m.targetName,
      units: jsonOf(m.units),
      wounded: jsonOf(m.wounded),
      loot: jsonOf(m.loot),
      heroXp: m.heroXp,
      state: m.state,
      startedAt: m.startedAt,
      arriveAt: m.arriveAt,
      returnAt: m.returnAt,
      reportId: m.reportId,
    });
    const prevMarches = new Map(prev.marches.map((m) => [m.id, m]));
    const nextMarchIds = new Set(next.marches.map((m) => m.id));
    const goneMarches = prev.marches.filter((m) => !nextMarchIds.has(m.id)).map((m) => m.id);
    if (goneMarches.length > 0)
      await this.db.march.deleteMany({ where: { id: { in: goneMarches } } });
    for (const m of next.marches) {
      const before = prevMarches.get(m.id);
      if (!before) {
        await this.db.march.create({ data: { id: m.id, castleId, ...marchData(m) } });
      } else if (JSON.stringify(before) !== JSON.stringify(m)) {
        await this.db.march.update({ where: { id: m.id }, data: marchData(m) });
      }
    }

    // герой
    const h = next.hero;
    if (h && JSON.stringify(h) !== JSON.stringify(prev.hero)) {
      const data = {
        level: h.level,
        xp: h.xp,
        skillCombat: h.skills.combat,
        skillDefense: h.skills.defense,
        skillEconomy: h.skills.economy,
      };
      await this.db.hero.upsert({
        where: { castleId },
        update: data,
        create: { castleId, ...data },
      });
      const prevItems = new Map((prev.hero?.items ?? []).map((i) => [i.id, i]));
      for (const item of h.items) {
        const old = prevItems.get(item.id);
        if (old && old.equipped === item.equipped) continue;
        await this.db.heroItem.upsert({
          where: { id: item.id },
          update: { equipped: item.equipped },
          create: {
            id: item.id,
            castleId,
            slot: item.slot,
            rarity: item.rarity,
            equipped: item.equipped,
          },
        });
      }
    }
  }

  /** Общая запись очереди: удалить исчезнувшие, добавить новые, обновить сдвинувшиеся по времени. */
  private async syncTasks<T extends { id: string; startedAt: Date; finishesAt: Date }>(
    prev: readonly T[],
    next: readonly T[],
    remove: (ids: string[]) => Promise<unknown>,
    add: (rows: T[]) => Promise<unknown>,
    move: (row: T) => Promise<unknown>,
  ): Promise<void> {
    const nextIds = new Set(next.map((t) => t.id));
    const prevById = new Map(prev.map((t) => [t.id, t]));
    const removed = prev.filter((t) => !nextIds.has(t.id)).map((t) => t.id);
    if (removed.length > 0) await remove(removed);
    const added = next.filter((t) => !prevById.has(t.id));
    if (added.length > 0) await add(added);
    for (const t of next) {
      const before = prevById.get(t.id);
      if (
        before &&
        (before.finishesAt.getTime() !== t.finishesAt.getTime() ||
          before.startedAt.getTime() !== t.startedAt.getTime())
      ) {
        await move(t);
      }
    }
  }

  // ── Карта, походы, отчёты ──────────────────────────────────────────────────

  private toSpot(c: {
    id: string;
    userId: string;
    x: number | null;
    y: number | null;
    shieldUntil: Date | null;
    user: { nickname: string };
  }): CastleSpot {
    return {
      castleId: c.id,
      userId: c.userId,
      nickname: c.user.nickname,
      x: c.x ?? 0,
      y: c.y ?? 0,
      shieldUntil: c.shieldUntil,
    };
  }

  private static readonly SPOT_SELECT = {
    id: true,
    userId: true,
    x: true,
    y: true,
    shieldUntil: true,
    user: { select: { nickname: true } },
  } as const;

  async occupiedSpots(worldId: string): Promise<Point[]> {
    const rows = await this.db.castle.findMany({
      where: { worldId, x: { not: null }, y: { not: null } },
      select: { x: true, y: true },
    });
    return rows.map((r) => ({ x: r.x ?? 0, y: r.y ?? 0 }));
  }

  async spotsIn(
    worldId: string,
    x0: number,
    y0: number,
    x1: number,
    y1: number,
  ): Promise<CastleSpot[]> {
    const rows = await this.db.castle.findMany({
      where: { worldId, x: { gte: x0, lt: x1 }, y: { gte: y0, lt: y1 } },
      select: PrismaCastleTx.SPOT_SELECT,
    });
    return rows.map((r) => this.toSpot(r));
  }

  async spotAt(worldId: string, x: number, y: number): Promise<CastleSpot | null> {
    const r = await this.db.castle.findFirst({
      where: { worldId, x, y },
      select: PrismaCastleTx.SPOT_SELECT,
    });
    return r ? this.toSpot(r) : null;
  }

  async searchSpots(worldId: string, query: string, limit: number): Promise<CastleSpot[]> {
    const rows = await this.db.castle.findMany({
      where: {
        worldId,
        x: { not: null },
        // По ключу ника (D-21), а не ILIKE: не зависит от локали БД
        user: { nicknameKey: { contains: nicknameKey(query) } },
      },
      select: PrismaCastleTx.SPOT_SELECT,
      orderBy: { user: { nickname: 'asc' } },
      take: limit,
    });
    return rows.map((r) => this.toSpot(r));
  }

  async dueArrivals(
    worldId: string,
    now: Date,
    limit: number,
    userId?: string,
  ): Promise<Array<{ marchId: string; attackerUserId: string }>> {
    const rows = await this.db.march.findMany({
      where: {
        state: 'outbound',
        arriveAt: { lte: now },
        castle: { worldId },
        ...(userId
          ? {
              OR: [
                { castle: { userId } },
                { targetCastleId: { in: await this.castleIdsOf(userId) } },
              ],
            }
          : {}),
      },
      orderBy: { arriveAt: 'asc' },
      take: limit,
      select: { id: true, castle: { select: { userId: true } } },
    });
    return rows.map((r) => ({ marchId: r.id, attackerUserId: r.castle.userId }));
  }

  private async castleIdsOf(userId: string): Promise<string[]> {
    const rows = await this.db.castle.findMany({ where: { userId }, select: { id: true } });
    return rows.map((r) => r.id);
  }

  async cellStates(
    worldId: string,
    x0: number,
    y0: number,
    x1: number,
    y1: number,
  ): Promise<CellStateRecord[]> {
    const rows = await this.db.cellState.findMany({
      where: { worldId, x: { gte: x0, lt: x1 }, y: { gte: y0, lt: y1 } },
    });
    return rows.map((r) => ({ x: r.x, y: r.y, remaining: r.remaining, resetAt: r.resetAt }));
  }

  async saveCellState(worldId: string, st: CellStateRecord): Promise<void> {
    await this.db.cellState.upsert({
      where: { worldId_x_y: { worldId, x: st.x, y: st.y } },
      update: { remaining: st.remaining, resetAt: st.resetAt },
      create: { worldId, x: st.x, y: st.y, remaining: st.remaining, resetAt: st.resetAt },
    });
  }

  private toReport(r: {
    id: string;
    userId: string;
    worldId: string;
    kind: string;
    role: string;
    outcome: string;
    targetX: number;
    targetY: number;
    opponent: string | null;
    payload: Prisma.JsonValue;
    read: boolean;
    createdAt: Date;
  }): ReportRecord {
    return {
      id: r.id,
      userId: r.userId,
      worldId: r.worldId,
      kind: r.kind as ReportRecord['kind'],
      role: r.role as ReportRecord['role'],
      outcome: r.outcome as ReportRecord['outcome'],
      target: { x: r.targetX, y: r.targetY },
      opponent: r.opponent,
      payload: r.payload as unknown as ReportDetailDto,
      read: r.read,
      createdAt: r.createdAt,
    };
  }

  async addReports(rows: ReportRecord[]): Promise<void> {
    if (rows.length === 0) return;
    await this.db.report.createMany({
      data: rows.map((r) => ({
        id: r.id,
        userId: r.userId,
        worldId: r.worldId,
        kind: r.kind,
        role: r.role,
        outcome: r.outcome,
        targetX: r.target.x,
        targetY: r.target.y,
        opponent: r.opponent,
        payload: r.payload as unknown as Prisma.InputJsonValue,
        read: r.read,
        createdAt: r.createdAt,
      })),
    });
  }

  async listReports(userId: string, page: number, pageSize: number) {
    const [rows, total, unread] = await Promise.all([
      this.db.report.findMany({
        where: { userId },
        orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      this.db.report.count({ where: { userId } }),
      this.db.report.count({ where: { userId, read: false } }),
    ]);
    return { items: rows.map((r) => this.toReport(r)), total, unread };
  }

  async getReport(userId: string, id: string): Promise<ReportRecord | null> {
    const r = await this.db.report.findFirst({ where: { id, userId } });
    return r ? this.toReport(r) : null;
  }

  async markReportRead(userId: string, id: string): Promise<void> {
    await this.db.report.updateMany({ where: { id, userId }, data: { read: true } });
  }

  async logEconomy(events: EconomyEventRecord[]): Promise<void> {
    if (events.length === 0) return;
    await this.db.economyEvent.createMany({ data: events });
  }

  async findIdempotent(
    userId: string,
    key: string,
    notBefore: Date,
  ): Promise<StoredResponse | null> {
    // Просроченная запись удаляется, чтобы тот же ключ можно было занять заново
    await this.db.idempotencyKey.deleteMany({
      where: { userId, key, createdAt: { lt: notBefore } },
    });
    const row = await this.db.idempotencyKey.findUnique({ where: { userId_key: { userId, key } } });
    return row
      ? {
          route: row.route,
          requestHash: row.requestHash,
          status: row.status,
          body: row.body,
          createdAt: row.createdAt,
        }
      : null;
  }

  async storeIdempotent(userId: string, key: string, r: StoredResponse): Promise<void> {
    try {
      await this.db.idempotencyKey.create({
        data: {
          userId,
          key,
          route: r.route,
          requestHash: r.requestHash,
          status: r.status,
          body: r.body as Prisma.InputJsonValue,
          createdAt: r.createdAt,
        },
      });
    } catch (err) {
      if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === 'P2002') {
        throw new IdempotencyRace();
      }
      throw err;
    }
  }
}

export class PrismaCastleRepository implements CastleRepository {
  constructor(private readonly db: PrismaClient) {}

  transaction<T>(fn: (tx: CastleTx) => Promise<T>): Promise<T> {
    return this.db
      .$transaction((client) => fn(new PrismaCastleTx(client)), {
        maxWait: 5000,
        timeout: 10_000,
      })
      .catch((err: unknown) => {
        // P2034: взаимная блокировка / конфликт записи (MySQL) — то же, что параллельное изменение замка
        if ((err as { code?: string } | null)?.code === 'P2034') throw new VersionConflict();
        throw err;
      });
  }

  async deleteExpiredIdempotency(before: Date): Promise<number> {
    const r = await this.db.idempotencyKey.deleteMany({ where: { createdAt: { lt: before } } });
    return r.count;
  }
}
