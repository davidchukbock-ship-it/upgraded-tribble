import type { MapVersion } from '@tc/shared';
import type { AdminStore } from '../admin/admin.types';
import type { ProgressStore } from '../progress/progress.types';
import type { SocialTx } from '../social/social.types';
import type {
  Army,
  MarchType,
  Point,
  ReportDetailDto,
  ReportKind,
  ReportRole,
  UnitCounts,
  BuildingKey,
  BuildingLevels,
  HeroState,
  ResourceAmounts,
  ResourceKey,
  TechKey,
  TechLevels,
  UnitId,
  PlacedStructure,
} from '@tc/shared';

export interface BuildTaskRecord {
  id: string;
  key: BuildingKey;
  toLevel: number;
  startedAt: Date;
  finishesAt: Date;
  /** Потрачено при постановке — основа возврата при отмене. */
  paid: ResourceAmounts;
  isGodAction: boolean;
}

export interface TrainTaskRecord {
  id: string;
  unit: UnitId;
  count: number;
  startedAt: Date;
  finishesAt: Date;
  paid: ResourceAmounts;
  isGodAction: boolean;
}

export interface ResearchTaskRecord {
  id: string;
  tech: TechKey;
  toLevel: number;
  startedAt: Date;
  finishesAt: Date;
  paid: ResourceAmounts;
  isGodAction: boolean;
}

export interface MarchRecord {
  id: string;
  type: MarchType;
  target: Point;
  targetCastleId: string | null;
  targetName: string | null;
  /** Отряд; после боя — выжившие. */
  units: UnitCounts;
  /** Раненые, которые вернутся вместе с отрядом. */
  wounded: UnitCounts;
  /** Добыча или награда, которую отряд везёт домой. */
  loot: ResourceAmounts;
  heroXp: number;
  state: 'outbound' | 'returning';
  startedAt: Date;
  arriveAt: Date;
  returnAt: Date;
  reportId: string | null;
}

/** Замок целиком: то, что читается и записывается одной транзакцией. */
export interface CastleAggregate {
  id: string;
  userId: string;
  worldId: string;
  worldSpeed: number;
  /** Seed карты мира (из строки World). */
  worldSeed: number;
  /** Версия генератора карты мира (D-74). */
  worldMapVersion: MapVersion;
  /** Координаты на карте; null — замок ещё не размещён. */
  x: number | null;
  y: number | null;
  resources: ResourceAmounts;
  gems: number;
  /** Накопленная доля кристалла от Алмазной шахты (0…1). */
  gemsCarry: number;
  /** Постройки города на свободных клетках острова (D-66). */
  structures: PlacedStructure[];
  resourcesUpdatedAt: Date;
  shieldUntil: Date | null;
  extraBuildSlot: boolean;
  /** Мощь: пересчитывается при каждой записи замка. */
  power: number;
  /** Оптимистичная блокировка (D-06). */
  version: number;
  isGodAction: boolean;
  levels: BuildingLevels;
  tasks: BuildTaskRecord[];
  /** Войска в строю и раненые. */
  army: Army;
  /** Партии в обучении — одна цепочка: каждая начинается, когда закончилась предыдущая. */
  trains: TrainTaskRecord[];
  tech: TechLevels;
  research: ResearchTaskRecord[];
  /** null — герой ещё не создан (создаётся при первом обращении). */
  hero: HeroState | null;
  marches: MarchRecord[];
}

export interface EconomyEventRecord {
  worldId: string;
  userId: string;
  kind: string;
  resource: ResourceKey | 'gems';
  /** Отрицательное — расход игрока. */
  amount: number;
  isGodAction: boolean;
  createdAt: Date;
}

export interface StoredResponse {
  route: string;
  requestHash: string;
  status: number;
  body: unknown;
  createdAt: Date;
}

/** Замок изменили параллельно: транзакцию нужно повторить с чистым чтением. */
export class VersionConflict extends Error {
  constructor() {
    super('Castle version conflict');
    this.name = 'VersionConflict';
  }
}

/** Тот же Idempotency-Key успел сохранить другой запрос: повтор вернёт его ответ. */
export class IdempotencyRace extends Error {
  constructor() {
    super('Idempotency key raced');
    this.name = 'IdempotencyRace';
  }
}

/** Замок на карте (для показа и поиска цели). */
export interface CastleSpot {
  castleId: string;
  userId: string;
  nickname: string;
  x: number;
  y: number;
  shieldUntil: Date | null;
}

/** Изменяемое состояние клетки: возрождение лагеря, остаток и наполнение ресурсной точки. */
export interface CellStateRecord {
  x: number;
  y: number;
  remaining: number | null;
  resetAt: Date | null;
}

export interface ReportRecord {
  id: string;
  userId: string;
  worldId: string;
  kind: ReportKind;
  role: ReportRole;
  outcome: 'win' | 'loss' | 'done';
  target: Point;
  opponent: string | null;
  payload: ReportDetailDto;
  read: boolean;
  createdAt: Date;
}

export interface CastleTx extends SocialTx {
  progress: ProgressStore;
  admin: AdminStore;
  load(userId: string, worldId: string): Promise<CastleAggregate | null>;
  /** Записывает разницу prev → next. Бросает VersionConflict, если замок изменился после чтения. */
  save(prev: CastleAggregate, next: CastleAggregate): Promise<void>;
  logEconomy(events: EconomyEventRecord[]): Promise<void>;
  /** Игроки, у которых что-то достроилось по расчёту, но ещё не записано: их надо «прочитать» (уведомления офлайн-игрокам). */
  dueCastleUsers(worldId: string, now: Date, limit: number): Promise<string[]>;

  // ── Карта, походы, отчёты ──
  loadById(castleId: string): Promise<CastleAggregate | null>;
  /** Занятые клетки мира (для размещения нового замка). */
  occupiedSpots(worldId: string): Promise<Point[]>;
  /** Замки в прямоугольнике [x0, x1) × [y0, y1). */
  spotsIn(worldId: string, x0: number, y0: number, x1: number, y1: number): Promise<CastleSpot[]>;
  spotAt(worldId: string, x: number, y: number): Promise<CastleSpot | null>;
  /** Поиск замков по части ника (без учёта регистра). */
  searchSpots(worldId: string, query: string, limit: number): Promise<CastleSpot[]>;
  /** Походы, которые уже прибыли, но ещё не разрешены; userId — только затрагивающие этого игрока. */
  dueArrivals(
    worldId: string,
    now: Date,
    limit: number,
    userId?: string,
  ): Promise<Array<{ marchId: string; attackerUserId: string }>>;
  cellStates(
    worldId: string,
    x0: number,
    y0: number,
    x1: number,
    y1: number,
  ): Promise<CellStateRecord[]>;
  saveCellState(worldId: string, state: CellStateRecord): Promise<void>;
  addReports(rows: ReportRecord[]): Promise<void>;
  listReports(
    userId: string,
    page: number,
    pageSize: number,
  ): Promise<{ items: ReportRecord[]; total: number; unread: number }>;
  getReport(userId: string, id: string): Promise<ReportRecord | null>;
  markReportRead(userId: string, id: string): Promise<void>;
  /** Сохранённый ответ не старше notBefore (просроченные не возвращаются). */
  findIdempotent(userId: string, key: string, notBefore: Date): Promise<StoredResponse | null>;
  /** Бросает IdempotencyRace, если ключ уже занят. */
  storeIdempotent(userId: string, key: string, response: StoredResponse): Promise<void>;
}

export interface CastleRepository {
  transaction<T>(fn: (tx: CastleTx) => Promise<T>): Promise<T>;
  deleteExpiredIdempotency(before: Date): Promise<number>;
}
