import { randomUUID } from 'node:crypto';
import {
  CAMP_RESPAWN_SECONDS,
  MAIN_WORLD_ID,
  NODE_RESPAWN_SECONDS,
  NO_ATTACK_BONUS,
  UNIT_TYPES,
  campForces,
  campReward,
  cargoOf,
  cellAtV,
  dayKey,
  fuzzUnits,
  gatherAmount,
  gatherSeconds,
  hashSeed,
  heroBonuses,
  nodeCapacity,
  plunder,
  seasonId,
  simulateBattle,
  siegeShare,
  splitCasualties,
  techEffects,
  totalUnits,
  warehouseCap,
  cavalryShare,
  towersBonus,
  wallsBonus,
  type BattleResult,
  type ReportDetailDto,
  type ReportKind,
  type UnitCounts,
  type UnitId,
  type UnitType,
} from '@tc/shared';
import type { Clock } from '../../lib/clock';
import {
  settleAggregate,
  starterHero,
  woundedRoom,
  type SettleEvent,
} from '../castle/castle.realm';
import {
  VersionConflict,
  type CastleAggregate,
  type CastleRepository,
  type CastleTx,
  type MarchRecord,
  type ReportRecord,
} from '../castle/castle.types';
import type { NotificationRecord } from '../social/social.types';

/** Уведомления по событиям расчёта (постройки, возвращения), которые случились при разборе похода. */
function noteRecords(userId: string, events: readonly SettleEvent[]): NotificationRecord[] {
  return events.map((e) => ({
    id: randomUUID(),
    userId,
    kind: e.kind,
    payload: e.payload,
    read: false,
    createdAt: e.at,
  }));
}

const BATCH = 25;
const MAX_ROUNDS = 20;
const HERO_XP_LOSS = 5;

interface Bonuses {
  attack: Record<UnitType, number>;
  defense: number;
}

/** Бонусы стороны: Кузница, технологии, герой (docs/GAME_DESIGN.md §4). */
export function bonusesOf(agg: CastleAggregate): Bonuses {
  const tech = techEffects(agg.tech);
  const hero = agg.hero ? heroBonuses(agg.hero) : { attack: 0, defense: 0 };
  const forge = (agg.levels.forge ?? 0) * 0.015;
  const attack = { ...NO_ATTACK_BONUS };
  for (const t of UNIT_TYPES) attack[t] = forge + tech.attack[t] + hero.attack;
  return { attack, defense: tech.defense + hero.defense };
}

const healthy = (agg: CastleAggregate): UnitCounts => {
  const out: UnitCounts = {};
  for (const [id, s] of Object.entries(agg.army)) if (s && s.count > 0) out[id as UnitId] = s.count;
  return out;
};

const isEmpty = (u: UnitCounts): boolean => totalUnits(u) === 0;

interface Ctx {
  tx: CastleTx;
  now: Date;
  att: CastleAggregate;
  m: MarchRecord;
  worldId: string;
  /** Другие затронутые замки: (что прочитали, что записать). */
  extra: Array<{ prev: CastleAggregate; next: CastleAggregate }>;
  reports: ReportRecord[];
  notes: NotificationRecord[];
}

const emptyDetail = (): ReportDetailDto => ({
  rounds: [],
  attacker: null,
  defender: null,
  loot: { gold: 0, wood: 0, stone: 0, food: 0 },
  heroXp: 0,
  wounded: {},
  dead: {},
  scout: null,
  gathered: null,
  campLevel: null,
});

/**
 * Разрешение походов, которые уже прибыли (D-35). Идёт по таймеру и перед любым чтением/изменением
 * замка, которого поход касается. Каждый поход — одна транзакция, затрагивающая оба замка
 * с оптимистичной блокировкой: параллельный запрос либо увидит результат, либо повторится.
 */
export class MarchResolver {
  private readonly worldId: string;

  constructor(
    private readonly deps: {
      repo: CastleRepository;
      clock: Clock;
      worldId?: string;
      log?: (msg: string, err?: unknown) => void;
      /** Доставка уведомлений онлайн-игрокам после фиксации боя. */
      onNotify?: (userId: string, notes: NotificationRecord[]) => void;
    },
  ) {
    this.worldId = deps.worldId ?? MAIN_WORLD_ID;
  }

  resolveFor(userId: string): Promise<number> {
    return this.run(userId);
  }

  resolveAll(): Promise<number> {
    return this.run(undefined);
  }

  private async run(userId: string | undefined): Promise<number> {
    let done = 0;
    for (let round = 0; round < MAX_ROUNDS; round++) {
      const now = this.deps.clock.now();
      const refs = await this.deps.repo.transaction((tx) =>
        tx.dueArrivals(this.worldId, now, BATCH, userId),
      );
      if (refs.length === 0) break;
      let progress = 0;
      for (const ref of refs) {
        try {
          if (await this.resolveOne(ref.attackerUserId, ref.marchId)) progress++;
        } catch (err) {
          // Конфликт версий — попробуем на следующем круге; прочее логируем, чтобы один сбойный поход
          // не блокировал чтение замков.
          if (!(err instanceof VersionConflict)) this.deps.log?.('march resolve failed', err);
        }
      }
      done += progress;
      if (progress === 0) break;
    }
    return done;
  }

  private async resolveOne(attackerUserId: string, marchId: string): Promise<boolean> {
    let pending: NotificationRecord[] = [];
    const done = await this.deps.repo.transaction(async (tx) => {
      pending = [];
      const now = this.deps.clock.now();
      const attacker = await tx.load(attackerUserId, this.worldId);
      const found = attacker?.marches.find((m) => m.id === marchId);
      if (!attacker || !found || found.state !== 'outbound' || found.arriveAt > now) return false;

      const settledAtt = settleAggregate(attacker, now);
      const att = settledAtt.draft;
      att.hero ??= starterHero();
      const m = att.marches.find((x) => x.id === marchId);
      if (!m) return false;
      const ctx: Ctx = {
        tx,
        now,
        att,
        m,
        worldId: this.worldId,
        extra: [],
        reports: [],
        notes: [],
      };

      switch (m.type) {
        case 'attack':
          await this.attack(ctx);
          break;
        case 'scout':
          await this.scout(ctx);
          break;
        case 'monster':
          await this.monster(ctx);
          break;
        case 'gather':
          await this.gather(ctx);
          break;
      }

      // Отряд идёт домой; если некому возвращаться — поход исчезает
      m.state = 'returning';
      if (isEmpty(m.units) && isEmpty(m.wounded)) att.marches = att.marches.filter((x) => x !== m);
      const settledFinal = settleAggregate(att, now);
      const final = settledFinal.draft;
      ctx.notes.push(...noteRecords(att.userId, settledFinal.events));
      await tx.save(attacker, final);
      for (const e of ctx.extra) await tx.save(e.prev, e.next);
      await tx.addReports(ctx.reports);
      await tx.notifications.add(ctx.notes);
      pending = ctx.notes;
      return true;
    });
    for (const n of pending) this.deps.onNotify?.(n.userId, [n]);
    return done;
  }

  // ── Бой с игроком ──────────────────────────────────────────────────────────

  private async loadTarget(
    ctx: Ctx,
  ): Promise<{ prev: CastleAggregate; next: CastleAggregate } | null> {
    if (!ctx.m.targetCastleId) return null;
    const prev = await ctx.tx.loadById(ctx.m.targetCastleId);
    if (!prev) return null;
    const settled = settleAggregate(prev, ctx.now);
    const next = settled.draft;
    next.hero ??= starterHero();
    ctx.notes.push(...noteRecords(next.userId, settled.events));
    return { prev, next };
  }

  private async attack(ctx: Ctx): Promise<void> {
    const target = await this.loadTarget(ctx);
    // Цель исчезла или под щитом: бой не состоялся, отряд возвращается
    if (!target || (target.next.shieldUntil && target.next.shieldUntil > ctx.now)) return;
    const { att, m } = ctx;
    const def = target.next;
    const attUnits = { ...m.units };
    const ab = bonusesOf(att);
    const db = bonusesOf(def);
    const result = simulateBattle({
      attacker: { units: attUnits, attackBonus: ab.attack, defenseBonus: ab.defense },
      defender: {
        units: healthy(def),
        attackBonus: db.attack,
        defenseBonus:
          db.defense +
          wallsBonus(def.levels.walls ?? 0, techEffects(def.tech).walls, siegeShare(attUnits)) +
          towersBonus(def.levels, cavalryShare(attUnits), siegeShare(attUnits)),
      },
      seed: hashSeed(m.id),
    });
    const won = result.winner === 'attacker';

    const attSplit = splitCasualties(result.attacker.fallen, woundedRoom(att));
    m.units = result.attacker.remaining;
    m.wounded = attSplit.wounded;

    const defSplit = splitCasualties(result.defender.fallen, woundedRoom(def));
    for (const [id, n] of Object.entries(result.defender.fallen)) {
      const cur = def.army[id as UnitId];
      if (!cur) continue;
      def.army[id as UnitId] = {
        count: cur.count - (n ?? 0),
        wounded: cur.wounded + (defSplit.wounded[id as UnitId] ?? 0),
      };
    }

    let loot = { gold: 0, wood: 0, stone: 0, food: 0 };
    if (won) {
      const cap = warehouseCap(def.levels.warehouse ?? 1, {
        warehouse: techEffects(def.tech).warehouse,
      });
      loot = plunder(
        def.resources,
        { gold: cap, wood: cap, stone: cap, food: cap },
        cargoOf(m.units),
      );
      for (const r of ['gold', 'wood', 'stone', 'food'] as const)
        def.resources = { ...def.resources, [r]: def.resources[r] - loot[r] };
      m.loot = loot;
    }
    m.heroXp = won ? 20 + Math.floor(totalUnits(result.defender.fallen) / 10) : HERO_XP_LOSS;
    ctx.extra.push({ prev: target.prev, next: def });
    await this.recordBattle(ctx, att.userId, won, totalUnits(result.defender.fallen));
    await this.recordBattle(ctx, def.userId, !won, totalUnits(result.attacker.fallen));

    const attSpot =
      att.x !== null && att.y !== null ? await ctx.tx.spotAt(ctx.worldId, att.x, att.y) : null;
    const attReport = this.report(ctx, att.userId, 'battle', 'attacker', won ? 'win' : 'loss', {
      opponent: m.targetName,
      detail: this.detail(result, loot, m.heroXp, attSplit.wounded, attSplit.dead),
    });
    m.reportId = attReport.id;
    const defReport = this.report(ctx, def.userId, 'battle', 'defender', won ? 'loss' : 'win', {
      opponent: attSpot?.nickname ?? null,
      detail: this.detail(result, loot, 0, defSplit.wounded, defSplit.dead),
    });
    ctx.notes.push({
      id: randomUUID(),
      userId: def.userId,
      kind: 'march.attacked',
      payload: { attacker: attSpot?.nickname ?? '', won: !won, reportId: defReport.id },
      read: false,
      createdAt: ctx.now,
    });
  }

  /** Победа и убийства идут в задания и в сезонную таблицу лиги. */
  private async recordBattle(ctx: Ctx, userId: string, won: boolean, kills: number): Promise<void> {
    const { tx, now } = ctx;
    if (won) await tx.progress.bump(userId, ['total', dayKey(now)], 'win', 1);
    if (won || kills > 0)
      await tx.progress.addSeasonStat(seasonId(now), userId, { wins: won ? 1 : 0, kills });
  }

  private detail(
    result: BattleResult,
    loot: { gold: number; wood: number; stone: number; food: number },
    heroXp: number,
    wounded: UnitCounts,
    dead: UnitCounts,
  ): ReportDetailDto {
    return {
      ...emptyDetail(),
      rounds: result.rounds,
      attacker: result.attacker,
      defender: result.defender,
      loot,
      heroXp,
      wounded,
      dead,
    };
  }

  private report(
    ctx: Ctx,
    userId: string,
    kind: ReportKind,
    role: 'attacker' | 'defender',
    outcome: 'win' | 'loss' | 'done',
    extra: { opponent: string | null; detail: ReportDetailDto },
  ): ReportRecord {
    const rec: ReportRecord = {
      id: randomUUID(),
      userId,
      worldId: ctx.worldId,
      kind,
      role,
      outcome,
      target: { ...ctx.m.target },
      opponent: extra.opponent,
      payload: extra.detail,
      read: false,
      createdAt: ctx.now,
    };
    ctx.reports.push(rec);
    return rec;
  }

  // ── Разведка ───────────────────────────────────────────────────────────────

  private async scout(ctx: Ctx): Promise<void> {
    const target = await this.loadTarget(ctx);
    if (!target) return;
    const def = target.next;
    const detail: ReportDetailDto = {
      ...emptyDetail(),
      scout: {
        units: fuzzUnits(healthy(def), hashSeed(ctx.m.id)),
        resources: {
          gold: Math.floor(def.resources.gold),
          wood: Math.floor(def.resources.wood),
          stone: Math.floor(def.resources.stone),
          food: Math.floor(def.resources.food),
        },
      },
    };
    const rec = this.report(ctx, ctx.att.userId, 'scout', 'attacker', 'done', {
      opponent: ctx.m.targetName,
      detail,
    });
    ctx.m.reportId = rec.id;
  }

  // ── Лагерь монстров ────────────────────────────────────────────────────────

  private async monster(ctx: Ctx): Promise<void> {
    const { att, m, tx, now } = ctx;
    const cell = cellAtV(att.worldMapVersion, att.worldSeed, m.target.x, m.target.y);
    if (cell.kind !== 'camp') return;
    const [state] = await tx.cellStates(
      ctx.worldId,
      m.target.x,
      m.target.y,
      m.target.x + 1,
      m.target.y + 1,
    );
    if (state?.resetAt && state.resetAt > now) return; // уже повержен

    const ab = bonusesOf(att);
    const result = simulateBattle({
      attacker: { units: { ...m.units }, attackBonus: ab.attack, defenseBonus: ab.defense },
      defender: { units: campForces(cell.level), attackBonus: NO_ATTACK_BONUS, defenseBonus: 0 },
      seed: hashSeed(m.id),
    });
    const won = result.winner === 'attacker';
    const split = splitCasualties(result.attacker.fallen, woundedRoom(att));
    m.units = result.attacker.remaining;
    m.wounded = split.wounded;
    await this.recordBattle(ctx, att.userId, won, totalUnits(result.defender.fallen));

    let loot = { gold: 0, wood: 0, stone: 0, food: 0 };
    if (won) {
      const reward = campReward(cell.level);
      loot = reward.resources;
      m.loot = loot;
      m.heroXp = reward.heroXp;
      await tx.saveCellState(ctx.worldId, {
        x: m.target.x,
        y: m.target.y,
        remaining: null,
        resetAt: new Date(now.getTime() + CAMP_RESPAWN_SECONDS * 1000),
      });
    } else {
      m.heroXp = HERO_XP_LOSS;
    }
    const detail = {
      ...this.detail(result, loot, m.heroXp, split.wounded, split.dead),
      campLevel: cell.level,
    };
    const rec = this.report(ctx, att.userId, 'monster', 'attacker', won ? 'win' : 'loss', {
      opponent: null,
      detail,
    });
    m.reportId = rec.id;
  }

  // ── Ресурсная точка ────────────────────────────────────────────────────────

  private async gather(ctx: Ctx): Promise<void> {
    const { att, m, tx, now } = ctx;
    const cell = cellAtV(att.worldMapVersion, att.worldSeed, m.target.x, m.target.y);
    if (cell.kind !== 'resource' || !cell.resource) return;
    const [state] = await tx.cellStates(
      ctx.worldId,
      m.target.x,
      m.target.y,
      m.target.x + 1,
      m.target.y + 1,
    );
    const refilled = !state || state.remaining === null || (state.resetAt && state.resetAt <= now);
    const remaining = refilled ? nodeCapacity(cell.level) : (state.remaining ?? 0);
    const amount = gatherAmount(m.units, remaining);

    await tx.progress.bump(att.userId, ['total', dayKey(now)], 'gather', 1);
    m.loot = { gold: 0, wood: 0, stone: 0, food: 0, [cell.resource]: amount };
    // Сбор занимает время на месте: отряд задерживается до возвращения домой
    m.returnAt = new Date(m.returnAt.getTime() + gatherSeconds(amount) * 1000);
    await tx.saveCellState(ctx.worldId, {
      x: m.target.x,
      y: m.target.y,
      remaining: remaining - amount,
      resetAt: new Date(now.getTime() + NODE_RESPAWN_SECONDS * 1000),
    });
    const rec = this.report(ctx, att.userId, 'gather', 'attacker', 'done', {
      opponent: null,
      detail: { ...emptyDetail(), gathered: { resource: cell.resource, amount } },
    });
    m.reportId = rec.id;
  }
}
