import type { FastifyInstance } from 'fastify';
import type { ZodTypeProvider } from 'fastify-type-provider-zod';
import { z } from 'zod';
import { sendResult } from '../castle/castle.controller';
import { castleSchema, errorSchema, failures, idempotencyHeaders } from '../castle/castle.schema';
import type { CastleService } from '../castle/castle.service';
import type { MapService } from './map.service';
import {
  overviewSchema,
  cellParams,
  mapCellSchema,
  marchBody,
  marchesSchema,
  reportPageQuery,
  reportPageSchema,
  reportSchema,
  searchQuery,
  searchSchema,
  tilesQuery,
  tilesSchema,
} from './march.schema';
import type { MarchService } from './march.service';
import type { ReportService } from './report.service';

export function registerMarchRoutes(
  app: FastifyInstance,
  deps: {
    march: MarchService;
    map: MapService;
    reports: ReportService;
    castle: CastleService;
    /** Разрешает прибывшие походы игрока: отчёты и карта должны быть свежими. */
    before: (userId: string) => Promise<void>;
  },
): void {
  const r = app.withTypeProvider<ZodTypeProvider>();
  const security = [{ bearerAuth: [] }];
  const read = { 401: errorSchema, 404: errorSchema };

  r.get(
    '/marches',
    {
      preHandler: app.authenticate,
      schema: {
        tags: ['march'],
        summary: 'Мои походы',
        security,
        response: { 200: marchesSchema, ...read },
      },
    },
    async (req) => (await deps.castle.view(req.auth!.user.id)).marches,
  );

  r.post(
    '/marches',
    {
      preHandler: app.authenticate,
      schema: {
        tags: ['march'],
        summary: 'Отправить отряд: attack, scout, monster или gather',
        security,
        headers: idempotencyHeaders,
        body: marchBody,
        response: { 200: castleSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await deps.march.send(req.auth!.user.id, req.body, req.headers['idempotency-key']),
      ),
  );

  r.get(
    '/map/tiles',
    {
      preHandler: app.authenticate,
      schema: {
        tags: ['map'],
        summary: 'Участок карты (по умолчанию 20×20)',
        security,
        querystring: tilesQuery,
        response: { 200: tilesSchema, ...read },
      },
    },
    async (req) => {
      await deps.before(req.auth!.user.id);
      return deps.map.tiles(req.auth!.user.id, req.query.x, req.query.y, req.query.size);
    },
  );

  r.get(
    '/map/overview',
    {
      preHandler: app.authenticate,
      schema: {
        tags: ['map'],
        summary: 'Обзор мира для мини-карты',
        security,
        response: { 200: overviewSchema, ...read },
      },
    },
    async (req) => {
      await deps.before(req.auth!.user.id);
      return deps.map.overview(req.auth!.user.id);
    },
  );

  r.get(
    '/map/cell/:x/:y',
    {
      preHandler: app.authenticate,
      schema: {
        tags: ['map'],
        summary: 'Клетка карты',
        security,
        params: cellParams,
        response: { 200: mapCellSchema, ...read },
      },
    },
    async (req) => {
      await deps.before(req.auth!.user.id);
      return deps.map.cell(req.auth!.user.id, req.params.x, req.params.y);
    },
  );

  r.get(
    '/map/search',
    {
      preHandler: app.authenticate,
      schema: {
        tags: ['map'],
        summary: 'Поиск по нику или координатам «x,y»',
        security,
        querystring: searchQuery,
        response: { 200: searchSchema, ...read },
      },
    },
    async (req) => deps.map.search(req.query.q),
  );

  r.get(
    '/reports',
    {
      preHandler: app.authenticate,
      schema: {
        tags: ['battle'],
        summary: 'Боевые отчёты (страницами)',
        security,
        querystring: reportPageQuery,
        response: { 200: reportPageSchema, ...read },
      },
    },
    async (req) => {
      await deps.before(req.auth!.user.id);
      return deps.reports.list(req.auth!.user.id, req.query.page, req.query.pageSize);
    },
  );

  r.get(
    '/reports/:id',
    {
      preHandler: app.authenticate,
      schema: {
        tags: ['battle'],
        summary: 'Отчёт (помечается прочитанным)',
        security,
        params: z.object({ id: z.string().uuid() }),
        response: { 200: reportSchema, ...read },
      },
    },
    async (req) => {
      await deps.before(req.auth!.user.id);
      return deps.reports.get(req.auth!.user.id, req.params.id);
    },
  );
}
