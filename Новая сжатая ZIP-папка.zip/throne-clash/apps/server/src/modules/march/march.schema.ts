import { z } from 'zod';
import { MARCH_TYPES, MAP_SIZE, MAP_TILE_SIZE } from '@tc/shared';
import { resourceMap, unitCounts } from '../castle/castle.schema';

const coord = z.coerce
  .number()
  .int()
  .min(0)
  .max(MAP_SIZE - 1);

export const marchBody = z
  .object({
    type: z.enum(MARCH_TYPES),
    target: z.object({ x: coord, y: coord }).strict(),
    /** Отряд: { "infantry_1": 20 }. Ключи проверяются сервисом. */
    units: z.record(z.string(), z.number().int().min(1).max(100_000)),
  })
  .strict();

export const tilesQuery = z.object({
  x: coord.default(0),
  y: coord.default(0),
  size: z.coerce.number().int().min(1).max(MAP_TILE_SIZE).default(MAP_TILE_SIZE),
});

export const cellParams = z.object({ x: coord, y: coord });

const mapCell = z.object({
  x: z.number(),
  y: z.number(),
  terrain: z.enum([
    'plain',
    'forest',
    'mountain',
    'water',
    'desert',
    'swamp',
    'sea',
    'lake',
    'river',
  ]),
  road: z.boolean().optional(),
  region: z.number().optional(),
  kind: z.enum(['empty', 'resource', 'camp']),
  level: z.number(),
  resource: z.enum(['gold', 'wood', 'stone', 'food']).nullable(),
  castle: z.object({ nickname: z.string(), isMe: z.boolean(), shielded: z.boolean() }).nullable(),
  busyUntil: z.string().nullable(),
  remaining: z.number().nullable(),
});

export const mapCellSchema = mapCell;

export const tilesSchema = z.object({
  serverTime: z.string(),
  x: z.number(),
  y: z.number(),
  size: z.number(),
  cells: z.array(mapCell),
});

export const overviewSchema = z.object({
  step: z.number(),
  cols: z.number(),
  terrain: z.string(),
});

export const searchQuery = z.object({ q: z.string().trim().min(1).max(40) });
export const searchSchema = z.array(
  z.object({ x: z.number(), y: z.number(), nickname: z.string().nullable() }),
);

export const reportSummary = z.object({
  id: z.string(),
  kind: z.enum(['battle', 'monster', 'scout', 'gather']),
  role: z.enum(['attacker', 'defender']),
  outcome: z.enum(['win', 'loss', 'done']),
  createdAt: z.string(),
  target: z.object({ x: z.number(), y: z.number() }),
  opponent: z.string().nullable(),
  read: z.boolean(),
});

const sideOutcome = z.object({ start: unitCounts, remaining: unitCounts, fallen: unitCounts });

export const reportSchema = reportSummary.extend({
  detail: z.object({
    rounds: z.array(
      z.object({
        round: z.number(),
        attackerLosses: z.number(),
        defenderLosses: z.number(),
        attackerAlive: z.number(),
        defenderAlive: z.number(),
      }),
    ),
    attacker: sideOutcome.nullable(),
    defender: sideOutcome.nullable(),
    loot: resourceMap,
    heroXp: z.number(),
    wounded: unitCounts,
    dead: unitCounts,
    scout: z.object({ units: unitCounts, resources: resourceMap }).nullable(),
    gathered: z
      .object({ resource: z.enum(['gold', 'wood', 'stone', 'food']), amount: z.number() })
      .nullable(),
    campLevel: z.number().nullable(),
  }),
});

export const reportPageQuery = z.object({
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(50).default(20),
});

export const reportPageSchema = z.object({
  items: z.array(reportSummary),
  page: z.number(),
  pageSize: z.number(),
  total: z.number(),
  unread: z.number(),
});

export const marchesSchema = z.array(
  z.object({
    id: z.string(),
    type: z.enum(MARCH_TYPES),
    target: z.object({ x: z.number(), y: z.number() }),
    targetName: z.string().nullable(),
    units: unitCounts,
    loot: resourceMap,
    state: z.enum(['outbound', 'returning']),
    startedAt: z.string(),
    arriveAt: z.string(),
    returnAt: z.string(),
    reportId: z.string().nullable(),
  }),
);
