import { randomUUID } from 'node:crypto';
import {
  MAIN_WORLD_ID,
  MAX_MARCHES,
  MAP_SIZE,
  cellAtV,
  inBounds,
  isOnlyCavalry,
  parseUnitId,
  techEffects,
  totalUnits,
  travelSeconds,
  type MarchType,
  type UnitCounts,
  type UnitId,
} from '@tc/shared';
import type { Clock } from '../../lib/clock';
import { Errors } from '../../lib/errors';
import type { CastleResult, RealmRunner } from '../castle/castle.runner';
import type { CastleRepository } from '../castle/castle.types';

/** Отправка походов. Бой и результат — в MarchResolver, когда отряд прибудет. */
export class MarchService {
  private readonly worldId: string;

  constructor(
    private readonly deps: {
      runner: RealmRunner;
      repo: CastleRepository;
      clock: Clock;
      worldId?: string;
    },
  ) {
    this.worldId = deps.worldId ?? MAIN_WORLD_ID;
  }

  async send(
    userId: string,
    input: { type: MarchType; target: { x: number; y: number }; units: Record<string, number> },
    idemKey: string,
  ): Promise<CastleResult> {
    const { type, target } = input;
    if (!inBounds(target.x, target.y)) throw Errors.validation({ field: 'target' });
    const units = this.cleanUnits(input.units);

    // Что стоит на цели — читаем заранее; в момент прибытия всё проверяется ещё раз
    const info = await this.deps.repo.transaction(async (tx) => ({
      spot: await tx.spotAt(this.worldId, target.x, target.y),
      state: (await tx.cellStates(this.worldId, target.x, target.y, target.x + 1, target.y + 1))[0],
    }));

    const route = `march:${type}:${target.x},${target.y}:${JSON.stringify(
      Object.entries(units).sort(([a], [b]) => (a < b ? -1 : 1)),
    )}`;
    return this.deps.runner.mutate(
      userId,
      route,
      idemKey,
      (draft, now) => {
        if (draft.marches.length >= MAX_MARCHES) throw Errors.queueFull();
        if (draft.x === target.x && draft.y === target.y)
          throw Errors.requirementNotMet({ reason: 'own_castle' });

        for (const [id, n] of Object.entries(units)) {
          if ((draft.army[id as UnitId]?.count ?? 0) < n)
            throw Errors.requirementNotMet({ reason: 'not_enough_units', unit: id });
        }

        let targetCastleId: string | null = null;
        let targetName: string | null = null;
        const cell = cellAtV(draft.worldMapVersion, draft.worldSeed, target.x, target.y);
        switch (type) {
          case 'attack':
          case 'scout': {
            if (!info.spot) throw Errors.requirementNotMet({ reason: 'no_target' });
            if (info.spot.userId === draft.userId)
              throw Errors.requirementNotMet({ reason: 'own_castle' });
            if (type === 'scout' && !isOnlyCavalry(units))
              throw Errors.requirementNotMet({ reason: 'scout_needs_cavalry' });
            if (type === 'attack' && info.spot.shieldUntil && info.spot.shieldUntil > now)
              throw Errors.shieldActive({ until: info.spot.shieldUntil.toISOString() });
            targetCastleId = info.spot.castleId;
            targetName = info.spot.nickname;
            // Собственное нападение снимает щит новичка
            if (type === 'attack') draft.shieldUntil = null;
            break;
          }
          case 'monster':
            if (cell.kind !== 'camp') throw Errors.requirementNotMet({ reason: 'no_target' });
            if (info.state?.resetAt && info.state.resetAt > now)
              throw Errors.requirementNotMet({ reason: 'camp_respawning' });
            break;
          case 'gather':
            if (cell.kind !== 'resource') throw Errors.requirementNotMet({ reason: 'no_target' });
            break;
        }

        const from = { x: draft.x ?? 0, y: draft.y ?? 0 };
        const seconds = travelSeconds(
          from,
          target,
          units,
          techEffects(draft.tech).travelTime,
          draft.worldSpeed,
        );
        for (const [id, n] of Object.entries(units)) {
          const cur = draft.army[id as UnitId];
          if (cur) draft.army[id as UnitId] = { ...cur, count: cur.count - n };
        }
        draft.marches.push({
          id: randomUUID(),
          type,
          target: { ...target },
          targetCastleId,
          targetName,
          units,
          wounded: {},
          loot: { gold: 0, wood: 0, stone: 0, food: 0 },
          heroXp: 0,
          state: 'outbound',
          startedAt: now,
          arriveAt: new Date(now.getTime() + seconds * 1000),
          returnAt: new Date(now.getTime() + 2 * seconds * 1000),
          reportId: null,
        });
        return [];
      },
      undefined,
      { bump: { march: 1 } },
    );
  }

  /** Отряд: только известные юниты, целые положительные количества. */
  private cleanUnits(raw: Record<string, number>): UnitCounts {
    const out: UnitCounts = {};
    for (const [id, n] of Object.entries(raw)) {
      if (!parseUnitId(id) || !Number.isInteger(n) || n < 1)
        throw Errors.validation({ field: 'units', unit: id });
      out[id as UnitId] = n;
    }
    if (totalUnits(out) < 1) throw Errors.validation({ field: 'units' });
    return out;
  }
}

export { MAP_SIZE };
