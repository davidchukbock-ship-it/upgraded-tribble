import type { ReportDto, ReportPageDto, ReportSummaryDto } from '@tc/shared';
import type { Clock } from '../../lib/clock';
import { Errors } from '../../lib/errors';
import type { CastleRepository, ReportRecord } from '../castle/castle.types';

const summary = (r: ReportRecord): ReportSummaryDto => ({
  id: r.id,
  kind: r.kind,
  role: r.role,
  outcome: r.outcome,
  createdAt: r.createdAt.toISOString(),
  target: r.target,
  opponent: r.opponent,
  read: r.read,
});

/** Боевые отчёты игрока. */
export class ReportService {
  constructor(private readonly deps: { repo: CastleRepository; clock: Clock }) {}

  async list(userId: string, page: number, pageSize: number): Promise<ReportPageDto> {
    const r = await this.deps.repo.transaction((tx) => tx.listReports(userId, page, pageSize));
    return { items: r.items.map(summary), page, pageSize, total: r.total, unread: r.unread };
  }

  async get(userId: string, id: string): Promise<ReportDto> {
    return this.deps.repo.transaction(async (tx) => {
      const r = await tx.getReport(userId, id);
      if (!r) throw Errors.notFound('Report');
      if (!r.read) await tx.markReportRead(userId, id);
      return { ...summary({ ...r, read: true }), detail: r.payload };
    });
  }
}
