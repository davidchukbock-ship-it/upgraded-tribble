import {
  MAIN_WORLD_ID,
  MAP_SIZE,
  cellAtV,
  inBounds,
  nodeCapacity,
  type MapVersion,
  terrainAtV,
  type MapCellDto,
  type MapOverviewDto,
  type MapSearchResultDto,
  type MapTilesDto,
} from '@tc/shared';
import type { Clock } from '../../lib/clock';
import { Errors } from '../../lib/errors';
import type {
  CastleRepository,
  CastleSpot,
  CastleTx,
  CellStateRecord,
} from '../castle/castle.types';

const COORDS_RE = /^\s*(\d{1,3})\s*[,;\s]\s*(\d{1,3})\s*$/;
const SEARCH_LIMIT = 10;

interface WorldRef {
  seed: number;
  version: MapVersion;
}

/** Код рельефа в строке обзора мира (мини-карта). */
const OVERVIEW_GLYPH = {
  plain: 'p',
  forest: 'f',
  mountain: 'm',
  water: 'w',
  desert: 'd',
  swamp: 's',
  sea: 'o',
  lake: 'l',
  river: 'r',
} as const;
const OVERVIEW_TTL_MS = 10 * 60_000;

/** Просмотр карты: рельеф и объекты считаются из seed, замки и состояния клеток — из БД. */
const OVERVIEW_STEP = 5;

export class MapService {
  private readonly worldId: string;
  private readonly overviewCache = new Map<string, { value: MapOverviewDto; until: number }>();

  constructor(private readonly deps: { repo: CastleRepository; clock: Clock; worldId?: string }) {
    this.worldId = deps.worldId ?? MAIN_WORLD_ID;
  }

  async tiles(userId: string, x: number, y: number, size: number): Promise<MapTilesDto> {
    const s = Math.min(Math.max(1, size), MAP_SIZE);
    const x0 = Math.min(Math.max(0, x), MAP_SIZE - s);
    const y0 = Math.min(Math.max(0, y), MAP_SIZE - s);
    const now = this.deps.clock.now();
    const cells = await this.deps.repo.transaction(async (tx) => {
      const world = await this.worldOf(tx, userId);
      return this.build(tx, world, userId, x0, y0, x0 + s, y0 + s, now);
    });
    return { serverTime: now.toISOString(), x: x0, y: y0, size: s, cells };
  }

  /** Грубый обзор мира для мини-карты: детерминированный рельеф, без запросов к БД по клеткам. */
  async overview(userId: string): Promise<MapOverviewDto> {
    const world = await this.deps.repo.transaction((tx) => this.worldOf(tx, userId));
    const key = `${world.version}:${world.seed}`;
    const hit = this.overviewCache.get(key);
    if (hit && hit.until > Date.now()) return hit.value;
    const step = OVERVIEW_STEP;
    const cols = Math.ceil(MAP_SIZE / step);
    let terrain = '';
    for (let j = 0; j < cols; j++)
      for (let i = 0; i < cols; i++)
        terrain +=
          OVERVIEW_GLYPH[
            terrainAtV(
              world.version,
              world.seed,
              Math.min(MAP_SIZE - 1, i * step),
              Math.min(MAP_SIZE - 1, j * step),
            )
          ];
    const value = { step, cols, terrain };
    // Рельеф мира не меняется: кэш в памяти с временем жизни вместо повторного расчёта на каждый запрос
    this.overviewCache.set(key, { value, until: Date.now() + OVERVIEW_TTL_MS });
    return value;
  }

  async cell(userId: string, x: number, y: number): Promise<MapCellDto> {
    if (!inBounds(x, y)) throw Errors.notFound('Cell');
    const now = this.deps.clock.now();
    const cells = await this.deps.repo.transaction(async (tx) => {
      const world = await this.worldOf(tx, userId);
      return this.build(tx, world, userId, x, y, x + 1, y + 1, now);
    });
    return cells[0]!;
  }

  async search(q: string): Promise<MapSearchResultDto[]> {
    const m = COORDS_RE.exec(q);
    if (m) {
      const x = Number(m[1]);
      const y = Number(m[2]);
      if (!inBounds(x, y)) return [];
      const spot = await this.deps.repo.transaction((tx) => tx.spotAt(this.worldId, x, y));
      return [{ x, y, nickname: spot?.nickname ?? null }];
    }
    if (q.length < 2) return [];
    const spots = await this.deps.repo.transaction((tx) =>
      tx.searchSpots(this.worldId, q, SEARCH_LIMIT),
    );
    return spots.map((s) => ({ x: s.x, y: s.y, nickname: s.nickname }));
  }

  private async worldOf(tx: CastleTx, userId: string): Promise<WorldRef> {
    const castle = await tx.load(userId, this.worldId);
    if (!castle) throw Errors.notFound('Castle');
    return { seed: castle.worldSeed, version: castle.worldMapVersion };
  }

  private async build(
    tx: CastleTx,
    world: WorldRef,
    userId: string,
    x0: number,
    y0: number,
    x1: number,
    y1: number,
    now: Date,
  ): Promise<MapCellDto[]> {
    const [spots, states] = await Promise.all([
      tx.spotsIn(this.worldId, x0, y0, x1, y1),
      tx.cellStates(this.worldId, x0, y0, x1, y1),
    ]);
    const spotAt = new Map<string, CastleSpot>(spots.map((s) => [`${s.x},${s.y}`, s]));
    const stateAt = new Map<string, CellStateRecord>(states.map((s) => [`${s.x},${s.y}`, s]));
    const cells: MapCellDto[] = [];
    for (let y = y0; y < y1; y++) {
      for (let x = x0; x < x1; x++) {
        const base = cellAtV(world.version, world.seed, x, y);
        const spot = spotAt.get(`${x},${y}`);
        const state = stateAt.get(`${x},${y}`);
        const active = state?.resetAt && state.resetAt > now;
        cells.push({
          ...base,
          castle: spot
            ? {
                nickname: spot.nickname,
                isMe: spot.userId === userId,
                shielded: !!spot.shieldUntil && spot.shieldUntil > now,
              }
            : null,
          busyUntil: base.kind === 'camp' && active ? (state.resetAt as Date).toISOString() : null,
          remaining:
            base.kind === 'resource'
              ? active && state.remaining !== null
                ? state.remaining
                : nodeCapacity(base.level)
              : null,
        });
      }
    }
    return cells;
  }
}
