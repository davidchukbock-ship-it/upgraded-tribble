import {
  HERO_TRAIN_XP,
  MAX_HERO_LEVEL,
  MAX_SKILL_LEVEL,
  addHeroXp,
  mageHeroXpBonus,
  heroSkillPoints,
  heroTrainCost,
  shortfall,
  subtractCost,
  type SkillKey,
} from '@tc/shared';
import { Errors } from '../../lib/errors';
import {
  negate,
  resourceEvents,
  type CastleResult,
  type RealmRunner,
} from '../castle/castle.runner';

/** Герой: вложить очко навыка, надеть предмет, потренировать за ресурсы. Герой создаётся при первом обращении. */
export class HeroService {
  constructor(private readonly runner: RealmRunner) {}

  spendSkill(userId: string, skill: SkillKey, idemKey: string): Promise<CastleResult> {
    return this.runner.mutate(userId, `hero-skill:${skill}`, idemKey, (draft) => {
      const hero = draft.hero!;
      if (heroSkillPoints(hero) < 1) throw Errors.requirementNotMet({ reason: 'no_points' });
      if (hero.skills[skill] >= MAX_SKILL_LEVEL)
        throw Errors.requirementNotMet({ reason: 'max_level' });
      hero.skills[skill] += 1;
      return [];
    });
  }

  equip(userId: string, itemId: string, idemKey: string): Promise<CastleResult> {
    return this.runner.mutate(userId, `hero-equip:${itemId}`, idemKey, (draft) => {
      const hero = draft.hero!;
      const item = hero.items.find((i) => i.id === itemId);
      if (!item) throw Errors.notFound('Item');
      // В слоте одновременно один предмет
      for (const other of hero.items)
        if (other.slot === item.slot) other.equipped = other.id === item.id;
      return [];
    });
  }

  train(userId: string, idemKey: string): Promise<CastleResult> {
    return this.runner.mutate(userId, 'hero-train', idemKey, (draft, now) => {
      const hero = draft.hero!;
      if (hero.level >= MAX_HERO_LEVEL) throw Errors.requirementNotMet({ reason: 'max_level' });
      const cost = heroTrainCost(hero.level);
      const missing = shortfall(draft.resources, cost);
      if (Object.keys(missing).length > 0) throw Errors.insufficientResources({ missing });
      draft.resources = subtractCost(draft.resources, cost);
      const up = addHeroXp(
        hero.level,
        hero.xp,
        Math.round(HERO_TRAIN_XP * (1 + mageHeroXpBonus(draft.levels.magetower ?? 0))),
      );
      hero.level = up.level;
      hero.xp = up.xp;
      return resourceEvents(draft, now, 'hero_train', negate(cost));
    });
  }
}
