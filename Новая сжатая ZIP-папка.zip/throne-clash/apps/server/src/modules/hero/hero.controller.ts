import type { FastifyInstance } from 'fastify';
import type { ZodTypeProvider } from 'fastify-type-provider-zod';
import { z } from 'zod';
import { sendResult } from '../castle/castle.controller';
import {
  castleSchema,
  errorSchema,
  failures,
  heroSchema,
  idempotencyHeaders,
  skillKey,
} from '../castle/castle.schema';
import type { CastleService } from '../castle/castle.service';
import type { HeroService } from './hero.service';

export function registerHeroRoutes(
  app: FastifyInstance,
  hero: HeroService,
  castle: CastleService,
): void {
  const r = app.withTypeProvider<ZodTypeProvider>();
  const tags = ['hero'];
  const security = [{ bearerAuth: [] }];

  r.get(
    '/hero',
    {
      preHandler: app.authenticate,
      schema: {
        tags,
        summary: 'Герой: уровень, навыки, экипировка',
        security,
        response: { 200: heroSchema, 401: errorSchema, 404: errorSchema },
      },
    },
    async (req) => (await castle.view(req.auth!.user.id)).hero,
  );

  r.post(
    '/hero/skills/:key',
    {
      preHandler: app.authenticate,
      schema: {
        tags,
        summary: 'Вложить очко навыка',
        security,
        headers: idempotencyHeaders,
        params: z.object({ key: skillKey }),
        response: { 200: castleSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await hero.spendSkill(req.auth!.user.id, req.params.key, req.headers['idempotency-key']),
      ),
  );

  r.post(
    '/hero/equip',
    {
      preHandler: app.authenticate,
      schema: {
        tags,
        summary: 'Надеть предмет из сумки',
        security,
        headers: idempotencyHeaders,
        body: z.object({ itemId: z.string().uuid() }).strict(),
        response: { 200: castleSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await hero.equip(req.auth!.user.id, req.body.itemId, req.headers['idempotency-key']),
      ),
  );

  r.post(
    '/hero/train',
    {
      preHandler: app.authenticate,
      schema: {
        tags,
        summary: 'Потренировать героя за ресурсы (+опыт)',
        security,
        headers: idempotencyHeaders,
        response: { 200: castleSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(reply, await hero.train(req.auth!.user.id, req.headers['idempotency-key'])),
  );
}
