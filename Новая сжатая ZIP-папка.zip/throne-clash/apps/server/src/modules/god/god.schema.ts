import { z } from 'zod';
import { ALL_UNIT_IDS, BALANCE_KEYS, MAP_SIZE } from '@tc/shared';
import { adminUserSchema } from '../admin/admin.schema';
import { castleSchema } from '../castle/castle.schema';
import { inventorySchema } from '../progress/progress.schema';

export const loginBody = z
  .object({
    password: z.string().min(1).max(200),
    totp: z
      .string()
      .regex(/^\d{6}$/)
      .optional(),
  })
  .strict();

export const sessionSchema = z.object({ expiresAt: z.string(), totpRequired: z.boolean() });

export const actResultSchema = z.object({ castle: castleSchema });

export const playerSchema = z.object({
  user: adminUserSchema,
  castle: castleSchema,
  inventory: inventorySchema,
  godTouched: z.boolean(),
  snapshots: z.array(z.object({ id: z.string(), label: z.string(), createdAt: z.string() })),
});

export const labelBody = z.object({ label: z.string().trim().min(1).max(60) }).strict();
export const snapshotParams = z.object({ id: z.string().uuid(), sid: z.string().uuid() });
export const roleBody = z.object({ role: z.enum(['PLAYER', 'ADMIN']) }).strict();
export const cellBody = z
  .object({
    x: z
      .number()
      .int()
      .min(0)
      .max(MAP_SIZE - 1),
    y: z
      .number()
      .int()
      .min(0)
      .max(MAP_SIZE - 1),
  })
  .strict();

const counts = z.record(
  z.enum(ALL_UNIT_IDS as unknown as [string, ...string[]]),
  z.number().int().min(0).max(1_000_000),
);
const bonus = z
  .object({ attack: z.number().min(0).max(5), defense: z.number().min(0).max(5) })
  .strict();
export const simulateBody = z
  .object({
    attacker: counts,
    defender: counts,
    attackerBonus: bonus.default({ attack: 0, defense: 0 }),
    defenderBonus: bonus.default({ attack: 0, defense: 0 }),
    seed: z
      .number()
      .int()
      .min(0)
      .max(2 ** 32 - 1)
      .default(1),
    force: z.enum(['attacker', 'defender']).optional(),
  })
  .strict();

export const balanceSchemaDto = z.object({
  balance: z.record(z.number()),
  updatedAt: z.string().nullable(),
  revisions: z.array(
    z.object({
      id: z.string(),
      createdAt: z.string(),
      note: z.string().nullable(),
      balance: z.record(z.number()),
    }),
  ),
});
export const balanceBody = z
  .object(
    Object.fromEntries(BALANCE_KEYS.map((k) => [k, z.number()])) as Record<string, z.ZodNumber>,
  )
  .partial()
  .strict();
export const rollbackBody = z.object({ revisionId: z.string().uuid() }).strict();

export const announceBody = z.object({ text: z.string().trim().min(1).max(300) }).strict();

export const debugSchema = z.object({
  uptimeSeconds: z.number(),
  memoryMb: z.number(),
  online: z.number(),
  counts: z.object({
    users: z.number(),
    castles: z.number(),
    marches: z.number(),
    guilds: z.number(),
    chatMessages: z.number(),
  }),
  redis: z.enum(['ok', 'off', 'error']),
  serverTime: z.string(),
});
