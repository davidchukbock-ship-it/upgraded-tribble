import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import type { ZodTypeProvider } from 'fastify-type-provider-zod';
import { z } from 'zod';
import { godActionSchema, type UnitCounts } from '@tc/shared';
import type { AppConfig } from '../../config/env';
import type { Clock } from '../../lib/clock';
import { Errors } from '../../lib/errors';
import { actorOf } from '../admin/admin.controller';
import {
  adminUserSchema,
  auditQuery,
  auditSchema,
  banBody,
  idParams,
  muteBody,
  usersQuery,
  adminUserPageSchema,
} from '../admin/admin.schema';
import type { AdminService } from '../admin/admin.service';
import { authResponseSchema } from '../auth/auth.controller';
import { errorSchema, failures, idempotencyHeaders } from '../castle/castle.schema';
import { sendResult } from '../castle/castle.controller';
import type { BalanceService } from './balance.service';
import type { GodAuth } from './god.auth';
import type { GodService } from './god.service';
import {
  actResultSchema,
  announceBody,
  balanceBody,
  balanceSchemaDto,
  cellBody,
  debugSchema,
  labelBody,
  loginBody,
  playerSchema,
  rollbackBody,
  roleBody,
  sessionSchema,
  simulateBody,
  snapshotParams,
} from './god.schema';

export const GOD_COOKIE = 'tc_god';

declare module 'fastify' {
  interface FastifyRequest {
    god?: { sessionId: string; expiresAt: Date };
  }
}

export interface GodControllerDeps {
  config: AppConfig;
  clock: Clock;
  auth: GodAuth;
  service: GodService;
  admin: AdminService;
  balance: BalanceService;
}

/**
 * Режим бога `/api/god/*` (D-13, D-49). Три слоя допуска, все на сервере:
 *  1. флаг GOD_MODE_ENABLED — выключен: любой путь отвечает 404, как несуществующий;
 *  2. аккаунт с действующей ролью OWNER — иначе тоже 404 (существование не подтверждаем);
 *  3. сессия режима бога (пароль [+ TOTP]) в httpOnly-cookie — иначе 401.
 * Bearer-токен нужен на каждый запрос, поэтому подделка запроса с чужого сайта невозможна (cookie сам по себе бесполезен).
 */
export function registerGodRoutes(app: FastifyInstance, deps: GodControllerDeps): void {
  const { config, auth, service, balance } = deps;
  const r = app.withTypeProvider<ZodTypeProvider>();
  const tags = ['god'];
  const security = [{ bearerAuth: [] }];
  const notFound = () => Errors.notFound('Route');

  const guard =
    (needSession: boolean) =>
    async (req: FastifyRequest, reply: FastifyReply): Promise<void> => {
      if (!config.godMode.enabled) throw notFound();
      await app.authenticate(req, reply);
      if (req.auth!.role !== 'OWNER' || req.auth!.impersonatedBy) throw notFound();
      reply.header('X-Robots-Tag', 'noindex, nofollow, noarchive');
      reply.header('Cache-Control', 'no-store');
      if (!needSession) return;
      const v = await auth.verify(req.cookies[GOD_COOKIE], req.auth!.user.id);
      if (!v) throw Errors.unauthorized();
      req.god = { sessionId: v.session.id, expiresAt: v.expiresAt };
    };
  const owner = { preHandler: guard(false) };
  const god = { preHandler: guard(true) };
  const read = { 401: errorSchema, 404: errorSchema };
  const idem = { headers: idempotencyHeaders };

  const setCookie = (reply: FastifyReply, token: string): void => {
    reply.setCookie(GOD_COOKIE, token, {
      httpOnly: true,
      secure: config.cookieSecure,
      sameSite: 'strict',
      path: '/api/god',
      maxAge: 8 * 3600,
    });
  };

  // ── Вход и сессия ──
  r.post(
    '/god/login',
    {
      ...owner,
      config: { rateLimit: { max: 10, timeWindow: '1 minute' } },
      schema: {
        tags,
        summary: 'Вход в режим бога: пароль [+ TOTP]. 5 неудач — блокировка на 15 минут',
        security,
        body: loginBody,
        response: { 200: sessionSchema, 429: errorSchema, ...read },
      },
    },
    async (req, reply) => {
      const { token, expiresAt } = await auth.login(
        req.auth!.user,
        req.ip,
        req.body.password,
        req.body.totp,
      );
      setCookie(reply, token);
      return { expiresAt: expiresAt.toISOString(), totpRequired: auth.totpRequired };
    },
  );

  r.get(
    '/god/session',
    {
      ...god,
      schema: {
        tags,
        summary: 'Текущая сессия (продлевает срок)',
        security,
        response: { 200: sessionSchema, ...read },
      },
    },
    async (req) => ({
      expiresAt: req.god!.expiresAt.toISOString(),
      totpRequired: auth.totpRequired,
    }),
  );

  r.post(
    '/god/logout',
    {
      ...god,
      schema: {
        tags,
        summary: 'Выйти из режима бога',
        security,
        response: { 204: z.null(), ...read },
      },
    },
    async (req, reply) => {
      const session = await deps.auth.verify(req.cookies[GOD_COOKIE], req.auth!.user.id);
      if (session) await auth.logout(session.session, req.ip);
      reply.clearCookie(GOD_COOKIE, { path: '/api/god' });
      return reply.code(204).send(null);
    },
  );

  // ── Игроки ──
  r.get(
    '/god/players',
    {
      ...god,
      schema: {
        tags,
        summary: 'Поиск игроков',
        security,
        querystring: usersQuery,
        response: { 200: adminUserPageSchema, ...read },
      },
    },
    async (req) => deps.admin.listUsers(req.query.q, req.query.page, req.query.pageSize),
  );

  r.get(
    '/god/players/:id',
    {
      ...god,
      schema: {
        tags,
        summary: 'Игрок целиком: профиль, замок, инвентарь, снимки',
        security,
        params: idParams,
        response: { 200: playerSchema, ...read },
      },
    },
    async (req) => service.player(req.params.id),
  );

  r.post(
    '/god/players/:id/act',
    {
      ...god,
      schema: {
        tags,
        summary: 'Действие над замком игрока (ресурсы, здания, армия, время, карта…)',
        security,
        ...idem,
        params: idParams,
        body: godActionSchema,
        response: { 200: actResultSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await service.act(actorOf(req), req.params.id, req.body, req.headers['idempotency-key']),
      ),
  );

  r.post(
    '/god/players/:id/snapshots',
    {
      ...god,
      schema: {
        tags,
        summary: 'Сохранить снимок замка',
        security,
        params: idParams,
        body: labelBody,
        response: {
          200: z.object({ id: z.string(), label: z.string(), createdAt: z.string() }),
          ...read,
        },
      },
    },
    async (req) => service.snapshot(actorOf(req), req.params.id, req.body.label),
  );

  r.post(
    '/god/players/:id/snapshots/:sid/restore',
    {
      ...god,
      schema: {
        tags,
        summary: 'Восстановить замок из снимка',
        security,
        ...idem,
        params: snapshotParams,
        response: { 200: actResultSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await service.restore(
          actorOf(req),
          req.params.id,
          req.params.sid,
          req.headers['idempotency-key'],
        ),
      ),
  );

  r.post(
    '/god/players/:id/ban',
    {
      ...god,
      schema: {
        tags,
        summary: 'Заблокировать',
        security,
        params: idParams,
        body: banBody,
        response: { 200: adminUserSchema, ...read },
      },
    },
    async (req) => deps.admin.ban(actorOf(req), req.params.id, req.body.hours, req.body.reason),
  );
  r.post(
    '/god/players/:id/unban',
    {
      ...god,
      schema: {
        tags,
        summary: 'Снять блокировку',
        security,
        params: idParams,
        response: { 200: adminUserSchema, ...read },
      },
    },
    async (req) => deps.admin.unban(actorOf(req), req.params.id),
  );
  r.post(
    '/god/players/:id/mute',
    {
      ...god,
      schema: {
        tags,
        summary: 'Запретить чат',
        security,
        params: idParams,
        body: muteBody,
        response: { 200: adminUserSchema, ...read },
      },
    },
    async (req) => deps.admin.mute(actorOf(req), req.params.id, req.body.minutes, req.body.reason),
  );
  r.post(
    '/god/players/:id/unmute',
    {
      ...god,
      schema: {
        tags,
        summary: 'Снять запрет чата',
        security,
        params: idParams,
        response: { 200: adminUserSchema, ...read },
      },
    },
    async (req) => deps.admin.unmute(actorOf(req), req.params.id),
  );
  r.post(
    '/god/players/:id/role',
    {
      ...god,
      schema: {
        tags,
        summary: 'Назначить или снять администратора',
        security,
        params: idParams,
        body: roleBody,
        response: { 200: adminUserSchema, ...read },
      },
    },
    async (req) => service.setRole(actorOf(req), req.params.id, req.body.role),
  );
  r.post(
    '/god/players/:id/impersonate',
    {
      ...god,
      schema: {
        tags,
        summary: 'Войти под игроком (короткий токен, действия в аудите)',
        security,
        params: idParams,
        response: { 200: authResponseSchema, ...read },
      },
    },
    async (req) => service.impersonate(actorOf(req), req.params.id),
  );

  // ── Карта, бой, братства, чат ──
  r.post(
    '/god/map/cell-reset',
    {
      ...god,
      schema: {
        tags,
        summary: 'Сбросить клетку: лагерь возрождается, ресурсная точка наполняется',
        security,
        body: cellBody,
        response: { 204: z.null(), ...read },
      },
    },
    async (req, reply) => {
      await service.cellReset(actorOf(req), req.body.x, req.body.y);
      return reply.code(204).send(null);
    },
  );

  r.post(
    '/god/simulate',
    {
      ...god,
      schema: {
        tags,
        summary: 'Симулятор боя двух произвольных отрядов; данные игры не меняются',
        security,
        body: simulateBody,
        response: { 200: z.unknown(), ...read, 409: errorSchema },
      },
    },
    async (req) => {
      const b = req.body;
      return service.simulate({
        attacker: b.attacker as UnitCounts,
        defender: b.defender as UnitCounts,
        attackerBonus: b.attackerBonus,
        defenderBonus: b.defenderBonus,
        seed: b.seed,
        force: b.force,
      });
    },
  );

  r.delete(
    '/god/guilds/:id',
    {
      ...god,
      schema: {
        tags,
        summary: 'Распустить братство',
        security,
        params: idParams,
        response: { 204: z.null(), ...read },
      },
    },
    async (req, reply) => {
      await service.deleteGuild(actorOf(req), req.params.id);
      return reply.code(204).send(null);
    },
  );

  r.post(
    '/god/chat/announce',
    {
      ...god,
      schema: {
        tags,
        summary: 'Системное объявление в мировой чат',
        security,
        body: announceBody,
        response: { 204: z.null(), ...read },
      },
    },
    async (req, reply) => {
      await service.announce(actorOf(req), req.body.text);
      return reply.code(204).send(null);
    },
  );

  // ── Баланс ──
  r.get(
    '/god/balance',
    {
      ...god,
      schema: {
        tags,
        summary: 'Действующий баланс и ревизии (он же экспорт JSON)',
        security,
        response: { 200: balanceSchemaDto, ...read },
      },
    },
    async () => balance.get(),
  );

  r.put(
    '/god/balance',
    {
      ...god,
      schema: {
        tags,
        summary: 'Применить множители баланса на лету (и импорт JSON)',
        security,
        body: balanceBody,
        response: { 200: balanceSchemaDto, ...read },
      },
    },
    async (req) => {
      const { before, after } = await balance.apply(req.body, req.auth!.user.id, 'manual');
      await service.record(actorOf(req), 'balance_set', null, req.body, before, after);
      return balance.get();
    },
  );

  r.post(
    '/god/balance/rollback',
    {
      ...god,
      schema: {
        tags,
        summary: 'Откатить баланс к ревизии',
        security,
        body: rollbackBody,
        response: { 200: balanceSchemaDto, ...read },
      },
    },
    async (req) => {
      const { before, after } = await balance.rollback(req.body.revisionId, req.auth!.user.id);
      await service.record(actorOf(req), 'balance_rollback', null, req.body, before, after);
      return balance.get();
    },
  );

  // ── Аудит и отладка ──
  r.get(
    '/god/audit',
    {
      ...god,
      schema: {
        tags,
        summary: 'Журнал действий (админка и режим бога)',
        security,
        querystring: auditQuery,
        response: { 200: auditSchema, ...read },
      },
    },
    async (req) =>
      deps.admin.audit(
        {
          ...(req.query.scope && { scope: req.query.scope }),
          ...(req.query.targetUserId && { targetUserId: req.query.targetUserId }),
        },
        req.query.page,
        req.query.pageSize,
      ),
  );

  r.get(
    '/god/debug',
    {
      ...god,
      schema: {
        tags,
        summary: 'Состояние сервера: соединения, таблицы, Redis',
        security,
        response: { 200: debugSchema, ...read },
      },
    },
    async () => service.debug(),
  );

  r.post(
    '/god/debug/reseed',
    {
      ...god,
      schema: {
        tags,
        summary: 'Досоздать ботов и демо-игроков (идемпотентно)',
        security,
        response: {
          200: z.object({ bots: z.number(), demos: z.number() }),
          ...read,
          409: errorSchema,
        },
      },
    },
    async (req) => service.reseed(actorOf(req)),
  );
}
