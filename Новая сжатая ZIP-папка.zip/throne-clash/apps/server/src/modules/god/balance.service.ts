import { randomUUID } from 'node:crypto';
import {
  BALANCE_KEYS,
  DEFAULT_BALANCE,
  balanceSchema,
  getBalance,
  setBalance,
  type Balance,
  type BalanceDto,
} from '@tc/shared';
import type { Clock } from '../../lib/clock';
import { Errors } from '../../lib/errors';
import type { BalanceRevisionRecord } from '../admin/admin.types';
import type { CastleRepository } from '../castle/castle.types';

const HISTORY = 20;

/**
 * Конструктор баланса (D-50). Множители хранятся ревизиями в БД; действующим считается последняя.
 * Применение «на лету» — установка множителей в общих формулах процесса. Откат — не удаление, а новая ревизия
 * со старым содержимым: история остаётся полной, как и аудит.
 */
export class BalanceService {
  constructor(private readonly deps: { repo: CastleRepository; clock: Clock }) {}

  /** Подхватывает последнюю ревизию (при старте и по таймеру: другой экземпляр мог её изменить). */
  async reload(): Promise<void> {
    const [latest] = await this.deps.repo.transaction((tx) => tx.admin.listBalanceRevisions(1));
    const parsed = latest ? balanceSchema.safeParse(latest.config) : null;
    setBalance(parsed?.success ? parsed.data : { ...DEFAULT_BALANCE });
  }

  async get(): Promise<BalanceDto> {
    const revs = await this.deps.repo.transaction((tx) => tx.admin.listBalanceRevisions(HISTORY));
    return {
      balance: { ...getBalance() },
      updatedAt: revs[0]?.createdAt.toISOString() ?? null,
      revisions: revs.map((r) => ({
        id: r.id,
        createdAt: r.createdAt.toISOString(),
        note: r.note,
        balance: r.config,
      })),
    };
  }

  /** Применяет новые множители (недостающие ключи берутся из действующих). Возвращает прежние и новые для аудита. */
  async apply(
    input: unknown,
    actorId: string,
    note: string | null,
  ): Promise<{ before: Balance; after: Balance }> {
    const merged = balanceSchema.safeParse({ ...getBalance(), ...(input as object) });
    if (!merged.success) throw Errors.validation({ field: 'balance' });
    // Лишние ключи отсекаем строго: импорт чужого JSON не должен пронести неизвестные поля
    const unknown = Object.keys((input ?? {}) as object).filter(
      (k) => !(BALANCE_KEYS as readonly string[]).includes(k),
    );
    if (unknown.length > 0) throw Errors.validation({ field: 'balance', unknown });
    const before = { ...getBalance() };
    const rec: BalanceRevisionRecord = {
      id: randomUUID(),
      config: merged.data,
      actorId,
      note,
      createdAt: this.deps.clock.now(),
    };
    await this.deps.repo.transaction((tx) => tx.admin.addBalanceRevision(rec));
    setBalance(merged.data);
    return { before, after: merged.data };
  }

  async rollback(revisionId: string, actorId: string) {
    const revs = await this.deps.repo.transaction((tx) => tx.admin.listBalanceRevisions(200));
    const target = revs.find((r) => r.id === revisionId);
    if (!target) throw Errors.notFound('Revision');
    return this.apply(target.config, actorId, `rollback to ${revisionId.slice(0, 8)}`);
  }

  /** Полный сброс к значениям из GAME_DESIGN. */
  reset(actorId: string) {
    return this.apply({ ...DEFAULT_BALANCE }, actorId, 'reset to defaults');
  }
}
