import { randomUUID } from 'node:crypto';
import {
  maxBuildingLevel,
  GOD_MAX_STOCK,
  MAX_TECH_LEVEL,
  NEWBIE_SHIELD_HOURS,
  START_BUILDINGS,
  START_GEMS,
  START_RESOURCES,
  SKILL_KEYS,
  TECH_KEYS,
  techEffects,
  warehouseCap,
  type BuildingKey,
  type GodAction,
  type ResourceKey,
  type UnitId,
} from '@tc/shared';
import { Errors } from '../../lib/errors';
import { rechain, settleAggregate, starterHero, type SettleEvent } from '../castle/castle.realm';
import { gemEvent, resourceEvents } from '../castle/castle.runner';
import type { CastleAggregate, CastleTx, EconomyEventRecord } from '../castle/castle.types';
import { boostKey, chestKey } from '../progress/progress.types';

const clamp = (n: number): number => Math.max(0, Math.min(GOD_MAX_STOCK, Math.round(n)));

export interface ActionContext {
  now: Date;
  tx: CastleTx;
  emit: (events: readonly SettleEvent[]) => void;
}

/** Компактная сводка замка для журнала: что было и что стало. Полный замок в журнал не пишем. */
export function godSummary(a: CastleAggregate): Record<string, unknown> {
  const units: Record<string, number> = {};
  for (const [id, s] of Object.entries(a.army)) if (s) units[id] = s.count + s.wounded;
  return {
    resources: { ...a.resources },
    gems: a.gems,
    levels: { ...a.levels },
    army: units,
    tech: { ...a.tech },
    hero: a.hero ? { level: a.hero.level, items: a.hero.items.length } : null,
    position: a.x === null ? null : { x: a.x, y: a.y },
    shieldUntil: a.shieldUntil?.toISOString() ?? null,
    queues: { build: a.tasks.length, train: a.trains.length, research: a.research.length },
    marches: a.marches.length,
  };
}

/** Сдвигает все таймеры замка на `seconds` в прошлое — как если бы время прошло. */
function skipTime(draft: CastleAggregate, seconds: number): void {
  const ms = seconds * 1000;
  const back = (d: Date): Date => new Date(d.getTime() - ms);
  for (const t of [...draft.tasks, ...draft.trains, ...draft.research]) {
    t.startedAt = back(t.startedAt);
    t.finishesAt = back(t.finishesAt);
  }
  for (const m of draft.marches) {
    m.startedAt = back(m.startedAt);
    m.arriveAt = back(m.arriveAt);
    m.returnAt = back(m.returnAt);
  }
  draft.resourcesUpdatedAt = back(draft.resourcesUpdatedAt);
  if (draft.shieldUntil) draft.shieldUntil = back(draft.shieldUntil);
}

/** Применяет пересчёт: постройки и очереди, чьё время вышло, завершаются, походы возвращаются. */
function settleNow(draft: CastleAggregate, ctx: ActionContext): void {
  const settled = settleAggregate(draft, ctx.now);
  ctx.emit(settled.events);
  Object.assign(draft, settled.draft);
  rechain(draft.trains, ctx.now);
  rechain(draft.research, ctx.now);
}

/**
 * Действие режима бога над замком. Замок помечается `isGodAction`: он и его экономика исключаются из
 * рейтингов и статистики (D-13). Проверок требований нет — это и есть смысл режима; ограничены только
 * технические пределы (целые числа в БД, границы карты).
 */
export async function applyGodAction(
  draft: CastleAggregate,
  action: GodAction,
  ctx: ActionContext,
): Promise<EconomyEventRecord[]> {
  const { now, tx } = ctx;
  draft.isGodAction = true;

  switch (action.type) {
    case 'resources': {
      if (action.resource === 'gems') {
        const next =
          action.op === 'give'
            ? draft.gems + action.amount
            : action.op === 'take'
              ? draft.gems - action.amount
              : action.amount;
        const value = clamp(next);
        const delta = value - draft.gems;
        draft.gems = value;
        return delta === 0 ? [] : [gemEvent(draft, now, 'god_resources', delta)];
      }
      const key: ResourceKey = action.resource;
      const cur = draft.resources[key];
      const next =
        action.op === 'give'
          ? cur + action.amount
          : action.op === 'take'
            ? cur - action.amount
            : action.amount;
      const value = clamp(next);
      draft.resources = { ...draft.resources, [key]: value };
      const delta = { gold: 0, wood: 0, stone: 0, food: 0, [key]: value - cur };
      return resourceEvents(draft, now, 'god_resources', delta);
    }
    case 'fill': {
      const cap = warehouseCap(draft.levels.warehouse ?? 1, {
        warehouse: techEffects(draft.tech).warehouse,
      });
      const delta = {
        gold: Math.max(0, cap - draft.resources.gold),
        wood: Math.max(0, cap - draft.resources.wood),
        stone: Math.max(0, cap - draft.resources.stone),
        food: Math.max(0, cap - draft.resources.food),
      };
      draft.resources = {
        gold: Math.max(draft.resources.gold, cap),
        wood: Math.max(draft.resources.wood, cap),
        stone: Math.max(draft.resources.stone, cap),
        food: Math.max(draft.resources.food, cap),
      };
      return resourceEvents(draft, now, 'god_resources', delta);
    }
    case 'building': {
      const key: BuildingKey = action.key;
      draft.levels = {
        ...draft.levels,
        [key]:
          key === 'castle'
            ? Math.max(1, action.level)
            : Math.min(action.level, maxBuildingLevel(key)),
      };
      // Незавершённая постройка этого здания теряет смысл
      draft.tasks = draft.tasks.filter((t) => t.key !== key);
      return [];
    }
    case 'finish': {
      for (const t of [...draft.tasks, ...draft.trains, ...draft.research]) {
        if (t.startedAt > now) t.startedAt = now;
        t.finishesAt = now;
      }
      settleNow(draft, ctx);
      return [];
    }
    case 'army': {
      const id = action.unit as UnitId;
      const cur = draft.army[id] ?? { count: 0, wounded: 0 };
      draft.army[id] = {
        count: Math.min(GOD_MAX_STOCK, cur.count + action.count),
        wounded: cur.wounded,
      };
      return [];
    }
    case 'resurrect': {
      for (const [id, s] of Object.entries(draft.army)) {
        if (s && s.wounded > 0)
          draft.army[id as UnitId] = { count: s.count + s.wounded, wounded: 0 };
      }
      return [];
    }
    case 'research': {
      draft.tech = { ...draft.tech, [action.tech]: action.level };
      draft.research = draft.research.filter((r) => r.tech !== action.tech);
      return [];
    }
    case 'research_all': {
      draft.tech = Object.fromEntries(
        TECH_KEYS.map((k) => [k, MAX_TECH_LEVEL]),
      ) as typeof draft.tech;
      draft.research = [];
      return [];
    }
    case 'hero': {
      const hero = (draft.hero ??= starterHero());
      hero.level = action.level;
      hero.xp = 0;
      // Вложенные очки не могут превышать уровень
      const spent = SKILL_KEYS.reduce((s, k) => s + hero.skills[k], 0);
      if (spent > hero.level) hero.skills = { combat: 0, defense: 0, economy: 0 };
      return [];
    }
    case 'hero_gear': {
      const hero = (draft.hero ??= starterHero());
      hero.items.push({
        id: randomUUID(),
        slot: action.slot,
        rarity: action.rarity,
        equipped: false,
      });
      return [];
    }
    case 'time': {
      skipTime(draft, action.seconds);
      settleNow(draft, ctx);
      return [];
    }
    case 'teleport': {
      const spot = await tx.spotAt(draft.worldId, action.x, action.y);
      if (spot && spot.userId !== draft.userId) throw Errors.conflict('Cell is occupied');
      draft.x = action.x;
      draft.y = action.y;
      return [];
    }
    case 'shield': {
      draft.shieldUntil =
        action.hours > 0 ? new Date(now.getTime() + action.hours * 3600_000) : null;
      return [];
    }
    case 'chest': {
      await tx.progress.addItem(draft.userId, chestKey(action.kind), action.count);
      return [];
    }
    case 'booster': {
      await tx.progress.addItem(draft.userId, boostKey(action.booster), action.count);
      return [];
    }
    case 'reset': {
      draft.resources = { ...START_RESOURCES };
      draft.gems = START_GEMS;
      draft.levels = Object.fromEntries(START_BUILDINGS.map((k) => [k, 1]));
      draft.tasks = [];
      draft.trains = [];
      draft.research = [];
      draft.army = {};
      draft.tech = {};
      draft.hero = starterHero();
      draft.marches = [];
      draft.extraBuildSlot = false;
      draft.resourcesUpdatedAt = now;
      draft.shieldUntil = new Date(now.getTime() + NEWBIE_SHIELD_HOURS * 3600_000);
      // Сброс возвращает аккаунт в честное состояние: метка режима бога снимается
      draft.isGodAction = false;
      return [];
    }
  }
}
