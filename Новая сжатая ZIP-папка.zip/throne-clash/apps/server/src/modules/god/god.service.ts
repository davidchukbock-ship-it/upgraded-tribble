import { randomUUID } from 'node:crypto';
import {
  MAIN_WORLD_ID,
  describeGodAction,
  simulateBattle,
  type AuthResponse,
  type BattleResult,
  type GodAction,
  type GodActResultDto,
  type GodDebugDto,
  type GodPlayerDto,
  type UnitCounts,
  type UnitType,
  UNIT_TYPES,
} from '@tc/shared';
import type { Clock } from '../../lib/clock';
import { Errors } from '../../lib/errors';
import type { AccessTokenService } from '../../lib/tokens';
import { toAdminUser, type Actor } from '../admin/admin.service';
import type { AuditRecord } from '../admin/admin.types';
import { effectiveRole, toUserDto } from '../auth/auth.service';
import type { UserRepository } from '../auth/auth.types';
import { settleAggregate, starterHero, toCastleDto } from '../castle/castle.realm';
import type { CastleResult, RealmRunner } from '../castle/castle.runner';
import type { CastleAggregate, CastleRepository } from '../castle/castle.types';
import { inventoryDto } from '../progress/progress.logic';
import type { ChatService } from '../social/chat.service';
import type { Hub } from '../social/hub';
import { applyGodAction, godSummary } from './god.actions';

const IMPERSONATION_SECONDS = 600;

export interface Bonus {
  attack: number;
  defense: number;
}

export interface GodDeps {
  repo: CastleRepository;
  runner: RealmRunner;
  users: UserRepository;
  tokens: AccessTokenService;
  chat: ChatService;
  hub: Hub;
  clock: Clock;
  ownerEmail: string;
  redis: () => Promise<'ok' | 'off' | 'error'>;
  /** Пересоздаёт ботов и демо-игроков; в боевом запуске подключается к Prisma. */
  reseed?: () => Promise<{ bots: number; demos: number }>;
  worldId?: string;
}

/** Поля замка, которые сохраняются в снимке и восстанавливаются из него. */
const SNAPSHOT_FIELDS = [
  'resources',
  'gems',
  'levels',
  'army',
  'tech',
  'hero',
  'tasks',
  'trains',
  'research',
  'marches',
  'extraBuildSlot',
  'shieldUntil',
  'x',
  'y',
] as const;

const toDate = (v: unknown): Date | null => (typeof v === 'string' ? new Date(v) : null);
const dates = <T extends object>(rows: T[], keys: string[]): T[] =>
  rows.map((r) => {
    const out = { ...r } as Record<string, unknown>;
    for (const k of keys) out[k] = toDate(out[k]) ?? out[k];
    return out as T;
  });

/** Действия владельца в режиме бога. Всё, что меняет данные, пишется в GodAuditLog в той же транзакции. */
export class GodService {
  private readonly worldId: string;

  constructor(private readonly deps: GodDeps) {
    this.worldId = deps.worldId ?? MAIN_WORLD_ID;
  }

  private audit(
    actor: Actor,
    action: string,
    target: string | null,
    params: unknown,
    before?: unknown,
    after?: unknown,
  ): AuditRecord {
    return {
      id: randomUUID(),
      scope: 'god',
      actorId: actor.user.id,
      action,
      targetUserId: target,
      params,
      before: before ?? null,
      after: after ?? null,
      ip: actor.ip,
      createdAt: this.deps.clock.now(),
    };
  }

  private async requireUser(id: string) {
    const u = await this.deps.users.findById(id);
    if (!u) throw Errors.notFound('Player');
    return u;
  }

  async player(targetId: string): Promise<GodPlayerDto> {
    const user = await this.requireUser(targetId);
    const now = this.deps.clock.now();
    return this.deps.repo.transaction(async (tx) => {
      const agg = await tx.load(targetId, this.worldId);
      if (!agg) throw Errors.notFound('Castle');
      const draft = settleAggregate(agg, now).draft;
      draft.hero ??= starterHero();
      return {
        user: toAdminUser(user),
        castle: toCastleDto(draft, now),
        inventory: inventoryDto(await tx.progress.inventory(targetId)),
        godTouched: agg.isGodAction,
        snapshots: (await tx.admin.listSnapshots(targetId)).map((s) => ({
          id: s.id,
          label: s.label,
          createdAt: s.createdAt.toISOString(),
        })),
      };
    });
  }

  async act(
    actor: Actor,
    targetId: string,
    action: GodAction,
    idemKey: string,
  ): Promise<CastleResult<GodActResultDto>> {
    await this.requireUser(targetId);
    let before: unknown;
    let after: unknown;
    return this.deps.runner.mutate<GodActResultDto>(
      targetId,
      `god:${JSON.stringify(action)}`,
      idemKey,
      async (draft, now, emit, tx) => {
        before = godSummary(draft);
        const events = await applyGodAction(draft, action, { now, tx, emit });
        after = godSummary(draft);
        return events;
      },
      async (tx, _draft, now) => {
        const rec = this.audit(
          actor,
          `act:${describeGodAction(action)}`,
          targetId,
          action,
          before,
          after,
        );
        await tx.admin.addAudit({ ...rec, createdAt: now });
      },
      { wrap: (castle) => ({ castle }) },
    );
  }

  // ── Снимки (песочница) ─────────────────────────────────────────────────────

  async snapshot(actor: Actor, targetId: string, label: string) {
    await this.requireUser(targetId);
    const now = this.deps.clock.now();
    return this.deps.repo.transaction(async (tx) => {
      const agg = await tx.load(targetId, this.worldId);
      if (!agg) throw Errors.notFound('Castle');
      const draft = settleAggregate(agg, now).draft;
      const data = JSON.parse(
        JSON.stringify(Object.fromEntries(SNAPSHOT_FIELDS.map((k) => [k, draft[k]]))),
      ) as unknown;
      const id = randomUUID();
      await tx.admin.saveSnapshot({
        id,
        userId: targetId,
        label,
        takenBy: actor.user.id,
        data,
        createdAt: now,
      });
      await tx.admin.addAudit(this.audit(actor, 'snapshot_save', targetId, { label, id }));
      return { id, label, createdAt: now.toISOString() };
    });
  }

  async restore(
    actor: Actor,
    targetId: string,
    snapshotId: string,
    idemKey: string,
  ): Promise<CastleResult<GodActResultDto>> {
    await this.requireUser(targetId);
    let before: unknown;
    let after: unknown;
    return this.deps.runner.mutate<GodActResultDto>(
      targetId,
      `god-restore:${snapshotId}`,
      idemKey,
      async (draft, now, _emit, tx) => {
        const snap = await tx.admin.getSnapshot(snapshotId);
        if (!snap || snap.userId !== targetId) throw Errors.notFound('Snapshot');
        before = godSummary(draft);
        const d = snap.data as Record<string, unknown>;
        draft.resources = d['resources'] as CastleAggregate['resources'];
        draft.gems = d['gems'] as number;
        draft.levels = d['levels'] as CastleAggregate['levels'];
        draft.army = d['army'] as CastleAggregate['army'];
        draft.tech = d['tech'] as CastleAggregate['tech'];
        draft.hero = d['hero'] as CastleAggregate['hero'];
        draft.tasks = dates(d['tasks'] as CastleAggregate['tasks'], ['startedAt', 'finishesAt']);
        draft.trains = dates(d['trains'] as CastleAggregate['trains'], ['startedAt', 'finishesAt']);
        draft.research = dates(d['research'] as CastleAggregate['research'], [
          'startedAt',
          'finishesAt',
        ]);
        draft.marches = dates(d['marches'] as CastleAggregate['marches'], [
          'startedAt',
          'arriveAt',
          'returnAt',
        ]);
        draft.extraBuildSlot = d['extraBuildSlot'] === true;
        draft.shieldUntil = toDate(d['shieldUntil']);
        // Место на карте занять может кто-то другой: тогда остаёмся там, где стоим
        const x = d['x'] as number | null;
        const y = d['y'] as number | null;
        if (x !== null && y !== null) {
          const spot = await tx.spotAt(draft.worldId, x, y);
          if (!spot || spot.userId === targetId) {
            draft.x = x;
            draft.y = y;
          }
        }
        draft.resourcesUpdatedAt = now;
        draft.isGodAction = true;
        after = godSummary(draft);
        return [];
      },
      async (tx, _draft, now) => {
        await tx.admin.addAudit({
          ...this.audit(actor, 'snapshot_restore', targetId, { snapshotId }, before, after),
          createdAt: now,
        });
      },
      { wrap: (castle) => ({ castle }) },
    );
  }

  // ── Карта, бой, игроки, братства, чат ─────────────────────────────────────

  /** Сбрасывает состояние клетки: лагерь снова на месте, ресурсная точка полна. */
  async cellReset(actor: Actor, x: number, y: number): Promise<void> {
    await this.deps.repo.transaction(async (tx) => {
      await tx.saveCellState(this.worldId, { x, y, remaining: null, resetAt: null });
      await tx.admin.addAudit(this.audit(actor, 'cell_reset', null, { x, y }));
    });
  }

  /**
   * Симулятор боя: любые два отряда, данные игры не меняются. Исход можно потребовать: тогда бонусы нужной
   * стороны растут шагами по +25%, пока она не победит; итоговая прибавка возвращается в ответе — подгонка не скрывается.
   */
  simulate(input: {
    attacker: UnitCounts;
    defender: UnitCounts;
    attackerBonus: Bonus;
    defenderBonus: Bonus;
    seed: number;
    force?: 'attacker' | 'defender' | undefined;
  }): { seed: number; forcedBonus: number; result: BattleResult } {
    const spread = (v: number): Record<UnitType, number> =>
      Object.fromEntries(UNIT_TYPES.map((t) => [t, v])) as Record<UnitType, number>;
    const run = (boost: number) => {
      const a = input.force === 'attacker' ? boost : 0;
      const d = input.force === 'defender' ? boost : 0;
      return simulateBattle({
        attacker: {
          units: input.attacker,
          attackBonus: spread(input.attackerBonus.attack + a),
          defenseBonus: input.attackerBonus.defense + a,
        },
        defender: {
          units: input.defender,
          attackBonus: spread(input.defenderBonus.attack + d),
          defenseBonus: input.defenderBonus.defense + d,
        },
        seed: input.seed,
      });
    };
    let boost = 0;
    let result = run(boost);
    while (input.force && result.winner !== input.force && boost < 20) {
      boost += 0.25;
      result = run(boost);
    }
    if (input.force && result.winner !== input.force)
      throw Errors.conflict('Outcome cannot be forced for these armies');
    return { seed: input.seed, forcedBonus: boost, result };
  }

  /**
   * Вход под игроком: короткий токен с пометкой владельца. Все изменяющие запросы под ним пишутся в аудит
   * (хук в app.ts); на режим бога и админку такой токен не действует — там роль игрока.
   */
  async impersonate(actor: Actor, targetId: string): Promise<AuthResponse> {
    const target = await this.requireUser(targetId);
    if (effectiveRole(target, this.deps.ownerEmail) !== 'PLAYER') throw Errors.forbidden();
    const now = this.deps.clock.now();
    const ttl = Math.min(IMPERSONATION_SECONDS, this.deps.tokens.ttl);
    const accessToken = await this.deps.tokens.sign({ userId: target.id, role: 'PLAYER' }, now, {
      actorId: actor.user.id,
      ttlSeconds: ttl,
    });
    await this.deps.repo.transaction((tx) =>
      tx.admin.addAudit(this.audit(actor, 'impersonate', target.id, { seconds: ttl })),
    );
    return {
      accessToken,
      expiresIn: ttl,
      user: toUserDto(target, this.deps.ownerEmail),
      serverTime: now.toISOString(),
    };
  }

  /** Назначение администратора. Владельца назначает только CLI (D-19), поэтому здесь доступны PLAYER и ADMIN. */
  async setRole(actor: Actor, targetId: string, role: 'PLAYER' | 'ADMIN') {
    const target = await this.requireUser(targetId);
    if (target.id === actor.user.id || effectiveRole(target, this.deps.ownerEmail) === 'OWNER')
      throw Errors.forbidden();
    await this.deps.users.setRole(target.id, role);
    await this.deps.repo.transaction((tx) =>
      tx.admin.addAudit(
        this.audit(actor, 'set_role', target.id, { role }, { role: target.role }, { role }),
      ),
    );
    return toAdminUser({ ...target, role });
  }

  async deleteGuild(actor: Actor, guildId: string): Promise<void> {
    await this.deps.repo.transaction(async (tx) => {
      const guild = await tx.guilds.get(guildId);
      if (!guild) throw Errors.notFound('Guild');
      await tx.guilds.deleteGuild(guildId);
      await tx.admin.addAudit(
        this.audit(actor, 'delete_guild', null, { guildId, name: guild.name }),
      );
    });
  }

  async announce(actor: Actor, text: string) {
    const msg = await this.deps.chat.announce(actor.user.id, text);
    await this.deps.repo.transaction((tx) =>
      tx.admin.addAudit(this.audit(actor, 'announce', null, { text })),
    );
    return msg;
  }

  async debug(): Promise<GodDebugDto> {
    const counts = await this.deps.repo.transaction((tx) => tx.admin.counts(this.worldId));
    return {
      uptimeSeconds: Math.round(process.uptime()),
      memoryMb: Math.round(process.memoryUsage().rss / 1_048_576),
      online: this.deps.hub.online,
      counts,
      redis: await this.deps.redis(),
      serverTime: this.deps.clock.now().toISOString(),
    };
  }

  async reseed(actor: Actor) {
    if (!this.deps.reseed) throw Errors.conflict('Re-seed is not available');
    const r = await this.deps.reseed();
    await this.deps.repo.transaction((tx) =>
      tx.admin.addAudit(this.audit(actor, 'reseed', null, r)),
    );
    return r;
  }

  /** Запись в аудит (для роутов, которые сами не меняют данные, но должны оставить след). */
  record(
    actor: Actor,
    action: string,
    target: string | null,
    params: unknown,
    before?: unknown,
    after?: unknown,
  ) {
    return this.deps.repo.transaction((tx) =>
      tx.admin.addAudit(this.audit(actor, action, target, params, before, after)),
    );
  }
}
