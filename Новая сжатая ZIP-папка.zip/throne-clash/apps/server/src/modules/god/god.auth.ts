import { randomUUID } from 'node:crypto';
import type { Clock } from '../../lib/clock';
import { AppError, Errors } from '../../lib/errors';
import { randomToken, sha256 } from '../../lib/tokens';
import { verifyTotp } from '../../lib/totp';
import type { AuditRecord, GodSessionRecord } from '../admin/admin.types';
import type { SecurityLogger } from '../abuse/abuse';
import type { PasswordHasher } from '../auth/auth.service';
import type { SecurityLogRepository, UserRecord } from '../auth/auth.types';
import type { CastleRepository } from '../castle/castle.types';

/** Пять неверных попыток входа в режим бога — блокировка на 15 минут для пары IP + аккаунт (D-49). */
export const GOD_MAX_FAILURES = 5;
export const GOD_LOCK_SECONDS = 15 * 60;

export interface GodAuthDeps {
  repo: CastleRepository;
  security: SecurityLogRepository;
  logger: SecurityLogger;
  hasher: PasswordHasher;
  clock: Clock;
  passwordHash: string;
  totpSecret: string;
  sessionMinutes: number;
}

/**
 * Второй фактор режима бога: пароль (argon2-хеш из окружения) и, если задан секрет, одноразовый код TOTP.
 * Успех создаёт серверную сессию — токен клиенту, в БД только его хеш. Срок скользящий: каждый запрос
 * продлевает сессию, простой дольше `sessionMinutes` её завершает.
 */
export class GodAuth {
  constructor(private readonly deps: GodAuthDeps) {}

  get totpRequired(): boolean {
    return this.deps.totpSecret !== '';
  }

  async login(
    user: UserRecord,
    ip: string,
    password: string,
    totp: string | undefined,
  ): Promise<{ token: string; expiresAt: Date }> {
    const { clock, security, logger } = this.deps;
    const now = clock.now();
    const since = new Date(now.getTime() - GOD_LOCK_SECONDS * 1000);
    const failures = await security.count({
      kind: 'god_login_failed',
      since,
      ip,
      userId: user.id,
    });
    if (failures >= GOD_MAX_FAILURES) {
      logger.log('god_login_blocked', { userId: user.id, ip }, undefined, 5 * 60_000);
      throw Errors.locked(GOD_LOCK_SECONDS);
    }

    const passwordOk =
      this.deps.passwordHash !== '' &&
      (await this.deps.hasher.verify(this.deps.passwordHash, password));
    // Код проверяем всегда, когда он требуется: по времени ответа нельзя понять, какой из факторов неверен
    const totpOk =
      !this.totpRequired ||
      (totp !== undefined && verifyTotp(this.deps.totpSecret, totp, now.getTime()));
    if (!passwordOk || !totpOk) {
      logger.log('god_login_failed', { userId: user.id, ip }, undefined, 0);
      throw new AppError('ERR_INVALID_CREDENTIALS', 401, 'Invalid credentials');
    }

    const token = randomToken(32);
    const expiresAt = new Date(now.getTime() + this.deps.sessionMinutes * 60_000);
    const session: GodSessionRecord = {
      id: randomUUID(),
      userId: user.id,
      tokenHash: sha256(token),
      ip,
      createdAt: now,
      lastSeenAt: now,
      expiresAt,
    };
    const audit: AuditRecord = {
      id: randomUUID(),
      scope: 'god',
      actorId: user.id,
      action: 'login',
      targetUserId: null,
      params: { totp: this.totpRequired },
      before: null,
      after: null,
      ip,
      createdAt: now,
    };
    await this.deps.repo.transaction(async (tx) => {
      await tx.admin.createGodSession(session);
      await tx.admin.addAudit(audit);
    });
    logger.log('god_login', { userId: user.id, ip }, undefined, 0);
    return { token, expiresAt };
  }

  /** Сессия по токену из cookie; продлевает срок. null — нет такой или истекла. */
  async verify(
    token: string | undefined,
    userId: string,
  ): Promise<{ session: GodSessionRecord; expiresAt: Date } | null> {
    if (!token) return null;
    const now = this.deps.clock.now();
    return this.deps.repo.transaction(async (tx) => {
      const session = await tx.admin.findGodSession(sha256(token));
      if (!session || session.userId !== userId) return null;
      if (session.expiresAt <= now) {
        await tx.admin.deleteGodSession(session.id);
        return null;
      }
      const expiresAt = new Date(now.getTime() + this.deps.sessionMinutes * 60_000);
      await tx.admin.slideGodSession(session.id, now, expiresAt);
      return { session, expiresAt };
    });
  }

  async logout(session: GodSessionRecord, ip: string): Promise<void> {
    await this.deps.repo.transaction(async (tx) => {
      await tx.admin.deleteGodSession(session.id);
      await tx.admin.addAudit({
        id: randomUUID(),
        scope: 'god',
        actorId: session.userId,
        action: 'logout',
        targetUserId: null,
        params: null,
        before: null,
        after: null,
        ip,
        createdAt: this.deps.clock.now(),
      });
    });
  }
}
