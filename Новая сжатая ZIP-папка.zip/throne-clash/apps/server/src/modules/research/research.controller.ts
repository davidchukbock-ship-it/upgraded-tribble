import type { FastifyInstance } from 'fastify';
import type { ZodTypeProvider } from 'fastify-type-provider-zod';
import { z } from 'zod';
import { sendResult } from '../castle/castle.controller';
import {
  castleSchema,
  errorSchema,
  failures,
  idempotencyHeaders,
  researchSchema,
  techKey,
} from '../castle/castle.schema';
import type { CastleService } from '../castle/castle.service';
import type { ResearchService } from './research.service';

export function registerResearchRoutes(
  app: FastifyInstance,
  research: ResearchService,
  castle: CastleService,
): void {
  const r = app.withTypeProvider<ZodTypeProvider>();
  const tags = ['research'];
  const security = [{ bearerAuth: [] }];
  const taskParams = z.object({ taskId: z.string().uuid() });

  r.get(
    '/research',
    {
      preHandler: app.authenticate,
      schema: {
        tags,
        summary: 'Технологии Академии и очередь исследований',
        security,
        response: { 200: researchSchema, 401: errorSchema, 404: errorSchema },
      },
    },
    async (req) => (await castle.view(req.auth!.user.id)).research,
  );

  r.post(
    '/research/:key/start',
    {
      preHandler: app.authenticate,
      schema: {
        tags,
        summary: 'Начать исследование следующего уровня технологии',
        security,
        headers: idempotencyHeaders,
        params: z.object({ key: techKey }),
        response: { 200: castleSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await research.start(req.auth!.user.id, req.params.key, req.headers['idempotency-key']),
      ),
  );

  r.post(
    '/research/queue/:taskId/cancel',
    {
      preHandler: app.authenticate,
      schema: {
        tags,
        summary: 'Отменить исследование (возврат 50%)',
        security,
        headers: idempotencyHeaders,
        params: taskParams,
        response: { 200: castleSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await research.cancel(req.auth!.user.id, req.params.taskId, req.headers['idempotency-key']),
      ),
  );

  r.post(
    '/research/queue/:taskId/speedup',
    {
      preHandler: app.authenticate,
      schema: {
        tags,
        summary: 'Ускорить идущее исследование за кристаллы',
        security,
        headers: idempotencyHeaders,
        params: taskParams,
        response: { 200: castleSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await research.speedup(
          req.auth!.user.id,
          req.params.taskId,
          req.headers['idempotency-key'],
        ),
      ),
  );
}
