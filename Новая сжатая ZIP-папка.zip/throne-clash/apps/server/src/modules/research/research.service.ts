import { randomUUID } from 'node:crypto';
import {
  MAX_TECH_LEVEL,
  RESEARCH_QUEUE_MAX,
  academyLevelFor,
  addAmounts,
  cancelRefund,
  shortfall,
  speedupGems,
  subtractCost,
  techCost,
  mageResearchBonus,
  techSeconds,
  type TechKey,
} from '@tc/shared';
import { Errors } from '../../lib/errors';
import { chainEnd, rechain, settleAggregate } from '../castle/castle.realm';
import {
  gemEvent,
  negate,
  resourceEvents,
  type CastleResult,
  type RealmRunner,
} from '../castle/castle.runner';

/** Академия: изучение технологий, отмена и ускорение. */
export class ResearchService {
  constructor(private readonly runner: RealmRunner) {}

  start(userId: string, tech: TechKey, idemKey: string): Promise<CastleResult> {
    return this.runner.mutate(userId, `research:${tech}`, idemKey, (draft, now) => {
      if (draft.research.some((t) => t.tech === tech))
        throw Errors.requirementNotMet({ reason: 'in_progress' });
      const next = (draft.tech[tech] ?? 0) + 1;
      if (next > MAX_TECH_LEVEL) throw Errors.requirementNotMet({ reason: 'max_level' });
      const need = academyLevelFor(next);
      if ((draft.levels.academy ?? 0) < need) {
        throw Errors.requirementNotMet({ reason: 'academy_level', required: need });
      }
      if (draft.research.length >= RESEARCH_QUEUE_MAX) throw Errors.queueFull();

      const cost = techCost(tech, next);
      const missing = shortfall(draft.resources, cost);
      if (Object.keys(missing).length > 0) throw Errors.insufficientResources({ missing });
      draft.resources = subtractCost(draft.resources, cost);

      const start = chainEnd(draft.research, now);
      draft.research.push({
        id: randomUUID(),
        tech,
        toLevel: next,
        startedAt: start,
        finishesAt: new Date(
          start.getTime() +
            techSeconds(
              tech,
              next,
              draft.worldSpeed,
              mageResearchBonus(draft.levels.magetower ?? 0),
            ) *
              1000,
        ),
        paid: cost,
        isGodAction: draft.isGodAction,
      });
      return resourceEvents(draft, now, 'research_cost', negate(cost));
    });
  }

  cancel(userId: string, taskId: string, idemKey: string): Promise<CastleResult> {
    return this.runner.mutate(userId, `research-cancel:${taskId}`, idemKey, (draft, now) => {
      const task = draft.research.find((t) => t.id === taskId);
      if (!task) throw Errors.notFound('Research');
      const refund = cancelRefund(task.paid);
      draft.resources = addAmounts(draft.resources, refund);
      draft.research = draft.research.filter((t) => t.id !== taskId);
      rechain(draft.research, now);
      return resourceEvents(draft, now, 'research_refund', refund);
    });
  }

  speedup(userId: string, taskId: string, idemKey: string): Promise<CastleResult> {
    return this.runner.mutate(userId, `research-speedup:${taskId}`, idemKey, (draft, now, emit) => {
      const sorted = [...draft.research].sort(
        (a, b) => a.finishesAt.getTime() - b.finishesAt.getTime(),
      );
      const task = draft.research.find((t) => t.id === taskId);
      if (!task) throw Errors.notFound('Research');
      if (sorted[0]?.id !== taskId) throw Errors.requirementNotMet({ reason: 'not_active' });
      const gems = speedupGems(
        Math.max(0, Math.ceil((task.finishesAt.getTime() - now.getTime()) / 1000)),
      );
      if (draft.gems < gems)
        throw Errors.insufficientResources({ missing: { gems: gems - draft.gems } });
      draft.gems -= gems;
      task.finishesAt = now;
      const settled = settleAggregate(draft, now);
      emit(settled.events);
      Object.assign(draft, settled.draft);
      rechain(draft.research, now);
      return [gemEvent(draft, now, 'research_speedup', -gems)];
    });
  }
}
