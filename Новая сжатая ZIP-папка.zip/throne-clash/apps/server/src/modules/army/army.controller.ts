import type { FastifyInstance } from 'fastify';
import type { ZodTypeProvider } from 'fastify-type-provider-zod';
import { z } from 'zod';
import type { UnitId } from '@tc/shared';
import { sendResult } from '../castle/castle.controller';
import {
  armySchema,
  castleSchema,
  errorSchema,
  failures,
  idempotencyHeaders,
  unitTier,
  unitType,
} from '../castle/castle.schema';
import type { CastleService } from '../castle/castle.service';
import type { ArmyService } from './army.service';

export function registerArmyRoutes(
  app: FastifyInstance,
  army: ArmyService,
  castle: CastleService,
): void {
  const r = app.withTypeProvider<ZodTypeProvider>();
  const tags = ['army'];
  const security = [{ bearerAuth: [] }];
  const taskParams = z.object({ taskId: z.string().uuid() });

  r.get(
    '/army',
    {
      preHandler: app.authenticate,
      schema: {
        tags,
        summary: 'Войска, очередь обучения, лимит и содержание',
        security,
        response: { 200: armySchema, 401: errorSchema, 404: errorSchema },
      },
    },
    async (req) => (await castle.view(req.auth!.user.id)).army,
  );

  r.post(
    '/army/train',
    {
      preHandler: app.authenticate,
      schema: {
        tags,
        summary: 'Поставить партию войск в обучение (оплата при постановке)',
        security,
        headers: idempotencyHeaders,
        body: z
          .object({ type: unitType, tier: unitTier, count: z.number().int().min(1).max(100_000) })
          .strict(),
        response: { 200: castleSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await army.train(
          req.auth!.user.id,
          req.body.type,
          req.body.tier,
          req.body.count,
          req.headers['idempotency-key'],
        ),
      ),
  );

  r.post(
    '/army/queue/:taskId/cancel',
    {
      preHandler: app.authenticate,
      schema: {
        tags,
        summary: 'Отменить партию (возврат 50%)',
        security,
        headers: idempotencyHeaders,
        params: taskParams,
        response: { 200: castleSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await army.cancel(req.auth!.user.id, req.params.taskId, req.headers['idempotency-key']),
      ),
  );

  r.post(
    '/army/queue/:taskId/speedup',
    {
      preHandler: app.authenticate,
      schema: {
        tags,
        summary: 'Ускорить идущую партию за кристаллы',
        security,
        headers: idempotencyHeaders,
        params: taskParams,
        response: { 200: castleSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await army.speedup(req.auth!.user.id, req.params.taskId, req.headers['idempotency-key']),
      ),
  );

  r.post(
    '/army/heal',
    {
      preHandler: app.authenticate,
      schema: {
        tags,
        summary: 'Вылечить раненых (платно, мгновенно)',
        security,
        headers: idempotencyHeaders,
        body: z
          .object({
            unit: z.string().regex(/^(infantry|archer|cavalry|siege)_[1-5]$/),
            count: z.number().int().min(1).max(100_000),
          })
          .strict(),
        response: { 200: castleSchema, ...failures },
      },
    },
    async (req, reply) =>
      sendResult(
        reply,
        await army.heal(
          req.auth!.user.id,
          req.body.unit as UnitId,
          req.body.count,
          req.headers['idempotency-key'],
        ),
      ),
  );
}
