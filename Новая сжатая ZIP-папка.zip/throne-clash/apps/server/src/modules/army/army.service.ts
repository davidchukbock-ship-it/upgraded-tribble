import { randomUUID } from 'node:crypto';
import {
  MAX_TRAIN_QUEUE,
  addAmounts,
  armyCap,
  armyCount,
  barracksLevelForTier,
  cancelRefund,
  healCost,
  parseUnitId,
  type UnitId,
  maxTierFor,
  shortfall,
  speedupGems,
  subtractCost,
  techEffects,
  trainCost,
  trainSeconds,
  unitId,
  type UnitTier,
  type UnitType,
} from '@tc/shared';
import { Errors } from '../../lib/errors';
import {
  barracksLevel,
  chainEnd,
  marchingCount,
  rechain,
  settleAggregate,
} from '../castle/castle.realm';
import {
  gemEvent,
  negate,
  resourceEvents,
  type CastleResult,
  type RealmRunner,
} from '../castle/castle.runner';

/** Войска: постановка партий в обучение, отмена и ускорение. */
export class ArmyService {
  constructor(private readonly runner: RealmRunner) {}

  train(
    userId: string,
    type: UnitType,
    tier: UnitTier,
    count: number,
    idemKey: string,
  ): Promise<CastleResult> {
    return this.runner.mutate(
      userId,
      `train:${type}:${tier}:${count}`,
      idemKey,
      (draft, now) => {
        const barracks = barracksLevel(draft);
        if (barracks < 1) throw Errors.requirementNotMet({ reason: 'no_barracks' });
        if (tier > maxTierFor(barracks)) {
          throw Errors.requirementNotMet({
            reason: 'tier_locked',
            required: barracksLevelForTier(tier),
          });
        }
        if (draft.trains.length >= MAX_TRAIN_QUEUE) throw Errors.queueFull();

        // Лимит армии считает и тех, кто ещё в обучении
        const cap = armyCap(barracks);
        const used =
          armyCount(draft.army) +
          marchingCount(draft) +
          draft.trains.reduce((s, t) => s + t.count, 0);
        if (used + count > cap) {
          throw Errors.requirementNotMet({
            reason: 'army_cap',
            cap,
            free: Math.max(0, cap - used),
          });
        }

        const cost = trainCost(type, tier, count);
        const missing = shortfall(draft.resources, cost);
        if (Object.keys(missing).length > 0) throw Errors.insufficientResources({ missing });
        draft.resources = subtractCost(draft.resources, cost);

        const seconds = trainSeconds(
          type,
          tier,
          count,
          barracks,
          techEffects(draft.tech).trainTime,
          draft.worldSpeed,
        );
        const start = chainEnd(draft.trains, now);
        draft.trains.push({
          id: randomUUID(),
          unit: unitId(type, tier),
          count,
          startedAt: start,
          finishesAt: new Date(start.getTime() + seconds * 1000),
          paid: cost,
          isGodAction: draft.isGodAction,
        });
        return resourceEvents(draft, now, 'train_cost', negate(cost));
      },
      undefined,
      { bump: { train: count } },
    );
  }

  cancel(userId: string, taskId: string, idemKey: string): Promise<CastleResult> {
    return this.runner.mutate(userId, `train-cancel:${taskId}`, idemKey, (draft, now) => {
      const task = draft.trains.find((t) => t.id === taskId);
      if (!task) throw Errors.notFound('Training batch');
      const refund = cancelRefund(task.paid);
      draft.resources = addAmounts(draft.resources, refund);
      draft.trains = draft.trains.filter((t) => t.id !== taskId);
      rechain(draft.trains, now); // следующие партии подтягиваются вперёд
      return resourceEvents(draft, now, 'train_refund', refund);
    });
  }

  /** Ускорить можно только идущую партию (первую в цепочке). */
  speedup(userId: string, taskId: string, idemKey: string): Promise<CastleResult> {
    return this.runner.mutate(userId, `train-speedup:${taskId}`, idemKey, (draft, now, emit) => {
      const sorted = [...draft.trains].sort(
        (a, b) => a.finishesAt.getTime() - b.finishesAt.getTime(),
      );
      const task = draft.trains.find((t) => t.id === taskId);
      if (!task) throw Errors.notFound('Training batch');
      if (sorted[0]?.id !== taskId) throw Errors.requirementNotMet({ reason: 'not_active' });
      const gems = speedupGems(
        Math.max(0, Math.ceil((task.finishesAt.getTime() - now.getTime()) / 1000)),
      );
      if (draft.gems < gems)
        throw Errors.insufficientResources({ missing: { gems: gems - draft.gems } });
      draft.gems -= gems;
      task.finishesAt = now;
      const settled = settleAggregate(draft, now);
      emit(settled.events);
      Object.assign(draft, settled.draft);
      rechain(draft.trains, now);
      return [gemEvent(draft, now, 'train_speedup', -gems)];
    });
  }

  /** Лечение раненых в госпитале: платно, мгновенно; вылеченные возвращаются в строй. */
  heal(userId: string, unit: UnitId, count: number, idemKey: string): Promise<CastleResult> {
    return this.runner.mutate(userId, `heal:${unit}:${count}`, idemKey, (draft, now) => {
      const parsed = parseUnitId(unit);
      const stack = draft.army[unit];
      if (!parsed || !stack) throw Errors.notFound('Unit');
      if (stack.wounded < count) throw Errors.requirementNotMet({ reason: 'not_enough_wounded' });
      const cost = healCost(parsed.type, parsed.tier, count, techEffects(draft.tech).healDiscount);
      const missing = shortfall(draft.resources, cost);
      if (Object.keys(missing).length > 0) throw Errors.insufficientResources({ missing });
      draft.resources = subtractCost(draft.resources, cost);
      draft.army[unit] = { count: stack.count + count, wounded: stack.wounded - count };
      return resourceEvents(draft, now, 'heal_cost', negate(cost));
    });
  }
}
