import type { Clock } from '../../lib/clock';

/** Проверка зависимости для /health (БД, Redis). */
export interface Probe {
  name: 'db' | 'redis';
  check(): Promise<void>;
}

export interface HealthReport {
  status: 'ok' | 'degraded';
  checks: Record<string, 'up' | 'down'>;
  serverTime: string;
  uptimeSeconds: number;
}

const PROBE_TIMEOUT_MS = 2000;

const withTimeout = <T>(p: Promise<T>, ms: number): Promise<T> =>
  new Promise<T>((resolve, reject) => {
    const t = setTimeout(() => reject(new Error('timeout')), ms);
    p.then(
      (v) => {
        clearTimeout(t);
        resolve(v);
      },
      (e: unknown) => {
        clearTimeout(t);
        reject(e instanceof Error ? e : new Error(String(e)));
      },
    );
  });

export class HealthService {
  constructor(
    private probes: Probe[],
    private clock: Clock,
    private startedAt: Date = clock.now(),
  ) {}

  async report(): Promise<HealthReport> {
    const results = await Promise.all(
      this.probes.map(async (p): Promise<[string, 'up' | 'down']> => {
        try {
          await withTimeout(p.check(), PROBE_TIMEOUT_MS);
          return [p.name, 'up'];
        } catch {
          return [p.name, 'down']; // причину не отдаём наружу — она в логах
        }
      }),
    );
    const checks = Object.fromEntries(results);
    const now = this.clock.now();
    return {
      status: results.every(([, s]) => s === 'up') ? 'ok' : 'degraded',
      checks,
      serverTime: now.toISOString(),
      uptimeSeconds: Math.max(0, Math.floor((now.getTime() - this.startedAt.getTime()) / 1000)),
    };
  }
}
