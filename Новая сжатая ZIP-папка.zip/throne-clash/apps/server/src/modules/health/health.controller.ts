import type { FastifyInstance } from 'fastify';
import type { ZodTypeProvider } from 'fastify-type-provider-zod';
import { z } from 'zod';
import type { HealthService } from './health.service';

const healthSchema = z.object({
  status: z.enum(['ok', 'degraded']),
  checks: z.record(z.enum(['up', 'down'])),
  serverTime: z.string(),
  uptimeSeconds: z.number(),
});

export function registerHealthRoutes(app: FastifyInstance, health: HealthService): void {
  app.withTypeProvider<ZodTypeProvider>().get(
    '/health',
    {
      config: { rateLimit: false },
      schema: {
        tags: ['system'],
        summary: 'Состояние сервиса и зависимостей',
        response: { 200: healthSchema, 503: healthSchema },
      },
    },
    async (_req, reply) => {
      const report = await health.report();
      return reply.code(report.status === 'ok' ? 200 : 503).send(report);
    },
  );
}
