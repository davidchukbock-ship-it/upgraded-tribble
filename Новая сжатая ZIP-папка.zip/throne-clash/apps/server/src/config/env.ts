import { z } from 'zod';
import type { DonateMode } from '@tc/shared';

const bool = z.enum(['true', 'false', '1', '0']).transform((v) => v === 'true' || v === '1');

/** Плейсхолдер из .env.example — в production с ним сервер не стартует. */
export const SECRET_PLACEHOLDER = 'change-me-to-a-long-random-string-of-at-least-32-chars';

const schema = z
  .object({
    NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
    HOST: z.string().default('0.0.0.0'),
    PORT: z.coerce.number().int().min(1).max(65535).default(3000),
    LOG_LEVEL: z
      .enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent'])
      .default('info'),

    DATABASE_URL: z.string().min(1).default('postgresql://throne:throne@localhost:5432/throne'),
    REDIS_URL: z.string().min(1).default('redis://localhost:6379'),
    /** Каталог собранного сайта: если задан, сервер отдаёт его сам (без nginx). */
    WEB_DIST: z.string().optional(),

    CORS_ORIGIN: z.string().default('http://localhost:5173'),
    JWT_ACCESS_SECRET: z.string().min(1).default(SECRET_PLACEHOLDER),
    JWT_ACCESS_TTL_SECONDS: z.coerce.number().int().min(60).default(900),
    REFRESH_TTL_DAYS: z.coerce.number().int().min(1).default(30),
    COOKIE_SECURE: bool.optional(),

    TRUST_PROXY: bool.optional(),
    AUTH_LOGIN_RATE_MAX: z.coerce.number().int().min(1).default(10),
    AUTH_REGISTER_RATE_MAX: z.coerce.number().int().min(1).default(10),
    AUTH_GUEST_RATE_MAX: z.coerce.number().int().min(1).default(20),
    AUTH_REFRESH_RATE_MAX: z.coerce.number().int().min(1).default(60),
    WORLD_SEED: z.coerce.number().int().default(20260101),
    /** Версия карты для НОВОГО мира: 1 — исходная, 2 — биомы, реки, моря, дороги (D-74). */
    MAP_VERSION: z.coerce.number().int().min(1).max(2).default(2),
    RATE_LIMIT_MAX: z.coerce.number().int().min(1).default(300),
    RATE_LIMIT_WINDOW: z.string().default('1 minute'),
    SWAGGER_ENABLED: bool.optional(),

    OWNER_EMAIL: z.string().default(''),
    GOD_MODE_ENABLED: bool.optional(),
    GOD_MODE_PASSWORD_HASH: z.string().default(''),
    GOD_MODE_TOTP_SECRET: z.string().default(''),
    GOD_SESSION_MINUTES: z.coerce.number().int().min(1).max(240).default(30),
    LEAGUE_CACHE_SECONDS: z.coerce.number().int().min(0).max(300).optional(),
    ACTION_RATE_MAX: z.coerce.number().int().min(1).default(60),
    /** Оплата донатов: off — выключена, test — кристаллы без денег (только разработка, D-62). */
    PAYMENTS_MODE: z.enum(['off', 'test']).default('off'),
  })
  .superRefine((v, ctx) => {
    if (v.NODE_ENV === 'production') {
      if (v.JWT_ACCESS_SECRET === SECRET_PLACEHOLDER || v.JWT_ACCESS_SECRET.length < 32) {
        ctx.addIssue({
          code: 'custom',
          path: ['JWT_ACCESS_SECRET'],
          message: 'В production нужен уникальный секрет длиной от 32 символов',
        });
      }
      if (v.PAYMENTS_MODE === 'test') {
        ctx.addIssue({
          code: 'custom',
          path: ['PAYMENTS_MODE'],
          message: 'Тестовые платежи выдают кристаллы даром и запрещены в production',
        });
      }
      if (v.GOD_MODE_ENABLED === true && !v.GOD_MODE_PASSWORD_HASH) {
        ctx.addIssue({
          code: 'custom',
          path: ['GOD_MODE_PASSWORD_HASH'],
          message: 'Режим бога включён, но хеш пароля не задан (pnpm god:hash)',
        });
      }
    }
  });

export interface AppConfig {
  env: 'development' | 'test' | 'production';
  isProduction: boolean;
  host: string;
  port: number;
  logLevel: string;
  databaseUrl: string;
  redisUrl: string;
  /** Каталог собранного сайта (WEB_DIST): сервер отдаёт его сам. */
  webDist?: string | undefined;
  corsOrigins: string[];
  jwtAccessSecret: string;
  jwtAccessTtlSeconds: number;
  refreshTtlDays: number;
  cookieSecure: boolean;
  trustProxy: boolean;
  rateLimitMax: number;
  rateLimitWindow: string;
  /** Лимиты на попытки (в окне): вход — 1 минута, регистрация и гости — 1 час, по IP. */
  authRateLimit: {
    loginPerMinute: number;
    registerPerHour: number;
    guestPerHour: number;
    refreshPerMinute: number;
  };
  worldSeed: number;
  mapVersion: 1 | 2;
  swaggerEnabled: boolean;
  ownerEmail: string;
  godMode: { enabled: boolean; passwordHash: string; totpSecret: string; sessionMinutes: number };
  /** Изменяющих запросов на игрока за 10 секунд (поверх лимита по IP). */
  actionRateMax: number;
  /** Оплата донатов: off — выключена, test — без денег (D-62). */
  paymentsMode: DonateMode;
  /** Кэш таблицы лиги, секунды (в тестах 0). */
  leagueCacheSeconds: number;
}

/**
 * Читает и проверяет переменные окружения. Ошибки перечисляются все сразу.
 * Умолчания безопасны: в production режим бога и Swagger выключены, cookie — Secure.
 */
export function loadConfig(source: Record<string, string | undefined> = process.env): AppConfig {
  const parsed = schema.safeParse(source);
  if (!parsed.success) {
    const lines = parsed.error.issues.map((i) => `  - ${i.path.join('.')}: ${i.message}`);
    throw new Error(`Некорректная конфигурация:\n${lines.join('\n')}`);
  }
  const v = parsed.data;
  const isProduction = v.NODE_ENV === 'production';
  return {
    env: v.NODE_ENV,
    isProduction,
    host: v.HOST,
    port: v.PORT,
    logLevel: v.NODE_ENV === 'test' ? 'silent' : v.LOG_LEVEL,
    databaseUrl: v.DATABASE_URL,
    redisUrl: v.REDIS_URL,
    webDist: v.WEB_DIST,
    corsOrigins: v.CORS_ORIGIN.split(',')
      .map((s) => s.trim())
      .filter(Boolean),
    jwtAccessSecret: v.JWT_ACCESS_SECRET,
    jwtAccessTtlSeconds: v.JWT_ACCESS_TTL_SECONDS,
    refreshTtlDays: v.REFRESH_TTL_DAYS,
    cookieSecure: v.COOKIE_SECURE ?? isProduction,
    trustProxy: v.TRUST_PROXY ?? isProduction,
    rateLimitMax: v.RATE_LIMIT_MAX,
    rateLimitWindow: v.RATE_LIMIT_WINDOW,
    authRateLimit: {
      loginPerMinute: v.AUTH_LOGIN_RATE_MAX,
      registerPerHour: v.AUTH_REGISTER_RATE_MAX,
      guestPerHour: v.AUTH_GUEST_RATE_MAX,
      refreshPerMinute: v.AUTH_REFRESH_RATE_MAX,
    },
    worldSeed: v.WORLD_SEED,
    mapVersion: v.MAP_VERSION === 1 ? 1 : 2,
    swaggerEnabled: v.SWAGGER_ENABLED ?? !isProduction,
    ownerEmail: v.OWNER_EMAIL.trim().toLowerCase(),
    godMode: {
      // Режим бога: включён по умолчанию только в разработке (D-13)
      enabled: v.GOD_MODE_ENABLED ?? v.NODE_ENV === 'development',
      passwordHash: v.GOD_MODE_PASSWORD_HASH,
      totpSecret: v.GOD_MODE_TOTP_SECRET,
      sessionMinutes: v.GOD_SESSION_MINUTES,
    },
    actionRateMax: v.ACTION_RATE_MAX,
    paymentsMode: v.PAYMENTS_MODE,
    leagueCacheSeconds: v.LEAGUE_CACHE_SECONDS ?? (v.NODE_ENV === 'test' ? 0 : 5),
  };
}
