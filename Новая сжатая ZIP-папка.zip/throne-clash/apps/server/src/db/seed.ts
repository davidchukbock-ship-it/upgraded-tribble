import type { PrismaClient } from '@prisma/client';
import {
  BUILDING_KEYS,
  DEFAULT_CRESTS,
  MAIN_WORLD_ID,
  START_BUILDINGS,
  START_GEMS,
  START_RESOURCES,
  castlePower,
  hashSeed,
  mulberry32,
  nicknameKey,
  type BuildingKey,
} from '@tc/shared';
import { hashPassword } from '../lib/password';
import { ensureMainWorld } from './bootstrap';

const BOT_NAMES = [
  'Рагнар',
  'Ярослав',
  'Эйрик',
  'Годфрид',
  'Бранка',
  'Далибор',
  'Свенья',
  'Томас Кромвель',
  'Ольгерд',
  'Изольда',
  'Мстислав',
  'Хельга',
  'Вальдемар',
  'Ульрих',
  'Гвиневра',
  'Борислав',
  'Альрик',
  'Мирослава',
  'Гуннар',
  'Ратибор',
  'Эдгар',
  'Лидия Чёрная',
  'Фарамонд',
  'Кассандра',
] as const;

const DEMO_NAMES = ['Демо Рыцарь', 'Демо Лучница', 'Демо Барон'] as const;

export interface SeedOptions {
  /** Сколько ботов создать (по умолчанию все имена из списка). */
  bots?: number;
  /** Демо-игроки с известным паролем. В production выключены, если явно не запрошены. */
  demoPlayers?: { password: string } | null;
  seed?: number;
  now?: Date;
}

export interface SeedResult {
  bots: number;
  demos: number;
}

/**
 * Начальные данные: мир, боты-замки и демо-игроки. Идемпотентно — повторный запуск ничего не дублирует.
 * Боты детерминированы от seed мира: одни и те же имена, гербы и уровни.
 */
export async function seedDatabase(db: PrismaClient, opts: SeedOptions = {}): Promise<SeedResult> {
  const seed = opts.seed ?? 20260101;
  const now = opts.now ?? new Date();
  await ensureMainWorld(db, seed);

  const rng = mulberry32(hashSeed(`bots:${seed}`));
  const names = BOT_NAMES.slice(0, opts.bots ?? BOT_NAMES.length);
  let bots = 0;
  for (const nickname of names) {
    const key = nicknameKey(nickname);
    const crest = DEFAULT_CRESTS[Math.floor(rng() * DEFAULT_CRESTS.length)] ?? 'lion';
    const levels = botLevels(rng);
    const scale = 1 + Math.floor(rng() * 5);
    if (
      await createAccountIfMissing(db, {
        nickname,
        key,
        crest,
        isBot: true,
        email: null,
        passwordHash: null,
        levels,
        scale,
        now,
      })
    )
      bots++;
  }

  let demos = 0;
  if (opts.demoPlayers) {
    const hash = await hashPassword(opts.demoPlayers.password);
    for (const [i, nickname] of DEMO_NAMES.entries()) {
      const created = await createAccountIfMissing(db, {
        nickname,
        key: nicknameKey(nickname),
        crest: DEFAULT_CRESTS[i % DEFAULT_CRESTS.length] ?? 'lion',
        isBot: false,
        email: `demo${i + 1}@example.com`,
        passwordHash: hash,
        levels: Object.fromEntries(START_BUILDINGS.map((k) => [k, 1])) as Partial<
          Record<BuildingKey, number>
        >,
        scale: 1,
        now,
      });
      if (created) demos++;
    }
  }
  return { bots, demos };
}

/** Замок ≥ остальных зданий (как в игре: остальные ограничены уровнем замка), уровни 1–8. */
function botLevels(rng: () => number): Partial<Record<BuildingKey, number>> {
  const castle = 2 + Math.floor(rng() * 7);
  const levels: Partial<Record<BuildingKey, number>> = { castle };
  for (const key of BUILDING_KEYS) {
    if (key === 'castle') continue;
    const isStart = START_BUILDINGS.includes(key);
    if (!isStart && rng() < 0.4) continue; // часть зданий ещё не построена
    levels[key] = 1 + Math.floor(rng() * castle);
  }
  return levels;
}

async function createAccountIfMissing(
  db: PrismaClient,
  a: {
    nickname: string;
    key: string;
    crest: string;
    isBot: boolean;
    email: string | null;
    passwordHash: string | null;
    levels: Partial<Record<BuildingKey, number>>;
    scale: number;
    now: Date;
  },
): Promise<boolean> {
  if (await db.user.findUnique({ where: { nicknameKey: a.key }, select: { id: true } }))
    return false;
  await db.user.create({
    data: {
      nickname: a.nickname,
      nicknameKey: a.key,
      crest: a.crest,
      isBot: a.isBot,
      email: a.email,
      passwordHash: a.passwordHash,
      castles: {
        create: {
          worldId: MAIN_WORLD_ID,
          structures: [],
          gold: START_RESOURCES.gold * a.scale,
          wood: START_RESOURCES.wood * a.scale,
          stone: START_RESOURCES.stone * a.scale,
          food: START_RESOURCES.food * a.scale,
          gems: a.isBot ? 0 : START_GEMS,
          resourcesUpdatedAt: a.now,
          power: castlePower({ army: {}, levels: a.levels, tech: {}, heroLevel: 1 }),
          buildings: {
            create: Object.entries(a.levels).map(([key, level]) => ({ key, level: level ?? 1 })),
          },
        },
      },
    },
  });
  return true;
}
