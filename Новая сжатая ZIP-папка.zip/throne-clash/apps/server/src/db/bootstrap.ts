import type { PrismaClient } from '@prisma/client';
import { MAIN_WORLD_ID, type MapVersion } from '@tc/shared';

/**
 * Живой мир должен существовать до первой регистрации; вызывается при старте и в seed. Идемпотентно.
 * Версия карты применяется только при создании: уже существующий мир остаётся на своей (D-74).
 */
export async function ensureMainWorld(
  db: PrismaClient,
  seed: number,
  mapVersion: MapVersion = 2,
): Promise<void> {
  await db.world.upsert({
    where: { id: MAIN_WORLD_ID },
    update: {},
    create: { id: MAIN_WORLD_ID, name: 'Main', seed, speed: 1, isSandbox: false, mapVersion },
  });
}
