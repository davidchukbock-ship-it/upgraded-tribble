import type { Repositories as AuthRepositories } from './modules/auth/auth.types';
import type { CastleRepository } from './modules/castle/castle.types';

/** Все репозитории приложения. Боевой запуск — Prisma, юнит-тесты — in-memory (D-07). */
export interface Repositories extends AuthRepositories {
  castles: CastleRepository;
}
