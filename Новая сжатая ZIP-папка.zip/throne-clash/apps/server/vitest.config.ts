import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    globalSetup: ['./tests/global-setup.ts'],
    // Тесты с БД очищают таблицы — файлы идут по очереди
    fileParallelism: false,
    include: ['src/**/*.test.ts', 'tests/**/*.test.ts'],
    testTimeout: 15_000,
    hookTimeout: 30_000,
    coverage: {
      provider: 'v8',
      include: ['src/**/*.ts'],
      exclude: [
        'src/**/*.test.ts',
        'src/main.ts',
        'src/cli/**',
        'src/**/*.repository.ts',
        'src/**/*.memory.ts',
      ],
      // Порог для ядра (D-15) ужесточается по мере появления сервисов экономики и боя
      thresholds: { lines: 80, functions: 80, branches: 70, statements: 80 },
    },
  },
});
