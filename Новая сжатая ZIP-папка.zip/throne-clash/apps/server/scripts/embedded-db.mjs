/* eslint-disable no-console */
// PostgreSQL без Docker для локальной разработки: скачанные вместе с зависимостями бинарники,
// данные — в apps/server/.data/pg (переживают перезапуск). Запуск: pnpm db:embedded
import { existsSync, rmSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import EmbeddedPostgres from 'embedded-postgres';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const dir = process.env.TC_PG_DIR ?? join(root, '.data', 'pg');
const port = Number(process.env.PGPORT ?? 5432);

const pg = new EmbeddedPostgres({
  databaseDir: dir,
  user: 'throne',
  password: 'throne',
  port,
  persistent: true,
  onLog: (m) => console.log(String(m).trim()),
  onError: (m) => console.error(String(m).trim()),
});

try {
  if (!existsSync(join(dir, 'PG_VERSION'))) {
    console.log('Initialising database (first run)...');
    rmSync(dir, { recursive: true, force: true }); // остатки прерванной инициализации
    await pg.initialise();
  }
  await pg.start();
  try {
    await pg.createDatabase('throne');
  } catch {
    /* уже существует */
  }
} catch (err) {
  console.error(
    '\nDatabase failed to start:',
    err instanceof Error ? err.message : String(err ?? 'unknown error'),
  );
  console.error(
    'If this window title says "Administrator": close everything and run start-windows.bat from a NORMAL cmd window.',
  );
  process.exit(1);
}

console.log(
  `PostgreSQL ready on localhost:${port} (user throne, db throne). Keep this window open.`,
);

const stop = async () => {
  await pg.stop().catch(() => undefined);
  process.exit(0);
};
process.on('SIGINT', stop);
process.on('SIGTERM', stop);
setInterval(() => undefined, 1 << 30);
