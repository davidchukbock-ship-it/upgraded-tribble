// Строит схему для MySQL/MariaDB из основной (PostgreSQL) — prisma/mysql/schema.prisma.
/* eslint-disable no-console */
// Запуск:  node scripts/gen-mysql-schema.mjs   (см. docs/HOSTINGER.md)
// Отличия: провайдер; длинные строки — @db.Text / VarChar; у Json нет значения по умолчанию (MySQL не поддерживает).
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const src = readFileSync(resolve(root, 'prisma/schema.prisma'), 'utf8');

/** Поля, где текст может быть длиннее 191 символа (стандартная длина строки Prisma в MySQL). */
const TEXT = new Set(['text', 'userAgent', 'reason', 'note', 'banReason']);
const LONG = { description: 1000, email: 255 };

const out = src
  .replace('provider = "postgresql"', 'provider = "mysql"')
  .replace(
    /^\/\/ Схема данных[^\n]*\n/,
    '// СГЕНЕРИРОВАНО scripts/gen-mysql-schema.mjs из ../schema.prisma — не править руками.\n',
  )
  .split('\n')
  .map((line) => {
    const m = line.match(/^(\s+)(\w+)(\s+)String(\??)(\s.*|)$/);
    if (m && !/@db\./.test(line) && !/@id/.test(line)) {
      const [, ind, name, sp, opt, rest] = m;
      const type = TEXT.has(name) ? '@db.Text' : LONG[name] ? `@db.VarChar(${LONG[name]})` : '';
      if (type) return `${ind}${name}${sp}String${opt} ${type}${rest}`.replace(/\s+$/, '');
    }
    // Json @default(...) не поддерживается MySQL
    if (/\bJson\b/.test(line)) return line.replace(/\s*@default\([^)]*\)/, '');
    return line;
  })
  .join('\n');

mkdirSync(resolve(root, 'prisma/mysql'), { recursive: true });
writeFileSync(resolve(root, 'prisma/mysql/schema.prisma'), out);
console.log('prisma/mysql/schema.prisma готов');
