import { START_BUILDINGS, START_GEMS } from '@tc/shared';
import { FakeClock } from '../src/lib/clock';
import { createMemoryRepositories } from '../src/modules/auth/auth.memory';
import { castleFor, userFor } from './repository.contract';
import { socialSuite } from './social.suite';

let n = 0;

socialSuite('in-memory', async () => {
  const repos = createMemoryRepositories();
  const clock = new FakeClock();
  return {
    repo: repos.castles,
    users: repos.users,
    clock,
    async addPlayer(name, opts) {
      const user = await repos.users.createWithCastle(
        {
          ...userFor(name, `s${n++}@example.com`),
          isGuest: opts?.guest ?? false,
          createdAt: clock.now(),
        },
        {
          ...castleFor(),
          buildings: START_BUILDINGS,
          resourcesUpdatedAt: clock.now(),
          gems: START_GEMS,
        },
      );
      return user.id;
    },
  };
});
