import { describe, expect, it } from 'vitest';
import {
  MAP_SIZE,
  MIN_CASTLE_GAP,
  NO_ATTACK_BONUS,
  cargoOf,
  cellAtV,
  fuzzUnits,
  gatherAmount,
  gatherSeconds,
  hashSeed,
  hospitalCapacity,
  nodeCapacity,
  plunder,
  simulateBattle,
  splitCasualties,
  totalUnits,
  travelSeconds,
  warehouseCap,
  healCost,
  type MapCell,
  type MapVersion,
  type MarchType,
} from '@tc/shared';
import type { FakeClock } from '../src/lib/clock';
import { AppError } from '../src/lib/errors';
import { ArmyService } from '../src/modules/army/army.service';
import type { CastleAggregate, CastleRepository } from '../src/modules/castle/castle.types';
import { CastleService } from '../src/modules/castle/castle.service';
import { MapService } from '../src/modules/march/map.service';
import { MarchResolver } from '../src/modules/march/march.resolver';
import { MarchService } from '../src/modules/march/march.service';
import { ReportService } from '../src/modules/march/report.service';

export interface MarchWorld {
  repo: CastleRepository;
  clock: FakeClock;
  /** Создаёт игрока с замком; возвращает его id. Ник = name. */
  addPlayer(name: string): Promise<string>;
}

let seq = 0;
const key = () => `march-${Date.now()}-${seq++}-abcdef`;
const RICH = { gold: 3000, wood: 3000, stone: 3000, food: 3000 };

async function fail(p: Promise<unknown>) {
  const err = await p.then(
    () => undefined,
    (e: unknown) => e,
  );
  expect(err).toBeInstanceOf(AppError);
  const e = err as AppError;
  return {
    code: e.code,
    status: e.statusCode,
    details: (e.details ?? {}) as Record<string, unknown>,
  };
}

/** Сценарии карты, походов, боёв и отчётов. Гоняются на in-memory и на PostgreSQL (D-24). */
export function marchSuite(name: string, makeWorld: () => Promise<MarchWorld>): void {
  const setup = async () => {
    const w = await makeWorld();
    const resolver = new MarchResolver({ repo: w.repo, clock: w.clock });
    const castle = new CastleService({
      repo: w.repo,
      clock: w.clock,
      before: async (u) => void (await resolver.resolveFor(u)),
    });
    const shared = { repo: w.repo, clock: w.clock };
    const patch = async (userId: string, fn: (a: CastleAggregate) => void) => {
      await w.repo.transaction(async (tx) => {
        const prev = await tx.load(userId, 'main');
        const next = structuredClone(prev!);
        fn(next);
        next.resourcesUpdatedAt = w.clock.now();
        await tx.save(prev!, next);
      });
    };
    const stored = (userId: string) =>
      w.repo.transaction(async (tx) => (await tx.load(userId, 'main'))!);
    /** Игрок с известным местом, без щита новичка и с богатыми запасами. */
    const player = async (nick: string, x: number, y: number) => {
      const id = await w.addPlayer(nick);
      await castle.view(id); // материализация героя
      await patch(id, (a) => {
        a.x = x;
        a.y = y;
        a.shieldUntil = null;
        a.resources = { ...RICH };
      });
      return id;
    };
    return {
      w,
      resolver,
      castle,
      patch,
      stored,
      player,
      march: new MarchService({ runner: castle.runner, ...shared }),
      map: new MapService(shared),
      reports: new ReportService(shared),
      army: new ArmyService(castle.runner),
    };
  };

  /** Ищет на карте клетку нужного вида (детерминированно) — seed теста фиксирован. */
  const findCell = (
    world: { worldSeed: number; worldMapVersion: MapVersion },
    pred: (c: MapCell) => boolean,
  ): MapCell => {
    for (let y = 0; y < MAP_SIZE; y++)
      for (let x = 0; x < MAP_SIZE; x++) {
        const c = cellAtV(world.worldMapVersion, world.worldSeed, x, y);
        if (pred(c)) return c;
      }
    throw new Error('no such cell');
  };

  describe(`карта и размещение: ${name}`, () => {
    it('замки получают места по спирали от центра на расстоянии не меньше зазора; место не меняется', async () => {
      const t = await setup();
      const a = await t.w.addPlayer('Alpha');
      const b = await t.w.addPlayer('Beta');
      const ca = await t.castle.view(a);
      const cb = await t.castle.view(b);
      expect(ca.position).toEqual({ x: MAP_SIZE / 2, y: MAP_SIZE / 2 });
      expect(cb.position).not.toBeNull();
      expect(
        Math.max(
          Math.abs(ca.position!.x - cb.position!.x),
          Math.abs(ca.position!.y - cb.position!.y),
        ),
      ).toBeGreaterThanOrEqual(MIN_CASTLE_GAP);
      t.w.clock.advance(3600);
      expect((await t.castle.view(a)).position).toEqual(ca.position);
    });

    it('тайлы показывают замки, «это я», щит, лагеря и точки; границы прижимаются к карте', async () => {
      const t = await setup();
      const a = await t.player('Alpha', 50, 50);
      const b = await t.player('Beta', 52, 50);
      await t.patch(b, (x) => (x.shieldUntil = new Date(t.w.clock.now().getTime() + 3600_000)));
      const tiles = await t.map.tiles(a, 40, 40, 20);
      expect(tiles.cells).toHaveLength(400);
      const at = (x: number, y: number) => tiles.cells[(y - tiles.y) * tiles.size + (x - tiles.x)]!;
      expect(at(50, 50).castle).toEqual({ nickname: 'Alpha', isMe: true, shielded: false });
      expect(at(52, 50).castle).toEqual({ nickname: 'Beta', isMe: false, shielded: true });
      expect(at(51, 50).castle).toBeNull();

      const edge = await t.map.tiles(a, MAP_SIZE - 1, MAP_SIZE - 1, 20);
      expect([edge.x, edge.y]).toEqual([MAP_SIZE - 20, MAP_SIZE - 20]);
      const one = await t.map.cell(a, 50, 50);
      expect(one.castle?.nickname).toBe('Alpha');
      expect(await fail(t.map.cell(a, MAP_SIZE, 3))).toMatchObject({ status: 404 });
    });

    it('поиск: по нику (без учёта регистра), по координатам, мусор и короткие запросы', async () => {
      const t = await setup();
      await t.player('Alpha', 50, 50);
      await t.player('Alfred', 53, 50);
      const a = await t.player('Beta', 56, 50);
      expect((await t.map.search('al')).map((r) => r.nickname).sort()).toEqual(['Alfred', 'Alpha']);
      expect(await t.map.search('53,50')).toEqual([{ x: 53, y: 50, nickname: 'Alfred' }]);
      expect(await t.map.search('10 10')).toEqual([{ x: 10, y: 10, nickname: null }]);
      expect(await t.map.search('500,5')).toEqual([]);
      expect(await t.map.search('a')).toEqual([]);
      expect(await t.map.search('zzzz')).toEqual([]);
      void a;
    });

    it('лагерь и ресурсная точка на карте показывают уровень, запас и возрождение', async () => {
      const t = await setup();
      const a = await t.player('Alpha', 50, 50);
      const seed = await t.stored(a);
      const node = findCell(seed, (c) => c.kind === 'resource');
      const view = await t.map.cell(a, node.x, node.y);
      expect(view).toMatchObject({ kind: 'resource', level: node.level, resource: node.resource });
      expect(view.remaining).toBe(nodeCapacity(node.level));
      const camp = findCell(seed, (c) => c.kind === 'camp');
      expect((await t.map.cell(a, camp.x, camp.y)).busyUntil).toBeNull();
    });
  });

  describe(`отправка походов: ${name}`, () => {
    it('отряд уходит из строя, время в пути по формуле, повтор с тем же ключом не дублирует поход', async () => {
      const t = await setup();
      const a = await t.player('Alpha', 50, 50);
      await t.player('Beta', 53, 50);
      await t.patch(a, (x) => (x.army = { infantry_1: { count: 100, wounded: 0 } }));
      const k = key();
      const input = {
        type: 'attack' as MarchType,
        target: { x: 53, y: 50 },
        units: { infantry_1: 40 },
      };
      const res = await t.march.send(a, input, k);
      const m = res.body.marches[0]!;
      const seconds = travelSeconds({ x: 50, y: 50 }, { x: 53, y: 50 }, { infantry_1: 40 });
      expect(Date.parse(m.arriveAt) - Date.parse(m.startedAt)).toBe(seconds * 1000);
      expect(Date.parse(m.returnAt) - Date.parse(m.arriveAt)).toBe(seconds * 1000);
      expect(m.targetName).toBe('Beta');
      expect(res.body.army.count).toBe(60);
      expect(res.body.army.marching).toBe(40);

      const again = await t.march.send(a, input, k);
      expect(again.replayed).toBe(true);
      expect((await t.stored(a)).marches).toHaveLength(1);
      expect(await fail(t.march.send(a, { ...input, units: { infantry_1: 41 } }, k))).toMatchObject(
        { code: 'ERR_IDEMPOTENCY_MISMATCH' },
      );
    });

    it('отказы: нехватка войск, своя клетка, пустая цель, разведка не кавалерией, чужие ключи юнитов', async () => {
      const t = await setup();
      const a = await t.player('Alpha', 50, 50);
      await t.player('Beta', 53, 50);
      await t.patch(
        a,
        (x) =>
          (x.army = { infantry_1: { count: 10, wounded: 0 }, cavalry_1: { count: 5, wounded: 0 } }),
      );
      const send = (type: MarchType, x: number, y: number, units: Record<string, number>) =>
        t.march.send(a, { type, target: { x, y }, units }, key());
      expect(await fail(send('attack', 53, 50, { infantry_1: 11 }))).toMatchObject({
        details: { reason: 'not_enough_units' },
      });
      expect(await fail(send('attack', 50, 50, { infantry_1: 1 }))).toMatchObject({
        details: { reason: 'own_castle' },
      });
      expect(await fail(send('attack', 60, 60, { infantry_1: 1 }))).toMatchObject({
        details: { reason: 'no_target' },
      });
      expect(await fail(send('scout', 53, 50, { infantry_1: 1 }))).toMatchObject({
        details: { reason: 'scout_needs_cavalry' },
      });
      expect(await fail(send('attack', 53, 50, { ghost_9: 1 }))).toMatchObject({
        code: 'ERR_VALIDATION',
      });
      expect(await fail(send('attack', 53, 50, {}))).toMatchObject({ code: 'ERR_VALIDATION' });
      expect(await fail(send('attack', 500, 50, { infantry_1: 1 }))).toMatchObject({
        code: 'ERR_VALIDATION',
      });
      expect(await fail(send('monster', 53, 50, { infantry_1: 1 }))).toMatchObject({
        details: { reason: 'no_target' },
      });
    });

    it('под щитом нападать нельзя; собственное нападение снимает щит нападающего', async () => {
      const t = await setup();
      const a = await t.player('Alpha', 50, 50);
      const b = await t.player('Beta', 53, 50);
      await t.patch(a, (x) => {
        x.army = { infantry_1: { count: 10, wounded: 0 } };
        x.shieldUntil = new Date(t.w.clock.now().getTime() + 3600_000);
      });
      await t.patch(b, (x) => (x.shieldUntil = new Date(t.w.clock.now().getTime() + 3600_000)));
      const input = {
        type: 'attack' as MarchType,
        target: { x: 53, y: 50 },
        units: { infantry_1: 5 },
      };
      expect(await fail(t.march.send(a, input, key()))).toMatchObject({
        code: 'ERR_SHIELD_ACTIVE',
        status: 422,
      });
      expect((await t.stored(a)).shieldUntil).not.toBeNull();

      await t.patch(b, (x) => (x.shieldUntil = null));
      await t.march.send(a, input, key());
      expect((await t.stored(a)).shieldUntil).toBeNull();
    });

    it('не больше пяти одновременных походов; армия с походами не превышает лимит', async () => {
      const t = await setup();
      const a = await t.player('Alpha', 50, 50);
      await t.player('Beta', 53, 50);
      await t.patch(a, (x) => {
        x.army = { infantry_1: { count: 50, wounded: 0 } };
        x.levels = { ...x.levels, barracks: 1 };
      });
      for (let i = 0; i < 5; i++)
        await t.march.send(
          a,
          { type: 'attack', target: { x: 53, y: 50 }, units: { infantry_1: 1 } },
          key(),
        );
      expect(
        await fail(
          t.march.send(
            a,
            { type: 'attack', target: { x: 53, y: 50 }, units: { infantry_1: 1 } },
            key(),
          ),
        ),
      ).toMatchObject({ code: 'ERR_QUEUE_FULL' });

      // лимит Казармы 1 — 250: в строю 45 + в походах 5 + в обучение можно ещё ≤ 200
      expect(await fail(t.army.train(a, 'infantry', 1, 201, key()))).toMatchObject({
        details: { reason: 'army_cap' },
      });
      await t.patch(
        a,
        (x) => (x.resources = { gold: 99_000, wood: 99_000, stone: 99_000, food: 99_000 }),
      );
      await expect(t.army.train(a, 'infantry', 1, 200, key())).resolves.toBeDefined();
    });
  });

  describe(`бой с игроком: ${name}`, () => {
    const scenario = async () => {
      const t = await setup();
      const a = await t.player('Alpha', 50, 50);
      const b = await t.player('Beta', 53, 50);
      await t.patch(a, (x) => {
        x.army = { infantry_3: { count: 300, wounded: 0 } };
        x.levels = { ...x.levels, hospital: 3 };
      });
      await t.patch(b, (x) => {
        x.army = { infantry_1: { count: 50, wounded: 0 } };
        x.resources = { gold: 2000, wood: 2000, stone: 2000, food: 2000 };
      });
      const sent = await t.march.send(
        a,
        { type: 'attack', target: { x: 53, y: 50 }, units: { infantry_3: 300 } },
        key(),
      );
      return { t, a, b, march: sent.body.marches[0]! };
    };

    it('до прибытия ничего не меняется; после — потери, добыча, отчёты у обеих сторон (по формулам боя)', async () => {
      const { t, a, b, march } = await scenario();
      expect((await t.castle.view(b)).army.count).toBe(50);
      expect((await t.reports.list(b, 1, 20)).total).toBe(0);

      const travel = Math.round((Date.parse(march.arriveAt) - Date.parse(march.startedAt)) / 1000);
      t.w.clock.advance(travel + 1);

      // Ожидаемый исход считаем теми же чистыми функциями
      const expected = simulateBattle({
        attacker: { units: { infantry_3: 300 }, attackBonus: NO_ATTACK_BONUS, defenseBonus: 0 },
        defender: { units: { infantry_1: 50 }, attackBonus: NO_ATTACK_BONUS, defenseBonus: 0 },
        seed: hashSeed(march.id),
      });
      expect(expected.winner).toBe('attacker');

      // Защитник ни разу не «заходил» — его замок разрешает поход при чтении
      const defView = await t.castle.view(b);
      expect(defView.army.count).toBe(0);
      // Добыча — по формуле плюндрования от запасов защитника на момент боя (он успел накопить чуть больше 2000)
      const attView = await t.castle.view(a);
      const loot = attView.marches[0]!.loot;
      const cap = warehouseCap(1);
      const bound = plunder(
        { gold: 2100, wood: 2100, stone: 2100, food: 2100 },
        { gold: cap, wood: cap, stone: cap, food: cap },
        cargoOf(expected.attacker.remaining),
      );
      expect(loot.gold).toBeGreaterThan(0);
      expect(loot.gold).toBeLessThanOrEqual(bound.gold);
      expect(attView.marches[0]).toMatchObject({ state: 'returning' });
      expect(attView.army.marching).toBeGreaterThan(0);
      // за три минуты у защитника накапало немного золота (300/ч)
      expect(defView.resources.gold).toBeGreaterThan(2000 - loot.gold);
      expect(defView.resources.gold).toBeLessThan(2000 - loot.gold + 30);

      const ra = await t.reports.list(a, 1, 20);
      const rb = await t.reports.list(b, 1, 20);
      expect(ra).toMatchObject({ total: 1, unread: 1 });
      expect(ra.items[0]).toMatchObject({
        kind: 'battle',
        role: 'attacker',
        outcome: 'win',
        opponent: 'Beta',
      });
      expect(rb.items[0]).toMatchObject({
        kind: 'battle',
        role: 'defender',
        outcome: 'loss',
        opponent: 'Alpha',
      });
      const detail = await t.reports.get(a, ra.items[0]!.id);
      expect(detail.detail.loot).toEqual(loot);
      expect(detail.detail.attacker?.remaining).toEqual(expected.attacker.remaining);
      expect(detail.detail.rounds).toEqual(expected.rounds);
      expect((await t.reports.list(a, 1, 20)).unread).toBe(0);
    });

    it('возвращение: живые в строй, раненые в госпиталь, добыча на склад, опыт герою — ровно один раз', async () => {
      const { t, a, march } = await scenario();
      const travel = Math.round((Date.parse(march.arriveAt) - Date.parse(march.startedAt)) / 1000);
      t.w.clock.advance(travel + 1);
      const mid = await t.castle.view(a);
      const back = mid.marches[0]!;
      const goldBefore = mid.resources.gold;
      t.w.clock.advance(travel + 5);
      const home = await t.castle.view(a);

      const expected = simulateBattle({
        attacker: { units: { infantry_3: 300 }, attackBonus: NO_ATTACK_BONUS, defenseBonus: 0 },
        defender: { units: { infantry_1: 50 }, attackBonus: NO_ATTACK_BONUS, defenseBonus: 0 },
        seed: hashSeed(march.id),
      });
      const split = splitCasualties(expected.attacker.fallen, hospitalCapacity(3));
      expect(home.marches).toHaveLength(0);
      expect(home.army.count).toBe(totalUnits(expected.attacker.remaining));
      expect(home.army.units.reduce((s, u) => s + u.wounded, 0)).toBe(totalUnits(split.wounded));
      expect(home.resources.gold).toBeGreaterThan(goldBefore + back.loot.gold - 1);
      expect(home.hero.xp + (home.hero.level - 1) * 1000).toBeGreaterThan(0);

      // Повторное чтение ничего не начисляет второй раз
      const again = await t.castle.view(a);
      expect(again.army.count).toBe(home.army.count);
      expect((await t.stored(a)).hero?.xp).toBe(home.hero.xp);
    });

    it('слабый нападающий проигрывает: добычи нет, у защитника потери, отчёт «поражение»', async () => {
      const t = await setup();
      const a = await t.player('Alpha', 50, 50);
      const b = await t.player('Beta', 53, 50);
      await t.patch(a, (x) => (x.army = { infantry_1: { count: 10, wounded: 0 } }));
      await t.patch(b, (x) => (x.army = { infantry_3: { count: 200, wounded: 0 } }));
      const res = await t.march.send(
        a,
        { type: 'attack', target: { x: 53, y: 50 }, units: { infantry_1: 10 } },
        key(),
      );
      t.w.clock.advance(
        Math.round((Date.parse(res.body.marches[0]!.arriveAt) - t.w.clock.now().getTime()) / 1000) +
          1,
      );
      await t.resolver.resolveAll();
      const ra = await t.reports.list(a, 1, 20);
      expect(ra.items[0]).toMatchObject({ outcome: 'loss' });
      expect((await t.reports.list(b, 1, 20)).items[0]).toMatchObject({
        outcome: 'win',
        role: 'defender',
      });
      // Отряд полностью погиб: возвращаться некому, ни добычи, ни похода
      const att = await t.stored(a);
      expect(att.marches).toHaveLength(0);
      expect(Object.values(att.army).reduce((s, u) => s + (u?.count ?? 0), 0)).toBe(0);
      expect((await t.stored(b)).army['infantry_3']?.count).toBeGreaterThan(190);
    });

    it('таймерный разбор (resolveAll) обрабатывает поход, даже если никто не заходил; повтор ничего не меняет', async () => {
      const { t, a, b, march } = await scenario();
      t.w.clock.advance(
        Math.round((Date.parse(march.arriveAt) - Date.parse(march.startedAt)) / 1000) + 1,
      );
      expect(await t.resolver.resolveAll()).toBe(1);
      expect(await t.resolver.resolveAll()).toBe(0);
      expect((await t.stored(a)).marches[0]?.state).toBe('returning');
      expect((await t.reports.list(b, 1, 20)).total).toBe(1);
    });

    it('параллельный разбор одного похода даёт один бой и по одному отчёту', async () => {
      const { t, a, b, march } = await scenario();
      t.w.clock.advance(
        Math.round((Date.parse(march.arriveAt) - Date.parse(march.startedAt)) / 1000) + 1,
      );
      await Promise.all([
        t.resolver.resolveAll(),
        t.resolver.resolveAll(),
        t.resolver.resolveFor(b),
        t.castle.view(a),
      ]);
      expect((await t.reports.list(a, 1, 20)).total).toBe(1);
      expect((await t.reports.list(b, 1, 20)).total).toBe(1);
    });

    it('щит цели, поставленный до прибытия, отменяет бой: отряд возвращается целым', async () => {
      const { t, a, b, march } = await scenario();
      await t.patch(
        b,
        (x) => (x.shieldUntil = new Date(t.w.clock.now().getTime() + 24 * 3600_000)),
      );
      t.w.clock.advance(
        Math.round((Date.parse(march.arriveAt) - Date.parse(march.startedAt)) / 1000) + 1,
      );
      await t.resolver.resolveAll();
      expect((await t.reports.list(b, 1, 20)).total).toBe(0);
      const home = (await t.stored(a)).marches[0]!;
      expect(home.state).toBe('returning');
      expect(home.units).toEqual({ infantry_3: 300 });
    });

    it('отчёт чужого игрока недоступен', async () => {
      const { t, a, b } = await scenario();
      t.w.clock.advance(3600);
      await t.resolver.resolveAll();
      const id = (await t.reports.list(a, 1, 20)).items[0]!.id;
      expect(await fail(t.reports.get(b, id))).toMatchObject({ status: 404 });
    });

    it('отчёты листаются страницами, новые сверху', async () => {
      const t = await setup();
      const a = await t.player('Alpha', 50, 50);
      await t.player('Beta', 53, 50);
      await t.patch(a, (x) => (x.army = { cavalry_1: { count: 30, wounded: 0 } }));
      for (let i = 0; i < 3; i++) {
        await t.march.send(
          a,
          { type: 'scout', target: { x: 53, y: 50 }, units: { cavalry_1: 1 } },
          key(),
        );
        t.w.clock.advance(400);
        await t.resolver.resolveAll();
        t.w.clock.advance(400);
      }
      const p1 = await t.reports.list(a, 1, 2);
      const p2 = await t.reports.list(a, 2, 2);
      expect([p1.items.length, p2.items.length, p1.total]).toEqual([2, 1, 3]);
      expect(p1.items[0]!.createdAt > p2.items[0]!.createdAt).toBe(true);
    });
  });

  describe(`разведка, лагеря, ресурсы: ${name}`, () => {
    it('разведка показывает состав защиты с погрешностью ±10% и ресурсы; потерь нет, защитник не уведомляется', async () => {
      const t = await setup();
      const a = await t.player('Alpha', 50, 50);
      const b = await t.player('Beta', 53, 50);
      await t.patch(a, (x) => (x.army = { cavalry_1: { count: 5, wounded: 0 } }));
      await t.patch(b, (x) => (x.army = { infantry_1: { count: 200, wounded: 0 } }));
      const res = await t.march.send(
        a,
        { type: 'scout', target: { x: 53, y: 50 }, units: { cavalry_1: 5 } },
        key(),
      );
      const m = res.body.marches[0]!;
      t.w.clock.advance(
        Math.round((Date.parse(m.arriveAt) - t.w.clock.now().getTime()) / 1000) + 1,
      );
      await t.resolver.resolveAll();
      const item = (await t.reports.list(a, 1, 20)).items[0]!;
      expect(item).toMatchObject({ kind: 'scout', outcome: 'done' });
      const detail = (await t.reports.get(a, item.id)).detail;
      expect(detail.scout?.units).toEqual(fuzzUnits({ infantry_1: 200 }, hashSeed(m.id)));
      expect(detail.scout!.units.infantry_1).toBeGreaterThanOrEqual(180);
      expect(detail.scout!.units.infantry_1).toBeLessThanOrEqual(220);
      expect(detail.scout?.resources.gold).toBe(3000);
      expect((await t.reports.list(b, 1, 20)).total).toBe(0);
      expect((await t.stored(a)).marches[0]?.units).toEqual({ cavalry_1: 5 });
    });

    it('лагерь: победа даёт награду и опыт, лагерь возрождается через 30 минут', async () => {
      const t = await setup();
      const a = await t.player('Alpha', 50, 50);
      const seed = await t.stored(a);
      const camp = findCell(seed, (c) => c.kind === 'camp' && c.level <= 2);
      await t.patch(a, (x) => (x.army = { infantry_5: { count: 400, wounded: 0 } }));
      const go = () =>
        t.march.send(
          a,
          { type: 'monster', target: { x: camp.x, y: camp.y }, units: { infantry_5: 100 } },
          key(),
        );
      const res = await go();
      const m = res.body.marches[0]!;
      t.w.clock.advance(
        Math.round((Date.parse(m.arriveAt) - t.w.clock.now().getTime()) / 1000) + 1,
      );
      await t.resolver.resolveAll();
      const report = (await t.reports.list(a, 1, 20)).items[0]!;
      expect(report).toMatchObject({ kind: 'monster', outcome: 'win' });
      const stored = (await t.stored(a)).marches[0]!;
      expect(stored.loot.gold).toBeGreaterThan(0);
      expect(stored.heroXp).toBeGreaterThan(0);
      expect((await t.reports.get(a, report.id)).detail.campLevel).toBe(camp.level);

      const cell = await t.map.cell(a, camp.x, camp.y);
      expect(cell.busyUntil).not.toBeNull();
      expect(await fail(go())).toMatchObject({ details: { reason: 'camp_respawning' } });
      t.w.clock.advance(31 * 60);
      expect((await t.map.cell(a, camp.x, camp.y)).busyUntil).toBeNull();
      await expect(go()).resolves.toBeDefined();
    });

    it('сбор: добыча — груз отряда, но не больше остатка; возвращение позже на время сбора; запас убывает', async () => {
      const t = await setup();
      const a = await t.player('Alpha', 50, 50);
      const seed = await t.stored(a);
      const node = findCell(seed, (c) => c.kind === 'resource' && c.level === 1);
      await t.patch(a, (x) => (x.army = { cavalry_1: { count: 100, wounded: 0 } }));
      const units = { cavalry_1: 100 };
      const res = await t.march.send(
        a,
        { type: 'gather', target: { x: node.x, y: node.y }, units },
        key(),
      );
      const m = res.body.marches[0]!;
      t.w.clock.advance(
        Math.round((Date.parse(m.arriveAt) - t.w.clock.now().getTime()) / 1000) + 1,
      );
      await t.resolver.resolveAll();

      const amount = gatherAmount(units, nodeCapacity(1));
      expect(amount).toBe(4000);
      const stored = (await t.stored(a)).marches[0]!;
      expect(stored.loot[node.resource!]).toBe(amount);
      const extra = gatherSeconds(amount) * 1000;
      expect(stored.returnAt.getTime()).toBe(Date.parse(m.returnAt) + extra);
      expect((await t.map.cell(a, node.x, node.y)).remaining).toBe(nodeCapacity(1) - amount);

      // Возвращение: ресурс на складе
      const before = (await t.castle.view(a)).resources[node.resource!];
      t.w.clock.set(new Date(stored.returnAt.getTime() + 1000));
      const home = await t.castle.view(a);
      expect(home.marches).toHaveLength(0);
      expect(home.resources[node.resource!]).toBeGreaterThan(before + amount - 1);
      expect(home.army.units.find((u) => u.id === 'cavalry_1')?.count).toBe(100);

      // Через час точка наполняется заново
      t.w.clock.advance(3600);
      expect((await t.map.cell(a, node.x, node.y)).remaining).toBe(nodeCapacity(1));
    });
  });

  describe(`лечение: ${name}`, () => {
    it('раненые лечатся платно и мгновенно; без раненых или денег — отказ', async () => {
      const t = await setup();
      const a = await t.player('Alpha', 50, 50);
      await t.patch(a, (x) => {
        x.army = { infantry_1: { count: 10, wounded: 20 } };
        x.resources = { gold: 10_000, wood: 10_000, stone: 10_000, food: 10_000 };
      });
      const cost = healCost('infantry', 1, 8);
      const res = await t.army.heal(a, 'infantry_1', 8, key());
      expect(res.body.army.units).toEqual([{ id: 'infantry_1', count: 18, wounded: 12 }]);
      expect(res.body.resources.gold).toBeCloseTo(10_000 - cost.gold, 0);
      expect(await fail(t.army.heal(a, 'infantry_1', 13, key()))).toMatchObject({
        details: { reason: 'not_enough_wounded' },
      });
      await t.patch(a, (x) => (x.resources = { gold: 0, wood: 0, stone: 0, food: 0 }));
      expect(await fail(t.army.heal(a, 'infantry_1', 1, key()))).toMatchObject({
        code: 'ERR_INSUFFICIENT_RESOURCES',
      });
    });
  });
}
