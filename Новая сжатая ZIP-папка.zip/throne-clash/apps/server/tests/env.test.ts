import { describe, expect, it } from 'vitest';
import { loadConfig, SECRET_PLACEHOLDER } from '../src/config/env';

describe('loadConfig', () => {
  it('умолчания для разработки', () => {
    const c = loadConfig({});
    expect(c).toMatchObject({
      env: 'development',
      port: 3000,
      isProduction: false,
      cookieSecure: false,
      swaggerEnabled: true,
    });
    expect(c.godMode.enabled).toBe(true); // D-13: включён только в development
  });

  it('в production режим бога и Swagger выключены, cookie Secure', () => {
    const c = loadConfig({ NODE_ENV: 'production', JWT_ACCESS_SECRET: 'a'.repeat(40) });
    expect(c).toMatchObject({
      isProduction: true,
      cookieSecure: true,
      swaggerEnabled: false,
      trustProxy: true,
    });
    expect(c.godMode.enabled).toBe(false);
  });

  it('в production нельзя стартовать с плейсхолдером или коротким секретом', () => {
    expect(() => loadConfig({ NODE_ENV: 'production' })).toThrow(/JWT_ACCESS_SECRET/);
    expect(() =>
      loadConfig({ NODE_ENV: 'production', JWT_ACCESS_SECRET: SECRET_PLACEHOLDER }),
    ).toThrow(/JWT_ACCESS_SECRET/);
    expect(() => loadConfig({ NODE_ENV: 'production', JWT_ACCESS_SECRET: 'short' })).toThrow(
      /JWT_ACCESS_SECRET/,
    );
  });

  it('режим бога в production без хеша пароля не стартует', () => {
    const base = { NODE_ENV: 'production', JWT_ACCESS_SECRET: 'a'.repeat(40) };
    expect(() => loadConfig({ ...base, GOD_MODE_ENABLED: 'true' })).toThrow(
      /GOD_MODE_PASSWORD_HASH/,
    );
    expect(
      loadConfig({ ...base, GOD_MODE_ENABLED: 'true', GOD_MODE_PASSWORD_HASH: '$argon2id$x' })
        .godMode.enabled,
    ).toBe(true);
  });

  it('ошибки перечисляются все сразу; порт проверяется', () => {
    expect(() => loadConfig({ PORT: '99999', NODE_ENV: 'staging' })).toThrow(
      /PORT[\s\S]*NODE_ENV|NODE_ENV[\s\S]*PORT/,
    );
  });

  it('CORS_ORIGIN — список через запятую; OWNER_EMAIL нормализуется', () => {
    const c = loadConfig({
      CORS_ORIGIN: 'http://a.test, http://b.test ,',
      OWNER_EMAIL: '  Owner@Example.COM ',
    });
    expect(c.corsOrigins).toEqual(['http://a.test', 'http://b.test']);
    expect(c.ownerEmail).toBe('owner@example.com');
  });

  it('в тестовом окружении логи выключены', () => {
    expect(loadConfig({ NODE_ENV: 'test' }).logLevel).toBe('silent');
  });
});
