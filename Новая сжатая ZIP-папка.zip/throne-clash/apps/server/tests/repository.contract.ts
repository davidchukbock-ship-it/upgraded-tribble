import { describe, expect, it } from 'vitest';
import { nicknameKey } from '@tc/shared';
import { UniqueViolation, type NewCastle, type NewUser } from '../src/modules/auth/auth.types';
import type { Repositories } from '../src/repositories';

const T0 = new Date('2026-01-01T00:00:00.000Z');
const at = (sec: number) => new Date(T0.getTime() + sec * 1000);

export const castleFor = (): NewCastle => ({
  worldId: 'main',
  resources: { gold: 1000, wood: 1000, stone: 1000, food: 1000 },
  gems: 50,
  buildings: ['castle', 'farm'],
  resourcesUpdatedAt: T0,
  shieldUntil: at(72 * 3600),
});

export const userFor = (nickname: string, email: string | null = null): NewUser => ({
  email,
  passwordHash: email ? 'hash' : null,
  nickname,
  nicknameKey: nicknameKey(nickname),
  language: 'ru',
  crest: 'lion',
  createdAt: T0,
});

/**
 * Контракт репозиториев. Один набор проверок для in-memory и Prisma-реализаций:
 * юнит-тесты на памяти остаются честными, пока обе ведут себя одинаково.
 */
export function repositoryContract(name: string, make: () => Promise<Repositories>): void {
  describe(`контракт репозиториев: ${name}`, () => {
    it('создаёт пользователя и находит по id и email', async () => {
      const { users } = await make();
      const u = await users.createWithCastle(userFor('Артур', 'a@example.com'), castleFor());
      expect(u).toMatchObject({
        nickname: 'Артур',
        role: 'PLAYER',
        isGuest: false,
        failedLogins: 0,
      });
      expect((await users.findById(u.id))?.email).toBe('a@example.com');
      expect((await users.findByEmail('a@example.com'))?.id).toBe(u.id);
      expect(await users.findByEmail('nobody@example.com')).toBeNull();
      expect(await users.findById('00000000-0000-4000-8000-000000000000')).toBeNull();
    });

    it('уникальность email и ника (по ключу) — UniqueViolation с полем', async () => {
      const { users } = await make();
      await users.createWithCastle(userFor('Кая', 'k@example.com'), castleFor());
      await expect(
        users.createWithCastle(userFor('Другой', 'k@example.com'), castleFor()),
      ).rejects.toMatchObject({ field: 'email' });
      await expect(
        users.createWithCastle(userFor('кАЯ', 'z@example.com'), castleFor()),
      ).rejects.toBeInstanceOf(UniqueViolation);
      await expect(
        users.createWithCastle(userFor('кАЯ', 'z@example.com'), castleFor()),
      ).rejects.toMatchObject({ field: 'nickname' });
    });

    it('несколько гостей без email не конфликтуют', async () => {
      const { users } = await make();
      await users.createWithCastle({ ...userFor('Гость-AAAAA'), isGuest: true }, castleFor());
      await expect(
        users.createWithCastle({ ...userFor('Гость-BBBBB'), isGuest: true }, castleFor()),
      ).resolves.toBeDefined();
    });

    it('update меняет только переданные поля и защищён уникальностью', async () => {
      const { users } = await make();
      const a = await users.createWithCastle(userFor('Первый', 'a@example.com'), castleFor());
      await users.createWithCastle(userFor('Второй', 'b@example.com'), castleFor());
      const u = await users.update(a.id, { crest: 'wolf', language: 'en' });
      expect(u).toMatchObject({ crest: 'wolf', language: 'en', nickname: 'Первый' });
      await expect(
        users.update(a.id, { nickname: 'второй', nicknameKey: nicknameKey('второй') }),
      ).rejects.toMatchObject({ field: 'nickname' });
      await expect(users.update(a.id, { email: 'b@example.com' })).rejects.toMatchObject({
        field: 'email',
      });
      expect((await users.findById(a.id))?.nickname).toBe('Первый'); // неудачный update ничего не менял
    });

    it('счётчик неудач: блокировка на пороге, сброс при успехе', async () => {
      const { users } = await make();
      const u = await users.createWithCastle(userFor('Игрок', 'p@example.com'), castleFor());
      const limit = { maxFailures: 3, lockMs: 60_000 };
      expect(await users.recordLoginFailure(u.id, T0, limit)).toMatchObject({ lockedUntil: null });
      expect(await users.recordLoginFailure(u.id, T0, limit)).toMatchObject({ lockedUntil: null });
      const third = await users.recordLoginFailure(u.id, T0, limit);
      expect(third.lockedUntil?.getTime()).toBe(T0.getTime() + 60_000);
      const after = await users.findById(u.id);
      expect(after?.lockedUntil?.getTime()).toBe(T0.getTime() + 60_000);
      expect(after?.failedLogins).toBe(0);

      await users.recordLoginSuccess(u.id, at(120));
      expect(await users.findById(u.id)).toMatchObject({ lockedUntil: null, lastLoginAt: at(120) });
    });

    it('параллельные неудачи не теряются: ровно одна блокировка на порогах', async () => {
      const { users } = await make();
      const u = await users.createWithCastle(userFor('Гонка', 'r@example.com'), castleFor());
      const results = await Promise.all(
        Array.from({ length: 5 }, () =>
          users.recordLoginFailure(u.id, T0, { maxFailures: 5, lockMs: 1000 }),
        ),
      );
      expect(results.filter((r) => r.lockedUntil !== null)).toHaveLength(1);
    });

    it('setRole и countByRole', async () => {
      const { users } = await make();
      const u = await users.createWithCastle(userFor('Власть', 'o@example.com'), castleFor());
      expect(await users.countByRole('OWNER')).toBe(0);
      await users.setRole(u.id, 'OWNER');
      expect(await users.countByRole('OWNER')).toBe(1);
      expect((await users.findById(u.id))?.role).toBe('OWNER');
    });

    it('сессии: поиск по хешу, одноразовый отзыв, семейство, все устройства, очистка', async () => {
      const { users, sessions } = await make();
      const u = await users.createWithCastle(userFor('Сессии', 's@example.com'), castleFor());
      const mk = (hash: string, family: string, exp = 3600) =>
        sessions.create({
          userId: u.id,
          family,
          tokenHash: hash,
          expiresAt: at(exp),
          createdAt: T0,
        });

      const s1 = await mk('h1', 'f1');
      await mk('h2', 'f1');
      await mk('h3', 'f2');
      expect((await sessions.findByHash('h1'))?.id).toBe(s1.id);
      expect(await sessions.findByHash('nope')).toBeNull();

      // гонка двух refresh: успешно отзывает ровно один
      const race = await Promise.all([
        sessions.revokeIfActive(s1.id, at(1)),
        sessions.revokeIfActive(s1.id, at(1)),
      ]);
      expect(race.filter(Boolean)).toHaveLength(1);
      expect((await sessions.findByHash('h1'))?.revokedAt).toEqual(at(1));

      await sessions.revokeFamily('f1', at(2));
      expect((await sessions.findByHash('h2'))?.revokedAt).toEqual(at(2));
      expect((await sessions.findByHash('h1'))?.revokedAt).toEqual(at(1)); // прежняя отметка не затирается
      expect((await sessions.findByHash('h3'))?.revokedAt).toBeNull();

      await sessions.revokeAllForUser(u.id, at(3));
      expect((await sessions.findByHash('h3'))?.revokedAt).toEqual(at(3));

      await mk('old', 'f3', 10);
      expect(await sessions.deleteExpired(at(100))).toBe(1);
      expect(await sessions.findByHash('old')).toBeNull();
      expect(await sessions.findByHash('h2')).not.toBeNull();
    });

    it('журнал безопасности: запись и фильтры', async () => {
      const { users, security } = await make();
      const u = await users.createWithCastle(userFor('Журнал', 'j@example.com'), castleFor());
      await security.add({
        userId: u.id,
        kind: 'login_locked',
        ip: '203.0.113.1',
        details: { n: 1 },
        createdAt: T0,
      });
      await security.add({ userId: null, kind: 'other', createdAt: at(1) });
      expect(await security.list({ kind: 'login_locked' })).toEqual([
        expect.objectContaining({
          userId: u.id,
          kind: 'login_locked',
          ip: '203.0.113.1',
          details: { n: 1 },
        }),
      ]);
      expect(await security.list({ userId: u.id })).toHaveLength(1);
      expect(await security.list({})).toHaveLength(2);
    });

    it('журнал безопасности: страницы, счётчик по IP и игроку за период', async () => {
      const { users, security } = await make();
      const u = await users.createWithCastle(userFor('Счёт', 's@example.com'), castleFor());
      for (let i = 0; i < 5; i++)
        await security.add({
          userId: u.id,
          kind: 'god_login_failed',
          ip: '198.51.100.7',
          createdAt: at(i),
        });
      await security.add({
        userId: u.id,
        kind: 'god_login_failed',
        ip: '198.51.100.8',
        createdAt: at(6),
      });
      await security.add({ userId: null, kind: 'other', createdAt: at(7) });

      const p1 = await security.page({ kind: 'god_login_failed' }, 1, 4);
      expect(p1.total).toBe(6);
      expect(p1.items).toHaveLength(4);
      expect(p1.items[0]!.createdAt.getTime()).toBeGreaterThan(p1.items[1]!.createdAt.getTime());
      expect((await security.page({ kind: 'god_login_failed' }, 2, 4)).items).toHaveLength(2);

      const count = (extra: object, since = T0) =>
        security.count({ kind: 'god_login_failed', since, ...extra });
      expect(await count({})).toBe(6);
      expect(await count({ ip: '198.51.100.7', userId: u.id })).toBe(5);
      expect(await count({ ip: '198.51.100.8' })).toBe(1);
      expect(await count({}, at(3))).toBe(3); // старые попытки за окном не считаются
    });

    it('поиск игроков и сводка для админки', async () => {
      const { users, sessions } = await make();
      const a = await users.createWithCastle(userFor('Артур', 'a@example.com'), castleFor());
      const b = await users.createWithCastle(
        { ...userFor('Борис', 'b@example.com'), createdAt: at(60) },
        castleFor(),
      );
      await users.createWithCastle(
        { ...userFor('Гость-1'), isGuest: true, createdAt: at(120) },
        castleFor(),
      );
      await users.createWithCastle(
        { ...userFor('Бот-1'), isBot: true, createdAt: at(180) },
        castleFor(),
      );
      await users.update(b.id, {
        bannedUntil: at(1_000_000),
        banReason: 'x',
        mutedUntil: at(1_000_000),
      });

      // нику ищем по ключу (регистр, кириллица), почте — по вхождению, id — точно
      expect(
        (await users.list({ query: 'артур', page: 1, pageSize: 10 })).items.map((u) => u.id),
      ).toEqual([a.id]);
      expect(
        (await users.list({ query: 'b@exam', page: 1, pageSize: 10 })).items.map((u) => u.id),
      ).toEqual([b.id]);
      expect((await users.list({ query: a.id, page: 1, pageSize: 10 })).total).toBe(1);
      expect((await users.list({ query: 'нет такого', page: 1, pageSize: 10 })).total).toBe(0);
      const all = await users.list({ page: 1, pageSize: 3 });
      expect(all.total).toBe(4);
      expect(all.items.map((u) => u.nickname)).toEqual(['Бот-1', 'Гость-1', 'Борис']); // новые сверху
      expect((await users.list({ page: 2, pageSize: 3 })).items).toHaveLength(1);
      await users.setRole(a.id, 'ADMIN');
      expect((await users.list({ role: 'ADMIN', page: 1, pageSize: 10 })).total).toBe(1);

      const stats = await users.stats(at(200));
      expect(stats).toEqual({
        total: 4,
        guests: 1,
        bots: 1,
        banned: 1,
        muted: 1,
        new24h: 4,
        new7d: 4,
      });
      expect((await users.stats(at(9 * 86_400))).new7d).toBe(0);

      await sessions.create({
        userId: a.id,
        family: 'f1',
        tokenHash: 'x1',
        expiresAt: at(9_000),
        createdAt: at(10),
      });
      await sessions.create({
        userId: a.id,
        family: 'f1',
        tokenHash: 'x2',
        expiresAt: at(9_000),
        createdAt: at(20),
      });
      await sessions.create({
        userId: b.id,
        family: 'f2',
        tokenHash: 'x3',
        expiresAt: at(9_000),
        createdAt: at(30),
      });
      expect(await sessions.countActiveUsers(at(0))).toBe(2);
      expect(await sessions.countActiveUsers(at(25))).toBe(1);
    });

    it('хранилище администрирования: аудит, сессии режима бога, снимки, ревизии баланса', async () => {
      const { castles } = await make();
      const rec = (i: number, over: object = {}) => ({
        id: `00000000-0000-4000-8000-0000000000${String(i).padStart(2, '0')}`,
        scope: 'god' as const,
        actorId: 'actor-1',
        action: `act:${i}`,
        targetUserId: i % 2 ? 'target-1' : 'target-2',
        params: { i },
        before: { gold: i },
        after: { gold: i + 1 },
        ip: '127.0.0.1',
        createdAt: at(i),
        ...over,
      });
      await castles.transaction(async (tx) => {
        for (let i = 1; i <= 5; i++) await tx.admin.addAudit(rec(i));
        await tx.admin.addAudit(
          rec(6, {
            scope: 'admin',
            actorId: null,
            targetUserId: null,
            ip: null,
            before: null,
            after: null,
            params: null,
          }),
        );
      });
      await castles.transaction(async (tx) => {
        const god = await tx.admin.listAudit({ scope: 'god' }, 1, 3);
        expect(god.total).toBe(5);
        expect(god.items.map((r) => r.action)).toEqual(['act:5', 'act:4', 'act:3']);
        expect(god.items[0]).toMatchObject({
          params: { i: 5 },
          before: { gold: 5 },
          after: { gold: 6 },
          ip: '127.0.0.1',
        });
        expect((await tx.admin.listAudit({ scope: 'god' }, 2, 3)).items).toHaveLength(2);
        expect((await tx.admin.listAudit({ targetUserId: 'target-1' }, 1, 10)).total).toBe(3);
        expect((await tx.admin.listAudit({ scope: 'admin' }, 1, 10)).items[0]).toMatchObject({
          actorId: null,
          params: null,
        });
        expect((await tx.admin.listAudit({ actorId: 'actor-1' }, 1, 10)).total).toBe(5);
      });

      await castles.transaction(async (tx) => {
        const s = (id: string, userId: string, exp: number) => ({
          id,
          userId,
          tokenHash: `h-${id}`,
          ip: '1.1.1.1',
          createdAt: at(0),
          lastSeenAt: at(0),
          expiresAt: at(exp),
        });
        await tx.admin.createGodSession(s('00000000-0000-4000-8000-0000000000a1', 'u1', 100));
        await tx.admin.createGodSession(s('00000000-0000-4000-8000-0000000000a2', 'u2', 50));
        expect(
          (await tx.admin.findGodSession('h-00000000-0000-4000-8000-0000000000a1'))?.userId,
        ).toBe('u1');
        expect(await tx.admin.findGodSession('nope')).toBeNull();
        await tx.admin.slideGodSession('00000000-0000-4000-8000-0000000000a1', at(60), at(200));
        expect(
          (await tx.admin.findGodSession('h-00000000-0000-4000-8000-0000000000a1'))?.expiresAt,
        ).toEqual(at(200));
        expect(await tx.admin.deleteExpiredGodSessions(at(100))).toBe(1);
        await tx.admin.deleteGodSessionsOf('u1');
        expect(await tx.admin.findGodSession('h-00000000-0000-4000-8000-0000000000a1')).toBeNull();
      });

      await castles.transaction(async (tx) => {
        await tx.admin.saveSnapshot({
          id: '00000000-0000-4000-8000-0000000000b1',
          userId: 'u1',
          label: 'один',
          takenBy: 'o',
          data: { gems: 5, nested: { a: [1, 2] } },
          createdAt: at(1),
        });
        await tx.admin.saveSnapshot({
          id: '00000000-0000-4000-8000-0000000000b2',
          userId: 'u1',
          label: 'два',
          takenBy: 'o',
          data: { gems: 6 },
          createdAt: at(2),
        });
        expect((await tx.admin.listSnapshots('u1')).map((x) => x.label)).toEqual(['два', 'один']);
        expect((await tx.admin.getSnapshot('00000000-0000-4000-8000-0000000000b1'))?.data).toEqual({
          gems: 5,
          nested: { a: [1, 2] },
        });
        expect(await tx.admin.getSnapshot('00000000-0000-4000-8000-0000000000ff')).toBeNull();
        expect(await tx.admin.listSnapshots('u2')).toEqual([]);
      });

      await castles.transaction(async (tx) => {
        await tx.admin.addBalanceRevision({
          id: '00000000-0000-4000-8000-0000000000c1',
          config: { buildCost: 2 },
          actorId: 'o',
          note: null,
          createdAt: at(1),
        });
        await tx.admin.addBalanceRevision({
          id: '00000000-0000-4000-8000-0000000000c2',
          config: { buildCost: 3 },
          actorId: null,
          note: 'вручную',
          createdAt: at(2),
        });
        const revs = await tx.admin.listBalanceRevisions(10);
        expect(revs.map((r) => r.config)).toEqual([{ buildCost: 3 }, { buildCost: 2 }]);
        expect(revs[0]).toMatchObject({ note: 'вручную', actorId: null });
        expect(await tx.admin.listBalanceRevisions(1)).toHaveLength(1);
      });
    });

    it('хранилище администрирования: откат транзакции отменяет записи', async () => {
      const { castles } = await make();
      await expect(
        castles.transaction(async (tx) => {
          await tx.admin.addAudit({
            id: '00000000-0000-4000-8000-0000000000d1',
            scope: 'god',
            actorId: null,
            action: 'x',
            targetUserId: null,
            params: null,
            before: null,
            after: null,
            ip: null,
            createdAt: at(1),
          });
          throw new Error('boom');
        }),
      ).rejects.toThrow('boom');
      expect((await castles.transaction((tx) => tx.admin.listAudit({}, 1, 10))).total).toBe(0);
    });

    it('экономика за период без действий режима бога, счётчики, жалобы', async () => {
      const { users, castles } = await make();
      const u = await users.createWithCastle(userFor('Эконом', 'e@example.com'), castleFor());
      const ev = (
        resource: 'gold' | 'gems',
        amount: number,
        isGodAction: boolean,
        sec: number,
      ) => ({
        worldId: 'main',
        userId: u.id,
        kind: 'k',
        resource,
        amount,
        isGodAction,
        createdAt: at(sec),
      });
      await castles.transaction(async (tx) => {
        await tx.logEconomy([
          ev('gold', 100, false, 10),
          ev('gold', -30, false, 11),
          ev('gems', 5, false, 12),
          ev('gold', 1_000_000, true, 13), // режим бога не считается
          ev('gold', 999, false, 1), // раньше периода
        ]);
      });
      const flow = await castles.transaction((tx) => tx.admin.economyFlow('main', at(5)));
      expect(flow.gained).toEqual({ gold: 100, wood: 0, stone: 0, food: 0, gems: 5 });
      expect(flow.spent).toEqual({ gold: 30, wood: 0, stone: 0, food: 0, gems: 0 });
      const counts = await castles.transaction((tx) => tx.admin.counts('main'));
      expect(counts).toMatchObject({
        users: 1,
        castles: 1,
        marches: 0,
        guilds: 0,
        chatMessages: 0,
      });
      expect(await castles.transaction((tx) => tx.admin.listChatReports(1, 10))).toEqual({
        items: [],
        total: 0,
      });
    });
  });
}
