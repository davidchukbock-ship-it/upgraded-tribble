import { PrismaClient } from '@prisma/client';
import type { FastifyInstance } from 'fastify';
import request from 'supertest';
import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { ensureMainWorld } from '../src/db/bootstrap';
import { createPrismaRepositories } from '../src/modules/auth/auth.repository';
import { makeApp } from './helpers';
import { resetTables, testDatabaseUrl } from './test-db';

const url = testDatabaseUrl();
const HIGH = {
  AUTH_LOGIN_RATE_MAX: '1000',
  AUTH_REGISTER_RATE_MAX: '1000',
  AUTH_GUEST_RATE_MAX: '1000',
};
const creds = { email: 'race@example.com', password: 'Correct horse 42', nickname: 'Гонщик' };

/** Полный стек на настоящей PostgreSQL: то, что in-memory проверить не может — гонки и транзакции. */
describe.runIf(url)('аутентификация на PostgreSQL', () => {
  const db = new PrismaClient({ datasourceUrl: url });
  let app: FastifyInstance | undefined;

  beforeAll(() => ensureMainWorld(db, 1));
  beforeEach(async () => {
    await resetTables(db, ['SecurityLog', 'RefreshToken', 'Building', 'Castle', 'User']);
    ({ app } = await makeApp({ env: HIGH, deps: { repos: createPrismaRepositories(db) } }));
  });
  afterEach(async () => {
    await app?.close();
  });
  afterAll(() => db.$disconnect());

  it('регистрация создаёт пользователя, замок и здания в БД', async () => {
    const res = await request(app!.server).post('/api/auth/register').send(creds);
    expect(res.status).toBe(201);
    const castle = await db.castle.findFirstOrThrow({
      where: { userId: res.body.user.id },
      include: { buildings: true },
    });
    expect(castle.worldId).toBe('main');
    expect(castle.buildings).toHaveLength(6);
    expect(castle.shieldUntil).not.toBeNull();
  });

  it('5 одновременных регистраций с одним email: успех один, остальные 409', async () => {
    const results = await Promise.all(
      Array.from({ length: 5 }, (_, i) =>
        request(app!.server)
          .post('/api/auth/register')
          .send({ ...creds, nickname: `Гонщик ${i}` }),
      ),
    );
    expect(results.filter((r) => r.status === 201)).toHaveLength(1);
    expect(results.filter((r) => r.status === 409)).toHaveLength(4);
    expect(await db.user.count()).toBe(1);
    expect(await db.castle.count()).toBe(1); // проигравшие не оставили замков-сирот
  });

  it('5 одновременных refresh одним токеном: успех один', async () => {
    const reg = await request(app!.server).post('/api/auth/register').send(creds);
    const cookies = reg.headers['set-cookie'] as unknown as string[];
    const val = (n: string) =>
      cookies
        .find((c) => c.startsWith(`${n}=`))!
        .split(';')[0]!
        .slice(n.length + 1);
    const results = await Promise.all(
      Array.from({ length: 5 }, () =>
        request(app!.server)
          .post('/api/auth/refresh')
          .set('Cookie', [`tc_refresh=${val('tc_refresh')}`, `tc_csrf=${val('tc_csrf')}`])
          .set('X-CSRF-Token', val('tc_csrf')),
      ),
    );
    expect(results.filter((r) => r.status === 200)).toHaveLength(1);
    expect(results.filter((r) => r.status === 401)).toHaveLength(4);
  });

  it('блокировка входа хранится в БД и переживает перезапуск приложения', async () => {
    await request(app!.server).post('/api/auth/register').send(creds);
    for (let i = 0; i < 5; i++)
      await request(app!.server)
        .post('/api/auth/login')
        .send({ email: creds.email, password: 'wrong-pass' });
    await app!.close();
    ({ app } = await makeApp({ env: HIGH, deps: { repos: createPrismaRepositories(db) } }));
    const res = await request(app!.server)
      .post('/api/auth/login')
      .send({ email: creds.email, password: creds.password });
    expect(res.status).toBe(429);
    expect(await db.securityLog.count({ where: { kind: 'login_locked' } })).toBe(1);
  });
});
