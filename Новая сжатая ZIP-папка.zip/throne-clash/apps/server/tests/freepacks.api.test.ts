import type { FastifyInstance } from 'fastify';
import request from 'supertest';
import { afterEach, describe, expect, it } from 'vitest';
import { FREE_PACKS } from '@tc/shared';
import { createMemoryRepositories } from '../src/modules/auth/auth.memory';
import { makeApp } from './helpers';

const HIGH = {
  AUTH_LOGIN_RATE_MAX: '1000',
  AUTH_REGISTER_RATE_MAX: '1000',
  AUTH_GUEST_RATE_MAX: '1000',
};
let app: FastifyInstance | undefined;
afterEach(async () => {
  await app?.close();
  app = undefined;
});

let seq = 0;
const idem = () => `free-packs-${Date.now()}-${seq++}`;
const auth = (t: string) => ({ Authorization: `Bearer ${t}` });

async function boot() {
  const repos = createMemoryRepositories();
  const made = await makeApp({ env: HIGH, deps: { repos } });
  app = made.app;
  const reg = await request(made.app.server)
    .post('/api/auth/register')
    .send({ email: 'a@example.com', password: 'Correct horse 42', nickname: 'Артур' });
  const token = reg.body.accessToken as string;
  await request(made.app.server).get('/api/castle').set(auth(token));
  return { app: made.app, clock: made.clock, token };
}

describe('бесплатные наборы через HTTP (D-76)', () => {
  it('требует входа', async () => {
    const { app: x } = await boot();
    expect((await request(x.server).get('/api/free-packs')).status).toBe(401);
    expect(
      (await request(x.server).post('/api/free-packs/breeze/claim').set('Idempotency-Key', idem()))
        .status,
    ).toBe(401);
  });

  it('список: все наборы доступны новому игроку, награды публичны и без случайности', async () => {
    const { app: x, token } = await boot();
    const res = await request(x.server).get('/api/free-packs').set(auth(token));
    expect(res.status).toBe(200);
    expect(res.body.packs).toHaveLength(FREE_PACKS.length);
    expect(res.body.claimable).toBe(FREE_PACKS.length);
    const welcome = res.body.packs.find((p: { id: string }) => p.id === 'welcome');
    expect(welcome).toMatchObject({ everyHours: null, claimed: false, nextAt: null });
    expect(welcome.reward.gems).toBeGreaterThan(0);
  });

  it('набор начисляется один раз за окно; повтор с тем же ключом возвращает тот же ответ', async () => {
    const { app: x, token } = await boot();
    const before = await request(x.server).get('/api/castle').set(auth(token));
    const key = idem();
    const a = await request(x.server)
      .post('/api/free-packs/breeze/claim')
      .set(auth(token))
      .set('Idempotency-Key', key);
    expect(a.status).toBe(200);
    expect(a.body.reward.resources.gold).toBe(150);
    expect(a.body.castle.resources.gold).toBeGreaterThan(before.body.resources.gold);
    const replay = await request(x.server)
      .post('/api/free-packs/breeze/claim')
      .set(auth(token))
      .set('Idempotency-Key', key);
    expect(replay.status).toBe(200);
    expect(replay.body.castle.resources.gold).toBe(a.body.castle.resources.gold);
    const again = await request(x.server)
      .post('/api/free-packs/breeze/claim')
      .set(auth(token))
      .set('Idempotency-Key', idem());
    expect(again.status).toBe(409);
    const list = await request(x.server).get('/api/free-packs').set(auth(token));
    expect(list.body.claimable).toBe(FREE_PACKS.length - 1);
    expect(list.body.packs.find((p: { id: string }) => p.id === 'breeze').claimed).toBe(true);
  });

  it('следующее окно открывает набор снова; разовый набор — никогда', async () => {
    const { app: x, clock, token } = await boot();
    for (const id of ['breeze', 'welcome']) {
      const r = await request(x.server)
        .post(`/api/free-packs/${id}/claim`)
        .set(auth(token))
        .set('Idempotency-Key', idem());
      expect(r.status).toBe(200);
    }
    const relogin = async () =>
      (
        await request(x.server)
          .post('/api/auth/login')
          .send({ email: 'a@example.com', password: 'Correct horse 42' })
      ).body.accessToken as string;
    clock.advance(5 * 3600); // прошло больше одного окна «breeze» (4 часа); токен доступа живёт 15 минут
    const fresh = await relogin();
    const breeze = await request(x.server)
      .post('/api/free-packs/breeze/claim')
      .set(auth(fresh))
      .set('Idempotency-Key', idem());
    expect(breeze.status).toBe(200);
    clock.advance(30 * 24 * 3600);
    const fresh2 = await relogin();
    const welcome = await request(x.server)
      .post('/api/free-packs/welcome/claim')
      .set(auth(fresh2))
      .set('Idempotency-Key', idem());
    expect(welcome.status).toBe(409);
  });

  it('неизвестный набор — 404; сундук из набора попадает в инвентарь', async () => {
    const { app: x, token } = await boot();
    expect(
      (
        await request(x.server)
          .post('/api/free-packs/nope/claim')
          .set(auth(token))
          .set('Idempotency-Key', idem())
      ).status,
    ).toBe(404);
    const w = await request(x.server)
      .post('/api/free-packs/builder/claim')
      .set(auth(token))
      .set('Idempotency-Key', idem());
    expect(w.status).toBe(200);
    expect(w.body.inventory.chests.wooden).toBeGreaterThanOrEqual(1);
  });
});
