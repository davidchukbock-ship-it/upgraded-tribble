import type { FastifyInstance } from 'fastify';
import { SignJWT } from 'jose';
import request from 'supertest';
import { afterEach, describe, expect, it } from 'vitest';
import type { FakeClock } from '../src/lib/clock';
import { createMemoryRepositories } from '../src/modules/auth/auth.memory';
import { makeApp } from './helpers';

const OWNER = 'owner@example.com';
const creds = { email: 'hero@example.com', password: 'Correct horse 42', nickname: 'Артур' };

// Лимиты входа/регистрации в тестах высокие; отдельный тест проверяет 429 на низком пороге
const HIGH = {
  AUTH_LOGIN_RATE_MAX: '1000',
  AUTH_REGISTER_RATE_MAX: '1000',
  AUTH_GUEST_RATE_MAX: '1000',
};

let app: FastifyInstance | undefined;
afterEach(async () => {
  await app?.close();
  app = undefined;
});

async function boot(env: Record<string, string> = {}, repos = createMemoryRepositories()) {
  const made = await makeApp({ env: { ...HIGH, OWNER_EMAIL: OWNER, ...env }, deps: { repos } });
  app = made.app;
  return { app: made.app, clock: made.clock as FakeClock, repos };
}

const setCookies = (res: request.Response): string[] => {
  const raw = res.headers['set-cookie'] as unknown;
  return Array.isArray(raw) ? (raw as string[]) : typeof raw === 'string' ? [raw] : [];
};
const cookieValue = (res: request.Response, name: string): string | undefined =>
  setCookies(res)
    .find((c) => c.startsWith(`${name}=`))
    ?.split(';')[0]
    ?.slice(name.length + 1);

/** Регистрирует игрока и возвращает всё, что нужно для cookie-эндпоинтов. */
async function register(a: FastifyInstance, body: object = creds) {
  const res = await request(a.server).post('/api/auth/register').send(body);
  expect(res.status).toBe(201);
  return {
    res,
    access: res.body.accessToken as string,
    refresh: cookieValue(res, 'tc_refresh')!,
    csrf: cookieValue(res, 'tc_csrf')!,
  };
}

const refreshWith = (
  a: FastifyInstance,
  refresh: string,
  csrf: string,
  extra: Record<string, string> = {},
) =>
  request(a.server)
    .post('/api/auth/refresh')
    .set('Cookie', [`tc_refresh=${refresh}`, `tc_csrf=${csrf}`])
    .set('X-CSRF-Token', csrf)
    .set(extra);

describe('POST /api/auth/register', () => {
  it('201, токены, безопасные cookie и ни следа хеша в ответе', async () => {
    const { app: a, repos } = await boot();
    const { res } = await register(a);
    expect(res.body.user).toMatchObject({
      nickname: 'Артур',
      email: 'hero@example.com',
      role: 'PLAYER',
    });
    expect(res.body.expiresIn).toBe(900);
    expect(res.body.serverTime).toBe('2026-01-01T00:00:00.000Z');
    expect(JSON.stringify(res.body)).not.toMatch(/argon2|passwordHash/);

    const [rt, csrf] = ['tc_refresh', 'tc_csrf'].map((n) =>
      setCookies(res).find((c) => c.startsWith(`${n}=`))!,
    );
    expect(rt).toMatch(/HttpOnly/i);
    expect(rt).toMatch(/SameSite=Strict/i);
    expect(rt).toMatch(/Path=\/api\/auth/);
    expect(csrf).not.toMatch(/HttpOnly/i); // клиенту нужно прочитать его и продублировать в заголовок
    expect(csrf).toMatch(/SameSite=Strict/i);

    const stored = [...repos.users.users.values()][0]!;
    expect(stored.passwordHash).toMatch(/^\$argon2id\$/); // настоящий argon2id, не заглушка
  });

  it('секретный cookie помечается Secure в production-настройке', async () => {
    const { app: a } = await boot({ COOKIE_SECURE: 'true' });
    const { res } = await register(a);
    expect(setCookies(res).every((c) => /Secure/i.test(c))).toBe(true);
  });

  it.each([
    ['короткий пароль', { ...creds, password: 'short' }],
    ['частый пароль', { ...creds, password: 'password123' }],
    ['плохой email', { ...creds, email: 'not-an-email' }],
    ['зарезервированный ник', { ...creds, nickname: 'Admin' }],
    ['ник со спецсимволами', { ...creds, nickname: '<b>x</b>' }],
    ['лишнее поле role (mass assignment)', { ...creds, role: 'OWNER' }],
    ['лишнее поле isGuest', { ...creds, isGuest: true }],
    ['пустое тело', {}],
  ])('400 ERR_VALIDATION: %s', async (_name, body) => {
    const { app: a } = await boot();
    const res = await request(a.server).post('/api/auth/register').send(body);
    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe('ERR_VALIDATION');
    expect(res.body.requestId).toBeTruthy();
  });

  it('409 при занятом email — независимо от регистра — и при занятом нике', async () => {
    const { app: a } = await boot();
    await register(a);
    const dupEmail = await request(a.server)
      .post('/api/auth/register')
      .send({ ...creds, email: 'HERO@example.com', nickname: 'Другой' });
    expect(dupEmail.status).toBe(409);
    expect(dupEmail.body.error.code).toBe('ERR_EMAIL_TAKEN');
    const dupNick = await request(a.server)
      .post('/api/auth/register')
      .send({ ...creds, email: 'b@example.com', nickname: 'артур' });
    expect(dupNick.body.error.code).toBe('ERR_NICKNAME_TAKEN');
  });

  it('владелец по email всё равно регистрируется как PLAYER', async () => {
    const { app: a } = await boot();
    const { res } = await register(a, { ...creds, email: OWNER });
    expect(res.body.user.role).toBe('PLAYER');
  });
});

describe('POST /api/auth/login', () => {
  it('200 при верных данных; email нормализуется', async () => {
    const { app: a } = await boot();
    await register(a);
    const res = await request(a.server)
      .post('/api/auth/login')
      .send({ email: '  HERO@example.com ', password: creds.password });
    expect(res.status).toBe(200);
    expect(res.body.user.nickname).toBe('Артур');
    expect(cookieValue(res, 'tc_refresh')).toBeTruthy();
  });

  it('неверный пароль и незнакомый email — одинаковый 401', async () => {
    const { app: a } = await boot();
    await register(a);
    const wrong = await request(a.server)
      .post('/api/auth/login')
      .send({ email: creds.email, password: 'wrong-pass' });
    const ghost = await request(a.server)
      .post('/api/auth/login')
      .send({ email: 'ghost@example.com', password: 'wrong-pass' });
    expect(wrong.status).toBe(401);
    expect(ghost.status).toBe(401);
    expect(wrong.body.error).toEqual(ghost.body.error);
    expect(wrong.body.error.code).toBe('ERR_INVALID_CREDENTIALS');
    expect(setCookies(wrong)).toHaveLength(0);
  });

  it('после 5 неверных паролей аккаунт заблокирован: 429 даже с верным паролем', async () => {
    const { app: a } = await boot();
    await register(a);
    for (let i = 0; i < 5; i++) {
      await request(a.server)
        .post('/api/auth/login')
        .send({ email: creds.email, password: 'bad-pass-1' });
    }
    const res = await request(a.server)
      .post('/api/auth/login')
      .send({ email: creds.email, password: creds.password });
    expect(res.status).toBe(429);
    expect(res.body.error.code).toBe('ERR_RATE_LIMITED');
    expect(res.body.error.details.retryAfterSeconds).toBeGreaterThan(0);
  });

  it('лимит по IP: сверх порога — 429 с Retry-After', async () => {
    const { app: a } = await boot({ AUTH_LOGIN_RATE_MAX: '3' });
    const attempt = () =>
      request(a.server).post('/api/auth/login').send({ email: 'x@example.com', password: 'y' });
    for (let i = 0; i < 3; i++) expect((await attempt()).status).toBe(401);
    const limited = await attempt();
    expect(limited.status).toBe(429);
    expect(limited.body.error.code).toBe('ERR_RATE_LIMITED');
    expect(limited.headers['retry-after']).toBeDefined();
  });
});

describe('GET /api/auth/me и проверка access-токена', () => {
  it('без токена и с мусором — 401', async () => {
    const { app: a } = await boot();
    for (const h of [undefined, 'Bearer', 'Bearer abc', 'Basic Zm9vOmJhcg==', 'Bearer a.b.c']) {
      const req = request(a.server).get('/api/auth/me');
      const res = await (h ? req.set('Authorization', h) : req);
      expect(res.status).toBe(401);
      expect(res.body.error.code).toBe('ERR_UNAUTHORIZED');
    }
  });

  it('возвращает профиль по валидному токену', async () => {
    const { app: a } = await boot();
    const { access } = await register(a);
    const res = await request(a.server)
      .get('/api/auth/me')
      .set('Authorization', `Bearer ${access}`);
    expect(res.status).toBe(200);
    expect(res.body.user.email).toBe(creds.email);
  });

  it('подделка: чужой секрет, alg=none, чужой issuer — 401', async () => {
    const { app: a, repos } = await boot();
    const { res } = await register(a);
    const id = res.body.user.id as string;
    const forge = (secret: string, iss: string) =>
      new SignJWT({ role: 'OWNER' })
        .setProtectedHeader({ alg: 'HS256' })
        .setSubject(id)
        .setIssuer(iss)
        .setAudience('throne-clash-web')
        .setIssuedAt()
        .setExpirationTime('1h')
        .sign(new TextEncoder().encode(secret));
    const unsigned = `${Buffer.from('{"alg":"none"}').toString('base64url')}.${Buffer.from(
      JSON.stringify({ sub: id, iss: 'throne-clash', aud: 'throne-clash-web', exp: 4102444800 }),
    ).toString('base64url')}.`;
    const tokens = [
      await forge('another-secret-another-secret-123456', 'throne-clash'),
      await forge('x'.repeat(40), 'evil'),
      unsigned,
    ];
    for (const t of tokens) {
      const r = await request(a.server).get('/api/auth/me').set('Authorization', `Bearer ${t}`);
      expect(r.status).toBe(401);
    }
    expect(repos.users.users.get(id)?.role).toBe('PLAYER');
  });

  it('токен истекает по серверным часам', async () => {
    const { app: a, clock } = await boot();
    const { access } = await register(a);
    clock.advance(901);
    const res = await request(a.server)
      .get('/api/auth/me')
      .set('Authorization', `Bearer ${access}`);
    expect(res.status).toBe(401);
  });

  it('бан действует сразу, не дожидаясь истечения токена', async () => {
    const { app: a, repos, clock } = await boot();
    const { access, res } = await register(a);
    const user = repos.users.users.get(res.body.user.id)!;
    user.bannedUntil = new Date(clock.now().getTime() + 3600_000);
    user.banReason = 'cheating';
    const r = await request(a.server).get('/api/auth/me').set('Authorization', `Bearer ${access}`);
    expect(r.status).toBe(403);
    expect(r.body.error.code).toBe('ERR_BANNED');
  });

  it('роль OWNER без совпадения с OWNER_EMAIL в API выглядит как PLAYER', async () => {
    const { app: a, repos } = await boot();
    const { access, res } = await register(a);
    repos.users.users.get(res.body.user.id)!.role = 'OWNER'; // «подмена» роли в БД
    const me = await request(a.server).get('/api/auth/me').set('Authorization', `Bearer ${access}`);
    expect(me.body.user.role).toBe('PLAYER');
  });

  it('OWNER с совпавшим email распознаётся', async () => {
    const { app: a, repos } = await boot();
    const { access, res } = await register(a, { ...creds, email: OWNER });
    repos.users.users.get(res.body.user.id)!.role = 'OWNER'; // выдаётся CLI, не API
    const me = await request(a.server).get('/api/auth/me').set('Authorization', `Bearer ${access}`);
    expect(me.body.user.role).toBe('OWNER');
  });
});

describe('POST /api/auth/refresh (cookie + CSRF)', () => {
  it('ротация: новый access и новые cookie, старый refresh больше не работает', async () => {
    const { app: a } = await boot();
    const s = await register(a);
    const r1 = await refreshWith(a, s.refresh, s.csrf);
    expect(r1.status).toBe(200);
    expect(r1.body.accessToken).toBeTruthy();
    const newRefresh = cookieValue(r1, 'tc_refresh')!;
    expect(newRefresh).not.toBe(s.refresh);
    const r2 = await refreshWith(a, newRefresh, cookieValue(r1, 'tc_csrf')!);
    expect(r2.status).toBe(200);
  });

  it('без CSRF-заголовка, с чужим значением или чужим Origin — 403', async () => {
    const { app: a } = await boot({ CORS_ORIGIN: 'https://game.example' });
    const s = await register(a);
    const noHeader = await request(a.server)
      .post('/api/auth/refresh')
      .set('Cookie', [`tc_refresh=${s.refresh}`, `tc_csrf=${s.csrf}`]);
    expect(noHeader.status).toBe(403);
    // cookie и заголовок различаются — так выглядит подделанный межсайтовый запрос
    const wrong = await request(a.server)
      .post('/api/auth/refresh')
      .set('Cookie', [`tc_refresh=${s.refresh}`, `tc_csrf=${s.csrf}`])
      .set('X-CSRF-Token', 'a-different-value');
    expect(wrong.status).toBe(403);
    const evil = await refreshWith(a, s.refresh, s.csrf, { Origin: 'https://evil.example' });
    expect(evil.status).toBe(403);
    const good = await refreshWith(a, s.refresh, s.csrf, { Origin: 'https://game.example' });
    expect(good.status).toBe(200);
  });

  it('без refresh-cookie — 401', async () => {
    const { app: a } = await boot();
    const res = await request(a.server)
      .post('/api/auth/refresh')
      .set('Cookie', ['tc_csrf=abc'])
      .set('X-CSRF-Token', 'abc');
    expect(res.status).toBe(401);
  });

  it('повторное использование украденного токена: цепочка отзывается, cookie очищаются', async () => {
    const { app: a, clock } = await boot();
    const s = await register(a);
    const r1 = await refreshWith(a, s.refresh, s.csrf);
    clock.advance(60);
    const replay = await refreshWith(a, s.refresh, s.csrf);
    expect(replay.status).toBe(401);
    // Set-Cookie с обнулением сохраняется в ответе-ошибке
    expect(setCookies(replay).some((c) => /^tc_refresh=;/.test(c))).toBe(true);
    const victim = await refreshWith(
      a,
      cookieValue(r1, 'tc_refresh')!,
      cookieValue(r1, 'tc_csrf')!,
    );
    expect(victim.status).toBe(401);
  });
});

describe('logout', () => {
  it('204, cookie очищены, refresh больше не работает; без CSRF — 403', async () => {
    const { app: a } = await boot();
    const s = await register(a);
    const forbidden = await request(a.server)
      .post('/api/auth/logout')
      .set('Cookie', [`tc_refresh=${s.refresh}`]);
    expect(forbidden.status).toBe(403);

    const res = await request(a.server)
      .post('/api/auth/logout')
      .set('Cookie', [`tc_refresh=${s.refresh}`, `tc_csrf=${s.csrf}`])
      .set('X-CSRF-Token', s.csrf);
    expect(res.status).toBe(204);
    expect(setCookies(res).some((c) => /^tc_refresh=;/.test(c))).toBe(true);
    expect((await refreshWith(a, s.refresh, s.csrf)).status).toBe(401);
  });

  it('logout-all требует токен и закрывает все устройства', async () => {
    const { app: a } = await boot();
    const s = await register(a);
    const login = await request(a.server)
      .post('/api/auth/login')
      .send({ email: creds.email, password: creds.password });
    expect((await request(a.server).post('/api/auth/logout-all')).status).toBe(401);
    const res = await request(a.server)
      .post('/api/auth/logout-all')
      .set('Authorization', `Bearer ${s.access}`);
    expect(res.status).toBe(204);
    expect((await refreshWith(a, s.refresh, s.csrf)).status).toBe(401);
    expect(
      (await refreshWith(a, cookieValue(login, 'tc_refresh')!, cookieValue(login, 'tc_csrf')!))
        .status,
    ).toBe(401);
  });
});

describe('гость и привязка аккаунта', () => {
  it('POST /auth/guest без тела → 201; затем /auth/upgrade делает полноценный аккаунт', async () => {
    const { app: a } = await boot();
    const g = await request(a.server).post('/api/auth/guest');
    expect(g.status).toBe(201);
    expect(g.body.user).toMatchObject({ isGuest: true, email: null });
    const up = await request(a.server)
      .post('/api/auth/upgrade')
      .set('Authorization', `Bearer ${g.body.accessToken}`)
      .send({ email: 'guest@example.com', password: 'Correct horse 42' });
    expect(up.status).toBe(200);
    expect(up.body.user).toMatchObject({ isGuest: false, email: 'guest@example.com' });
    const login = await request(a.server)
      .post('/api/auth/login')
      .send({ email: 'guest@example.com', password: 'Correct horse 42' });
    expect(login.status).toBe(200);
    expect(login.body.user.id).toBe(g.body.user.id);
  });

  it('украинский язык: гость «Гість-…», язык профиля сохраняется', async () => {
    const { app: a } = await boot();
    const g = await request(a.server).post('/api/auth/guest').send({ language: 'uk' });
    expect(g.status).toBe(201);
    expect(g.body.user.language).toBe('uk');
    expect(g.body.user.nickname).toMatch(/^Гість-/);
    const upd = await request(a.server)
      .patch('/api/profile')
      .set('Authorization', `Bearer ${g.body.accessToken}`)
      .send({ language: 'ru' });
    expect(upd.status).toBe(200);
    expect(upd.body.user.language).toBe('ru');
  });

  it('язык гостя из тела', async () => {
    const { app: a } = await boot();
    const g = await request(a.server).post('/api/auth/guest').send({ language: 'en' });
    expect(g.body.user.language).toBe('en');
    expect(g.body.user.nickname).toMatch(/^Guest-/);
    expect((await request(a.server).post('/api/auth/guest').send({ language: 'xx' })).status).toBe(
      400,
    );
  });
});

describe('PATCH /api/profile', () => {
  it('меняет ник, герб и язык; чужие поля отклоняются', async () => {
    const { app: a } = await boot();
    const { access } = await register(a);
    const ok = await request(a.server)
      .patch('/api/profile')
      .set('Authorization', `Bearer ${access}`)
      .send({ nickname: 'Рыцарь Ночи', crest: 'wolf', language: 'en' });
    expect(ok.status).toBe(200);
    expect(ok.body.user).toMatchObject({ nickname: 'Рыцарь Ночи', crest: 'wolf', language: 'en' });

    for (const body of [{ role: 'OWNER' }, { crest: 'dragon' }, { email: 'x@y.co' }, {}]) {
      const bad = await request(a.server)
        .patch('/api/profile')
        .set('Authorization', `Bearer ${access}`)
        .send(body);
      expect(bad.status).toBe(400);
    }
    const cooldown = await request(a.server)
      .patch('/api/profile')
      .set('Authorization', `Bearer ${access}`)
      .send({ nickname: 'Третий Ник' });
    expect(cooldown.status).toBe(422);
    expect(cooldown.body.error.details.reason).toBe('nickname_cooldown');
  });

  it('требует авторизации', async () => {
    const { app: a } = await boot();
    expect((await request(a.server).patch('/api/profile').send({ crest: 'wolf' })).status).toBe(
      401,
    );
  });
});

describe('документация и служебные заголовки', () => {
  it('OpenAPI описывает маршруты аутентификации и безопасность bearer', async () => {
    const { app: a } = await boot({ SWAGGER_ENABLED: 'true' });
    const res = await request(a.server).get('/docs/json');
    expect(res.status).toBe(200);
    expect(Object.keys(res.body.paths)).toEqual(
      expect.arrayContaining([
        '/api/auth/register',
        '/api/auth/login',
        '/api/auth/refresh',
        '/api/auth/me',
        '/api/profile',
      ]),
    );
  });

  it('каждый ответ несёт X-Server-Time и X-Request-Id', async () => {
    const { app: a } = await boot();
    const res = await request(a.server)
      .post('/api/auth/login')
      .send({ email: 'x@y.co', password: 'z' });
    expect(res.headers['x-server-time']).toBe('2026-01-01T00:00:00.000Z');
    expect(res.headers['x-request-id']).toBeTruthy();
  });
});
