import { START_BUILDINGS, START_GEMS } from '@tc/shared';
import { FakeClock } from '../src/lib/clock';
import { createMemoryRepositories } from '../src/modules/auth/auth.memory';
import { castleFor, userFor } from './repository.contract';
import { marchSuite } from './march.suite';

let n = 0;

marchSuite('in-memory', async () => {
  const repos = createMemoryRepositories();
  const clock = new FakeClock();
  return {
    repo: repos.castles,
    clock,
    async addPlayer(name) {
      const user = await repos.users.createWithCastle(
        { ...userFor(name, `m${n++}@example.com`), createdAt: clock.now() },
        {
          ...castleFor(),
          buildings: START_BUILDINGS,
          resourcesUpdatedAt: clock.now(),
          gems: START_GEMS,
        },
      );
      return user.id;
    },
  };
});
