import { execFileSync } from 'node:child_process';
import { schemaArgs, testDatabaseUrl } from './test-db';

/** Применяет миграции к тестовой БД перед прогоном: так проверяются и сами миграции. */
export default function setup(): void {
  const url = testDatabaseUrl();
  if (!url) return;
  execFileSync('pnpm', ['exec', 'prisma', 'migrate', 'deploy', ...schemaArgs()], {
    env: { ...process.env, DATABASE_URL: url },
    stdio: 'pipe',
  });
}
