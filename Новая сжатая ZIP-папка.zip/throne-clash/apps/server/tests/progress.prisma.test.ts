import { PrismaClient } from '@prisma/client';
import { afterAll, beforeEach, describe } from 'vitest';
import { START_BUILDINGS, START_GEMS } from '@tc/shared';
import { ensureMainWorld } from '../src/db/bootstrap';
import { FakeClock } from '../src/lib/clock';
import { createPrismaRepositories } from '../src/modules/auth/auth.repository';
import { PrismaCastleRepository } from '../src/modules/castle/castle.repository';
import { progressSuite } from './progress.suite';
import { castleFor, userFor } from './repository.contract';
import { resetTables, testDatabaseUrl } from './test-db';

const url = testDatabaseUrl();

describe.runIf(url)('задания, сундуки, магазин и лиги на PostgreSQL', () => {
  const db = new PrismaClient({ datasourceUrl: url });
  const repos = createPrismaRepositories(db);
  let n = 0;

  beforeEach(async () => {
    await resetTables(db, [
      'ChestLog',
      'SeasonReward',
      'Season',
      'SeasonStat',
      'LoginStreak',
      'QuestClaim',
      'QuestCounter',
      'InventoryItem',
      'Notification',
      'ChatReport',
      'ChatMessage',
      'GuildHelp',
      'GuildApplication',
      'GuildMember',
      'Guild',
      'Report',
      'CellState',
      'March',
      'IdempotencyKey',
      'EconomyEvent',
      'BuildTask',
      'TrainTask',
      'ResearchTask',
      'ArmyUnit',
      'TechLevel',
      'HeroItem',
      'Hero',
      'SecurityLog',
      'RefreshToken',
      'Building',
      'Castle',
      'User',
    ]);
    await ensureMainWorld(db, 20260101);
  });
  afterAll(() => db.$disconnect());

  progressSuite('PostgreSQL', async () => {
    const clock = new FakeClock();
    return {
      repo: new PrismaCastleRepository(db),
      users: repos.users,
      clock,
      async markGod(userId) {
        await db.castle.updateMany({ where: { userId }, data: { isGodAction: true } });
      },
      async addPlayer(name) {
        const user = await repos.users.createWithCastle(
          { ...userFor(name, `pp${n++}@example.com`), isGuest: false, createdAt: clock.now() },
          {
            ...castleFor(),
            buildings: START_BUILDINGS,
            resourcesUpdatedAt: clock.now(),
            gems: START_GEMS,
          },
        );
        return user.id;
      },
    };
  });
});
