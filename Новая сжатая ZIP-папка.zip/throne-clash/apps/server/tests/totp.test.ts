import { describe, expect, it } from 'vitest';
import {
  base32Decode,
  base32Encode,
  generateTotpSecret,
  totpCode,
  verifyTotp,
} from '../src/lib/totp';

// Секрет из RFC 6238 (ASCII "12345678901234567890"); RFC даёт 8-значные коды, мы берём 6 младших цифр
const RFC_SECRET = 'GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ';

describe('TOTP (RFC 6238)', () => {
  it('совпадает с тестовыми векторами RFC', () => {
    const vectors: Array<[number, string]> = [
      [59, '287082'],
      [1_111_111_109, '081804'],
      [1_111_111_111, '050471'],
      [1_234_567_890, '005924'],
      [2_000_000_000, '279037'],
    ];
    for (const [t, code] of vectors) expect(totpCode(RFC_SECRET, t * 1000)).toBe(code);
  });

  it('допускает сдвиг часов на один шаг, но не больше', () => {
    const t = 1_234_567_890_000;
    const code = totpCode(RFC_SECRET, t);
    expect(verifyTotp(RFC_SECRET, code, t)).toBe(true);
    expect(verifyTotp(RFC_SECRET, code, t + 30_000)).toBe(true);
    expect(verifyTotp(RFC_SECRET, code, t - 30_000)).toBe(true);
    expect(verifyTotp(RFC_SECRET, code, t + 90_000)).toBe(false);
  });

  it('отвергает неверный формат', () => {
    for (const bad of ['', '12345', '1234567', 'abcdef', '12 456'])
      expect(verifyTotp(RFC_SECRET, bad, 59_000)).toBe(false);
  });

  it('base32 туда и обратно; секрет генерируется случайно', () => {
    const bytes = Uint8Array.from([1, 2, 3, 250, 251, 0, 77]);
    expect([...base32Decode(base32Encode(bytes))]).toEqual([...bytes]);
    expect(base32Decode('gezd gndv-')).toBeDefined();
    expect(() => base32Decode('!!!')).toThrow();
    const a = generateTotpSecret();
    expect(a).toMatch(/^[A-Z2-7]{32}$/);
    expect(generateTotpSecret()).not.toBe(a);
  });
});
