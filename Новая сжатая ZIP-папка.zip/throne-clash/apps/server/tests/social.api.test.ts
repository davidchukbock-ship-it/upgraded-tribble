import type { FastifyInstance } from 'fastify';
import request from 'supertest';
import { afterEach, describe, expect, it } from 'vitest';
import { createMemoryRepositories } from '../src/modules/auth/auth.memory';
import { makeApp } from './helpers';

const HIGH = {
  AUTH_LOGIN_RATE_MAX: '1000',
  AUTH_REGISTER_RATE_MAX: '1000',
  AUTH_GUEST_RATE_MAX: '1000',
};
let app: FastifyInstance | undefined;
afterEach(async () => {
  await app?.close();
  app = undefined;
});

let seq = 0;
const idem = () => `social-api-${Date.now()}-${seq++}`;
const auth = (t: string) => ({ Authorization: `Bearer ${t}` });

async function boot() {
  const repos = createMemoryRepositories();
  const made = await makeApp({ env: HIGH, deps: { repos } });
  app = made.app;
  const player = async (nickname: string, email: string) => {
    const reg = await request(made.app.server)
      .post('/api/auth/register')
      .send({ email, password: 'Correct horse 42', nickname });
    const token = reg.body.accessToken as string;
    const userId = reg.body.user.id as string;
    await request(made.app.server).get('/api/castle').set(auth(token));
    const cur = repos.castles.peek(userId)!;
    repos.castles.seed({ ...cur, levels: { ...cur.levels, castle: 5 }, shieldUntil: null });
    return { token, userId };
  };
  const a = await player('Артур', 'a@example.com');
  const b = await player('Борис', 'b@example.com');
  return { app: made.app, clock: made.clock, repos, a, b };
}

describe('братства через HTTP', () => {
  it('всё требует входа', async () => {
    const { app: x } = await boot();
    for (const path of [
      '/api/guilds',
      '/api/guilds/mine',
      '/api/notifications',
      '/api/chat/world/history',
    ]) {
      expect((await request(x.server).get(path)).status).toBe(401);
    }
  });

  it('создание → моё братство → заявка → принятие → взнос → выход', async () => {
    const { app: x, repos, a, b } = await boot();
    const created = await request(x.server)
      .post('/api/guilds')
      .set(auth(a.token))
      .set('Idempotency-Key', idem())
      .send({ name: 'Волки Севера', description: 'Мы сильны' });
    expect(created.status).toBe(200);
    expect(created.body.guild).toMatchObject({
      name: 'Волки Севера',
      myRole: 'leader',
      level: 1,
      capacity: 22,
      members: 1,
    });
    const gid = created.body.guild.id as string;

    const list = await request(x.server)
      .get('/api/guilds')
      .query({ q: 'волки' })
      .set(auth(b.token));
    expect(list.body.items).toMatchObject([
      { id: gid, name: 'Волки Севера', members: 1, leaderName: 'Артур' },
    ]);

    expect(
      (await request(x.server).post(`/api/guilds/${gid}/apply`).set(auth(b.token))).status,
    ).toBe(204);
    expect(
      (await request(x.server).post(`/api/guilds/${gid}/apply`).set(auth(b.token))).status,
    ).toBe(409);
    const mineB = await request(x.server).get('/api/guilds/mine').set(auth(b.token));
    expect(mineB.body).toMatchObject({
      guild: null,
      applications: [{ guildId: gid, guildName: 'Волки Севера' }],
    });

    const mineA = await request(x.server).get('/api/guilds/mine').set(auth(a.token));
    const appId = mineA.body.guild.applications[0].id as string;
    expect(
      (await request(x.server).post(`/api/guilds/applications/${appId}/accept`).set(auth(b.token)))
        .status,
    ).toBe(422); // b ещё не в братстве
    expect(
      (await request(x.server).post(`/api/guilds/applications/${appId}/accept`).set(auth(a.token)))
        .status,
    ).toBe(204);
    expect(
      (await request(x.server).get('/api/guilds/mine').set(auth(b.token))).body.guild,
    ).toMatchObject({ myRole: 'member', members: 2 });

    const rich = repos.castles.peek(a.userId)!;
    repos.castles.seed({ ...rich, resources: { ...rich.resources, gold: 5000 } });
    const donate = await request(x.server)
      .post('/api/guilds/treasury/donate')
      .set(auth(a.token))
      .set('Idempotency-Key', idem())
      .send({ amount: 500 });
    expect(donate.status).toBe(200);
    expect(
      (await request(x.server).get('/api/guilds/mine').set(auth(a.token))).body.guild.treasury,
    ).toBe(500);

    expect(
      (
        await request(x.server)
          .post(`/api/guilds/members/${b.userId}/role`)
          .set(auth(a.token))
          .send({ role: 'officer' })
      ).status,
    ).toBe(204);
    expect(
      (
        await request(x.server)
          .post(`/api/guilds/members/${b.userId}/role`)
          .set(auth(b.token))
          .send({ role: 'member' })
      ).status,
    ).toBe(403);
    expect((await request(x.server).post('/api/guilds/leave').set(auth(a.token))).status).toBe(422);
    expect(
      (await request(x.server).delete(`/api/guilds/members/${b.userId}`).set(auth(a.token))).status,
    ).toBe(204);
    expect((await request(x.server).post('/api/guilds/leave').set(auth(a.token))).status).toBe(204);
  });

  it('валидация: имя, ключ идемпотентности, лишние поля', async () => {
    const { app: x, a } = await boot();
    const post = (body: object, key = idem()) =>
      request(x.server)
        .post('/api/guilds')
        .set(auth(a.token))
        .set('Idempotency-Key', key)
        .send(body);
    expect((await post({ name: 'ab' })).status).toBe(400);
    expect((await post({ name: 'Ок Имя', extra: 1 })).status).toBe(400);
    expect(
      (await request(x.server).post('/api/guilds').set(auth(a.token)).send({ name: 'Ок Имя' }))
        .status,
    ).toBe(400);
    expect((await post({ name: '<b>x</b>' })).status).toBe(400);
  });
});

describe('чат и уведомления через HTTP', () => {
  it('сообщение, история, лимит и жалоба', async () => {
    const { app: x, a, b } = await boot();
    const send = (t: string, text: string, channel = 'world') =>
      request(x.server).post(`/api/chat/${channel}/messages`).set(auth(t)).send({ text });
    const ok = await send(a.token, 'привет');
    expect(ok.status).toBe(200);
    expect(ok.body).toMatchObject({ channel: 'world', nickname: 'Артур', text: 'привет' });
    const hist = await request(x.server).get('/api/chat/world/history').set(auth(b.token));
    expect(hist.body).toHaveLength(1);

    for (let i = 0; i < 4; i++) await send(a.token, `m${i}`);
    const limited = await send(a.token, 'лишнее');
    expect(limited.status).toBe(429);
    expect(limited.body.error.details.retryAfterSeconds).toBeGreaterThan(0);

    const rep = await request(x.server)
      .post('/api/chat/report')
      .set(auth(b.token))
      .send({ messageId: ok.body.id, reason: 'спам' });
    expect(rep.status).toBe(204);
    expect(
      (
        await request(x.server)
          .post('/api/chat/report')
          .set(auth(b.token))
          .send({ messageId: ok.body.id, reason: 'спам' })
      ).status,
    ).toBe(409);
    expect(
      (
        await request(x.server)
          .post('/api/chat/report')
          .set(auth(b.token))
          .send({ messageId: 'x', reason: 'y' })
      ).status,
    ).toBe(400);
    expect((await send(a.token, 'привет', 'nope')).status).toBe(400);
    expect(
      (
        await request(x.server)
          .post('/api/chat/world/messages')
          .set(auth(a.token))
          .send({ text: 'a', extra: 1 })
      ).status,
    ).toBe(400);
  });

  it('личный канал по id собеседника', async () => {
    const { app: x, a, b } = await boot();
    const res = await request(x.server)
      .post(`/api/chat/dm:${b.userId}/messages`)
      .set(auth(a.token))
      .send({ text: 'лично' });
    expect(res.status).toBe(200);
    const theirs = await request(x.server)
      .get(`/api/chat/dm:${a.userId}/history`)
      .set(auth(b.token));
    expect(theirs.body).toMatchObject([{ text: 'лично', channel: `dm:${a.userId}` }]);
    const notes = await request(x.server).get('/api/notifications').set(auth(b.token));
    expect(notes.body).toMatchObject({
      total: 1,
      unread: 1,
      items: [{ kind: 'chat.dm', payload: { from: 'Артур' } }],
    });
  });

  it('уведомления: страницы, отметка прочитанным, валидация', async () => {
    const { app: x, a, b } = await boot();
    for (let i = 0; i < 3; i++) {
      await request(x.server)
        .post(`/api/chat/dm:${b.userId}/messages`)
        .set(auth(a.token))
        .send({ text: `m${i}` });
    }
    const page = await request(x.server)
      .get('/api/notifications')
      .query({ pageSize: 2 })
      .set(auth(b.token));
    expect(page.body).toMatchObject({ total: 3, unread: 3, pageSize: 2 });
    expect(page.body.items).toHaveLength(2);
    const one = await request(x.server)
      .post('/api/notifications/read')
      .set(auth(b.token))
      .send({ ids: [page.body.items[0].id] });
    expect(one.body).toEqual({ marked: 1 });
    const all = await request(x.server).post('/api/notifications/read').set(auth(b.token)).send({});
    expect(all.body).toEqual({ marked: 2 });
    expect((await request(x.server).get('/api/notifications').set(auth(b.token))).body.unread).toBe(
      0,
    );
    expect(
      (await request(x.server).get('/api/notifications?pageSize=500').set(auth(b.token))).status,
    ).toBe(400);
    expect(
      (
        await request(x.server)
          .post('/api/notifications/read')
          .set(auth(b.token))
          .send({ ids: ['x'] })
      ).status,
    ).toBe(400);
  });
});
