import { START_BUILDINGS, START_GEMS } from '@tc/shared';
import { describe, expect, it } from 'vitest';
import { FakeClock } from '../src/lib/clock';
import { runMaintenance } from '../src/lib/maintenance';
import { createMemoryRepositories } from '../src/modules/auth/auth.memory';
import { CastleService } from '../src/modules/castle/castle.service';
import { castleServiceSuite, type CastleEnv } from './castle.suite';
import { castleFor, userFor } from './repository.contract';

let n = 0;

castleServiceSuite('in-memory', async (): Promise<CastleEnv> => {
  const repos = createMemoryRepositories();
  const clock = new FakeClock();
  const user = await repos.users.createWithCastle(
    { ...userFor(`Игрок${n++}`, `m${n}@example.com`), createdAt: clock.now() },
    {
      ...castleFor(),
      buildings: START_BUILDINGS,
      resourcesUpdatedAt: clock.now(),
      gems: START_GEMS,
    },
  );
  const service = new CastleService({ repo: repos.castles, clock });
  return {
    service,
    clock,
    userId: user.id,
    async setState(patch) {
      const cur = repos.castles.peek(user.id)!;
      repos.castles.seed({
        ...cur,
        resources: { ...cur.resources, ...patch.resources },
        gems: patch.gems ?? cur.gems,
        levels: { ...cur.levels, ...patch.levels },
        army: patch.army ?? cur.army,
        tech: { ...cur.tech, ...patch.tech },
        hero: patch.hero ?? cur.hero,
        resourcesUpdatedAt: clock.now(),
      });
    },
    async stored() {
      return repos.castles.peek(user.id)!;
    },
    async economy() {
      return repos.castles.economy;
    },
  };
});

describe('уборка устаревших данных', () => {
  it('удаляет истёкшие refresh-токены и старые ключи идемпотентности, свежие оставляет', async () => {
    const repos = createMemoryRepositories();
    const clock = new FakeClock();
    const user = await repos.users.createWithCastle(
      { ...userFor('Уборка', 'u@example.com'), createdAt: clock.now() },
      { ...castleFor(), buildings: START_BUILDINGS, resourcesUpdatedAt: clock.now() },
    );
    const mk = (hash: string, expiresInSec: number) =>
      repos.sessions.create({
        userId: user.id,
        family: 'f',
        tokenHash: hash,
        expiresAt: new Date(clock.now().getTime() + expiresInSec * 1000),
        createdAt: clock.now(),
      });
    await mk('alive', 30 * 3600); // переживёт сдвиг часов на 25 ч
    await mk('dead', -10);
    const service = new CastleService({ repo: repos.castles, clock });
    await service.upgrade(user.id, 'barracks', 'old-maintenance-key');
    clock.advance(25 * 3600);
    await service.upgrade(user.id, 'forge', 'new-maintenance-key').catch(() => undefined);

    const r = await runMaintenance(repos, clock);
    expect(r.sessions).toBe(1);
    expect(r.idempotencyKeys).toBe(1);
    expect(await repos.sessions.findByHash('alive')).not.toBeNull();
    expect(await repos.sessions.findByHash('dead')).toBeNull();
  });
});
