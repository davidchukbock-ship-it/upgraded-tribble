import { describe, expect, it } from 'vitest';
import { DAILY, LOGIN_REWARDS, TUTORIAL, seasonId, type BoosterKey } from '@tc/shared';
import type { FakeClock } from '../src/lib/clock';
import { AppError } from '../src/lib/errors';
import type { UserRepository } from '../src/modules/auth/auth.types';
import type { CastleAggregate, CastleRepository } from '../src/modules/castle/castle.types';
import { CastleService } from '../src/modules/castle/castle.service';
import { ArmyService } from '../src/modules/army/army.service';
import { MarchResolver } from '../src/modules/march/march.resolver';
import { MarchService } from '../src/modules/march/march.service';
import { ChestService } from '../src/modules/progress/chest.service';
import { LeagueService } from '../src/modules/progress/league.service';
import { boostKey, chestKey } from '../src/modules/progress/progress.types';
import { QuestService } from '../src/modules/progress/quest.service';
import { ShopService } from '../src/modules/progress/shop.service';
import { ChatService } from '../src/modules/social/chat.service';
import { GuildService } from '../src/modules/social/guild.service';
import { Hub } from '../src/modules/social/hub';
import { NotificationService } from '../src/modules/social/notification.service';

export interface ProgressWorld {
  repo: CastleRepository;
  users: UserRepository;
  clock: FakeClock;
  addPlayer(name: string): Promise<string>;
  /** Помечает замок как созданный режимом бога (save() этот флаг не пишет). */
  markGod(userId: string): Promise<void>;
}

let seq = 0;
const key = () => `progress-${Date.now()}-${seq++}-abcdef`;

async function fail(p: Promise<unknown>) {
  const err = await p.then(
    () => undefined,
    (e: unknown) => e,
  );
  expect(err).toBeInstanceOf(AppError);
  const e = err as AppError;
  return {
    code: e.code,
    status: e.statusCode,
    details: (e.details ?? {}) as Record<string, unknown>,
  };
}

/** Сценарии заданий, сундуков, магазина и лиг. Гоняются на in-memory и на PostgreSQL (D-24). */
export function progressSuite(name: string, makeWorld: () => Promise<ProgressWorld>): void {
  /** Детерминированный RNG: значения выдаются по очереди, потом повторяется последнее. */
  const seq_ = (...values: number[]) => {
    let i = 0;
    return () => values[Math.min(i++, values.length - 1)]!;
  };

  const setup = async (random: () => number = () => 0) => {
    const w = await makeWorld();
    const hub = new Hub();
    const notifications = new NotificationService({ repo: w.repo, hub });
    const resolver = new MarchResolver({
      repo: w.repo,
      clock: w.clock,
      onNotify: (u, n) => notifications.deliver(u, n),
    });
    const castle = new CastleService({
      repo: w.repo,
      clock: w.clock,
      before: async (u) => void (await resolver.resolveFor(u)),
      onNotify: (u, n) => notifications.deliver(u, n),
    });
    const shared = { repo: w.repo, clock: w.clock };
    const deps = { runner: castle.runner, ...shared };
    const quests = new QuestService(deps);
    const chests = new ChestService({ ...deps, random });
    const shop = new ShopService(deps);
    const leagues = new LeagueService({ ...deps, onNotify: (u, n) => notifications.deliver(u, n) });
    const army = new ArmyService(castle.runner);
    const march = new MarchService(deps);
    const chat = new ChatService({ ...shared, users: w.users, hub, notifications });
    const guilds = new GuildService({ runner: castle.runner, notifications, ...shared });

    const patch = async (userId: string, fn: (a: CastleAggregate) => void) => {
      await w.repo.transaction(async (tx) => {
        const prev = await tx.load(userId, 'main');
        const next = structuredClone(prev!);
        fn(next);
        next.resourcesUpdatedAt = w.clock.now();
        await tx.save(prev!, next);
      });
    };
    const stored = (userId: string) =>
      w.repo.transaction(async (tx) => (await tx.load(userId, 'main'))!);
    const inv = (userId: string) => w.repo.transaction((tx) => tx.progress.inventory(userId));
    const give = (userId: string, k: string, n = 1) =>
      w.repo.transaction((tx) => tx.progress.addItem(userId, k, n));
    const player = async (nick: string) => {
      const id = await w.addPlayer(nick);
      await castle.view(id);
      await patch(id, (a) => {
        a.levels = { ...a.levels, castle: 5, barracks: 3 };
        a.resources = { gold: 50_000, wood: 50_000, stone: 50_000, food: 50_000 };
        a.shieldUntil = null;
      });
      return id;
    };
    const quest = async (userId: string, id: string) => {
      const q = await quests.list(userId);
      return [...q.tutorial, ...q.daily, ...q.achievements].find((x) => x.id === id)!;
    };
    return {
      w,
      castle,
      quests,
      chests,
      shop,
      leagues,
      army,
      march,
      chat,
      guilds,
      resolver,
      notifications,
      patch,
      stored,
      inv,
      give,
      player,
      quest,
      shared,
    };
  };

  describe(`задания: ${name}`, () => {
    it('список: туториал из 10 шагов, 4 ежедневных, достижения, вход', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      const q = await t.quests.list(a);
      expect(q.tutorial).toHaveLength(TUTORIAL.length);
      expect(q.daily.map((d) => d.id)).toEqual(DAILY.map((d) => d.id));
      expect(q.achievements.length).toBeGreaterThan(5);
      expect(q.login).toMatchObject({ day: 1, claimed: false });
      expect(q.login.rewards).toHaveLength(7);
      // Уровень Замка 5 уже даёт достижение a_castle_5
      expect(q.achievements.find((x) => x.id === 'a_castle_5')).toMatchObject({
        claimable: true,
        claimed: false,
      });
      expect(new Date(q.dailyResetAt).getUTCHours()).toBe(0);
    });

    it('улучшение засчитывается, награда выдаётся один раз, повтор с тем же ключом не удваивает', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      expect(await fail(t.quests.claim(a, 't1_upgrade', key()))).toMatchObject({
        code: 'ERR_REQUIREMENT_NOT_MET',
        details: { reason: 'not_done' },
      });
      await t.castle.upgrade(a, 'farm', key());
      expect(await t.quest(a, 't1_upgrade')).toMatchObject({ progress: 1, claimable: true });

      const before = await t.stored(a);
      const k = key();
      const res = await t.quests.claim(a, 't1_upgrade', k);
      expect(res.body.reward).toMatchObject({ gems: 5 });
      expect(res.body.castle.gems).toBe(before.gems + 5);
      const again = await t.quests.claim(a, 't1_upgrade', k);
      expect(again.replayed).toBe(true);
      expect(again.body.castle.gems).toBe(res.body.castle.gems);
      expect((await t.stored(a)).gems).toBe(before.gems + 5);

      expect(await fail(t.quests.claim(a, 't1_upgrade', key()))).toMatchObject({ status: 409 });
      expect(await t.quest(a, 't1_upgrade')).toMatchObject({ claimed: true, claimable: false });
      expect(await fail(t.quests.claim(a, 'nope', key()))).toMatchObject({ status: 404 });
    });

    it('обучение, поход и чат идут в счётчики; туториал ведёт по шагам', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      await t.patch(a, (x) => {
        x.x = 50;
        x.y = 50;
      });
      await t.army.train(a, 'infantry', 1, 10, key());
      expect(await t.quest(a, 't3_train')).toMatchObject({ progress: 10, claimable: true });
      expect(await t.quest(a, 'd_train')).toMatchObject({ progress: 10, claimable: false });
      await t.chat.send(a, 'world', 'привет');
      expect(await t.quest(a, 't8_chat')).toMatchObject({ claimable: true });
      await t.patch(a, (x) => (x.army = { infantry_1: { count: 5, wounded: 0 } }));
      await t.march
        .send(a, { type: 'attack', target: { x: 60, y: 60 }, units: { infantry_1: 1 } }, key())
        .catch(() => undefined);
      // Неудавшийся поход (нет цели) не засчитывается
      expect(await t.quest(a, 't7_march')).toMatchObject({ progress: 0 });
    });

    it('неудавшееся действие не засчитывается (транзакция откатывается)', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      await t.patch(a, (x) => (x.resources = { gold: 0, wood: 0, stone: 0, food: 0 }));
      await fail(t.castle.upgrade(a, 'farm', key()));
      expect(await t.quest(a, 't1_upgrade')).toMatchObject({ progress: 0 });
    });

    it('ежедневные: сбрасываются в 00:00 UTC, награда доступна снова', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      t.w.clock.set(new Date('2026-03-10T12:00:00Z'));
      await t.castle.upgrade(a, 'farm', key());
      const first = await t.quests.claim(a, 'd_upgrade', key());
      expect(first.body.reward.chest).toBe('wooden');
      expect((await t.inv(a))[chestKey('wooden')]).toBe(1);
      expect(await fail(t.quests.claim(a, 'd_upgrade', key()))).toMatchObject({ status: 409 });

      t.w.clock.set(new Date('2026-03-11T00:00:05Z'));
      expect(await t.quest(a, 'd_upgrade')).toMatchObject({ progress: 0, claimed: false });
      // Туториал накопил счётчик за всё время, ежедневное — только за день
      expect(await t.quest(a, 't1_upgrade')).toMatchObject({ progress: 1 });
      await t.castle.upgrade(a, 'sawmill', key());
      await t.quests.claim(a, 'd_upgrade', key());
      expect((await t.inv(a))[chestKey('wooden')]).toBe(2);
    });

    it('достижения по состоянию замка: уровень, мощь, братство', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      expect(await t.quest(a, 'a_castle_5')).toMatchObject({ claimable: true });
      expect(await t.quest(a, 'a_castle_10')).toMatchObject({ claimable: false, progress: 5 });
      const q = await t.quest(a, 'a_power_1k');
      expect(q.progress).toBeGreaterThan(0);
      expect(await t.quest(a, 't9_guild')).toMatchObject({ progress: 0 });
      await t.guilds.create(a, 'Волки Севера', '', key());
      expect(await t.quest(a, 't9_guild')).toMatchObject({ progress: 1, claimable: true });
    });

    it('ежедневный вход: серия 1…7, пропуск дня сбрасывает, после 7-го — заново', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      const day = (n: number) => new Date(Date.UTC(2026, 2, n, 10));
      t.w.clock.set(day(1));
      const r1 = await t.quests.claimLogin(a, key());
      expect(r1.body.reward.resources).toEqual(
        LOGIN_REWARDS[0]!.resources && { gold: 300, wood: 300, stone: 300, food: 300 },
      );
      expect(await fail(t.quests.claimLogin(a, key()))).toMatchObject({ status: 409 });
      expect((await t.quests.list(a)).login).toMatchObject({ day: 1, claimed: true });

      t.w.clock.set(day(2));
      expect((await t.quests.list(a)).login).toMatchObject({ day: 2, claimed: false });
      await t.quests.claimLogin(a, key());
      // Пропуск дня 3 → серия начинается с 1
      t.w.clock.set(day(4));
      expect((await t.quests.list(a)).login.day).toBe(1);
      for (let d = 4; d <= 10; d++) {
        t.w.clock.set(day(d));
        const res = await t.quests.claimLogin(a, key());
        if (d === 10) expect(res.body.reward).toMatchObject({ gems: 20, chest: 'silver' });
      }
      expect((await t.inv(a))[chestKey('silver')]).toBe(1);
      t.w.clock.set(day(11));
      expect((await t.quests.list(a)).login.day).toBe(1);
    });

    it('claimable считает готовые награды и вход', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      const before = (await t.quests.list(a)).claimable;
      expect(before).toBeGreaterThanOrEqual(2); // вход + a_castle_5
      await t.quests.claimLogin(a, key());
      expect((await t.quests.list(a)).claimable).toBe(before - 1);
    });
  });

  describe(`сундуки и ускорители: ${name}`, () => {
    it('нельзя открыть, если сундука нет', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      expect(await fail(t.chests.open(a, 'wooden', key()))).toMatchObject({
        code: 'ERR_REQUIREMENT_NOT_MET',
        details: { reason: 'no_chest' },
      });
    });

    it('ресурсы: пакет по таблице, сундук списывается, открытие пишется в журнал и в задание', async () => {
      const t = await setup(seq_(0));
      const a = await t.player('Alpha');
      await t.give(a, chestKey('wooden'));
      const before = await t.stored(a);
      const res = await t.chests.open(a, 'wooden', key());
      expect(res.body.reward).toEqual({
        type: 'resources',
        resources: { gold: 800, wood: 800, stone: 800, food: 800 },
      });
      expect(res.body.inventory.chests.wooden).toBe(0);
      const after = await t.stored(a);
      expect(after.resources.gold - before.resources.gold).toBeGreaterThanOrEqual(800);
      expect(await t.quest(a, 't10_chest')).toMatchObject({ progress: 1, claimable: true });
    });

    it('кристаллы, ускоритель и экипировка по своим диапазонам', async () => {
      const t = await setup(seq_(0.7, 0.9)); // деревянный: 0.70 → ускоритель, 0.9 → малый
      const a = await t.player('Alpha');
      await t.give(a, chestKey('wooden'), 3);
      const boost = await t.chests.open(a, 'wooden', key());
      expect(boost.body.reward).toEqual({ type: 'booster', booster: 'boost_5m' });
      expect(boost.body.inventory.boosters.boost_5m).toBe(1);

      const t2 = await setup(seq_(0.9, 0.99)); // 0.90 → кристаллы, верх диапазона 5…10
      const b = await t2.player('Beta');
      await t2.give(b, chestKey('wooden'));
      const gems0 = (await t2.stored(b)).gems;
      const g = await t2.chests.open(b, 'wooden', key());
      expect(g.body.reward).toEqual({ type: 'gems', gems: 10 });
      expect((await t2.stored(b)).gems).toBe(gems0 + 10);

      const t3 = await setup(seq_(0.97, 0.5, 0.0, 0.0)); // 0.97 → экипировка редк. 1–3
      const c = await t3.player('Gamma');
      await t3.give(c, chestKey('wooden'));
      const gear = await t3.chests.open(c, 'wooden', key());
      expect(gear.body.reward).toMatchObject({ type: 'gear', rarity: 1 });
      const hero = (await t3.stored(c)).hero!;
      expect(hero.items).toHaveLength(1);
      expect(hero.items[0]).toMatchObject({ equipped: false });
    });

    it('золотой сундук выдаёт редкую экипировку 4–5', async () => {
      const t = await setup(seq_(0.95, 0.1, 0.5, 0.9)); // 0.95 → gear_high (золотой: 90–100%)
      const a = await t.player('Alpha');
      await t.give(a, chestKey('gold'));
      const res = await t.chests.open(a, 'gold', key());
      expect(res.body.reward).toMatchObject({ type: 'gear' });
      const r = res.body.reward as { rarity: number };
      expect([4, 5]).toContain(r.rarity);
    });

    it('повтор с тем же ключом не открывает второй сундук', async () => {
      const t = await setup(seq_(0));
      const a = await t.player('Alpha');
      await t.give(a, chestKey('wooden'), 2);
      const k = key();
      const one = await t.chests.open(a, 'wooden', k);
      const two = await t.chests.open(a, 'wooden', k);
      expect(two.replayed).toBe(true);
      expect(two.body.reward).toEqual(one.body.reward);
      expect((await t.inv(a))[chestKey('wooden')]).toBe(1);
    });

    it('параллельное открытие последнего сундука удаётся ровно один раз', async () => {
      const t = await setup(seq_(0));
      const a = await t.player('Alpha');
      await t.give(a, chestKey('wooden'));
      const results = await Promise.allSettled([
        t.chests.open(a, 'wooden', key()),
        t.chests.open(a, 'wooden', key()),
        t.chests.open(a, 'wooden', key()),
      ]);
      expect(results.filter((r) => r.status === 'fulfilled')).toHaveLength(1);
      expect((await t.inv(a))[chestKey('wooden')] ?? 0).toBe(0);
    });

    it('ускоритель сокращает постройку и расходуется; без него — отказ', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      const up = await t.castle.upgrade(a, 'farm', key());
      const task = up.body.tasks[0]!;
      expect(await fail(t.chests.useBooster(a, 'boost_5m', 'build', task.id, key()))).toMatchObject(
        { details: { reason: 'no_booster' } },
      );
      await t.give(a, boostKey('boost_5m'));
      const used = await t.chests.useBooster(a, 'boost_5m', 'build', task.id, key());
      const left = used.body.castle.tasks[0] ? Date.parse(used.body.castle.tasks[0].finishesAt) : 0;
      const orig = Date.parse(task.finishesAt);
      expect(left === 0 || orig - left === 300_000).toBe(true);
      expect(used.body.inventory.boosters.boost_5m).toBe(0);
      expect(
        await fail(
          t.chests.useBooster(
            a,
            'boost_5m',
            'build',
            'b1b1b1b1-b1b1-41b1-81b1-b1b1b1b1b1b1',
            key(),
          ),
        ),
      ).toMatchObject({ status: 404 });
    });

    it('большой ускоритель завершает короткую постройку сразу', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      const up = await t.castle.upgrade(a, 'farm', key());
      await t.give(a, boostKey('boost_8h' as BoosterKey));
      const used = await t.chests.useBooster(a, 'boost_8h', 'build', up.body.tasks[0]!.id, key());
      expect(used.body.castle.tasks).toHaveLength(0);
      expect((await t.stored(a)).levels.farm).toBe(2);
    });

    it('в цепочке обучения ускоряется только идущая партия', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      const one = await t.army.train(a, 'infantry', 1, 5, key());
      const two = await t.army.train(a, 'infantry', 1, 5, key());
      await t.give(a, boostKey('boost_1h'), 2);
      const ids = two.body.army.queue.map((q) => q.id);
      expect(await fail(t.chests.useBooster(a, 'boost_1h', 'train', ids[1]!, key()))).toMatchObject(
        { details: { reason: 'not_active' } },
      );
      await t.chests.useBooster(a, 'boost_1h', 'train', one.body.army.queue[0]!.id, key());
      expect((await t.stored(a)).army.infantry_1?.count).toBeGreaterThanOrEqual(5);
    });
  });

  describe(`магазин: ${name}`, () => {
    it('каталог: пакеты, ускорители, слот и 10 гербов', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      const shop = await t.shop.catalog(a);
      expect(shop.items.filter((i) => i.kind === 'crest')).toHaveLength(10);
      expect(shop.items.find((i) => i.id === 'slot')).toMatchObject({ price: 250, owned: false });
      expect(shop.gems).toBeGreaterThanOrEqual(0);
    });

    it('покупка пакета: кристаллы списываются, ресурсы начисляются; не хватает — отказ', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      await t.patch(a, (x) => {
        x.gems = 100;
        x.resources = { gold: 0, wood: 0, stone: 0, food: 0 };
      });
      const bought = await t.shop.buy(a, 'pack_s', key());
      expect(bought.body.castle.gems).toBe(80);
      expect((await t.stored(a)).resources.gold).toBeGreaterThanOrEqual(2000);
      expect(await fail(t.shop.buy(a, 'pack_l', key()))).toMatchObject({
        code: 'ERR_INSUFFICIENT_RESOURCES',
        details: { missing: { gems: 350 - 80 } },
      });
      expect(await fail(t.shop.buy(a, 'nope', key()))).toMatchObject({ status: 404 });
    });

    it('повтор покупки с тем же ключом не списывает дважды', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      await t.patch(a, (x) => (x.gems = 100));
      const k = key();
      await t.shop.buy(a, 'boost_1h', k);
      const again = await t.shop.buy(a, 'boost_1h', k);
      expect(again.replayed).toBe(true);
      expect((await t.stored(a)).gems).toBe(75);
      expect((await t.inv(a))[boostKey('boost_1h')]).toBe(1);
    });

    it('второй слот покупается один раз', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      await t.patch(a, (x) => (x.gems = 600));
      const res = await t.shop.buy(a, 'slot', key());
      expect(res.body.castle.slots).toMatchObject({ total: 2, extraUnlocked: true });
      expect(res.body.shop.items.find((i) => i.id === 'slot')?.owned).toBe(true);
      expect(await fail(t.shop.buy(a, 'slot', key()))).toMatchObject({ status: 409 });
      expect((await t.stored(a)).gems).toBe(350);
    });

    it('герб покупается один раз и попадает в инвентарь', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      await t.patch(a, (x) => (x.gems = 200));
      const res = await t.shop.buy(a, 'crest_lion-gold', key());
      expect(res.body.shop.inventory.crests).toEqual(['lion-gold']);
      expect(res.body.castle.gems).toBe(150);
      expect(await fail(t.shop.buy(a, 'crest_lion-gold', key()))).toMatchObject({ status: 409 });
      expect((await t.stored(a)).gems).toBe(150);
    });

    it('реальные деньги: провайдер-заглушка отклоняет', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      expect(await fail(t.shop.checkout(a, 'pack_l'))).toMatchObject({
        status: 403,
        details: { reason: 'payments_disabled' },
      });
    });
  });

  describe(`лиги: ${name}`, () => {
    const setStats = async (
      t: Awaited<ReturnType<typeof setup>>,
      userId: string,
      wins: number,
      kills: number,
    ) => {
      await t.w.repo.transaction((tx) =>
        tx.progress.addSeasonStat(seasonId(t.w.clock.now()), userId, { wins, kills }),
      );
    };

    it('очки = мощь/100 + 50·победы + убийства/10; порядок и фильтры', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      const b = await t.player('Beta');
      const c = await t.player('Gamma');
      await setStats(t, b, 2, 30);
      await setStats(t, c, 1, 0);
      const top = await t.leagues.standings(a, 'top100', 'points');
      expect(top.entries.map((e) => e.nickname)).toEqual(['Beta', 'Gamma', 'Alpha']);
      const beta = top.entries[0]!;
      const alpha = top.entries[2]!;
      expect(beta.value - alpha.value).toBeGreaterThanOrEqual(100 + 3 - 1);
      expect(top.me).toMatchObject({ place: 3 });

      const wins = await t.leagues.standings(a, 'top100', 'wins');
      expect(wins.entries.map((e) => [e.nickname, e.value])).toEqual([
        ['Beta', 2],
        ['Gamma', 1],
        ['Alpha', 0],
      ]);
      const kills = await t.leagues.standings(a, 'top100', 'kills');
      expect(kills.entries[0]).toMatchObject({ nickname: 'Beta', value: 30 });
      const power = await t.leagues.standings(a, 'top100', 'power');
      expect(power.entries).toHaveLength(3);

      const me = await t.leagues.standings(a, 'me', 'points');
      expect(me.entries.some((e) => e.isMe)).toBe(true);
    });

    it('«я» показывает окно ±5 вокруг игрока, «братство» — только соратников', async () => {
      const t = await setup();
      const ids: string[] = [];
      for (let i = 0; i < 14; i++) ids.push(await t.player(`Player${String(i).padStart(2, '0')}`));
      for (const [i, id] of ids.entries()) await setStats(t, id, 14 - i, 0);
      const mid = ids[7]!;
      const me = await t.leagues.standings(mid, 'me', 'wins');
      expect(me.entries).toHaveLength(11);
      expect(me.entries.find((e) => e.isMe)?.place).toBe(8);
      expect(me.entries[0]!.place).toBe(3);

      const noGuild = await t.leagues.standings(mid, 'guild', 'wins');
      expect(noGuild.entries).toEqual([]);
      expect(noGuild.me).not.toBeNull();
      await t.guilds.create(ids[0]!, 'Лига Тест', '', key());
      const leader = ids[0]!;
      const glist = await t.leagues.standings(leader, 'guild', 'wins');
      expect(glist.entries.map((e) => e.userId)).toEqual([leader]);
    });

    it('кэш таблицы: пока не вышел срок, строки не перечитываются', async () => {
      const t = await setup();
      const cached = new LeagueService({ runner: t.castle.runner, ...t.shared, cacheMs: 5000 });
      const a = await t.player('Alpha');
      const b = await t.player('Beta');
      const wins = async () =>
        (await cached.standings(a, 'top100', 'wins')).entries.map((e) => [e.nickname, e.value]);
      expect(await wins()).toEqual([
        ['Alpha', 0],
        ['Beta', 0],
      ]);
      await setStats(t, b, 3, 0);
      expect(await wins()).toEqual([
        ['Alpha', 0],
        ['Beta', 0],
      ]);
      t.w.clock.advance(6);
      expect(await wins()).toEqual([
        ['Beta', 3],
        ['Alpha', 0],
      ]);
    });

    it('замки режима бога не попадают в таблицу', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      const g = await t.player('Godlike');
      await t.w.markGod(g);
      const top = await t.leagues.standings(a, 'top100', 'power');
      expect(top.entries.map((e) => e.nickname)).toEqual(['Alpha']);
    });

    it('победа в бою идёт в сезонную статистику обеих сторон и в задание «выиграть бой»', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      const b = await t.player('Beta');
      await t.patch(a, (x) => {
        x.x = 50;
        x.y = 50;
        x.army = { infantry_3: { count: 300, wounded: 0 } };
      });
      await t.patch(b, (x) => {
        x.x = 53;
        x.y = 50;
        x.army = { infantry_1: { count: 10, wounded: 0 } };
      });
      const sent = await t.march.send(
        a,
        { type: 'attack', target: { x: 53, y: 50 }, units: { infantry_3: 200 } },
        key(),
      );
      const m = sent.body.marches[0]!;
      t.w.clock.set(new Date(Date.parse(m.returnAt) + 1000));
      await t.castle.view(a);
      const wins = await t.leagues.standings(a, 'top100', 'wins');
      const kills = await t.leagues.standings(a, 'top100', 'kills');
      const valueOf = (l: typeof wins, name: string) =>
        l.entries.find((e) => e.nickname === name)?.value;
      const attackerWon = valueOf(wins, 'Alpha') === 1;
      expect(valueOf(wins, attackerWon ? 'Beta' : 'Alpha')).toBe(0);
      expect((valueOf(kills, 'Alpha') ?? 0) + (valueOf(kills, 'Beta') ?? 0)).toBeGreaterThan(0);
      expect(await t.quest(attackerWon ? a : b, 'd_win')).toMatchObject({
        progress: 1,
        claimable: true,
      });
      expect(await t.quest(attackerWon ? a : b, 'a_wins_10')).toMatchObject({ progress: 1 });
    });

    it('закрытие сезона раздаёт призы участникам; забрать можно один раз', async () => {
      const t = await setup();
      t.w.clock.set(new Date('2026-03-11T12:00:00Z')); // среда
      const first = await t.player('Alpha');
      const second = await t.player('Beta');
      const idle = await t.player('Gamma');
      await setStats(t, first, 3, 10);
      await setStats(t, second, 1, 0);
      expect(await t.leagues.closeDue()).toBe(0); // сезон ещё идёт

      t.w.clock.set(new Date('2026-03-16T00:00:30Z')); // следующий понедельник
      expect(await t.leagues.closeDue()).toBe(1);
      expect(await t.leagues.closeDue()).toBe(0); // повторно не закрывается

      const notesA = await t.notifications.list(first, 1, 20);
      expect(notesA.items.some((n) => n.kind === 'season.reward')).toBe(true);
      const idleNotes = await t.notifications.list(idle, 1, 20);
      expect(idleNotes.items.some((n) => n.kind === 'season.reward')).toBe(false);

      const view = await t.leagues.standings(first, 'top100', 'points');
      expect(view.pending).toHaveLength(1);
      expect(view.pending[0]).toMatchObject({ gems: 100, chest: 'gold', place: 1 });

      const gems0 = (await t.stored(first)).gems;
      const claimed = await t.leagues.claim(first, key());
      expect(claimed.body.reward).toMatchObject({ gems: 100, chest: 'gold' });
      expect((await t.stored(first)).gems).toBe(gems0 + 100);
      const items = await t.inv(first);
      expect(items[chestKey('gold')]).toBe(1);
      expect(items[chestKey('wooden')]).toBe(1);
      expect(await fail(t.leagues.claim(first, key()))).toMatchObject({
        details: { reason: 'nothing_to_claim' },
      });

      const bClaim = await t.leagues.claim(second, key());
      expect(bClaim.body.reward).toMatchObject({ gems: 50, chest: 'silver' });
      expect(await fail(t.leagues.claim(idle, key()))).toMatchObject({ status: 422 });
    });
  });
}
