import { describe, expect, it } from 'vitest';
import {
  CHAT_RATE_MAX,
  GUILD_CREATE_COST,
  guildHelpSeconds,
  type WsServerMessage,
} from '@tc/shared';
import type { FakeClock } from '../src/lib/clock';
import { AppError } from '../src/lib/errors';
import type { UserRepository } from '../src/modules/auth/auth.types';
import type { CastleAggregate, CastleRepository } from '../src/modules/castle/castle.types';
import { CastleService } from '../src/modules/castle/castle.service';
import { MarchResolver } from '../src/modules/march/march.resolver';
import { MarchService } from '../src/modules/march/march.service';
import { ChatService } from '../src/modules/social/chat.service';
import { GuildService } from '../src/modules/social/guild.service';
import { Hub } from '../src/modules/social/hub';
import { NotificationService } from '../src/modules/social/notification.service';

export interface SocialWorld {
  repo: CastleRepository;
  users: UserRepository;
  clock: FakeClock;
  addPlayer(name: string, opts?: { guest?: boolean }): Promise<string>;
}

let seq = 0;
const key = () => `social-${Date.now()}-${seq++}-abcdef`;

async function fail(p: Promise<unknown>) {
  const err = await p.then(
    () => undefined,
    (e: unknown) => e,
  );
  expect(err).toBeInstanceOf(AppError);
  const e = err as AppError;
  return {
    code: e.code,
    status: e.statusCode,
    details: (e.details ?? {}) as Record<string, unknown>,
  };
}

/** Сценарии братств, чата и уведомлений. Гоняются на in-memory и на PostgreSQL (D-24). */
export function socialSuite(name: string, makeWorld: () => Promise<SocialWorld>): void {
  const setup = async () => {
    const w = await makeWorld();
    const hub = new Hub();
    const notifications = new NotificationService({ repo: w.repo, hub });
    const resolver = new MarchResolver({
      repo: w.repo,
      clock: w.clock,
      onNotify: (u, n) => notifications.deliver(u, n),
    });
    const castle = new CastleService({
      repo: w.repo,
      clock: w.clock,
      before: async (u) => void (await resolver.resolveFor(u)),
      onNotify: (u, n) => notifications.deliver(u, n),
    });
    const shared = { repo: w.repo, clock: w.clock };
    const guilds = new GuildService({ runner: castle.runner, notifications, ...shared });
    const chat = new ChatService({ ...shared, users: w.users, hub, notifications });
    const patch = async (userId: string, fn: (a: CastleAggregate) => void) => {
      await w.repo.transaction(async (tx) => {
        const prev = await tx.load(userId, 'main');
        const next = structuredClone(prev!);
        fn(next);
        next.resourcesUpdatedAt = w.clock.now();
        await tx.save(prev!, next);
      });
    };
    const stored = (userId: string) =>
      w.repo.transaction(async (tx) => (await tx.load(userId, 'main'))!);
    /** Игрок с Замком 5, золотом и без щита. */
    const player = async (nick: string, opts: { guest?: boolean } = {}) => {
      const id = await w.addPlayer(nick, opts);
      await castle.view(id);
      await patch(id, (a) => {
        a.levels = { ...a.levels, castle: 5 };
        a.resources = { gold: 5000, wood: 5000, stone: 5000, food: 5000 };
        a.shieldUntil = null;
      });
      return id;
    };
    /** Что получил онлайн-клиент игрока. */
    const listen = (userId: string): WsServerMessage[] => {
      const got: WsServerMessage[] = [];
      hub.add(userId, (m) => got.push(m));
      return got;
    };
    const notes = async (userId: string) => (await notifications.list(userId, 1, 50)).items;
    return {
      w,
      hub,
      castle,
      guilds,
      chat,
      notifications,
      resolver,
      patch,
      stored,
      player,
      listen,
      notes,
      shared,
    };
  };

  describe(`братства: ${name}`, () => {
    it('создание: Замок ≥ 5 и 1 000 золота; создатель — глава; золото списывается', async () => {
      const t = await setup();
      const a = await t.w.addPlayer('Alpha');
      await t.castle.view(a);
      expect(await fail(t.guilds.create(a, 'Волки', '', key()))).toMatchObject({
        details: { reason: 'castle_level', required: 5 },
      });
      const b = await t.player('Beta');
      await t.patch(b, (x) => (x.resources = { gold: 500, wood: 0, stone: 0, food: 0 }));
      expect(await fail(t.guilds.create(b, 'Волки', '', key()))).toMatchObject({
        code: 'ERR_INSUFFICIENT_RESOURCES',
      });

      const c = await t.player('Gamma');
      const res = await t.guilds.create(c, 'Волки Севера', 'Мы сильны', key());
      expect(res.body.resources.gold).toBe(5000 - GUILD_CREATE_COST);
      const mine = await t.guilds.mine(c);
      expect(mine.guild).toMatchObject({
        name: 'Волки Севера',
        description: 'Мы сильны',
        level: 1,
        capacity: 22,
        myRole: 'leader',
        members: 1,
        treasury: 0,
      });
      expect(mine.guild?.memberList[0]).toMatchObject({ nickname: 'Gamma', role: 'leader' });
    });

    it('гостям братство недоступно; занятое имя (по ключу) и повторное создание не списывают золото', async () => {
      const t = await setup();
      const guest = await t.player('Guest', { guest: true });
      expect(await fail(t.guilds.create(guest, 'Гостевые', '', key()))).toMatchObject({
        details: { reason: 'guest' },
      });
      expect((await t.stored(guest)).resources.gold).toBe(5000);

      const a = await t.player('Alpha');
      const b = await t.player('Beta');
      await t.guilds.create(a, 'Волки Севера', '', key());
      expect(await fail(t.guilds.create(b, 'волки-севера', '', key()))).toMatchObject({
        code: 'ERR_CONFLICT',
      });
      expect((await t.stored(b)).resources.gold).toBe(5000); // откат: золото на месте
      expect(await fail(t.guilds.create(a, 'Другие', '', key()))).toMatchObject({
        details: { reason: 'already_in_guild' },
      });
      expect((await t.stored(a)).resources.gold).toBe(5000 - GUILD_CREATE_COST);
    });

    it('заявка → уведомление главе → принятие → участник; заявки чистятся', async () => {
      const t = await setup();
      const leader = await t.player('Leader');
      const joiner = await t.player('Joiner');
      const other = await t.player('Other');
      await t.guilds.create(leader, 'Дозор', '', key());
      const gid = (await t.guilds.mine(leader)).guild!.id;
      const leaderInbox = t.listen(leader);
      const joinerInbox = t.listen(joiner);

      await t.guilds.apply(joiner, gid);
      await expect(t.guilds.apply(joiner, gid)).rejects.toMatchObject({ code: 'ERR_CONFLICT' });
      expect((await t.guilds.mine(joiner)).applications).toEqual([
        { guildId: gid, guildName: 'Дозор' },
      ]);
      expect(leaderInbox.find((m) => m.type === 'notification')).toMatchObject({
        notification: {
          kind: 'guild.application',
          payload: { nickname: 'Joiner', guild: 'Дозор' },
        },
      });

      const app = (await t.guilds.mine(leader)).guild!.applications[0]!;
      expect(app.nickname).toBe('Joiner');
      // участник без прав не видит заявки
      await t.guilds.apply(other, gid);
      await t.guilds.decide(leader, app.id, true);
      const asMember = (await t.guilds.mine(joiner)).guild!;
      expect(asMember.myRole).toBe('member');
      expect(asMember.applications).toEqual([]);
      expect(asMember.members).toBe(2);
      expect(
        joinerInbox.find(
          (m) => m.type === 'notification' && m.notification.kind === 'guild.accepted',
        ),
      ).toBeTruthy();
      expect(await fail(t.guilds.apply(joiner, gid))).toMatchObject({
        details: { reason: 'already_in_guild' },
      });

      // заявки стороннего игрока отклоняет офицер/глава
      const pending = (await t.guilds.mine(leader)).guild!.applications;
      expect(pending).toHaveLength(1);
      await t.guilds.decide(leader, pending[0]!.id, false);
      expect((await t.guilds.mine(other)).applications).toEqual([]);
    });

    it('заявку можно отозвать; чужую заявку решить нельзя; участник не решает заявки', async () => {
      const t = await setup();
      const leader = await t.player('Leader');
      const a = await t.player('A');
      const b = await t.player('B');
      await t.guilds.create(leader, 'Дозор', '', key());
      const gid = (await t.guilds.mine(leader)).guild!.id;
      await t.guilds.apply(a, gid);
      await t.guilds.withdraw(a, gid);
      expect(await fail(t.guilds.withdraw(a, gid))).toMatchObject({ status: 404 });
      await t.guilds.apply(a, gid);
      const appId = (await t.guilds.mine(leader)).guild!.applications[0]!.id;
      await t.guilds.decide(leader, appId, true);
      await t.guilds.apply(b, gid);
      const bApp = (await t.guilds.mine(leader)).guild!.applications[0]!.id;
      expect(await fail(t.guilds.decide(a, bApp, true))).toMatchObject({ status: 403 });
      expect(
        await fail(t.guilds.decide(leader, '00000000-0000-4000-8000-000000000000', true)),
      ).toMatchObject({ status: 404 });
    });

    it('роли: глава повышает до офицера; офицер принимает заявки и исключает рядовых, но не офицеров; передача главенства', async () => {
      const t = await setup();
      const leader = await t.player('Leader');
      const off = await t.player('Off');
      const m1 = await t.player('M1');
      const m2 = await t.player('M2');
      await t.guilds.create(leader, 'Дозор', '', key());
      const gid = (await t.guilds.mine(leader)).guild!.id;
      for (const p of [off, m1, m2]) {
        await t.guilds.apply(p, gid);
        const a = (await t.guilds.mine(leader)).guild!.applications.find((x) => x.userId === p)!;
        await t.guilds.decide(leader, a.id, true);
      }
      expect(await fail(t.guilds.setRole(off, m1, 'officer'))).toMatchObject({ status: 403 }); // ещё рядовой
      await t.guilds.setRole(leader, off, 'officer');
      await t.guilds.setRole(leader, m2, 'officer');
      expect(await fail(t.guilds.kick(off, m2))).toMatchObject({ status: 403 }); // офицера офицер не исключает
      const inbox = t.listen(m1);
      await t.guilds.kick(off, m1);
      expect(
        inbox.find((m) => m.type === 'notification' && m.notification.kind === 'guild.kicked'),
      ).toBeTruthy();
      expect((await t.guilds.mine(m1)).guild).toBeNull();
      expect(await fail(t.guilds.kick(off, leader))).toMatchObject({ status: 403 });

      // передача главенства
      expect(await fail(t.guilds.setRole(leader, leader, 'officer'))).toMatchObject({
        details: { reason: 'self' },
      });
      await t.guilds.setRole(leader, off, 'leader');
      const g = (await t.guilds.mine(off)).guild!;
      expect(g.myRole).toBe('leader');
      expect(g.memberList.find((m) => m.userId === leader)?.role).toBe('officer');
    });

    it('выход: глава с соратниками должен передать главенство; последний участник распускает братство', async () => {
      const t = await setup();
      const leader = await t.player('Leader');
      const a = await t.player('A');
      await t.guilds.create(leader, 'Дозор', '', key());
      const gid = (await t.guilds.mine(leader)).guild!.id;
      await t.guilds.apply(a, gid);
      await t.guilds.decide(leader, (await t.guilds.mine(leader)).guild!.applications[0]!.id, true);

      expect(await fail(t.guilds.leave(leader))).toMatchObject({
        details: { reason: 'leader_must_transfer' },
      });
      await t.guilds.leave(a);
      expect((await t.guilds.mine(a)).guild).toBeNull();
      await t.guilds.leave(leader); // остался один → братство распущено
      expect((await t.guilds.list('', 1, 20)).total).toBe(0);
      expect(await fail(t.guilds.leave(leader))).toMatchObject({ details: { reason: 'no_guild' } });
    });

    it('вместимость: при 22 участниках принять нельзя; список ищет по названию', async () => {
      const t = await setup();
      const leader = await t.player('Leader');
      await t.guilds.create(leader, 'Дозор', '', key());
      await t.guilds.create(await t.player('Other'), 'Стража', '', key());
      const gid = (await t.guilds.mine(leader)).guild!.id;
      // набираем 21 участника напрямую в хранилище
      const ids: string[] = [];
      for (let i = 0; i < 21; i++) ids.push(await t.w.addPlayer(`Fill${i}`));
      await t.w.repo.transaction(async (tx) => {
        for (const id of ids) await tx.guilds.addMember(gid, id, 'main', 'member', t.w.clock.now());
      });
      const late = await t.player('Late');
      await t.guilds.apply(late, gid);
      const appId = (await t.guilds.mine(leader)).guild!.applications[0]!.id;
      expect(await fail(t.guilds.decide(leader, appId, true))).toMatchObject({
        details: { reason: 'guild_full' },
      });

      expect((await t.guilds.list('дозор', 1, 20)).items.map((g) => g.name)).toEqual(['Дозор']);
      expect((await t.guilds.list('', 1, 1)).items).toHaveLength(1);
      expect((await t.guilds.list('', 1, 20)).items.find((g) => g.name === 'Дозор')).toMatchObject({
        members: 22,
        leaderName: 'Leader',
      });
    });

    it('казна: взнос списывает золото и повышает уровень братства', async () => {
      const t = await setup();
      const leader = await t.player('Leader');
      await t.guilds.create(leader, 'Дозор', '', key());
      await t.patch(leader, (x) => (x.resources = { gold: 200_000, wood: 0, stone: 0, food: 0 }));
      expect(await fail(t.guilds.donate(leader, 5, key()))).toMatchObject({
        code: 'ERR_VALIDATION',
      });
      const res = await t.guilds.donate(leader, 100_000, key());
      expect(res.body.resources.gold).toBeCloseTo(100_000, 0);
      const g = (await t.guilds.mine(leader)).guild!;
      expect(g.treasury).toBe(100_000);
      expect(g.level).toBe(3);
      expect(g.capacity).toBe(26);
      await t.patch(leader, (x) => (x.resources = { gold: 10, wood: 0, stone: 0, food: 0 }));
      expect(await fail(t.guilds.donate(leader, 100, key()))).toMatchObject({
        code: 'ERR_INSUFFICIENT_RESOURCES',
      });
      expect((await t.guilds.mine(leader)).guild!.treasury).toBe(100_000);

      const loner = await t.player('Loner');
      expect(await fail(t.guilds.donate(loner, 100, key()))).toMatchObject({
        details: { reason: 'no_guild' },
      });
      expect((await t.stored(loner)).resources.gold).toBe(5000);
    });

    it('помощь: стройка соратника заканчивается раньше на max(10 с, 1%); повторно нельзя; посторонним нельзя', async () => {
      const t = await setup();
      const leader = await t.player('Leader');
      const helper = await t.player('Helper');
      const stranger = await t.player('Stranger');
      await t.guilds.create(leader, 'Дозор', '', key());
      const gid = (await t.guilds.mine(leader)).guild!.id;
      await t.guilds.apply(helper, gid);
      await t.guilds.decide(leader, (await t.guilds.mine(leader)).guild!.applications[0]!.id, true);

      const start = t.w.clock.now();
      await t.patch(leader, (x) => {
        x.tasks = [
          {
            id: '11111111-1111-4111-8111-111111111111',
            key: 'barracks',
            toLevel: 1,
            startedAt: start,
            finishesAt: new Date(start.getTime() + 3600_000),
            paid: { gold: 0, wood: 0, stone: 0, food: 0 },
            isGodAction: false,
          },
        ];
      });
      const taskId = '11111111-1111-4111-8111-111111111111';
      const before = (await t.guilds.mine(helper)).guild!.helpRequests[0]!;
      expect(before).toMatchObject({
        nickname: 'Leader',
        building: 'barracks',
        canHelp: true,
        helps: 0,
      });
      expect(before.helpSeconds).toBe(guildHelpSeconds(3600));

      const inbox = t.listen(leader);
      const res = await t.guilds.help(helper, leader, taskId);
      expect(res.seconds).toBe(36);
      const task = (await t.stored(leader)).tasks[0]!;
      expect(task.finishesAt.getTime()).toBe(start.getTime() + (3600 - 36) * 1000);
      expect(
        inbox.find((m) => m.type === 'notification' && m.notification.kind === 'guild.help'),
      ).toMatchObject({
        notification: { payload: { helper: 'Helper', building: 'barracks', seconds: 36 } },
      });
      expect((await t.guilds.mine(helper)).guild!.helpRequests[0]).toMatchObject({
        helps: 1,
        canHelp: false,
      });

      expect(await fail(t.guilds.help(helper, leader, taskId))).toMatchObject({
        code: 'ERR_CONFLICT',
      });
      expect(await fail(t.guilds.help(leader, leader, taskId))).toMatchObject({
        details: { reason: 'self' },
      });
      expect(await fail(t.guilds.help(stranger, leader, taskId))).toMatchObject({
        details: { reason: 'no_guild' },
      });
      expect(
        await fail(t.guilds.help(helper, leader, '22222222-2222-4222-8222-222222222222')),
      ).toMatchObject({ status: 404 });
    });

    it('помощь не опускает срок ниже текущего момента', async () => {
      const t = await setup();
      const leader = await t.player('Leader');
      const helper = await t.player('Helper');
      await t.guilds.create(leader, 'Дозор', '', key());
      await t.guilds.apply(helper, (await t.guilds.mine(leader)).guild!.id);
      await t.guilds.decide(leader, (await t.guilds.mine(leader)).guild!.applications[0]!.id, true);
      const now = t.w.clock.now();
      const taskId = '33333333-3333-4333-8333-333333333333';
      await t.patch(leader, (x) => {
        x.tasks = [
          {
            id: taskId,
            key: 'farm',
            toLevel: 2,
            startedAt: new Date(now.getTime() - 1000_000),
            finishesAt: new Date(now.getTime() + 3000),
            paid: { gold: 0, wood: 0, stone: 0, food: 0 },
            isGodAction: false,
          },
        ];
      });
      await t.guilds.help(helper, leader, taskId);
      expect((await t.stored(leader)).tasks[0]!.finishesAt.getTime()).toBeGreaterThanOrEqual(
        now.getTime(),
      );
    });
  });

  describe(`уведомления: ${name}`, () => {
    it('завершённая стройка при чтении замка даёт уведомление, онлайн-клиент получает его сразу', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      const inbox = t.listen(a);
      await t.castle.runner.mutate(a, 'x', key(), (draft, now) => {
        draft.tasks.push({
          id: '44444444-4444-4444-8444-444444444444',
          key: 'forge',
          toLevel: 1,
          startedAt: now,
          finishesAt: new Date(now.getTime() + 60_000),
          paid: { gold: 0, wood: 0, stone: 0, food: 0 },
          isGodAction: false,
        });
        return [];
      });
      t.w.clock.advance(61);
      await t.castle.view(a);
      const list = await t.notes(a);
      expect(list).toHaveLength(1);
      expect(list[0]).toMatchObject({
        kind: 'build.done',
        payload: { building: 'forge', level: 1 },
        read: false,
      });
      expect(inbox.filter((m) => m.type === 'notification')).toHaveLength(1);
      // повторное чтение не дублирует
      await t.castle.view(a);
      expect(await t.notes(a)).toHaveLength(1);
    });

    it('ускорение за кристаллы завершает стройку и тоже даёт уведомление', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      const inbox = t.listen(a);
      const now = t.w.clock.now();
      await t.patch(a, (x) => {
        x.tasks = [
          {
            id: '88888888-8888-4888-8888-888888888888',
            key: 'forge',
            toLevel: 1,
            startedAt: now,
            finishesAt: new Date(now.getTime() + 600_000),
            paid: { gold: 0, wood: 0, stone: 0, food: 0 },
            isGodAction: false,
          },
        ];
      });
      await t.castle.speedup(a, '88888888-8888-4888-8888-888888888888', key());
      expect((await t.notes(a)).map((n) => n.kind)).toEqual(['build.done']);
      expect(inbox.filter((m) => m.type === 'notification')).toHaveLength(1);
    });

    it('офлайн-игрок: таймер settleDue записывает результат и уведомление, не дублируя', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      await t.patch(a, (x) => {
        x.tasks = [
          {
            id: '55555555-5555-4555-8555-555555555555',
            key: 'farm',
            toLevel: 2,
            startedAt: t.w.clock.now(),
            finishesAt: new Date(t.w.clock.now().getTime() + 30_000),
            paid: { gold: 0, wood: 0, stone: 0, food: 0 },
            isGodAction: false,
          },
        ];
      });
      expect(await t.castle.runner.settleDue()).toBe(0);
      t.w.clock.advance(31);
      expect(await t.castle.runner.settleDue()).toBe(1);
      expect((await t.stored(a)).levels.farm).toBe(2);
      expect((await t.notes(a)).map((n) => n.kind)).toEqual(['build.done']);
      expect(await t.castle.runner.settleDue()).toBe(0);
    });

    it('обучение и исследование тоже дают уведомления', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      const now = t.w.clock.now();
      await t.patch(a, (x) => {
        x.levels = { ...x.levels, barracks: 1, academy: 1 };
        x.trains = [
          {
            id: '66666666-6666-4666-8666-666666666666',
            unit: 'infantry_1',
            count: 5,
            startedAt: now,
            finishesAt: new Date(now.getTime() + 10_000),
            paid: { gold: 0, wood: 0, stone: 0, food: 0 },
            isGodAction: false,
          },
        ];
        x.research = [
          {
            id: '77777777-7777-4777-8777-777777777777',
            tech: 'farming',
            toLevel: 1,
            startedAt: now,
            finishesAt: new Date(now.getTime() + 20_000),
            paid: { gold: 0, wood: 0, stone: 0, food: 0 },
            isGodAction: false,
          },
        ];
      });
      t.w.clock.advance(30);
      await t.castle.view(a);
      expect((await t.notes(a)).map((n) => n.kind).sort()).toEqual(['research.done', 'train.done']);
    });

    it('возвращение похода и нападение на замок дают уведомления', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      const b = await t.player('Beta');
      await t.patch(a, (x) => {
        x.x = 50;
        x.y = 50;
        x.army = { infantry_3: { count: 300, wounded: 0 } };
      });
      await t.patch(b, (x) => {
        x.x = 53;
        x.y = 50;
        x.army = { infantry_1: { count: 10, wounded: 0 } };
      });
      const march = new MarchService({ runner: t.castle.runner, ...t.shared });
      const inboxB = t.listen(b);
      const sent = await march.send(
        a,
        { type: 'attack', target: { x: 53, y: 50 }, units: { infantry_3: 200 } },
        key(),
      );
      const m = sent.body.marches[0]!;
      t.w.clock.set(new Date(Date.parse(m.returnAt) + 1000));
      await t.castle.view(a);
      const noteA = await t.notes(a);
      expect(noteA.map((n) => n.kind)).toContain('march.returned');
      const noteB = await t.notes(b);
      expect(noteB.find((n) => n.kind === 'march.attacked')).toMatchObject({
        payload: { attacker: 'Alpha', won: false },
      });
      expect(
        inboxB.some((x) => x.type === 'notification' && x.notification.kind === 'march.attacked'),
      ).toBe(true);
    });

    it('прочитанные: по списку и все сразу; страницы; чужие не трогаются', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      const b = await t.player('Beta');
      const rows = Array.from({ length: 5 }, (_, i) => ({
        id: `00000000-0000-4000-8000-00000000000${i}`,
        userId: a,
        kind: 'guild.help' as const,
        payload: { n: i },
        read: false,
        createdAt: new Date(t.w.clock.now().getTime() + i * 1000),
      }));
      await t.w.repo.transaction((tx) =>
        tx.notifications.add([
          ...rows,
          { ...rows[0]!, id: '00000000-0000-4000-8000-0000000000ff', userId: b },
        ]),
      );
      const page1 = await t.notifications.list(a, 1, 2);
      expect(page1).toMatchObject({ total: 5, unread: 5, page: 1, pageSize: 2 });
      expect(page1.items.map((n) => n.payload.n)).toEqual([4, 3]); // новые сверху
      expect(await t.notifications.markRead(a, [rows[0]!.id, rows[1]!.id])).toBe(2);
      expect((await t.notifications.list(a, 1, 10)).unread).toBe(3);
      expect(await t.notifications.markRead(a)).toBe(3);
      expect((await t.notifications.list(a, 1, 10)).unread).toBe(0);
      expect((await t.notifications.list(b, 1, 10)).unread).toBe(1);
      expect(await t.notifications.markRead(a)).toBe(0);
    });
  });

  describe(`чат: ${name}`, () => {
    it('мировой чат: сообщение сохраняется, попадает в историю и всем онлайн; брань маскируется', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      const b = await t.player('Beta');
      const inboxB = t.listen(b);
      const sent = await t.chat.send(a, 'world', '  привет,   мир  ');
      t.w.clock.advance(1);
      expect(sent).toMatchObject({ channel: 'world', nickname: 'Alpha', text: 'привет, мир' });
      const masked = await t.chat.send(a, 'world', 'ты мудак');
      expect(masked.text).toBe('ты *****');
      expect(inboxB.filter((m) => m.type === 'chat.message')).toHaveLength(2);
      const history = await t.chat.history(b, 'world');
      expect(history.map((m) => m.text)).toEqual(['привет, мир', 'ты *****']);
    });

    it('проверки: пустой текст, длинный текст, неизвестный канал', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      expect(await fail(t.chat.send(a, 'world', '   '))).toMatchObject({ code: 'ERR_VALIDATION' });
      expect(await fail(t.chat.send(a, 'world', 'x'.repeat(301)))).toMatchObject({
        code: 'ERR_VALIDATION',
      });
      expect(await fail(t.chat.send(a, 'nope', 'hi'))).toMatchObject({ code: 'ERR_VALIDATION' });
      expect(await fail(t.chat.history(a, 'dm:bad'))).toMatchObject({ code: 'ERR_VALIDATION' });
    });

    it('лимит: 5 сообщений за 10 секунд, затем ожидание; через окно можно снова', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      for (let i = 0; i < CHAT_RATE_MAX; i++) await t.chat.send(a, 'world', `m${i}`);
      const blocked = await fail(t.chat.send(a, 'world', 'лишнее'));
      expect(blocked).toMatchObject({ code: 'ERR_RATE_LIMITED', status: 429 });
      expect(blocked.details.retryAfterSeconds).toBeGreaterThan(0);
      t.w.clock.advance(11);
      await expect(t.chat.send(a, 'world', 'снова')).resolves.toBeDefined();
      // другой игрок не задет
      const b = await t.player('Beta');
      await expect(t.chat.send(b, 'world', 'я')).resolves.toBeDefined();
    });

    it('заглушённый игрок не пишет', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      const until = new Date(t.w.clock.now().getTime() + 3600_000);
      await t.w.users.update(a, { mutedUntil: until });
      expect(await fail(t.chat.send(a, 'world', 'hi'))).toMatchObject({
        code: 'ERR_MUTED',
        status: 403,
      });
    });

    it('чат братства: нужен состав; сообщения получают только участники', async () => {
      const t = await setup();
      const leader = await t.player('Leader');
      const member = await t.player('Member');
      const outsider = await t.player('Outsider');
      expect(await fail(t.chat.send(outsider, 'guild', 'hi'))).toMatchObject({
        details: { reason: 'no_guild' },
      });
      await t.guilds.create(leader, 'Дозор', '', key());
      await t.guilds.apply(member, (await t.guilds.mine(leader)).guild!.id);
      await t.guilds.decide(leader, (await t.guilds.mine(leader)).guild!.applications[0]!.id, true);
      const inM = t.listen(member);
      const inO = t.listen(outsider);
      await t.chat.send(leader, 'guild', 'совет в полночь');
      expect(inM.filter((m) => m.type === 'chat.message')).toHaveLength(1);
      expect(inO.filter((m) => m.type === 'chat.message')).toHaveLength(0);
      expect((await t.chat.history(member, 'guild')).map((m) => m.text)).toEqual([
        'совет в полночь',
      ]);
      expect(await fail(t.chat.history(outsider, 'guild'))).toMatchObject({
        details: { reason: 'no_guild' },
      });
    });

    it('личные: оба видят один канал под именем собеседника; посторонний не видит; офлайн-получатель получает уведомление', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      const b = await t.player('Beta');
      const c = await t.player('Gamma');
      const inA = t.listen(a);
      const sent = await t.chat.send(a, `dm:${b}`, 'секрет');
      expect(sent.channel).toBe(`dm:${b}`);
      const bView = await t.chat.history(b, `dm:${a}`);
      expect(bView).toHaveLength(1);
      expect(bView[0]).toMatchObject({ channel: `dm:${a}`, text: 'секрет', nickname: 'Alpha' });
      expect(await t.chat.history(c, `dm:${a}`)).toEqual([]);
      expect(await t.chat.history(c, `dm:${b}`)).toEqual([]);
      expect(inA.some((m) => m.type === 'chat.message')).toBe(true);
      expect((await t.notes(b)).find((n) => n.kind === 'chat.dm')).toMatchObject({
        payload: { from: 'Alpha', text: 'секрет' },
      });

      // если получатель онлайн — записи в уведомлениях нет
      t.listen(b);
      await t.chat.send(a, `dm:${b}`, 'ещё');
      expect((await t.notes(b)).filter((n) => n.kind === 'chat.dm')).toHaveLength(1);

      expect(await fail(t.chat.send(a, `dm:${a}`, 'себе'))).toMatchObject({
        details: { reason: 'self_dm' },
      });
      expect(
        await fail(t.chat.send(a, 'dm:99999999-9999-4999-8999-999999999999', 'x')),
      ).toMatchObject({ status: 404 });
    });

    it('история: не больше 50 последних, старые первыми; before листает назад', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      for (let i = 0; i < 60; i++) {
        await t.w.repo.transaction((tx) =>
          tx.chat.add({
            id: `00000000-0000-4000-8000-${String(i).padStart(12, '0')}`,
            worldId: 'main',
            channel: 'world',
            userId: a,
            text: `m${i}`,
            createdAt: new Date(t.w.clock.now().getTime() + i * 1000),
          }),
        );
      }
      const h = await t.chat.history(a, 'world');
      expect(h).toHaveLength(50);
      expect([h[0]!.text, h[49]!.text]).toEqual(['m10', 'm59']);
      const older = await t.chat.history(a, 'world', new Date(h[0]!.createdAt));
      expect(older.map((m) => m.text)).toEqual(Array.from({ length: 10 }, (_, i) => `m${i}`));
    });

    it('жалобы: на чужое видимое сообщение один раз; на своё, на невидимое и несуществующее нельзя', async () => {
      const t = await setup();
      const a = await t.player('Alpha');
      const b = await t.player('Beta');
      const c = await t.player('Gamma');
      const world = await t.chat.send(a, 'world', 'привет');
      await t.chat.report(b, world.id, 'спам');
      expect(await fail(t.chat.report(b, world.id, 'спам'))).toMatchObject({
        code: 'ERR_CONFLICT',
      });
      expect(await fail(t.chat.report(a, world.id, 'я'))).toMatchObject({
        details: { reason: 'own_message' },
      });
      expect(
        await fail(t.chat.report(b, '00000000-0000-4000-8000-000000000000', 'x')),
      ).toMatchObject({ status: 404 });
      const dm = await t.chat.send(a, `dm:${b}`, 'лично');
      await t.chat.report(b, dm.id, 'оскорбление');
      expect(await fail(t.chat.report(c, dm.id, 'подслушал'))).toMatchObject({ status: 404 });
    });
  });
}
