import type { FastifyInstance } from 'fastify';
import request from 'supertest';
import { afterEach, describe, expect, it } from 'vitest';
import { createMemoryRepositories } from '../src/modules/auth/auth.memory';
import { makeApp } from './helpers';

const HIGH = {
  AUTH_LOGIN_RATE_MAX: '1000',
  AUTH_REGISTER_RATE_MAX: '1000',
  AUTH_GUEST_RATE_MAX: '1000',
};
let app: FastifyInstance | undefined;
afterEach(async () => {
  await app?.close();
  app = undefined;
});

async function boot() {
  const repos = createMemoryRepositories();
  const made = await makeApp({ env: HIGH, deps: { repos } });
  app = made.app;
  const reg = await request(app.server)
    .post('/api/auth/register')
    .send({ email: 'hero@example.com', password: 'Correct horse 42', nickname: 'Артур' });
  return {
    app: made.app,
    repos,
    clock: made.clock,
    token: reg.body.accessToken as string,
    userId: reg.body.user.id as string,
  };
}

let seq = 0;
const idem = () => `realm-api-${Date.now()}-${seq++}`;
const auth = (t: string) => ({ Authorization: `Bearer ${t}` });

describe('GET /api/army, /research, /hero', () => {
  it('требуют входа', async () => {
    const { app: a } = await boot();
    for (const path of ['/api/army', '/api/research', '/api/hero']) {
      expect((await request(a.server).get(path)).status).toBe(401);
    }
  });

  it('отдают свои части состояния замка', async () => {
    const { app: a, token } = await boot();
    const army = await request(a.server).get('/api/army').set(auth(token));
    expect(army.body).toMatchObject({
      count: 0,
      cap: 0,
      maxTier: 0,
      queueMax: 4,
      upkeepPerHour: 0,
      units: [],
    });
    const research = await request(a.server).get('/api/research').set(auth(token));
    expect(research.body.techs).toHaveLength(14);
    expect(research.body.queueMax).toBe(2);
    const hero = await request(a.server).get('/api/hero').set(auth(token));
    expect(hero.body).toMatchObject({ level: 1, skillPoints: 1, xpToNext: 100 });
  });

  it('полный ответ /castle содержит армию, исследования и героя', async () => {
    const { app: a, token } = await boot();
    const c = await request(a.server).get('/api/castle').set(auth(token));
    expect(Object.keys(c.body)).toEqual(expect.arrayContaining(['army', 'research', 'hero']));
  });
});

describe('POST /api/army/train', () => {
  const train = (a: FastifyInstance, token: string, body: unknown, key: string | null = idem()) => {
    const r = request(a.server)
      .post('/api/army/train')
      .set(auth(token))
      .send(body as object);
    return key ? r.set('Idempotency-Key', key) : r;
  };

  it('без Казармы — 422 с причиной', async () => {
    const { app: a, token } = await boot();
    const res = await train(a, token, { type: 'infantry', tier: 1, count: 5 });
    expect(res.status).toBe(422);
    expect(res.body.error).toMatchObject({
      code: 'ERR_REQUIREMENT_NOT_MET',
      details: { reason: 'no_barracks' },
    });
  });

  it.each([
    ['количество 0', { type: 'infantry', tier: 1, count: 0 }],
    ['дробное количество', { type: 'infantry', tier: 1, count: 1.5 }],
    ['гигантское количество', { type: 'infantry', tier: 1, count: 1e9 }],
    ['тир 6', { type: 'infantry', tier: 6, count: 1 }],
    ['неизвестный тип', { type: 'dragon', tier: 1, count: 1 }],
    ['лишнее поле', { type: 'infantry', tier: 1, count: 1, free: true }],
    ['пустое тело', {}],
  ])('400 ERR_VALIDATION: %s', async (_n, body) => {
    const { app: a, token } = await boot();
    const res = await train(a, token, body);
    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe('ERR_VALIDATION');
  });

  it('Idempotency-Key обязателен; без входа — 401', async () => {
    const { app: a, token } = await boot();
    expect((await train(a, token, { type: 'infantry', tier: 1, count: 1 }, null)).status).toBe(400);
    const anon = await request(a.server)
      .post('/api/army/train')
      .set('Idempotency-Key', idem())
      .send({ type: 'infantry', tier: 1, count: 1 });
    expect(anon.status).toBe(401);
  });

  it('с Казармой: партия в очереди, деньги списаны, повтор по ключу — тот же ответ', async () => {
    const { app: a, token, repos, userId } = await boot();
    const castle = repos.castles.peek(userId)!;
    repos.castles.seed({ ...castle, levels: { ...castle.levels, barracks: 1 } });
    const key = idem();
    const first = await train(a, token, { type: 'archer', tier: 1, count: 5 }, key);
    expect(first.status).toBe(200);
    expect(first.body.army.queue).toEqual([
      expect.objectContaining({ unit: 'archer_1', count: 5 }),
    ]);
    expect(first.body.resources.gold).toBe(1000 - 200);
    const again = await train(a, token, { type: 'archer', tier: 1, count: 5 }, key);
    expect(again.headers['idempotent-replay']).toBe('true');
    expect(again.body).toEqual(first.body);
  });

  it('отмена и ускорение: id должен быть UUID', async () => {
    const { app: a, token } = await boot();
    for (const action of ['cancel', 'speedup']) {
      const res = await request(a.server)
        .post(`/api/army/queue/nope/${action}`)
        .set(auth(token))
        .set('Idempotency-Key', idem());
      expect(res.status).toBe(400);
    }
  });
});

describe('исследования и герой по HTTP', () => {
  it('неизвестная технология → 400; без Академии → 422', async () => {
    const { app: a, token } = await boot();
    const bad = await request(a.server)
      .post('/api/research/alchemy/start')
      .set(auth(token))
      .set('Idempotency-Key', idem());
    expect(bad.status).toBe(400);
    const locked = await request(a.server)
      .post('/api/research/farming/start')
      .set(auth(token))
      .set('Idempotency-Key', idem());
    expect(locked.status).toBe(422);
    expect(locked.body.error.details).toMatchObject({ reason: 'academy_level', required: 1 });
  });

  it('герой: вложить очко, потренировать, лишнее очко — отказ', async () => {
    const { app: a, token } = await boot();
    const skill = await request(a.server)
      .post('/api/hero/skills/combat')
      .set(auth(token))
      .set('Idempotency-Key', idem());
    expect(skill.status).toBe(200);
    expect(skill.body.hero.skills.combat).toBe(1);
    const again = await request(a.server)
      .post('/api/hero/skills/economy')
      .set(auth(token))
      .set('Idempotency-Key', idem());
    expect(again.status).toBe(422);
    const trained = await request(a.server)
      .post('/api/hero/train')
      .set(auth(token))
      .set('Idempotency-Key', idem());
    expect(trained.body.hero.xp).toBe(60);
    const unknown = await request(a.server)
      .post('/api/hero/skills/magic')
      .set(auth(token))
      .set('Idempotency-Key', idem());
    expect(unknown.status).toBe(400);
  });

  it('надеть предмет: тело строгое, id — UUID', async () => {
    const { app: a, token } = await boot();
    const r = (body: object) =>
      request(a.server)
        .post('/api/hero/equip')
        .set(auth(token))
        .set('Idempotency-Key', idem())
        .send(body);
    expect((await r({ itemId: 'x' })).status).toBe(400);
    expect((await r({ itemId: '11111111-1111-4111-8111-111111111111', extra: 1 })).status).toBe(
      400,
    );
    expect((await r({ itemId: '11111111-1111-4111-8111-111111111111' })).status).toBe(404);
  });

  it('OpenAPI описывает новые маршруты', async () => {
    const { app: a } = await boot();
    const res = await request(a.server).get('/docs/json');
    expect(Object.keys(res.body.paths)).toEqual(
      expect.arrayContaining([
        '/api/army',
        '/api/army/train',
        '/api/research',
        '/api/research/{key}/start',
        '/api/hero',
        '/api/hero/skills/{key}',
        '/api/hero/equip',
        '/api/hero/train',
      ]),
    );
  });
});
