import { MAP_SIZE } from '@tc/shared';
import type { FastifyInstance } from 'fastify';
import request from 'supertest';
import { afterEach, describe, expect, it } from 'vitest';
import { createMemoryRepositories } from '../src/modules/auth/auth.memory';
import { makeApp } from './helpers';

const HIGH = {
  AUTH_LOGIN_RATE_MAX: '1000',
  AUTH_REGISTER_RATE_MAX: '1000',
  AUTH_GUEST_RATE_MAX: '1000',
};
let app: FastifyInstance | undefined;
afterEach(async () => {
  await app?.close();
  app = undefined;
});

let seq = 0;
const idem = () => `march-api-${Date.now()}-${seq++}`;
const auth = (t: string) => ({ Authorization: `Bearer ${t}` });

async function boot() {
  const repos = createMemoryRepositories();
  const made = await makeApp({ env: HIGH, deps: { repos } });
  app = made.app;
  const player = async (nickname: string, email: string) => {
    const reg = await request(made.app.server)
      .post('/api/auth/register')
      .send({ email, password: 'Correct horse 42', nickname });
    const token = reg.body.accessToken as string;
    const userId = reg.body.user.id as string;
    await request(made.app.server).get('/api/castle').set(auth(token)); // размещение замка
    return { token, userId };
  };
  const a = await player('Артур', 'a@example.com');
  const b = await player('Борис', 'b@example.com');
  // Подготовка: убираем щиты, даём армию и известные места
  const prep = (userId: string, x: number, y: number, army: object) => {
    const cur = repos.castles.peek(userId)!;
    repos.castles.seed({ ...cur, x, y, shieldUntil: null, army: army as typeof cur.army });
  };
  prep(a.userId, 50, 50, {
    infantry_3: { count: 200, wounded: 0 },
    cavalry_1: { count: 5, wounded: 0 },
  });
  prep(b.userId, 53, 50, { infantry_1: { count: 10, wounded: 0 } });
  return { app: made.app, clock: made.clock, repos, a, b };
}

describe('карта, походы и отчёты через HTTP', () => {
  it('всё требует входа', async () => {
    const { app: x } = await boot();
    for (const path of [
      '/api/map/tiles',
      '/api/map/cell/1/1',
      '/api/map/search?q=ab',
      '/api/marches',
      '/api/reports',
    ]) {
      expect((await request(x.server).get(path)).status).toBe(401);
    }
    expect(
      (
        await request(x.server)
          .post('/api/marches')
          .set('Idempotency-Key', idem())
          .send({ type: 'scout', target: { x: 1, y: 1 }, units: { cavalry_1: 1 } })
      ).status,
    ).toBe(401);
  });

  it('карта: тайлы, клетка, поиск; замок игрока отмечен как «мой»', async () => {
    const { app: x, a } = await boot();
    const tiles = await request(x.server)
      .get('/api/map/tiles?x=40&y=40&size=20')
      .set(auth(a.token));
    expect(tiles.status).toBe(200);
    expect(tiles.body).toMatchObject({ x: 40, y: 40, size: 20 });
    expect(tiles.body.cells).toHaveLength(400);
    const mine = tiles.body.cells.find((c: { castle: { isMe: boolean } | null }) => c.castle?.isMe);
    expect(mine).toMatchObject({ x: 50, y: 50, castle: { nickname: 'Артур' } });

    const cell = await request(x.server).get('/api/map/cell/53/50').set(auth(a.token));
    expect(cell.body.castle).toMatchObject({ nickname: 'Борис', isMe: false });
    expect(
      (await request(x.server).get(`/api/map/cell/${MAP_SIZE}/1`).set(auth(a.token))).status,
    ).toBe(400);

    const found = await request(x.server)
      .get('/api/map/search')
      .query({ q: 'бор' })
      .set(auth(a.token));
    expect(found.body).toEqual([{ x: 53, y: 50, nickname: 'Борис' }]);
    expect(
      (await request(x.server).get('/api/map/search').query({ q: '' }).set(auth(a.token))).status,
    ).toBe(400);
  });

  it('поход: ключ идемпотентности обязателен, лишние поля отклоняются, ответ — полный замок с походом', async () => {
    const { app: x, a } = await boot();
    const body = { type: 'attack', target: { x: 53, y: 50 }, units: { infantry_3: 100 } };
    expect(
      (await request(x.server).post('/api/marches').set(auth(a.token)).send(body)).status,
    ).toBe(400);
    expect(
      (
        await request(x.server)
          .post('/api/marches')
          .set(auth(a.token))
          .set('Idempotency-Key', idem())
          .send({ ...body, extra: 1 })
      ).status,
    ).toBe(400);
    const key = idem();
    const ok = await request(x.server)
      .post('/api/marches')
      .set(auth(a.token))
      .set('Idempotency-Key', key)
      .send(body);
    expect(ok.status).toBe(200);
    expect(ok.body.marches).toHaveLength(1);
    expect(ok.body.marches[0]).toMatchObject({
      type: 'attack',
      state: 'outbound',
      targetName: 'Борис',
    });
    expect(ok.body.army.marching).toBe(100);
    expect(ok.body.position).toEqual({ x: 50, y: 50 });

    const replay = await request(x.server)
      .post('/api/marches')
      .set(auth(a.token))
      .set('Idempotency-Key', key)
      .send(body);
    expect(replay.headers['idempotent-replay']).toBe('true');
    const list = await request(x.server).get('/api/marches').set(auth(a.token));
    expect(list.body).toHaveLength(1);
  });

  it('бизнес-ошибки: пустая клетка — 422 с причиной', async () => {
    const { app: x, a } = await boot();
    const send = (target: { x: number; y: number }) =>
      request(x.server)
        .post('/api/marches')
        .set(auth(a.token))
        .set('Idempotency-Key', idem())
        .send({ type: 'attack', target, units: { infantry_3: 1 } });
    const none = await send({ x: 70, y: 70 });
    expect(none.status).toBe(422);
    expect(none.body.error.details).toMatchObject({ reason: 'no_target' });
  });

  it('отчёты: после прибытия появляются у обеих сторон, чтение помечает прочитанным, чужие — 404', async () => {
    const { app: x, clock, a, b } = await boot();
    await request(x.server)
      .post('/api/marches')
      .set(auth(a.token))
      .set('Idempotency-Key', idem())
      .send({ type: 'attack', target: { x: 53, y: 50 }, units: { infantry_3: 100 } });
    clock.advance(600);

    const list = await request(x.server).get('/api/reports').set(auth(a.token));
    expect(list.status).toBe(200);
    expect(list.body).toMatchObject({ total: 1, unread: 1, page: 1 });
    const id = list.body.items[0].id as string;
    const one = await request(x.server).get(`/api/reports/${id}`).set(auth(a.token));
    expect(one.status).toBe(200);
    expect(one.body).toMatchObject({
      kind: 'battle',
      role: 'attacker',
      outcome: 'win',
      opponent: 'Борис',
    });
    expect(one.body.detail.rounds.length).toBeGreaterThan(0);
    expect((await request(x.server).get('/api/reports').set(auth(a.token))).body.unread).toBe(0);

    const theirs = await request(x.server).get('/api/reports').set(auth(b.token));
    expect(theirs.body.items[0]).toMatchObject({
      role: 'defender',
      outcome: 'loss',
      opponent: 'Артур',
    });
    expect((await request(x.server).get(`/api/reports/${id}`).set(auth(b.token))).status).toBe(404);
    expect((await request(x.server).get('/api/reports/not-a-uuid').set(auth(a.token))).status).toBe(
      400,
    );
    expect(
      (await request(x.server).get('/api/reports?pageSize=100').set(auth(a.token))).status,
    ).toBe(400);
  });

  it('лечение через HTTP', async () => {
    const { app: x, a } = await boot();
    const res = await request(x.server)
      .post('/api/army/heal')
      .set(auth(a.token))
      .set('Idempotency-Key', idem())
      .send({ unit: 'infantry_3', count: 1 });
    expect(res.status).toBe(422);
    expect(res.body.error.details).toMatchObject({ reason: 'not_enough_wounded' });
  });

  it('мир на карте v2: море, биомы, дороги в тайлах и коды рельефа в обзоре; мир v1 не меняется', async () => {
    const { app: x, repos, a } = await boot();
    const v1 = await request(x.server).get('/api/map/overview').set(auth(a.token));
    expect(v1.status).toBe(200);
    expect(v1.body.terrain).not.toMatch(/[dsolr]/); // в v1 только p, f, m, w
    const cur = repos.castles.peek(a.userId)!;
    repos.castles.seed({ ...cur, worldMapVersion: 2 });
    const ov = await request(x.server).get('/api/map/overview').set(auth(a.token));
    expect(ov.status).toBe(200);
    expect(ov.body.terrain).toContain('o'); // море
    expect(ov.body.terrain.length).toBe(ov.body.cols * ov.body.cols);
    const tiles = await request(x.server).get('/api/map/tiles?x=0&y=0&size=40').set(auth(a.token));
    expect(tiles.status).toBe(200);
    const kinds = new Set(tiles.body.cells.map((c: { terrain: string }) => c.terrain));
    expect(kinds.has('sea')).toBe(true); // угол карты — океан
    const centre = await request(x.server)
      .get('/api/map/tiles?x=180&y=180&size=40')
      .set(auth(a.token));
    const land = new Set(centre.body.cells.map((c: { terrain: string }) => c.terrain));
    expect(['plain', 'forest'].some((k) => land.has(k))).toBe(true);
    for (const k of [...kinds, ...land])
      expect(['plain', 'forest', 'mountain', 'desert', 'swamp', 'sea', 'lake', 'river']).toContain(
        k,
      );
    // Дорога видна в клетке; обзор при том же seed берётся из кэша и совпадает
    const again = await request(x.server).get('/api/map/overview').set(auth(a.token));
    expect(again.body.terrain).toBe(ov.body.terrain);
  });
});
