import { BUILDING_KEYS } from '@tc/shared';
import type { FastifyInstance } from 'fastify';
import request from 'supertest';
import { afterEach, describe, expect, it } from 'vitest';
import { createMemoryRepositories } from '../src/modules/auth/auth.memory';
import { makeApp } from './helpers';

const HIGH = {
  AUTH_LOGIN_RATE_MAX: '1000',
  AUTH_REGISTER_RATE_MAX: '1000',
  AUTH_GUEST_RATE_MAX: '1000',
};
let app: FastifyInstance | undefined;
afterEach(async () => {
  await app?.close();
  app = undefined;
});

async function boot() {
  const repos = createMemoryRepositories();
  const made = await makeApp({ env: HIGH, deps: { repos } });
  app = made.app;
  const reg = await request(app.server)
    .post('/api/auth/register')
    .send({ email: 'hero@example.com', password: 'Correct horse 42', nickname: 'Артур' });
  return { app: made.app, clock: made.clock, repos, token: reg.body.accessToken as string };
}

let seq = 0;
const idem = () => `api-key-${Date.now()}-${seq++}`;
const auth = (t: string) => ({ Authorization: `Bearer ${t}` });

describe('GET /api/castle', () => {
  it('требует входа', async () => {
    const { app: a } = await boot();
    expect((await request(a.server).get('/api/castle')).status).toBe(401);
  });

  it('отдаёт замок только что зарегистрированного игрока', async () => {
    const { app: a, token } = await boot();
    const res = await request(a.server).get('/api/castle').set(auth(token));
    expect(res.status).toBe(200);
    expect(res.body.resources).toEqual({ gold: 1000, wood: 1000, stone: 1000, food: 1000 });
    expect(res.body.gems).toBe(50);
    expect(res.body.buildings).toHaveLength(BUILDING_KEYS.length);
    expect(res.body.serverTime).toBe('2026-01-01T00:00:00.000Z');
    expect(res.body.slots.total).toBe(1);
  });

  it('время идёт по серверным часам', async () => {
    const { app: a, token, clock } = await boot();
    clock.advance(600); // 10 минут: токен доступа (15 мин) ещё жив
    const res = await request(a.server).get('/api/castle').set(auth(token));
    expect(res.body.resources.gold).toBe(1050);
    expect(res.body.serverTime).toBe('2026-01-01T00:10:00.000Z');
  });

  it('игроки не видят замки друг друга', async () => {
    const { app: a, token } = await boot();
    const other = await request(a.server)
      .post('/api/auth/register')
      .send({ email: 'other@example.com', password: 'Correct horse 42', nickname: 'Другой' });
    await request(a.server)
      .post('/api/castle/buildings/barracks/upgrade')
      .set(auth(other.body.accessToken))
      .set('Idempotency-Key', idem());
    const mine = await request(a.server).get('/api/castle').set(auth(token));
    expect(mine.body.tasks).toHaveLength(0);
    expect(mine.body.resources.gold).toBe(1000);
  });
});

describe('POST /api/castle/buildings/:key/upgrade', () => {
  const up = (a: FastifyInstance, token: string, key = 'barracks', k: string | null = idem()) => {
    const r = request(a.server).post(`/api/castle/buildings/${key}/upgrade`).set(auth(token));
    return k ? r.set('Idempotency-Key', k) : r;
  };

  it('200: стоимость списана, задача в очереди', async () => {
    const { app: a, token } = await boot();
    const res = await up(a, token);
    expect(res.status).toBe(200);
    expect(res.body.resources.gold).toBe(850);
    expect(res.body.tasks).toEqual([expect.objectContaining({ key: 'barracks', toLevel: 1 })]);
  });

  it('Idempotency-Key обязателен и проверяется по формату', async () => {
    const { app: a, token } = await boot();
    const none = await up(a, token, 'barracks', null);
    expect(none.status).toBe(400);
    expect(none.body.error.code).toBe('ERR_VALIDATION');
    expect((await up(a, token, 'barracks', 'short')).status).toBe(400);
    expect((await up(a, token, 'barracks', 'has spaces in it!')).status).toBe(400);
  });

  it('повтор с тем же ключом: тот же ответ, заголовок Idempotent-Replay, списание одно', async () => {
    const { app: a, token } = await boot();
    const k = idem();
    const first = await up(a, token, 'barracks', k);
    const again = await up(a, token, 'barracks', k);
    expect(again.status).toBe(200);
    expect(again.headers['idempotent-replay']).toBe('true');
    expect(first.headers['idempotent-replay']).toBeUndefined();
    expect(again.body).toEqual(first.body);
    const c = await request(a.server).get('/api/castle').set(auth(token));
    expect(c.body.resources.gold).toBe(850);
  });

  it('тот же ключ для другого здания → 422 ERR_IDEMPOTENCY_MISMATCH', async () => {
    const { app: a, token } = await boot();
    const k = idem();
    await up(a, token, 'barracks', k);
    const res = await up(a, token, 'forge', k);
    expect(res.status).toBe(422);
    expect(res.body.error.code).toBe('ERR_IDEMPOTENCY_MISMATCH');
  });

  it('неизвестное здание → 400; без входа → 401', async () => {
    const { app: a, token } = await boot();
    expect((await up(a, token, 'dragon-lair')).status).toBe(400);
    const anon = await request(a.server)
      .post('/api/castle/buildings/farm/upgrade')
      .set('Idempotency-Key', idem());
    expect(anon.status).toBe(401);
  });

  it('очередь полна → 422 ERR_QUEUE_FULL; нехватка ресурсов → 422 с деталями', async () => {
    const { app: a, token } = await boot();
    await up(a, token, 'barracks');
    const full = await up(a, token, 'forge');
    expect(full.status).toBe(422);
    expect(full.body.error.code).toBe('ERR_QUEUE_FULL');
  });

  it('нехватка ресурсов → 422 и список недостающего', async () => {
    const { app: a, token, repos } = await boot();
    const me = await request(a.server).get('/api/auth/me').set(auth(token));
    const castle = repos.castles.peek(me.body.user.id)!;
    repos.castles.seed({ ...castle, resources: { ...castle.resources, gold: 10 } });
    const res = await up(a, token, 'forge');
    expect(res.status).toBe(422);
    expect(res.body.error.code).toBe('ERR_INSUFFICIENT_RESOURCES');
    expect(res.body.error.details.missing).toEqual({ gold: 190 });
  });
});

describe('очередь: ускорение, отмена, слот', () => {
  it('полный цикл: построить → ускорить → уровень вырос', async () => {
    const { app: a, token } = await boot();
    const started = await request(a.server)
      .post('/api/castle/buildings/castle/upgrade')
      .set(auth(token))
      .set('Idempotency-Key', idem());
    const taskId = started.body.tasks[0].id as string;
    const sped = await request(a.server)
      .post(`/api/castle/queue/${taskId}/speedup`)
      .set(auth(token))
      .set('Idempotency-Key', idem());
    expect(sped.status).toBe(200);
    expect(sped.body.gems).toBe(49);
    expect(sped.body.buildings.find((b: { key: string }) => b.key === 'castle').level).toBe(2);
  });

  it('отмена возвращает половину', async () => {
    const { app: a, token } = await boot();
    const started = await request(a.server)
      .post('/api/castle/buildings/barracks/upgrade')
      .set(auth(token))
      .set('Idempotency-Key', idem());
    const res = await request(a.server)
      .post(`/api/castle/queue/${started.body.tasks[0].id}/cancel`)
      .set(auth(token))
      .set('Idempotency-Key', idem());
    expect(res.body.tasks).toHaveLength(0);
    expect(res.body.resources.gold).toBe(1000 - 150 + 75);
  });

  it('id задачи должен быть UUID; чужая/несуществующая → 404', async () => {
    const { app: a, token } = await boot();
    const bad = await request(a.server)
      .post('/api/castle/queue/not-a-uuid/speedup')
      .set(auth(token))
      .set('Idempotency-Key', idem());
    expect(bad.status).toBe(400);
    const missing = await request(a.server)
      .post('/api/castle/queue/00000000-0000-4000-8000-000000000000/cancel')
      .set(auth(token))
      .set('Idempotency-Key', idem());
    expect(missing.status).toBe(404);
  });

  it('второй слот: 50 кристаллов не хватает на 250 → 422', async () => {
    const { app: a, token } = await boot();
    const res = await request(a.server)
      .post('/api/castle/slots/unlock')
      .set(auth(token))
      .set('Idempotency-Key', idem());
    expect(res.status).toBe(422);
    expect(res.body.error.code).toBe('ERR_INSUFFICIENT_RESOURCES');
    expect(res.body.error.details.missing.gems).toBe(200);
  });
});

describe('документация', () => {
  it('OpenAPI содержит маршруты замка', async () => {
    const { app: a } = await boot();
    const res = await request(a.server).get('/docs/json');
    expect(Object.keys(res.body.paths)).toEqual(
      expect.arrayContaining([
        '/api/castle',
        '/api/castle/buildings/{key}/upgrade',
        '/api/castle/queue/{taskId}/speedup',
        '/api/castle/queue/{taskId}/cancel',
        '/api/castle/slots/unlock',
      ]),
    );
  });
});
