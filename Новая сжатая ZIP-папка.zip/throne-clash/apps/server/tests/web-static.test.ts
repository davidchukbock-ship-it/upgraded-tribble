import { mkdirSync, mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import helmet from '@fastify/helmet';
import Fastify from 'fastify';
import { describe, expect, it } from 'vitest';
import { registerWeb } from '../src/web-static';

async function build(withIndex = true) {
  const dir = mkdtempSync(join(tmpdir(), 'tc-web-'));
  if (withIndex) {
    mkdirSync(join(dir, 'assets'));
    writeFileSync(join(dir, 'index.html'), '<!doctype html><title>Throne</title>');
    writeFileSync(join(dir, 'assets', 'app-1.js'), 'console.log(1)');
  }
  const app = Fastify();
  await app.register(helmet, { contentSecurityPolicy: { directives: { defaultSrc: ["'none'"] } } });
  app.get('/health', async () => ({ ok: true }));
  const served = await registerWeb(app, dir);
  return { app, served };
}

describe('раздача сайта сервером (без nginx)', () => {
  it('не включается, если каталога с index.html нет', async () => {
    const { served } = await build(false);
    expect(served).toBe(false);
  });

  it('отдаёт index.html на корне и на адресах приложения, ассеты кэшируются', async () => {
    const { app } = await build();
    const root = await app.inject({ url: '/' });
    expect(root.statusCode).toBe(200);
    expect(root.body).toContain('Throne');
    expect(root.headers['cache-control']).toBe('no-cache');
    const deep = await app.inject({ url: '/castle?x=1' });
    expect(deep.statusCode).toBe(200);
    expect(deep.body).toContain('Throne');
    const asset = await app.inject({ url: '/assets/app-1.js' });
    expect(asset.statusCode).toBe(200);
    expect(asset.headers['cache-control']).toContain('immutable');
  });

  it('для страниц заменяет строгую политику API своей; API и 404 не подменяются', async () => {
    const { app } = await build();
    const page = await app.inject({ url: '/' });
    expect(page.headers['content-security-policy']).toBeUndefined();
    expect(String(page.headers['content-security-policy-report-only'])).toContain(
      "default-src 'self'",
    );
    const health = await app.inject({ url: '/health' });
    expect(health.json()).toEqual({ ok: true });
    const missingApi = await app.inject({ url: '/api/nope' });
    expect(missingApi.statusCode).toBe(404);
    expect(missingApi.headers['content-type']).toContain('application/json');
    const post = await app.inject({ method: 'POST', url: '/castle' });
    expect(post.statusCode).toBe(404);
  });
});
