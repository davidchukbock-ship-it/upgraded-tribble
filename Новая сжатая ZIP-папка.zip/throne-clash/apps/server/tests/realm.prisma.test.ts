import { PrismaClient } from '@prisma/client';
import { afterAll, beforeEach, describe } from 'vitest';
import { BUILDING_KEYS, START_BUILDINGS, START_GEMS } from '@tc/shared';
import { ensureMainWorld } from '../src/db/bootstrap';
import { FakeClock } from '../src/lib/clock';
import { createPrismaRepositories } from '../src/modules/auth/auth.repository';
import { PrismaCastleRepository } from '../src/modules/castle/castle.repository';
import { CastleService } from '../src/modules/castle/castle.service';
import type { CastleEnv } from './castle.suite';
import { realmSuite } from './realm.suite';
import { castleFor, userFor } from './repository.contract';
import { resetTables, testDatabaseUrl } from './test-db';

const url = testDatabaseUrl();

describe.runIf(url)('армия, исследования, герой на PostgreSQL', () => {
  const db = new PrismaClient({ datasourceUrl: url });
  const repos = createPrismaRepositories(db);
  let n = 0;

  beforeEach(async () => {
    await resetTables(db, [
      'IdempotencyKey',
      'EconomyEvent',
      'BuildTask',
      'TrainTask',
      'ResearchTask',
      'ArmyUnit',
      'TechLevel',
      'HeroItem',
      'Hero',
      'SecurityLog',
      'RefreshToken',
      'Building',
      'Castle',
      'User',
    ]);
    await ensureMainWorld(db, 1);
  });
  afterAll(() => db.$disconnect());

  realmSuite('PostgreSQL', async (): Promise<CastleEnv> => {
    const clock = new FakeClock();
    const user = await repos.users.createWithCastle(
      { ...userFor(`Игрок${n++}`, `p${n}@example.com`), createdAt: clock.now() },
      {
        ...castleFor(),
        buildings: START_BUILDINGS,
        resourcesUpdatedAt: clock.now(),
        gems: START_GEMS,
      },
    );
    const service = new CastleService({ repo: new PrismaCastleRepository(db), clock });
    const castle = await db.castle.findFirstOrThrow({ where: { userId: user.id } });
    return {
      service,
      clock,
      userId: user.id,
      async setState(patch) {
        await db.castle.update({
          where: { id: castle.id },
          data: {
            ...patch.resources,
            ...(patch.gems !== undefined ? { gems: patch.gems } : {}),
            resourcesUpdatedAt: clock.now(),
          },
        });
        for (const [unitId, s] of Object.entries(patch.army ?? {})) {
          await db.armyUnit.upsert({
            where: { castleId_unitId: { castleId: castle.id, unitId } },
            update: { count: s.count, wounded: s.wounded },
            create: { castleId: castle.id, unitId, count: s.count, wounded: s.wounded },
          });
        }
        for (const [tech, level] of Object.entries(patch.tech ?? {})) {
          await db.techLevel.upsert({
            where: { castleId_tech: { castleId: castle.id, tech } },
            update: { level },
            create: { castleId: castle.id, tech, level },
          });
        }
        if (patch.hero) {
          const h = patch.hero;
          const data = {
            level: h.level,
            xp: h.xp,
            skillCombat: h.skills.combat,
            skillDefense: h.skills.defense,
            skillEconomy: h.skills.economy,
          };
          await db.hero.upsert({
            where: { castleId: castle.id },
            update: data,
            create: { castleId: castle.id, ...data },
          });
          await db.heroItem.deleteMany({ where: { castleId: castle.id } });
          for (const i of h.items) {
            await db.heroItem.create({
              data: {
                id: i.id,
                castleId: castle.id,
                slot: i.slot,
                rarity: i.rarity,
                equipped: i.equipped,
              },
            });
          }
        }
        for (const key of BUILDING_KEYS) {
          const level = patch.levels?.[key];
          if (level === undefined) continue;
          await db.building.upsert({
            where: { castleId_key: { castleId: castle.id, key } },
            update: { level },
            create: { castleId: castle.id, key, level },
          });
        }
      },
      async stored() {
        const repo = new PrismaCastleRepository(db);
        const agg = await repo.transaction((tx) => tx.load(user.id, 'main'));
        return agg!;
      },
      async economy() {
        const rows = await db.economyEvent.findMany({ where: { userId: user.id } });
        return rows.map((r) => ({ ...r, resource: r.resource as 'gold' }));
      },
    };
  });
});
