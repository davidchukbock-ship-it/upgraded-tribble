import type { FastifyInstance } from 'fastify';
import request from 'supertest';
import { afterEach, describe, expect, it } from 'vitest';
import { DONATE_PACKS, START_GEMS, donateTotal } from '@tc/shared';
import { loadConfig } from '../src/config/env';
import { createMemoryRepositories } from '../src/modules/auth/auth.memory';
import { makeApp, testConfig } from './helpers';

const HIGH = {
  AUTH_LOGIN_RATE_MAX: '1000',
  AUTH_REGISTER_RATE_MAX: '1000',
  AUTH_GUEST_RATE_MAX: '1000',
};
let app: FastifyInstance | undefined;
afterEach(async () => {
  await app?.close();
  app = undefined;
});

let seq = 0;
const idem = () => `donate-${Date.now()}-${seq++}-xyz`;
const auth = (t: string) => ({ Authorization: `Bearer ${t}` });

async function boot(mode?: 'off' | 'test') {
  const repos = createMemoryRepositories();
  const made = await makeApp({
    env: { ...HIGH, ...(mode ? { PAYMENTS_MODE: mode } : {}) },
    deps: { repos },
  });
  app = made.app;
  const reg = await request(made.app.server)
    .post('/api/auth/register')
    .send({ email: 'd@example.com', password: 'Correct horse 42', nickname: 'Донатор' });
  return {
    server: made.app.server,
    token: reg.body.accessToken as string,
    repos,
    userId: reg.body.user.id as string,
  };
}

describe('магазин донатов (D-62)', () => {
  it('каталог требует входа и по умолчанию показывает режим «off»', async () => {
    const { server, token } = await boot();
    expect((await request(server).get('/api/donate')).status).toBe(401);
    const res = await request(server).get('/api/donate').set(auth(token));
    expect(res.status).toBe(200);
    expect(res.body.mode).toBe('off');
    expect(res.body.gems).toBe(START_GEMS);
    expect(res.body.packs).toHaveLength(DONATE_PACKS.length);
    expect(res.body.packs[0]).toMatchObject({ id: 'gems_s', total: 80 });
    expect(res.body.packs.find((p: { tag?: string }) => p.tag === 'best')).toBeTruthy();
  });

  it('пока оплата выключена, купить нельзя: 403 payments_disabled, кристаллы не меняются', async () => {
    const { server, token } = await boot('off');
    const res = await request(server)
      .post('/api/donate/buy')
      .set(auth(token))
      .set('Idempotency-Key', idem())
      .send({ packId: 'gems_m' });
    expect(res.status).toBe(403);
    expect(res.body.error.details).toMatchObject({ reason: 'payments_disabled' });
    const after = await request(server).get('/api/donate').set(auth(token));
    expect(after.body.gems).toBe(START_GEMS);
  });

  it('тестовый режим начисляет пакет целиком, пишет в журнал экономики и повтор по ключу не удваивает', async () => {
    const { server, token, repos, userId } = await boot('test');
    const pack = DONATE_PACKS.find((p) => p.id === 'gems_l')!;
    const key = idem();
    const one = await request(server)
      .post('/api/donate/buy')
      .set(auth(token))
      .set('Idempotency-Key', key)
      .send({ packId: pack.id });
    expect(one.status).toBe(200);
    expect(one.body.granted).toBe(donateTotal(pack));
    expect(one.body.castle.gems).toBe(START_GEMS + donateTotal(pack));

    const again = await request(server)
      .post('/api/donate/buy')
      .set(auth(token))
      .set('Idempotency-Key', key)
      .send({ packId: pack.id });
    expect(again.status).toBe(200);
    expect(again.body.castle.gems).toBe(START_GEMS + donateTotal(pack));
    expect(repos.castles.peek(userId)!.gems).toBe(START_GEMS + donateTotal(pack));

    const events = repos.castles.economy;
    expect(events.filter((e) => e.kind === 'donate_test')).toEqual([
      expect.objectContaining({ amount: donateTotal(pack), resource: 'gems' }),
    ]);
  });

  it('неизвестный пакет — 404, лишние поля в теле — 400, без ключа идемпотентности — 400', async () => {
    const { server, token } = await boot('test');
    const post = (body: object, key: string | null = idem()) => {
      const r = request(server).post('/api/donate/buy').set(auth(token));
      return (key ? r.set('Idempotency-Key', key) : r).send(body);
    };
    expect((await post({ packId: 'nope' })).status).toBe(404);
    expect((await post({ packId: 'gems_s', gems: 999999 })).status).toBe(400);
    expect((await post({ packId: 'gems_s' }, null)).status).toBe(400);
  });

  it('тестовые платежи запрещены в production; цены пакетов целые, а крупные пакеты выгоднее', () => {
    const base = {
      NODE_ENV: 'production',
      JWT_ACCESS_SECRET: 'x'.repeat(40),
      DATABASE_URL: 'postgresql://u:p@h/db',
    };
    expect(() => loadConfig({ ...base, PAYMENTS_MODE: 'test' })).toThrow(/PAYMENTS_MODE/);
    expect(loadConfig({ ...base, PAYMENTS_MODE: 'off' }).paymentsMode).toBe('off');
    expect(testConfig().paymentsMode).toBe('off');
    const rate = (p: (typeof DONATE_PACKS)[number]) => donateTotal(p) / p.usdCents;
    for (const p of DONATE_PACKS) {
      expect(Number.isInteger(p.usdCents)).toBe(true);
    }
    expect(rate(DONATE_PACKS.at(-1)!)).toBeGreaterThan(rate(DONATE_PACKS[0]!));
  });
});
