import request from 'supertest';
import type { FastifyInstance } from 'fastify';
import { afterEach, describe, expect, it } from 'vitest';
import { z } from 'zod';
import type { ZodTypeProvider } from 'fastify-type-provider-zod';
import { Errors } from '../src/lib/errors';
import { makeApp } from './helpers';

let app: FastifyInstance | undefined;
afterEach(async () => {
  await app?.close();
  app = undefined;
});

describe('/health', () => {
  it('200 и статус ok, когда БД и Redis доступны; время сервера в UTC', async () => {
    ({ app } = await makeApp());
    const res = await request(app.server).get('/health');
    expect(res.status).toBe(200);
    expect(res.body).toMatchObject({
      status: 'ok',
      checks: { db: 'up', redis: 'up' },
      serverTime: '2026-01-01T00:00:00.000Z',
    });
  });

  it('503 и degraded, если зависимость упала; причина наружу не уходит', async () => {
    ({ app } = await makeApp({
      deps: {
        probes: [
          { name: 'db', check: async () => undefined },
          {
            name: 'redis',
            check: async () => {
              throw new Error('ECONNREFUSED 10.0.0.5:6379 secret-host');
            },
          },
        ],
      },
    }));
    const res = await request(app.server).get('/health');
    expect(res.status).toBe(503);
    expect(res.body.status).toBe('degraded');
    expect(res.body.checks).toEqual({ db: 'up', redis: 'down' });
    expect(JSON.stringify(res.body)).not.toContain('secret-host');
  });

  it('зависший пробник не подвешивает ответ (таймаут)', async () => {
    ({ app } = await makeApp({
      deps: { probes: [{ name: 'db', check: () => new Promise<void>(() => undefined) }] },
    }));
    const started = Date.now();
    const res = await request(app.server).get('/health');
    expect(res.status).toBe(503);
    expect(Date.now() - started).toBeLessThan(4000);
  });
});

describe('единый формат ошибок', () => {
  const routes = (a: FastifyInstance) => {
    a.post('/echo', async (req) => req.body);
    a.get('/boom', async () => {
      throw new Error('connect ECONNREFUSED db.internal:5432 password=hunter2');
    });
    a.get('/game-error', async () => {
      throw Errors.insufficientResources({ missing: { gold: 50 } });
    });
    a.withTypeProvider<ZodTypeProvider>().post(
      '/typed',
      { schema: { body: z.object({ count: z.number().int().min(1).max(10) }) } },
      async (req) => ({ count: req.body.count }),
    );
  };

  it('404 несуществующего маршрута', async () => {
    ({ app } = await makeApp());
    const res = await request(app.server).get('/api/nope');
    expect(res.status).toBe(404);
    expect(res.body).toMatchObject({ error: { code: 'ERR_NOT_FOUND' } });
    expect(res.body.requestId).toBe(res.headers['x-request-id']);
  });

  it('битый JSON -> 400 ERR_VALIDATION, без утечки внутренностей', async () => {
    ({ app } = await makeApp({ routes }));
    const res = await request(app.server)
      .post('/echo')
      .set('Content-Type', 'application/json')
      .send('{oops');
    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe('ERR_VALIDATION');
    expect(JSON.stringify(res.body)).not.toMatch(/stack|node_modules/i);
  });

  it('необработанная ошибка -> 500 ERR_INTERNAL, текст исключения клиенту не уходит', async () => {
    ({ app } = await makeApp({ routes }));
    const res = await request(app.server).get('/boom');
    expect(res.status).toBe(500);
    expect(res.body.error).toEqual({ code: 'ERR_INTERNAL', message: 'Internal server error' });
    expect(JSON.stringify(res.body)).not.toMatch(/hunter2|db\.internal|ECONNREFUSED/);
  });

  it('ожидаемая ошибка игры -> свой код и статус, детали сохраняются', async () => {
    ({ app } = await makeApp({ routes }));
    const res = await request(app.server).get('/game-error');
    expect(res.status).toBe(422);
    expect(res.body.error).toMatchObject({
      code: 'ERR_INSUFFICIENT_RESOURCES',
      details: { missing: { gold: 50 } },
    });
  });

  it('Zod-валидация тела: плохое значение -> 400 с путём поля', async () => {
    ({ app } = await makeApp({ routes }));
    const bad = await request(app.server).post('/typed').send({ count: 99 });
    expect(bad.status).toBe(400);
    expect(bad.body.error.code).toBe('ERR_VALIDATION');
    expect(JSON.stringify(bad.body.error.details)).toContain('count');
    const notInt = await request(app.server).post('/typed').send({ count: 1.5 });
    expect(notInt.status).toBe(400);
    const ok = await request(app.server).post('/typed').send({ count: 3 });
    expect(ok.status).toBe(200);
    expect(ok.body).toEqual({ count: 3 });
  });

  it('слишком большое тело отклоняется', async () => {
    ({ app } = await makeApp({ routes }));
    const res = await request(app.server)
      .post('/echo')
      .set('Content-Type', 'application/json')
      .send(JSON.stringify({ pad: 'a'.repeat(70_000) }));
    expect(res.status).toBe(413);
    expect(res.body.error.code).toBe('ERR_VALIDATION');
  });
});

describe('безопасность', () => {
  it('заголовки Helmet и отсутствие X-Powered-By', async () => {
    ({ app } = await makeApp());
    const res = await request(app.server).get('/health');
    expect(res.headers['x-powered-by']).toBeUndefined();
    expect(res.headers['x-content-type-options']).toBe('nosniff');
    expect(res.headers['content-security-policy']).toContain("default-src 'none'");
    expect(res.headers['strict-transport-security']).toBeDefined();
    expect(res.headers['x-frame-options']).toBeDefined();
  });

  it('CORS: разрешённый origin получает заголовки с credentials, чужой — нет', async () => {
    ({ app } = await makeApp({ env: { CORS_ORIGIN: 'https://game.example' } }));
    const ok = await request(app.server).get('/health').set('Origin', 'https://game.example');
    expect(ok.headers['access-control-allow-origin']).toBe('https://game.example');
    expect(ok.headers['access-control-allow-credentials']).toBe('true');
    const evil = await request(app.server).get('/health').set('Origin', 'https://evil.example');
    expect(evil.headers['access-control-allow-origin']).toBeUndefined();
  });

  it('preflight разрешает нужные заголовки (Idempotency-Key, X-CSRF-Token)', async () => {
    ({ app } = await makeApp({ env: { CORS_ORIGIN: 'https://game.example' } }));
    const res = await request(app.server)
      .options('/health')
      .set('Origin', 'https://game.example')
      .set('Access-Control-Request-Method', 'POST')
      .set('Access-Control-Request-Headers', 'idempotency-key,x-csrf-token,authorization');
    expect(res.status).toBe(204);
    expect(res.headers['access-control-allow-headers']?.toLowerCase()).toContain('idempotency-key');
    expect(res.headers['access-control-allow-headers']?.toLowerCase()).toContain('x-csrf-token');
  });

  it('rate limit: после лимита 429 ERR_RATE_LIMITED и Retry-After; /health в лимит не входит', async () => {
    ({ app } = await makeApp({
      env: { RATE_LIMIT_MAX: '3' },
      routes: (a) => a.get('/limited', async () => ({ ok: true })),
    }));
    for (let i = 0; i < 3; i++)
      expect((await request(app.server).get('/limited')).status).toBe(200);
    const blocked = await request(app.server).get('/limited');
    expect(blocked.status).toBe(429);
    expect(blocked.body.error.code).toBe('ERR_RATE_LIMITED');
    expect(blocked.headers['retry-after']).toBeDefined();
    for (let i = 0; i < 10; i++)
      expect((await request(app.server).get('/health')).status).toBe(200);
  });

  it('входящий X-Request-Id принимается только в безопасном формате', async () => {
    ({ app } = await makeApp());
    const good = await request(app.server).get('/health').set('X-Request-Id', 'req-12345678');
    expect(good.headers['x-request-id']).toBe('req-12345678');
    const bad = await request(app.server)
      .get('/health')
      .set('X-Request-Id', '<script>alert(1)</script>');
    expect(bad.headers['x-request-id']).toMatch(/^[0-9a-f-]{36}$/);
  });

  it('в каждом ответе есть X-Server-Time (для синхронизации таймеров клиента)', async () => {
    ({ app } = await makeApp());
    const res = await request(app.server).get('/health');
    expect(res.headers['x-server-time']).toBe('2026-01-01T00:00:00.000Z');
  });
});

describe('Swagger', () => {
  it('в разработке /docs/json отдаёт OpenAPI с /health', async () => {
    ({ app } = await makeApp());
    const res = await request(app.server).get('/docs/json');
    expect(res.status).toBe(200);
    expect(res.body.openapi).toMatch(/^3\./);
    expect(res.body.paths['/health']).toBeDefined();
  });
  it('в production по умолчанию выключен', async () => {
    ({ app } = await makeApp({
      env: { NODE_ENV: 'production', JWT_ACCESS_SECRET: 'x'.repeat(40) },
    }));
    const res = await request(app.server).get('/docs/json');
    expect(res.status).toBe(404);
  });
});
