import { createMemoryRepositories } from '../src/modules/auth/auth.memory';
import { repositoryContract } from './repository.contract';

repositoryContract('in-memory', async () => createMemoryRepositories());
