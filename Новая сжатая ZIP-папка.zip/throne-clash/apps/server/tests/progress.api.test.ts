import type { FastifyInstance } from 'fastify';
import request from 'supertest';
import { afterEach, describe, expect, it } from 'vitest';
import { createMemoryRepositories } from '../src/modules/auth/auth.memory';
import { boostKey, chestKey } from '../src/modules/progress/progress.types';
import { makeApp } from './helpers';

const HIGH = {
  AUTH_LOGIN_RATE_MAX: '1000',
  AUTH_REGISTER_RATE_MAX: '1000',
  AUTH_GUEST_RATE_MAX: '1000',
};
let app: FastifyInstance | undefined;
afterEach(async () => {
  await app?.close();
  app = undefined;
});

let seq = 0;
const idem = () => `progress-api-${Date.now()}-${seq++}`;
const auth = (t: string) => ({ Authorization: `Bearer ${t}` });

async function boot() {
  const repos = createMemoryRepositories();
  const made = await makeApp({ env: HIGH, deps: { repos } });
  app = made.app;
  const reg = await request(made.app.server)
    .post('/api/auth/register')
    .send({ email: 'a@example.com', password: 'Correct horse 42', nickname: 'Артур' });
  const token = reg.body.accessToken as string;
  const userId = reg.body.user.id as string;
  await request(made.app.server).get('/api/castle').set(auth(token));
  const cur = repos.castles.peek(userId)!;
  repos.castles.seed({ ...cur, levels: { ...cur.levels, castle: 5 }, shieldUntil: null });
  return { app: made.app, clock: made.clock, repos, token, userId };
}

describe('задания, сундуки, магазин и лиги через HTTP', () => {
  it('всё, кроме таблицы шансов, требует входа', async () => {
    const { app: x } = await boot();
    for (const path of ['/api/quests', '/api/inventory', '/api/shop', '/api/leagues/current']) {
      expect((await request(x.server).get(path)).status).toBe(401);
    }
    for (const path of [
      '/api/quests/t1_upgrade/claim',
      '/api/daily/claim',
      '/api/chests/wooden/open',
      '/api/leagues/rewards/claim',
    ]) {
      expect((await request(x.server).post(path).set('Idempotency-Key', idem())).status).toBe(401);
    }
    expect(
      (
        await request(x.server)
          .post('/api/shop/buy')
          .set('Idempotency-Key', idem())
          .send({ itemId: 'pack_s' })
      ).status,
    ).toBe(401);
    const odds = await request(x.server).get('/api/chests/odds');
    expect(odds.status).toBe(200);
    expect(odds.body).toHaveLength(3);
    for (const row of odds.body) {
      const total = Object.values(row.odds as Record<string, number>).reduce((s, v) => s + v, 0);
      expect(total).toBe(100);
    }
    expect(odds.body[0]).toMatchObject({ kind: 'wooden', odds: { resources: 60, gear_high: 0 } });
  });

  it('задания: список, награда за вход и за задание, повтор ключа', async () => {
    const { app: x, token } = await boot();
    const list = await request(x.server).get('/api/quests').set(auth(token));
    expect(list.status).toBe(200);
    expect(list.body.tutorial).toHaveLength(10);
    expect(list.body.login).toMatchObject({ day: 1, claimed: false });

    const k = idem();
    const login = await request(x.server)
      .post('/api/daily/claim')
      .set(auth(token))
      .set('Idempotency-Key', k);
    expect(login.status).toBe(200);
    expect(login.body.reward.resources).toMatchObject({ gold: 300 });
    const replay = await request(x.server)
      .post('/api/daily/claim')
      .set(auth(token))
      .set('Idempotency-Key', k);
    expect(replay.headers['idempotent-replay']).toBe('true');
    expect(
      (
        await request(x.server)
          .post('/api/daily/claim')
          .set(auth(token))
          .set('Idempotency-Key', idem())
      ).status,
    ).toBe(409);

    const notDone = await request(x.server)
      .post('/api/quests/t1_upgrade/claim')
      .set(auth(token))
      .set('Idempotency-Key', idem());
    expect(notDone.status).toBe(422);
    expect(
      (
        await request(x.server)
          .post('/api/quests/nope/claim')
          .set(auth(token))
          .set('Idempotency-Key', idem())
      ).status,
    ).toBe(404);
    expect(
      (await request(x.server).post('/api/quests/t1_upgrade/claim').set(auth(token))).status,
    ).toBe(400);

    await request(x.server)
      .post('/api/castle/buildings/farm/upgrade')
      .set(auth(token))
      .set('Idempotency-Key', idem());
    const done = await request(x.server)
      .post('/api/quests/t1_upgrade/claim')
      .set(auth(token))
      .set('Idempotency-Key', idem());
    expect(done.status).toBe(200);
    expect(done.body.reward.gems).toBe(5);
    expect(done.body.castle.gems).toBeGreaterThan(0);
  });

  it('сундук: открытие, инвентарь, неверный вид', async () => {
    const { app: x, repos, token, userId } = await boot();
    const none = await request(x.server)
      .post('/api/chests/wooden/open')
      .set(auth(token))
      .set('Idempotency-Key', idem());
    expect(none.status).toBe(422);
    await repos.castles.progress.addItem(userId, chestKey('wooden'), 1);
    expect(
      (await request(x.server).get('/api/inventory').set(auth(token))).body.chests.wooden,
    ).toBe(1);
    const opened = await request(x.server)
      .post('/api/chests/wooden/open')
      .set(auth(token))
      .set('Idempotency-Key', idem());
    expect(opened.status).toBe(200);
    expect(['resources', 'booster', 'gems', 'gear']).toContain(opened.body.reward.type);
    expect(opened.body.inventory.chests.wooden).toBe(0);
    expect(
      (
        await request(x.server)
          .post('/api/chests/diamond/open')
          .set(auth(token))
          .set('Idempotency-Key', idem())
      ).status,
    ).toBe(400);
  });

  it('ускоритель: валидация тела и применение', async () => {
    const { app: x, repos, token, userId } = await boot();
    const up = await request(x.server)
      .post('/api/castle/buildings/farm/upgrade')
      .set(auth(token))
      .set('Idempotency-Key', idem());
    const taskId = up.body.tasks[0].id as string;
    const use = (body: object) =>
      request(x.server)
        .post('/api/inventory/boosters/use')
        .set(auth(token))
        .set('Idempotency-Key', idem())
        .send(body);
    expect((await use({ booster: 'boost_5m', target: 'build', taskId, extra: 1 })).status).toBe(
      400,
    );
    expect((await use({ booster: 'nope', target: 'build', taskId })).status).toBe(400);
    expect((await use({ booster: 'boost_5m', target: 'build', taskId })).status).toBe(422);
    await repos.castles.progress.addItem(userId, boostKey('boost_8h'), 1);
    const ok = await use({ booster: 'boost_8h', target: 'build', taskId });
    expect(ok.status).toBe(200);
    expect(ok.body.castle.tasks).toHaveLength(0);
    expect(ok.body.inventory.boosters.boost_8h).toBe(0);
  });

  it('магазин: каталог, покупка, недостаток кристаллов, реальные деньги отклонены', async () => {
    const { app: x, repos, token, userId } = await boot();
    const shop = await request(x.server).get('/api/shop').set(auth(token));
    expect(shop.status).toBe(200);
    expect(shop.body.items.some((i: { id: string }) => i.id === 'crest_wolf-night')).toBe(true);

    const buy = (itemId: string) =>
      request(x.server)
        .post('/api/shop/buy')
        .set(auth(token))
        .set('Idempotency-Key', idem())
        .send({ itemId });
    const cur = repos.castles.peek(userId)!;
    repos.castles.seed({ ...cur, gems: 30 });
    const ok = await buy('boost_1h');
    expect(ok.status).toBe(200);
    expect(ok.body.castle.gems).toBe(5);
    expect(ok.body.shop.inventory.boosters.boost_1h).toBe(1);
    expect((await buy('pack_l')).status).toBe(422);
    expect((await buy('nope')).status).toBe(404);
    expect(
      (
        await request(x.server)
          .post('/api/shop/buy')
          .set(auth(token))
          .set('Idempotency-Key', idem())
          .send({ itemId: 'x', more: 1 })
      ).status,
    ).toBe(400);

    const pay = await request(x.server)
      .post('/api/shop/checkout')
      .set(auth(token))
      .send({ packId: 'pack_l' });
    expect(pay.status).toBe(403);
    expect(pay.body.error.details).toMatchObject({ reason: 'payments_disabled' });
  });

  it('премиум-герб: выбрать можно только купленный', async () => {
    const { app: x, repos, token, userId } = await boot();
    const set = (crest: string) =>
      request(x.server).patch('/api/profile').set(auth(token)).send({ crest });
    const denied = await set('lion-gold');
    expect(denied.status).toBe(422);
    expect(denied.body.error.details).toMatchObject({ reason: 'crest_not_owned' });
    expect((await set('wolf')).status).toBe(200);
    expect((await set('nonexistent')).status).toBe(400);

    const cur = repos.castles.peek(userId)!;
    repos.castles.seed({ ...cur, gems: 100 });
    await request(x.server)
      .post('/api/shop/buy')
      .set(auth(token))
      .set('Idempotency-Key', idem())
      .send({ itemId: 'crest_lion-gold' });
    const ok = await set('lion-gold');
    expect(ok.status).toBe(200);
    expect(ok.body.user.crest).toBe('lion-gold');
  });

  it('лига: фильтры, валидация запроса, забрать нечего', async () => {
    const { app: x, token } = await boot();
    const league = await request(x.server).get('/api/leagues/current').set(auth(token));
    expect(league.status).toBe(200);
    expect(league.body).toMatchObject({ metric: 'points', scope: 'top100' });
    expect(league.body.entries).toMatchObject([{ nickname: 'Артур', isMe: true, place: 1 }]);
    expect(
      (
        await request(x.server)
          .get('/api/leagues/current')
          .query({ scope: 'me', metric: 'wins' })
          .set(auth(token))
      ).status,
    ).toBe(200);
    expect(
      (
        await request(x.server)
          .get('/api/leagues/current')
          .query({ scope: 'nope' })
          .set(auth(token))
      ).status,
    ).toBe(400);
    const claim = await request(x.server)
      .post('/api/leagues/rewards/claim')
      .set(auth(token))
      .set('Idempotency-Key', idem());
    expect(claim.status).toBe(422);
  });
});
