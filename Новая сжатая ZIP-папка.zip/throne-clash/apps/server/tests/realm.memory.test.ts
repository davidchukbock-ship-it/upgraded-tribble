import { START_BUILDINGS, START_GEMS } from '@tc/shared';
import { FakeClock } from '../src/lib/clock';
import { createMemoryRepositories } from '../src/modules/auth/auth.memory';
import { CastleService } from '../src/modules/castle/castle.service';
import type { CastleEnv } from './castle.suite';
import { castleFor, userFor } from './repository.contract';
import { realmSuite } from './realm.suite';

let n = 0;

realmSuite('in-memory', async (): Promise<CastleEnv> => {
  const repos = createMemoryRepositories();
  const clock = new FakeClock();
  const user = await repos.users.createWithCastle(
    { ...userFor(`Realm${n++}`, `r${n}@example.com`), createdAt: clock.now() },
    {
      ...castleFor(),
      buildings: START_BUILDINGS,
      resourcesUpdatedAt: clock.now(),
      gems: START_GEMS,
    },
  );
  const service = new CastleService({ repo: repos.castles, clock });
  return {
    service,
    clock,
    userId: user.id,
    async setState(patch) {
      const cur = repos.castles.peek(user.id)!;
      repos.castles.seed({
        ...cur,
        resources: { ...cur.resources, ...patch.resources },
        gems: patch.gems ?? cur.gems,
        levels: { ...cur.levels, ...patch.levels },
        army: patch.army ?? cur.army,
        tech: { ...cur.tech, ...patch.tech },
        hero: patch.hero ?? cur.hero,
        resourcesUpdatedAt: clock.now(),
      });
    },
    async stored() {
      return repos.castles.peek(user.id)!;
    },
    async economy() {
      return repos.castles.economy;
    },
  };
});
