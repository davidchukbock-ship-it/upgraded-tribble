import type { FastifyInstance } from 'fastify';
import { buildApp, type AppDeps } from '../src/app';
import { loadConfig, type AppConfig } from '../src/config/env';
import { FakeClock } from '../src/lib/clock';
import { createMemoryRepositories } from '../src/modules/auth/auth.memory';
import type { Probe } from '../src/modules/health/health.service';

export const okProbes: Probe[] = [
  { name: 'db', check: async () => undefined },
  { name: 'redis', check: async () => undefined },
];

export function testConfig(over: Record<string, string> = {}): AppConfig {
  return loadConfig({ NODE_ENV: 'test', ...over });
}

export async function makeApp(
  over: {
    env?: Record<string, string>;
    deps?: Partial<AppDeps>;
    /** Тестовые маршруты: регистрируются до запуска приложения (после ready() Fastify их не примет). */
    routes?: (app: FastifyInstance) => void;
  } = {},
): Promise<{ app: FastifyInstance; clock: FakeClock }> {
  const clock = new FakeClock();
  const app = await buildApp(testConfig(over.env), {
    clock,
    probes: okProbes,
    repos: createMemoryRepositories(),
    ...over.deps,
  });
  over.routes?.(app);
  await app.ready();
  return { app, clock };
}
