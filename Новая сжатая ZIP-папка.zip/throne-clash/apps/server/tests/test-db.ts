/**
 * Адрес тестовой БД. Тесты очищают таблицы, поэтому берём только явный TEST_DATABASE_URL
 * (или DATABASE_URL в CI, где БД одноразовая) — обычную DATABASE_URL разработчика не трогаем.
 */
export function testDatabaseUrl(): string | undefined {
  return (
    process.env['TEST_DATABASE_URL'] ??
    (process.env['CI'] ? process.env['DATABASE_URL'] : undefined)
  );
}

export const isMysql = (): boolean => (testDatabaseUrl() ?? '').startsWith('mysql:');

/** Схема Prisma для миграций тестовой БД: основная (PostgreSQL) или prisma/mysql/schema.prisma. */
export const schemaArgs = (): string[] =>
  isMysql() ? ['--schema', 'prisma/mysql/schema.prisma'] : [];

interface RawTx {
  $executeRawUnsafe(sql: string): Promise<number>;
  $queryRawUnsafe<T = unknown>(sql: string): Promise<T>;
}
interface RawDb extends RawTx {
  $transaction<T>(fn: (tx: RawTx) => Promise<T>): Promise<T>;
}

/**
 * Очищает таблицы между тестами. В PostgreSQL CASCADE сам добирается до зависимых таблиц; в MySQL каскада
 * у TRUNCATE нет, поэтому там чистятся все таблицы схемы, кроме служебной таблицы миграций и мира (его чистит только seed-тест).
 */
export async function resetTables(db: RawDb, tables: string[]): Promise<void> {
  if (isMysql()) {
    // Внешние ключи отключаются на одном соединении, поэтому всё — в одной транзакции
    await db.$transaction(async (tx) => {
      const all = await tx.$queryRawUnsafe<Array<{ name: string }>>(
        "SELECT table_name AS name FROM information_schema.tables WHERE table_schema = DATABASE() AND table_type = 'BASE TABLE' AND table_name <> '_prisma_migrations'",
      );
      await tx.$executeRawUnsafe('SET FOREIGN_KEY_CHECKS = 0');
      for (const t of all.filter((x) => x.name !== 'World' || tables.includes('World')))
        await tx.$executeRawUnsafe(`TRUNCATE TABLE \`${t.name}\``);
      await tx.$executeRawUnsafe('SET FOREIGN_KEY_CHECKS = 1');
    });
    return;
  }
  const list = tables.map((t) => `"${t}"`).join(',');
  await db.$executeRawUnsafe(`TRUNCATE ${list} RESTART IDENTITY CASCADE`);
}
