import { describe, expect, it } from 'vitest';
import {
  HERO_TRAIN_XP,
  START_RESOURCES,
  academyLevelFor,
  heroTrainCost,
  newHero,
  techCost,
  techSeconds,
  trainCost,
  trainSeconds,
  unitStats,
  type HeroState,
} from '@tc/shared';
import { AppError } from '../src/lib/errors';
import { ArmyService } from '../src/modules/army/army.service';
import { HeroService } from '../src/modules/hero/hero.service';
import { ResearchService } from '../src/modules/research/research.service';
import type { CastleEnv } from './castle.suite';

let seq = 0;
const key = () => `realm-${Date.now()}-${seq++}-abcdef`;
const HOUR = 3600;
const RICH = { gold: 3000, wood: 3000, stone: 3000, food: 3000 };

async function fail(
  p: Promise<unknown>,
): Promise<{ code: string; status: number; details: Record<string, unknown> }> {
  const err = await p.then(
    () => undefined,
    (e: unknown) => e,
  );
  expect(err).toBeInstanceOf(AppError);
  const e = err as AppError;
  return {
    code: e.code,
    status: e.statusCode,
    details: (e.details ?? {}) as Record<string, unknown>,
  };
}

/**
 * Сценарии армии, исследований и героя. Гоняются на in-memory и на PostgreSQL (D-24).
 */
export function realmSuite(name: string, make: () => Promise<CastleEnv>): void {
  const setup = async (state: Parameters<CastleEnv['setState']>[0] = {}) => {
    const env = await make();
    await env.setState({ resources: RICH, ...state });
    return {
      env,
      army: new ArmyService(env.service.runner),
      research: new ResearchService(env.service.runner),
      hero: new HeroService(env.service.runner),
    };
  };

  describe(`армия: ${name}`, () => {
    it('без Казармы обучение недоступно', async () => {
      const { env, army } = await setup();
      expect(await fail(army.train(env.userId, 'infantry', 1, 10, key()))).toMatchObject({
        code: 'ERR_REQUIREMENT_NOT_MET',
        details: { reason: 'no_barracks' },
      });
    });

    it('партия оплачивается сразу, идёт по формуле времени и пополняет армию по завершении', async () => {
      const { env, army } = await setup({ levels: { barracks: 1 } });
      const res = await army.train(env.userId, 'infantry', 1, 10, key());
      const cost = trainCost('infantry', 1, 10);
      expect(res.body.resources.gold).toBe(RICH.gold - cost.gold);
      expect(res.body.army.queue).toHaveLength(1);
      expect(res.body.army.queued).toBe(10);
      const seconds = trainSeconds('infantry', 1, 10, 1);
      const task = res.body.army.queue[0]!;
      expect(Date.parse(task.finishesAt) - Date.parse(task.startedAt)).toBe(seconds * 1000);

      env.clock.advance(seconds + 1);
      const after = await env.service.view(env.userId);
      expect(after.army.queue).toHaveLength(0);
      expect(after.army.units).toEqual([{ id: 'infantry_1', count: 10, wounded: 0 }]);
      expect(after.army.upkeepPerHour).toBe(10);
      expect((await env.stored()).army['infantry_1']?.count).toBe(10);
    });

    it('содержание армии уменьшает прирост еды', async () => {
      const { env } = await setup({
        levels: { barracks: 1 },
        army: { infantry_1: { count: 100, wounded: 0 } },
        resources: { ...RICH, food: 0 },
      });
      env.clock.advance(HOUR);
      const c = await env.service.view(env.userId);
      expect(c.resources.food).toBeCloseTo(400 - 100, 3);
      expect(c.ratesPerHour.food).toBe(400); // валовая ставка; содержание показано отдельно
      expect(c.army.upkeepPerHour).toBe(100);
    });

    it('тир открывается уровнем Казармы: тир 2 — с 5-го', async () => {
      const { env, army } = await setup({ levels: { barracks: 4 } });
      expect(await fail(army.train(env.userId, 'archer', 2, 1, key()))).toMatchObject({
        details: { reason: 'tier_locked', required: 5 },
      });
      await env.setState({ levels: { barracks: 5 } });
      await expect(army.train(env.userId, 'archer', 2, 1, key())).resolves.toBeDefined();
    });

    it('лимит армии 100 + 150·L учитывает и тех, кто в очереди', async () => {
      const { env, army } = await setup({
        levels: { barracks: 1 },
        army: { infantry_1: { count: 200, wounded: 0 } },
        resources: { gold: 100_000, wood: 100_000, stone: 0, food: 100_000 },
      });
      await army.train(env.userId, 'infantry', 1, 40, key()); // 240 из 250
      const e = await fail(army.train(env.userId, 'infantry', 1, 11, key()));
      expect(e.details).toMatchObject({ reason: 'army_cap', cap: 250, free: 10 });
      await expect(army.train(env.userId, 'infantry', 1, 10, key())).resolves.toBeDefined();
    });

    it('нехватка ресурсов: что именно не хватает; ничего не списано', async () => {
      const { env, army } = await setup({
        levels: { barracks: 1 },
        resources: { gold: 100, wood: 1000, stone: 0, food: 1000 },
      });
      const e = await fail(army.train(env.userId, 'infantry', 1, 10, key()));
      expect(e).toMatchObject({ code: 'ERR_INSUFFICIENT_RESOURCES', status: 422 });
      expect((e.details as { missing: Record<string, number> }).missing.gold).toBe(200);
      expect((await env.stored()).resources.gold).toBe(100);
    });

    it('очередь — 4 партии подряд; каждая начинается, когда кончилась предыдущая', async () => {
      const { env, army } = await setup({ levels: { barracks: 1 } });
      for (let i = 0; i < 4; i++) await army.train(env.userId, 'infantry', 1, 5, key());
      expect(await fail(army.train(env.userId, 'infantry', 1, 5, key()))).toMatchObject({
        code: 'ERR_QUEUE_FULL',
      });
      const q = (await env.service.view(env.userId)).army.queue;
      expect(q).toHaveLength(4);
      for (let i = 1; i < 4; i++) expect(q[i]!.startedAt).toBe(q[i - 1]!.finishesAt);
    });

    it('партии выходят по очереди: спустя время первой в строю только она', async () => {
      const { env, army } = await setup({ levels: { barracks: 1 } });
      await army.train(env.userId, 'infantry', 1, 5, key());
      await army.train(env.userId, 'archer', 1, 5, key());
      env.clock.advance(trainSeconds('infantry', 1, 5, 1) + 1);
      const c = await env.service.view(env.userId);
      expect(c.army.units.map((u) => u.id)).toEqual(['infantry_1']);
      expect(c.army.queue).toHaveLength(1);
    });

    it('отмена возвращает 50%, а следующие партии подтягиваются вперёд', async () => {
      const { env, army } = await setup({ levels: { barracks: 1 } });
      const a = (await army.train(env.userId, 'infantry', 1, 10, key())).body.army.queue[0]!;
      await army.train(env.userId, 'archer', 1, 10, key());
      const before = (await env.service.view(env.userId)).army.queue[1]!;
      const res = await army.cancel(env.userId, a.id, key());
      const cost = trainCost('infantry', 1, 10);
      expect(res.body.army.queue).toHaveLength(1);
      expect(res.body.resources.gold).toBe(
        RICH.gold - cost.gold - trainCost('archer', 1, 10).gold + Math.floor(cost.gold / 2),
      );
      const moved = res.body.army.queue[0]!;
      expect(Date.parse(moved.finishesAt)).toBeLessThan(Date.parse(before.finishesAt));
      expect(Date.parse(moved.finishesAt) - Date.parse(moved.startedAt)).toBe(
        Date.parse(before.finishesAt) - Date.parse(before.startedAt), // длительность партии не меняется
      );
      expect(moved.startedAt).toBe(res.body.serverTime); // теперь она идущая
    });

    it('ускорение — только идущей партии, за кристаллы; следующая стартует сразу', async () => {
      const { env, army } = await setup({ levels: { barracks: 1 } });
      const first = (await army.train(env.userId, 'infantry', 1, 10, key())).body.army.queue[0]!;
      const second = (await army.train(env.userId, 'archer', 1, 10, key())).body.army.queue[1]!;
      expect(second.speedupGems).toBeNull();
      expect(await fail(army.speedup(env.userId, second.id, key()))).toMatchObject({
        details: { reason: 'not_active' },
      });
      const res = await army.speedup(env.userId, first.id, key());
      expect(res.body.gems).toBe(50 - first.speedupGems!);
      expect(res.body.army.units).toEqual([{ id: 'infantry_1', count: 10, wounded: 0 }]);
      expect(res.body.army.queue).toHaveLength(1);
      expect(res.body.army.queue[0]!.startedAt).toBe(res.body.serverTime);
    });

    it('Муштра сокращает время обучения', async () => {
      const { env, army } = await setup({ levels: { barracks: 1 }, tech: { drill: 5 } });
      const task = (await army.train(env.userId, 'infantry', 1, 10, key())).body.army.queue[0]!;
      const seconds = (Date.parse(task.finishesAt) - Date.parse(task.startedAt)) / 1000;
      expect(seconds).toBe(trainSeconds('infantry', 1, 10, 1, 0.15));
      expect(seconds).toBeLessThan(trainSeconds('infantry', 1, 10, 1));
    });

    it('повтор запроса с тем же ключом не списывает дважды', async () => {
      const { env, army } = await setup({ levels: { barracks: 1 } });
      const k = key();
      const a = await army.train(env.userId, 'infantry', 1, 10, k);
      const b = await army.train(env.userId, 'infantry', 1, 10, k);
      expect(b.replayed).toBe(true);
      expect(b.body).toEqual(a.body);
      expect((await env.stored()).trains).toHaveLength(1);
    });

    it('7 одновременных постановок: ровно 4 в очереди, ресурсы списаны 4 раза', async () => {
      const { env, army } = await setup({ levels: { barracks: 1 } });
      const results = await Promise.allSettled(
        Array.from({ length: 7 }, () => army.train(env.userId, 'infantry', 1, 5, key())),
      );
      expect(results.filter((r) => r.status === 'fulfilled')).toHaveLength(4);
      for (const r of results)
        if (r.status === 'rejected') expect((r.reason as AppError).code).toBe('ERR_QUEUE_FULL');
      const stored = await env.stored();
      expect(stored.trains).toHaveLength(4);
      expect(stored.resources.gold).toBe(RICH.gold - 4 * trainCost('infantry', 1, 5).gold);
    });
  });

  describe(`исследования: ${name}`, () => {
    it('без Академии нужного уровня технология заблокирована', async () => {
      const { env, research } = await setup();
      const c = await env.service.view(env.userId);
      expect(c.research.techs.find((t) => t.key === 'farming')).toMatchObject({
        blocked: 'academy_level',
        academyRequired: 1,
      });
      expect(await fail(research.start(env.userId, 'farming', key()))).toMatchObject({
        details: { reason: 'academy_level', required: 1 },
      });
    });

    it('исследование оплачивается, идёт по времени и даёт эффект после завершения', async () => {
      const { env, research } = await setup({ levels: { academy: 1 } });
      const res = await research.start(env.userId, 'farming', key());
      const cost = techCost('farming', 1);
      expect(res.body.resources.gold).toBe(RICH.gold - cost.gold);
      expect(res.body.resources.wood).toBe(RICH.wood - cost.wood);
      const task = res.body.research.queue[0]!;
      expect(task).toMatchObject({ tech: 'farming', toLevel: 1 });
      expect(res.body.ratesPerHour.food).toBe(400); // пока не готово — без бонуса

      env.clock.advance(techSeconds('farming', 1) + 1);
      const done = await env.service.view(env.userId);
      expect(done.research.queue).toHaveLength(0);
      expect(done.research.techs.find((t) => t.key === 'farming')!.level).toBe(1);
      expect(done.ratesPerHour.food).toBe(420); // +5%
      expect((await env.stored()).tech.farming).toBe(1);
    });

    it('следующий уровень требует Академию 2L−1', async () => {
      const { env, research } = await setup({ levels: { academy: 1 }, tech: { farming: 1 } });
      expect(await fail(research.start(env.userId, 'farming', key()))).toMatchObject({
        details: { reason: 'academy_level', required: academyLevelFor(2) },
      });
      await env.setState({ levels: { academy: 3 } });
      await expect(research.start(env.userId, 'farming', key())).resolves.toBeDefined();
    });

    it('очередь — две записи, одну технологию дважды не ставят; вторая ждёт первую', async () => {
      const { env, research } = await setup({ levels: { academy: 1 } });
      await research.start(env.userId, 'farming', key());
      expect(await fail(research.start(env.userId, 'farming', key()))).toMatchObject({
        details: { reason: 'in_progress' },
      });
      await research.start(env.userId, 'mining', key());
      expect(await fail(research.start(env.userId, 'forestry', key()))).toMatchObject({
        code: 'ERR_QUEUE_FULL',
      });
      const q = (await env.service.view(env.userId)).research.queue;
      expect(q).toHaveLength(2);
      expect(q[1]!.startedAt).toBe(q[0]!.finishesAt);
      expect(q[1]!.speedupGems).toBeNull();
    });

    it('уровень 10 — потолок', async () => {
      const { env, research } = await setup({ levels: { academy: 20 }, tech: { armor: 10 } });
      expect(await fail(research.start(env.userId, 'armor', key()))).toMatchObject({
        details: { reason: 'max_level' },
      });
    });

    it('отмена возвращает 50% и подтягивает вторую; ускорение — только идущей', async () => {
      const { env, research } = await setup({ levels: { academy: 1 } });
      const first = (await research.start(env.userId, 'farming', key())).body.research.queue[0]!;
      const second = (await research.start(env.userId, 'mining', key())).body.research.queue[1]!;
      expect(await fail(research.speedup(env.userId, second.id, key()))).toMatchObject({
        details: { reason: 'not_active' },
      });

      const cancelled = await research.cancel(env.userId, first.id, key());
      expect(cancelled.body.research.queue).toHaveLength(1);
      expect(cancelled.body.research.queue[0]!.startedAt).toBe(cancelled.body.serverTime);

      const sped = await research.speedup(env.userId, second.id, key());
      expect(sped.body.research.queue).toHaveLength(0);
      expect(sped.body.research.techs.find((t) => t.key === 'mining')!.level).toBe(1);
      expect(sped.body.gems).toBeLessThan(50);
    });

    it('Логистика поднимает ёмкость склада', async () => {
      const { env } = await setup({ tech: { logistics: 5 } });
      expect((await env.service.view(env.userId)).caps.gold).toBe(3600); // 3000 · 1.2
    });

    it('нехватка ресурсов и повтор по ключу', async () => {
      const { env, research } = await setup({
        levels: { academy: 1 },
        resources: { gold: 10, wood: 10, stone: 0, food: 0 },
      });
      expect(await fail(research.start(env.userId, 'farming', key()))).toMatchObject({
        code: 'ERR_INSUFFICIENT_RESOURCES',
      });
      await env.setState({ resources: RICH });
      const k = key();
      await research.start(env.userId, 'farming', k);
      expect((await research.start(env.userId, 'farming', k)).replayed).toBe(true);
      expect((await env.stored()).research).toHaveLength(1);
    });
  });

  describe(`герой: ${name}`, () => {
    const withHero = (over: Partial<HeroState> = {}): HeroState => ({ ...newHero(), ...over });

    it('герой создаётся при первом обращении: 1 уровень, 1 очко, пустая сумка', async () => {
      const { env } = await setup();
      const c = await env.service.view(env.userId);
      expect(c.hero).toMatchObject({ level: 1, xp: 0, skillPoints: 1, xpToNext: 100, items: [] });
      expect(c.hero.bonuses).toEqual({ attack: 0, defense: 0, production: 0 });
    });

    it('очко навыка вкладывается один раз; без очков — отказ', async () => {
      const { env, hero } = await setup();
      const res = await hero.spendSkill(env.userId, 'combat', key());
      expect(res.body.hero).toMatchObject({
        skillPoints: 0,
        skills: { combat: 1, defense: 0, economy: 0 },
      });
      expect(res.body.hero.bonuses.attack).toBeCloseTo(0.02);
      expect(await fail(hero.spendSkill(env.userId, 'defense', key()))).toMatchObject({
        details: { reason: 'no_points' },
      });
    });

    it('навык максимум 5 уровней', async () => {
      const { env, hero } = await setup({
        hero: withHero({ level: 10, skills: { combat: 5, defense: 0, economy: 0 } }),
      });
      expect(await fail(hero.spendSkill(env.userId, 'combat', key()))).toMatchObject({
        details: { reason: 'max_level' },
      });
    });

    it('хозяйственный навык увеличивает производство', async () => {
      const { env, hero } = await setup();
      const res = await hero.spendSkill(env.userId, 'economy', key());
      expect(res.body.ratesPerHour.gold).toBeCloseTo(309, 6); // 300 · 1.03
      expect(res.body.hero.bonuses.production).toBeCloseTo(0.03);
    });

    it('тренировка тратит ресурсы, даёт опыт и повышает уровень с переносом остатка', async () => {
      const { env, hero } = await setup();
      const cost = heroTrainCost(1);
      const one = await hero.train(env.userId, key());
      expect(one.body.resources.gold).toBe(RICH.gold - cost.gold);
      expect(one.body.hero).toMatchObject({ level: 1, xp: HERO_TRAIN_XP });
      const two = await hero.train(env.userId, key());
      // 120 опыта: 100 уходит на 2-й уровень, остаток 20
      expect(two.body.hero).toMatchObject({ level: 2, xp: 20, skillPoints: 2 });
      expect(two.body.hero.xpToNext).toBe(303);
      expect(two.body.resources.gold).toBe(RICH.gold - cost.gold - heroTrainCost(1).gold);
    });

    it('тренировка: нехватка ресурсов — отказ без изменений', async () => {
      const { env, hero } = await setup({ resources: { gold: 10, wood: 0, stone: 0, food: 0 } });
      expect(await fail(hero.train(env.userId, key()))).toMatchObject({
        code: 'ERR_INSUFFICIENT_RESOURCES',
      });
      expect((await env.stored()).hero?.xp ?? 0).toBe(0); // героя могло и не быть: отказ ничего не записал
    });

    it('предмет надевается; прежний в слоте снимается; чужой id — 404', async () => {
      const w1 = '11111111-1111-4111-8111-111111111111';
      const w2 = '22222222-2222-4222-8222-222222222222';
      const { env, hero } = await setup({
        hero: withHero({
          items: [
            { id: w1, slot: 'weapon', rarity: 2, equipped: true },
            { id: w2, slot: 'weapon', rarity: 5, equipped: false },
          ],
        }),
      });
      const res = await hero.equip(env.userId, w2, key());
      expect(res.body.hero.items.find((i) => i.id === w1)!.equipped).toBe(false);
      expect(res.body.hero.items.find((i) => i.id === w2)!.equipped).toBe(true);
      expect(res.body.hero.bonuses.attack).toBeCloseTo(5 * 0.015);
      expect(
        await fail(hero.equip(env.userId, '33333333-3333-4333-8333-333333333333', key())),
      ).toMatchObject({ code: 'ERR_NOT_FOUND' });
      const stored = (await env.stored()).hero!;
      expect(stored.items.filter((i) => i.slot === 'weapon' && i.equipped)).toHaveLength(1);
    });

    it('герой переживает чтение из хранилища без потерь', async () => {
      const { env, hero } = await setup();
      await hero.spendSkill(env.userId, 'defense', key());
      await hero.train(env.userId, key());
      const stored = (await env.stored()).hero!;
      expect(stored).toMatchObject({
        level: 1,
        xp: 60,
        skills: { combat: 0, defense: 1, economy: 0 },
      });
    });
  });

  it('стартовые значения не изменились', () => {
    expect(START_RESOURCES.gold).toBe(1000);
    expect(unitStats('infantry', 1).upkeep).toBe(1);
  });
}
