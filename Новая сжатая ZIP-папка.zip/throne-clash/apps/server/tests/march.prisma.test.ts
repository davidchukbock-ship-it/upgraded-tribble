import { PrismaClient } from '@prisma/client';
import { afterAll, beforeEach, describe } from 'vitest';
import { START_BUILDINGS, START_GEMS } from '@tc/shared';
import { ensureMainWorld } from '../src/db/bootstrap';
import { FakeClock } from '../src/lib/clock';
import { createPrismaRepositories } from '../src/modules/auth/auth.repository';
import { PrismaCastleRepository } from '../src/modules/castle/castle.repository';
import { marchSuite } from './march.suite';
import { castleFor, userFor } from './repository.contract';
import { resetTables, testDatabaseUrl } from './test-db';

const url = testDatabaseUrl();

describe.runIf(url)('карта и походы на PostgreSQL', () => {
  const db = new PrismaClient({ datasourceUrl: url });
  const repos = createPrismaRepositories(db);
  let n = 0;

  beforeEach(async () => {
    await resetTables(db, [
      'Report',
      'CellState',
      'March',
      'IdempotencyKey',
      'EconomyEvent',
      'BuildTask',
      'TrainTask',
      'ResearchTask',
      'ArmyUnit',
      'TechLevel',
      'HeroItem',
      'Hero',
      'SecurityLog',
      'RefreshToken',
      'Building',
      'Castle',
      'User',
    ]);
    await ensureMainWorld(db, 20260101);
  });
  afterAll(() => db.$disconnect());

  marchSuite('PostgreSQL', async () => {
    const clock = new FakeClock();
    return {
      repo: new PrismaCastleRepository(db),
      clock,
      async addPlayer(name) {
        const user = await repos.users.createWithCastle(
          { ...userFor(name, `pm${n++}@example.com`), createdAt: clock.now() },
          {
            ...castleFor(),
            buildings: START_BUILDINGS,
            resourcesUpdatedAt: clock.now(),
            gems: START_GEMS,
          },
        );
        return user.id;
      },
    };
  });
});
