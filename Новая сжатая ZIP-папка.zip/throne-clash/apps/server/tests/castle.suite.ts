import { describe, expect, it } from 'vitest';
import {
  BUILDING_KEYS,
  EXTRA_SLOT_GEMS,
  START_GEMS,
  START_RESOURCES,
  buildSeconds,
  buildingCost,
  type BuildingKey,
  type BuildingLevels,
  type ResourceAmounts,
  type Army,
  type HeroState,
  type TechLevels,
} from '@tc/shared';
import type { FakeClock } from '../src/lib/clock';
import { AppError } from '../src/lib/errors';
import type { CastleService } from '../src/modules/castle/castle.service';
import type { CastleAggregate, EconomyEventRecord } from '../src/modules/castle/castle.types';

export interface CastleEnv {
  service: CastleService;
  clock: FakeClock;
  userId: string;
  /** Подменяет состояние замка напрямую (минуя игровые правила) — для подготовки сценария. */
  setState(patch: {
    resources?: Partial<ResourceAmounts>;
    gems?: number;
    levels?: BuildingLevels;
    army?: Army;
    tech?: TechLevels;
    hero?: HeroState;
  }): Promise<void>;
  /** Что реально лежит в хранилище. */
  stored(): Promise<CastleAggregate>;
  economy(): Promise<EconomyEventRecord[]>;
}

let seq = 0;
const key = () => `idem-${Date.now()}-${seq++}-abcdef`;

async function code(
  p: Promise<unknown>,
): Promise<{ code: string; status: number; details: unknown }> {
  const err = await p.then(
    () => undefined,
    (e: unknown) => e,
  );
  expect(err).toBeInstanceOf(AppError);
  const e = err as AppError;
  return { code: e.code, status: e.statusCode, details: e.details };
}

const HOUR = 3600;

/**
 * Сценарии сервиса замка. Гоняются на in-memory и на PostgreSQL (D-24):
 * одинаковое поведение в обоих — условие честности быстрых тестов.
 */
export function castleServiceSuite(name: string, make: () => Promise<CastleEnv>): void {
  describe(`замок: ${name}`, () => {
    it('стартовое состояние соответствует правилам', async () => {
      const env = await make();
      const c = await env.service.view(env.userId);
      expect(c.resources).toEqual(START_RESOURCES);
      expect(c.gems).toBe(START_GEMS);
      expect(c.caps).toEqual({ gold: 3000, wood: 3000, stone: 3000, food: 3000 });
      expect(c.ratesPerHour).toEqual({ gold: 300, wood: 400, stone: 350, food: 400 });
      expect(c.slots).toMatchObject({
        total: 1,
        used: 0,
        canUnlock: true,
        unlockCostGems: EXTRA_SLOT_GEMS,
      });
      expect(c.buildings).toHaveLength(BUILDING_KEYS.length);
      const level = (k: BuildingKey) => c.buildings.find((b) => b.key === k)?.level;
      expect(level('castle')).toBe(1);
      expect(level('barracks')).toBe(0);
      expect(c.shieldUntil).not.toBeNull();
    });

    it('ресурсы копятся с течением времени; повторные чтения ничего не пишут', async () => {
      const env = await make();
      env.clock.advance(HOUR / 2);
      const c = await env.service.view(env.userId);
      expect(c.resources.gold).toBe(1150);
      expect(c.resources.food).toBe(1200);
      // Первое чтение создаёт героя, поэтому записывает состояние; дальше GET — чистое чтение
      const first = await env.stored();
      expect(first.hero).not.toBeNull();
      env.clock.advance(60);
      const later = await env.service.view(env.userId);
      expect(later.resources.gold).toBeGreaterThan(c.resources.gold);
      const second = await env.stored();
      expect(second.version).toBe(first.version);
      expect(second.resources.gold).toBe(first.resources.gold);
    });

    it('упирается в ёмкость склада', async () => {
      const env = await make();
      env.clock.advance(10 * HOUR);
      const c = await env.service.view(env.userId);
      expect(c.resources).toEqual({ gold: 3000, wood: 3000, stone: 3000, food: 3000 });
    });

    describe('улучшение', () => {
      it('списывает стоимость, ставит задачу и логирует экономику', async () => {
        const env = await make();
        const res = await env.service.upgrade(env.userId, 'barracks', key());
        expect(res.replayed).toBe(false);
        const cost = buildingCost('barracks', 1);
        expect(res.body.resources.gold).toBe(START_RESOURCES.gold - cost.gold);
        expect(res.body.resources.food).toBe(START_RESOURCES.food - cost.food);
        expect(res.body.tasks).toHaveLength(1);
        const task = res.body.tasks[0]!;
        expect(task).toMatchObject({ key: 'barracks', toLevel: 1 });
        expect(Date.parse(task.finishesAt) - Date.parse(task.startedAt)).toBe(
          buildSeconds('barracks', 1, 1) * 1000,
        );
        expect(res.body.slots).toMatchObject({ used: 1 });
        const b = res.body.buildings.find((x) => x.key === 'barracks')!;
        expect(b.blocked).toBe('in_progress');

        const events = await env.economy();
        expect(
          events.filter((e) => e.kind === 'build_cost').reduce((s, e) => s + e.amount, 0),
        ).toBe(-(cost.gold + cost.wood + cost.stone + cost.food));
        expect(events.every((e) => e.amount < 0 && !e.isGodAction)).toBe(true);
      });

      it('постройка завершается по времени и применяется при чтении; результат записан', async () => {
        const env = await make();
        await env.setState({ levels: { castle: 2 } });
        await env.service.upgrade(env.userId, 'farm', key());
        env.clock.advance(buildSeconds('farm', 2, 2) + 1);
        const c = await env.service.view(env.userId);
        expect(c.buildings.find((b) => b.key === 'farm')?.level).toBe(2);
        expect(c.tasks).toHaveLength(0);
        expect(c.ratesPerHour.food).toBe(468);
        const stored = await env.stored();
        expect(stored.levels.farm).toBe(2);
        expect(stored.tasks).toHaveLength(0);
      });

      it('производство считается по-старому до завершения и по-новому после', async () => {
        const env = await make();
        await env.setState({
          levels: { castle: 2 },
          resources: { food: 0, gold: 3000, wood: 3000, stone: 3000 },
        });
        await env.service.upgrade(env.userId, 'farm', key());
        const build = buildSeconds('farm', 2, 2);
        env.clock.advance(build + HOUR);
        const c = await env.service.view(env.userId);
        // build секунд по 400/ч, затем час по 468/ч
        expect(c.resources.food).toBeCloseTo((400 * build) / HOUR + 468, 3);
      });

      it('нехватка ресурсов: 422 и что именно не хватает; ничего не списано', async () => {
        const env = await make();
        await env.setState({ resources: { gold: 10 } });
        const e = await code(env.service.upgrade(env.userId, 'forge', key()));
        expect(e).toMatchObject({ code: 'ERR_INSUFFICIENT_RESOURCES', status: 422 });
        expect((e.details as { missing: Record<string, number> }).missing.gold).toBe(190);
        expect((await env.stored()).resources.gold).toBe(10);
        expect((await env.stored()).tasks).toHaveLength(0);
      });

      it('уровень не выше Замка (кроме самого Замка)', async () => {
        const env = await make();
        const e = await code(
          env.service.upgrade(env.userId, 'farm', key()).then(async () => {
            env.clock.advance(buildSeconds('farm', 2, 1) + 1);
            return env.service.upgrade(env.userId, 'farm', key()); // ферма L2 > замок L1
          }),
        );
        expect(e).toMatchObject({ code: 'ERR_REQUIREMENT_NOT_MET', status: 422 });
        expect(e.details).toMatchObject({ reason: 'castle_level' });
        const c = await env.service.view(env.userId);
        expect(c.buildings.find((b) => b.key === 'farm')?.blocked).toBe('castle_level');
        expect(c.buildings.find((b) => b.key === 'castle')?.blocked).toBeNull();
      });

      it('одно здание нельзя улучшать дважды одновременно; второй слот занят — очередь полна', async () => {
        const env = await make();
        await env.service.upgrade(env.userId, 'barracks', key());
        expect(await code(env.service.upgrade(env.userId, 'barracks', key()))).toMatchObject({
          code: 'ERR_REQUIREMENT_NOT_MET',
          details: { reason: 'in_progress' },
        });
        expect(await code(env.service.upgrade(env.userId, 'forge', key()))).toMatchObject({
          code: 'ERR_QUEUE_FULL',
          status: 422,
        });
      });

      it('потолок 20 уровня', async () => {
        const env = await make();
        await env.setState({
          levels: { castle: 20 },
          resources: { gold: 3000, wood: 3000, stone: 3000, food: 3000 },
        });
        expect(await code(env.service.upgrade(env.userId, 'castle', key()))).toMatchObject({
          details: { reason: 'max_level' },
        });
      });

      it('Замок 8+ открывает второй слот бесплатно', async () => {
        const env = await make();
        await env.setState({
          levels: { castle: 8 },
          resources: { gold: 3000, wood: 3000, stone: 3000, food: 3000 },
        });
        await env.service.upgrade(env.userId, 'farm', key());
        const res = await env.service.upgrade(env.userId, 'sawmill', key());
        expect(res.body.slots).toMatchObject({ total: 2, used: 2, canUnlock: false });
      });
    });

    describe('ускорение', () => {
      it('стоит 1 кристалл за 5 минут остатка и завершает постройку сразу', async () => {
        const env = await make();
        await env.setState({ resources: { gold: 3000, wood: 3000, stone: 3000, food: 3000 } });
        const started = await env.service.upgrade(env.userId, 'castle', key()); // ~180 c → 1 кристалл
        const task = started.body.tasks[0]!;
        expect(task.speedupGems).toBe(1);
        const res = await env.service.speedup(env.userId, task.id, key());
        expect(res.body.gems).toBe(START_GEMS - 1);
        expect(res.body.tasks).toHaveLength(0);
        expect(res.body.buildings.find((b) => b.key === 'castle')?.level).toBe(2);
        expect((await env.economy()).find((e) => e.kind === 'speedup')).toMatchObject({
          resource: 'gems',
          amount: -1,
        });
      });

      it('цена падает по мере выполнения', async () => {
        const env = await make();
        await env.setState({
          levels: { castle: 10 },
          resources: { gold: 3000, wood: 3000, stone: 3000, food: 3000 },
        });
        const t = (await env.service.upgrade(env.userId, 'farm', key())).body.tasks[0]!;
        const before = t.speedupGems;
        env.clock.advance(
          Math.floor((Date.parse(t.finishesAt) - Date.parse(t.startedAt)) / 1000 / 2),
        );
        const after = (await env.service.view(env.userId)).tasks[0]!.speedupGems;
        expect(after).toBeLessThanOrEqual(before);
      });

      it('не хватает кристаллов → 422, ничего не изменено', async () => {
        const env = await make();
        await env.setState({ gems: 0 });
        const t = (await env.service.upgrade(env.userId, 'barracks', key())).body.tasks[0]!;
        expect(await code(env.service.speedup(env.userId, t.id, key()))).toMatchObject({
          code: 'ERR_INSUFFICIENT_RESOURCES',
        });
        expect((await env.stored()).tasks).toHaveLength(1);
      });

      it('чужой/несуществующий id → 404', async () => {
        const env = await make();
        expect(
          await code(
            env.service.speedup(env.userId, '00000000-0000-4000-8000-000000000000', key()),
          ),
        ).toMatchObject({ code: 'ERR_NOT_FOUND', status: 404 });
      });
    });

    describe('отмена', () => {
      it('возвращает 50% ресурсов (вниз), задача исчезает', async () => {
        const env = await make();
        const started = await env.service.upgrade(env.userId, 'barracks', key());
        const cost = buildingCost('barracks', 1);
        const res = await env.service.cancel(env.userId, started.body.tasks[0]!.id, key());
        expect(res.body.tasks).toHaveLength(0);
        expect(res.body.resources.gold).toBe(
          START_RESOURCES.gold - cost.gold + Math.floor(cost.gold / 2),
        );
        expect(res.body.resources.wood).toBe(
          START_RESOURCES.wood - cost.wood + Math.floor(cost.wood / 2),
        );
        expect((await env.stored()).levels.barracks).toBeUndefined();
        const refunds = (await env.economy()).filter((e) => e.kind === 'build_refund');
        expect(refunds.length).toBeGreaterThan(0);
        expect(refunds.every((e) => e.amount > 0)).toBe(true);
      });

      it('повторная отмена той же задачи → 404 (двойного возврата нет)', async () => {
        const env = await make();
        const t = (await env.service.upgrade(env.userId, 'barracks', key())).body.tasks[0]!;
        await env.service.cancel(env.userId, t.id, key());
        const gold = (await env.stored()).resources.gold;
        expect(await code(env.service.cancel(env.userId, t.id, key()))).toMatchObject({
          code: 'ERR_NOT_FOUND',
        });
        expect((await env.stored()).resources.gold).toBe(gold);
      });

      it('отменить нельзя уже завершённую постройку', async () => {
        const env = await make();
        const t = (await env.service.upgrade(env.userId, 'barracks', key())).body.tasks[0]!;
        env.clock.advance(buildSeconds('barracks', 1, 1) + 5);
        expect(await code(env.service.cancel(env.userId, t.id, key()))).toMatchObject({
          code: 'ERR_NOT_FOUND',
        });
        expect(
          (await env.service.view(env.userId)).buildings.find((b) => b.key === 'barracks')?.level,
        ).toBe(1);
      });
    });

    describe('второй слот за кристаллы', () => {
      it('не хватает кристаллов → 422; хватает → списывает 250 и открывает навсегда', async () => {
        const env = await make();
        expect(await code(env.service.unlockSlot(env.userId, key()))).toMatchObject({
          code: 'ERR_INSUFFICIENT_RESOURCES',
        });
        await env.setState({ gems: 300 });
        const res = await env.service.unlockSlot(env.userId, key());
        expect(res.body.gems).toBe(50);
        expect(res.body.slots).toMatchObject({ total: 2, extraUnlocked: true, canUnlock: false });
        expect(await code(env.service.unlockSlot(env.userId, key()))).toMatchObject({
          code: 'ERR_CONFLICT',
        });
        expect((await env.stored()).extraBuildSlot).toBe(true);
      });
    });

    describe('идемпотентность (Idempotency-Key)', () => {
      it('повтор с тем же ключом возвращает прежний ответ и не тратит ресурсы дважды', async () => {
        const env = await make();
        const k = key();
        const first = await env.service.upgrade(env.userId, 'barracks', k);
        const again = await env.service.upgrade(env.userId, 'barracks', k);
        expect(first.replayed).toBe(false);
        expect(again.replayed).toBe(true);
        expect(again.body).toEqual(first.body);
        const stored = await env.stored();
        expect(stored.tasks).toHaveLength(1);
        expect(stored.resources.gold).toBe(START_RESOURCES.gold - buildingCost('barracks', 1).gold);
      });

      it('тот же ключ для другого действия → ERR_IDEMPOTENCY_MISMATCH', async () => {
        const env = await make();
        const k = key();
        await env.service.upgrade(env.userId, 'barracks', k);
        expect(await code(env.service.upgrade(env.userId, 'forge', k))).toMatchObject({
          code: 'ERR_IDEMPOTENCY_MISMATCH',
          status: 422,
        });
      });

      it('ключи разных игроков независимы', async () => {
        const a = await make();
        const b = await make();
        const k = key();
        expect((await a.service.upgrade(a.userId, 'barracks', k)).replayed).toBe(false);
        expect((await b.service.upgrade(b.userId, 'barracks', k)).replayed).toBe(false);
      });

      it('через 24 часа ключ считается новым', async () => {
        const env = await make();
        await env.setState({
          levels: { castle: 8 },
          resources: { gold: 3000, wood: 3000, stone: 3000, food: 3000 },
        });
        const k = key();
        await env.service.upgrade(env.userId, 'farm', k);
        env.clock.advance(25 * HOUR);
        const res = await env.service.upgrade(env.userId, 'farm', k);
        expect(res.replayed).toBe(false);
        expect(res.body.buildings.find((b) => b.key === 'farm')?.level).toBe(2); // первое выполнено, второе — уже L3 в очереди
      });

      it('ошибка не сохраняется под ключом: после исправления причины повтор проходит', async () => {
        const env = await make();
        await env.setState({ resources: { gold: 0 } });
        const k = key();
        await code(env.service.upgrade(env.userId, 'barracks', k));
        await env.setState({ resources: { gold: 1000 } });
        expect((await env.service.upgrade(env.userId, 'barracks', k)).replayed).toBe(false);
      });
    });

    describe('земли и новые здания (D-59…D-61)', () => {
      const rich = { gold: 50_000, wood: 50_000, stone: 50_000, food: 50_000 };

      it('Земли открываются порогом уровня Замка и растут по одному уровню', async () => {
        const env = await make();
        await env.setState({ resources: rich });
        expect(await code(env.service.upgrade(env.userId, 'territory', key()))).toMatchObject({
          code: 'ERR_REQUIREMENT_NOT_MET',
          details: { reason: 'castle_level' },
        });
        const c0 = await env.service.view(env.userId);
        expect(c0.buildings.find((b) => b.key === 'territory')).toMatchObject({
          level: 0,
          blocked: 'castle_level',
        });

        await env.setState({ levels: { castle: 4 } });
        const res = await env.service.upgrade(env.userId, 'territory', key());
        expect(res.body.tasks[0]).toMatchObject({ key: 'territory', toLevel: 1 });
        env.clock.advance(buildSeconds('territory', 1, 4) + 1);
        const done = await env.service.view(env.userId);
        expect(done.buildings.find((b) => b.key === 'territory')?.level).toBe(1);
        // второй уровень Земель ждёт седьмого Замка
        expect(done.buildings.find((b) => b.key === 'territory')?.blocked).toBe('castle_level');
      });

      it('потолок Земель — 4 уровня', async () => {
        const env = await make();
        await env.setState({ levels: { castle: 20, territory: 4 }, resources: rich });
        expect(await code(env.service.upgrade(env.userId, 'territory', key()))).toMatchObject({
          code: 'ERR_REQUIREMENT_NOT_MET',
          details: { reason: 'max_level' },
        });
      });

      it('новое здание нельзя строить без Земель и нужных зданий; в ответе видно, чего не хватает', async () => {
        const env = await make();
        await env.setState({ levels: { castle: 8 }, resources: rich });
        const c = await env.service.view(env.userId);
        expect(c.buildings.find((b) => b.key === 'fishery')).toMatchObject({
          blocked: 'requires',
          missing: [{ kind: 'territory', level: 1 }],
        });
        const err = await code(env.service.upgrade(env.userId, 'fishery', key()));
        expect(err).toMatchObject({
          code: 'ERR_REQUIREMENT_NOT_MET',
          details: { reason: 'requires' },
        });
        // Ничего не списано и не поставлено в очередь
        const stored = await env.stored();
        expect(stored.tasks).toHaveLength(0);
        expect(stored.resources.gold).toBe(50_000);

        await env.setState({ levels: { castle: 8, territory: 2 } });
        expect(
          (await env.service.view(env.userId)).buildings.find((b) => b.key === 'stormtower')
            ?.missing,
        ).toEqual([
          { kind: 'territory', level: 3 },
          { kind: 'building', key: 'magetower', level: 5 },
        ]);
      });

      it('Рыбацкая пристань добавляет еду; башни и шахта строятся, когда условия выполнены', async () => {
        const env = await make();
        await env.setState({
          levels: { castle: 8, territory: 2, barracks: 5, forge: 3, academy: 3 },
          resources: rich,
        });
        const before = (await env.service.view(env.userId)).ratesPerHour.food;
        for (const k of [
          'fishery',
          'archertower',
          'ballistatower',
          'magetower',
          'diamondmine',
        ] as const) {
          await env.setState({
            levels: { castle: 8, territory: 2, barracks: 5, forge: 3, academy: 3 },
          });
          const res = await env.service.upgrade(env.userId, k, key());
          expect(res.body.tasks.at(-1)).toMatchObject({ key: k, toLevel: 1 });
          env.clock.advance(buildSeconds(k, 1, 8) + 1);
          await env.service.view(env.userId);
        }
        // очередь одна: каждое здание достроено к следующей итерации
        const after = await env.service.view(env.userId);
        expect(after.ratesPerHour.food).toBeGreaterThan(before);
      });

      it('Алмазная шахта копит кристаллы между чтениями и не теряет доли', async () => {
        const env = await make();
        await env.setState({ levels: { castle: 8, territory: 2, diamondmine: 5 }, gems: 0 });
        env.clock.advance(3 * HOUR);
        const a = await env.service.view(env.userId);
        env.clock.advance(3 * HOUR);
        // промежуточное действие сохраняет состояние, затем читаем ещё раз
        await env.service.unlockSlot(env.userId, key()).catch(() => undefined);
        const b = await env.service.view(env.userId);
        expect(a.gems).toBeGreaterThan(0);
        expect(b.gems).toBeGreaterThan(a.gems);
        // повторное чтение в тот же момент ничего не добавляет
        expect((await env.service.view(env.userId)).gems).toBe(b.gems);
        const stored = await env.stored();
        expect(stored.gemsCarry).toBeGreaterThanOrEqual(0);
        expect(stored.gemsCarry).toBeLessThan(1);
      });
    });

    describe('постройки города (D-66)', () => {
      const rich = { gold: 50_000, wood: 50_000, stone: 50_000, food: 50_000 };
      // первая свободная клетка стартового острова (не улица, не участок здания)
      const CELL = { x: 6, y: 1 };

      it('дом ставится сразу за ресурсы и повышает производство; снос возвращает половину', async () => {
        const env = await make();
        await env.setState({ levels: { castle: 4 }, resources: rich });
        const before = await env.service.view(env.userId);
        const res = await env.service.placeStructure(env.userId, { kind: 'house', ...CELL }, key());
        expect(res.body.city.structures).toHaveLength(1);
        expect(res.body.city.prosperity).toBeCloseTo(0.006, 6);
        expect(res.body.ratesPerHour.gold).toBeGreaterThan(before.ratesPerHour.gold);
        expect(res.body.resources.gold).toBe(50_000 - 150);
        // вторая постройка вида дороже первой
        const house = res.body.city.catalog.find((c) => c.kind === 'house');
        expect(house?.owned).toBe(1);
        expect(house?.cost.gold).toBeGreaterThan(150);

        const id = res.body.city.structures[0]!.id;
        const removed = await env.service.removeStructure(env.userId, id, key());
        expect(removed.body.city.structures).toHaveLength(0);
        expect(removed.body.resources.gold).toBe(50_000 - 150 + 75);
        const stored = await env.stored();
        expect(stored.structures).toHaveLength(0);
      });

      it('нельзя: занятая клетка, улица, участок здания, чужой вид, малый уровень Замка, нехватка ресурсов', async () => {
        const env = await make();
        await env.setState({ levels: { castle: 4 }, resources: rich });
        await env.service.placeStructure(env.userId, { kind: 'house', ...CELL }, key());
        // та же клетка
        expect(
          await code(env.service.placeStructure(env.userId, { kind: 'garden', ...CELL }, key())),
        ).toMatchObject({ status: 409 });
        // улица (строка 5) и участок фермы (1.6, 0.9)
        for (const bad of [
          { x: 3, y: 5 },
          { x: 2, y: 1 },
          { x: 0, y: 0 },
          { x: 99, y: 3 },
        ]) {
          expect(
            await code(env.service.placeStructure(env.userId, { kind: 'house', ...bad }, key())),
          ).toMatchObject({ status: 409 });
        }
        // Рынок требует Замок 8
        expect(
          await code(env.service.placeStructure(env.userId, { kind: 'bank', x: 13, y: 1 }, key())),
        ).toMatchObject({ code: 'ERR_REQUIREMENT_NOT_MET', details: { reason: 'castle_level' } });
        await env.setState({ resources: { gold: 10 } });
        expect(
          await code(
            env.service.placeStructure(env.userId, { kind: 'garden', x: 13, y: 2 }, key()),
          ),
        ).toMatchObject({ code: 'ERR_INSUFFICIENT_RESOURCES' });
        const stored = await env.stored();
        expect(stored.structures).toHaveLength(1);
      });

      it('корабль ставится на воду за задним краем, а не на сушу; дорога — на сушу и почти бесплатна', async () => {
        const env = await make();
        await env.setState({ levels: { castle: 8 }, resources: rich });
        const ship = await env.service.placeStructure(
          env.userId,
          { kind: 'ship', x: -2, y: 4 },
          key(),
        );
        expect(ship.body.city.structures[0]).toMatchObject({ kind: 'ship', x: -2, y: 4 });
        expect(
          await code(env.service.placeStructure(env.userId, { kind: 'ship', ...CELL }, key())),
        ).toMatchObject({ status: 409 });
        expect(
          await code(env.service.placeStructure(env.userId, { kind: 'house', x: -1, y: 4 }, key())),
        ).toMatchObject({ status: 409 });
        const road = await env.service.placeStructure(env.userId, { kind: 'road', ...CELL }, key());
        expect(road.body.city.structures).toHaveLength(2);
        // дорога не повышает производство, корабль — повышает
        expect(road.body.city.prosperity).toBeCloseTo(0.006, 6);
      });

      it('предел вида и потолок процветания; повтор с тем же ключом не ставит вторую постройку', async () => {
        const env = await make();
        await env.setState({
          levels: { castle: 10 },
          resources: {
            ...rich,
            gold: 5_000_000,
            wood: 5_000_000,
            stone: 5_000_000,
            food: 5_000_000,
          },
        });
        const k = key();
        const a = await env.service.placeStructure(env.userId, { kind: 'statue', ...CELL }, k);
        const b = await env.service.placeStructure(env.userId, { kind: 'statue', ...CELL }, k);
        expect(b.replayed).toBe(true);
        expect(b.body.city.structures).toHaveLength(1);
        expect(a.body.city.structures).toHaveLength(1);
        const cells = [
          { x: 7, y: 1 },
          { x: 6, y: 2 },
          { x: 7, y: 2 },
        ];
        for (const c of cells)
          await env.service.placeStructure(env.userId, { kind: 'statue', ...c }, key());
        expect(
          await code(
            env.service.placeStructure(env.userId, { kind: 'statue', x: 13, y: 3 }, key()),
          ),
        ).toMatchObject({
          code: 'ERR_REQUIREMENT_NOT_MET',
          details: { reason: 'structure_limit' },
        });
      });
    });

    describe('гонки', () => {
      it('10 одновременных улучшений разных зданий при одном слоте: успех ровно один, ресурсы списаны один раз', async () => {
        const env = await make();
        await env.setState({ resources: { gold: 3000, wood: 3000, stone: 3000, food: 3000 } });
        const keys: BuildingKey[] = [
          'barracks',
          'forge',
          'academy',
          'walls',
          'hospital',
          'castle',
          'farm',
          'sawmill',
          'quarry',
          'goldmine',
        ];
        const results = await Promise.allSettled(
          keys.map((k) => env.service.upgrade(env.userId, k, key())),
        );
        const ok = results.filter((r) => r.status === 'fulfilled');
        expect(ok).toHaveLength(1);
        for (const r of results) {
          if (r.status === 'rejected')
            expect((r.reason as AppError).code).toMatch(/ERR_QUEUE_FULL|ERR_REQUIREMENT_NOT_MET/);
        }
        const stored = await env.stored();
        expect(stored.tasks).toHaveLength(1);
        const paid = stored.tasks[0]!.paid;
        expect(stored.resources.gold).toBe(3000 - paid.gold);
      });

      it('5 одновременных запросов с ОДНИМ ключом: одно списание, у всех одинаковый ответ', async () => {
        const env = await make();
        const k = key();
        const results = await Promise.all(
          Array.from({ length: 5 }, () => env.service.upgrade(env.userId, 'barracks', k)),
        );
        expect(results.filter((r) => !r.replayed)).toHaveLength(1);
        // JSONB не сохраняет порядок ключей — сравниваем по значению, а не по строке
        for (const r of results) expect(r.body).toEqual(results[0]!.body);
        const stored = await env.stored();
        expect(stored.tasks).toHaveLength(1);
        expect(stored.resources.gold).toBe(START_RESOURCES.gold - buildingCost('barracks', 1).gold);
      });

      it('одновременное ускорение и отмена одной задачи: срабатывает одно действие', async () => {
        const env = await make();
        const t = (await env.service.upgrade(env.userId, 'barracks', key())).body.tasks[0]!;
        const r = await Promise.allSettled([
          env.service.speedup(env.userId, t.id, key()),
          env.service.cancel(env.userId, t.id, key()),
        ]);
        expect(r.filter((x) => x.status === 'fulfilled')).toHaveLength(1);
        const stored = await env.stored();
        expect(stored.tasks).toHaveLength(0);
        // либо здание построено (ускорение), либо ресурсы возвращены (отмена) — но не оба сразу
        const built = stored.levels.barracks === 1;
        const refunded =
          stored.resources.gold > START_RESOURCES.gold - buildingCost('barracks', 1).gold;
        expect(built !== refunded).toBe(true);
      });
    });
  });
}
