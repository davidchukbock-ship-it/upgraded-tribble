import type { FastifyInstance } from 'fastify';
import request from 'supertest';
import { afterEach, describe, expect, it } from 'vitest';
import { createMemoryRepositories } from '../src/modules/auth/auth.memory';
import { makeApp } from './helpers';

let app: FastifyInstance | undefined;
afterEach(async () => {
  await app?.close();
  app = undefined;
});

let seq = 0;
const idem = () => `abuse-${Date.now()}-${seq++}`;
const bearer = (t: string) => ({ Authorization: `Bearer ${t}` });

async function boot(env: Record<string, string> = {}) {
  const repos = createMemoryRepositories();
  const made = await makeApp({
    env: {
      AUTH_LOGIN_RATE_MAX: '1000',
      AUTH_REGISTER_RATE_MAX: '1000',
      AUTH_GUEST_RATE_MAX: '1000',
      JWT_ACCESS_TTL_SECONDS: '86400',
      ...env,
    },
    deps: { repos },
  });
  app = made.app;
  const reg = await request(made.app.server)
    .post('/api/auth/register')
    .send({ email: 'a@example.com', password: 'Correct horse 42', nickname: 'Артур' });
  const token = reg.body.accessToken as string;
  await request(made.app.server).get('/api/castle').set(bearer(token));
  return { ...made, repos, server: made.app.server, token, userId: reg.body.user.id as string };
}

describe('антиабьюз', () => {
  it('поток изменяющих запросов от одного игрока получает 429 и запись action_flood; чтение не считается', async () => {
    const t = await boot({ ACTION_RATE_MAX: '5' });
    const hit = () =>
      request(t.server)
        .post('/api/castle/buildings/farm/upgrade')
        .set(bearer(t.token))
        .set('Idempotency-Key', idem());
    const codes: number[] = [];
    for (let i = 0; i < 8; i++) codes.push((await hit()).status);
    expect(codes.filter((c) => c === 429)).toHaveLength(3);
    for (let i = 0; i < 20; i++)
      expect((await request(t.server).get('/api/castle').set(bearer(t.token))).status).toBe(200);
    const flood = t.repos.security.events.filter((e) => e.kind === 'action_flood');
    expect(flood).toHaveLength(1); // одинаковые записи не раздувают журнал
    expect(flood[0]).toMatchObject({
      userId: t.userId,
      details: { path: '/api/castle/buildings/farm/upgrade' },
    });
    // окно 10 секунд: потом снова можно
    t.clock.advance(11);
    expect((await hit()).status).not.toBe(429);
  });

  it('лимит считается на игрока, а не на всех', async () => {
    const t = await boot({ ACTION_RATE_MAX: '3' });
    const second = await request(t.server)
      .post('/api/auth/register')
      .send({ email: 'b@example.com', password: 'Correct horse 42', nickname: 'Борис' });
    const other = second.body.accessToken as string;
    await request(t.server).get('/api/castle').set(bearer(other));
    const hit = (token: string) =>
      request(t.server)
        .post('/api/castle/buildings/farm/upgrade')
        .set(bearer(token))
        .set('Idempotency-Key', idem());
    for (let i = 0; i < 4; i++) await hit(t.token);
    expect((await hit(t.token)).status).toBe(429);
    expect((await hit(other)).status).not.toBe(429);
  });

  it('тот же Idempotency-Key с другим действием — отказ и запись idempotency_mismatch', async () => {
    const t = await boot();
    const cur = t.repos.castles.peek(t.userId)!;
    t.repos.castles.seed({
      ...cur,
      levels: { ...cur.levels, castle: 5 },
      resources: { gold: 50_000, wood: 50_000, stone: 50_000, food: 50_000 },
    });
    const key = idem();
    await request(t.server)
      .post('/api/castle/buildings/farm/upgrade')
      .set(bearer(t.token))
      .set('Idempotency-Key', key);
    const res = await request(t.server)
      .post('/api/castle/buildings/sawmill/upgrade')
      .set(bearer(t.token))
      .set('Idempotency-Key', key);
    expect(res.body.error.code).toBe('ERR_IDEMPOTENCY_MISMATCH');
    expect(
      t.repos.security.events.some(
        (e) => e.kind === 'idempotency_mismatch' && e.userId === t.userId,
      ),
    ).toBe(true);
  });

  it('превышение общего лимита по IP попадает в журнал rate_limited', async () => {
    const t = await boot({ RATE_LIMIT_MAX: '5' });
    let limited = 0;
    for (let i = 0; i < 12; i++) {
      const res = await request(t.server).get('/api/castle').set(bearer(t.token));
      if (res.status === 429) limited++;
    }
    expect(limited).toBeGreaterThan(0);
    expect(t.repos.security.events.some((e) => e.kind === 'rate_limited')).toBe(true);
  });

  it('флуд в чате логируется (chat_flood)', async () => {
    const t = await boot({ ACTION_RATE_MAX: '1000' });
    const send = () =>
      request(t.server)
        .post('/api/chat/world/messages')
        .set(bearer(t.token))
        .send({ text: 'привет' });
    for (let i = 0; i < 8; i++) await send();
    expect(t.repos.security.events.filter((e) => e.kind === 'chat_flood')).toHaveLength(1);
  });

  it('служебная зона режима бога не ограничивается лимитом действий', async () => {
    // Владелец вводит команды подряд; при этом попытки без сессии всё равно отвергаются 404/401
    const t = await boot({ ACTION_RATE_MAX: '2', GOD_MODE_ENABLED: 'true' });
    const codes: number[] = [];
    for (let i = 0; i < 6; i++)
      codes.push((await request(t.server).post('/api/god/logout').set(bearer(t.token))).status);
    expect(codes.every((c) => c === 404)).toBe(true); // игрок — не владелец
    expect(t.repos.security.events.some((e) => e.kind === 'action_flood')).toBe(false);
  });
});
