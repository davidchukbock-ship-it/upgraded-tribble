import type { FastifyInstance } from 'fastify';
import request from 'supertest';
import { afterAll, afterEach, beforeAll, describe, expect, it } from 'vitest';
import { MAP_SIZE, buildingCost, resetBalance, type GodAction } from '@tc/shared';
import { hashPassword } from '../src/lib/password';
import { totpCode } from '../src/lib/totp';
import { createMemoryRepositories } from '../src/modules/auth/auth.memory';
import { makeApp } from './helpers';

const GOD_PASSWORD = 'Zeus-thunder-2026!';
const TOTP_SECRET = 'GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ';
let godHash = '';
beforeAll(async () => {
  godHash = await hashPassword(GOD_PASSWORD);
});

let app: FastifyInstance | undefined;
afterEach(async () => {
  resetBalance();
  await app?.close();
  app = undefined;
});
afterAll(() => resetBalance());

let seq = 0;
const idem = () => `god-api-${Date.now()}-${seq++}`;
const bearer = (t: string) => ({ Authorization: `Bearer ${t}` });

interface BootOptions {
  enabled?: boolean;
  totp?: boolean;
}

async function boot(opts: BootOptions = {}) {
  const repos = createMemoryRepositories();
  const made = await makeApp({
    env: {
      AUTH_LOGIN_RATE_MAX: '1000',
      AUTH_REGISTER_RATE_MAX: '1000',
      AUTH_GUEST_RATE_MAX: '1000',
      OWNER_EMAIL: 'owner@example.com',
      JWT_ACCESS_TTL_SECONDS: '86400',
      GOD_MODE_ENABLED: String(opts.enabled ?? true),
      GOD_MODE_PASSWORD_HASH: godHash,
      GOD_MODE_TOTP_SECRET: opts.totp ? TOTP_SECRET : '',
    },
    deps: { repos },
  });
  app = made.app;
  const register = async (email: string, nickname: string) => {
    const res = await request(made.app.server)
      .post('/api/auth/register')
      .send({ email, password: 'Correct horse 42', nickname });
    const token = res.body.accessToken as string;
    const id = res.body.user.id as string;
    await request(made.app.server).get('/api/castle').set(bearer(token));
    return { token, id };
  };
  const owner = await register('owner@example.com', 'Хозяин');
  await repos.users.setRole(owner.id, 'OWNER');
  const player = await register('p@example.com', 'Артур');
  const other = await register('q@example.com', 'Борис');
  // Игрокам нужны Замок 5 и запас, чтобы строить без проверок требований в каждом тесте
  for (const id of [player.id, other.id]) {
    const cur = repos.castles.peek(id)!;
    repos.castles.seed({
      ...cur,
      levels: { ...cur.levels, castle: 5 },
      resources: { gold: 50_000, wood: 50_000, stone: 50_000, food: 50_000 },
      shieldUntil: null,
    });
  }
  const server = made.app.server;

  /** Вход в режим бога; возвращает cookie сессии. */
  const login = async (password = GOD_PASSWORD, totp?: string) => {
    const res = await request(server)
      .post('/api/god/login')
      .set(bearer(owner.token))
      .send({ password, ...(totp && { totp }) });
    const cookie = (res.headers['set-cookie'] as unknown as string[] | undefined)?.[0]?.split(
      ';',
    )[0];
    return { res, cookie: cookie ?? '' };
  };
  const god = async () => {
    const { cookie } = await login(
      GOD_PASSWORD,
      opts.totp ? totpCode(TOTP_SECRET, made.clock.now().getTime()) : undefined,
    );
    const call = (method: 'get' | 'post' | 'put' | 'delete', path: string) =>
      request(server)[method](`/api/god${path}`).set(bearer(owner.token)).set('Cookie', cookie);
    const act = (targetId: string, action: GodAction, key = idem()) =>
      call('post', `/players/${targetId}/act`).set('Idempotency-Key', key).send(action);
    return { cookie, call, act };
  };
  return { ...made, app: made.app, repos, server, owner, player, other, login, god };
}

describe('режим бога: допуск', () => {
  it('флаг выключен → все пути 404, даже для владельца с верным паролем', async () => {
    const t = await boot({ enabled: false });
    for (const [method, path] of [
      ['post', '/api/god/login'],
      ['get', '/api/god/session'],
      ['get', '/api/god/players'],
      ['get', '/api/god/audit'],
    ] as const) {
      const agent = request(t.server);
      const res = await agent[method](path)
        .set(bearer(t.owner.token))
        .send({ password: GOD_PASSWORD });
      expect(res.status).toBe(404);
    }
    // и для анонима: ответ не отличается от несуществующего маршрута
    const anon = await request(t.server).get('/api/god/players');
    expect(anon.status).toBe(404);
    expect(anon.body.error.message).toBe(
      (await request(t.server).get('/api/nope')).body.error.message,
    );
  });

  it('обычный игрок и администратор получают 404 — существование не подтверждается', async () => {
    const t = await boot();
    for (const token of [t.player.token]) {
      expect((await request(t.server).get('/api/god/players').set(bearer(token))).status).toBe(404);
      expect(
        (
          await request(t.server)
            .post('/api/god/login')
            .set(bearer(token))
            .send({ password: GOD_PASSWORD })
        ).status,
      ).toBe(404);
    }
    await t.repos.users.setRole(t.player.id, 'ADMIN');
    expect(
      (await request(t.server).get('/api/god/players').set(bearer(t.player.token))).status,
    ).toBe(404);
  });

  it('без токена доступа — 401; у владельца без сессии режима бога — 401', async () => {
    const t = await boot();
    expect((await request(t.server).get('/api/god/players')).status).toBe(401);
    expect(
      (await request(t.server).get('/api/god/players').set(bearer(t.owner.token))).status,
    ).toBe(401);
    expect(
      (
        await request(t.server)
          .get('/api/god/players')
          .set(bearer(t.owner.token))
          .set('Cookie', 'tc_god=forged')
      ).status,
    ).toBe(401);
  });

  it('неверный пароль → 401 и запись в журнал; после 5 попыток блокировка 15 минут даже с верным паролем', async () => {
    const t = await boot();
    for (let i = 0; i < 5; i++) expect((await t.login('wrong-password')).res.status).toBe(401);
    const blocked = await t.login(GOD_PASSWORD);
    expect(blocked.res.status).toBe(429);
    expect(blocked.res.body.error.details.retryAfterSeconds).toBe(900);
    const kinds = t.repos.security.events.map((e) => e.kind);
    expect(kinds.filter((k) => k === 'god_login_failed')).toHaveLength(5);
    expect(kinds).toContain('god_login_blocked');
    // через 15 минут можно снова
    t.clock.advance(15 * 60 + 1);
    expect((await t.login(GOD_PASSWORD)).res.status).toBe(200);
  });

  it('вход: cookie httpOnly/strict, заголовки noindex, сессия скользящая и истекает', async () => {
    const t = await boot();
    const { res, cookie } = await t.login();
    expect(res.status).toBe(200);
    const raw = (res.headers['set-cookie'] as unknown as string[])[0]!;
    expect(raw).toMatch(/HttpOnly/i);
    expect(raw).toMatch(/SameSite=Strict/i);
    expect(raw).toMatch(/Path=\/api\/god/);
    expect(res.headers['x-robots-tag']).toContain('noindex');

    const get = () =>
      request(t.server).get('/api/god/session').set(bearer(t.owner.token)).set('Cookie', cookie);
    t.clock.advance(20 * 60);
    expect((await get()).status).toBe(200); // продлевает
    t.clock.advance(20 * 60);
    expect((await get()).status).toBe(200); // 40 минут с входа, но не более 30 без действий
    t.clock.advance(31 * 60);
    expect((await get()).status).toBe(401);
  });

  it('TOTP: без кода и с чужим кодом отказ; верный код пускает', async () => {
    const t = await boot({ totp: true });
    expect((await t.login(GOD_PASSWORD)).res.status).toBe(401);
    expect((await t.login(GOD_PASSWORD, '000000')).res.status).toBe(401);
    const ok = await t.login(GOD_PASSWORD, totpCode(TOTP_SECRET, t.clock.now().getTime()));
    expect(ok.res.status).toBe(200);
    expect(ok.res.body.totpRequired).toBe(true);
  });

  it('выход закрывает только свою сессию; входы с разных устройств независимы', async () => {
    const t = await boot();
    const a = await t.login();
    const b = await t.login();
    const get = (cookie: string) =>
      request(t.server).get('/api/god/session').set(bearer(t.owner.token)).set('Cookie', cookie);
    expect((await get(a.cookie)).status).toBe(200);
    expect((await get(b.cookie)).status).toBe(200);
    const out = await request(t.server)
      .post('/api/god/logout')
      .set(bearer(t.owner.token))
      .set('Cookie', b.cookie);
    expect(out.status).toBe(204);
    expect((await get(b.cookie)).status).toBe(401);
    expect((await get(a.cookie)).status).toBe(200);
    // аудит: вход и выход записаны
    const actions = t.repos.castles.admin.audit.map((e) => e.action);
    expect(actions.filter((x) => x === 'login')).toHaveLength(2);
    expect(actions).toContain('logout');
  });

  it('валидация: лишние поля в теле отвергаются', async () => {
    const t = await boot();
    const res = await request(t.server)
      .post('/api/god/login')
      .set(bearer(t.owner.token))
      .send({ password: GOD_PASSWORD, admin: true });
    expect(res.status).toBe(400);
  });
});

describe('режим бога: действия', () => {
  it('ресурсы: give/take/set, пределы, метка isGodAction и запись в аудит до/после', async () => {
    const t = await boot();
    const g = await t.god();
    const start = t.repos.castles.peek(t.player.id)!.resources.gold;

    const give = await g.act(t.player.id, {
      type: 'resources',
      op: 'give',
      resource: 'gold',
      amount: 1_000_000,
    });
    expect(give.status).toBe(200);
    expect(give.body.castle.resources.gold).toBeGreaterThanOrEqual(start + 1_000_000);
    const stored = t.repos.castles.peek(t.player.id)!;
    expect(stored.isGodAction).toBe(true);

    await g.act(t.player.id, {
      type: 'resources',
      op: 'take',
      resource: 'gold',
      amount: 5_000_000_000 % 1_000_000_000,
    });
    const set = await g.act(t.player.id, {
      type: 'resources',
      op: 'set',
      resource: 'gems',
      amount: 777,
    });
    expect(set.body.castle.gems).toBe(777);
    // потолок значения
    const huge = await g.act(t.player.id, {
      type: 'resources',
      op: 'give',
      resource: 'wood',
      amount: 1_000_000_000,
    });
    const huge2 = await g.act(t.player.id, {
      type: 'resources',
      op: 'give',
      resource: 'wood',
      amount: 1_000_000_000,
    });
    const huge3 = await g.act(t.player.id, {
      type: 'resources',
      op: 'give',
      resource: 'wood',
      amount: 1_000_000_000,
    });
    expect(huge.status + huge2.status + huge3.status).toBe(600);
    expect(t.repos.castles.peek(t.player.id)!.resources.wood).toBe(2_000_000_000);

    const audit = await g.call('get', '/audit?scope=god&pageSize=100');
    const entry = audit.body.items.find(
      (e: { action: string }) => e.action === 'act:give gold 1000000',
    );
    expect(entry).toMatchObject({
      scope: 'god',
      actor: { nickname: 'Хозяин' },
      target: { nickname: 'Артур' },
      params: { type: 'resources', op: 'give', resource: 'gold', amount: 1_000_000 },
    });
    expect(entry.before.resources.gold).toBe(start);
    expect(entry.after.resources.gold).toBeGreaterThanOrEqual(start + 1_000_000);
    expect(entry.ip).toBeTruthy();
  });

  it('повтор с тем же ключом не выполняет действие дважды и не дублирует аудит', async () => {
    const t = await boot();
    const g = await t.god();
    const key = idem();
    const action: GodAction = { type: 'resources', op: 'give', resource: 'gems', amount: 100 };
    const a = await g.act(t.player.id, action, key);
    const b = await g.act(t.player.id, action, key);
    expect(b.headers['idempotent-replay']).toBe('true');
    expect(b.body.castle.gems).toBe(a.body.castle.gems);
    expect(
      t.repos.castles.admin.audit.filter((e) => e.action === 'act:give gems 100'),
    ).toHaveLength(1);
    // тот же ключ с другим действием отвергается
    const other = await g.act(
      t.player.id,
      { type: 'resources', op: 'give', resource: 'gems', amount: 5 },
      key,
    );
    expect(other.status).toBe(422);
  });

  it('здания, армия, исследования, герой', async () => {
    const t = await boot();
    const g = await t.god();
    const b = await g.act(t.player.id, { type: 'building', key: 'barracks', level: 12 });
    expect(b.body.castle.buildings.find((x: { key: string }) => x.key === 'barracks').level).toBe(
      12,
    );
    await g.act(t.player.id, { type: 'army', unit: 'cavalry_3', count: 500 });
    expect(t.repos.castles.peek(t.player.id)!.army.cavalry_3?.count).toBe(500);
    await g.act(t.player.id, { type: 'research_all' });
    expect(t.repos.castles.peek(t.player.id)!.tech.farming).toBe(10);
    await g.act(t.player.id, { type: 'hero', level: 30 });
    await g.act(t.player.id, { type: 'hero_gear', slot: 'weapon', rarity: 5 });
    const hero = t.repos.castles.peek(t.player.id)!.hero!;
    expect(hero.level).toBe(30);
    expect(hero.items).toMatchObject([{ slot: 'weapon', rarity: 5, equipped: false }]);
    // ранение и воскрешение
    const cur = t.repos.castles.peek(t.player.id)!;
    t.repos.castles.seed({ ...cur, army: { cavalry_3: { count: 100, wounded: 400 } } });
    await g.act(t.player.id, { type: 'resurrect' });
    expect(t.repos.castles.peek(t.player.id)!.army.cavalry_3).toEqual({ count: 500, wounded: 0 });
  });

  it('время: +1 час заканчивает постройку; finish завершает всё сразу', async () => {
    const t = await boot();
    const g = await t.god();
    await request(t.server)
      .post('/api/castle/buildings/farm/upgrade')
      .set(bearer(t.player.token))
      .set('Idempotency-Key', idem());
    expect(t.repos.castles.peek(t.player.id)!.tasks).toHaveLength(1);
    const skip = await g.act(t.player.id, { type: 'time', seconds: 30 * 86_400 });
    expect(skip.body.castle.tasks).toHaveLength(0);
    expect(t.repos.castles.peek(t.player.id)!.levels.farm).toBe(2);

    await request(t.server)
      .post('/api/castle/buildings/sawmill/upgrade')
      .set(bearer(t.player.token))
      .set('Idempotency-Key', idem());
    const fin = await g.act(t.player.id, { type: 'finish' });
    expect(fin.body.castle.tasks).toHaveLength(0);
    expect(t.repos.castles.peek(t.player.id)!.levels.sawmill).toBe(2);
  });

  it('телепорт: занятая клетка — 409, свободная — успех; щит; сундуки и ускорители', async () => {
    const t = await boot();
    const g = await t.god();
    const other = t.repos.castles.peek(t.other.id)!;
    const busy = await g.act(t.player.id, { type: 'teleport', x: other.x!, y: other.y! });
    expect(busy.status).toBe(409);
    const free = await g.act(t.player.id, { type: 'teleport', x: 3, y: 4 });
    expect(free.body.castle.position).toEqual({ x: 3, y: 4 });
    const sh = await g.act(t.player.id, { type: 'shield', hours: 0 });
    expect(sh.body.castle.shieldUntil).toBeNull();
    await g.act(t.player.id, { type: 'chest', kind: 'gold', count: 3 });
    await g.act(t.player.id, { type: 'booster', booster: 'boost_1h', count: 2 });
    const inv = await request(t.server).get('/api/inventory').set(bearer(t.player.token));
    expect(inv.body.chests.gold).toBe(3);
    expect(inv.body.boosters.boost_1h).toBe(2);
  });

  it('тронутый режимом бога замок исключён из рейтинга; сброс возвращает честное состояние', async () => {
    const t = await boot();
    const g = await t.god();
    await g.act(t.other.id, { type: 'army', unit: 'infantry_5', count: 100_000 });
    const before = await request(t.server)
      .get('/api/leagues/current')
      .query({ scope: 'top100', metric: 'power' })
      .set(bearer(t.player.token));
    expect(before.body.entries.map((e: { nickname: string }) => e.nickname)).not.toContain('Борис');
    await g.act(t.other.id, { type: 'reset' });
    expect(t.repos.castles.peek(t.other.id)!.isGodAction).toBe(false);
    const after = await request(t.server)
      .get('/api/leagues/current')
      .query({ scope: 'top100', metric: 'power' })
      .set(bearer(t.player.token));
    expect(after.body.entries.map((e: { nickname: string }) => e.nickname)).toContain('Борис');
  });

  it('экономические события god-действий помечены и не попадают в статистику', async () => {
    const t = await boot();
    const g = await t.god();
    await g.act(t.player.id, { type: 'resources', op: 'give', resource: 'gold', amount: 999_999 });
    const events = t.repos.castles.economy.filter((e) => e.kind === 'god_resources');
    expect(events.length).toBeGreaterThan(0);
    expect(events.every((e) => e.isGodAction)).toBe(true);
    await t.repos.users.setRole(t.player.id, 'ADMIN');
    const stats = await request(t.server).get('/api/admin/stats').set(bearer(t.player.token));
    expect(stats.body.economy.gained.gold).toBeLessThan(999_999);
  });

  it('снимок и восстановление', async () => {
    const t = await boot();
    const g = await t.god();
    const snap = await g.call('post', `/players/${t.player.id}/snapshots`).send({ label: 'до' });
    expect(snap.status).toBe(200);
    await g.act(t.player.id, { type: 'building', key: 'castle', level: 15 });
    await g.act(t.player.id, { type: 'resources', op: 'set', resource: 'gold', amount: 1 });
    const restored = await g
      .call('post', `/players/${t.player.id}/snapshots/${snap.body.id}/restore`)
      .set('Idempotency-Key', idem());
    expect(restored.status).toBe(200);
    const cur = t.repos.castles.peek(t.player.id)!;
    expect(cur.levels.castle).toBe(5);
    expect(cur.resources.gold).toBeGreaterThan(1);
    const view = await g.call('get', `/players/${t.player.id}`);
    expect(view.body.snapshots).toMatchObject([{ label: 'до' }]);
    const missing = await g
      .call(
        'post',
        `/players/${t.player.id}/snapshots/${'a'.repeat(8)}-aaaa-4aaa-8aaa-${'a'.repeat(12)}/restore`,
      )
      .set('Idempotency-Key', idem());
    expect(missing.status).toBe(404);
  });

  it('карта: сброс клетки; симулятор боя не меняет данные и умеет форсировать исход', async () => {
    const t = await boot();
    const g = await t.god();
    expect((await g.call('post', '/map/cell-reset').send({ x: 10, y: 10 })).status).toBe(204);
    expect((await g.call('post', '/map/cell-reset').send({ x: MAP_SIZE, y: 10 })).status).toBe(400);

    const body = { attacker: { infantry_1: 30 }, defender: { infantry_1: 34 }, seed: 5 };
    const before = JSON.stringify(t.repos.castles.peek(t.player.id));
    const plain = await g.call('post', '/simulate').send(body);
    expect(plain.status).toBe(200);
    expect(plain.body.result.rounds.length).toBeGreaterThan(0);
    expect(plain.body.result.winner).toBe('defender');
    expect(plain.body.forcedBonus).toBe(0);
    const again = await g.call('post', '/simulate').send(body);
    expect(again.body.result).toEqual(plain.body.result); // тот же seed — тот же бой

    for (const force of ['attacker', 'defender'] as const) {
      const forced = await g.call('post', '/simulate').send({ ...body, force });
      expect(forced.body.result.winner).toBe(force);
    }
    const flipped = await g.call('post', '/simulate').send({ ...body, force: 'attacker' });
    expect(flipped.body.forcedBonus).toBeGreaterThan(0);
    // пустой отряд победить не может ни при каких бонусах
    const impossible = await g
      .call('post', '/simulate')
      .send({ attacker: {}, defender: { infantry_5: 1000 }, seed: 1, force: 'attacker' });
    expect(impossible.status).toBe(409);
    expect(JSON.stringify(t.repos.castles.peek(t.player.id))).toBe(before);
  });

  it('несуществующий игрок — 404, неверное тело действия — 400', async () => {
    const t = await boot();
    const g = await t.god();
    expect((await g.act('b1b1b1b1-b1b1-41b1-81b1-b1b1b1b1b1b1', { type: 'finish' })).status).toBe(
      404,
    );
    const bad = await g
      .call('post', `/players/${t.player.id}/act`)
      .set('Idempotency-Key', idem())
      .send({ type: 'resources', op: 'give', resource: 'gold', amount: -5 });
    expect(bad.status).toBe(400);
    const unknown = await g
      .call('post', `/players/${t.player.id}/act`)
      .set('Idempotency-Key', idem())
      .send({ type: 'nuke' });
    expect(unknown.status).toBe(400);
  });
});

describe('режим бога: игроки, баланс, отладка', () => {
  it('поиск и карточка игрока', async () => {
    const t = await boot();
    const g = await t.god();
    const found = await g.call('get', '/players?q=артур');
    expect(found.body.items.map((u: { nickname: string }) => u.nickname)).toEqual(['Артур']);
    const card = await g.call('get', `/players/${t.player.id}`);
    expect(card.body).toMatchObject({ user: { nickname: 'Артур' }, godTouched: false });
    expect(card.body.castle.buildings.length).toBeGreaterThan(5);
  });

  it('бан, немота, роль администратора; владельца трогать нельзя', async () => {
    const t = await boot();
    const g = await t.god();
    expect(
      (await g.call('post', `/players/${t.player.id}/ban`).send({ hours: 1, reason: 'тест бана' }))
        .status,
    ).toBe(200);
    expect((await request(t.server).get('/api/castle').set(bearer(t.player.token))).status).toBe(
      403,
    );
    expect((await g.call('post', `/players/${t.player.id}/unban`)).status).toBe(200);
    expect((await request(t.server).get('/api/castle').set(bearer(t.player.token))).status).toBe(
      200,
    );
    expect(
      (await g.call('post', `/players/${t.player.id}/mute`).send({ minutes: 5, reason: 'тест' }))
        .status,
    ).toBe(200);
    expect(
      (await g.call('post', `/players/${t.player.id}/role`).send({ role: 'ADMIN' })).body.role,
    ).toBe('ADMIN');
    expect(
      (await request(t.server).get('/api/admin/stats').set(bearer(t.player.token))).status,
    ).toBe(200);
    expect(
      (await g.call('post', `/players/${t.owner.id}/ban`).send({ hours: 1, reason: 'себя' }))
        .status,
    ).toBe(422);
    expect(
      (await g.call('post', `/players/${t.owner.id}/role`).send({ role: 'PLAYER' })).status,
    ).toBe(403);
    const actions = t.repos.castles.admin.audit.map((e) => e.action);
    expect(actions).toEqual(expect.arrayContaining(['ban', 'unban', 'mute', 'set_role']));
  });

  it('вход под игроком: короткий токен работает в игре, но не в режиме бога; действия пишутся в аудит', async () => {
    const t = await boot();
    const g = await t.god();
    const res = await g.call('post', `/players/${t.player.id}/impersonate`);
    expect(res.status).toBe(200);
    expect(res.body.expiresIn).toBeLessThanOrEqual(600);
    expect(res.body.user.nickname).toBe('Артур');
    const token = res.body.accessToken as string;
    expect((await request(t.server).get('/api/castle').set(bearer(token))).status).toBe(200);
    const up = await request(t.server)
      .post('/api/castle/buildings/farm/upgrade')
      .set(bearer(token))
      .set('Idempotency-Key', idem());
    expect(up.status).toBe(200);
    // под чужим токеном режим бога недоступен, даже с cookie владельца
    expect(
      (await request(t.server).get('/api/god/players').set(bearer(token)).set('Cookie', g.cookie))
        .status,
    ).toBe(404);
    await new Promise((r) => setTimeout(r, 30));
    const logged = t.repos.castles.admin.audit.filter((e) => e.action === 'impersonated_request');
    expect(logged).toMatchObject([
      { actorId: t.owner.id, targetUserId: t.player.id, params: { method: 'POST', status: 200 } },
    ]);
    expect(t.repos.castles.admin.audit.map((e) => e.action)).toContain('impersonate');
    // войти под владельцем нельзя
    expect((await g.call('post', `/players/${t.owner.id}/impersonate`)).status).toBe(403);
    // срок токена короткий
    t.clock.advance(601);
    expect((await request(t.server).get('/api/castle').set(bearer(token))).status).toBe(401);
  });

  it('баланс: множители применяются на лету, ревизии и откат', async () => {
    const t = await boot();
    const g = await t.god();
    const cost = (res: request.Response) =>
      res.body.buildings.find((b: { key: string }) => b.key === 'farm').cost.gold as number;
    const base = cost(await request(t.server).get('/api/castle').set(bearer(t.player.token)));
    expect(base).toBe(buildingCost('farm', 2).gold);

    const put = await g.call('put', '/balance').send({ buildCost: 2 });
    expect(put.status).toBe(200);
    expect(put.body.balance.buildCost).toBe(2);
    expect(cost(await request(t.server).get('/api/castle').set(bearer(t.player.token)))).toBe(
      buildingCost('farm', 2).gold,
    );
    expect(buildingCost('farm', 2).gold).toBeGreaterThan(base);

    const revs = (await g.call('get', '/balance')).body.revisions as Array<{
      id: string;
      balance: { buildCost: number };
    }>;
    expect(revs).toHaveLength(1);
    await g.call('put', '/balance').send({ buildCost: 3, attack: 1.5 });
    const first = revs[0]!.id;
    const back = await g.call('post', '/balance/rollback').send({ revisionId: first });
    expect(back.body.balance).toMatchObject({ buildCost: 2, attack: 1 });
    expect(back.body.revisions).toHaveLength(3);
    expect(
      (
        await g
          .call('post', '/balance/rollback')
          .send({ revisionId: 'b1b1b1b1-b1b1-41b1-81b1-b1b1b1b1b1b1' })
      ).status,
    ).toBe(404);
    // границы и лишние поля
    expect((await g.call('put', '/balance').send({ buildCost: 100 })).status).toBe(400);
    expect((await g.call('put', '/balance').send({ buildCost: 2, hack: 1 })).status).toBe(400);
    expect(t.repos.castles.admin.audit.map((e) => e.action)).toEqual(
      expect.arrayContaining(['balance_set', 'balance_rollback']),
    );
  });

  it('объявление в мировой чат, роспуск братства, отладка', async () => {
    const t = await boot();
    const g = await t.god();
    expect(
      (await g.call('post', '/chat/announce').send({ text: 'Сервер перезагрузится' })).status,
    ).toBe(204);
    const hist = await request(t.server).get('/api/chat/world/history').set(bearer(t.player.token));
    expect(hist.body.at(-1).text).toBe('[System] Сервер перезагрузится');

    // братство создаёт игрок с Замком 5 и золотом
    const cur = t.repos.castles.peek(t.player.id)!;
    t.repos.castles.seed({
      ...cur,
      levels: { ...cur.levels, castle: 5 },
      resources: { ...cur.resources, gold: 5000 },
    });
    const made = await request(t.server)
      .post('/api/guilds')
      .set(bearer(t.player.token))
      .set('Idempotency-Key', idem())
      .send({ name: 'Волки' });
    expect(made.status).toBe(200);
    expect((await g.call('delete', `/guilds/${made.body.guild.id}`)).status).toBe(204);
    expect(
      (await request(t.server).get('/api/guilds/mine').set(bearer(t.player.token))).body.guild,
    ).toBeNull();

    const dbg = await g.call('get', '/debug');
    expect(dbg.body).toMatchObject({ redis: 'off', counts: { castles: 3 } });
    expect((await g.call('post', '/debug/reseed')).status).toBe(409); // в тестах не подключён
  });

  it('аудит: страницы, фильтр по цели; админка видит только свои записи', async () => {
    const t = await boot();
    const g = await t.god();
    for (let i = 0; i < 3; i++)
      await g.act(t.player.id, { type: 'resources', op: 'give', resource: 'gems', amount: i + 1 });
    const page = await g.call(
      'get',
      `/audit?scope=god&targetUserId=${t.player.id}&pageSize=2&page=1`,
    );
    expect(page.body).toMatchObject({ pageSize: 2, total: 3 });
    expect(page.body.items).toHaveLength(2);
    expect(page.body.items[0].createdAt >= page.body.items[1].createdAt).toBe(true);
    await t.repos.users.setRole(t.other.id, 'ADMIN');
    const adm = await request(t.server).get('/api/admin/audit').set(bearer(t.other.token));
    expect(adm.body.items.every((e: { scope: string }) => e.scope === 'admin')).toBe(true);
  });
});
