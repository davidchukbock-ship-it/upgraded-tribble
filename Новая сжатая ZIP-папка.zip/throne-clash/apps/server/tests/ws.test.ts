import type { AddressInfo } from 'node:net';
import type { FastifyInstance } from 'fastify';
import request from 'supertest';
import WebSocket from 'ws';
import { afterEach, describe, expect, it } from 'vitest';
import type { WsServerMessage } from '@tc/shared';
import { createMemoryRepositories } from '../src/modules/auth/auth.memory';
import { makeApp } from './helpers';

const HIGH = {
  AUTH_LOGIN_RATE_MAX: '1000',
  AUTH_REGISTER_RATE_MAX: '1000',
  AUTH_GUEST_RATE_MAX: '1000',
};

let app: FastifyInstance | undefined;
const sockets: WebSocket[] = [];
afterEach(async () => {
  for (const s of sockets.splice(0)) s.terminate();
  await app?.close();
  app = undefined;
});

async function boot(ws: { authTimeoutMs?: number; heartbeatMs?: number } = {}) {
  const repos = createMemoryRepositories();
  const made = await makeApp({ env: HIGH, deps: { repos, ws } });
  app = made.app;
  await app.listen({ port: 0, host: '127.0.0.1' });
  const port = (app.server.address() as AddressInfo).port;
  const register = async (nickname: string, email: string) => {
    const r = await request(app!.server)
      .post('/api/auth/register')
      .send({ email, password: 'Correct horse 42', nickname });
    return { token: r.body.accessToken as string, userId: r.body.user.id as string };
  };
  return { repos, clock: made.clock, port, register, app: made.app };
}

/** Клиент с очередью полученных сообщений и ожиданием нужного. */
function connect(port: number) {
  const ws = new WebSocket(`ws://127.0.0.1:${port}/ws`);
  sockets.push(ws);
  const got: WsServerMessage[] = [];
  const waiters: Array<() => void> = [];
  ws.on('message', (raw) => {
    got.push(JSON.parse(raw.toString()) as WsServerMessage);
    waiters.splice(0).forEach((w) => w());
  });
  const opened = new Promise<void>((res, rej) => {
    ws.once('open', () => res());
    ws.once('error', rej);
  });
  const closed = new Promise<{ code: number }>((res) => ws.once('close', (code) => res({ code })));
  const next = async <T extends WsServerMessage['type']>(
    type: T,
    from = 0,
  ): Promise<Extract<WsServerMessage, { type: T }>> => {
    for (let i = 0; i < 100; i++) {
      const hit = got.slice(from).find((m) => m.type === type);
      if (hit) return hit as Extract<WsServerMessage, { type: T }>;
      await new Promise<void>((res) => {
        waiters.push(res);
        setTimeout(res, 50);
      });
    }
    throw new Error(`не дождались сообщения ${type}; пришло: ${JSON.stringify(got)}`);
  };
  const send = (msg: unknown) => ws.send(typeof msg === 'string' ? msg : JSON.stringify(msg));
  return { ws, got, opened, closed, next, send };
}

describe('WebSocket /ws', () => {
  it('без аутентификации сообщения отвергаются; по таймауту соединение закрывается', async () => {
    const { port } = await boot({ authTimeoutMs: 150 });
    const c = connect(port);
    await c.opened;
    c.send({ type: 'chat.send', channel: 'world', text: 'hi' });
    expect(await c.next('error')).toMatchObject({ code: 'ERR_UNAUTHORIZED' });
    expect((await c.closed).code).toBe(4001);
  });

  it('неверный токен → ошибка и закрытие', async () => {
    const { port } = await boot();
    const c = connect(port);
    await c.opened;
    c.send({ type: 'auth', token: 'a.b.c' });
    expect(await c.next('error')).toMatchObject({ code: 'ERR_UNAUTHORIZED' });
    expect((await c.closed).code).toBe(4003);
  });

  it('аутентификация: ready с числом онлайн; второй игрок виден в presence; отключение обновляет счёт', async () => {
    const { port, register } = await boot();
    const a = await register('Артур', 'a@example.com');
    const b = await register('Борис', 'b@example.com');
    const ca = connect(port);
    await ca.opened;
    ca.send({ type: 'auth', token: a.token });
    expect(await ca.next('ready')).toMatchObject({ userId: a.userId, online: 1 });

    const cb = connect(port);
    await cb.opened;
    cb.send({ type: 'auth', token: b.token });
    expect(await cb.next('ready')).toMatchObject({ userId: b.userId, online: 2 });
    const seen = ca.got.length;
    cb.ws.close();
    await cb.closed;
    const p = await ca.next('presence', seen);
    expect(p.online).toBe(1);
  });

  it('чат по WebSocket: мировое сообщение получают все онлайн; брань маскируется; лимит даёт ошибку с ожиданием', async () => {
    const { port, register } = await boot();
    const a = await register('Артур', 'a@example.com');
    const b = await register('Борис', 'b@example.com');
    const ca = connect(port);
    const cb = connect(port);
    await Promise.all([ca.opened, cb.opened]);
    ca.send({ type: 'auth', token: a.token });
    cb.send({ type: 'auth', token: b.token });
    await Promise.all([ca.next('ready'), cb.next('ready')]);

    ca.send({ type: 'chat.send', channel: 'world', text: 'привет всем' });
    const msg = await cb.next('chat.message');
    expect(msg.message).toMatchObject({ channel: 'world', nickname: 'Артур', text: 'привет всем' });
    expect(await ca.next('chat.message')).toMatchObject({ message: { text: 'привет всем' } });

    for (let i = 0; i < 6; i++) ca.send({ type: 'chat.send', channel: 'world', text: `m${i}` });
    const err = await ca.next('error');
    expect(err).toMatchObject({ code: 'ERR_RATE_LIMITED' });
    expect(err.retryAfterSeconds).toBeGreaterThan(0);
  });

  it('личное сообщение доходит только адресату, чужой канал не подписать', async () => {
    const { port, register } = await boot();
    const a = await register('Артур', 'a@example.com');
    const b = await register('Борис', 'b@example.com');
    const c = await register('Виктор', 'c@example.com');
    const [ca, cb, cc] = [connect(port), connect(port), connect(port)];
    await Promise.all([ca.opened, cb.opened, cc.opened]);
    ca.send({ type: 'auth', token: a.token });
    cb.send({ type: 'auth', token: b.token });
    cc.send({ type: 'auth', token: c.token });
    await Promise.all([ca.next('ready'), cb.next('ready'), cc.next('ready')]);

    ca.send({ type: 'chat.send', channel: `dm:${b.userId}`, text: 'секрет' });
    expect((await cb.next('chat.message')).message).toMatchObject({
      channel: `dm:${a.userId}`,
      text: 'секрет',
    });
    await ca.next('chat.message');
    await new Promise((r) => setTimeout(r, 100));
    expect(cc.got.filter((m) => m.type === 'chat.message')).toHaveLength(0);

    // чужой канал гильдии и мусор
    ca.send({ type: 'chat.send', channel: 'guild', text: 'x' });
    expect(await ca.next('error')).toMatchObject({ code: 'ERR_REQUIREMENT_NOT_MET' });
  });

  it('мусор: невалидный JSON, неизвестный тип, слишком большое сообщение', async () => {
    const { port, register } = await boot();
    const a = await register('Артур', 'a@example.com');
    const ca = connect(port);
    await ca.opened;
    ca.send('это не json');
    expect(await ca.next('error')).toMatchObject({ code: 'ERR_VALIDATION' });
    ca.send({ type: 'hack' });
    expect(await ca.next('error', 1)).toMatchObject({ code: 'ERR_VALIDATION' });
    ca.send({ type: 'auth', token: a.token });
    await ca.next('ready');
    ca.send({ type: 'ping' });
    expect(await ca.next('pong')).toEqual({ type: 'pong' });
    ca.send('x'.repeat(8000));
    expect((await ca.closed).code).toBe(1009);
  });

  it('уведомление о достроенном здании приходит онлайн-клиенту сразу при чтении замка', async () => {
    const { port, register, repos, clock } = await boot();
    const a = await register('Артур', 'a@example.com');
    await request(app!.server).get('/api/castle').set('Authorization', `Bearer ${a.token}`);
    const cur = repos.castles.peek(a.userId)!;
    repos.castles.seed({
      ...cur,
      tasks: [
        {
          id: '11111111-1111-4111-8111-111111111111',
          key: 'forge',
          toLevel: 1,
          startedAt: clock.now(),
          finishesAt: new Date(clock.now().getTime() + 30_000),
          paid: { gold: 0, wood: 0, stone: 0, food: 0 },
          isGodAction: false,
        },
      ],
    });
    const ca = connect(port);
    await ca.opened;
    ca.send({ type: 'auth', token: a.token });
    await ca.next('ready');
    clock.advance(31);
    await request(app!.server).get('/api/castle').set('Authorization', `Bearer ${a.token}`);
    const n = await ca.next('notification');
    expect(n.notification).toMatchObject({
      kind: 'build.done',
      payload: { building: 'forge', level: 1 },
      read: false,
    });
  });

  it('повторная аутентификация тем же игроком допустима, чужим — нет', async () => {
    const { port, register } = await boot();
    const a = await register('Артур', 'a@example.com');
    const b = await register('Борис', 'b@example.com');
    const ca = connect(port);
    await ca.opened;
    ca.send({ type: 'auth', token: a.token });
    await ca.next('ready');
    const seen = ca.got.length;
    ca.send({ type: 'auth', token: a.token });
    await ca.next('ready', seen);
    const seen2 = ca.got.length;
    ca.send({ type: 'auth', token: b.token });
    expect(await ca.next('error', seen2)).toMatchObject({ code: 'ERR_FORBIDDEN' });
  });
});
