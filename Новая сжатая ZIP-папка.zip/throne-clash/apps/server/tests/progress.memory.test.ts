import { START_BUILDINGS, START_GEMS } from '@tc/shared';
import { FakeClock } from '../src/lib/clock';
import { createMemoryRepositories } from '../src/modules/auth/auth.memory';
import { castleFor, userFor } from './repository.contract';
import { progressSuite } from './progress.suite';

let n = 0;

progressSuite('in-memory', async () => {
  const repos = createMemoryRepositories();
  const clock = new FakeClock();
  return {
    repo: repos.castles,
    users: repos.users,
    clock,
    async markGod(userId) {
      repos.castles.castles.get(userId)!.isGodAction = true;
    },
    async addPlayer(name) {
      const user = await repos.users.createWithCastle(
        { ...userFor(name, `p${n++}@example.com`), isGuest: false, createdAt: clock.now() },
        {
          ...castleFor(),
          buildings: START_BUILDINGS,
          resourcesUpdatedAt: clock.now(),
          gems: START_GEMS,
        },
      );
      return user.id;
    },
  };
});
