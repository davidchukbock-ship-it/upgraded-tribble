import { PrismaClient } from '@prisma/client';
import { afterAll, beforeEach, describe, expect, it } from 'vitest';
import { MAX_BUILDING_LEVEL } from '@tc/shared';
import { seedDatabase } from '../src/db/seed';
import { resetTables, testDatabaseUrl } from './test-db';

const url = testDatabaseUrl();

describe.runIf(url)('seed', () => {
  const db = new PrismaClient({ datasourceUrl: url });
  beforeEach(async () => {
    await resetTables(db, ['SecurityLog', 'RefreshToken', 'Building', 'Castle', 'User', 'World']);
  });
  afterAll(() => db.$disconnect());

  it('создаёт мир, ботов и демо-игроков; повторный запуск ничего не дублирует', async () => {
    const first = await seedDatabase(db, { demoPlayers: { password: 'Demo-pass-12345' } });
    expect(first).toEqual({ bots: 24, demos: 3 });
    expect(await db.world.count()).toBe(1);
    expect(await db.user.count()).toBe(27);
    expect(await db.castle.count()).toBe(27);

    const second = await seedDatabase(db, { demoPlayers: { password: 'Demo-pass-12345' } });
    expect(second).toEqual({ bots: 0, demos: 0 });
    expect(await db.user.count()).toBe(27);
  });

  it('боты не могут войти (нет email и пароля), демо-игроки — могут', async () => {
    await seedDatabase(db, { demoPlayers: { password: 'Demo-pass-12345' } });
    const bots = await db.user.findMany({ where: { isBot: true } });
    expect(bots).toHaveLength(24);
    expect(bots.every((b) => b.email === null && b.passwordHash === null)).toBe(true);
    const demo = await db.user.findUniqueOrThrow({ where: { email: 'demo1@example.com' } });
    expect(demo.passwordHash).toMatch(/^\$argon2id\$/);
    expect(demo.passwordHash).not.toContain('Demo-pass');
  });

  it('уровни зданий допустимы, замок не ниже остальных зданий', async () => {
    await seedDatabase(db, {});
    const castles = await db.castle.findMany({ include: { buildings: true } });
    for (const c of castles) {
      const castle = c.buildings.find((b) => b.key === 'castle');
      expect(castle).toBeDefined();
      for (const b of c.buildings) {
        expect(b.level).toBeGreaterThanOrEqual(1);
        expect(b.level).toBeLessThanOrEqual(MAX_BUILDING_LEVEL);
        expect(b.level).toBeLessThanOrEqual(castle!.level);
      }
    }
  });

  it('детерминирован: один seed — одинаковые боты', async () => {
    await seedDatabase(db, { seed: 7 });
    const snap = async () =>
      (
        await db.user.findMany({
          orderBy: { nickname: 'asc' },
          include: { castles: { include: { buildings: true } } },
        })
      ).map((u) => [
        u.nickname,
        u.crest,
        u.castles[0]?.gold,
        u.castles[0]?.buildings
          .map((b) => `${b.key}${b.level}`)
          .sort()
          .join(),
      ]);
    const a = await snap();
    await resetTables(db, ['Building', 'Castle', 'User', 'World']);
    await seedDatabase(db, { seed: 7 });
    expect(await snap()).toEqual(a);
  });

  it('без demoPlayers (production) демо-аккаунтов нет', async () => {
    await seedDatabase(db, { demoPlayers: null });
    expect(await db.user.count({ where: { isBot: false } })).toBe(0);
  });
});
