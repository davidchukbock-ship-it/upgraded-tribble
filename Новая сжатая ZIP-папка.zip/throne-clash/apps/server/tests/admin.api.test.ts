import type { FastifyInstance } from 'fastify';
import request from 'supertest';
import { afterEach, describe, expect, it } from 'vitest';
import { createMemoryRepositories } from '../src/modules/auth/auth.memory';
import { makeApp } from './helpers';

let app: FastifyInstance | undefined;
afterEach(async () => {
  await app?.close();
  app = undefined;
});

let seq = 0;
const idem = () => `admin-api-${Date.now()}-${seq++}`;
const bearer = (t: string) => ({ Authorization: `Bearer ${t}` });

async function boot(env: Record<string, string> = {}) {
  const repos = createMemoryRepositories();
  const made = await makeApp({
    env: {
      AUTH_LOGIN_RATE_MAX: '1000',
      AUTH_REGISTER_RATE_MAX: '1000',
      AUTH_GUEST_RATE_MAX: '1000',
      JWT_ACCESS_TTL_SECONDS: '86400',
      OWNER_EMAIL: 'owner@example.com',
      ...env,
    },
    deps: { repos },
  });
  app = made.app;
  const server = made.app.server;
  const register = async (email: string, nickname: string) => {
    const res = await request(server)
      .post('/api/auth/register')
      .send({ email, password: 'Correct horse 42', nickname });
    await request(server).get('/api/castle').set(bearer(res.body.accessToken));
    return { token: res.body.accessToken as string, id: res.body.user.id as string };
  };
  const owner = await register('owner@example.com', 'Хозяин');
  await repos.users.setRole(owner.id, 'OWNER');
  const admin = await register('admin@example.com', 'Модератор');
  await repos.users.setRole(admin.id, 'ADMIN');
  const player = await register('p@example.com', 'Артур');
  const other = await register('q@example.com', 'Борис');
  const as = (t: string) => ({
    get: (p: string) => request(server).get(`/api/admin${p}`).set(bearer(t)),
    post: (p: string) => request(server).post(`/api/admin${p}`).set(bearer(t)),
  });
  return { ...made, repos, server, owner, admin, player, other, as, register };
}

describe('админ-панель: права', () => {
  it('игроку и анониму закрыто; отказ игроку попадает в журнал безопасности', async () => {
    const t = await boot();
    for (const path of ['/stats', '/users', '/logs', '/reports', '/audit']) {
      expect((await t.as(t.player.token).get(path)).status).toBe(403);
      expect((await request(t.server).get(`/api/admin${path}`)).status).toBe(401);
    }
    expect(
      (
        await t
          .as(t.player.token)
          .post(`/users/${t.other.id}/ban`)
          .send({ hours: 1, reason: 'просто так' })
      ).status,
    ).toBe(403);
    expect(
      t.repos.security.events.some((e) => e.kind === 'admin_denied' && e.userId === t.player.id),
    ).toBe(true);
    expect((await t.as(t.admin.token).get('/stats')).status).toBe(200);
    expect((await t.as(t.owner.token).get('/stats')).status).toBe(200);
  });

  it('роль в БД OWNER без совпадения OWNER_EMAIL не даёт прав администратора', async () => {
    const t = await boot();
    await t.repos.users.setRole(t.player.id, 'OWNER');
    // effectiveRole понижает такого «владельца» до игрока
    expect((await t.as(t.player.token).get('/stats')).status).toBe(403);
  });

  it('модерировать нельзя себя и владельца; администратора — только владелец', async () => {
    const t = await boot();
    const ban = (who: { id: string }, token: string) =>
      t.as(token).post(`/users/${who.id}/ban`).send({ hours: 1, reason: 'проверка' });
    expect((await ban(t.admin, t.admin.token)).status).toBe(422);
    expect((await ban(t.owner, t.admin.token)).status).toBe(403);
    expect((await ban(t.owner, t.owner.token)).status).toBe(422);
    const second = await t.register('adm2@example.com', 'Модератор2');
    await t.repos.users.setRole(second.id, 'ADMIN');
    expect((await ban(second, t.admin.token)).status).toBe(403);
    expect((await ban(second, t.owner.token)).status).toBe(200);
  });
});

describe('админ-панель: модерация', () => {
  it('бан: вход и запросы закрываются сразу, сессии отозваны; разбан возвращает доступ; всё в аудите', async () => {
    const t = await boot();
    const ban = await t
      .as(t.admin.token)
      .post(`/users/${t.player.id}/ban`)
      .send({ hours: 2, reason: 'читерство' });
    expect(ban.status).toBe(200);
    expect(ban.body).toMatchObject({ nickname: 'Артур', banReason: 'читерство' });
    expect((await request(t.server).get('/api/castle').set(bearer(t.player.token))).status).toBe(
      403,
    );
    const login = await request(t.server)
      .post('/api/auth/login')
      .send({ email: 'p@example.com', password: 'Correct horse 42' });
    expect(login.status).toBe(403);
    expect(
      [...t.repos.sessions.sessions.values()]
        .filter((s) => s.userId === t.player.id)
        .every((s) => s.revokedAt),
    ).toBe(true);

    t.clock.advance(3 * 3600);
    expect((await request(t.server).get('/api/castle').set(bearer(t.player.token))).status).toBe(
      200,
    ); // срок вышел

    await t
      .as(t.admin.token)
      .post(`/users/${t.other.id}/ban`)
      .send({ hours: null, reason: 'навсегда' });
    expect((await request(t.server).get('/api/castle').set(bearer(t.other.token))).status).toBe(
      403,
    );
    expect((await t.as(t.admin.token).post(`/users/${t.other.id}/unban`)).status).toBe(200);
    expect((await request(t.server).get('/api/castle').set(bearer(t.other.token))).status).toBe(
      200,
    );

    const audit = await t.as(t.owner.token).get('/audit?pageSize=50');
    const actions = audit.body.items.map((e: { action: string }) => e.action);
    expect(actions).toEqual(expect.arrayContaining(['ban', 'unban']));
    expect(
      audit.body.items.find(
        (e: { action: string; params: { reason: string } }) =>
          e.action === 'ban' && e.params.reason === 'читерство',
      ),
    ).toMatchObject({
      scope: 'admin',
      actor: { nickname: 'Модератор' },
      params: { reason: 'читерство' },
    });
  });

  it('немота запрещает чат до конца срока', async () => {
    const t = await boot();
    const mute = await t
      .as(t.admin.token)
      .post(`/users/${t.player.id}/mute`)
      .send({ minutes: 10, reason: 'спам' });
    expect(mute.body.mutedUntil).toBeTruthy();
    const say = () =>
      request(t.server)
        .post('/api/chat/world/messages')
        .set(bearer(t.player.token))
        .send({ text: 'привет' });
    expect((await say()).status).toBe(403);
    t.clock.advance(11 * 60);
    expect((await say()).status).toBe(200);
    await t
      .as(t.admin.token)
      .post(`/users/${t.player.id}/mute`)
      .send({ minutes: 10, reason: 'ещё раз' });
    await t.as(t.admin.token).post(`/users/${t.player.id}/unmute`);
    expect((await say()).status).toBe(200);
  });

  it('кристаллы поддержки: начисление, идемпотентность, лимит, след в аудите и экономике', async () => {
    const t = await boot();
    const before = t.repos.castles.peek(t.player.id)!.gems;
    const key = idem();
    const grant = () =>
      t
        .as(t.admin.token)
        .post(`/users/${t.player.id}/grant`)
        .set('Idempotency-Key', key)
        .send({ amount: 500, reason: 'компенсация' });
    expect((await grant()).status).toBe(200);
    const again = await grant();
    expect(again.headers['idempotent-replay']).toBe('true');
    expect(t.repos.castles.peek(t.player.id)!.gems).toBe(before + 500);
    expect(t.repos.castles.economy.some((e) => e.kind === 'admin_grant' && !e.isGodAction)).toBe(
      true,
    );
    expect(t.repos.castles.peek(t.player.id)!.isGodAction).toBe(false);
    expect(
      (
        await t
          .as(t.admin.token)
          .post(`/users/${t.player.id}/grant`)
          .set('Idempotency-Key', idem())
          .send({ amount: 10_001, reason: 'много' })
      ).status,
    ).toBe(400);
    const entry = t.repos.castles.admin.audit.find((e) => e.action === 'grant_gems')!;
    expect(entry).toMatchObject({
      before: { gems: before },
      after: { gems: before + 500 },
      targetUserId: t.player.id,
    });
  });

  it('валидация тел: причина обязательна, лишние поля запрещены, id — uuid', async () => {
    const t = await boot();
    const post = (path: string, body: object) => t.as(t.admin.token).post(path).send(body);
    expect((await post(`/users/${t.player.id}/ban`, { hours: 1 })).status).toBe(400);
    expect(
      (await post(`/users/${t.player.id}/ban`, { hours: 0, reason: 'нулевой срок' })).status,
    ).toBe(400);
    expect(
      (await post(`/users/${t.player.id}/ban`, { hours: 1, reason: 'ok ok', role: 'OWNER' }))
        .status,
    ).toBe(400);
    expect((await post('/users/not-a-uuid/ban', { hours: 1, reason: 'ok ok' })).status).toBe(400);
    expect(
      (await post('/users/b1b1b1b1-b1b1-41b1-81b1-b1b1b1b1b1b1/ban', { hours: 1, reason: 'ok ok' }))
        .status,
    ).toBe(404);
  });
});

describe('админ-панель: обзор', () => {
  it('игроки: поиск по нику, почте и id, страницы', async () => {
    const t = await boot();
    const byNick = await t.as(t.admin.token).get('/users?q=артур');
    expect(byNick.body.items.map((u: { nickname: string }) => u.nickname)).toEqual(['Артур']);
    const byMail = await t.as(t.admin.token).get('/users?q=q@example');
    expect(byMail.body.items[0].email).toBe('q@example.com');
    const byId = await t.as(t.admin.token).get(`/users?q=${t.other.id}`);
    expect(byId.body.total).toBe(1);
    const page = await t.as(t.admin.token).get('/users?pageSize=2&page=2');
    expect(page.body).toMatchObject({ page: 2, pageSize: 2, total: 4 });
    expect(page.body.items).toHaveLength(2);
    expect((await t.as(t.admin.token).get('/users?pageSize=1000')).status).toBe(400);
  });

  it('статистика: игроки, активность, экономика за сутки без действий режима бога', async () => {
    const t = await boot();
    await t
      .as(t.admin.token)
      .post(`/users/${t.player.id}/ban`)
      .send({ hours: 5, reason: 'проверка' });
    const stats = await t.as(t.admin.token).get('/stats');
    expect(stats.body.users).toMatchObject({ total: 4, banned: 1 });
    expect(stats.body.activity).toMatchObject({ new24h: 4, active24h: 4, online: 0 });
    expect(stats.body.reportsOpen).toBe(0);
    expect(Object.keys(stats.body.economy.gained).sort()).toEqual([
      'food',
      'gems',
      'gold',
      'stone',
      'wood',
    ]);
  });

  it('жалобы на чат видны с текстом и участниками', async () => {
    const t = await boot();
    const msg = await request(t.server)
      .post('/api/chat/world/messages')
      .set(bearer(t.player.token))
      .send({ text: 'плохое слово' });
    await request(t.server)
      .post('/api/chat/report')
      .set(bearer(t.other.token))
      .send({ messageId: msg.body.id, reason: 'оскорбление' });
    const list = await t.as(t.admin.token).get('/reports');
    expect(list.body.total).toBe(1);
    expect(list.body.items[0]).toMatchObject({
      reason: 'оскорбление',
      reporter: { nickname: 'Борис' },
      author: { nickname: 'Артур' },
      message: { channel: 'world', text: 'плохое слово' },
    });
    expect((await t.as(t.admin.token).get('/stats')).body.reportsOpen).toBe(1);
  });

  it('журнал безопасности: фильтр по виду и игроку', async () => {
    const t = await boot();
    await request(t.server)
      .post('/api/auth/login')
      .send({ email: 'p@example.com', password: 'wrong' });
    t.repos.security.events.push({
      kind: 'action_flood',
      userId: t.player.id,
      ip: '1.2.3.4',
      createdAt: t.clock.now(),
    });
    const all = await t.as(t.admin.token).get('/logs');
    expect(all.body.total).toBeGreaterThan(0);
    const flood = await t.as(t.admin.token).get(`/logs?kind=action_flood&userId=${t.player.id}`);
    expect(flood.body.items).toMatchObject([
      { kind: 'action_flood', nickname: 'Артур', ip: '1.2.3.4' },
    ]);
  });
});
