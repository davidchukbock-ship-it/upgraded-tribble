import { PrismaClient } from '@prisma/client';
import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { ensureMainWorld } from '../src/db/bootstrap';
import { createPrismaRepositories } from '../src/modules/auth/auth.repository';
import { castleFor, repositoryContract, userFor } from './repository.contract';
import { resetTables, testDatabaseUrl } from './test-db';

const url = testDatabaseUrl();

// В CI база обязательна: без неё пропуск тестов означал бы ложную зелёную сборку
describe('тестовая БД', () => {
  it.runIf(Boolean(process.env['CI']))('доступна в CI', () => {
    expect(url).toBeTruthy();
  });
});

describe.runIf(url)('Prisma + PostgreSQL', () => {
  const db = new PrismaClient({ datasourceUrl: url });

  beforeAll(async () => {
    await ensureMainWorld(db, 1);
  });
  beforeEach(async () => {
    await resetTables(db, [
      'AuditLog',
      'GodSession',
      'GodSnapshot',
      'BalanceRevision',
      'EconomyEvent',
      'SecurityLog',
      'RefreshToken',
      'Building',
      'Castle',
      'User',
    ]);
  });
  afterAll(async () => {
    await db.$disconnect();
  });

  repositoryContract('Prisma', async () => createPrismaRepositories(db));

  it('пользователь, замок и стартовые здания создаются одной транзакцией', async () => {
    const repos = createPrismaRepositories(db);
    const u = await repos.users.createWithCastle(userFor('Замковый', 'c@example.com'), castleFor());
    const castle = await db.castle.findUniqueOrThrow({
      where: { worldId_userId: { worldId: 'main', userId: u.id } },
      include: { buildings: true },
    });
    expect(castle).toMatchObject({
      gold: 1000,
      wood: 1000,
      stone: 1000,
      food: 1000,
      gems: 50,
      version: 1,
    });
    expect(castle.isGodAction).toBe(false);
    expect(castle.buildings.map((b) => `${b.key}:${b.level}`).sort()).toEqual([
      'castle:1',
      'farm:1',
    ]);
  });

  it('при ошибке замка (нет мира) пользователь не остаётся без замка', async () => {
    const repos = createPrismaRepositories(db);
    await expect(
      repos.users.createWithCastle(userFor('Сирота', 's@example.com'), {
        ...castleFor(),
        worldId: 'nope',
      }),
    ).rejects.toBeDefined();
    expect(await db.user.count()).toBe(0);
  });

  it('удаление пользователя каскадно убирает замок, здания и сессии', async () => {
    const repos = createPrismaRepositories(db);
    const u = await repos.users.createWithCastle(userFor('Каскад', 'k@example.com'), castleFor());
    await repos.sessions.create({
      userId: u.id,
      family: 'f',
      tokenHash: 'h',
      expiresAt: new Date('2027-01-01'),
      createdAt: new Date('2026-01-01'),
    });
    await db.user.delete({ where: { id: u.id } });
    expect(await db.castle.count()).toBe(0);
    expect(await db.building.count()).toBe(0);
    expect(await db.refreshToken.count()).toBe(0);
  });
});
