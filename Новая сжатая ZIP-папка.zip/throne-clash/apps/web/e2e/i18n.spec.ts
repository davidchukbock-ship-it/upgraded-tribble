import { expect, test } from '@playwright/test';
import { register } from './helpers';

/** Экраны без пользовательского текста (чат и список братств показывают чужие сообщения и названия на любом языке). */
const SCREENS = [
  '/castle',
  '/map',
  '/army',
  '/academy',
  '/hero',
  '/quests',
  '/chests',
  '/shop',
  '/leagues',
  '/notifications',
  '/reports',
  '/profile',
  '/more',
  '/play',
  '/donate',
];

test('английский интерфейс: язык переключается, сохраняется и на экранах нет русских строк', async ({
  page,
}) => {
  test.setTimeout(120_000);
  await register(page);
  await page.goto('/profile');
  await page.getByRole('radio', { name: 'English' }).click();
  await expect(page.locator('html')).toHaveAttribute('lang', 'en');

  for (const path of SCREENS) {
    await page.goto(path);
    await page.waitForLoadState('networkidle');
    await expect(page.locator('html')).toHaveAttribute('lang', 'en');
    // «Русский» в переключателе языков — название языка на нём самом, так и должно быть;
    // «Гость-xxxx» — ники гостей из параллельных тестов (данные игроков, а не интерфейс)
    const text = (await page.locator('body').innerText())
      .replace(/Русский|Українська/g, '')
      .replace(/Гость-\w*/g, '');
    // Ники игроков латиницей (helpers.newPlayer), поэтому любая кириллица — непереведённая строка
    const cyrillic = text.match(/[А-Яа-яЁё][А-Яа-яЁё\s.,!?-]{2,}/g);
    expect(cyrillic, `${path}: непереведённые строки`).toBeNull();
  }

  // Язык сохраняется в профиле и переживает перезагрузку
  await page.reload();
  await expect(page.locator('html')).toHaveAttribute('lang', 'en');
  await expect(page.getByRole('button', { name: 'Settings and menu' })).toBeVisible();
});

test('английский: меню, задания и сообщения об ошибках на английском', async ({ page }) => {
  await register(page);
  await page.goto('/profile');
  await page.getByRole('radio', { name: 'English' }).click();
  await page.goto('/quests');
  await expect(page.getByRole('heading', { level: 1, name: 'Quests' })).toBeVisible();
  await page.getByRole('button', { name: /Claim reward: day 1/ }).click();
  await expect(page.getByText('Reward received')).toBeVisible();
  await page.goto('/guild');
  await expect(page.getByText(/Castle level 5|You are not in a guild yet/i).first()).toBeVisible();
});
