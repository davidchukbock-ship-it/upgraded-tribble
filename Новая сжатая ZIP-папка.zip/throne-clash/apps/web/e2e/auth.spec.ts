import { expect, test } from '@playwright/test';
import { newPlayer, register } from './helpers';

test('регистрация → замок; перезагрузка сохраняет вход; выход и повторный вход', async ({
  page,
}) => {
  const player = await register(page);
  // на телефоне боковое меню скрыто — ник виден в профиле
  await page.goto('/profile');
  await expect(
    page.getByRole('heading', { level: 1, name: new RegExp(player.nickname) }),
  ).toBeVisible();

  await page.reload();
  await expect(
    page.getByRole('heading', { level: 1, name: new RegExp(player.nickname) }),
  ).toBeVisible();

  await page.getByRole('button', { name: 'Выйти', exact: true }).click();
  await expect(page).toHaveURL(/\/login$/);
  await page.goto('/castle');
  await expect(page).toHaveURL(/\/login$/); // без входа игровые экраны закрыты

  await page.getByLabel('Email').fill(player.email);
  await page.getByLabel('Пароль').fill(player.password);
  await page.getByRole('button', { name: 'Войти', exact: true }).click();
  await expect(page).toHaveURL(/\/castle$/); // вернулись на запрошенный экран
});

test('неверный пароль и занятый email показывают понятные ошибки', async ({ page, browser }) => {
  const player = newPlayer();
  await register(page, player);

  const other = await (await browser.newContext()).newPage();
  await other.goto('/login');
  await other.getByLabel('Email').fill(player.email);
  await other.getByLabel('Пароль').fill('totally-wrong-1');
  await other.getByRole('button', { name: 'Войти', exact: true }).click();
  await expect(other.getByText('Неверный email или пароль')).toBeVisible();

  await other.goto('/register');
  await other.getByLabel('Email').fill(player.email);
  await other.getByLabel('Ник').fill(`Drugoi ${Date.now().toString(36).slice(-6)}`);
  await other.getByLabel('Пароль').fill('Correct horse 42');
  await other.getByRole('button', { name: 'Зарегистрироваться' }).click();
  await expect(other.getByText('Этот email уже зарегистрирован')).toBeVisible();
  await other.context().close();
});

test('два игрока в разных браузерах не мешают друг другу', async ({ browser }) => {
  const a = await (await browser.newContext()).newPage();
  const b = await (await browser.newContext()).newPage();
  const pa = await register(a);
  const pb = await register(b);
  await a.goto('/profile');
  await b.goto('/profile');
  await expect(a.getByRole('heading', { level: 1 })).toContainText(pa.nickname);
  await expect(b.getByRole('heading', { level: 1 })).toContainText(pb.nickname);
  await a.context().close();
  await b.context().close();
});

test('гость: игра без email, затем привязка аккаунта', async ({ page }) => {
  await page.goto('/login');
  await page.getByRole('button', { name: 'Играть как гость' }).click();
  await expect(page).toHaveURL(/\/castle$/);
  await page.goto('/profile');
  await expect(page.getByRole('heading', { level: 1 })).toContainText('Гость-');
  const email = newPlayer().email;
  const form = page.getByRole('heading', { name: 'Сохраните прогресс' }).locator('..');
  await form.getByLabel('Email').fill(email);
  await form.getByLabel('Пароль').fill('Correct horse 42');
  await form.getByRole('button', { name: 'Привязать' }).click();
  await expect(page.getByText(email)).toBeVisible();
  await expect(page.getByRole('heading', { name: 'Сохраните прогресс' })).toBeHidden();
});

test('профиль: смена герба сохраняется после перезагрузки', async ({ page }) => {
  await register(page);
  await page.goto('/profile');
  await page.getByRole('radio', { name: 'Орёл' }).click();
  await expect(page.getByRole('radio', { name: 'Орёл' })).toBeChecked();
  await page.reload();
  await expect(page.getByRole('radio', { name: 'Орёл' })).toBeChecked();
});
