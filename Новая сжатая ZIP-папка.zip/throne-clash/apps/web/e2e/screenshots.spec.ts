import { mkdirSync } from 'node:fs';
import { resolve } from 'node:path';
import { expect, test, type APIRequestContext, type Page } from '@playwright/test';
import { GOD_PASSWORD, OWNER, loginAsOwner, newPlayer, register } from './helpers';
import { STRUCTURE_DEFS, STRUCTURE_KINDS, freeCells, type PlacedStructure } from '@tc/shared';

/**
 * Снимки экранов для README (`pnpm screenshots`). В обычный прогон не входят: нужен флаг SCREENSHOTS=1.
 * Игрок получает наполненный замок через настоящее API режима бога — так же, как это делает владелец.
 */
test.skip(!process.env['SCREENSHOTS'], 'только по запросу: pnpm screenshots');

const OUT = resolve(process.cwd(), '../../docs/screenshots');

async function ownerApi(request: APIRequestContext) {
  const login = await request.post('/api/auth/login', {
    data: { email: OWNER.email, password: OWNER.password },
  });
  const token = (await login.json()).accessToken as string;
  const auth = { Authorization: `Bearer ${token}` };
  const god = await request.post('/api/god/login', {
    headers: auth,
    data: { password: GOD_PASSWORD },
  });
  expect(god.ok()).toBe(true);
  return {
    find: async (nickname: string) =>
      (
        await (
          await request.get(`/api/god/players?q=${encodeURIComponent(nickname)}`, { headers: auth })
        ).json()
      ).items[0].id as string,
    act: async (id: string, action: object) => {
      const res = await request.post(`/api/god/players/${id}/act`, {
        headers: { ...auth, 'Idempotency-Key': crypto.randomUUID() },
        data: action,
      });
      expect(res.ok(), JSON.stringify(await res.json())).toBe(true);
    },
  };
}

test('снимки экранов для README', async ({ page, browser }, info) => {
  test.setTimeout(240_000);
  const mobile = info.project.name.startsWith('mobile');
  const tag = mobile ? 'mobile' : 'desktop';
  mkdirSync(OUT, { recursive: true });
  const shot = async (name: string, p: Page = page) => {
    await p.waitForLoadState('networkidle');
    await p.waitForTimeout(400); // анимации появления экрана
    await p.screenshot({ path: `${OUT}/${name}-${tag}.png`, fullPage: false });
  };

  if (!mobile) {
    await page.goto('/login');
    await shot('login');
  }

  const me = await register(page, newPlayer());
  const ownerCtx = await browser.newContext();
  const ownerPage = await ownerCtx.newPage();
  await loginAsOwner(ownerPage);
  const api = await ownerApi(ownerCtx.request);
  const id = await api.find(me.nickname);
  for (const [key, level] of [
    ['castle', 9],
    ['barracks', 6],
    ['farm', 7],
    ['sawmill', 6],
    ['quarry', 6],
    ['goldmine', 7],
    ['warehouse', 8],
    ['academy', 5],
    ['forge', 4],
    ['walls', 4],
    ['hospital', 3],
    ['territory', 2],
    ['fishery', 4],
    ['archertower', 5],
    ['diamondmine', 3],
    ['magetower', 3],
    ['ballistatower', 3],
  ] as const)
    await api.act(id, { type: 'building', key, level });
  await api.act(id, { type: 'fill' });
  await api.act(id, { type: 'army', unit: 'infantry_3', count: 240 });
  await api.act(id, { type: 'army', unit: 'archer_2', count: 180 });
  await api.act(id, { type: 'army', unit: 'cavalry_2', count: 90 });
  await api.act(id, { type: 'hero', level: 12 });
  await api.act(id, { type: 'hero_gear', slot: 'weapon', rarity: 4 });
  await api.act(id, { type: 'chest', kind: 'silver', count: 2 });
  await api.act(id, { type: 'resources', op: 'set', resource: 'gems', amount: 340 });
  await api.act(id, { type: 'shield', hours: 0 });
  // Город: по одной постройке каждого доступного вида, чтобы остров выглядел живым
  const login = await page.request.post('/api/auth/login', {
    data: { email: me.email, password: me.password },
  });
  const auth = { Authorization: `Bearer ${(await login.json()).accessToken as string}` };
  const placed: PlacedStructure[] = [];
  for (const kind of STRUCTURE_KINDS.filter((k) => STRUCTURE_DEFS[k].castle <= 9)) {
    const cell = freeCells(2, placed, kind)[kind === 'ship' ? 5 : 0];
    if (!cell) continue;
    const res = await page.request.post('/api/castle/structures', {
      headers: { ...auth, 'Idempotency-Key': crypto.randomUUID() },
      data: { kind, x: cell.x, y: cell.y },
    });
    if (res.ok()) placed.push({ id: kind, kind, x: cell.x, y: cell.y });
  }
  // Достраивается что-то в очереди — на снимке живая полоса времени
  await page.goto('/castle');
  await page.getByRole('button', { name: /Кузница/ }).click();
  await page
    .getByRole('dialog')
    .getByRole('button', { name: /Построить|Улучшить/ })
    .click();
  await page.goto('/castle');

  const screens: Array<[string, string]> = mobile
    ? [
        ['castle', '/castle'],
        ['map', '/map'],
        ['quests', '/quests'],
        ['army', '/army'],
      ]
    : [
        ['castle', '/castle'],
        ['map', '/map'],
        ['army', '/army'],
        ['academy', '/academy'],
        ['hero', '/hero'],
        ['quests', '/quests'],
        ['chests', '/chests'],
        ['shop', '/shop'],
        ['donate', '/donate'],
        ['leagues', '/leagues'],
        ['guild', '/guild'],
        ['chat', '/chat'],
        ['profile', '/profile'],
        ['play', '/play'],
      ];
  for (const [name, path] of screens) {
    await page.goto(path);
    await shot(name);
  }

  if (!mobile) {
    await page.goto('/play');
    await page.getByRole('tab', { name: 'Рыбалка' }).click();
    await page.getByRole('button', { name: 'Забросить' }).click();
    await page.getByRole('button', { name: 'Подсечь!' }).waitFor({ timeout: 8000 });
    await page.waitForTimeout(700);
    await shot('fishing');
    await page.getByRole('tab', { name: 'Руны' }).click();
    await page.waitForTimeout(1200);
    await shot('runes');
  }

  if (!mobile) {
    // Служебные экраны (в README не выносятся; лежат рядом для docs/GOD_MODE.md)
    await ownerPage.goto('/god');
    const pass = ownerPage.getByLabel('Пароль режима бога');
    if (await pass.isVisible().catch(() => false)) {
      await pass.fill(GOD_PASSWORD);
      await ownerPage.getByRole('button', { name: 'Войти' }).click();
    }
    await expect(ownerPage.getByText('GOD MODE', { exact: true })).toBeVisible();
    await shot('god', ownerPage);
    await ownerPage.goto('/admin');
    await ownerPage.waitForLoadState('networkidle');
    await shot('admin', ownerPage);
  }
  await ownerCtx.close();
});
