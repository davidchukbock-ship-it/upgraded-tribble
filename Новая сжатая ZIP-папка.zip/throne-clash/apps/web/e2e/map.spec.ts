import { expect, test, type Page } from '@playwright/test';
import { buildAndSpeedUp, newPlayer, register } from './helpers';

const noHorizontalScroll = async (page: Page) => {
  const report = await page.evaluate(() => {
    const w = document.documentElement.clientWidth;
    return {
      over: document.documentElement.scrollWidth - w,
      culprits: [...document.querySelectorAll('body *')]
        .filter((e) => e.getBoundingClientRect().right > w + 1)
        .slice(0, 5)
        .map((e) => `${e.tagName}[${(e.textContent ?? '').slice(0, 20)}]`),
    };
  });
  expect(report.over, `выступают: ${report.culprits.join(' | ')}`).toBeLessThanOrEqual(0);
};

test('карта: замок на месте, поиск по нику, переход к замку, без горизонтальной прокрутки', async ({
  page,
}) => {
  const me = await register(page);
  await page.goto('/map');
  const grid = page.getByRole('application');
  await expect(grid).toBeVisible();
  await expect(page.getByTestId('map-surface')).toBeVisible();
  // курсор стоит на своём замке
  await expect(page.getByRole('status').filter({ hasText: /Замок:/ })).toContainText(me.nickname);
  await noHorizontalScroll(page);

  await page.getByRole('button', { name: 'Найти' }).click();
  await page.getByLabel(/Ник или/).fill(me.nickname);
  await page.getByRole('list', { name: 'Результаты поиска' }).getByRole('button').first().click();
  await grid.focus();
  await page.keyboard.press('Enter');
  const dlg = page.getByRole('dialog');
  await expect(dlg).toContainText('Это ваш замок');
  await page.keyboard.press('Escape');
  await expect(dlg).toBeHidden();
});

test('разведка соседа: казарма → конница → отряд уходит, поход виден на карте', async ({
  page,
  browser,
}) => {
  // Второй игрок, чтобы было кого разведывать
  const other = await browser.newPage();
  const rival = await register(other, newPlayer());
  await other.goto('/castle');

  await register(page);
  await buildAndSpeedUp(page, /Казарма/);
  await expect(page.getByRole('button', { name: /Казарма/ })).toContainText('1');

  await page.goto('/army');
  const cav = page.getByRole('list', { name: 'Набор войск' }).locator(':scope > li').nth(2);
  await cav.getByRole('textbox').fill('3');
  await cav.getByRole('button', { name: 'Обучить' }).click();
  await page
    .getByRole('region', { name: 'Обучение' })
    .getByRole('button', { name: /Ускорить/ })
    .click();
  await expect(
    page
      .getByText('Кавалерия × 3')
      .or(page.getByText(/Кавалерия.*3/))
      .first(),
  ).toBeVisible();

  await page.goto('/map');
  await page.getByRole('button', { name: 'Найти' }).click();
  await page.getByLabel(/Ник или/).fill(rival.nickname);
  await page.getByRole('list', { name: 'Результаты поиска' }).getByRole('button').first().click();
  await page.getByRole('application').focus();
  await page.keyboard.press('Enter');
  const dlg = page.getByRole('dialog');
  await expect(dlg).toContainText(rival.nickname);
  await dlg.getByRole('radio', { name: 'Разведка' }).click();
  await dlg.getByRole('button', { name: /Все: Кавалерия/ }).click();
  await dlg.locator('button[type="submit"]').click();
  await expect(dlg).toBeHidden();

  await page.getByRole('button', { name: /^Походы/ }).click();
  const marches = page.getByRole('region', { name: 'Походы' });
  await expect(marches.getByText(new RegExp(`Разведка → ${rival.nickname}`))).toBeVisible();
  await expect(marches.getByRole('progressbar')).toBeVisible();
  await expect(marches.getByText('Отрядов в пути: 1 из 5')).toBeVisible();
  await noHorizontalScroll(page);

  await page.goto('/reports');
  await expect(page.getByText('Отчётов пока нет. Отправьте отряд с карты.')).toBeVisible();
  await noHorizontalScroll(page);
  await other.close();
});
