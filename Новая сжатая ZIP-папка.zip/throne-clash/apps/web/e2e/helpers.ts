import { expect, type Page } from '@playwright/test';
import { execFileSync } from 'node:child_process';

let seq = 0;
/** Уникальные данные игрока: тесты идут параллельно и на общей БД. */
export function newPlayer() {
  const id = `${Date.now().toString(36)}${(seq++).toString(36)}${Math.random().toString(36).slice(2, 6)}`;
  return {
    email: `e2e-${id}@example.com`,
    password: 'Correct horse 42',
    // Ник: буквы латиницей; хвост — короткий, чтобы уложиться в 20 символов
    nickname: `Rytsar ${id.slice(-8)}`,
  };
}

export async function register(page: Page, player = newPlayer()) {
  await page.goto('/register');
  await page.getByLabel('Email').fill(player.email);
  await page.getByLabel('Ник').fill(player.nickname);
  await page.getByLabel('Пароль').fill(player.password);
  await page.getByRole('button', { name: 'Зарегистрироваться' }).click();
  await expect(page).toHaveURL(/\/castle$/);
  return player;
}

export const OWNER = {
  email: 'owner-e2e@example.com',
  password: 'Correct horse 42',
  nickname: 'E2E Owner',
};
/** Пароль режима бога для e2e (его хеш — в playwright.config.ts). */
export const GOD_PASSWORD = 'e2e-god-password-2026';

/**
 * Владелец для e2e: аккаунт создаётся при первом запуске, роль OWNER выдаёт настоящая CLI (D-19) —
 * так проверяется и весь путь получения роли. Повторный запуск безопасен.
 */
export async function loginAsOwner(page: Page): Promise<void> {
  await page.request.post('/api/auth/register', {
    data: { email: OWNER.email, password: OWNER.password, nickname: OWNER.nickname },
  });
  execFileSync('pnpm', ['--filter', '@tc/server', 'owner:grant', '--', '--stdin'], {
    cwd: '../..',
    input: `${OWNER.password}\n`,
    env: { ...process.env, OWNER_EMAIL: OWNER.email },
    stdio: ['pipe', 'ignore', 'ignore'],
  });
  // Роль в клиенте берётся из сессии: перезагрузка подхватывает выданный OWNER; без сессии — обычный вход
  await page.goto('/castle');
  const email = page.getByLabel('Email');
  await page.waitForLoadState('networkidle');
  if (await email.isVisible()) {
    await email.fill(OWNER.email);
    await page.getByLabel('Пароль').fill(OWNER.password);
    await page.getByRole('button', { name: 'Войти' }).click();
  }
  await expect(page).toHaveURL(/\/castle$/);
}

export async function enterGodMode(page: Page): Promise<void> {
  await page.keyboard.press('Control+Shift+G');
  await expect(page).toHaveURL(/\/god$/);
  await page.getByLabel('Пароль режима бога').fill(GOD_PASSWORD);
  await page.getByRole('button', { name: 'Войти' }).click();
  await expect(page.getByText('GOD MODE', { exact: true })).toBeVisible();
}

/** Панель «Стройка» на экране замка: открывается кнопкой-плашкой поверх сцены. */
export async function openQueue(page: Page) {
  const region = page.getByRole('region', { name: 'Стройка' });
  if (!(await region.isVisible().catch(() => false)))
    await page.getByRole('button', { name: /^Стройка/ }).click();
  return region;
}

/** Строит и сразу ускоряет за кристалл (для сценариев, которым нужно готовое здание). */
export async function buildAndSpeedUp(page: Page, building: RegExp) {
  await page.getByRole('button', { name: building }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Построить' }).click();
  const queue = await openQueue(page);
  await queue.getByRole('button', { name: /Ускорить/ }).click();
}
