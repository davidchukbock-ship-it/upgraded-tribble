import { expect, test, type Page } from '@playwright/test';
import { buildAndSpeedUp, register } from './helpers';

const noHorizontalScroll = async (page: Page) => {
  const report = await page.evaluate(() => {
    const w = document.documentElement.clientWidth;
    const over = document.documentElement.scrollWidth - w;
    const culprits = [...document.querySelectorAll('body *')]
      .filter((e) => e.getBoundingClientRect().right > w + 1)
      .slice(0, 5)
      .map(
        (e) =>
          `${e.tagName}[${(e.textContent ?? '').slice(0, 20)}]@${Math.round(e.getBoundingClientRect().left)}-${Math.round(e.getBoundingClientRect().right)}`,
      );
    return { over, culprits };
  });
  expect(report.over, `выступают: ${report.culprits.join(' | ')}`).toBeLessThanOrEqual(0);
};

test('без Казармы и Академии экраны объясняют, что построить', async ({ page }) => {
  await register(page);
  await page.goto('/army');
  await expect(page.getByRole('heading', { name: 'Армия', exact: true })).toBeVisible();
  await expect(page.getByText('Постройте Казарму в замке').first()).toBeVisible();
  await noHorizontalScroll(page);

  await page.goto('/academy');
  await expect(
    page.getByText('Постройте Академию в замке, чтобы изучать технологии.'),
  ).toBeVisible();
  await noHorizontalScroll(page);
});

test('герой: очко навыка вкладывается и сохраняется после перезагрузки', async ({ page }) => {
  await register(page);
  await page.goto('/hero');
  await expect(page.getByText('Очков навыков: 1')).toBeVisible();
  await page.getByRole('button', { name: 'Улучшить: Боевой' }).click();
  await expect(page.getByText('Очков навыков: 0')).toBeVisible();
  await noHorizontalScroll(page);
  await page.reload();
  await expect(page.getByText('Очков навыков: 0')).toBeVisible();
});

test('Казарма → обучение пехоты: ресурсы списаны, партия в очереди, отмена возвращает половину', async ({
  page,
}) => {
  await register(page);
  await buildAndSpeedUp(page, /Казарма/);
  await expect(page.getByRole('button', { name: /Казарма/ })).toContainText('1');

  await page.goto('/army');
  const card = page.getByRole('list', { name: 'Набор войск' }).getByRole('listitem').first();
  await card.getByRole('textbox').fill('2');
  await card.getByRole('button', { name: 'Обучить' }).click();
  const queue = page.getByRole('region', { name: 'Обучение' });
  await expect(queue.getByRole('progressbar')).toBeVisible();
  await noHorizontalScroll(page);

  await queue.getByRole('button', { name: 'Отменить' }).click();
  await page.getByRole('alertdialog').getByRole('button', { name: 'Отменить' }).click();
  await expect(queue.getByRole('progressbar')).toBeHidden();
});
