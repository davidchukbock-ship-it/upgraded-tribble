import { expect, test } from '@playwright/test';
import { openQueue, register } from './helpers';

test('новый игрок: стартовые ресурсы, стройка Казармы, ускорение за кристалл', async ({ page }) => {
  await register(page);
  // Полоса ресурсов: старт 1000 (+ немного накопилось), 50 кристаллов
  await expect(page.getByLabel(/^Золото: /)).toBeVisible();
  await expect(page.getByLabel('Кристаллы: 50')).toBeVisible();

  await page.getByRole('button', { name: /Казарма/ }).click();
  const dialog = page.getByRole('dialog');
  await expect(dialog.getByText('1м 30с')).toBeVisible();
  await dialog.getByRole('button', { name: 'Построить' }).click();
  await expect(dialog).toBeHidden();

  const queue = await openQueue(page);
  await expect(queue.getByText(/Казарма → 1/)).toBeVisible();
  await expect(queue.getByRole('progressbar')).toBeVisible();
  await expect(page.getByLabel(/^Золото: 8/)).toBeVisible(); // 1000 − 150 (+ копейки производства)

  await queue.getByRole('button', { name: /Ускорить/ }).click();
  await expect(queue.getByRole('progressbar')).toBeHidden();
  await expect(page.getByLabel('Кристаллы: 49')).toBeVisible();
  await expect(page.getByRole('button', { name: /Казарма/ })).toContainText('1');
});

test('состояние замка переживает перезагрузку и общий для двух вкладок', async ({
  page,
  context,
}) => {
  await register(page);
  await page.getByRole('button', { name: /Казарма/ }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Построить' }).click();
  await expect((await openQueue(page)).getByText(/Казарма → 1/)).toBeVisible();

  const second = await context.newPage(); // те же cookie — тот же игрок
  await second.goto('/castle');
  await expect((await openQueue(second)).getByText(/Казарма → 1/)).toBeVisible();

  await page.reload();
  await expect((await openQueue(page)).getByText(/Казарма → 1/)).toBeVisible();
});

test('отмена стройки возвращает половину ресурсов; ограничение по уровню Замка объяснено', async ({
  page,
}) => {
  await register(page);
  await page.getByRole('button', { name: /Ферма/ }).click();
  const farm = page.getByRole('dialog');
  await expect(farm.getByRole('button', { name: 'Улучшить до 2' })).toBeDisabled();
  await expect(farm.getByText('Нужен Замок уровня 2')).toBeVisible();
  await page.keyboard.press('Escape');

  await page.getByRole('button', { name: /Кузница/ }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Построить' }).click();
  await openQueue(page);
  await page.getByRole('button', { name: 'Отменить' }).click();
  await page.getByRole('alertdialog').getByRole('button', { name: 'Отменить' }).click();
  await expect(page.getByText('Сейчас ничего не строится')).toBeVisible();
  // 1000 − 200 + 100 = 900 золота (плюс накопленное за секунды)
  await expect(page.getByLabel(/^Золото: 9/)).toBeVisible();
});

test('на телефоне сетка зданий помещается без горизонтальной прокрутки', async ({ page }) => {
  await register(page);
  await expect(page.getByRole('button', { name: /Замок/ }).first()).toBeVisible();
  const overflow = await page.evaluate(
    () => document.documentElement.scrollWidth - document.documentElement.clientWidth,
  );
  expect(overflow).toBeLessThanOrEqual(0);
});
