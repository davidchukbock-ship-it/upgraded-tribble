import { expect, test } from '@playwright/test';
import { register } from './helpers';

test('главная открывается на русском и предлагает войти', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('heading', { level: 1, name: 'Битва за трон' })).toBeVisible();
  await page.getByRole('link', { name: 'Войти' }).first().click();
  await expect(page).toHaveURL(/\/login$/);
});

test('нет горизонтальной прокрутки на витрине UI', async ({ page }) => {
  await page.goto('/ui-kit');
  await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
  const overflow = await page.evaluate(
    () => document.documentElement.scrollWidth - document.documentElement.clientWidth,
  );
  expect(overflow).toBeLessThanOrEqual(0);
});

test('окно-свиток открывается и закрывается по Esc, фокус возвращается', async ({ page }) => {
  await page.goto('/ui-kit');
  const opener = page.getByRole('button', { name: 'Открыть окно' });
  await opener.click();
  await expect(page.getByRole('dialog')).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(page.getByRole('dialog')).toBeHidden();
  await expect(opener).toBeFocused();
});

test('боковых панелей нет: сверху ресурсы и донат, все разделы — в меню шестерёнки', async ({
  page,
}) => {
  await register(page);
  await expect(page.getByRole('navigation', { name: 'main' })).toHaveCount(0);
  await expect(page.getByLabel(/^Золото: /)).toBeVisible();
  await expect(page.getByRole('link', { name: 'Пополнить кристаллы' })).toHaveAttribute(
    'href',
    '/donate',
  );
  await page.getByRole('button', { name: 'Настройки и меню' }).click();
  const menu = page.getByRole('dialog');
  for (const name of ['Карта', 'Армия', 'Задания', 'Магазин', 'Донат', 'Приключения', 'Профиль'])
    await expect(menu.getByRole('link', { name: new RegExp(`^${name}`) })).toBeVisible();
  await menu.getByRole('link', { name: /^Карта/ }).click();
  await expect(page).toHaveURL(/\/map$/);
  await expect(menu).toBeHidden();
});

test('облик мира переключается в меню и запоминается', async ({ page }) => {
  await register(page);
  await page.getByRole('button', { name: 'Настройки и меню' }).click();
  await page.getByRole('radio', { name: 'Современность' }).click();
  await page.keyboard.press('Escape');
  await page.reload();
  await page.getByRole('button', { name: 'Настройки и меню' }).click();
  await expect(page.getByRole('radio', { name: 'Современность' })).toBeChecked();
  await page.getByRole('radio', { name: 'Средневековье' }).click();
});

test('скриншоты для обзора дизайна', async ({ page }, info) => {
  await page.goto('/ui-kit');
  await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
  await page.screenshot({ path: `test-results/uikit-${info.project.name}.png`, fullPage: true });
});
