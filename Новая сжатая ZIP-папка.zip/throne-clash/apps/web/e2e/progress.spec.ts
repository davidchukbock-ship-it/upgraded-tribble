import { expect, test, type Page } from '@playwright/test';
import { register } from './helpers';

const noHorizontalScroll = async (page: Page) => {
  const over = await page.evaluate(
    () => document.documentElement.scrollWidth - document.documentElement.clientWidth,
  );
  expect(over).toBeLessThanOrEqual(0);
};

test('задания → сундук → магазин: награда за улучшение, открытие сундука, покупка ускорителя', async ({
  page,
}) => {
  const me = await register(page);

  // Подсказка туториала ведёт новичка: первый шаг — улучшить здание
  const hint = page.getByRole('complementary', { name: 'Обучение' });
  await expect(hint).toContainText('Шаг 1 из 10');

  await page.getByRole('button', { name: /Казарма/ }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Построить' }).click();

  // Ежедневный вход
  await page.goto('/quests');
  await expect(page.getByRole('heading', { level: 1, name: 'Задания' })).toBeVisible();
  await page.getByRole('button', { name: 'Забрать награду: день 1' }).click();
  await expect(page.getByText('Сегодняшняя награда получена')).toBeVisible();
  await noHorizontalScroll(page);

  // Ежедневное задание «улучшить здание» → деревянный сундук
  await page.getByRole('tab', { name: /Ежедневные/ }).click();
  await page.getByRole('button', { name: /Забрать: Начните улучшение здания/ }).click();
  await expect(page.getByText('Получено').first()).toBeVisible();

  await page.goto('/chests');
  await expect(page.getByRole('table', { name: 'Шансы выпадения' })).toBeVisible();
  await page.getByRole('button', { name: 'Открыть: Деревянный сундук' }).click();
  const dialog = page.getByRole('dialog', { name: 'Сундук открыт' });
  await expect(dialog).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(dialog).toBeHidden();
  await expect(page.getByRole('button', { name: 'Открыть: Деревянный сундук' })).toBeDisabled();
  await noHorizontalScroll(page);

  // Магазин: ускоритель за кристаллы попадает в инвентарь
  await page.goto('/shop');
  await page.getByRole('button', { name: 'Купить: Ускоритель 5 минут' }).click();
  await expect(page.getByText('Куплено: Ускоритель 5 минут')).toBeVisible();
  await noHorizontalScroll(page);
  await page.goto('/chests');
  await expect(page.getByRole('button', { name: 'Применить: Ускоритель 5 минут' })).toBeEnabled();

  // Лига: игрок есть в таблице
  await page.goto('/leagues');
  await expect(page.getByRole('row', { name: new RegExp(me.nickname) })).toBeVisible();
  await noHorizontalScroll(page);
});

test('ускоритель из инвентаря сокращает стройку', async ({ page }) => {
  await register(page);
  await page.goto('/shop');
  await page.getByRole('button', { name: 'Купить: Ускоритель 1 час' }).click();
  await expect(page.getByText('Куплено: Ускоритель 1 час')).toBeVisible();

  await page.goto('/castle');
  await page.getByRole('button', { name: /Казарма/ }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Построить' }).click();
  await page.goto('/chests');
  await page.getByRole('button', { name: 'Применить: Ускоритель 1 час' }).click();
  await page
    .getByRole('dialog')
    .getByRole('button', { name: /Применить: Казарма/ })
    .click();
  await expect(page.getByText('Ускоритель применён')).toBeVisible();
  // Часовой ускоритель закрывает короткую стройку целиком — приходит уведомление о завершении
  await page.goto('/notifications');
  await expect(page.getByText(/Построено: Казарма, уровень 1/)).toBeVisible({ timeout: 15_000 });
});

test('премиум-герб: покупка и выбор в профиле', async ({ page }) => {
  await register(page);
  await page.goto('/shop');
  await page.getByRole('button', { name: 'Купить: Герб: Золотой лев' }).click();
  await expect(page.getByText('Куплено: Герб: Золотой лев')).toBeVisible();
  await page.goto('/profile');
  await page.getByRole('radio', { name: 'Золотой лев' }).click();
  await expect(page.getByRole('radio', { name: 'Золотой лев' })).toHaveAttribute(
    'aria-checked',
    'true',
  );
});
