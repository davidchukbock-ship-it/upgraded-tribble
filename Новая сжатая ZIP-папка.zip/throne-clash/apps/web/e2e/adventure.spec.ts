import { expect, test } from '@playwright/test';
import { register } from './helpers';

test('город: дорога на свободную клетку, снос возвращает половину', async ({ page }) => {
  await register(page);
  await page.getByRole('button', { name: /^Город/ }).click();
  await page.getByRole('tab', { name: /^Дороги и улицы/ }).click();
  await page.getByRole('button', { name: 'Построить: Дорога' }).click();
  await expect(page.getByText(/Выберите свободную клетку на острове: Дорога/)).toBeVisible();
  await page.getByRole('button', { name: 'В первую свободную' }).click();
  await expect(page.getByText('Построено: Дорога').first()).toBeVisible();
  await page.keyboard.press('Escape');
  await page.getByRole('button', { name: /^Город/ }).click();
  await page.getByRole('tab', { name: /^Дороги и улицы/ }).click();
  await page.getByRole('button', { name: 'Снести: Дорога' }).click();
  await page.getByRole('alertdialog').getByRole('button', { name: 'Снести' }).click();
  await expect(page.getByRole('button', { name: 'Снести: Дорога' })).toBeHidden();
});

test('приключения: арена доходит до итога, рыбалка и руны отвечают', async ({ page }) => {
  test.setTimeout(90_000);
  await register(page);
  await page.goto('/play');
  await expect(page.getByRole('tab', { name: 'Арена' })).toHaveAttribute('aria-selected', 'true');
  await page.getByRole('radio', { name: /Вулкан/ }).click();
  await page.getByRole('button', { name: 'В бой!' }).click();
  await expect(page.getByText(/Победа!|Поражение/)).toBeVisible({ timeout: 40_000 });

  await page.getByRole('tab', { name: 'Рыбалка' }).click();
  await page.getByRole('button', { name: 'Забросить' }).click();
  await expect(page.getByRole('button', { name: 'Подсечь!' })).toBeVisible({ timeout: 8_000 });
  await page.getByRole('button', { name: 'Подсечь!' }).click();
  await expect(page.getByText(/Заброс 1 из 10/)).toBeVisible();

  await page.getByRole('tab', { name: 'Руны' }).click();
  const cards = page.getByRole('button', { name: /Закрытая карта/ });
  await expect(cards).toHaveCount(16);
  await cards.first().click();
  await expect(page.getByRole('button', { pressed: true })).toHaveCount(1);
});

test('мини-карта: видна на карте и переносит обзор', async ({ page }) => {
  await register(page);
  await page.goto('/map');
  const mini = page.getByTestId('minimap');
  await expect(mini).toBeVisible();
  await mini.click({ position: { x: 20, y: 20 } });
  await expect(page.getByRole('status').filter({ hasText: /\d+, \d+:/ })).toBeVisible();
});
