import { expect, test, type Page } from '@playwright/test';
import { buildAndSpeedUp, newPlayer, register } from './helpers';

const noHorizontalScroll = async (page: Page) => {
  const over = await page.evaluate(
    () => document.documentElement.scrollWidth - document.documentElement.clientWidth,
  );
  expect(over).toBeLessThanOrEqual(0);
};

test('мировой чат между двумя игроками по WebSocket и личное сообщение офлайн-игроку', async ({
  browser,
}) => {
  const ctxA = await browser.newContext();
  const ctxB = await browser.newContext();
  const a = await ctxA.newPage();
  const b = await ctxB.newPage();
  const pa = await register(a, newPlayer());
  const pb = await register(b, newPlayer());

  await a.goto('/chat');
  await b.goto('/chat');
  await expect(a.getByText(/Сейчас в игре: [2-9]/)).toBeVisible({ timeout: 15_000 });

  const box = (p: Page) => p.getByPlaceholder('Сообщение…');
  await box(a).fill('Привет, мир!');
  await a.getByRole('button', { name: 'Отправить' }).click();
  await expect(b.getByRole('log', { name: 'Мировой' })).toContainText('Привет, мир!');
  await expect(b.getByRole('log', { name: 'Мировой' })).toContainText(pa.nickname);

  await box(b).fill('Ответ');
  await b.getByRole('button', { name: 'Отправить' }).click();
  await expect(a.getByRole('log', { name: 'Мировой' })).toContainText('Ответ');
  await noHorizontalScroll(a);

  // Б уходит из игры; А пишет ему лично
  await b.goto('about:blank');
  await a.getByRole('button', { name: `Написать: ${pb.nickname}` }).click();
  await expect(a.getByRole('tab', { name: pb.nickname, selected: true })).toBeVisible();
  await box(a).fill('лично для тебя');
  await a.getByRole('button', { name: 'Отправить' }).click();
  await expect(a.getByRole('log', { name: pb.nickname })).toContainText('лично для тебя');

  await b.goto('/notifications');
  await expect(b.getByText(new RegExp(`${pa.nickname}: лично для тебя`))).toBeVisible();
  await expect(b.getByRole('link', { name: /Уведомления, непрочитанных: 1/ })).toBeVisible();
  await b.getByRole('button', { name: 'Прочитать все' }).click();
  await expect(b.getByRole('link', { name: 'Уведомления', exact: true })).toBeVisible();

  await ctxA.close();
  await ctxB.close();
});

test('братство: новичку объяснено, что нужно для создания; список и поиск работают', async ({
  page,
}) => {
  await register(page);
  await page.goto('/guild');
  await page.getByLabel('Название').first().fill('Волки Севера');
  await expect(page.getByText('Нужен Замок 5 уровня')).toBeVisible();
  await expect(page.getByRole('button', { name: 'Создать', exact: true })).toBeDisabled();
  await expect(page.getByText('Вы пока не состоите в братстве')).toBeVisible();
  await noHorizontalScroll(page);
});

test('завершение постройки приходит уведомлением без перезагрузки', async ({ page }) => {
  await register(page);
  await buildAndSpeedUp(page, /Казарма/);
  await page.goto('/notifications');
  // Ускорение завершает стройку сразу — уведомление появляется в ленте
  await expect(page.getByText(/Построено: Казарма, уровень 1/)).toBeVisible({ timeout: 15_000 });
});
