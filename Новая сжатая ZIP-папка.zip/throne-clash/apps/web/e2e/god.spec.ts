import AxeBuilder from '@axe-core/playwright';
import { expect, test } from '@playwright/test';
import { enterGodMode, loginAsOwner, newPlayer, register } from './helpers';
import type { Page } from '@playwright/test';

/** Кристаллы из подписи полосы ресурсов: «Кристаллы: 1 284». */
/** Доступность служебных экранов: те же правила WCAG A/AA, что и у игры. */
const noViolations = async (page: Page, where: string) => {
  const res = await new AxeBuilder({ page })
    .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
    .analyze();
  expect(
    res.violations.map(
      (v) =>
        `${v.id}: ${v.nodes
          .slice(0, 2)
          .map((n) => n.target.join(' '))
          .join(', ')}`,
    ),
    where,
  ).toEqual([]);
};

const gemsOf = async (page: Page): Promise<number> => {
  const label =
    (await page
      .getByLabel(/^Кристаллы:/)
      .first()
      .getAttribute('aria-label')) ?? '';
  return Number(label.split(':')[1]?.replace(/\D/g, ''));
};

test('обычный игрок не видит режим бога: /god ведёт на главную, ссылок в меню нет', async ({
  page,
}) => {
  await register(page);
  await expect(page.getByRole('link', { name: /бога|God/i })).toHaveCount(0);
  await expect(page.getByRole('link', { name: 'Админка' })).toHaveCount(0);
  await page.goto('/god');
  await expect(page).toHaveURL(/\/$/);
  await page.goto('/admin');
  await expect(page.getByRole('alert')).toContainText('Недостаточно прав');
});

test('владелец: вход в режим бога, действие над игроком, аудит, назначение администратора и его панель', async ({
  browser,
}) => {
  const playerCtx = await browser.newContext();
  const player = await playerCtx.newPage();
  const me = await register(player, newPlayer());
  const start = await gemsOf(player);
  expect(start).toBeGreaterThan(0);

  const ownerCtx = await browser.newContext();
  const owner = await ownerCtx.newPage();
  await loginAsOwner(owner);
  await enterGodMode(owner);

  await noViolations(owner, 'режим бога: панель');

  // Игрок находится по нику, действие выполняется и пишется в аудит
  await owner.getByLabel('Поиск').fill(me.nickname);
  await owner.getByRole('button', { name: 'Найти' }).click();
  await owner.getByRole('button', { name: new RegExp(me.nickname) }).click();
  const form = owner.getByRole('form', { name: 'Ресурсы' });
  await form.getByLabel('Ресурс').selectOption('gems');
  await form.getByLabel('Количество').fill('1234');
  await form.getByRole('button', { name: 'Применить' }).click();
  await expect(owner.getByText('Выполнено').first()).toBeVisible();
  await expect(owner.getByText('тронут режимом бога')).toBeVisible();

  // Палитра команд
  await owner.keyboard.press('Control+K');
  await owner.getByLabel('Команда').fill('give gold 5k');
  await expect(owner.getByText('→ give gold 5000')).toBeVisible();
  await owner.getByRole('button', { name: 'Выполнить' }).click();

  await owner.getByRole('tab', { name: 'Аудит' }).click();
  await expect(owner.getByText('act:give gems 1234').first()).toBeVisible();
  await expect(owner.getByText('act:give gold 5000').first()).toBeVisible();

  // Игрок увидел кристаллы; замок тронут режимом бога, поэтому в рейтинге его нет
  await player.reload();
  const gems = await gemsOf(player);
  expect(gems).toBeGreaterThanOrEqual(start + 1234);

  // Назначение администратора → у игрока появляется «Админка» и рабочая панель
  await owner.getByRole('tab', { name: 'Игроки' }).click();
  await owner.getByRole('button', { name: new RegExp(me.nickname) }).click();
  await owner.getByRole('button', { name: 'Назначить администратором' }).click();
  await expect(owner.getByRole('button', { name: 'Снять администратора' })).toBeVisible();
  await player.goto('/more'); // на телефоне пункт лежит в «Ещё»
  await player.getByRole('link', { name: 'Админка' }).first().click();
  await expect(
    player.getByRole('heading', { level: 1, name: 'Панель администратора' }),
  ).toBeVisible();
  await expect(player.getByRole('table', { name: 'Экономика за 24 часа' })).toBeVisible();
  await noViolations(player, 'админка: сводка');
  // Но режим бога для администратора недоступен
  await player.goto('/god');
  await expect(player).toHaveURL(/\/$/);

  // Выход из режима бога закрывает панель
  await owner.getByRole('button', { name: 'Выйти', exact: true }).click();
  await expect(owner.getByRole('heading', { name: 'Вход в режим бога' })).toBeVisible();

  await ownerCtx.close();
  await playerCtx.close();
});
