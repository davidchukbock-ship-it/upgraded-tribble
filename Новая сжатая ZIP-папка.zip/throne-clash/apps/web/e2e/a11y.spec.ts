import AxeBuilder from '@axe-core/playwright';
import { expect, test, type Page } from '@playwright/test';
import { register } from './helpers';

/** Игровые экраны для проверки доступности и адаптива на обоих размерах экрана (375 и 1440). */
const SCREENS = [
  '/castle',
  '/map',
  '/army',
  '/academy',
  '/hero',
  '/quests',
  '/chests',
  '/shop',
  '/leagues',
  '/guild',
  '/chat',
  '/notifications',
  '/reports',
  '/profile',
  '/more',
  '/play',
  '/donate',
  '/credits',
];

const noHorizontalScroll = async (page: Page, path: string) => {
  const report = await page.evaluate(() => {
    const w = document.documentElement.clientWidth;
    const culprits = [...document.querySelectorAll('body *')]
      .filter((e) => e.getBoundingClientRect().right > w + 1)
      .slice(0, 3)
      .map((e) => `${e.tagName.toLowerCase()}.${String(e.className).slice(0, 60)}`);
    return { over: document.documentElement.scrollWidth - w, culprits };
  });
  expect(
    report.over,
    `${path}: горизонтальная прокрутка (${report.culprits.join(' | ')})`,
  ).toBeLessThanOrEqual(0);
};

const scan = async (page: Page, path: string) => {
  const res = await new AxeBuilder({ page })
    .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
    .analyze();
  const summary = res.violations.map(
    (v) =>
      `${v.id} (${v.impact}): ${v.nodes
        .slice(0, 2)
        .map((n) => n.target.join(' '))
        .join(', ')}`,
  );
  expect(summary, `${path}: нарушения доступности`).toEqual([]);
};

test('вход и регистрация: доступность и адаптив', async ({ page }) => {
  for (const path of ['/', '/login', '/register']) {
    await page.goto(path);
    await page.waitForLoadState('networkidle');
    await scan(page, path);
    await noHorizontalScroll(page, path);
  }
});

test('игровые экраны: нет нарушений WCAG A/AA и горизонтальной прокрутки', async ({ page }) => {
  test.setTimeout(120_000);
  await register(page);
  for (const path of SCREENS) {
    await page.goto(path);
    await page.waitForLoadState('networkidle');
    await expect(page.locator('main')).toBeVisible();
    await scan(page, path);
    await noHorizontalScroll(page, path);
  }
});

test('окно здания и подтверждения: доступность, фокус возвращается на кнопку', async ({ page }) => {
  await register(page);
  const trigger = page.getByRole('button', { name: /Казарма/ });
  await trigger.click();
  const dialog = page.getByRole('dialog');
  await expect(dialog).toBeVisible();
  await scan(page, 'окно здания');
  await page.keyboard.press('Escape');
  await expect(dialog).toBeHidden();
  await expect(trigger).toBeFocused();
});

test('клавиатура: ссылка «к содержимому», видимый фокус, Tab проходит по меню', async ({
  page,
}) => {
  await register(page);
  // Свежая загрузка: иначе Chrome продолжает обход с места последнего клика
  await page.goto('/castle');
  await page.waitForLoadState('networkidle');
  await page.keyboard.press('Tab');
  const skip = page.getByRole('link', { name: 'К содержимому' });
  await expect(skip).toBeFocused();
  await expect(skip).toBeVisible();
  await page.keyboard.press('Enter');
  await expect(page.locator('#main')).toBeFocused();

  // Любой интерактивный элемент при фокусе с клавиатуры получает заметную рамку
  await page.goto('/quests');
  await page.waitForLoadState('networkidle');
  const rings = new Set<string>();
  for (let i = 0; i < 12; i++) {
    await page.keyboard.press('Tab');
    const ring = await page.evaluate(() => {
      const el = document.activeElement;
      if (!el || el === document.body) return 'none';
      const s = getComputedStyle(el);
      const visible =
        (s.outlineStyle !== 'none' && parseFloat(s.outlineWidth) > 0) ||
        s.boxShadow !== 'none' ||
        el.matches('[class*="ring"]');
      return visible
        ? 'ok'
        : `${el.tagName.toLowerCase()}:${(el.textContent ?? '').trim().slice(0, 20)}`;
    });
    rings.add(ring);
  }
  expect([...rings]).toEqual(['ok']);
});
