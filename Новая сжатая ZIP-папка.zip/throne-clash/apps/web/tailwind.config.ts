import type { Config } from 'tailwindcss';

// Цвета берутся из CSS-переменных темы (src/styles/index.css) — тему можно менять без пересборки
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        wood: { DEFAULT: 'var(--wood)', dark: 'var(--wood-dark)', light: 'var(--wood-light)' },
        stone: { DEFAULT: 'var(--stone)', dark: 'var(--stone-dark)' },
        parchment: { DEFAULT: 'var(--parchment)', dark: 'var(--parchment-dark)' },
        gold: { DEFAULT: 'var(--gold)', light: 'var(--gold-light)', dark: 'var(--gold-dark)' },
        red: { DEFAULT: 'var(--red)' },
        green: { DEFAULT: 'var(--green)', btn: 'var(--green-btn)' },
        ink: 'var(--ink)',
      },
      fontFamily: {
        display: ['Cinzel', 'Georgia', 'serif'],
        body: ['Inter', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        panel: '0 6px 0 rgba(0,0,0,.35), 0 12px 24px rgba(0,0,0,.35)',
      },
    },
  },
  plugins: [],
} satisfies Config;
