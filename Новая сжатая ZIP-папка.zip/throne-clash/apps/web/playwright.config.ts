import { defineConfig, devices } from '@playwright/test';

const chromium = process.env['PW_CHROMIUM_PATH'];
const dbUrl = process.env['DATABASE_URL'] ?? 'postgresql://throne:throne@localhost:5432/throne';
const redisUrl = process.env['REDIS_URL'] ?? 'redis://localhost:6379';

export default defineConfig({
  testDir: './e2e',
  timeout: 30_000,
  fullyParallel: true,
  reporter: process.env['CI'] ? [['github'], ['html', { open: 'never' }]] : 'list',
  use: {
    baseURL: 'http://localhost:4173',
    trace: 'on-first-retry',
    launchOptions: chromium ? { executablePath: chromium } : {},
  },
  projects: [
    {
      name: 'desktop-1440',
      use: { ...devices['Desktop Chrome'], viewport: { width: 1440, height: 900 } },
    },
    {
      name: 'mobile-375',
      use: { ...devices['Pixel 5'], viewport: { width: 375, height: 800 } },
    },
  ],
  webServer: [
    {
      // Настоящий сервер игры: e2e проходят через HTTP, БД и Redis, без подмен
      command: 'pnpm --filter @tc/server exec tsx src/main.ts',
      cwd: '../..',
      url: 'http://localhost:3000/health',
      reuseExistingServer: !process.env['CI'],
      timeout: 60_000,
      env: {
        NODE_ENV: 'development',
        LOG_LEVEL: 'warn',
        DATABASE_URL: dbUrl,
        REDIS_URL: redisUrl,
        PORT: '3000',
        // Тесты регистрируют десятки игроков с одного IP
        AUTH_LOGIN_RATE_MAX: '1000',
        AUTH_REGISTER_RATE_MAX: '1000',
        AUTH_GUEST_RATE_MAX: '1000',
        AUTH_REFRESH_RATE_MAX: '1000',
        ACTION_RATE_MAX: '1000',
        // Режим бога для e2e. Пароль и хеш — тестовые, только для одноразового сервера e2e;
        // настоящий пароль владельца в репозитории не хранится (D-13).
        OWNER_EMAIL: 'owner-e2e@example.com',
        GOD_MODE_ENABLED: 'true',
        GOD_MODE_PASSWORD_HASH:
          '$argon2id$v=19$m=19456,t=2,p=1$BCpoe4d7lc1KFkLDTZMF0Q$fGy1x9UOjhlQc7tt87kLD4UICil/AIXhtsVCPjNaNrk',
        RATE_LIMIT_MAX: '100000',
        CORS_ORIGIN: 'http://localhost:4173',
      },
    },
    {
      command: 'pnpm build && pnpm preview --port 4173 --strictPort',
      port: 4173,
      reuseExistingServer: !process.env['CI'],
      timeout: 120_000,
    },
  ],
});
