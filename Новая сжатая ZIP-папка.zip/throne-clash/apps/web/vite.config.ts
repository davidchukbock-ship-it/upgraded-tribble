import react from '@vitejs/plugin-react';
import { defineConfig } from 'vitest/config';

/** Публичные адреса туннелей и Codespaces. */
const TUNNEL_ORIGIN =
  /^https:\/\/[^/]+\.(trycloudflare\.com|loca\.lt|ngrok-free\.app|ngrok\.app|app\.github\.dev)$/;

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    // Публичные адреса временных туннелей (`pnpm share`): без этого Vite отвечает «Blocked request»
    allowedHosts: [
      '.app.github.dev',
      '.trycloudflare.com',
      '.loca.lt',
      '.ngrok-free.app',
      '.ngrok.app',
    ],
    // В разработке API и WebSocket проксируются на сервер игры.
    // Через туннель браузер шлёт Origin с публичным адресом, а сервер доверяет только своему CORS_ORIGIN:
    // для адресов туннелей подменяем Origin на локальный. Обычные запросы (localhost, preview) не трогаем.
    proxy: {
      '/api': {
        target: 'http://localhost:3000',
        changeOrigin: true,
        configure: (proxy) => {
          proxy.on('proxyReq', (proxyReq, req) => {
            const origin = req.headers.origin;
            if (typeof origin === 'string' && TUNNEL_ORIGIN.test(origin))
              proxyReq.setHeader('origin', 'http://localhost:5173');
          });
        },
      },
      '/health': { target: 'http://localhost:3000', changeOrigin: true },
      '/ws': { target: 'ws://localhost:3000', ws: true },
    },
  },
  build: {
    sourcemap: true,
    target: 'es2022',
    rollupOptions: {
      output: {
        // Крупные библиотеки — отдельными файлами: они меняются реже кода игры и кэшируются браузером
        manualChunks: {
          react: ['react', 'react-dom', 'react-router-dom'],
          motion: ['framer-motion'],
          data: ['@tanstack/react-query', 'zustand', 'zod'],
          i18n: ['i18next', 'react-i18next'],
        },
      },
    },
  },
  test: {
    environment: 'jsdom',
    globals: true,
    setupFiles: ['./src/test-setup.ts'],
    include: ['src/**/*.test.{ts,tsx}'],
    css: false,
    coverage: {
      provider: 'v8',
      include: ['src/ui/**', 'src/lib/**', 'src/store/**', 'src/features/**', 'src/icons/**'],
      exclude: ['src/**/*.test.{ts,tsx}'],
      thresholds: { lines: 80, functions: 75, branches: 70, statements: 80 },
    },
  },
});
