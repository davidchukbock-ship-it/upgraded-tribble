/** Уровень здания → ступень облика 0…3 (как в таблице баланса). */
export const tierOf = (level: number): 0 | 1 | 2 | 3 =>
  level <= 5 ? 0 : level <= 10 ? 1 : level <= 15 ? 2 : 3;
