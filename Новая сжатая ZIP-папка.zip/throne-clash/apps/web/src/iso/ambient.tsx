import type { CSSProperties, ReactNode } from 'react';
import { useEffect } from 'react';
import { playSfx } from '../audio/useSoundtrack';
import { useEra } from '../store/era';
import { iso } from './project';

/**
 * Жизнь вокруг острова: лодки плавают по морю за границей территории, время от времени пролетают птицы.
 * Всё на CSS-анимациях (отключаются при prefers-reduced-motion), в SVG сцены, поверх воды и под зданиями.
 */
const OUT = '#2a1a0e';
const line = {
  stroke: OUT,
  strokeWidth: 1.2,
  strokeLinejoin: 'round',
  strokeLinecap: 'round',
} as const;

function Sailboat() {
  return (
    <g>
      <path d="M-22 0h44l-6 9h-32Z" fill="#8a5a34" {...line} />
      <path d="M-20 3h40" stroke="#e0b030" strokeWidth="1.500" />
      <path d="M0 0V-38" stroke={OUT} strokeWidth="2" />
      <path d="M2 -36c10 8 12 22 12 32H2Z" fill="#f6f1e6" {...line} />
      <path d="M-2 -32c-8 8-11 20-11 28h11Z" fill="#e9dfc8" {...line} />
      <path d="M0 -38l9 3-9 3Z" fill="#c0392b" />
    </g>
  );
}

function FishingBoat() {
  return (
    <g>
      <path d="M-24 0h48l-7 10h-34Z" fill="#3f68b4" {...line} />
      <path d="M-24 0h48" stroke="#f6f1e6" strokeWidth="2" />
      <rect x="-6" y="-14" width="14" height="14" fill="#f6f1e6" {...line} />
      <rect x="-3" y="-11" width="8" height="6" fill="#8fc9ee" stroke={OUT} strokeWidth="1" />
      <path d="M-8 -14h18l-2-4h-14Z" fill="#c0472f" {...line} />
      <path d="M-14 0V-18M-14 -18l-9 8" stroke={OUT} strokeWidth="1.400" fill="none" />
    </g>
  );
}

function Longship() {
  return (
    <g>
      <path d="M-28 -4c8 8 40 8 56 0l-6 10h-42Z" fill="#6a4426" {...line} />
      <path d="M-28 -4c-2-4-2-8 0-12M28 -4c2-4 2-8 0-12" stroke={OUT} strokeWidth="2" fill="none" />
      <path d="M-4 -4V-30" stroke={OUT} strokeWidth="2" />
      <path d="M-4 -28h16v16h-16Z" fill="#b33a2a" {...line} />
      <path d="M-4 -20h16" stroke="#f6f1e6" strokeWidth="3" />
      {[-18, -8, 6, 16].map((x) => (
        <circle key={x} cx={x} cy="1" r="3" fill="#e0b030" {...line} />
      ))}
    </g>
  );
}

function Yacht() {
  return (
    <g>
      <path d="M-26 0h50l6-6-58 0Z" fill="#f6f8fa" {...line} />
      <path d="M-26 0h52l-6 8h-42Z" fill="#2f6fae" {...line} />
      <path d="M-14 -6v-8h20l8 8Z" fill="#dfe8ee" {...line} />
      <path d="M-10 -8v-4h12v4Z" fill="#69b4e0" stroke={OUT} strokeWidth="1" />
      <path d="M-4 -14V-24" stroke={OUT} strokeWidth="1.500" />
      <circle cx="-4" cy="-25" r="1.800" fill="#ff4d4d" />
    </g>
  );
}

function CargoShip() {
  return (
    <g>
      <path d="M-34 0h68l-8 11h-52Z" fill="#3a4652" {...line} />
      <path d="M-34 0h68" stroke="#d9503c" strokeWidth="2.500" />
      {[
        [-28, '#d9503c'],
        [-16, '#f0a03a'],
        [-4, '#4fae6a'],
      ].map(([x, c]) => (
        <rect
          key={String(x)}
          x={Number(x)}
          y="-9"
          width="11"
          height="9"
          fill={String(c)}
          {...line}
        />
      ))}
      <rect x="10" y="-16" width="16" height="16" fill="#eef2f5" {...line} />
      <rect x="13" y="-13" width="10" height="4" fill="#69b4e0" />
      <path d="M22 -16V-24" stroke={OUT} strokeWidth="1.500" />
    </g>
  );
}

function Rowboat() {
  return (
    <g>
      <path d="M-16 0h32l-5 7h-22Z" fill="#a8703c" {...line} />
      <path d="M-16 0h32" stroke="#e6c37a" strokeWidth="1.500" />
      <path d="M-4 -1 8 -10" stroke={OUT} strokeWidth="1.800" strokeLinecap="round" />
      <ellipse
        cx="9"
        cy="-11"
        rx="4"
        ry="1.800"
        fill="#c9a86a"
        stroke={OUT}
        strokeWidth="1"
        transform="rotate(-30 9 -11)"
      />
      <circle cx="-3" cy="-6" r="3.500" fill="#f0c49a" {...line} />
      <path d="M-7 -1c0-5 2-6 4-6s4 1 4 6Z" fill="#3f68b4" {...line} />
    </g>
  );
}

function Ferry() {
  return (
    <g>
      <path d="M-34 0h68l-6 10h-56Z" fill="#6a4426" {...line} />
      <rect x="-30" y="-10" width="60" height="10" fill="#c9a86a" {...line} />
      {[-24, -12, 0, 12, 22].map((x) => (
        <rect key={x} x={x} y="-19" width="8" height="9" fill="#b33a2a" {...line} />
      ))}
      <path d="M-30 -10h60" stroke="#f6f1e6" strokeWidth="2" />
      <path d="M26 -10V-26h-10" stroke={OUT} strokeWidth="1.800" fill="none" />
      <path d="M16 -26l-8 3 8 3Z" fill="#c0392b" />
    </g>
  );
}

function Galleon() {
  return (
    <g>
      <path d="M-38 -2h76l-8 14h-60Z" fill="#5a3620" {...line} />
      <path d="M-38 -2h76" stroke="#e0b030" strokeWidth="2.500" />
      <rect x="-32" y="-12" width="22" height="10" fill="#7a4a24" {...line} />
      <rect x="18" y="-14" width="16" height="12" fill="#7a4a24" {...line} />
      {[-18, 2, 20].map((x, i) => (
        <g key={x}>
          <path d={`M${x} -2V${-46 + i * 6}`} stroke={OUT} strokeWidth="2.200" />
          <path
            d={`M${x + 1.5} ${-44 + i * 6}c9 6 10 16 10 26H${x + 1.5}Z`}
            fill="#f6f1e6"
            {...line}
          />
          <path
            d={`M${x - 1.5} ${-40 + i * 6}c-7 6-8 14-8 22H${x - 1.5}Z`}
            fill="#e9dfc8"
            {...line}
          />
        </g>
      ))}
      <path d="M-18 -46l9 3-9 3Z" fill="#c0392b" />
      <path d="M38 -2l10-6-4 8Z" fill="#7a4a24" {...line} />
    </g>
  );
}

function Buoy() {
  return (
    <g>
      <path d="M-6 0h12l-2-10h-8Z" fill="#f6f1e6" {...line} />
      <path d="M-5 -4h10l-1-3h-8Z" fill="#d9503c" />
      <path d="M0 -10V-16" stroke={OUT} strokeWidth="1.500" />
      <circle cx="0" cy="-17" r="2.500" fill="#ffe27a" stroke={OUT} strokeWidth="1" />
    </g>
  );
}

function Speedboat() {
  return (
    <g>
      <path d="M-22 0h40l8-4-4 9h-40Z" fill="#f6f8fa" {...line} />
      <path d="M-22 0h36" stroke="#d9503c" strokeWidth="2.500" />
      <path d="M-8 -1v-7h12l6 7Z" fill="#8fc9ee" {...line} />
      <path
        d="M-24 3l-6 1M-24 5l-8 1"
        stroke="#fff"
        strokeOpacity=".7"
        strokeWidth="2"
        strokeLinecap="round"
      />
    </g>
  );
}

function ModernFerry() {
  return (
    <g>
      <path d="M-36 0h72l-6 10h-60Z" fill="#2f6fae" {...line} />
      <rect x="-32" y="-10" width="64" height="10" fill="#f6f8fa" {...line} />
      <rect x="-24" y="-20" width="44" height="10" fill="#dfe8ee" {...line} />
      {[-20, -10, 0, 10].map((x) => (
        <rect key={x} x={x} y="-18" width="6" height="5" fill="#69b4e0" />
      ))}
      <rect x="4" y="-27" width="8" height="7" fill="#d9503c" {...line} />
    </g>
  );
}

function Warship() {
  return (
    <g>
      <path d="M-40 0h80l-10 10h-60Z" fill="#6d7a86" {...line} />
      <rect x="-14" y="-12" width="26" height="12" fill="#8a97a3" {...line} />
      <rect x="-6" y="-20" width="12" height="8" fill="#a7b3be" {...line} />
      <path d="M-30 -2v-6h10v6M18 -2v-6h10v6" stroke={OUT} strokeWidth="1.200" fill="#5d6a75" />
      <path d="M0 -20V-30" stroke={OUT} strokeWidth="1.500" />
    </g>
  );
}

/** Суда по видам построек: у каждой эпохи свой облик. */
export const BOATS: Record<
  'rowboat' | 'fishboat' | 'ship' | 'ferry' | 'galleon' | 'buoy',
  Record<'medieval' | 'modern', () => ReactNode>
> = {
  rowboat: { medieval: Rowboat, modern: Speedboat },
  fishboat: { medieval: FishingBoat, modern: Yacht },
  ship: { medieval: Sailboat, modern: CargoShip },
  ferry: { medieval: Ferry, modern: ModernFerry },
  galleon: { medieval: Galleon, modern: Warship },
  buoy: { medieval: Buoy, modern: Buoy },
};

export const FLEET: Record<'medieval' | 'modern', Array<() => ReactNode>> = {
  medieval: [Sailboat, FishingBoat, Longship, Sailboat],
  modern: [Yacht, CargoShip, Yacht, CargoShip],
};

interface Lane {
  from: [number, number];
  to: [number, number];
  seconds: number;
  delay: number;
}

function Boat({ lane, art, scale = 1 }: { lane: Lane; art: () => ReactNode; scale?: number }) {
  const [x0, y0] = iso(...lane.from);
  const [x1, y1] = iso(...lane.to);
  const style = {
    '--x0': `${x0}px`,
    '--y0': `${y0}px`,
    '--x1': `${x1}px`,
    '--y1': `${y1}px`,
    animationDuration: `${lane.seconds}s`,
    animationDelay: `${-lane.delay}s`,
  } as CSSProperties;
  const flip = x1 < x0 ? -1 : 1;
  return (
    <g className="iso-boat" style={style}>
      <g transform={`scale(${flip * scale} ${scale})`}>
        <ellipse cx="0" cy="8" rx="34" ry="6" fill="#fff" opacity=".28" className="iso-boat-wake" />
        <g className="iso-boat-bob">{art()}</g>
      </g>
    </g>
  );
}

function Bird({
  x0,
  y0,
  x1,
  y1,
  delay,
  seconds,
  s = 1,
}: {
  x0: number;
  y0: number;
  x1: number;
  y1: number;
  delay: number;
  seconds: number;
  s?: number;
}) {
  const style = {
    '--x0': `${x0}px`,
    '--y0': `${y0}px`,
    '--x1': `${x1}px`,
    '--y1': `${y1}px`,
    animationDuration: `${seconds}s`,
    animationDelay: `${delay}s`,
  } as CSSProperties;
  return (
    <g className="iso-bird" style={style}>
      <g transform={`scale(${s})`}>
        <path className="iso-bird-wing" d="M0 0Q-8 -9 -17 -4Q-9 -3 0 0Z" fill="#2b3340" />
        <path
          className="iso-bird-wing iso-bird-wing-r"
          d="M0 0Q8 -9 17 -4Q9 -3 0 0Z"
          fill="#2b3340"
        />
        <ellipse cx="0" cy="0.500" rx="3" ry="1.800" fill="#2b3340" />
      </g>
    </g>
  );
}

/**
 * `W`, `D` — размеры острова с закрытым слоем следующих земель: лодки идут по воде за ним.
 * `vb` — область рисунка: по ней летят птицы.
 */
export function Ambient({
  W,
  D,
  vb,
}: {
  W: number;
  D: number;
  vb: { x: number; y: number; w: number; h: number };
}) {
  const era = useEra((s) => s.era);
  const fleet = FLEET[era];
  const lanes: Lane[] = [
    { from: [-1.5, D + 1.5], to: [W * 0.85, D + 1.5], seconds: 70, delay: 10 },
    { from: [W + 1.6, D * 0.9], to: [W + 1.6, 1], seconds: 82, delay: 44 },
    { from: [W * 0.9, D + 2.6], to: [1, D + 2.6], seconds: 96, delay: 30 },
    { from: [W + 2.6, 2], to: [W + 2.6, D * 0.8], seconds: 90, delay: 5 },
  ];
  const y = vb.y + vb.h * 0.16;
  // Щебет в такт пролёту стай (те же задержки и периоды, что у CSS-анимации)
  useEffect(() => {
    const flocks = [
      { d: 4, sec: 34 },
      { d: 19, sec: 40 },
      { d: 33, sec: 36 },
    ];
    const timers: ReturnType<typeof setTimeout | typeof setInterval>[] = [];
    for (const f of flocks) {
      const first = setTimeout(() => {
        playSfx('chirp');
        timers.push(setInterval(() => playSfx('chirp'), f.sec * 1000));
      }, f.d * 1000);
      timers.push(first);
    }
    return () => timers.forEach((id) => (clearTimeout(id), clearInterval(id)));
  }, []);
  return (
    <g pointerEvents="none">
      {lanes.map((l, i) => (
        <Boat key={i} lane={l} art={fleet[i % fleet.length]!} scale={0.9 + (i % 2) * 0.15} />
      ))}
      {[
        { d: 4, sec: 34, dy: 0 },
        { d: 19, sec: 40, dy: 70 },
        { d: 33, sec: 36, dy: 30 },
      ].map((b, i) => (
        <g key={i}>
          <Bird
            x0={vb.x - 40}
            y0={y + b.dy}
            x1={vb.x + vb.w + 40}
            y1={y + b.dy - 60}
            delay={b.d}
            seconds={b.sec}
          />
          <Bird
            x0={vb.x - 70}
            y0={y + b.dy + 14}
            x1={vb.x + vb.w + 10}
            y1={y + b.dy - 46}
            delay={b.d + 0.4}
            seconds={b.sec}
            s={0.8}
          />
          <Bird
            x0={vb.x - 96}
            y0={y + b.dy - 6}
            x1={vb.x + vb.w - 16}
            y1={y + b.dy - 66}
            delay={b.d + 0.9}
            seconds={b.sec}
            s={0.7}
          />
        </g>
      ))}
    </g>
  );
}
