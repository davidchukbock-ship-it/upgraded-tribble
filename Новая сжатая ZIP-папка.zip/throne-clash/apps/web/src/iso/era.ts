import { PAL, faces, type Faces, type PalKey } from './primitives';

/**
 * Эпохи — задел под «стильный современный мир» (D-63). Эпоха меняет только материалы
 * (палитру граней): геометрия зданий, логика и данные остаются теми же. Средневековье — по умолчанию.
 * Форму зданий (стекло вместо черепицы, небоскрёбы) добавим отдельными вариантами в `buildings.tsx`.
 */
export const ERA_IDS = ['medieval', 'modern'] as const;
export type EraId = (typeof ERA_IDS)[number];

const MEDIEVAL: Record<PalKey, Faces> = { ...PAL };

const MODERN: Record<PalKey, Faces> = {
  stone: faces('#c9d2da'), // бетон
  stoneDark: faces('#8a97a3'),
  plaster: faces('#f2f5f7'),
  timber: faces('#8fb7c9'), // стекло в лёгком оттенке
  wood: faces('#5b6b78'),
  redRoof: faces('#d9503c'),
  blueRoof: faces('#2f7fd0'),
  purpleRoof: faces('#7e57c2'),
  greenRoof: faces('#2fa37a'),
  goldRoof: faces('#f0c14b'),
  slate: faces('#3a4652'),
  thatch: faces('#b7c4cf'),
  white: faces('#fbfdff'),
  dirt: faces('#98a3ac'),
};

const ERAS: Record<EraId, Record<PalKey, Faces>> = { medieval: MEDIEVAL, modern: MODERN };

let current: EraId = 'medieval';

export const currentEra = (): EraId => current;

/** Подменяет материалы палитры; вызывающий отвечает за перерисовку сцены. */
export function applyEra(era: EraId): void {
  Object.assign(PAL, ERAS[era]);
  current = era;
}
