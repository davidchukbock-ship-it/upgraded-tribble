import type { ReactNode } from 'react';
import { FOOTPRINT, type PlacedKey } from '@tc/shared';
import { darken, lighten } from '../art/color';
import { iso, pts } from './project';
import { MODERN_ART } from './modern';
import { useEra } from '../store/era';
import {
  Bricks,
  Box,
  Doorway,
  Gable,
  GroundShadow,
  PAL,
  Patch,
  Pyramid,
  Tower,
  Win,
  faces,
  type Faces,
} from './primitives';

/**
 * Изометрические здания. Каждое рисуется на своём участке клеток (ox, oy) размером FOOTPRINT.
 * Ступень (tier 0…3) делает здание богаче: выше, с башенками, цветной крышей и флагами.
 */
/** Здания, которые стоят на участке острова (Стены и Земли рисуются отдельно). */
export type { PlacedKey };

export { FOOTPRINT };

type Tier = 0 | 1 | 2 | 3;
interface B {
  ox: number;
  oy: number;
  tier: Tier;
  id: string;
}

const ROOF: readonly Faces[] = [PAL.redRoof, PAL.blueRoof, PAL.purpleRoof, PAL.goldRoof];

function Flag({
  x,
  y,
  z,
  color = '#c0392b',
  h = 26,
}: {
  x: number;
  y: number;
  z: number;
  color?: string;
  h?: number;
}) {
  const [sx, sy] = iso(x, y, z);
  return (
    <g>
      <line
        x1={sx}
        y1={sy}
        x2={sx}
        y2={sy - h}
        stroke="#4a2c14"
        strokeWidth="2"
        strokeLinecap="round"
      />
      <path
        className="scene-flag"
        d={`M${sx} ${sy - h}q9 -3 17 1 -4 5 0 10 -8 -3 -17 1Z`}
        fill={color}
        stroke={darken(color, 0.5)}
        strokeWidth="1"
        strokeLinejoin="round"
      />
    </g>
  );
}

function Crenels({
  x,
  y,
  w,
  d,
  z,
  c,
}: {
  x: number;
  y: number;
  w: number;
  d: number;
  z: number;
  c: Faces;
}) {
  const out: ReactNode[] = [];
  const n = Math.max(2, Math.round(w * 2));
  const m = Math.max(2, Math.round(d * 2));
  for (let i = 0; i < n; i += 2)
    out.push(
      <Box
        key={`a${i}`}
        x={x + (i / n) * w}
        y={y + d - 0.12}
        w={w / n}
        d={0.12}
        h={7}
        z={z}
        c={c}
      />,
    );
  for (let j = 0; j < m; j += 2)
    out.push(
      <Box
        key={`b${j}`}
        x={x + w - 0.12}
        y={y + (j / m) * d}
        w={0.12}
        d={d / m}
        h={7}
        z={z}
        c={c}
      />,
    );
  return <>{out}</>;
}

function Castle({ ox, oy, tier, id }: B) {
  const roof = ROOF[tier]!;
  const th = 74 + tier * 10;
  const kh = 96 + tier * 16;
  const wall = 34;
  const wallLen = (x: number, y: number, w: number, d: number) => (
    <Box x={ox + x} y={oy + y} w={w} d={d} h={wall} c={PAL.stone} bricks="stone" />
  );
  const tw = (x: number, y: number, k: string) => (
    <g key={k}>
      <Tower
        cx={ox + x}
        cy={oy + y}
        r={0.5}
        h={th}
        c={PAL.stone}
        roof={roof}
        roofRise={34}
        id={`${id}-${k}`}
      />
    </g>
  );
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={5} d={4} />
      {/* задние башни и стены */}
      {tw(0.55, 0.55, 't1')}
      {tw(4.45, 0.55, 't2')}
      {wallLen(0.55, 0.42, 3.9, 0.26)}
      {wallLen(0.42, 0.55, 0.26, 2.9)}
      {wallLen(4.32, 0.55, 0.26, 2.9)}
      {/* донжон */}
      <Box
        x={ox + 1.5}
        y={oy + 1}
        w={2}
        d={2}
        h={kh}
        c={PAL.stone}
        bricks="stone"
        left={(len) => (
          <g>
            <Win u={len * 0.25} v={kh * 0.55} lit />
            <Win u={len * 0.68} v={kh * 0.55} lit />
            <Win u={len * 0.45} v={kh * 0.8} w={10} h={16} lit={tier >= 1} />
          </g>
        )}
        right={(len) => (
          <g>
            <Win u={len * 0.3} v={kh * 0.55} />
            <Win u={len * 0.65} v={kh * 0.55} />
          </g>
        )}
      />
      <Crenels x={ox + 1.5} y={oy + 1} w={2} d={2} z={kh} c={PAL.stone} />
      {tier >= 1 && (
        <Box x={ox + 2} y={oy + 1.5} w={1} d={1} h={36} z={kh} c={PAL.stone} bricks="stone" />
      )}
      <Pyramid
        x={ox + (tier >= 1 ? 1.9 : 1.6)}
        y={oy + (tier >= 1 ? 1.4 : 1.1)}
        w={tier >= 1 ? 1.2 : 1.8}
        d={tier >= 1 ? 1.2 : 1.8}
        z={kh + (tier >= 1 ? 36 : 6)}
        rise={tier >= 1 ? 40 : 26}
        c={roof}
      />
      <Flag
        x={ox + 2.5}
        y={oy + 2}
        z={kh + (tier >= 1 ? 76 : 32)}
        color={tier >= 2 ? '#e0b030' : '#c0392b'}
        h={30}
      />
      {/* передняя стена с воротами */}
      {wallLen(0.55, 3.42, 1.5, 0.26)}
      {wallLen(2.95, 3.42, 1.5, 0.26)}
      <Box
        x={ox + 2.05}
        y={oy + 3.3}
        w={0.9}
        d={0.5}
        h={wall + 10}
        c={PAL.stone}
        bricks="stone"
        left={(len) => (
          <g>
            <Doorway u={len / 2 - 11} w={22} h={28} />
            <path
              d={`M${len / 2 - 11} 10H${len / 2 + 11}M${len / 2 - 11} 18H${len / 2 + 11}`}
              stroke="#6a5a4a"
              strokeWidth="1.6"
            />
          </g>
        )}
      />
      {tw(0.55, 3.55, 't3')}
      {tw(4.45, 3.55, 't4')}
      <Flag x={ox + 0.55} y={oy + 3.55} z={th + 34} color="#c0392b" h={20} />
      <Flag x={ox + 4.45} y={oy + 3.55} z={th + 34} color="#c0392b" h={20} />
    </g>
  );
}

function Farm({ ox, oy, tier, id }: B) {
  const rows = Array.from({ length: 6 }, (_, i) => i);
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={4} d={4} />
      <Patch x={ox} y={oy + 1.6} w={2.6} d={2.4} fill="#7a5530" stroke="#5a3a1a" />
      {rows.map((i) => {
        const a = iso(ox + 0.1, oy + 1.7 + i * 0.37, 0);
        const b = iso(ox + 2.5, oy + 1.7 + i * 0.37, 0);
        return (
          <g key={i}>
            <line
              x1={a[0]}
              y1={a[1]}
              x2={b[0]}
              y2={b[1]}
              stroke={i % 2 ? '#e0b030' : '#c9a020'}
              strokeWidth="7"
              strokeLinecap="round"
              opacity=".95"
            />
            <line
              x1={a[0]}
              y1={a[1] - 3}
              x2={b[0]}
              y2={b[1] - 3}
              stroke="#f2cf6b"
              strokeWidth="2"
              strokeDasharray="3 5"
              strokeLinecap="round"
            />
          </g>
        );
      })}
      {/* амбар */}
      <Box
        x={ox + 2.4}
        y={oy + 0.2}
        w={1.5}
        d={1.7}
        h={32}
        c={faces('#b5442e')}
        bricks="wood"
        left={(len) => (
          <g>
            <rect
              x={len * 0.3}
              y="0"
              width={len * 0.4}
              height="24"
              fill="#8a3324"
              stroke="#5a1f14"
              strokeWidth="1"
            />
            <path
              d={`M${len * 0.3} 0L${len * 0.7} 24M${len * 0.7} 0L${len * 0.3} 24`}
              stroke="#f3ead0"
              strokeWidth="2"
            />
          </g>
        )}
      />
      <Gable x={ox + 2.4} y={oy + 0.2} w={1.5} d={1.7} z={32} rise={22} c={PAL.slate} axis="y" />
      {/* мельница */}
      <Box x={ox + 0.2} y={oy + 0.2} w={1} d={1} h={54} c={PAL.plaster} bricks={null} />
      <Pyramid x={ox + 0.1} y={oy + 0.1} w={1.2} d={1.2} z={54} rise={24} c={faces('#8a3324')} />
      {(() => {
        const [cx, cy] = iso(ox + 1.2, oy + 1.2, 42);
        return (
          <g
            className="scene-blades"
            style={{ transformOrigin: `${cx}px ${cy}px`, transformBox: 'view-box' }}
          >
            {[0, 90, 180, 270].map((a) => (
              <g key={a} transform={`rotate(${a} ${cx} ${cy})`}>
                <rect x={cx - 2} y={cy - 40} width="4" height="40" fill="#5a3a20" />
                <rect
                  x={cx + 2}
                  y={cy - 38}
                  width="12"
                  height="24"
                  fill="#f3ead0"
                  stroke="#8a6a40"
                  strokeWidth="1"
                />
              </g>
            ))}
            <circle cx={cx} cy={cy} r="4" fill="#e0b030" />
          </g>
        );
      })()}
      {tier >= 1 && (
        <Tower
          cx={ox + 3.3}
          cy={oy + 2.9}
          r={0.45}
          h={56}
          c={PAL.white}
          roof={PAL.redRoof}
          roofRise={22}
          id={`${id}-silo`}
        />
      )}
    </g>
  );
}

function Goldmine({ ox, oy, tier }: B) {
  const rock1 = faces('#9a8a74');
  const rock2 = faces('#a89880');
  const rock3 = faces('#b8a88e');
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={4} d={4} />
      <Box x={ox + 0.3} y={oy + 0.3} w={3.2} d={2.6} h={40} c={rock1} bricks={null} />
      <Box x={ox + 0.8} y={oy + 0.55} w={2.3} d={1.8} h={80} c={rock2} bricks={null} />
      <Box x={ox + 1.3} y={oy + 0.8} w={1.3} d={1} h={112} c={rock3} bricks={null} />
      <Pyramid x={ox + 1.2} y={oy + 0.7} w={1.5} d={1.2} z={112} rise={26} c={faces('#c4b49a')} />
      {/* золотые жилы на скале */}
      {[
        [1.4, 1.85, 78],
        [1.9, 2.35, 32],
        [2.9, 2.9, 24],
      ].map(([x, y, z], i) => {
        const p = iso(ox + x!, oy + y!, z!);
        return (
          <g key={i}>
            <path
              d={`M${p[0] - 9} ${p[1]}l6 -5 7 3 5 -4 5 6-5 5-8-2Z`}
              fill="#e0b030"
              stroke="#8a6a12"
              strokeWidth="1"
              strokeLinejoin="round"
            />
            <circle
              className="scene-twinkle"
              style={{ animationDelay: `${i * 0.7}s` }}
              cx={p[0] + 2}
              cy={p[1] - 3}
              r="2.200"
              fill="#fff6c0"
            />
          </g>
        );
      })}
      {/* вход в шахту */}
      <Box
        x={ox + 0.3}
        y={oy + 2.9}
        w={3.2}
        d={0.5}
        h={40}
        c={rock1}
        left={(len) => (
          <g>
            <path
              d={`M${len * 0.3} 0V22a${len * 0.14} 12 0 0 1 ${len * 0.28} 0V0Z`}
              fill="#1a0f08"
            />
            <path
              d={`M${len * 0.3 - 2} 0V26M${len * 0.58 + 2} 0V26M${len * 0.3 - 4} 26H${len * 0.58 + 4}`}
              stroke="#8a5a2c"
              strokeWidth="4"
              strokeLinecap="round"
            />
            <circle cx={len * 0.44} cy="26" r="3" fill="#ffd76a" className="scene-glow" />
          </g>
        )}
      />
      {(() => {
        const a = iso(ox + 2, oy + 3.6, 0);
        const b = iso(ox + 3.7, oy + 3.6, 0);
        const c = iso(ox + 2.9, oy + 3.6, 0);
        return (
          <g>
            <line x1={a[0]} y1={a[1]} x2={b[0]} y2={b[1]} stroke="#4a4f56" strokeWidth="3" />
            <line
              x1={a[0]}
              y1={a[1] + 5}
              x2={b[0]}
              y2={b[1] + 5}
              stroke="#4a4f56"
              strokeWidth="3"
            />
            <path
              d={`M${c[0] - 14} ${c[1] - 4}h28l-4 14h-20Z`}
              fill="#8a5a34"
              stroke="#3a2416"
              strokeWidth="1.400"
              strokeLinejoin="round"
            />
            {[-8, 0, 8].map((dx) => (
              <circle
                key={dx}
                cx={c[0] + dx}
                cy={c[1] - 7 - Math.abs(dx) / 4}
                r="5"
                fill="#e0b030"
                stroke="#8a6a12"
                strokeWidth="1"
              />
            ))}
          </g>
        );
      })()}
      {tier >= 2 && (
        <Box x={ox + 0.4} y={oy + 3.4} w={0.6} d={0.4} h={14} c={PAL.wood} bricks="wood" />
      )}
    </g>
  );
}

function Sawmill({ ox, oy, tier }: B) {
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={3} d={3} />
      {/* навес на столбах */}
      {[
        [0.3, 0.3],
        [2.4, 0.3],
        [0.3, 2.1],
        [2.4, 2.1],
      ].map(([x, y], i) => (
        <Box key={i} x={ox + x!} y={oy + y!} w={0.2} d={0.2} h={44} c={PAL.wood} />
      ))}
      <Box x={ox + 0.3} y={oy + 0.5} w={2.3} d={1.6} h={12} c={PAL.timber} bricks="wood" />
      <Gable
        x={ox + 0.15}
        y={oy + 0.15}
        w={2.7}
        d={2.3}
        z={44}
        rise={26}
        c={PAL.thatch}
        axis="x"
        over={0.1}
      />
      {/* пила */}
      {(() => {
        const [cx, cy] = iso(ox + 1.5, oy + 1.9, 26);
        return (
          <g
            className="scene-saw"
            style={{ transformOrigin: `${cx}px ${cy}px`, transformBox: 'view-box' }}
          >
            <circle cx={cx} cy={cy} r="15" fill="#c8d0d8" stroke="#4a4f56" strokeWidth="1.400" />
            {Array.from({ length: 12 }, (_, i) => (
              <path
                key={i}
                d={`M${cx - 2} ${cy - 15}l2 -5 2 5Z`}
                transform={`rotate(${i * 30} ${cx} ${cy})`}
                fill="#c8d0d8"
                stroke="#4a4f56"
                strokeWidth=".8"
              />
            ))}
            <circle cx={cx} cy={cy} r="3.500" fill="#6f7c86" />
          </g>
        );
      })()}
      {/* бревна */}
      {[0, 1, 2].map((r) =>
        [0, 1, 2, 3].slice(0, 4 - r).map((c) => {
          const p = iso(ox + 2.2 + r * 0.12, oy + 2.2 + c * 0.18 - r * 0.09, 6 + r * 9);
          return (
            <g key={`${r}${c}`}>
              <rect
                x={p[0] - 22}
                y={p[1] - 4}
                width="30"
                height="9"
                rx="4.5"
                fill="#9a6a3c"
                stroke="#4a2c14"
                strokeWidth="1.2"
                transform={`skewY(26.5)`}
                style={{ transformBox: 'fill-box' }}
              />
              <circle
                cx={p[0] + 8}
                cy={p[1] + 0.5}
                r="4.500"
                fill="#e2c08a"
                stroke="#4a2c14"
                strokeWidth="1"
              />
            </g>
          );
        }),
      )}
      {/* водяное колесо */}
      {(() => {
        const [cx, cy] = iso(ox + 3, oy + 1.2, 20);
        return (
          <g
            className="scene-saw"
            style={{ transformOrigin: `${cx}px ${cy}px`, transformBox: 'view-box' }}
          >
            <circle cx={cx} cy={cy} r="19" fill="none" stroke="#7a4a24" strokeWidth="5" />
            {Array.from({ length: 8 }, (_, i) => (
              <g key={i} transform={`rotate(${i * 45} ${cx} ${cy})`}>
                <line x1={cx} y1={cy} x2={cx} y2={cy - 19} stroke="#5a3620" strokeWidth="2.400" />
                <rect
                  x={cx - 3.5}
                  y={cy - 24}
                  width="7"
                  height="8"
                  fill="#9a6a3c"
                  stroke="#4a2c14"
                  strokeWidth="1"
                />
              </g>
            ))}
          </g>
        );
      })()}
      {tier >= 2 && <Box x={ox + 0.1} y={oy + 2.6} w={0.4} d={0.4} h={14} c={PAL.wood} />}
    </g>
  );
}

function Quarry({ ox, oy, tier }: B) {
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={3} d={3} />
      <Patch x={ox + 0.1} y={oy + 0.2} w={2.6} d={2.4} fill="#8a8478" stroke="#4a463f" />
      <Patch x={ox + 0.5} y={oy + 0.6} w={1.8} d={1.6} fill="#6f6a60" />
      {/* ступени карьера и глыбы */}
      <Box x={ox + 0.1} y={oy + 0.2} w={0.6} d={2.4} h={30} c={PAL.stoneDark} bricks="stone" />
      <Box x={ox + 0.7} y={oy + 0.2} w={2} d={0.5} h={20} c={PAL.stoneDark} bricks="stone" />
      {[
        [1.2, 1.2, 12],
        [1.7, 1.6, 18],
        [2.1, 1.1, 10],
      ].map(([x, y, h], i) => (
        <Box
          key={i}
          x={ox + x!}
          y={oy + y!}
          w={0.5}
          d={0.5}
          h={h!}
          c={faces('#cfc8ba')}
          bricks="stone"
        />
      ))}
      {/* кран */}
      {(() => {
        const base = iso(ox + 2.6, oy + 2.4, 0);
        const top = iso(ox + 2.6, oy + 2.4, 96);
        const tip = iso(ox + 1.2, oy + 2.4, 88);
        const hook = iso(ox + 1.2, oy + 2.4, 46);
        return (
          <g strokeLinecap="round">
            <line
              x1={base[0]}
              y1={base[1]}
              x2={top[0]}
              y2={top[1]}
              stroke="#7a4a24"
              strokeWidth="7"
            />
            <line
              x1={top[0]}
              y1={top[1]}
              x2={tip[0]}
              y2={tip[1]}
              stroke="#7a4a24"
              strokeWidth="6"
            />
            <line
              x1={tip[0]}
              y1={tip[1]}
              x2={hook[0]}
              y2={hook[1]}
              stroke="#e2d2a4"
              strokeWidth="1.600"
            />
            <rect
              x={hook[0] - 9}
              y={hook[1]}
              width="18"
              height="14"
              fill="#cfc8ba"
              stroke="#4a463f"
              strokeWidth="1.200"
            />
          </g>
        );
      })()}
      {tier >= 1 && <Box x={ox + 0.4} y={oy + 2.7} w={0.7} d={0.3} h={12} c={PAL.wood} />}
    </g>
  );
}

function Warehouse({ ox, oy, tier }: B) {
  const roof = tier >= 2 ? PAL.blueRoof : faces('#8a5a34');
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={3} d={2} />
      <Box
        x={ox + 0.15}
        y={oy + 0.15}
        w={2.7}
        d={1.5}
        h={40}
        c={PAL.timber}
        bricks="wood"
        left={(len) => (
          <g>
            <rect
              x={len / 2 - 22}
              y="0"
              width="44"
              height="30"
              rx="2"
              fill="#5a3a26"
              stroke="#2a1a0e"
              strokeWidth="1.4"
            />
            <path
              d={`M${len / 2} 0V30M${len / 2 - 22} 8L${len / 2} 30M${len / 2 + 22} 8L${len / 2} 30`}
              stroke="#2a1a0e"
              strokeWidth="1.6"
            />
          </g>
        )}
      />
      <Gable x={ox + 0.15} y={oy + 0.15} w={2.7} d={1.5} z={40} rise={26} c={roof} axis="x" />
      {[
        [2.5, 1.7],
        [2.85, 1.55],
      ].map(([x, y], i) => (
        <Box
          key={i}
          x={ox + x!}
          y={oy + y!}
          w={0.3}
          d={0.3}
          h={12 + i * 4}
          c={PAL.wood}
          bricks="wood"
        />
      ))}
      {tier >= 1 && (
        <Box x={ox + 0.05} y={oy + 1.75} w={0.3} d={0.3} h={14} c={PAL.wood} bricks="wood" />
      )}
    </g>
  );
}

function Forge({ ox, oy, tier }: B) {
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={3} d={3} />
      <Box
        x={ox + 0.2}
        y={oy + 0.3}
        w={2.4}
        d={2}
        h={46}
        c={PAL.stoneDark}
        bricks="stone"
        left={(len) => (
          <g>
            <path
              d={`M${len * 0.2} 0V20a${len * 0.11} 12 0 0 1 ${len * 0.22} 0V0Z`}
              fill="#1a0f08"
            />
            <path
              d={`M${len * 0.24} 0V18a${len * 0.07} 8 0 0 1 ${len * 0.14} 0V0Z`}
              fill="#ff8a1e"
              className="scene-glow"
            />
            <path
              d={`M${len * 0.27} 0V12a${len * 0.04} 5 0 0 1 ${len * 0.08} 0V0Z`}
              fill="#ffe27a"
            />
            <Win u={len * 0.62} v={22} lit />
          </g>
        )}
      />
      <Gable x={ox + 0.2} y={oy + 0.3} w={2.4} d={2} z={46} rise={22} c={PAL.slate} axis="x" />
      <Box x={ox + 1.8} y={oy + 0.5} w={0.5} d={0.5} h={96} c={PAL.stoneDark} bricks="stone" />
      {(() => {
        const [sx, sy] = iso(ox + 2.05, oy + 0.75, 100);
        return (
          <g>
            {[0, 1, 2].map((i) => (
              <circle
                key={i}
                className="scene-smoke"
                cx={sx}
                cy={sy}
                r={5 + i}
                fill="#f3f0e8"
                style={{ animationDelay: `${i * 0.9}s` }}
              />
            ))}
          </g>
        );
      })()}
      {/* наковальня */}
      <Box x={ox + 0.3} y={oy + 2.5} w={0.5} d={0.3} h={10} c={faces('#4a4f56')} />
      <Box x={ox + 0.25} y={oy + 2.45} w={0.6} d={0.4} h={4} z={10} c={faces('#4a4f56')} />
      {[0, 1, 2].map((i) => {
        const p = iso(ox + 0.55, oy + 2.6, 16);
        return (
          <circle
            key={i}
            className="scene-spark"
            style={{ animationDelay: `${i * 0.35}s` }}
            cx={p[0]}
            cy={p[1]}
            r="2"
            fill="#ffd27a"
          />
        );
      })}
      {tier >= 1 && (
        <Box x={ox + 2.4} y={oy + 2.3} w={0.4} d={0.4} h={18} c={PAL.wood} bricks="wood" />
      )}
    </g>
  );
}

function Academy({ ox, oy, tier }: B) {
  const dome = tier >= 2 ? PAL.purpleRoof : PAL.blueRoof;
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={3} d={3} />
      <Box
        x={ox + 0.2}
        y={oy + 0.8}
        w={2.6}
        d={2}
        h={38}
        c={PAL.white}
        left={(len) => (
          <g>
            <Win u={len * 0.14} v={12} lit w={10} h={16} />
            <Win u={len * 0.5} v={12} lit w={10} h={16} />
            <Doorway u={len * 0.72} w={16} h={26} color="#5a3a26" />
          </g>
        )}
      />
      <Gable x={ox + 0.2} y={oy + 0.8} w={2.6} d={2} z={38} rise={16} c={dome} axis="x" />
      <Box
        x={ox + 1}
        y={oy + 0.5}
        w={1}
        d={1}
        h={94 + tier * 8}
        c={PAL.white}
        left={(len) => (
          <g>
            <Win u={len * 0.33} v={40} lit w={10} h={18} />
            <Win u={len * 0.33} v={66} lit={tier >= 1} w={10} h={16} />
          </g>
        )}
      />
      <Pyramid x={ox + 0.9} y={oy + 0.4} w={1.2} d={1.2} z={94 + tier * 8} rise={40} c={dome} />
      {(() => {
        const [sx, sy] = iso(ox + 1.5, oy + 1, 94 + tier * 8 + 44);
        return (
          <path
            d={`M${sx} ${sy - 12}l3.500 7 8 1-6 5.500 1.500 8-7-4-7 4 1.500-8-6-5.500 8-1Z`}
            fill="#ffe27a"
            stroke="#8a6a12"
            strokeWidth="1"
            transform={`translate(0 6)`}
          />
        );
      })()}
    </g>
  );
}

function Hospital({ ox, oy, tier }: B) {
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={3} d={3} />
      <Box
        x={ox + 0.2}
        y={oy + 0.4}
        w={2.4}
        d={2}
        h={40}
        c={PAL.white}
        left={(len) => (
          <g>
            <Win u={len * 0.16} v={14} lit />
            <Doorway u={len * 0.44} w={16} h={26} color="#5a3a26" />
            <rect x={len * 0.75 - 3} y="6" width="6" height="18" fill="#c0392b" />
            <rect x={len * 0.75 - 9} y="12" width="18" height="6" fill="#c0392b" />
          </g>
        )}
      />
      <Gable
        x={ox + 0.2}
        y={oy + 0.4}
        w={2.4}
        d={2}
        z={40}
        rise={20}
        c={tier >= 2 ? PAL.greenRoof : PAL.redRoof}
        axis="x"
      />
      {/* палатка */}
      <Pyramid x={ox + 2.2} y={oy + 2.2} w={0.7} d={0.6} z={0} rise={26} c={PAL.white} />
      {tier >= 1 &&
        [0, 1, 2].map((i) => {
          const p = iso(ox + 0.4 + i * 0.35, oy + 2.75, 0);
          return (
            <circle
              key={i}
              cx={p[0]}
              cy={p[1] - 4}
              r="5"
              fill="#58ab4e"
              stroke="#2f6a2a"
              strokeWidth="1.200"
            />
          );
        })}
    </g>
  );
}

function Barracks({ ox, oy, tier }: B) {
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={4} d={3} />
      <Box
        x={ox + 0.2}
        y={oy + 0.3}
        w={3.2}
        d={1.8}
        h={38}
        c={tier >= 1 ? PAL.stone : PAL.timber}
        bricks={tier >= 1 ? 'stone' : 'wood'}
        left={(len) => (
          <g>
            <Win u={len * 0.12} v={14} lit />
            <Doorway u={len * 0.44} w={20} h={28} />
            <Win u={len * 0.8} v={14} lit />
          </g>
        )}
      />
      <Gable
        x={ox + 0.2}
        y={oy + 0.3}
        w={3.2}
        d={1.8}
        z={38}
        rise={24}
        c={tier >= 2 ? PAL.blueRoof : PAL.redRoof}
        axis="x"
      />
      <Flag x={ox + 2.9} y={oy + 1.2} z={62} color={tier >= 1 ? '#2f5fae' : '#c0392b'} h={30} />
      {/* тренировочный манекен и стойка с копьями */}
      {(() => {
        const p = iso(ox + 0.5, oy + 2.6, 0);
        const q = iso(ox + 3, oy + 2.5, 0);
        return (
          <g strokeLinecap="round">
            <line x1={p[0]} y1={p[1]} x2={p[0]} y2={p[1] - 30} stroke="#7a4a24" strokeWidth="4" />
            <line
              x1={p[0] - 10}
              y1={p[1] - 22}
              x2={p[0] + 10}
              y2={p[1] - 22}
              stroke="#7a4a24"
              strokeWidth="3.500"
            />
            <circle
              cx={p[0]}
              cy={p[1] - 34}
              r="6"
              fill="#d9b27a"
              stroke="#4a2c14"
              strokeWidth="1.200"
            />
            <line x1={q[0]} y1={q[1]} x2={q[0]} y2={q[1] - 34} stroke="#7a4a24" strokeWidth="3" />
            <line
              x1={q[0] + 8}
              y1={q[1] + 2}
              x2={q[0] + 8}
              y2={q[1] - 38}
              stroke="#7a4a24"
              strokeWidth="3"
            />
            <path
              d={`M${q[0] - 3} ${q[1] - 34}l3 -8 3 8ZM${q[0] + 5} ${q[1] - 38}l3 -8 3 8Z`}
              fill="#c8d0d8"
              stroke="#4a4f56"
              strokeWidth=".8"
            />
          </g>
        );
      })()}
    </g>
  );
}

/** Круглая башня-основа для башен обороны: камень, зубцы и площадка. */
function StoneTower({
  ox,
  oy,
  h,
  id,
  roof,
  tier,
}: {
  ox: number;
  oy: number;
  h: number;
  id: string;
  roof?: Faces;
  tier: Tier;
}) {
  return (
    <g>
      <Tower
        cx={ox + 1}
        cy={oy + 1}
        r={0.78}
        h={h}
        c={PAL.stone}
        roof={roof}
        roofRise={roof ? 30 : 0}
        id={id}
        cap={!roof}
      />
      {!roof &&
        [0, 60, 120, 180, 240, 300].map((a) => {
          const [sx, sy] = iso(ox + 1, oy + 1, h);
          const r = 0.78 * 32;
          const x = sx + Math.cos((a * Math.PI) / 180) * r * 0.86;
          const y = sy + Math.sin((a * Math.PI) / 180) * r * 0.43;
          return (
            <rect
              key={a}
              x={x - 4}
              y={y - 9}
              width="8"
              height="9"
              fill="#b8b1a2"
              stroke="#4a463f"
              strokeWidth="1.200"
            />
          );
        })}
      {tier >= 2 && <Flag x={ox + 1} y={oy + 1} z={h + (roof ? 30 : 8)} color="#e0b030" h={22} />}
    </g>
  );
}

function ArcherTower({ ox, oy, tier, id }: B) {
  const h = 92 + tier * 12;
  const [px, py] = iso(ox + 1, oy + 1, h + 4);
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={2} d={2} />
      <StoneTower ox={ox} oy={oy} h={h} id={id} tier={tier} />
      {/* деревянная площадка с навесом и лучником */}
      <Box x={ox + 0.4} y={oy + 0.4} w={1.2} d={1.2} h={6} z={h} c={PAL.wood} bricks="wood" />
      <Gable
        x={ox + 0.3}
        y={oy + 0.3}
        w={1.4}
        d={1.4}
        z={h + 34}
        rise={20}
        c={tier >= 1 ? PAL.blueRoof : PAL.redRoof}
        axis="x"
      />
      {[
        [0.4, 0.4],
        [1.5, 0.4],
        [0.4, 1.5],
        [1.5, 1.5],
      ].map(([x, y], i) => (
        <Box
          key={i}
          x={ox + x! - 0.05}
          y={oy + y! - 0.05}
          w={0.1}
          d={0.1}
          h={34}
          z={h + 4}
          c={PAL.wood}
        />
      ))}
      <g transform={`translate(${px - 14} ${py - 44})`}>
        <NpcMini kind="archer" />
      </g>
      {/* стрелы в колчане у входа */}
      {(() => {
        const q = iso(ox + 0.4, oy + 1.9, 0);
        return <Doorway2 x={q[0]} y={q[1]} />;
      })()}
    </g>
  );
}

function Doorway2({ x, y }: { x: number; y: number }) {
  return (
    <path
      d={`M${x + 6} ${y}v-16a8 8 0 0 1 16 0v16Z`}
      fill="#3a2416"
      stroke="#1a0f08"
      strokeWidth="1.200"
    />
  );
}

/** Крошечная фигурка стрелка/мага для башен (упрощённая, без лишних деталей). */
function NpcMini({ kind }: { kind: 'archer' | 'mage' }) {
  const body = kind === 'archer' ? '#3f7a3a' : '#5a4aa8';
  return (
    <g>
      <ellipse cx="14" cy="34" rx="8" ry="3" fill="#000" opacity=".2" />
      <rect
        x="9"
        y="16"
        width="10"
        height="16"
        rx="4"
        fill={body}
        stroke="#2a1a0e"
        strokeWidth="1.200"
      />
      <circle cx="14" cy="11" r="6.500" fill="#f0c49a" stroke="#2a1a0e" strokeWidth="1.200" />
      {kind === 'archer' ? (
        <path d="M6 10a8 8 0 0 1 16 0Z" fill="#3c6f2c" stroke="#2a1a0e" strokeWidth="1.200" />
      ) : (
        <path
          d="M6 10c2-4 5-12 8-12s6 8 8 12Z"
          fill="#5a4aa8"
          stroke="#2a1a0e"
          strokeWidth="1.200"
        />
      )}
      {kind === 'archer' ? (
        <path d="M24 6c6 6 6 18 0 24" fill="none" stroke="#7a4a24" strokeWidth="2" />
      ) : (
        <>
          <line x1="24" y1="8" x2="24" y2="32" stroke="#7a4a24" strokeWidth="2" />
          <circle cx="24" cy="6" r="3.500" fill="#7fd6ff" className="scene-glow" />
        </>
      )}
    </g>
  );
}

function BallistaTower({ ox, oy, tier, id }: B) {
  const h = 84 + tier * 10;
  const [px, py] = iso(ox + 1, oy + 1, h);
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={2} d={2} />
      <Box
        x={ox + 0.15}
        y={oy + 0.15}
        w={1.7}
        d={1.7}
        h={h}
        c={PAL.stoneDark}
        bricks="stone"
        left={(len) => (
          <path
            d={`M${len / 2 - 6} 20v14M${len / 2 + 6} 20v14`}
            stroke="#1a0f08"
            strokeWidth="3"
            strokeLinecap="round"
          />
        )}
      />
      <Crenels x={ox + 0.15} y={oy + 0.15} w={1.7} d={1.7} z={h} c={PAL.stoneDark} />
      {/* баллиста на площадке */}
      <g transform={`translate(${px} ${py})`}>
        <path
          d="M-26 -6 26 -6 22 4H-22Z"
          fill="#9a6a3c"
          stroke="#2a1a0e"
          strokeWidth="1.400"
          strokeLinejoin="round"
        />
        <path
          d="M-22 -14c14 8 30 8 44 0-2 6-6 9-10 9H-12c-4 0-8-3-10-9Z"
          fill="#7a4a24"
          stroke="#2a1a0e"
          strokeWidth="1.300"
          strokeLinejoin="round"
        />
        <path d="M-16 -8 20 -16" stroke="#c8d0d8" strokeWidth="3.500" strokeLinecap="round" />
        <path d="M20 -16l7-2.500-3 6.500Z" fill="#c8d0d8" stroke="#4a4f56" strokeWidth="1" />
        <circle cx="-2" cy="-4" r="4" fill="#5a3620" stroke="#2a1a0e" strokeWidth="1.200" />
      </g>
      {tier >= 1 && <Flag x={ox + 0.4} y={oy + 0.4} z={h + 6} color="#2f5fae" h={26} />}
      <Doorway2 x={iso(ox + 0.4, oy + 1.9, 0)[0]} y={iso(ox + 0.4, oy + 1.9, 0)[1]} />
      <Tower cx={ox + 1.85} cy={oy + 0.25} r={0.22} h={h + 16} c={PAL.stoneDark} id={`${id}-t`} />
    </g>
  );
}

function StormTower({ ox, oy, tier, id }: B) {
  const h = 110 + tier * 14;
  const [px, py] = iso(ox + 1, oy + 1, h);
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={2} d={2} />
      <Tower
        cx={ox + 1}
        cy={oy + 1}
        r={0.72}
        h={h}
        c={faces('#5a5f78')}
        roof={faces('#3a3f5a')}
        roofRise={40}
        id={id}
      />
      {[0, 1, 2].map((i) => (
        <ellipse
          key={i}
          className="scene-glow"
          style={{ animationDelay: `${i * 0.4}s` }}
          cx={px}
          cy={py + 26 - i * 22}
          rx="34"
          ry="10"
          fill="none"
          stroke="#9ad8ff"
          strokeWidth="2"
          opacity=".6"
        />
      ))}
      <path
        className="scene-bolt"
        d={`M${px + 4} ${py - 64}l-9 22 8 2-10 24`}
        fill="none"
        stroke="#e8f8ff"
        strokeWidth="3.500"
        strokeLinejoin="round"
        strokeLinecap="round"
      />
      <path
        className="scene-bolt"
        style={{ animationDelay: '0.9s' }}
        d={`M${px - 24} ${py - 30}l6 12-6 3 5 12`}
        fill="none"
        stroke="#9ad8ff"
        strokeWidth="2.600"
        strokeLinejoin="round"
        strokeLinecap="round"
      />
      <circle cx={px} cy={py - 56} r="8" fill="#9ad8ff" opacity=".55" className="scene-glow" />
      {[0, 1, 2, 3].map((i) => (
        <rect key={i} x={px - 44 + i * 6} y={py + 70 - i * 3} width="0" height="0" />
      ))}
    </g>
  );
}

function MageTower({ ox, oy, tier, id }: B) {
  const h = 104 + tier * 12;
  const [px, py] = iso(ox + 1, oy + 1, h);
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={2} d={2} />
      <Tower
        cx={ox + 1}
        cy={oy + 1}
        r={0.7}
        h={h}
        c={faces('#7a5ab0')}
        roof={faces('#3f2f8a')}
        roofRise={46}
        id={id}
      />
      <Box
        x={ox + 0.35}
        y={oy + 0.35}
        w={1.3}
        d={1.3}
        h={18}
        c={PAL.stone}
        bricks="stone"
        left={(len) => <Doorway u={len / 2 - 9} w={18} h={22} color="#3a2416" />}
      />
      {[0, 1].map((i) => (
        <g key={i} className="scene-float" style={{ animationDelay: `${i * 1.1}s` }}>
          <ellipse
            cx={px}
            cy={py - 70}
            rx={32 - i * 6}
            ry={9 - i * 2}
            fill="none"
            stroke="#c9a8ff"
            strokeWidth="2.200"
            opacity=".7"
          />
        </g>
      ))}
      <g className="scene-float">
        <circle
          cx={px}
          cy={py - 84}
          r="10"
          fill="#7fd6ff"
          stroke="#3f2f8a"
          strokeWidth="2"
          className="scene-glow"
        />
        <circle cx={px - 3} cy={py - 87} r="3" fill="#fff" opacity=".8" />
      </g>
      {tier >= 1 &&
        [0, 1, 2].map((i) => (
          <circle
            key={i}
            className="scene-twinkle"
            style={{ animationDelay: `${i * 0.5}s` }}
            cx={px - 30 + i * 30}
            cy={py - 40 - (i % 2) * 20}
            r="2.600"
            fill="#e8d8ff"
          />
        ))}
      <Flag x={ox + 1} y={oy + 1} z={h + 46} color="#a86ad8" h={18} />
    </g>
  );
}

function Fishery({ ox, oy, tier }: B) {
  return (
    <g>
      {/* причал уходит в воду вправо от острова */}
      {Array.from({ length: 6 }, (_, i) => (
        <Box
          key={i}
          x={ox + 1 + i * 0.5}
          y={oy + 1.6}
          w={0.5}
          d={0.9}
          h={5}
          z={-1 + (i > 2 ? -1 : 0)}
          c={PAL.wood}
          bricks="wood"
        />
      ))}
      {[0, 2, 4].map((i) => (
        <Box key={i} x={ox + 1.1 + i * 0.5} y={oy + 1.55} w={0.12} d={0.12} h={16} c={PAL.wood} />
      ))}
      {/* хижина */}
      <Box
        x={ox + 0.2}
        y={oy + 0.3}
        w={1.6}
        d={1.4}
        h={30}
        c={PAL.timber}
        bricks="wood"
        left={(len) => (
          <g>
            <Doorway u={len * 0.3} w={14} h={22} />
            <Win u={len * 0.7} v={12} w={9} h={11} lit />
          </g>
        )}
      />
      <Gable x={ox + 0.2} y={oy + 0.3} w={1.6} d={1.4} z={30} rise={18} c={PAL.thatch} axis="y" />
      {/* лодка */}
      {(() => {
        const b = iso(ox + 3.4, oy + 2.1, -2);
        return (
          <g className="scene-float" transform={`translate(${b[0]} ${b[1]})`}>
            <path
              d="M-26 -6h52l-8 12h-36Z"
              fill="#a8763c"
              stroke="#3a2416"
              strokeWidth="1.400"
              strokeLinejoin="round"
            />
            <path
              d="M-2 -6V-34l20 22Z"
              fill="#f3ead0"
              stroke="#8a6a40"
              strokeWidth="1.200"
              strokeLinejoin="round"
            />
            <line x1="-2" y1="-6" x2="-2" y2="-36" stroke="#4a2c14" strokeWidth="2" />
          </g>
        );
      })()}
      {/* сети на кольях и садки */}
      {(() => {
        const n = iso(ox + 2.4, oy + 0.4, 0);
        return (
          <g>
            <line
              x1={n[0] - 18}
              y1={n[1]}
              x2={n[0] - 18}
              y2={n[1] - 32}
              stroke="#5a3620"
              strokeWidth="3"
            />
            <line
              x1={n[0] + 18}
              y1={n[1] + 10}
              x2={n[0] + 18}
              y2={n[1] - 22}
              stroke="#5a3620"
              strokeWidth="3"
            />
            <path
              d={`M${n[0] - 18} ${n[1] - 30}q18 22 36 10`}
              fill="none"
              stroke="#e8d6a8"
              strokeWidth="1.400"
              strokeDasharray="3 3"
            />
          </g>
        );
      })()}
      {tier >= 2 && (
        <Box x={ox + 1.9} y={oy + 0.5} w={0.5} d={0.5} h={12} c={PAL.wood} bricks="wood" />
      )}
    </g>
  );
}

function DiamondMine({ ox, oy, tier }: B) {
  const crystals: Array<[number, number, number, number]> = [
    [0.6, 0.7, 34, 0],
    [1.6, 0.5, 46, 0.4],
    [2.2, 1.4, 30, 0.8],
    [1.0, 1.6, 26, 1.2],
  ];
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={3} d={3} />
      <Box x={ox + 0.1} y={oy + 0.2} w={2.7} d={2} h={26} c={faces('#5e6a80')} bricks={null} />
      <Box x={ox + 0.5} y={oy + 0.4} w={1.9} d={1.4} h={44} c={faces('#6a7690')} bricks={null} />
      {crystals.map(([x, y, hh, d], i) => {
        const [cx, cy] = iso(ox + x!, oy + y!, 26 + (i === 1 ? 18 : 0));
        return (
          <g key={i} className="scene-twinkle" style={{ animationDelay: `${d}s` }}>
            <path
              d={`M${cx} ${cy - hh!}l10 ${hh! * 0.45}-3 ${hh! * 0.55}h-14l-3-${hh! * 0.55}Z`}
              fill="#8fe3ff"
              stroke="#1a5a8a"
              strokeWidth="1.400"
              strokeLinejoin="round"
            />
            <path
              d={`M${cx} ${cy - hh!}l-7 ${hh! * 0.45}-3 ${hh! * 0.55}h6Z`}
              fill="#d8f6ff"
              opacity=".8"
            />
            <path
              d={`M${cx} ${cy - hh!}l10 ${hh! * 0.45}-3 ${hh! * 0.55}h-6Z`}
              fill="#3aa8e0"
              opacity=".7"
            />
          </g>
        );
      })}
      {/* вход и подпорки */}
      <Box
        x={ox + 0.2}
        y={oy + 2.2}
        w={2.4}
        d={0.5}
        h={34}
        c={faces('#5e6a80')}
        left={(len) => (
          <g>
            <path
              d={`M${len * 0.3} 0V20a${len * 0.15} 12 0 0 1 ${len * 0.3} 0V0Z`}
              fill="#0d1622"
            />
            <path
              d={`M${len * 0.3 - 3} 0V24M${len * 0.6 + 3} 0V24M${len * 0.3 - 5} 24H${len * 0.6 + 5}`}
              stroke="#8a5a2c"
              strokeWidth="4"
              strokeLinecap="round"
            />
            <circle cx={len * 0.45} cy="22" r="3" fill="#8fe3ff" className="scene-glow" />
          </g>
        )}
      />
      {(() => {
        const c = iso(ox + 2.2, oy + 2.9, 0);
        return (
          <g>
            <path
              d={`M${c[0] - 14} ${c[1] - 4}h28l-4 14h-20Z`}
              fill="#8a5a34"
              stroke="#3a2416"
              strokeWidth="1.400"
              strokeLinejoin="round"
            />
            {[-8, 0, 8].map((dx) => (
              <path
                key={dx}
                d={`M${c[0] + dx} ${c[1] - 16}l5 6-5 6-5-6Z`}
                fill="#8fe3ff"
                stroke="#1a5a8a"
                strokeWidth="1"
              />
            ))}
          </g>
        );
      })()}
      {tier >= 1 && (
        <Box x={ox + 2.4} y={oy + 0.3} w={0.4} d={0.4} h={20} c={PAL.wood} bricks="wood" />
      )}
    </g>
  );
}

const ART: Record<PlacedKey, (p: B) => ReactNode> = {
  castle: Castle,
  farm: Farm,
  goldmine: Goldmine,
  sawmill: Sawmill,
  quarry: Quarry,
  warehouse: Warehouse,
  forge: Forge,
  academy: Academy,
  hospital: Hospital,
  barracks: Barracks,
  fishery: Fishery,
  diamondmine: DiamondMine,
  magetower: MageTower,
  archertower: ArcherTower,
  ballistatower: BallistaTower,
  stormtower: StormTower,
};

/** Леса на стройке: столбы по углам, настилы, рабочий. */
function Scaffold({
  ox,
  oy,
  w,
  d,
  h,
}: {
  ox: number;
  oy: number;
  w: number;
  d: number;
  h: number;
}) {
  const corners = [iso(ox, oy + d, 0), iso(ox + w, oy + d, 0), iso(ox + w, oy, 0)];
  return (
    <g strokeLinecap="round">
      {corners.map(([x, y], i) => (
        <line key={i} x1={x} y1={y} x2={x} y2={y - h} stroke="#8a5a2c" strokeWidth="5" />
      ))}
      {[0.4, 0.7].map((f) => (
        <polyline
          key={f}
          points={pts(corners.map(([x, y]) => [x, y - h * f] as const))}
          fill="none"
          stroke="#c99a5b"
          strokeWidth="5"
        />
      ))}
      <line
        x1={corners[0]![0]}
        y1={corners[0]![1] - h * 0.4}
        x2={corners[1]![0]}
        y2={corners[1]![1] - h * 0.7}
        stroke="#7a4a24"
        strokeWidth="2.400"
      />
    </g>
  );
}

/** Здание на сцене: построенное, строящееся (леса) или ещё не построенное («призрак»). */
export function IsoBuilding({
  kind,
  ox,
  oy,
  tier,
  built,
  busy,
  worker,
  id,
  art,
}: {
  kind: PlacedKey;
  ox: number;
  oy: number;
  tier: Tier;
  built: boolean;
  busy: boolean;
  worker: ReactNode;
  id: string;
  /** Готовая картинка вместо встроенной SVG (art2); получает запасной вариант. */
  art?: (fallback: ReactNode) => ReactNode;
}) {
  const era = useEra((st) => st.era);
  const Art = era === 'modern' ? MODERN_ART[kind] : ART[kind];
  const fp = FOOTPRINT[kind];
  const ghost = !built;
  return (
    <g>
      <g
        opacity={ghost ? (busy ? 0.5 : 0.36) : 1}
        style={ghost ? { filter: 'saturate(.55)' } : undefined}
      >
        {art ? (
          art(<Art ox={ox} oy={oy} tier={tier} id={id} />)
        ) : (
          <Art ox={ox} oy={oy} tier={tier} id={id} />
        )}
      </g>
      {ghost && !busy && (
        <polygon
          points={pts([
            iso(ox, oy),
            iso(ox + fp.w, oy),
            iso(ox + fp.w, oy + fp.d),
            iso(ox, oy + fp.d),
          ])}
          fill="none"
          stroke="#f2cf6b"
          strokeWidth="2.600"
          strokeDasharray="9 7"
          strokeLinejoin="round"
        />
      )}
      {busy && (
        <g>
          <Scaffold ox={ox} oy={oy} w={fp.w} d={fp.d} h={72} />
          {(() => {
            const [x, y] = iso(ox + fp.w * 0.5, oy + fp.d * 0.9, 0);
            return <g transform={`translate(${x - 22} ${y - 68})`}>{worker}</g>;
          })()}
        </g>
      )}
    </g>
  );
}

export { Bricks, lighten };
