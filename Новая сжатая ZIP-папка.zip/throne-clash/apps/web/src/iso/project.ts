/**
 * Изометрическая проекция 2:1. Координаты x, y — в клетках, z — высота в единицах рисунка.
 * +x уходит вправо-вниз, +y — влево-вниз. Одна клетка = ромб 64×32.
 */
export const TW = 64;
export const TH = 32;
/** Единиц рисунка в одной клетке вдоль стены (1 единица = 1 пиксель по горизонтали). */
export const U = 32;

export type P2 = readonly [number, number];

export const iso = (x: number, y: number, z = 0): P2 => [
  (x - y) * (TW / 2),
  (x + y) * (TH / 2) - z,
];

export const pts = (list: readonly P2[]): string =>
  list.map(([a, b]) => `${round(a)},${round(b)}`).join(' ');
const round = (v: number): number => Math.round(v * 100) / 100;

/** Обратное преобразование для попадания курсором: экранная точка → клетка (на плоскости z=0). */
export function unproject(sx: number, sy: number): { x: number; y: number } {
  const a = sx / (TW / 2);
  const b = sy / (TH / 2);
  return { x: (a + b) / 2, y: (b - a) / 2 };
}

/** Матрица «стены»: плоский рисунок в координатах (u вдоль стены, v вверх) кладётся на грань. */
export function wallMatrix(
  face: 'left' | 'right',
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  z: number,
): string {
  if (face === 'left') {
    // грань y = y1, идёт вдоль +x
    const [e, f] = iso(x0, y1, z);
    return `matrix(1 0.5 0 -1 ${round(e)} ${round(f)})`;
  }
  // грань x = x1, u растёт от y1 к y0 (вправо-вверх)
  const [e, f] = iso(x1, y1, z);
  void x0;
  void y0;
  return `matrix(1 -0.5 0 -1 ${round(e)} ${round(f)})`;
}

/** Порядок отрисовки: дальние (меньше x+y) рисуются раньше ближних. */
export const depth = (x: number, y: number, w = 0, d = 0): number => x + y + w + d;

/** Ограничивающий прямоугольник набора точек — для областей нажатия. */
export function bounds(list: readonly P2[]): { x: number; y: number; w: number; h: number } {
  let x0 = Infinity;
  let y0 = Infinity;
  let x1 = -Infinity;
  let y1 = -Infinity;
  for (const [x, y] of list) {
    x0 = Math.min(x0, x);
    y0 = Math.min(y0, y);
    x1 = Math.max(x1, x);
    y1 = Math.max(y1, y);
  }
  return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
}
