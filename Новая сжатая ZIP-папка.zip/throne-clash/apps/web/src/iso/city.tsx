import type { ReactNode } from 'react';
import type { StructureKind } from '@tc/shared';
import { useEra } from '../store/era';
import { BOATS } from './ambient';
import { Panes } from './modern';
import {
  Box,
  Gable,
  GroundShadow,
  Patch,
  Pyramid,
  Tower,
  Win,
  faces,
  type Faces,
} from './primitives';
import { iso } from './project';
import { Cobble, IsoFlowers, IsoFountain, IsoLamp, IsoTree } from './props';

/**
 * Постройки города (D-66): каждая занимает одну клетку острова (морские — клетку воды).
 * У каждой два облика — средневековый и современный; какой показывать, решает эпоха из меню (`store/era`).
 * Облики собраны из небольшого набора «конструкторов» с параметрами, поэтому вид добавляется одной строкой.
 */
const C = {
  plaster: faces('#efe2b8'),
  timber: faces('#b98548'),
  stone: faces('#b8b1a2'),
  stoneLight: faces('#d8d2c0'),
  red: faces('#c0472f'),
  blue: faces('#3f68b4'),
  purple: faces('#7a4a9a'),
  green: faces('#3f8a5a'),
  gold: faces('#e0b030'),
  cream: faces('#f3efe6'),
  hedge: faces('#4f9a44'),
  wood: faces('#9a6a3c'),
  woodDark: faces('#6a4426'),
  thatch: faces('#d2b060'),
  slate: faces('#6a7280'),
  glass: faces('#69b4e0'),
  glassDeep: faces('#2f6fae'),
  white: faces('#f6f8fa'),
  steel: faces('#7d8b98'),
  concrete: faces('#cfd6dc'),
  orange: faces('#f0a03a'),
  teal: faces('#2fa37a'),
  cyan: faces('#4fd8e8'),
};

interface P {
  gx: number;
  gy: number;
}
type Art = (p: P) => ReactNode;

const key = (p: P, s: string): string => `${s}-${p.gx}-${p.gy}`;

// ── Средневековые конструкторы ──────────────────────────────────────────────

/** Дом: стены, двускатная крыша, окна, по желанию труба, флаг, вывеска. */
function Cottage({
  gx,
  gy,
  wall = C.plaster,
  roof = C.red,
  h = 20,
  w = 0.76,
  d = 0.76,
  rise = 15,
  axis = 'x',
  chimney = false,
  flag,
  sign,
  bricks = null,
}: P & {
  wall?: Faces;
  roof?: Faces;
  h?: number;
  w?: number;
  d?: number;
  rise?: number;
  axis?: 'x' | 'y';
  chimney?: boolean;
  flag?: string;
  sign?: string;
  bricks?: 'stone' | 'wood' | 'plaster' | null;
}) {
  const x0 = gx + (1 - w) / 2;
  const y0 = gy + (1 - d) / 2;
  return (
    <g>
      <GroundShadow x={gx} y={gy} w={1} d={1} />
      <Box
        x={x0}
        y={y0}
        w={w}
        d={d}
        h={h}
        c={wall}
        bricks={bricks}
        left={(len) => <Win u={len * 0.3} v={h * 0.4} w={8} h={10} lit />}
        right={(len) => <Win u={len * 0.4} v={h * 0.4} w={8} h={10} />}
      />
      <Gable
        x={x0 - 0.06}
        y={y0 - 0.06}
        w={w + 0.12}
        d={d + 0.12}
        z={h}
        rise={rise}
        c={roof}
        axis={axis}
      />
      {chimney && (
        <Box x={x0 + w * 0.7} y={y0 + d * 0.2} w={0.12} d={0.12} h={12} z={h} c={C.stone} />
      )}
      {flag && (
        <g>
          <Box x={x0 + w - 0.06} y={y0 + d - 0.06} w={0.05} d={0.05} h={20} z={h} c={C.woodDark} />
          <Box
            x={x0 + w - 0.02}
            y={y0 + d - 0.06}
            w={0.16}
            d={0.02}
            h={7}
            z={h + 12}
            c={faces(flag)}
          />
        </g>
      )}
      {sign && (
        <Box x={x0 + w + 0.01} y={y0 + d * 0.5} w={0.04} d={0.22} h={9} z={12} c={faces(sign)} />
      )}
    </g>
  );
}

/** Усадьба: основной корпус, крыша и башенка. */
function Manor({ gx, gy }: P) {
  return (
    <g>
      <GroundShadow x={gx} y={gy} w={1} d={1} />
      <Box
        x={gx + 0.05}
        y={gy + 0.2}
        w={0.9}
        d={0.6}
        h={28}
        c={C.stoneLight}
        bricks="stone"
        left={(len) => (
          <g>
            <Win u={len * 0.15} v={12} w={8} h={11} lit />
            <Win u={len * 0.45} v={12} w={8} h={11} />
            <Win u={len * 0.75} v={12} w={8} h={11} lit />
          </g>
        )}
      />
      <Gable x={gx} y={gy + 0.14} w={1} d={0.72} z={28} rise={16} c={C.blue} axis="x" />
      <Tower
        cx={gx + 0.86}
        cy={gy + 0.24}
        r={0.13}
        h={46}
        c={C.stoneLight}
        roof={C.blue}
        roofRise={16}
        id={key({ gx, gy }, 'mn')}
      />
      <Box x={gx + 0.4} y={gy + 0.14} w={0.2} d={0.06} h={12} c={C.timber} />
    </g>
  );
}

/** Каменный зал: колонны, купол/колокольня/флаг. */
function Hall({
  gx,
  gy,
  wall = C.stoneLight,
  roof = C.blue,
  h = 24,
  top = 'gable',
  cols = false,
  cross = false,
  banner,
}: P & {
  wall?: Faces;
  roof?: Faces;
  h?: number;
  top?: 'gable' | 'dome' | 'bell' | 'pyramid';
  cols?: boolean;
  cross?: boolean;
  banner?: string;
}) {
  const id = key({ gx, gy }, 'hl');
  return (
    <g>
      <GroundShadow x={gx} y={gy} w={1} d={1} />
      <Box
        x={gx + 0.1}
        y={gy + 0.14}
        w={0.8}
        d={0.72}
        h={h}
        c={wall}
        bricks="stone"
        left={(len) => (
          <g>
            <Win u={len * 0.22} v={h * 0.4} w={8} h={12} lit />
            <Win u={len * 0.62} v={h * 0.4} w={8} h={12} />
          </g>
        )}
      />
      {cols &&
        [0.14, 0.34, 0.54, 0.74].map((dx) => (
          <Box key={dx} x={gx + dx} y={gy + 0.82} w={0.07} d={0.07} h={h - 4} c={C.cream} />
        ))}
      {top === 'gable' && (
        <Gable x={gx + 0.04} y={gy + 0.08} w={0.92} d={0.84} z={h} rise={15} c={roof} axis="x" />
      )}
      {top === 'pyramid' && (
        <Pyramid x={gx + 0.04} y={gy + 0.08} w={0.92} d={0.84} z={h} rise={18} c={roof} />
      )}
      {top === 'dome' && (
        <Tower
          cx={gx + 0.5}
          cy={gy + 0.5}
          r={0.3}
          h={12}
          z={h}
          c={roof}
          roof={C.gold}
          roofRise={16}
          id={id}
        />
      )}
      {top === 'bell' && (
        <g>
          <Gable x={gx + 0.04} y={gy + 0.08} w={0.92} d={0.84} z={h} rise={13} c={roof} axis="x" />
          <Box x={gx + 0.36} y={gy + 0.34} w={0.22} d={0.22} h={20} z={h + 4} c={wall} />
          <Pyramid x={gx + 0.33} y={gy + 0.31} w={0.28} d={0.28} z={h + 24} rise={14} c={roof} />
        </g>
      )}
      {cross && <Box x={gx + 0.47} y={gy + 0.46} w={0.05} d={0.05} h={9} z={h + 38} c={C.gold} />}
      {banner && (
        <g>
          <Box x={gx + 0.9} y={gy + 0.86} w={0.04} d={0.04} h={24} z={h} c={C.woodDark} />
          <Box x={gx + 0.94} y={gy + 0.86} w={0.16} d={0.02} h={8} z={h + 15} c={faces(banner)} />
        </g>
      )}
    </g>
  );
}

function Stall({ gx, gy, awning = C.red, goods = C.gold }: P & { awning?: Faces; goods?: Faces }) {
  return (
    <g>
      <GroundShadow x={gx} y={gy} w={1} d={1} />
      <Box x={gx + 0.12} y={gy + 0.35} w={0.76} d={0.4} h={9} c={C.timber} />
      {[0.12, 0.8].flatMap((dx) =>
        [0.2, 0.76].map((dy) => (
          <Box key={`${dx}${dy}`} x={gx + dx} y={gy + dy} w={0.07} d={0.07} h={26} c={C.wood} />
        )),
      )}
      <Gable x={gx + 0.05} y={gy + 0.12} w={0.9} d={0.72} z={26} rise={9} c={awning} axis="x" />
      <Box x={gx + 0.25} y={gy + 0.42} w={0.14} d={0.14} h={13} c={goods} />
      <Box x={gx + 0.55} y={gy + 0.42} w={0.14} d={0.14} h={11} c={C.cream} />
    </g>
  );
}

function Warehouse({ gx, gy }: P) {
  return (
    <g>
      <GroundShadow x={gx} y={gy} w={1} d={1} />
      <Box
        x={gx + 0.06}
        y={gy + 0.16}
        w={0.88}
        d={0.7}
        h={22}
        c={C.wood}
        bricks="wood"
        left={(len) => (
          <rect
            x={len * 0.3}
            y="0"
            width={len * 0.4}
            height="15"
            fill="#4a2a14"
            stroke="#2a1a0e"
            strokeWidth="1.500"
          />
        )}
      />
      <Gable x={gx} y={gy + 0.1} w={1} d={0.82} z={22} rise={12} c={C.slate} axis="y" />
      <Box x={gx + 0.7} y={gy + 0.7} w={0.16} d={0.12} h={7} c={C.timber} />
    </g>
  );
}

function Plot({
  gx,
  gy,
  ground = '#7a5a34',
  children,
}: P & { ground?: string; children?: ReactNode }) {
  return (
    <g>
      <Patch x={gx + 0.04} y={gy + 0.04} w={0.92} d={0.92} fill={ground} />
      {children}
    </g>
  );
}

const Hedge = ({ gx, gy }: P) => (
  <g>
    <Box x={gx + 0.05} y={gy + 0.05} w={0.9} d={0.1} h={7} c={C.hedge} />
    <Box x={gx + 0.05} y={gy + 0.05} w={0.1} d={0.9} h={7} c={C.hedge} />
  </g>
);

const Rows = ({ gx, gy, color, tall = 8 }: P & { color: string; tall?: number }) => (
  <g>
    {[0.14, 0.34, 0.54, 0.74].map((dx) => (
      <Box key={dx} x={gx + dx} y={gy + 0.12} w={0.1} d={0.76} h={tall} c={faces(color)} />
    ))}
  </g>
);

const FruitTree = ({ x, y, fruit }: { x: number; y: number; fruit: string }) => {
  const [sx, sy] = iso(x, y);
  return (
    <g>
      <IsoTree x={x} y={y} s={0.62} kind="oak" />
      {(
        [
          [-9, -30],
          [7, -36],
          [0, -22],
          [-3, -42],
        ] as const
      ).map(([dx, dy], i) => (
        <circle
          key={i}
          cx={sx + dx}
          cy={sy + dy}
          r="2.600"
          fill={fruit}
          stroke="#2a1a0e"
          strokeWidth=".6"
        />
      ))}
    </g>
  );
};

function Smoke({ x, y, z }: { x: number; y: number; z: number }) {
  const [sx, sy] = iso(x, y, z);
  return (
    <g transform={`translate(${sx} ${sy})`}>
      <g className="st-smoke">
        <circle cx="0" cy="-4" r="4" fill="#fff" />
        <circle cx="4" cy="-11" r="5" fill="#fff" opacity=".7" />
        <circle cx="-1" cy="-19" r="6" fill="#fff" opacity=".45" />
      </g>
    </g>
  );
}

const Flame = ({ x, y }: { x: number; y: number }) => {
  const [sx, sy] = iso(x, y, 6);
  return (
    <g transform={`translate(${sx} ${sy})`}>
      <g className="st-flame">
        <path
          d="M0 -20C-7 -10-8 -3-4 2H4C8-3 7-10 0-20Z"
          fill="#ff7a2f"
          stroke="#7a2a0a"
          strokeWidth="1"
        />
        <path d="M0 -12C-3 -7-3 -2 0 1 3-2 3-7 0-12Z" fill="#ffd06a" />
      </g>
    </g>
  );
};

// ── Современные конструкторы ────────────────────────────────────────────────

function Block({
  gx,
  gy,
  h = 36,
  w = 0.8,
  d = 0.8,
  body = C.white,
  rows = 3,
  cols = 4,
  top = 'flat',
  stripe,
}: P & {
  h?: number;
  w?: number;
  d?: number;
  body?: Faces;
  rows?: number;
  cols?: number;
  top?: 'flat' | 'antenna' | 'green' | 'dome' | 'sign' | 'cross' | 'coin';
  stripe?: string;
}) {
  const x0 = gx + (1 - w) / 2;
  const y0 = gy + (1 - d) / 2;
  return (
    <g>
      <GroundShadow x={gx} y={gy} w={1} d={1} />
      <Box
        x={x0}
        y={y0}
        w={w}
        d={d}
        h={h}
        c={body}
        left={(len, hh) => (
          <g>
            <Panes len={len} h={hh} rows={rows} cols={cols} seed={Math.abs(gx)} />
            {stripe && <rect x="2" y={hh - 7} width={len - 4} height="5" fill={stripe} />}
          </g>
        )}
        right={(len, hh) => (
          <Panes
            len={len}
            h={hh}
            rows={rows}
            cols={Math.max(2, cols - 1)}
            seed={Math.abs(gy) + 3}
          />
        )}
      />
      <Box x={x0} y={y0} w={w} d={d} h={3} z={h} c={C.steel} />
      {top === 'antenna' && (
        <Box x={x0 + w * 0.45} y={y0 + d * 0.45} w={0.04} d={0.04} h={22} z={h + 3} c={C.steel} />
      )}
      {top === 'green' && (
        <Patch x={x0 + 0.05} y={y0 + 0.05} w={w - 0.1} d={d - 0.1} z={h + 3} fill="#5fbd57" />
      )}
      {top === 'dome' && (
        <Tower
          cx={gx + 0.5}
          cy={gy + 0.5}
          r={0.22}
          h={9}
          z={h + 3}
          c={C.cyan}
          roof={C.glass}
          roofRise={9}
          id={key({ gx, gy }, 'bd')}
        />
      )}
      {top === 'sign' && (
        <Box x={x0 + 0.05} y={y0 + d - 0.05} w={w - 0.1} d={0.05} h={9} z={h + 3} c={C.orange} />
      )}
      {top === 'cross' && (
        <g>
          <Box
            x={gx + 0.44}
            y={gy + 0.44}
            w={0.12}
            d={0.12}
            h={12}
            z={h + 3}
            c={faces('#e0342c')}
          />
          <Box x={gx + 0.38} y={gy + 0.44} w={0.24} d={0.12} h={4} z={h + 7} c={faces('#e0342c')} />
        </g>
      )}
      {top === 'coin' && (
        <Tower
          cx={gx + 0.5}
          cy={gy + 0.5}
          r={0.16}
          h={5}
          z={h + 3}
          c={C.gold}
          id={key({ gx, gy }, 'bc')}
        />
      )}
    </g>
  );
}

const Kiosk = ({
  gx,
  gy,
  awning = '#e0342c',
  body = C.glass,
}: P & { awning?: string; body?: Faces }) => (
  <g>
    <GroundShadow x={gx} y={gy} w={1} d={1} />
    <Box
      x={gx + 0.12}
      y={gy + 0.22}
      w={0.76}
      d={0.56}
      h={22}
      c={body}
      left={(len, h) => (
        <g>
          <rect x="4" y="5" width={len - 8} height={h - 12} fill="#a9dcf6" opacity=".8" />
          <rect x="3" y="2" width={len - 6} height="6" fill={awning} />
        </g>
      )}
      right={(len, h) => <rect x="4" y="4" width={len - 8} height={h - 10} fill="#8fc9ee" />}
    />
    <Box x={gx + 0.04} y={gy + 0.14} w={0.92} d={0.72} h={3} z={22} c={C.steel} />
  </g>
);

const Pavers = ({ gx, gy }: P) => (
  <g>
    <Patch x={gx} y={gy} w={1} d={1} fill="#c8d0d6" />
    {[0.25, 0.5, 0.75].map((f) => (
      <g key={f}>
        <Patch x={gx + f - 0.01} y={gy} w={0.02} d={1} fill="#b0bac2" opacity={0.8} />
        <Patch x={gx} y={gy + f - 0.01} w={1} d={0.02} fill="#b0bac2" opacity={0.8} />
      </g>
    ))}
  </g>
);

// ── Общие для обеих эпох ───────────────────────────────────────────────────

function Lighthouse({ gx, gy, modern }: P & { modern?: boolean }) {
  const id = key({ gx, gy }, 'lh');
  return (
    <g>
      <GroundShadow x={gx} y={gy} w={1} d={1} />
      <Tower cx={gx + 0.5} cy={gy + 0.5} r={0.36} h={110} c={modern ? C.steel : C.cream} id={id} />
      {[18, 58].map((z) => (
        <Tower
          key={z}
          cx={gx + 0.5}
          cy={gy + 0.5}
          r={0.34}
          h={22}
          z={z}
          c={modern ? faces('#d9503c') : C.red}
          id={`${id}-${z}`}
          cap={false}
        />
      ))}
      <Box x={gx + 0.28} y={gy + 0.28} w={0.44} d={0.44} h={14} z={110} c={faces('#ffe27a')} />
      <Pyramid x={gx + 0.26} y={gy + 0.26} w={0.48} d={0.48} z={124} rise={14} c={C.red} />
    </g>
  );
}

function Pier({ gx, gy, modern }: P & { modern?: boolean }) {
  return (
    <g>
      <Box
        x={gx + 0.05}
        y={gy + 0.05}
        w={0.9}
        d={0.9}
        h={4}
        c={modern ? C.concrete : C.wood}
        bricks={modern ? null : 'wood'}
      />
      {(
        [
          [0.1, 0.1],
          [0.82, 0.1],
          [0.1, 0.82],
          [0.82, 0.82],
        ] as const
      ).map(([dx, dy], i) => (
        <Box
          key={i}
          x={gx + dx}
          y={gy + dy}
          w={0.08}
          d={0.08}
          h={11}
          c={modern ? C.steel : C.timber}
        />
      ))}
    </g>
  );
}

/** Док: причал с краном и ящиками. */
function Dock({ gx, gy, modern }: P & { modern?: boolean }) {
  return (
    <g>
      <Box
        x={gx + 0.03}
        y={gy + 0.03}
        w={0.94}
        d={0.94}
        h={4}
        c={modern ? C.concrete : C.wood}
        bricks={modern ? null : 'wood'}
      />
      <Box
        x={gx + 0.12}
        y={gy + 0.12}
        w={0.3}
        d={0.26}
        h={11}
        z={4}
        c={modern ? faces('#d9503c') : C.timber}
      />
      <Box
        x={gx + 0.5}
        y={gy + 0.14}
        w={0.26}
        d={0.24}
        h={9}
        z={4}
        c={modern ? faces('#2f7fd0') : C.wood}
      />
      <Box
        x={gx + 0.78}
        y={gy + 0.7}
        w={0.1}
        d={0.1}
        h={44}
        z={4}
        c={modern ? faces('#f0a03a') : C.woodDark}
      />
      <Box
        x={gx + 0.42}
        y={gy + 0.72}
        w={0.5}
        d={0.06}
        h={4}
        z={44}
        c={modern ? faces('#f0a03a') : C.woodDark}
      />
    </g>
  );
}

function Boat({ gx, gy, name }: P & { name: keyof typeof BOATS }) {
  const era = useEra((s) => s.era);
  const art = BOATS[name][era];
  const [x, y] = iso(gx + 0.5, gy + 0.5);
  return (
    <g transform={`translate(${x} ${y})`}>
      <ellipse cx="0" cy="8" rx="34" ry="6" fill="#fff" opacity=".3" className="iso-boat-wake" />
      <g
        className="iso-boat-bob"
        style={{ animationDelay: `${(((Math.abs(gx) + Math.abs(gy)) % 5) * 0.4).toFixed(1)}s` }}
      >
        {art()}
      </g>
    </g>
  );
}

const boat =
  (name: keyof typeof BOATS): Art =>
  (p) => <Boat {...p} name={name} />;

// ── Виды: средневековье / современность ─────────────────────────────────────

const ART: Record<'medieval' | 'modern', Record<StructureKind, Art>> = {
  medieval: {
    // жильё
    house: (p) => <Cottage {...p} />,
    cottage: (p) => (
      <Cottage {...p} wall={C.timber} roof={C.thatch} h={16} w={0.66} d={0.66} rise={13} chimney />
    ),
    townhouse: (p) => (
      <Cottage
        {...p}
        wall={C.plaster}
        roof={C.blue}
        h={30}
        w={0.8}
        d={0.7}
        rise={17}
        chimney
        flag="#c0392b"
        bricks="plaster"
      />
    ),
    manor: (p) => <Manor {...p} />,
    apartment: (p) => (
      <Cottage
        {...p}
        wall={C.stoneLight}
        roof={C.purple}
        h={40}
        w={0.86}
        d={0.78}
        rise={20}
        chimney
        bricks="stone"
        flag="#e0b030"
      />
    ),
    // дороги
    road: ({ gx, gy }) => <Cobble x={gx} y={gy} tone={(gx * 7 + gy * 3 + 30) % 3} />,
    plaza: ({ gx, gy }) => (
      <g>
        <Cobble x={gx} y={gy} tone={1} />
        <Patch x={gx + 0.3} y={gy + 0.3} w={0.4} d={0.4} fill="#e0b030" opacity={0.55} />
      </g>
    ),
    lamp: ({ gx, gy }) => <IsoLamp x={gx + 0.5} y={gy + 0.5} />,
    bench: ({ gx, gy }) => (
      <g>
        <Box x={gx + 0.2} y={gy + 0.4} w={0.6} d={0.2} h={5} z={4} c={C.wood} />
        <Box x={gx + 0.2} y={gy + 0.4} w={0.6} d={0.05} h={9} z={8} c={C.woodDark} />
        <Box x={gx + 0.24} y={gy + 0.42} w={0.05} d={0.16} h={4} c={C.woodDark} />
        <Box x={gx + 0.71} y={gy + 0.42} w={0.05} d={0.16} h={4} c={C.woodDark} />
      </g>
    ),
    signpost: ({ gx, gy }) => (
      <g>
        <Box x={gx + 0.47} y={gy + 0.47} w={0.06} d={0.06} h={30} c={C.woodDark} />
        <Box x={gx + 0.32} y={gy + 0.46} w={0.3} d={0.05} h={7} z={22} c={C.wood} />
        <Box x={gx + 0.42} y={gy + 0.5} w={0.05} d={0.3} h={7} z={14} c={C.wood} />
      </g>
    ),
    // природа
    garden: (p) => (
      <Plot {...p}>
        <Hedge {...p} />
        <IsoFlowers x={p.gx + 0.5} y={p.gy + 0.55} />
      </Plot>
    ),
    flowerbed: (p) => (
      <Plot {...p} ground="#6a4a2a">
        <IsoFlowers x={p.gx + 0.3} y={p.gy + 0.35} />
        <IsoFlowers x={p.gx + 0.65} y={p.gy + 0.65} />
      </Plot>
    ),
    grove: ({ gx, gy }) => (
      <g>
        <IsoTree x={gx + 0.3} y={gy + 0.3} s={0.72} kind="pine" />
        <IsoTree x={gx + 0.7} y={gy + 0.4} s={0.68} kind="oak" />
        <IsoTree x={gx + 0.45} y={gy + 0.75} s={0.7} kind="birch" />
      </g>
    ),
    orchard: ({ gx, gy }) => (
      <g>
        <Patch x={gx + 0.04} y={gy + 0.04} w={0.92} d={0.92} fill="#6bb35a" />
        <FruitTree x={gx + 0.3} y={gy + 0.3} fruit="#d9503c" />
        <FruitTree x={gx + 0.72} y={gy + 0.45} fruit="#f0a03a" />
        <FruitTree x={gx + 0.4} y={gy + 0.78} fruit="#d9503c" />
      </g>
    ),
    vineyard: (p) => (
      <Plot {...p} ground="#8a6a3a">
        <Rows {...p} color="#6b3a8a" tall={11} />
      </Plot>
    ),
    pond: ({ gx, gy }) => (
      <g>
        <Patch x={gx + 0.06} y={gy + 0.06} w={0.88} d={0.88} fill="#7a6a4a" />
        <Patch x={gx + 0.14} y={gy + 0.14} w={0.72} d={0.72} fill="#4fa8e0" />
        <Patch x={gx + 0.3} y={gy + 0.3} w={0.24} d={0.18} fill="#8fd2f5" opacity={0.7} />
        <Box x={gx + 0.78} y={gy + 0.2} w={0.04} d={0.04} h={12} c={C.hedge} />
        <Box x={gx + 0.84} y={gy + 0.26} w={0.04} d={0.04} h={9} c={C.hedge} />
      </g>
    ),
    // сервис
    well: ({ gx, gy }) => (
      <g>
        <GroundShadow x={gx} y={gy} w={1} d={1} />
        <Tower cx={gx + 0.5} cy={gy + 0.5} r={0.26} h={10} c={C.stone} id={key({ gx, gy }, 'wl')} />
        <Box x={gx + 0.24} y={gy + 0.46} w={0.05} d={0.08} h={26} c={C.woodDark} />
        <Box x={gx + 0.72} y={gy + 0.46} w={0.05} d={0.08} h={26} c={C.woodDark} />
        <Gable x={gx + 0.2} y={gy + 0.4} w={0.6} d={0.2} z={26} rise={8} c={C.red} axis="x" />
      </g>
    ),
    bakery: (p) => (
      <g>
        <Cottage {...p} wall={C.plaster} roof={C.thatch} h={18} chimney sign="#e0b030" />
        <Smoke x={p.gx + 0.72} y={p.gy + 0.28} z={32} />
      </g>
    ),
    workshop: (p) => (
      <Cottage
        {...p}
        wall={C.timber}
        roof={C.wood}
        h={18}
        w={0.8}
        d={0.7}
        rise={12}
        axis="y"
        chimney
        sign="#7d8b98"
        bricks="wood"
      />
    ),
    tavern: (p) => (
      <Cottage
        {...p}
        wall={C.timber}
        roof={C.red}
        h={24}
        w={0.8}
        d={0.8}
        rise={16}
        sign="#e0b030"
        chimney
        bricks="wood"
      />
    ),
    inn: (p) => (
      <Cottage
        {...p}
        wall={C.plaster}
        roof={C.green}
        h={30}
        w={0.86}
        d={0.78}
        rise={18}
        chimney
        flag="#3f8a5a"
        sign="#e0b030"
        bricks="plaster"
      />
    ),
    bathhouse: (p) => (
      <g>
        <Cottage
          {...p}
          wall={C.stoneLight}
          roof={C.blue}
          h={16}
          w={0.8}
          d={0.7}
          rise={12}
          bricks="stone"
        />
        <Smoke x={p.gx + 0.3} y={p.gy + 0.3} z={28} />
      </g>
    ),
    school: (p) => <Hall {...p} wall={C.plaster} roof={C.red} h={22} top="bell" banner="#3f68b4" />,
    clinic: (p) => (
      <Hall {...p} wall={C.cream} roof={C.green} h={22} top="gable" cross banner="#e0342c" />
    ),
    guardpost: ({ gx, gy }) => (
      <g>
        <GroundShadow x={gx} y={gy} w={1} d={1} />
        <Tower
          cx={gx + 0.5}
          cy={gy + 0.5}
          r={0.3}
          h={46}
          c={C.stone}
          roof={C.red}
          roofRise={18}
          id={key({ gx, gy }, 'gp')}
        />
        <Box x={gx + 0.7} y={gy + 0.7} w={0.04} d={0.04} h={22} z={40} c={C.woodDark} />
        <Box x={gx + 0.74} y={gy + 0.7} w={0.14} d={0.02} h={7} z={54} c={faces('#c0392b')} />
      </g>
    ),
    // торговля
    stall: (p) => <Stall {...p} />,
    market: (p) => (
      <g>
        <Stall {...p} awning={C.blue} goods={C.red} />
        <Box x={p.gx + 0.7} y={p.gy + 0.8} w={0.18} d={0.14} h={8} c={C.timber} />
      </g>
    ),
    warehouse: (p) => <Warehouse {...p} />,
    bank: (p) => <Hall {...p} wall={C.cream} roof={C.gold} h={26} top="dome" cols />,
    // культура
    chapel: (p) => <Hall {...p} wall={C.stoneLight} roof={C.slate} h={22} top="bell" cross />,
    temple: (p) => <Hall {...p} wall={C.cream} roof={C.gold} h={30} top="pyramid" cols cross />,
    theatre: ({ gx, gy }) => (
      <g>
        <GroundShadow x={gx} y={gy} w={1} d={1} />
        <Tower
          cx={gx + 0.5}
          cy={gy + 0.5}
          r={0.42}
          h={30}
          c={C.plaster}
          roof={C.red}
          roofRise={20}
          id={key({ gx, gy }, 'th')}
        />
        <Box x={gx + 0.4} y={gy + 0.84} w={0.2} d={0.06} h={14} c={C.woodDark} />
      </g>
    ),
    library: (p) => <Hall {...p} wall={C.stone} roof={C.blue} h={30} top="pyramid" />,
    statue: ({ gx, gy }) => (
      <g>
        <GroundShadow x={gx} y={gy} w={1} d={1} />
        <Box x={gx + 0.25} y={gy + 0.25} w={0.5} d={0.5} h={14} c={C.stone} bricks="stone" />
        <Tower
          cx={gx + 0.5}
          cy={gy + 0.5}
          r={0.12}
          h={26}
          z={14}
          c={faces('#d8c27a')}
          id={key({ gx, gy }, 'ms')}
        />
        <Pyramid x={gx + 0.4} y={gy + 0.4} w={0.2} d={0.2} z={40} rise={7} c={C.gold} />
      </g>
    ),
    obelisk: ({ gx, gy }) => (
      <g>
        <GroundShadow x={gx} y={gy} w={1} d={1} />
        <Box x={gx + 0.3} y={gy + 0.3} w={0.4} d={0.4} h={8} c={C.stone} bricks="stone" />
        <Box
          x={gx + 0.4}
          y={gy + 0.4}
          w={0.2}
          d={0.2}
          h={52}
          z={8}
          c={C.stoneLight}
          bricks="stone"
        />
        <Pyramid x={gx + 0.4} y={gy + 0.4} w={0.2} d={0.2} z={60} rise={12} c={C.gold} />
      </g>
    ),
    fountain: ({ gx, gy }) => <IsoFountain x={gx + 0.5} y={gy + 0.5} />,
    lighthouse: (p) => <Lighthouse {...p} />,
    // отдых
    park: ({ gx, gy }) => (
      <g>
        <Patch x={gx + 0.04} y={gy + 0.04} w={0.92} d={0.92} fill="#69b45a" />
        <Box x={gx + 0.55} y={gy + 0.72} w={0.34} d={0.12} h={5} c={C.wood} />
        <IsoTree x={gx + 0.35} y={gy + 0.4} s={0.8} kind="oak" />
      </g>
    ),
    playground: ({ gx, gy }) => (
      <g>
        <Patch x={gx + 0.04} y={gy + 0.04} w={0.92} d={0.92} fill="#d8c48a" />
        {[0.2, 0.62].map((dx) => (
          <Box key={dx} x={gx + dx} y={gy + 0.2} w={0.06} d={0.06} h={22} c={C.woodDark} />
        ))}
        <Box x={gx + 0.2} y={gy + 0.2} w={0.48} d={0.05} h={3} z={20} c={C.wood} />
        <Box x={gx + 0.36} y={gy + 0.21} w={0.03} d={0.03} h={16} z={4} c={C.steel} />
        <Box x={gx + 0.5} y={gy + 0.21} w={0.03} d={0.03} h={16} z={4} c={C.steel} />
        <Box x={gx + 0.6} y={gy + 0.55} w={0.3} d={0.3} h={12} c={C.red} />
      </g>
    ),
    campfire: ({ gx, gy }) => (
      <g>
        <GroundShadow x={gx} y={gy} w={1} d={1} />
        {[0.36, 0.56, 0.46].map((dx, i) => (
          <Box
            key={i}
            x={gx + dx}
            y={gy + 0.34 + (i % 2) * 0.22}
            w={0.1}
            d={0.1}
            h={5}
            c={C.stone}
          />
        ))}
        <Flame x={gx + 0.5} y={gy + 0.5} />
      </g>
    ),
    tent: ({ gx, gy }) => (
      <g>
        <GroundShadow x={gx} y={gy} w={1} d={1} />
        <Pyramid
          x={gx + 0.14}
          y={gy + 0.14}
          w={0.72}
          d={0.72}
          z={0}
          rise={34}
          c={faces('#d9503c')}
          over={0}
        />
        <Box x={gx + 0.44} y={gy + 0.72} w={0.12} d={0.03} h={14} c={C.woodDark} />
      </g>
    ),
    // море
    pier: (p) => <Pier {...p} />,
    dock: (p) => <Dock {...p} />,
    rowboat: boat('rowboat'),
    fishboat: boat('fishboat'),
    ship: boat('ship'),
    ferry: boat('ferry'),
    galleon: boat('galleon'),
    buoy: boat('buoy'),
  },
  modern: {
    house: (p) => <Block {...p} h={34} top="green" />,
    cottage: (p) => (
      <Block {...p} h={24} w={0.7} d={0.7} body={C.concrete} rows={2} cols={3} top="green" />
    ),
    townhouse: (p) => (
      <Block
        {...p}
        h={46}
        w={0.82}
        d={0.7}
        body={C.white}
        rows={4}
        cols={4}
        top="antenna"
        stripe="#d9503c"
      />
    ),
    manor: ({ gx, gy }) => (
      <g>
        <Block
          gx={gx}
          gy={gy}
          h={26}
          w={0.92}
          d={0.6}
          body={C.white}
          rows={2}
          cols={5}
          top="green"
        />
        <Patch x={gx + 0.1} y={gy + 0.74} w={0.5} d={0.22} fill="#6fcbe8" />
      </g>
    ),
    apartment: (p) => (
      <Block {...p} h={86} w={0.7} d={0.7} body={C.glass} rows={9} cols={4} top="antenna" />
    ),
    road: ({ gx, gy }) => (
      <g>
        <Patch x={gx} y={gy} w={1} d={1} fill="#4a5560" />
        <Patch x={gx + 0.44} y={gy + 0.05} w={0.12} d={0.4} fill="#f3efe6" opacity={0.9} />
        <Patch x={gx + 0.44} y={gy + 0.55} w={0.12} d={0.4} fill="#f3efe6" opacity={0.9} />
      </g>
    ),
    plaza: (p) => <Pavers {...p} />,
    lamp: ({ gx, gy }) => (
      <g>
        <Box x={gx + 0.47} y={gy + 0.47} w={0.05} d={0.05} h={40} c={C.steel} />
        <Box x={gx + 0.4} y={gy + 0.44} w={0.2} d={0.1} h={3} z={38} c={faces('#ffe27a')} />
      </g>
    ),
    bench: ({ gx, gy }) => (
      <g>
        <Box x={gx + 0.2} y={gy + 0.4} w={0.6} d={0.2} h={4} z={4} c={C.steel} />
        <Box x={gx + 0.2} y={gy + 0.4} w={0.6} d={0.04} h={8} z={8} c={C.concrete} />
      </g>
    ),
    signpost: ({ gx, gy }) => (
      <g>
        <Box x={gx + 0.47} y={gy + 0.47} w={0.05} d={0.05} h={36} c={C.steel} />
        <Box x={gx + 0.3} y={gy + 0.45} w={0.34} d={0.05} h={9} z={26} c={faces('#2f7fd0')} />
      </g>
    ),
    garden: (p) => (
      <g>
        <Box x={p.gx + 0.08} y={p.gy + 0.08} w={0.84} d={0.84} h={6} c={C.concrete} />
        <Patch x={p.gx + 0.14} y={p.gy + 0.14} w={0.72} d={0.72} z={6} fill="#5fbd57" />
        <Tower
          cx={p.gx + 0.5}
          cy={p.gy + 0.5}
          r={0.16}
          h={18}
          z={6}
          c={faces('#3fa14e')}
          id={key(p, 'mg')}
        />
      </g>
    ),
    flowerbed: (p) => (
      <g>
        <Box x={p.gx + 0.1} y={p.gy + 0.1} w={0.8} d={0.8} h={4} c={C.concrete} />
        <Patch x={p.gx + 0.16} y={p.gy + 0.16} w={0.68} d={0.68} z={4} fill="#4a8a3a" />
        <IsoFlowers x={p.gx + 0.5} y={p.gy + 0.5} />
      </g>
    ),
    grove: ({ gx, gy }) => (
      <g>
        <IsoTree x={gx + 0.3} y={gy + 0.35} s={0.7} kind="birch" />
        <IsoTree x={gx + 0.7} y={gy + 0.4} s={0.7} kind="birch" />
        <IsoTree x={gx + 0.5} y={gy + 0.75} s={0.7} kind="oak" />
      </g>
    ),
    orchard: (p) => (
      <g>
        <Block {...p} h={20} w={0.9} d={0.8} body={C.glass} rows={1} cols={5} top="flat" />
        <Patch x={p.gx + 0.1} y={p.gy + 0.1} w={0.8} d={0.8} z={23} fill="#5fbd57" />
      </g>
    ),
    vineyard: (p) => (
      <g>
        <Patch x={p.gx + 0.04} y={p.gy + 0.04} w={0.92} d={0.92} fill="#6a7a86" />
        {[0.12, 0.42, 0.72].map((dx) => (
          <Box key={dx} x={p.gx + dx} y={p.gy + 0.1} w={0.16} d={0.8} h={14} z={4} c={C.teal} />
        ))}
      </g>
    ),
    pond: ({ gx, gy }) => (
      <g>
        <Box x={gx + 0.06} y={gy + 0.06} w={0.88} d={0.88} h={3} c={C.concrete} />
        <Patch x={gx + 0.14} y={gy + 0.14} w={0.72} d={0.72} z={3} fill="#6fcbe8" />
        <Patch x={gx + 0.3} y={gy + 0.3} w={0.24} d={0.16} z={3} fill="#bff0ff" opacity={0.8} />
      </g>
    ),
    well: ({ gx, gy }) => (
      <g>
        <GroundShadow x={gx} y={gy} w={1} d={1} />
        <Tower
          cx={gx + 0.5}
          cy={gy + 0.5}
          r={0.2}
          h={34}
          c={C.steel}
          roof={C.cyan}
          roofRise={8}
          id={key({ gx, gy }, 'mw')}
        />
      </g>
    ),
    bakery: (p) => <Kiosk {...p} awning="#e0a02f" body={C.white} />,
    workshop: (p) => (
      <Block
        {...p}
        h={24}
        w={0.86}
        d={0.72}
        body={C.steel}
        rows={1}
        cols={4}
        top="antenna"
        stripe="#e0672f"
      />
    ),
    tavern: (p) => <Kiosk {...p} awning="#e0342c" body={C.glass} />,
    inn: (p) => (
      <Block {...p} h={52} w={0.74} d={0.7} body={C.concrete} rows={5} cols={4} top="sign" />
    ),
    bathhouse: (p) => (
      <Block {...p} h={20} w={0.86} d={0.76} body={C.glass} rows={1} cols={5} top="dome" />
    ),
    school: (p) => (
      <Block
        {...p}
        h={30}
        w={0.9}
        d={0.66}
        body={faces('#e0c060')}
        rows={2}
        cols={6}
        top="flat"
        stripe="#3f68b4"
      />
    ),
    clinic: (p) => (
      <Block {...p} h={44} w={0.8} d={0.7} body={C.white} rows={4} cols={4} top="cross" />
    ),
    guardpost: ({ gx, gy }) => (
      <g>
        <Block gx={gx} gy={gy} h={26} w={0.5} d={0.5} body={C.steel} rows={1} cols={2} top="flat" />
        <Box x={gx + 0.1} y={gy + 0.75} w={0.8} d={0.05} h={3} z={10} c={faces('#d9503c')} />
      </g>
    ),
    stall: (p) => <Kiosk {...p} awning="#2f7fd0" body={C.white} />,
    market: (p) => (
      <Block {...p} h={26} w={0.92} d={0.78} body={faces('#f0a03a')} rows={1} cols={6} top="sign" />
    ),
    warehouse: (p) => (
      <Block
        {...p}
        h={26}
        w={0.94}
        d={0.74}
        body={C.steel}
        rows={1}
        cols={3}
        top="flat"
        stripe="#e0672f"
      />
    ),
    bank: (p) => (
      <Block {...p} h={64} w={0.74} d={0.7} body={C.glassDeep} rows={7} cols={4} top="coin" />
    ),
    chapel: ({ gx, gy }) => (
      <g>
        <GroundShadow x={gx} y={gy} w={1} d={1} />
        <Box x={gx + 0.15} y={gy + 0.2} w={0.7} d={0.6} h={14} c={C.white} />
        <Pyramid
          x={gx + 0.12}
          y={gy + 0.17}
          w={0.76}
          d={0.66}
          z={14}
          rise={30}
          c={C.glass}
          over={0}
        />
        <Box x={gx + 0.47} y={gy + 0.47} w={0.05} d={0.05} h={9} z={44} c={C.steel} />
      </g>
    ),
    temple: (p) => (
      <Block {...p} h={30} w={0.9} d={0.8} body={C.white} rows={1} cols={6} top="dome" />
    ),
    theatre: ({ gx, gy }) => (
      <g>
        <GroundShadow x={gx} y={gy} w={1} d={1} />
        <Tower
          cx={gx + 0.5}
          cy={gy + 0.5}
          r={0.42}
          h={34}
          c={C.glass}
          roof={C.white}
          roofRise={6}
          id={key({ gx, gy }, 'mt')}
        />
      </g>
    ),
    library: (p) => (
      <Block {...p} h={34} w={0.84} d={0.76} body={C.glass} rows={3} cols={4} top="dome" />
    ),
    statue: ({ gx, gy }) => (
      <g>
        <GroundShadow x={gx} y={gy} w={1} d={1} />
        <Box x={gx + 0.2} y={gy + 0.2} w={0.6} d={0.6} h={6} c={C.concrete} />
        <Box x={gx + 0.4} y={gy + 0.4} w={0.2} d={0.2} h={46} z={6} c={C.steel} />
        <Pyramid x={gx + 0.4} y={gy + 0.4} w={0.2} d={0.2} z={52} rise={10} c={C.cyan} />
      </g>
    ),
    obelisk: ({ gx, gy }) => (
      <g>
        <GroundShadow x={gx} y={gy} w={1} d={1} />
        <Box x={gx + 0.32} y={gy + 0.32} w={0.36} d={0.36} h={4} c={C.concrete} />
        <Pyramid x={gx + 0.4} y={gy + 0.4} w={0.2} d={0.2} z={4} rise={70} c={C.glass} over={0} />
      </g>
    ),
    fountain: ({ gx, gy }) => (
      <g>
        <Box x={gx + 0.1} y={gy + 0.1} w={0.8} d={0.8} h={6} c={C.concrete} />
        <Patch x={gx + 0.2} y={gy + 0.2} w={0.6} d={0.6} z={6} fill="#6fcbe8" />
        <Tower
          cx={gx + 0.5}
          cy={gy + 0.5}
          r={0.06}
          h={26}
          z={6}
          c={faces('#bfefff')}
          id={key({ gx, gy }, 'mf')}
        />
      </g>
    ),
    lighthouse: (p) => <Lighthouse {...p} modern />,
    park: ({ gx, gy }) => (
      <g>
        <Patch x={gx + 0.04} y={gy + 0.04} w={0.92} d={0.92} fill="#c8d0d6" />
        <Patch x={gx + 0.14} y={gy + 0.16} w={0.5} d={0.44} fill="#6fcbe8" />
        <Box x={gx + 0.62} y={gy + 0.7} w={0.3} d={0.14} h={5} c={C.steel} />
        <IsoTree x={gx + 0.72} y={gy + 0.3} s={0.7} kind="birch" />
      </g>
    ),
    playground: ({ gx, gy }) => (
      <g>
        <Patch x={gx + 0.04} y={gy + 0.04} w={0.92} d={0.92} fill="#c8506a" opacity={0.85} />
        <Box x={gx + 0.2} y={gy + 0.2} w={0.5} d={0.5} h={14} c={faces('#f0c14b')} />
        <Box x={gx + 0.55} y={gy + 0.6} w={0.3} d={0.3} h={8} c={faces('#2f7fd0')} />
      </g>
    ),
    campfire: ({ gx, gy }) => (
      <g>
        <Box x={gx + 0.3} y={gy + 0.3} w={0.4} d={0.4} h={6} c={C.steel} />
        <Flame x={gx + 0.5} y={gy + 0.5} />
      </g>
    ),
    tent: ({ gx, gy }) => (
      <g>
        <GroundShadow x={gx} y={gy} w={1} d={1} />
        <Pyramid
          x={gx + 0.18}
          y={gy + 0.18}
          w={0.64}
          d={0.64}
          z={0}
          rise={26}
          c={faces('#2f7fd0')}
          over={0}
        />
        <Box x={gx + 0.7} y={gy + 0.7} w={0.16} d={0.16} h={10} c={faces('#f0a03a')} />
      </g>
    ),
    pier: (p) => <Pier {...p} modern />,
    dock: (p) => <Dock {...p} modern />,
    rowboat: boat('rowboat'),
    fishboat: boat('fishboat'),
    ship: boat('ship'),
    ferry: boat('ferry'),
    galleon: boat('galleon'),
    buoy: boat('buoy'),
  },
};

/** Постройка города в клетке (gx, gy). */
export function IsoStructure({ kind, gx, gy }: { kind: StructureKind } & P) {
  const era = useEra((s) => s.era);
  return <g>{ART[era][kind]({ gx, gy })}</g>;
}

const SEA_KINDS: readonly StructureKind[] = [
  'rowboat',
  'fishboat',
  'ship',
  'ferry',
  'galleon',
  'buoy',
];

/** Миниатюра вида для каталога: та же отрисовка в маленьком окошке. */
export function StructureThumb({ kind, size = 56 }: { kind: StructureKind; size?: number }) {
  const sea = SEA_KINDS.includes(kind) || kind === 'pier' || kind === 'dock';
  return (
    <svg
      viewBox="-38 -98 76 124"
      width={size}
      height={size * (124 / 76)}
      aria-hidden="true"
      focusable="false"
      className="shrink-0"
    >
      <ellipse cx="0" cy="6" rx="34" ry="17" fill={sea ? '#3f8fd0' : '#7cc26a'} opacity=".55" />
      <IsoStructure kind={kind} gx={-0.5} gy={-0.5} />
    </svg>
  );
}
