import { afterEach, describe, expect, it } from 'vitest';
import { applyEra, currentEra, ERA_IDS } from './era';
import { PAL } from './primitives';

afterEach(() => applyEra('medieval'));

describe('эпохи', () => {
  it('по умолчанию — средневековье', () => {
    expect(currentEra()).toBe('medieval');
  });

  it('смена эпохи подменяет материалы и возвращается обратно', () => {
    const before = PAL.stone.left;
    applyEra('modern');
    expect(currentEra()).toBe('modern');
    expect(PAL.stone.left).not.toBe(before);
    applyEra('medieval');
    expect(PAL.stone.left).toBe(before);
  });

  it('у каждой эпохи заполнены все материалы', () => {
    for (const id of ERA_IDS) {
      applyEra(id);
      for (const f of Object.values(PAL)) {
        expect(f.top && f.left && f.right).toBeTruthy();
      }
    }
  });
});
