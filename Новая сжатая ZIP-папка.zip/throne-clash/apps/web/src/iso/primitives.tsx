import type { ReactNode } from 'react';
import { OUTLINE, darken, lighten, mix } from '../art/color';
import { iso, pts, wallMatrix, U, type P2 } from './project';

/** Три грани предмета: свет сверху-слева, правая грань в тени. */
export interface Faces {
  top: string;
  left: string;
  right: string;
}

export const faces = (base: string): Faces => ({
  top: lighten(base, 0.28),
  left: base,
  right: darken(base, 0.3),
});

/** Палитра материалов. Объект изменяемый: смена эпохи (`iso/era.ts`) подменяет грани на месте. */
export const PAL = {
  stone: faces('#b8b1a2'),
  stoneDark: faces('#8e8a84'),
  plaster: faces('#ecdcae'),
  timber: faces('#b98548'),
  wood: faces('#9a6a3c'),
  redRoof: faces('#c0472f'),
  blueRoof: faces('#3f68b4'),
  purpleRoof: faces('#7a4a9a'),
  greenRoof: faces('#3f8a5a'),
  goldRoof: faces('#e0b030'),
  slate: faces('#6a7280'),
  thatch: faces('#d2b060'),
  white: faces('#f3efe6'),
  dirt: faces('#a8834f'),
};

export type PalKey = keyof typeof PAL;

const EDGE = 'rgba(30,18,8,.55)';

/** Тонкий тёмный контур в цвет грани — мягче чёрной линии, как в мобильных градостроителях. */
const edge = (c: string): string => darken(c, 0.55);

interface BoxProps {
  x: number;
  y: number;
  w: number;
  d: number;
  h: number;
  z?: number;
  c: Faces;
  /** Рисунок на левой (юго-западной) и правой (юго-восточной) стенах в координатах стены. */
  left?: (len: number, h: number) => ReactNode;
  right?: (len: number, h: number) => ReactNode;
  /** Каменная кладка на стенах. */
  bricks?: 'stone' | 'wood' | 'plaster' | null;
  topExtra?: ReactNode;
}

/** Параллелепипед с тремя гранями, кладкой и произвольным рисунком на стенах. */
export function Box({ x, y, w, d, h, z = 0, c, left, right, bricks = null, topExtra }: BoxProps) {
  const A = iso(x, y, z + h);
  const B = iso(x + w, y, z + h);
  const C = iso(x + w, y + d, z + h);
  const D = iso(x, y + d, z + h);
  const B0 = iso(x + w, y, z);
  const C0 = iso(x + w, y + d, z);
  const D0 = iso(x, y + d, z);
  const lm = wallMatrix('left', x, y, x + w, y + d, z);
  const rm = wallMatrix('right', x, y, x + w, y + d, z);
  const lenL = w * U;
  const lenR = d * U;
  return (
    <g strokeLinejoin="round" strokeLinecap="round">
      <polygon points={pts([D, C, C0, D0])} fill={c.left} stroke={edge(c.left)} strokeWidth="1.2" />
      <polygon
        points={pts([B, C, C0, B0])}
        fill={c.right}
        stroke={edge(c.right)}
        strokeWidth="1.2"
      />
      {bricks && (
        <>
          <g transform={lm}>
            <Bricks kind={bricks} len={lenL} h={h} dark={0.14} />
          </g>
          <g transform={rm}>
            <Bricks kind={bricks} len={lenR} h={h} dark={0.24} />
          </g>
        </>
      )}
      {left && <g transform={lm}>{left(lenL, h)}</g>}
      {right && <g transform={rm}>{right(lenR, h)}</g>}
      <polygon points={pts([A, B, C, D])} fill={c.top} stroke={edge(c.top)} strokeWidth="1.2" />
      {topExtra}
      {/* блик на верхнем ребре и тень у основания */}
      <polyline
        points={pts([D, C, B])}
        fill="none"
        stroke="#fff"
        strokeOpacity=".35"
        strokeWidth="1.6"
      />
      <polygon
        points={pts([D0, C0, iso(x + w, y + d, z + 3), iso(x, y + d, z + 3)])}
        fill={EDGE}
        opacity=".18"
      />
    </g>
  );
}

/** Кладка/доски на плоскости стены (u вдоль, v вверх). */
export function Bricks({
  kind,
  len,
  h,
  dark,
}: {
  kind: 'stone' | 'wood' | 'plaster';
  len: number;
  h: number;
  dark: number;
}) {
  const line = `rgba(20,12,4,${dark + 0.1})`;
  if (kind === 'wood') {
    return (
      <g stroke={line} strokeWidth="1">
        {Array.from({ length: Math.floor(h / 7) }, (_, i) => (
          <line key={i} x1="0" y1={(i + 1) * 7} x2={len} y2={(i + 1) * 7} />
        ))}
      </g>
    );
  }
  if (kind === 'plaster') {
    return (
      <g stroke={`rgba(90,54,20,${dark + 0.35})`} strokeWidth="2.2">
        <line x1="0" y1={h * 0.5} x2={len} y2={h * 0.5} />
        {Array.from({ length: Math.max(1, Math.floor(len / 34)) + 1 }, (_, i) => (
          <line
            key={i}
            x1={i * (len / Math.max(1, Math.floor(len / 34)))}
            y1="0"
            x2={i * (len / Math.max(1, Math.floor(len / 34)))}
            y2={h}
          />
        ))}
      </g>
    );
  }
  const rows = Math.max(2, Math.floor(h / 9));
  return (
    <g stroke={line} strokeWidth="0.9">
      {Array.from({ length: rows }, (_, r) => (
        <g key={r}>
          <line x1="0" y1={(r + 1) * 9} x2={len} y2={(r + 1) * 9} />
          {Array.from({ length: Math.floor(len / 16) }, (_, c) => (
            <line
              key={c}
              x1={c * 16 + (r % 2) * 8 + 8}
              y1={r * 9}
              x2={c * 16 + (r % 2) * 8 + 8}
              y2={(r + 1) * 9}
            />
          ))}
        </g>
      ))}
    </g>
  );
}

/** Окно на плоскости стены. */
export function Win({
  u,
  v,
  w = 9,
  h = 13,
  lit = false,
}: {
  u: number;
  v: number;
  w?: number;
  h?: number;
  lit?: boolean;
}) {
  return (
    <g>
      <rect x={u - 1.6} y={v - 1.6} width={w + 3.2} height={h + 3.2} rx="2" fill="#5a3a20" />
      <rect x={u} y={v} width={w} height={h} rx="1.6" fill={lit ? '#ffd76a' : '#6fa0d0'} />
      <path d={`M${u + w / 2} ${v}v${h}M${u} ${v + h / 2}h${w}`} stroke="#3a2416" strokeWidth="1" />
      {!lit && (
        <path
          d={`M${u + 1.5} ${v + h - 2}l${w * 0.6} ${-h * 0.5}`}
          stroke="#fff"
          strokeOpacity=".5"
          strokeWidth="1.6"
          strokeLinecap="round"
        />
      )}
    </g>
  );
}

/** Дверь на плоскости стены (арка). */
export function Doorway({
  u,
  w = 18,
  h = 26,
  color = '#5a3620',
}: {
  u: number;
  w?: number;
  h?: number;
  color?: string;
}) {
  return (
    <g>
      <path
        d={`M${u - 2} 0V${h - w / 2}a${w / 2 + 2} ${w / 2 + 2} 0 0 1 ${w + 4} 0V0Z`}
        fill="#3a2416"
      />
      <path d={`M${u} 0V${h - w / 2}a${w / 2} ${w / 2} 0 0 1 ${w} 0V0Z`} fill={color} />
      <path d={`M${u + w / 2} 0V${h}`} stroke="#2a1a0e" strokeWidth="1.2" />
      <circle cx={u + w * 0.72} cy={h * 0.4} r="1.5" fill="#f2cf6b" />
    </g>
  );
}

interface RoofProps {
  x: number;
  y: number;
  w: number;
  d: number;
  z: number;
  rise: number;
  c: Faces;
  /** Конёк идёт вдоль x или y. */
  axis?: 'x' | 'y';
  over?: number;
}

/** Двускатная крыша с черепицей: два ската и торцы. */
export function Gable({ x, y, w, d, z, rise, c, axis = 'x', over = 0.12 }: RoofProps) {
  const x0 = x - over;
  const y0 = y - over;
  const x1 = x + w + over;
  const y1 = y + d + over;
  const ridgeZ = z + rise;
  if (axis === 'x') {
    const ym = (y0 + y1) / 2;
    const R0 = iso(x0, ym, ridgeZ);
    const R1 = iso(x1, ym, ridgeZ);
    const FL0 = iso(x0, y1, z);
    const FL1 = iso(x1, y1, z);
    const BK0 = iso(x0, y0, z);
    const BK1 = iso(x1, y0, z);
    const rows = 4;
    return (
      <g strokeLinejoin="round">
        <polygon
          points={pts([BK0, R0, R1, BK1])}
          fill={c.top}
          stroke={edge(c.top)}
          strokeWidth="1.2"
        />
        <polygon
          points={pts([R0, FL0, FL1, R1])}
          fill={c.left}
          stroke={edge(c.left)}
          strokeWidth="1.2"
        />
        <polygon
          points={pts([R1, FL1, iso(x1, y1, z), iso(x1, y0, z), BK1])}
          fill={c.right}
          stroke={edge(c.right)}
          strokeWidth="1.2"
        />
        {Array.from({ length: rows }, (_, i) => {
          const t = (i + 1) / (rows + 1);
          const a = iso(x0, ym + (y1 - ym) * t, ridgeZ - rise * t);
          const b = iso(x1, ym + (y1 - ym) * t, ridgeZ - rise * t);
          return (
            <line
              key={i}
              x1={a[0]}
              y1={a[1]}
              x2={b[0]}
              y2={b[1]}
              stroke={darken(c.left, 0.45)}
              strokeWidth="1"
              opacity=".7"
            />
          );
        })}
        <polyline
          points={pts([FL0, R0, R1])}
          fill="none"
          stroke="#fff"
          strokeOpacity=".4"
          strokeWidth="1.4"
        />
      </g>
    );
  }
  const xm = (x0 + x1) / 2;
  const R0 = iso(xm, y0, ridgeZ);
  const R1 = iso(xm, y1, ridgeZ);
  const FR0 = iso(x1, y0, z);
  const FR1 = iso(x1, y1, z);
  const BL0 = iso(x0, y0, z);
  const BL1 = iso(x0, y1, z);
  const rows = 4;
  return (
    <g strokeLinejoin="round">
      <polygon
        points={pts([BL0, R0, R1, BL1])}
        fill={c.left}
        stroke={edge(c.left)}
        strokeWidth="1.2"
      />
      <polygon
        points={pts([R0, FR0, FR1, R1])}
        fill={c.right}
        stroke={edge(c.right)}
        strokeWidth="1.2"
      />
      <polygon points={pts([R1, BL1, FR1])} fill={c.left} stroke={edge(c.left)} strokeWidth="1.2" />
      {Array.from({ length: rows }, (_, i) => {
        const t = (i + 1) / (rows + 1);
        const a = iso(xm + (x1 - xm) * t, y0, ridgeZ - rise * t);
        const b = iso(xm + (x1 - xm) * t, y1, ridgeZ - rise * t);
        return (
          <line
            key={i}
            x1={a[0]}
            y1={a[1]}
            x2={b[0]}
            y2={b[1]}
            stroke={darken(c.right, 0.45)}
            strokeWidth="1"
            opacity=".7"
          />
        );
      })}
      <polyline
        points={pts([BL1, R1, FR1])}
        fill="none"
        stroke="#fff"
        strokeOpacity=".35"
        strokeWidth="1.4"
      />
    </g>
  );
}

/** Четырёхскатная (шатровая) крыша, острая вершина — для башен и куполов. */
export function Pyramid({
  x,
  y,
  w,
  d,
  z,
  rise,
  c,
  over = 0.1,
}: {
  x: number;
  y: number;
  w: number;
  d: number;
  z: number;
  rise: number;
  c: Faces;
  over?: number;
}) {
  const x0 = x - over;
  const y0 = y - over;
  const x1 = x + w + over;
  const y1 = y + d + over;
  const T = iso((x0 + x1) / 2, (y0 + y1) / 2, z + rise);
  const A = iso(x0, y0, z);
  const B = iso(x1, y0, z);
  const C = iso(x1, y1, z);
  const D = iso(x0, y1, z);
  return (
    <g strokeLinejoin="round">
      <polygon points={pts([D, C, T])} fill={c.left} stroke={edge(c.left)} strokeWidth="1.2" />
      <polygon points={pts([B, C, T])} fill={c.right} stroke={edge(c.right)} strokeWidth="1.2" />
      <polygon
        points={pts([A, D, T])}
        fill={c.top}
        stroke={edge(c.top)}
        strokeWidth="1.2"
        opacity=".0"
      />
      <polyline
        points={pts([D, T, C])}
        fill="none"
        stroke="#fff"
        strokeOpacity=".35"
        strokeWidth="1.2"
      />
    </g>
  );
}

/** Цилиндрическая башня с горизонтальным градиентом (левая сторона светлее) и зубцами/крышей сверху. */
export function Tower({
  cx,
  cy,
  r,
  h,
  z = 0,
  c,
  roof,
  roofRise = 0,
  cap = true,
  id,
}: {
  cx: number;
  cy: number;
  r: number;
  h: number;
  z?: number;
  c: Faces;
  roof?: Faces;
  roofRise?: number;
  cap?: boolean;
  id: string;
}) {
  const [sx, sy] = iso(cx, cy, z);
  const rx = r * TW_HALF;
  const ry = rx / 2;
  const top = sy - h;
  const grad = `${id}-g`;
  return (
    <g strokeLinejoin="round">
      <defs>
        <linearGradient id={grad} x1="0" x2="1" y1="0" y2="0">
          <stop offset="0" stopColor={lighten(c.left, 0.22)} />
          <stop offset="0.45" stopColor={c.left} />
          <stop offset="1" stopColor={c.right} />
        </linearGradient>
      </defs>
      <path
        d={`M${sx - rx} ${sy}V${top}A${rx} ${ry} 0 0 0 ${sx + rx} ${top}V${sy}A${rx} ${ry} 0 0 1 ${sx - rx} ${sy}Z`}
        fill={`url(#${grad})`}
        stroke={edge(c.right)}
        strokeWidth="1.2"
      />
      {cap && (
        <ellipse
          cx={sx}
          cy={top}
          rx={rx}
          ry={ry}
          fill={c.top}
          stroke={edge(c.top)}
          strokeWidth="1.2"
        />
      )}
      {roof && roofRise > 0 && (
        <g>
          <path
            d={`M${sx - rx - 3} ${top}L${sx} ${top - roofRise}L${sx + rx + 3} ${top}A${rx + 3} ${ry + 1.5} 0 0 1 ${sx - rx - 3} ${top}Z`}
            fill={roof.left}
            stroke={edge(roof.left)}
            strokeWidth="1.2"
          />
          <path
            d={`M${sx} ${top - roofRise}L${sx + rx + 3} ${top}A${rx + 3} ${ry + 1.5} 0 0 1 ${sx} ${top + ry + 1.5}Z`}
            fill={roof.right}
            opacity=".75"
          />
        </g>
      )}
    </g>
  );
}
const TW_HALF = 32;

/** Плоский ромб-участок земли на клетках. */
export function Patch({
  x,
  y,
  w,
  d,
  z = 0,
  fill,
  stroke,
  opacity = 1,
  dash,
}: {
  x: number;
  y: number;
  w: number;
  d: number;
  z?: number;
  fill: string;
  stroke?: string;
  opacity?: number;
  dash?: string;
}) {
  const A = iso(x, y, z);
  const B = iso(x + w, y, z);
  const C = iso(x + w, y + d, z);
  const D = iso(x, y + d, z);
  return (
    <polygon
      points={pts([A, B, C, D])}
      fill={fill}
      stroke={stroke}
      strokeWidth="1.4"
      strokeDasharray={dash}
      opacity={opacity}
      strokeLinejoin="round"
    />
  );
}

/** Мягкая тень на земле под зданием. */
export function GroundShadow({ x, y, w, d }: { x: number; y: number; w: number; d: number }) {
  const A = iso(x - 0.1, y + 0.05, 0);
  const B = iso(x + w + 0.5, y + 0.05, 0);
  const C = iso(x + w + 0.5, y + d + 0.4, 0);
  const D = iso(x - 0.1, y + d + 0.4, 0);
  return <polygon points={pts([A, B, C, D])} fill="#0b2a0b" opacity=".22" />;
}

export { OUTLINE, mix };
export type { P2 };
