import { hashSeed } from '@tc/shared';
import { darken, lighten } from '../art/color';
import { iso, pts } from './project';

/** Общие градиенты сцены: круглые кроны и травяной ковёр получают объём. Кладутся один раз в <defs>. */
export function IsoDefs() {
  return (
    <defs>
      <radialGradient id="ig-oak" cx=".35" cy=".3" r=".85">
        <stop offset="0" stopColor="#8fd06a" />
        <stop offset=".55" stopColor="#4f9a45" />
        <stop offset="1" stopColor="#2f6a2f" />
      </radialGradient>
      <radialGradient id="ig-oak2" cx=".35" cy=".3" r=".85">
        <stop offset="0" stopColor="#a8dc78" />
        <stop offset=".55" stopColor="#5aa84c" />
        <stop offset="1" stopColor="#367a36" />
      </radialGradient>
      <linearGradient id="ig-pine-l" x1="0" x2="1">
        <stop offset="0" stopColor="#4fae5a" />
        <stop offset="1" stopColor="#2f7a3a" />
      </linearGradient>
      <linearGradient id="ig-soil" x1="0" x2="0" y1="0" y2="1">
        <stop offset="0" stopColor="#a97b4a" />
        <stop offset="1" stopColor="#6a4526" />
      </linearGradient>
      <linearGradient id="ig-soil-r" x1="0" x2="0" y1="0" y2="1">
        <stop offset="0" stopColor="#8a6238" />
        <stop offset="1" stopColor="#4f321a" />
      </linearGradient>
      <linearGradient id="ig-sea" x1="0" x2="0" y1="0" y2="1">
        <stop offset="0" stopColor="#5fb4e8" />
        <stop offset="1" stopColor="#2f7fc0" />
      </linearGradient>
      <radialGradient id="ig-vignette" cx=".5" cy=".5" r=".75">
        <stop offset=".55" stopColor="#000" stopOpacity="0" />
        <stop offset="1" stopColor="#0a1a2a" stopOpacity=".35" />
      </radialGradient>
      <linearGradient id="ig-fog" x1="0" x2="1" y1="0" y2="1">
        <stop offset="0" stopColor="#ffffff" stopOpacity=".1" />
        <stop offset="1" stopColor="#ffffff" stopOpacity=".55" />
      </linearGradient>
      <radialGradient id="ig-water" cx=".4" cy=".35" r=".8">
        <stop offset="0" stopColor="#8fd4f4" />
        <stop offset="1" stopColor="#3f8ac8" />
      </radialGradient>
    </defs>
  );
}

const S = (c: string) => ({
  stroke: darken(c, 0.55),
  strokeWidth: 1.2,
  strokeLinejoin: 'round' as const,
});

export function IsoTree({
  x,
  y,
  s = 1,
  kind,
}: {
  x: number;
  y: number;
  s?: number;
  kind: 'oak' | 'pine' | 'bush' | 'birch';
}) {
  const [sx, sy] = iso(x, y, 0);
  return (
    <g transform={`translate(${sx} ${sy}) scale(${s})`}>
      <ellipse cx="2" cy="1" rx="17" ry="7" fill="#0b2a0b" opacity=".28" />
      {kind === 'pine' ? (
        <g>
          <rect x="-3" y="-10" width="6" height="12" fill="#6a4526" {...S('#6a4526')} />
          <path d="M0 -60 15 -30H-15Z" fill="url(#ig-pine-l)" {...S('#2f7a3a')} />
          <path d="M0 -48 19 -16H-19Z" fill="url(#ig-pine-l)" {...S('#2f7a3a')} />
          <path d="M0 -34 23 -4H-23Z" fill="url(#ig-pine-l)" {...S('#2f7a3a')} />
          <path d="M0 -60 15 -30 4 -30Z" fill="#fff" opacity=".18" />
        </g>
      ) : kind === 'bush' ? (
        <g>
          <circle cx="-8" cy="-7" r="9" fill="url(#ig-oak)" {...S('#3f8a3a')} />
          <circle cx="8" cy="-7" r="9" fill="url(#ig-oak2)" {...S('#3f8a3a')} />
          <circle cx="0" cy="-14" r="10" fill="url(#ig-oak2)" {...S('#3f8a3a')} />
        </g>
      ) : (
        <g>
          <path
            d="M-4 2 -3 -22H3L4 2Z"
            fill={kind === 'birch' ? '#e8e2d2' : '#7a5230'}
            {...S('#5a3620')}
          />
          <circle cx="-13" cy="-30" r="14" fill="url(#ig-oak)" {...S('#3f8a3a')} />
          <circle cx="13" cy="-30" r="14" fill="url(#ig-oak2)" {...S('#3f8a3a')} />
          <circle cx="0" cy="-44" r="17" fill="url(#ig-oak2)" {...S('#3f8a3a')} />
          <circle cx="-6" cy="-49" r="4.500" fill="#fff" opacity=".22" />
        </g>
      )}
    </g>
  );
}

export function IsoRock({ x, y, s = 1 }: { x: number; y: number; s?: number }) {
  const [sx, sy] = iso(x, y, 0);
  return (
    <g transform={`translate(${sx} ${sy}) scale(${s})`}>
      <ellipse cx="2" cy="1" rx="14" ry="5" fill="#0b2a0b" opacity=".25" />
      <path d="M-12 0 -8 -12 2 -16 12 -8 14 0Z" fill="#9a968c" {...S('#9a968c')} />
      <path d="M2 -16 12 -8 14 0 2 0Z" fill="#6f6b62" />
      <path d="M-8 -12 2 -16 -1 -8Z" fill="#c8c4b8" />
    </g>
  );
}

/** Колодец/фонтан на площади. */
export function IsoFountain({ x, y }: { x: number; y: number }) {
  const [sx, sy] = iso(x, y, 0);
  return (
    <g transform={`translate(${sx} ${sy})`}>
      <ellipse cx="0" cy="2" rx="46" ry="23" fill="#0b2a0b" opacity=".25" />
      <ellipse cx="0" cy="-6" rx="42" ry="21" fill="#a8a296" {...S('#a8a296')} />
      <ellipse cx="0" cy="-10" rx="42" ry="21" fill="#d2ccbe" {...S('#d2ccbe')} />
      <ellipse
        cx="0"
        cy="-10"
        rx="34"
        ry="17"
        fill="url(#ig-water)"
        stroke="#2a5a88"
        strokeWidth="1.200"
      />
      <ellipse
        className="scene-ripple"
        cx="0"
        cy="-10"
        rx="22"
        ry="10"
        fill="none"
        stroke="#fff"
        strokeWidth="1.600"
        opacity=".6"
      />
      <rect x="-5" y="-38" width="10" height="28" rx="3" fill="#b8b1a2" {...S('#b8b1a2')} />
      <ellipse cx="0" cy="-40" rx="14" ry="6" fill="#d2ccbe" {...S('#d2ccbe')} />
      <path
        d="M0 -44q-14 -10 -20 10M0 -44q14 -10 20 10"
        stroke="#cfeaff"
        strokeWidth="2.400"
        fill="none"
        strokeLinecap="round"
        className="scene-glow"
      />
    </g>
  );
}

/** Фонарь и столбик забора — мелкие детали на площади. */
export function IsoLamp({ x, y }: { x: number; y: number }) {
  const [sx, sy] = iso(x, y, 0);
  return (
    <g transform={`translate(${sx} ${sy})`}>
      <ellipse cx="0" cy="0" rx="7" ry="3" fill="#0b2a0b" opacity=".3" />
      <rect x="-1.600" y="-34" width="3.200" height="34" fill="#4a3a2a" />
      <rect
        x="-5"
        y="-44"
        width="10"
        height="11"
        rx="2"
        fill="#ffd76a"
        stroke="#4a3a2a"
        strokeWidth="1.400"
        className="scene-glow"
      />
      <path d="M-6 -44 0 -50 6 -44Z" fill="#4a3a2a" />
    </g>
  );
}

const roll = (x: number, y: number, salt: string): number =>
  (hashSeed(`${x}:${y}:${salt}`) % 10_000) / 10_000;
export { roll };

/** Цветочная поляна: россыпь цветов на клетке. */
export function IsoFlowers({ x, y }: { x: number; y: number }) {
  const cols = ['#ffe27a', '#fff', '#ff9ab0', '#c8a0ff'];
  return (
    <g>
      {Array.from({ length: 4 }, (_, i) => {
        const [sx, sy] = iso(x + roll(x, y, `fx${i}`) * 0.8, y + roll(x, y, `fy${i}`) * 0.8, 0);
        return (
          <g key={i}>
            <circle cx={sx} cy={sy} r="2.600" fill={cols[i % cols.length]} />
            <circle cx={sx} cy={sy} r="0.9" fill="#c98a1a" />
          </g>
        );
      })}
    </g>
  );
}

/** Плитка мостовой: ромб с камешками. */
export function Cobble({ x, y, tone = 0 }: { x: number; y: number; tone?: number }) {
  const A = iso(x, y);
  const B = iso(x + 1, y);
  const C = iso(x + 1, y + 1);
  const D = iso(x, y + 1);
  const base = tone > 0.5 ? '#d8c08a' : '#cfb67e';
  const cx = (A[0] + C[0]) / 2;
  const cy = (A[1] + C[1]) / 2;
  return (
    <g>
      <polygon
        points={pts([A, B, C, D])}
        fill={base}
        stroke={darken(base, 0.25)}
        strokeWidth=".8"
        strokeLinejoin="round"
      />
      <ellipse cx={cx - 8} cy={cy - 2} rx="5" ry="2.400" fill={lighten(base, 0.2)} opacity=".8" />
      <ellipse cx={cx + 9} cy={cy + 3} rx="4" ry="2" fill={darken(base, 0.16)} opacity=".7" />
    </g>
  );
}
