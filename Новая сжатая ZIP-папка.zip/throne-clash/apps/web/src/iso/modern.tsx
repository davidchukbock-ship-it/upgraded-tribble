import type { ReactNode } from 'react';
import type { PlacedKey } from './buildings';
import { Box, GroundShadow, Patch, Pyramid, Tower, faces, type Faces } from './primitives';
import { iso } from './project';

/**
 * Современные формы зданий (эпоха «modern», D-63): стекло, бетон, плоские крыши, трубы, антенны.
 * Тот же участок и те же ключи, что у средневековых; ступень (tier) добавляет этажи и оборудование.
 */
type Tier = 0 | 1 | 2 | 3;
interface M {
  ox: number;
  oy: number;
  tier: Tier;
  id: string;
}

const M_PAL = {
  concrete: faces('#cfd6dc'),
  concreteDark: faces('#8f9aa5'),
  glass: faces('#5fa8d8'),
  glassDeep: faces('#2f6fae'),
  white: faces('#f6f8fa'),
  steel: faces('#7d8b98'),
  asphalt: faces('#4a5560'),
  red: faces('#d9503c'),
  green: faces('#3fae6a'),
  orange: faces('#f0a03a'),
  violet: faces('#8a5fd0'),
  cyan: faces('#4fd8e8'),
} as const;

/** Остекление: сетка окон на плоскости стены (u вдоль, v вверх). */
export function Panes({
  len,
  h,
  rows,
  cols,
  lit = 0.25,
  seed = 0,
}: {
  len: number;
  h: number;
  rows: number;
  cols: number;
  lit?: number;
  seed?: number;
}) {
  const cw = (len - 8) / cols;
  const rh = (h - 10) / rows;
  const cells: ReactNode[] = [];
  for (let r = 0; r < rows; r++)
    for (let c = 0; c < cols; c++) {
      const on = ((c * 7 + r * 13 + seed * 5) % 10) / 10 < lit;
      cells.push(
        <rect
          key={`${r}-${c}`}
          x={4 + c * cw + 1}
          y={6 + r * rh + 1}
          width={cw - 2}
          height={rh - 2}
          rx="1"
          fill={on ? '#ffe9a0' : '#9fd2f2'}
          opacity={on ? 0.95 : 0.85}
        />,
      );
    }
  return (
    <g>
      <rect x="2" y="3" width={len - 4} height={h - 6} rx="2" fill="#1f4f80" opacity=".55" />
      {cells}
      <path
        d={`M${len * 0.1} ${h * 0.15}L${len * 0.45} ${h * 0.9}`}
        stroke="#fff"
        strokeOpacity=".22"
        strokeWidth="5"
      />
    </g>
  );
}

const Glass =
  (rows: number, cols: number, seed = 0) =>
  (len: number, h: number) => <Panes len={len} h={h} rows={rows} cols={cols} seed={seed} />;

function Antenna({ x, y, z, h = 36 }: { x: number; y: number; z: number; h?: number }) {
  const [sx, sy] = iso(x, y, z);
  return (
    <g>
      <line x1={sx} y1={sy} x2={sx} y2={sy - h} stroke="#5a6672" strokeWidth="2.500" />
      <circle cx={sx} cy={sy - h} r="3" fill="#ff4d4d" />
    </g>
  );
}

function Chimney({ x, y, z = 0, h = 60 }: { x: number; y: number; z?: number; h?: number }) {
  return (
    <g>
      <Tower cx={x} cy={y} r={0.28} h={h} z={z} c={M_PAL.concreteDark} id={`ch-${x}-${y}`} />
      <Patch x={x - 0.12} y={y - 0.12} w={0.24} d={0.24} z={z + h} fill="#e8e8e8" opacity={0.5} />
    </g>
  );
}

function Crate({ x, y, c }: { x: number; y: number; c: Faces }) {
  return <Box x={x} y={y} w={0.6} d={0.5} h={10} c={c} />;
}

function Skyscraper({ ox, oy, tier, id }: M) {
  const h = 120 + tier * 34;
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={5} d={4} />
      <Box
        x={ox + 0.4}
        y={oy + 0.5}
        w={4.2}
        d={3}
        h={22}
        c={M_PAL.concrete}
        left={Glass(1, 9)}
        right={Glass(1, 6)}
      />
      <Box
        x={ox + 1.5}
        y={oy + 1}
        w={2}
        d={2}
        h={h}
        z={22}
        c={M_PAL.glass}
        left={Glass(7 + tier * 2, 4)}
        right={Glass(7 + tier * 2, 4, 2)}
      />
      {tier >= 1 && (
        <Box
          x={ox + 3.1}
          y={oy + 1.4}
          w={1}
          d={1.2}
          h={h * 0.55}
          z={22}
          c={M_PAL.glassDeep}
          left={Glass(4, 2, 1)}
          right={Glass(4, 2, 3)}
        />
      )}
      <Box x={ox + 1.8} y={oy + 1.3} w={1.4} d={1.4} h={10} z={22 + h} c={M_PAL.steel} />
      <Antenna x={ox + 2.5} y={oy + 2} z={32 + h} h={44} />
      {tier >= 2 && <Patch x={ox + 0.6} y={oy + 3.2} w={1.4} d={0.6} fill="#3fae6a" />}
      <Tower cx={ox + 0.9} cy={oy + 3.5} r={0.3} h={8} c={M_PAL.green} id={`${id}-p`} />
    </g>
  );
}

function Greenhouse({ ox, oy, tier, id }: M) {
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={4} d={4} />
      <Patch x={ox + 0.2} y={oy + 2.6} w={3.4} d={1.2} fill="#6a4a2a" />
      {[0, 1, 2, 3].map((i) => (
        <Patch key={i} x={ox + 0.3 + i * 0.85} y={oy + 2.7} w={0.5} d={1} fill="#4fbf4a" />
      ))}
      <Box
        x={ox + 0.3}
        y={oy + 0.3}
        w={3}
        d={2}
        h={26}
        c={M_PAL.white}
        left={Glass(2, 6, 1)}
        right={Glass(2, 4, 2)}
      />
      <Pyramid x={ox + 0.3} y={oy + 0.3} w={3} d={2} z={26} rise={14} c={M_PAL.glass} />
      <Tower
        cx={ox + 3.5}
        cy={oy + 0.8}
        r={0.4}
        h={54 + tier * 8}
        c={M_PAL.steel}
        roof={M_PAL.red}
        roofRise={10}
        id={`${id}-silo`}
      />
    </g>
  );
}

function Goldmine({ ox, oy, tier, id }: M) {
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={4} d={4} />
      <Patch x={ox} y={oy} w={4} d={4} fill="#7a7f86" opacity={0.6} />
      <Box
        x={ox + 0.4}
        y={oy + 0.6}
        w={2.2}
        d={2}
        h={36 + tier * 8}
        c={M_PAL.steel}
        left={Glass(2, 3, 4)}
        right={Glass(2, 3, 1)}
      />
      <Box x={ox + 2.8} y={oy + 1.2} w={1} d={0.5} h={14} c={M_PAL.orange} />
      <Tower
        cx={ox + 3.2}
        cy={oy + 2.8}
        r={0.5}
        h={40}
        c={M_PAL.concrete}
        roof={M_PAL.orange}
        roofRise={0}
        id={`${id}-tank`}
      />
      <Crate x={ox + 0.5} y={oy + 3} c={M_PAL.orange} />
      <Crate x={ox + 1.3} y={oy + 3.2} c={M_PAL.red} />
    </g>
  );
}

function Sawmill({ ox, oy, tier }: M) {
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={3} d={3} />
      <Box
        x={ox + 0.2}
        y={oy + 0.3}
        w={2.2}
        d={1.8}
        h={24}
        c={M_PAL.concrete}
        left={Glass(1, 4)}
        right={Glass(1, 3)}
      />
      {[0, 1, 2].map((i) => (
        <Pyramid
          key={i}
          x={ox + 0.2 + i * 0.73}
          y={oy + 0.3}
          w={0.73}
          d={1.8}
          z={24}
          rise={9}
          c={M_PAL.steel}
        />
      ))}
      {[0, 1, 2].map((i) => (
        <Box
          key={i}
          x={ox + 0.3}
          y={oy + 2.3 + i * 0.22}
          w={2}
          d={0.2}
          h={8 + tier * 2}
          c={faces('#b9834f')}
        />
      ))}
      <Chimney x={ox + 2.6} y={oy + 0.6} h={44} />
    </g>
  );
}

function Quarry({ ox, oy, tier }: M) {
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={3} d={3} />
      <Patch x={ox} y={oy} w={3} d={3} fill="#8c8f94" />
      <Patch x={ox + 0.3} y={oy + 0.5} w={2} d={1.6} fill="#5d6166" />
      <Box x={ox + 2.2} y={oy + 0.3} w={0.6} d={0.6} h={70 + tier * 6} c={M_PAL.orange} />
      <Box x={ox + 0.8} y={oy + 0.42} w={1.9} d={0.16} h={8} z={62 + tier * 6} c={M_PAL.orange} />
      <Box x={ox + 0.5} y={oy + 2.2} w={1} d={0.7} h={12} c={M_PAL.red} />
      <Crate x={ox + 1.8} y={oy + 2.3} c={M_PAL.concreteDark} />
    </g>
  );
}

function Warehouse({ ox, oy, tier }: M) {
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={3} d={2} />
      <Box
        x={ox + 0.1}
        y={oy + 0.1}
        w={2.8}
        d={1.8}
        h={28 + tier * 3}
        c={M_PAL.white}
        left={(len, h) => (
          <g>
            {[0, 1, 2].map((i) => (
              <rect
                key={i}
                x={6 + i * ((len - 12) / 3)}
                y={2}
                width={(len - 12) / 3 - 4}
                height={h * 0.6}
                fill="#e0672f"
              />
            ))}
          </g>
        )}
        right={Glass(1, 3, 3)}
      />
      <Box x={ox + 0.1} y={oy + 0.1} w={2.8} d={1.8} h={3} z={28 + tier * 3} c={M_PAL.steel} />
    </g>
  );
}

function Forge({ ox, oy, tier }: M) {
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={3} d={3} />
      <Box
        x={ox + 0.2}
        y={oy + 0.5}
        w={2.4}
        d={2}
        h={30}
        c={M_PAL.steel}
        left={Glass(1, 4, 2)}
        right={Glass(1, 3, 1)}
      />
      <Chimney x={ox + 0.6} y={oy + 0.8} z={30} h={50 + tier * 8} />
      <Chimney x={ox + 1.4} y={oy + 0.8} z={30} h={38 + tier * 6} />
      <Box x={ox + 1.8} y={oy + 2.6} w={0.8} d={0.3} h={12} c={M_PAL.red} />
    </g>
  );
}

function Academy({ ox, oy, tier }: M) {
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={3} d={3} />
      <Box
        x={ox + 0.2}
        y={oy + 0.4}
        w={2.6}
        d={2.2}
        h={44 + tier * 8}
        c={M_PAL.glass}
        left={Glass(3 + tier, 5, 2)}
        right={Glass(3 + tier, 4, 4)}
      />
      <Box x={ox + 0.05} y={oy + 0.25} w={2.9} d={2.5} h={4} z={44 + tier * 8} c={M_PAL.white} />
      <Box x={ox + 1.1} y={oy + 2.6} w={0.8} d={0.3} h={22} c={M_PAL.white} />
      <Patch x={ox + 0.4} y={oy + 2.75} w={2.2} d={0.25} fill="#6fbf6a" />
    </g>
  );
}

function Hospital({ ox, oy, tier }: M) {
  const h = 46 + tier * 8;
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={3} d={3} />
      <Box
        x={ox + 0.2}
        y={oy + 0.4}
        w={2.6}
        d={2.2}
        h={h}
        c={M_PAL.white}
        left={(len, hh) => (
          <g>
            <Panes len={len} h={hh} rows={3} cols={5} seed={3} />
            <path d={`M${len * 0.5 - 4} ${hh - 22}h8v-8h-8z`} fill="none" />
            <rect x={len * 0.5 - 9} y={hh - 26} width="18" height="6" fill="#e0342c" />
            <rect x={len * 0.5 - 3} y={hh - 32} width="6" height="18" fill="#e0342c" />
          </g>
        )}
        right={Glass(3, 4, 5)}
      />
      <Patch x={ox + 0.7} y={oy + 0.9} w={1.6} d={1.6} z={h} fill="#5a6672" />
      <Patch x={ox + 1.05} y={oy + 1.25} w={0.9} d={0.9} z={h + 0.5} fill="none" stroke="#fff" />
    </g>
  );
}

function Barracks({ ox, oy, tier }: M) {
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={4} d={3} />
      <Box
        x={ox + 0.2}
        y={oy + 0.3}
        w={3.6}
        d={1.2}
        h={26 + tier * 4}
        c={faces('#8a9a6a')}
        left={Glass(1, 7, 6)}
        right={Glass(1, 2, 2)}
      />
      <Box
        x={ox + 0.2}
        y={oy + 1.8}
        w={2}
        d={1}
        h={18}
        c={faces('#7a8a5a')}
        left={Glass(1, 3, 1)}
        right={Glass(1, 2, 3)}
      />
      <Antenna x={ox + 3.5} y={oy + 2.2} z={0} h={62} />
      <Box x={ox + 2.8} y={oy + 2} w={0.9} d={0.9} h={8} c={M_PAL.steel} />
    </g>
  );
}

function Fishery({ ox, oy, tier }: M) {
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={3} d={3} />
      <Patch x={ox} y={oy + 1.8} w={3} d={1.2} fill="#4a5560" />
      <Box
        x={ox + 0.2}
        y={oy + 0.3}
        w={1.6}
        d={1.4}
        h={24}
        c={M_PAL.white}
        left={Glass(1, 3, 2)}
        right={Glass(1, 2, 1)}
      />
      <Box x={ox + 1.9} y={oy + 0.5} w={0.9} d={0.5} h={12 + tier * 2} c={M_PAL.red} />
      <Box x={ox + 1.9} y={oy + 1.1} w={0.9} d={0.5} h={12} c={M_PAL.cyan} />
      <Box x={ox + 2.5} y={oy + 2.2} w={0.2} d={0.2} h={44} c={M_PAL.orange} />
      <Box x={ox + 1.4} y={oy + 2.28} w={1.3} d={0.08} h={4} z={42} c={M_PAL.orange} />
    </g>
  );
}

function DiamondMine({ ox, oy, tier }: M) {
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={3} d={3} />
      <Box
        x={ox + 0.2}
        y={oy + 0.3}
        w={2.6}
        d={2.4}
        h={16}
        c={M_PAL.concreteDark}
        left={Glass(1, 5, 5)}
        right={Glass(1, 4, 1)}
      />
      <Pyramid x={ox + 0.5} y={oy + 0.6} w={2} d={1.8} z={16} rise={44 + tier * 8} c={M_PAL.cyan} />
      <Box x={ox + 2.2} y={oy + 2.7} w={0.5} d={0.3} h={10} c={M_PAL.cyan} />
    </g>
  );
}

function PowerTower({ ox, oy, tier, id }: M) {
  const h = 84 + tier * 12;
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={2} d={2} />
      <Box x={ox + 0.3} y={oy + 0.3} w={1.4} d={1.4} h={10} c={M_PAL.concrete} />
      <Tower
        cx={ox + 1}
        cy={oy + 1}
        r={0.42}
        h={h}
        z={10}
        c={M_PAL.violet}
        roof={M_PAL.cyan}
        roofRise={26}
        id={id}
      />
      <Box x={ox + 0.6} y={oy + 0.6} w={0.8} d={0.8} h={5} z={10 + h * 0.55} c={M_PAL.cyan} />
    </g>
  );
}

function RadarTower({ ox, oy, tier, id }: M) {
  const h = 70 + tier * 10;
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={2} d={2} />
      <Tower cx={ox + 1} cy={oy + 1} r={0.4} h={h} c={M_PAL.concrete} id={id} />
      <Box
        x={ox + 0.5}
        y={oy + 0.5}
        w={1}
        d={1}
        h={16}
        z={h}
        c={M_PAL.glass}
        left={Glass(1, 3)}
        right={Glass(1, 3, 1)}
      />
      <Antenna x={ox + 1} y={oy + 1} z={h + 16} h={24} />
    </g>
  );
}

function MissileTower({ ox, oy, tier }: M) {
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={2} d={2} />
      <Box
        x={ox + 0.2}
        y={oy + 0.2}
        w={1.6}
        d={1.6}
        h={34 + tier * 6}
        c={faces('#7a8a5a')}
        left={Glass(1, 3, 2)}
        right={Glass(1, 3, 1)}
      />
      {[0, 1, 2].map((i) => (
        <Box
          key={i}
          x={ox + 0.4 + i * 0.45}
          y={oy + 0.6}
          w={0.3}
          d={0.8}
          h={22}
          z={34 + tier * 6}
          c={M_PAL.red}
        />
      ))}
    </g>
  );
}

function StormPylon({ ox, oy, tier, id }: M) {
  const h = 96 + tier * 12;
  return (
    <g>
      <GroundShadow x={ox} y={oy} w={2} d={2} />
      <Box x={ox + 0.4} y={oy + 0.4} w={1.2} d={1.2} h={8} c={M_PAL.steel} />
      <Tower cx={ox + 1} cy={oy + 1} r={0.2} h={h} z={8} c={M_PAL.steel} id={id} />
      {[0.35, 0.6, 0.85].map((f, i) => (
        <Box
          key={i}
          x={ox + 0.5}
          y={oy + 0.5}
          w={1}
          d={1}
          h={3}
          z={8 + h * f}
          c={i % 2 ? M_PAL.cyan : M_PAL.violet}
        />
      ))}
      <Antenna x={ox + 1} y={oy + 1} z={8 + h} h={16} />
    </g>
  );
}

export const MODERN_ART: Record<PlacedKey, (p: M) => ReactNode> = {
  castle: Skyscraper,
  farm: Greenhouse,
  goldmine: Goldmine,
  sawmill: Sawmill,
  quarry: Quarry,
  warehouse: Warehouse,
  forge: Forge,
  academy: Academy,
  hospital: Hospital,
  barracks: Barracks,
  fishery: Fishery,
  diamondmine: DiamondMine,
  magetower: PowerTower,
  archertower: RadarTower,
  ballistatower: MissileTower,
  stormtower: StormPylon,
};
