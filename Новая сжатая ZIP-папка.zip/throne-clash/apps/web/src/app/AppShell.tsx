import { useEffect, useRef, useState } from 'react';
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Icon } from '../icons/Icon';
import { NavArt } from '../art';
import { refreshSession } from '../lib/api';
import { isImpersonating, useAuth } from '../store/auth';
import { ResourceHeader } from '../features/castle/ResourceHeader';
import { packsReady } from '../features/progress/FreePacks';
import { useFreePacks, useQuests } from '../features/progress/useProgress';
import { useNow } from '../features/castle/useCastle';
import { TutorialBanner } from '../features/progress/TutorialBanner';
import { NotificationBell } from '../features/social/NotificationBell';
import { useRealtimeConnection } from '../features/social/useRealtimeConnection';
import { ToastHost } from '../ui';
import { MenuModal } from './MenuModal';
import { NAV_ENTRIES } from './nav';
import { useSoundtrack } from '../audio/useSoundtrack';

/** Красная полоса, пока владелец действует от имени игрока; «Выйти» возвращает его собственную сессию. */
function ImpersonationBanner() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const token = useAuth((s) => s.accessToken);
  const user = useAuth((s) => s.user);
  if (!isImpersonating(token)) return null;
  return (
    <div
      role="alert"
      className="mb-3 flex flex-wrap items-center gap-3 rounded-lg bg-red-700 px-4 py-2 text-sm font-bold text-white"
    >
      <span>{t('god.impersonating', { name: user?.nickname ?? '' })}</span>
      <button
        type="button"
        className="min-h-[36px] rounded bg-white px-3 font-bold text-red-800"
        onClick={() => void refreshSession().then(() => navigate('/god'))}
      >
        {t('god.stopImpersonating')}
      </button>
    </div>
  );
}

export function AppShell() {
  const { t } = useTranslation();
  const role = useAuth((s) => s.user?.role);
  const navigate = useNavigate();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const freePacks = useFreePacks().data?.packs ?? [];
  const ready = (useQuests().data?.claimable ?? 0) + packsReady(freePacks, useNow(30_000));
  // Горячая клавиша владельца: Ctrl+Shift+G открывает режим бога (ссылок на него в интерфейсе нет)
  useEffect(() => {
    if (role !== 'OWNER') return;
    const onKey = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'g') {
        e.preventDefault();
        navigate('/god');
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [role, navigate]);
  const authed = useAuth((s) => s.status === 'authenticated');
  useRealtimeConnection();
  useSoundtrack();
  const entries = authed
    ? [
        ...NAV_ENTRIES,
        ...(role === 'ADMIN' || role === 'OWNER'
          ? [{ to: '/admin', icon: 'admin' as const, label: 'nav.admin' }]
          : []),
      ]
    : [
        { to: '/login', icon: 'login' as const, label: 'auth.login' },
        { to: '/register', icon: 'register' as const, label: 'auth.register' },
        { to: '/ui-kit', icon: 'uikit' as const, label: 'nav.uikit' },
      ];
  const headerRef = useRef<HTMLElement>(null);
  // Высота верхней полосы (на узком экране ресурсы переносятся) — от неё отсчитываются плашки экранов
  useEffect(() => {
    const el = headerRef.current;
    if (!el) return;
    const apply = (): void =>
      document.documentElement.style.setProperty('--hdr', `${el.getBoundingClientRect().height}px`);
    apply();
    if (typeof ResizeObserver === 'undefined') return;
    const ro = new ResizeObserver(apply);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return (
    <div className="flex min-h-full flex-col">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:z-[70] focus:rounded focus:bg-gold focus:px-3 focus:py-2 focus:text-ink"
      >
        {t('common.skipToContent')}
      </a>

      <header
        ref={headerRef}
        className="sticky top-0 z-30 flex flex-wrap items-start gap-2 bg-gradient-to-b from-black/60 to-transparent px-3 pb-2 pt-3 md:px-6"
      >
        {authed ? (
          <div className="order-last min-w-0 basis-full md:order-none md:basis-0 md:flex-1">
            <ResourceHeader />
          </div>
        ) : (
          <NavLink to="/" className="min-w-0 flex-1 font-display text-lg font-bold text-gold-light">
            {t('app.title')}
          </NavLink>
        )}
        {authed && (
          <Link
            to="/donate"
            aria-label={t('nav.topup')}
            title={t('nav.topup')}
            className="btn-3d ml-auto flex h-11 shrink-0 items-center gap-1 bg-gradient-to-b md:ml-0 from-[#63c8ff] to-[#2a78c0] px-3 text-white"
          >
            <NavArt name="donate" size={30} />
            <Icon name="plus" size={14} />
          </Link>
        )}
        {authed && <NotificationBell />}
        <button
          type="button"
          onClick={() => setMenuOpen(true)}
          aria-label={t('menu.open')}
          aria-haspopup="dialog"
          data-nosound
          className="panel-wood relative flex h-11 w-11 shrink-0 items-center justify-center rounded-full"
        >
          <NavArt name="settings" size={32} />
          {ready > 0 && (
            <span
              className="absolute -right-1 -top-1 min-w-[20px] rounded-full bg-red px-1 text-center text-xs font-bold leading-5 text-white"
              aria-label={t('quests.ready', { count: ready })}
            >
              {ready}
            </span>
          )}
        </button>
      </header>

      <main id="main" tabIndex={-1} className="flex-1 px-3 pb-6 pt-1 md:px-6">
        <ImpersonationBanner />
        {authed && <TutorialBanner />}
        <div key={location.pathname} className="page-enter">
          <Outlet />
        </div>
      </main>

      <MenuModal open={menuOpen} onClose={() => setMenuOpen(false)} entries={entries} />
      <ToastHost />
    </div>
  );
}
