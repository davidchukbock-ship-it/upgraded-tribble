import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
import { NAV_ENTRIES } from './nav';
import { NavArt } from '../art';
import { useAuth } from '../store/auth';
import { Button, Panel } from '../ui';

export function MorePage() {
  const { t } = useTranslation();
  const role = useAuth((s) => s.user?.role);
  return (
    <Panel title={t('nav.more')} className="mx-auto max-w-md">
      <ul className="flex flex-col gap-2 pt-2">
        {[
          ...NAV_ENTRIES,
          ...(role === 'ADMIN' || role === 'OWNER'
            ? [{ to: '/admin', icon: 'admin' as const, label: 'nav.admin' }]
            : []),
        ].map((e) => (
          <li key={e.to}>
            <Link
              to={e.to}
              className="flex min-h-[44px] items-center gap-3 rounded-lg px-3 font-display font-bold hover:bg-black/25"
            >
              <NavArt name={e.icon} size={28} />
              {t(e.label)}
            </Link>
          </li>
        ))}
      </ul>
    </Panel>
  );
}

/** Титры: вся графика и музыка нарисованы и синтезируются кодом игры; сторонние — только шрифты. */
export function CreditsPage() {
  const { t } = useTranslation();
  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-6">
      <h1 className="font-display text-2xl font-bold text-gold-light">{t('credits.title')}</h1>
      <Panel title={t('credits.ownTitle')}>
        <p className="pt-2 text-sm">{t('credits.own')}</p>
      </Panel>
      <Panel title={t('credits.fontsTitle')}>
        <ul className="list-disc pl-5 pt-2 text-sm">
          <li>Cinzel — SIL Open Font License 1.1</li>
          <li>Inter — SIL Open Font License 1.1</li>
        </ul>
      </Panel>
    </div>
  );
}

export function HomePage() {
  const { t } = useTranslation();
  const authed = useAuth((s) => s.status === 'authenticated');
  return (
    <div className="mx-auto flex max-w-md flex-col items-center gap-6 pt-10 text-center">
      <h1 className="font-display text-3xl font-bold text-gold-light sm:text-4xl">
        {t('app.title')}
      </h1>
      <p>{t('app.tagline')}</p>
      <div className="flex flex-wrap justify-center gap-3">
        {authed ? (
          <Link to="/castle">
            <Button variant="gold">{t('nav.castle')}</Button>
          </Link>
        ) : (
          <>
            <Link to="/register">
              <Button variant="gold">{t('auth.register')}</Button>
            </Link>
            <Link to="/login">
              <Button>{t('auth.login')}</Button>
            </Link>
          </>
        )}
      </div>
    </div>
  );
}
