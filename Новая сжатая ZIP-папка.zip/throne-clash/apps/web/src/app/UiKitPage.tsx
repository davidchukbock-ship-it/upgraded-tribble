import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Icon, ICON_NAMES } from '../icons/Icon';
import { useClock } from '../store/clock';
import { useToasts } from '../store/toast';
import {
  Badge,
  Button,
  ConfirmDialog,
  ItemCard,
  Panel,
  ProgressBar,
  ResourceBar,
  ScrollModal,
  Tabs,
  TimerProgress,
  Tooltip,
} from '../ui';

export function UiKitPage() {
  const { t } = useTranslation();
  const push = useToasts((s) => s.push);
  const now = useClock((s) => s.now);
  const [modal, setModal] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const [tab, setTab] = useState('a');
  const [end] = useState(() => now() + 90_000);
  const [start] = useState(() => now());

  return (
    <div className="mx-auto flex max-w-4xl flex-col gap-8">
      <h1 className="font-display text-2xl font-bold text-gold-light">{t('uikit.title')}</h1>

      <ResourceBar
        items={[
          { key: 'gold', amount: 12_345, cap: 50_000 },
          { key: 'wood', amount: 999 },
          { key: 'stone', amount: 1_250_000 },
          { key: 'food', amount: 50_000, cap: 50_000 },
          { key: 'gems', amount: 50 },
        ]}
      />

      <Panel title={t('uikit.buttons')}>
        <div className="flex flex-wrap gap-3 pt-2">
          <Button>{t('uikit.primary')}</Button>
          <Button variant="danger">{t('uikit.danger')}</Button>
          <Button variant="gold">{t('uikit.gold')}</Button>
          <Button loading>{t('common.loading')}</Button>
          <Button disabled>{t('common.cancel')}</Button>
        </div>
      </Panel>

      <div className="grid gap-8 sm:grid-cols-2">
        <Panel title={t('uikit.woodPanel')}>
          <p className="pt-2">{t('uikit.modalText')}</p>
        </Panel>
        <Panel tone="parchment" title={t('uikit.parchmentPanel')}>
          <p className="pt-2">{t('uikit.modalText')}</p>
        </Panel>
      </div>

      <Panel title={t('uikit.progress')}>
        <div className="flex flex-col gap-3 pt-2">
          <ProgressBar
            label={t('common.level')}
            value={3}
            max={10}
            text={`3 ${t('common.of')} 10`}
          />
          <TimerProgress label={t('uikit.timer')} startsAtMs={start} endsAtMs={end} />
        </div>
      </Panel>

      <Panel title={t('uikit.modal')}>
        <div className="flex flex-wrap items-center gap-3 pt-2">
          <Button variant="gold" onClick={() => setModal(true)}>
            {t('uikit.openModal')}
          </Button>
          <Button variant="danger" onClick={() => setConfirm(true)}>
            {t('uikit.openConfirm')}
          </Button>
          <Tooltip content={t('uikit.tooltipText')}>
            <Button>{t('uikit.hover')}</Button>
          </Tooltip>
          <Button onClick={() => push(t('uikit.toastHello'), 'success')}>
            {t('uikit.showToast')}
          </Button>
        </div>
      </Panel>

      <Panel title={t('uikit.tabs')} tone="parchment">
        <Tabs
          tone="parchment"
          value={tab}
          onChange={setTab}
          items={[
            { id: 'a', label: t('nav.castle'), content: <p>{t('building.castle')}</p> },
            { id: 'b', label: t('nav.army'), content: <p>{t('unit.infantry')}</p> },
            { id: 'c', label: t('nav.hero'), content: <p>{t('nav.hero')}</p> },
          ]}
        />
      </Panel>

      <Panel title={t('uikit.items')}>
        <div className="flex flex-wrap gap-3 pt-2">
          <ItemCard icon="infantry" name={t('unit.infantry')} count={120} />
          <ItemCard icon="archer" name={t('unit.archer')} rarity="rare" />
          <ItemCard
            icon="cavalry"
            name={t('unit.cavalry')}
            rarity="epic"
            footer={<Badge>T3</Badge>}
          />
          <ItemCard
            icon="siege"
            name={t('unit.siege')}
            rarity="legendary"
            onClick={() => push(t('unit.siege'))}
          />
        </div>
        <div className="flex flex-wrap gap-2 pt-4" aria-label={t('uikit.badges')}>
          <Badge>1</Badge>
          <Badge tone="green">OK</Badge>
          <Badge tone="red">!</Badge>
          <Badge tone="stone">99+</Badge>
        </div>
        <ul className="flex flex-wrap gap-3 pt-4 text-gold-light" aria-hidden="true">
          {ICON_NAMES.map((n) => (
            <li key={n}>
              <Icon name={n} size={28} />
            </li>
          ))}
        </ul>
      </Panel>

      <ScrollModal open={modal} title={t('uikit.modal')} onClose={() => setModal(false)}>
        <p>{t('uikit.modalText')}</p>
      </ScrollModal>
      <ConfirmDialog
        open={confirm}
        title={t('uikit.confirmDialog')}
        message={t('uikit.confirmText')}
        onCancel={() => setConfirm(false)}
        onConfirm={() => setConfirm(false)}
      />
    </div>
  );
}
