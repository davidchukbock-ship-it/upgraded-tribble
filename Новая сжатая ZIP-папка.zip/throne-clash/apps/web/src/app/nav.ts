import type { NavArtName } from '../art/navicons';

export interface NavEntry {
  to: string;
  icon: NavArtName;
  label: string;
}

/** Все разделы игры: открываются из меню настроек (боковых панелей нет). */
export const NAV_ENTRIES: readonly NavEntry[] = [
  { to: '/castle', icon: 'castle', label: 'nav.castle' },
  { to: '/map', icon: 'map', label: 'nav.map' },
  { to: '/army', icon: 'army', label: 'nav.army' },
  { to: '/quests', icon: 'quests', label: 'nav.quests' },
  { to: '/shop', icon: 'shop', label: 'nav.shop' },
  { to: '/donate', icon: 'donate', label: 'nav.donate' },
  { to: '/play', icon: 'adventure', label: 'nav.adventure' },
  { to: '/reports', icon: 'reports', label: 'nav.reports' },
  { to: '/chat', icon: 'chat', label: 'nav.chat' },
  { to: '/notifications', icon: 'notifications', label: 'nav.notifications' },
  { to: '/academy', icon: 'academy', label: 'nav.academy' },
  { to: '/hero', icon: 'hero', label: 'nav.hero' },
  { to: '/chests', icon: 'chests', label: 'nav.chests' },
  { to: '/guild', icon: 'guild', label: 'nav.guild' },
  { to: '/leagues', icon: 'leagues', label: 'nav.leagues' },
  { to: '/profile', icon: 'profile', label: 'nav.profile' },
  { to: '/ui-kit', icon: 'uikit', label: 'nav.uikit' },
  { to: '/credits', icon: 'credits', label: 'credits.title' },
];
