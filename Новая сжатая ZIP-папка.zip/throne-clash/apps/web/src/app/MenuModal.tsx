import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
import { Icon } from '../icons/Icon';
import { NavArt } from '../art';
import { cn } from '../lib/cn';
import { LOCALES } from '@tc/shared';
import { setLocale } from '../lib/i18n';
import { LOCALE_NAMES, asLocale } from '../lib/locales';
import { useEra } from '../store/era';
import { useGfx, type GfxMode } from '../store/gfx';
import { ERA_IDS } from '../iso/era';
import { Button, ScrollModal, SoundSettings } from '../ui';
import { NAV_ENTRIES, type NavEntry } from './nav';

/** Единое меню игры: все разделы, звук, язык и облик мира — вместо боковых панелей. */
export function MenuModal({
  open,
  onClose,
  entries,
}: {
  open: boolean;
  onClose: () => void;
  entries: readonly NavEntry[];
}) {
  const { t, i18n } = useTranslation();
  const era = useEra((s) => s.era);
  const setEra = useEra((s) => s.set);
  const gfx = useGfx((s) => s.mode);
  const setGfx = useGfx((s) => s.set);
  const current = asLocale(i18n.language);
  return (
    <ScrollModal open={open} title={t('menu.title')} onClose={onClose}>
      <nav aria-label={t('menu.sections')} className="flex flex-col gap-4">
        <ul className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {entries.map((e) => (
            <li key={e.to}>
              <Link
                to={e.to}
                onClick={onClose}
                className="flex min-h-[48px] items-center gap-2 rounded-lg border border-gold-dark/60 bg-white/30 px-3 py-2 font-display text-sm font-bold hover:bg-white/50"
              >
                <NavArt name={e.icon} size={30} />
                <span className="min-w-0 leading-tight">{t(e.label)}</span>
              </Link>
            </li>
          ))}
        </ul>
      </nav>

      <section aria-label={t('menu.world')} className="mt-4">
        <h3 className="mb-2 font-display text-sm font-bold text-wood">{t('menu.world')}</h3>
        <div role="radiogroup" aria-label={t('menu.world')} className="flex gap-2">
          {ERA_IDS.map((id) => (
            <button
              key={id}
              type="button"
              role="radio"
              aria-checked={era === id}
              onClick={() => setEra(id)}
              className={cn(
                'min-h-[44px] flex-1 rounded-lg border-2 px-3 font-display text-sm font-bold',
                era === id ? 'border-gold-dark bg-gold text-ink' : 'border-stone/60 bg-black/10',
              )}
            >
              {t(`menu.${id}`)}
            </button>
          ))}
        </div>
      </section>

      <section aria-label={t('menu.graphics')} className="mt-4">
        <h3 className="mb-2 font-display text-sm font-bold text-wood">{t('menu.graphics')}</h3>
        <div role="radiogroup" aria-label={t('menu.graphics')} className="flex gap-2">
          {(['rich', 'classic'] as GfxMode[]).map((id) => (
            <button
              key={id}
              type="button"
              role="radio"
              aria-checked={gfx === id}
              onClick={() => setGfx(id)}
              className={cn(
                'min-h-[44px] flex-1 rounded-lg border-2 px-3 font-display text-sm font-bold',
                gfx === id ? 'border-gold-dark bg-gold text-ink' : 'border-stone/60 bg-black/10',
              )}
            >
              {t(`menu.gfx.${id}`)}
            </button>
          ))}
        </div>
        <p className="mt-1 text-xs opacity-75">{t('menu.gfx.hint')}</p>
      </section>

      <section aria-label={t('menu.sound')} className="mt-4">
        <h3 className="font-display text-sm font-bold text-wood">{t('menu.sound')}</h3>
        <SoundSettings />
      </section>

      <section aria-label={t('menu.language')} className="mt-4">
        <h3 className="font-display text-sm font-bold text-wood">{t('menu.language')}</h3>
        <div role="group" aria-label={t('menu.language')} className="mt-2 flex flex-wrap gap-2">
          {LOCALES.map((l) => (
            <Button
              key={l}
              variant={l === current ? 'gold' : 'primary'}
              aria-pressed={l === current}
              aria-label={`${t('common.language')}: ${l.toUpperCase()}`}
              onClick={() => l !== current && setLocale(l)}
            >
              {l === current ? <Icon name="globe" size={18} /> : null}
              {LOCALE_NAMES[l]}
            </Button>
          ))}
        </div>
      </section>
    </ScrollModal>
  );
}

export { NAV_ENTRIES };
