import { SKILL_KEYS, TECH_KEYS, UNIT_TIERS, UNIT_TYPES } from '@tc/shared';
import { MapCanvas } from '../features/map/MapCanvas';
import type { MapCellDto } from '@tc/shared';
import { BattleScene } from '../features/map/BattleScene';
import { ERA_IDS } from '../iso/era';
import { useEra } from '../store/era';
import { Art2Canvas } from '../art2/Art2Canvas';
import { renderFort } from '../art2/fort';
import { BattleArena } from '../art2/BattleArena';
import type { BattleSetup } from '../art2/battle';
import { AnimatedBuilding } from '../art2/AnimatedBuilding';
import { BUILDING_KINDS } from '../art2/buildings';
import { renderChibi, type ChibiClass, type Rarity } from '../art2/chibi';
import {
  renderBush,
  renderRock,
  renderTile,
  renderTree,
  type TileKind,
  type TreeKind,
} from '../art2/nature';
import { IsoScene } from '../features/castle/scene/IsoScene';
import type { BuildingLevels } from '@tc/shared';
import {
  ArtIcon,
  HeroArt,
  NPC_SPEC,
  NpcArt,
  UnitArt,
  type FigureAnim,
  type HeroGear,
  type IconName,
  type NpcName,
} from '../art';

const RES: IconName[] = [
  'gold',
  'wood',
  'stone',
  'food',
  'gems',
  'lock',
  'heart',
  'shield',
  'hammer',
  'siege',
];
const HERO_STEPS: HeroGear[] = [0, 1, 2, 3, 4, 5].map((r) => ({
  weapon: r,
  armor: r,
  relic: r,
  helmet: Math.min(3, Math.ceil(r / 2)),
}));
const LEVELS = (l: number): BuildingLevels => ({
  castle: l,
  barracks: l,
  farm: l,
  sawmill: l,
  quarry: l,
  goldmine: l,
  warehouse: l,
  forge: l,
  academy: l,
  walls: l,
  hospital: l,
  territory: l >= 16 ? 4 : l >= 8 ? 2 : 0,
  fishery: l,
  archertower: l,
  diamondmine: l,
  ballistatower: l,
  magetower: l,
  stormtower: l >= 16 ? l : 0,
});
const NO_RATES = { gold: 0, wood: 0, stone: 0, food: 0 };
/** Пример карты для витрины: волнистый рельеф, замки, лагери и точки ресурсов. */
const DEMO_MAP: MapCellDto[] = (() => {
  const n = 18;
  const out: MapCellDto[] = [];
  for (let y = 0; y < n; y++)
    for (let x = 0; x < n; x++) {
      const v = Math.sin(x * 0.55) + Math.cos(y * 0.5) + Math.sin((x + y) * 0.3);
      const terrain: MapCellDto['terrain'] =
        v > 1.5 ? 'mountain' : v > 0.6 ? 'forest' : v < -1.3 ? 'water' : 'plain';
      const base: MapCellDto = {
        x,
        y,
        terrain,
        kind: 'empty',
        level: 0,
        resource: null,
        castle: null,
        busyUntil: null,
        remaining: null,
      };
      const key = `${x},${y}`;
      const special: Record<string, Partial<MapCellDto>> = {
        '8,8': { castle: { nickname: 'Я', isMe: true, shielded: false }, terrain: 'plain' },
        '12,5': { castle: { nickname: 'Враг', isMe: false, shielded: true }, terrain: 'plain' },
        '5,11': { castle: { nickname: 'Сосед', isMe: false, shielded: false }, terrain: 'plain' },
        '10,10': { kind: 'camp', level: 3, terrain: 'plain' },
        '4,6': { kind: 'camp', level: 7, terrain: 'plain' },
        '14,13': { kind: 'camp', level: 12, terrain: 'plain' },
        '2,2': { kind: 'camp', level: 2, terrain: 'plain' },
        '6,8': { kind: 'resource', level: 2, resource: 'gold', remaining: 500, terrain: 'plain' },
        '9,12': { kind: 'resource', level: 3, resource: 'wood', remaining: 500, terrain: 'plain' },
        '12,9': { kind: 'resource', level: 1, resource: 'stone', remaining: 500, terrain: 'plain' },
        '7,4': { kind: 'resource', level: 4, resource: 'food', remaining: 0, terrain: 'plain' },
      };
      out.push({ ...base, ...(special[key] ?? {}) });
    }
  return out;
})();
const DEMO_BATTLE: BattleSetup = {
  winner: 'left',
  seed: 3,
  left: [
    { cls: 'knight', rarity: 'legendary', tier: 5 },
    { cls: 'knight', rarity: 'rare', tier: 3 },
    { cls: 'archer', rarity: 'epic', tier: 4 },
    { cls: 'mage', rarity: 'rare', tier: 3 },
  ],
  right: [
    { cls: 'rogue', tier: 2 },
    { cls: 'peasant' },
    { cls: 'rogue', tier: 1 },
    { cls: 'archer', tier: 2 },
  ],
};
const FRAMES = [0, 1, 2, 3, 4, 5, 6, 7];

function Row({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section aria-label={title} className="flex flex-col gap-2">
      <h2 className="font-display text-lg text-gold-light">{title}</h2>
      <div className="flex flex-wrap items-end gap-4">{children}</div>
    </section>
  );
}

/** Витрина векторной графики: все значки, войска по уровням, экипировка героя, жители и кадры анимаций. */
export function ArtGalleryPage() {
  // Задел под смену эпохи (D-63): /art?era=modern перекрашивает материалы изометрической сцены
  const era = new URLSearchParams(window.location.search).get('era');
  const bt = new URLSearchParams(window.location.search).get('bt');
  useEra.getState().set(ERA_IDS.find((e) => e === era) ?? 'medieval');
  const strips: Array<{
    label: string;
    anim: FigureAnim;
    period: number;
    node: (i: number) => React.ReactNode;
  }> = [
    {
      label: 'attack: infantry T4',
      anim: 'attack',
      period: 1400,
      node: () => <UnitArt type="infantry" tier={4} size={96} anim="attack" />,
    },
    {
      label: 'attack: hero',
      anim: 'attack',
      period: 1400,
      node: () => <HeroArt gear={HERO_STEPS[5]!} size={96} anim="attack" />,
    },
    {
      label: 'walk: archer T3',
      anim: 'walk',
      period: 900,
      node: () => <UnitArt type="archer" tier={3} size={96} anim="walk" />,
    },
    {
      label: 'walk: cavalry T5',
      anim: 'walk',
      period: 900,
      node: () => <UnitArt type="cavalry" tier={5} size={80} anim="walk" />,
    },
    {
      label: 'attack: trebuchet T4',
      anim: 'attack',
      period: 1800,
      node: () => <UnitArt type="siege" tier={4} size={80} anim="attack" />,
    },
    {
      label: 'cheer: king',
      anim: 'cheer',
      period: 900,
      node: () => <NpcArt name="king" size={96} anim="cheer" />,
    },
  ];
  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-8" data-testid="art-gallery">
      <h1 className="font-display text-2xl font-bold text-gold-light">Art</h1>

      <Row title="art2: fort">
        <div id="g-art2-fort">
          <Art2Canvas make={() => renderFort({ seed: 7 })} label="fort" size={480} />
        </div>
      </Row>

      <Row title="art2: battle">
        <div id="g-art2-battle">
          <BattleArena
            setup={DEMO_BATTLE}
            label="battle"
            width={640}
            at={bt === null ? undefined : Number(bt)}
          />
        </div>
      </Row>

      <Row title="art2: animated buildings">
        <div id="g-art2-buildings" className="flex flex-wrap gap-2">
          {BUILDING_KINDS.map((k) => (
            <AnimatedBuilding key={k} kind={k} size={300} />
          ))}
        </div>
      </Row>

      <Row title="art2: trees">
        <div id="g-art2-nature" className="flex flex-wrap items-end gap-2">
          {(['oak', 'pine', 'birch', 'autumn'] as TreeKind[]).map((k) => (
            <Art2Canvas key={k} make={() => renderTree(k, 3)} label={k} size={120} />
          ))}
          <Art2Canvas make={() => renderBush(2, true)} label="bush" size={64} />
          <Art2Canvas make={() => renderRock(4)} label="rock" size={64} />
          {(['grass', 'road', 'water', 'sand', 'snow'] as TileKind[]).map((k) => (
            <Art2Canvas key={k} make={() => renderTile(k, 5)} label={k} size={96} />
          ))}
        </div>
      </Row>

      <Row title="art2: chibi">
        <div id="g-art2-chibi" className="flex flex-wrap items-end gap-2">
          {(
            [
              ['knight', 'legendary'],
              ['archer', 'epic'],
              ['mage', 'rare'],
              ['king', 'legendary'],
              ['rogue', 'common'],
              ['peasant', 'common'],
              ['guard', 'common'],
              ['captain', 'rare'],
              ['smith', 'common'],
              ['merchant', 'common'],
              ['healer', 'rare'],
              ['elder', 'epic'],
              ['scholar', 'common'],
            ] as Array<[ChibiClass, Rarity]>
          ).map(([c, rar], i) => (
            <Art2Canvas
              key={c}
              make={() => renderChibi({ cls: c, rarity: rar, tier: 1 + i, seed: i + 2 })}
              label={c}
              size={150}
            />
          ))}
        </div>
      </Row>

      <div id="g-scene" className="flex flex-col gap-6">
        {[0, 8, 16].map((l) => (
          <div key={l} id={`scene-${l}`} className="overflow-hidden rounded-xl">
            <IsoScene
              key={era}
              castle={{
                tasks:
                  l === 8
                    ? [
                        {
                          id: 'x',
                          key: 'forge',
                          toLevel: 9,
                          startedAt: '2026-01-01T00:00:00Z',
                          finishesAt: '2099-01-01T00:00:00Z',
                          speedupGems: 1,
                          refund: NO_RATES,
                        },
                      ]
                    : [],
                ratesPerHour: NO_RATES,
              }}
              levels={l === 0 ? {} : LEVELS(l)}
              now={0}
              onOpen={() => undefined}
            />
          </div>
        ))}
      </div>

      <div id="g-battle" className="flex flex-col gap-4">
        <BattleScene
          attacker={{ infantry_4: 120, archer_3: 60, cavalry_5: 30 }}
          defender={null}
          campLevel={10}
          attackerWon
        />
        <BattleScene
          attacker={{ infantry_2: 200, siege_2: 8 }}
          defender={{ infantry_5: 90, archer_4: 40, cavalry_3: 10 }}
          campLevel={null}
          attackerWon={false}
        />
      </div>

      <div id="g-map" className="overflow-hidden rounded-xl">
        <MapCanvas cells={DEMO_MAP} size={18} />
      </div>

      <div id="g-icons" className="flex flex-wrap items-center gap-4">
        {[...RES, ...SKILL_KEYS, ...TECH_KEYS].map((n) => (
          <span key={n} className="flex flex-col items-center gap-1 text-xs">
            <ArtIcon name={n} size={44} />
            {n}
          </span>
        ))}
      </div>

      <div id="g-tiers" className="flex flex-col gap-3">
        {UNIT_TYPES.map((u) => (
          <Row key={u} title={`${u}: T1–T5`}>
            {UNIT_TIERS.map((tier) => (
              <span key={tier} className="flex flex-col items-center gap-1 text-xs">
                <UnitArt type={u} tier={tier} size={96} />T{tier}
              </span>
            ))}
          </Row>
        ))}
      </div>

      <div id="g-hero">
        <Row title="Hero: gear rarity 0–5 (weapon, armor, relic aura, helmet by level)">
          {HERO_STEPS.map((g, r) => (
            <span key={r} className="flex flex-col items-center gap-1 text-xs">
              <HeroArt gear={g} size={110} />
              rarity {r}
            </span>
          ))}
        </Row>
      </div>

      <div id="g-npc">
        <Row title="NPC and enemies">
          {(Object.keys(NPC_SPEC) as NpcName[]).map((n) => (
            <span key={n} className="flex flex-col items-center gap-1 text-xs">
              <NpcArt name={n} size={92} />
              {n}
            </span>
          ))}
        </Row>
      </div>

      <div id="g-anim" className="flex flex-col gap-3">
        {strips.map((s) => (
          <Row key={s.label} title={`${s.label} (frames)`}>
            {FRAMES.map((i) => (
              <span key={i} data-frame={i} data-period={s.period} className="inline-flex">
                {s.node(i)}
              </span>
            ))}
          </Row>
        ))}
      </div>
    </div>
  );
}
