import type { ComponentType } from 'react';
import {
  createBrowserRouter,
  createMemoryRouter,
  Navigate,
  type RouteObject,
} from 'react-router-dom';
import { AppShell } from './AppShell';
import { LoginPage, RegisterPage } from '../features/auth/AuthPages';
import { ProfilePage } from '../features/auth/ProfilePage';
import { CastlePage } from '../features/castle/CastlePage';
import { RequireAuth } from '../features/auth/RequireAuth';
import { CreditsPage, HomePage, MorePage } from './pages';

/**
 * Тяжёлые и редкие экраны грузятся отдельными файлами при первом заходе (D-54): стартовая загрузка —
 * оболочка, вход и замок. Ошибка загрузки файла (сеть) обрабатывается обычным обработчиком ошибок маршрута.
 */
const screen = <K extends string>(
  load: () => Promise<Record<K, ComponentType>>,
  name: K,
): Pick<RouteObject, 'lazy'> => ({
  lazy: async () => ({ Component: (await load())[name] }),
});

export const routes: RouteObject[] = [
  // Режим бога вне игровой оболочки: свой вид и без ссылок из меню
  { path: 'god', ...screen(() => import('../features/god/GodPage'), 'GodPage') },
  {
    element: <AppShell />,
    children: [
      { index: true, element: <HomePage /> },
      { path: 'login', element: <LoginPage /> },
      { path: 'register', element: <RegisterPage /> },
      { path: 'ui-kit', ...screen(() => import('./UiKitPage'), 'UiKitPage') },
      { path: 'art', ...screen(() => import('./ArtGalleryPage'), 'ArtGalleryPage') },
      { path: 'credits', element: <CreditsPage /> },
      {
        // Игровые экраны требуют входа
        element: <RequireAuth />,
        children: [
          { path: 'admin', ...screen(() => import('../features/admin/AdminPage'), 'AdminPage') },
          {
            path: 'quests',
            ...screen(() => import('../features/progress/QuestsPage'), 'QuestsPage'),
          },
          {
            path: 'chests',
            ...screen(() => import('../features/progress/ChestsPage'), 'ChestsPage'),
          },
          { path: 'shop', ...screen(() => import('../features/progress/ShopPage'), 'ShopPage') },
          {
            path: 'play',
            ...screen(() => import('../features/adventure/AdventurePage'), 'AdventurePage'),
          },
          {
            path: 'donate',
            ...screen(() => import('../features/progress/DonatePage'), 'DonatePage'),
          },
          {
            path: 'leagues',
            ...screen(() => import('../features/progress/LeaguesPage'), 'LeaguesPage'),
          },
          { path: 'castle', element: <CastlePage /> },
          { path: 'map', ...screen(() => import('../features/map/MapPage'), 'MapPage') },
          { path: 'guild', ...screen(() => import('../features/social/GuildPage'), 'GuildPage') },
          { path: 'chat', ...screen(() => import('../features/social/ChatPage'), 'ChatPage') },
          {
            path: 'notifications',
            ...screen(() => import('../features/social/NotificationsPage'), 'NotificationsPage'),
          },
          {
            path: 'reports',
            ...screen(() => import('../features/map/ReportsPage'), 'ReportsPage'),
          },
          {
            path: 'reports/:id',
            ...screen(() => import('../features/map/ReportsPage'), 'ReportsPage'),
          },
          { path: 'army', ...screen(() => import('../features/realm/ArmyPage'), 'ArmyPage') },
          {
            path: 'academy',
            ...screen(() => import('../features/realm/AcademyPage'), 'AcademyPage'),
          },
          { path: 'hero', ...screen(() => import('../features/realm/HeroPage'), 'HeroPage') },
          { path: 'profile', element: <ProfilePage /> },
          { path: 'more', element: <MorePage /> },
        ],
      },
      { path: '*', element: <Navigate to="/" replace /> },
    ],
  },
];

export const createRouter = () => createBrowserRouter(routes);
export const createTestRouter = (initial: string) =>
  createMemoryRouter(routes, { initialEntries: [initial] });
