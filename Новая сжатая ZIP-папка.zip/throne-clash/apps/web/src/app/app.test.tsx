import { cleanup, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { ICON_NAMES } from '../icons/Icon';
import { initI18n, setLocale } from '../lib/i18n';
import { useAuth } from '../store/auth';
import { installFakeApi } from '../test-utils/fake-api';
import { renderApp, resetAuth, signIn } from '../test-utils/render';

beforeAll(async () => {
  await initI18n('ru');
});
beforeEach(() => {
  signIn();
  installFakeApi({});
});
afterEach(() => {
  resetAuth();
  vi.unstubAllGlobals();
});

describe('приложение', () => {
  it('открывает экран и подсвечивает пункт меню', async () => {
    renderApp('/quests');
    expect(await screen.findByRole('heading', { level: 1, name: 'Задания' })).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: 'Настройки и меню' }));
    const menu = await screen.findByRole('dialog');
    expect(within(menu).getByRole('link', { name: /^Задания/ })).toHaveAttribute('href', '/quests');
    expect(within(menu).getByRole('link', { name: 'Донат' })).toHaveAttribute('href', '/donate');
    expect(await screen.findByRole('heading', { level: 1, name: 'Задания' })).toBeInTheDocument();
  });

  it('неизвестный адрес ведёт на главную', () => {
    renderApp('/nope');
    expect(screen.getByRole('heading', { level: 1, name: 'Битва за трон' })).toBeInTheDocument();
  });

  it('есть ссылка «к содержимому» и главный ориентир', () => {
    renderApp('/castle');
    expect(screen.getByRole('link', { name: 'К содержимому' })).toHaveAttribute('href', '#main');
    expect(screen.getByRole('main')).toBeInTheDocument();
  });

  it('переключает язык на английский', async () => {
    renderApp('/castle');
    await userEvent.click(screen.getByRole('button', { name: 'Настройки и меню' }));
    await userEvent.click(await screen.findByRole('button', { name: /Язык: EN/ }));
    expect(await screen.findAllByText('Castle')).not.toHaveLength(0);
    expect(document.documentElement.lang).toBe('en');
    cleanup(); // размонтировать до смены языка: иначе перерисовка пройдёт вне act
    setLocale('ru');
  });

  it('переключает язык на украинский', async () => {
    renderApp('/castle');
    await userEvent.click(screen.getByRole('button', { name: 'Настройки и меню' }));
    await userEvent.click(await screen.findByRole('button', { name: /Язык: UK/ }));
    expect(await screen.findAllByText('Мапа')).not.toHaveLength(0);
    expect(document.documentElement.lang).toBe('uk');
    cleanup();
    setLocale('ru');
  });

  it('витрина UI открывается и содержит все иконки', async () => {
    renderApp('/ui-kit');
    expect(await screen.findByRole('heading', { level: 1 })).toBeInTheDocument();
    expect(ICON_NAMES.length).toBeGreaterThan(30);
  });

  it('все ключи из ru.json есть в en.json и uk.json', async () => {
    const [ru, en, uk] = await Promise.all([
      import('../locales/ru.json'),
      import('../locales/en.json'),
      import('../locales/uk.json'),
    ]);
    const keys = (o: object, p = ''): string[] =>
      Object.entries(o).flatMap(([k, v]) =>
        typeof v === 'object' && v ? keys(v, `${p}${k}.`) : [`${p}${k}`],
      );
    expect(keys(en.default).sort()).toEqual(keys(ru.default).sort());
    expect(keys(uk.default).sort()).toEqual(keys(ru.default).sort());
  });
});

describe('закрытые экраны', () => {
  it('без входа /castle ведёт на /login и запоминает адрес', () => {
    useAuth.getState().clear();
    const { router } = renderApp('/castle');
    expect(router.state.location.pathname).toBe('/login');
    expect(router.state.location.state).toEqual({ from: '/castle' });
    expect(screen.getByRole('heading', { name: 'Вход' })).toBeInTheDocument();
  });

  it('пока сессия восстанавливается — заставка, а не редирект', () => {
    useAuth.setState({ status: 'unknown', accessToken: null, user: null });
    const { router } = renderApp('/castle');
    expect(router.state.location.pathname).toBe('/castle');
    expect(screen.getByText(/Загрузка/)).toBeInTheDocument();
  });

  it.each(['/login', '/register'])('вошедшего с %s возвращает в замок', (path) => {
    const { router } = renderApp(path);
    expect(router.state.location.pathname).toBe('/castle');
  });

  it('анонимный видит вход и регистрацию вместо игрового меню', () => {
    useAuth.getState().clear();
    renderApp('/');
    expect(screen.getAllByRole('link', { name: 'Войти' }).length).toBeGreaterThan(0);
    expect(screen.queryByRole('link', { name: 'Карта' })).toBeNull();
  });
});

describe('меню вместо боковых панелей', () => {
  it('боковой навигации нет; облик мира переключается в меню', async () => {
    renderApp('/quests');
    await screen.findByRole('heading', { level: 1, name: 'Задания' });
    expect(screen.queryByRole('navigation', { name: 'main' })).toBeNull();
    await userEvent.click(screen.getByRole('button', { name: 'Настройки и меню' }));
    const menu = await screen.findByRole('dialog');
    await userEvent.click(within(menu).getByRole('radio', { name: 'Современность' }));
    expect(within(menu).getByRole('radio', { name: 'Современность' })).toBeChecked();
    await userEvent.click(within(menu).getByRole('radio', { name: 'Средневековье' }));
  });

  it('ресурсы и кнопка доната всегда сверху', async () => {
    renderApp('/quests');
    expect(await screen.findByLabelText(/Золото:/)).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Пополнить кристаллы' })).toHaveAttribute(
      'href',
      '/donate',
    );
  });
});
