import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { cleanup, render } from '@testing-library/react';
import { RouterProvider } from 'react-router-dom';
import { createTestRouter } from '../app/router';
import { useAuth } from '../store/auth';
import { makeAuth } from './fake-api';

/** Рендерит приложение на нужном адресе с чистым QueryClient (без повторов запросов). */
export function renderApp(path: string) {
  const router = createTestRouter(path);
  const client = new QueryClient({
    defaultOptions: { queries: { retry: false }, mutations: { retry: false } },
  });
  const utils = render(
    <QueryClientProvider client={client}>
      <RouterProvider router={router} future={{ v7_startTransition: true }} />
    </QueryClientProvider>,
  );
  return { ...utils, router };
}

export const signIn = (over: Parameters<typeof makeAuth>[0] = {}): void =>
  useAuth.getState().setSession(makeAuth(over));

/** Сначала размонтирует дерево, потом чистит стор: иначе сброс сессии перерисует живые компоненты вне act. */
export function resetAuth(): void {
  cleanup();
  useAuth.getState().clear();
}
