import type { WsClientMessage, WsServerMessage } from '@tc/shared';

/** Поддельный WebSocket для тестов: ничего не подключает, позволяет «принять» сообщение от сервера. */
export class FakeSocket {
  static instances: FakeSocket[] = [];
  static reset(): void {
    FakeSocket.instances = [];
  }
  static get last(): FakeSocket {
    const s = FakeSocket.instances[FakeSocket.instances.length - 1];
    if (!s) throw new Error('сокет ещё не создан');
    return s;
  }

  readyState = 0;
  sent: WsClientMessage[] = [];
  onopen: (() => void) | null = null;
  onmessage: ((ev: MessageEvent) => void) | null = null;
  onclose: (() => void) | null = null;
  onerror: (() => void) | null = null;

  constructor(readonly url: string) {
    FakeSocket.instances.push(this);
  }

  send(data: string): void {
    this.sent.push(JSON.parse(data) as WsClientMessage);
  }

  close(): void {
    this.readyState = 3;
    this.onclose?.();
  }

  /** Сервер принял соединение. */
  open(): void {
    this.readyState = 1;
    this.onopen?.();
  }

  /** Сообщение от сервера. */
  receive(msg: WsServerMessage): void {
    this.onmessage?.({ data: JSON.stringify(msg) } as MessageEvent);
  }
}

export const asWebSocket = FakeSocket as unknown as typeof WebSocket;
