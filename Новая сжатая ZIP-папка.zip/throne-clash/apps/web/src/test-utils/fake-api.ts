import { vi } from 'vitest';
import type { AuthResponse, UserDto } from '@tc/shared';

export interface RecordedCall {
  method: string;
  path: string;
  headers: Record<string, string>;
  body: unknown;
}

type Handler = (
  call: RecordedCall,
) => Response | Promise<Response> | { status: number; body?: unknown };

export const json = (
  status: number,
  body: unknown,
  headers: Record<string, string> = {},
): Response =>
  new Response(status === 204 ? null : JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json', ...headers },
  });

export const apiError = (status: number, code: string, details?: unknown) =>
  json(status, { error: { code, message: code, details }, requestId: 'req-1' });

export const makeUser = (over: Partial<UserDto> = {}): UserDto => ({
  id: 'u1',
  nickname: 'Артур',
  role: 'PLAYER',
  isGuest: false,
  email: 'hero@example.com',
  language: 'ru',
  crest: 'lion',
  createdAt: '2026-01-01T00:00:00.000Z',
  ...over,
});

export const makeAuth = (over: Partial<AuthResponse> = {}): AuthResponse => ({
  accessToken: 'access-1',
  expiresIn: 900,
  user: makeUser(),
  serverTime: '2026-01-01T00:00:00.000Z',
  ...over,
});

/**
 * Подменяет fetch: маршруты "METHOD /path" → обработчик. Все вызовы записываются.
 * Неописанный маршрут роняет тест — молчаливых запросов в никуда не бывает.
 */
export function installFakeApi(routes: Record<string, Handler>): { calls: RecordedCall[] } {
  const calls: RecordedCall[] = [];
  // Фоновые запросы оболочки (полоса ресурсов). Не попадают в calls, пока тест не описал их сам.
  const background: Record<string, Handler> = {
    'GET /api/castle': () => json(200, makeCastle()),
    'GET /api/notifications?page=1&pageSize=20': () =>
      json(200, { items: [], page: 1, pageSize: 20, total: 0, unread: 0 }),
    'GET /api/quests': () => json(200, makeQuests()),
    'GET /api/inventory': () => json(200, makeInventory()),
    'GET /api/map/overview': () => json(200, { step: 5, cols: 2, terrain: 'pfmw' }),
  };
  vi.stubGlobal(
    'fetch',
    vi.fn(async (input: string, init?: RequestInit) => {
      const headers = (init?.headers ?? {}) as Record<string, string>;
      const call: RecordedCall = {
        method: init?.method ?? 'GET',
        path: input,
        headers,
        body: typeof init?.body === 'string' ? (JSON.parse(init.body) as unknown) : undefined,
      };
      const id = `${call.method} ${call.path}`;
      const own = routes[id];
      const handler = own ?? background[id];
      if (own) calls.push(call);
      if (!handler) throw new Error(`Unexpected request: ${id}`);
      const res = await handler(call);
      return res instanceof Response ? res : json(res.status, res.body);
    }),
  );
  return { calls };
}

// ── Задания, сундуки, магазин, лиги ─────────────────────────────────────────

export function makeInventory(over: Partial<InventoryDto> = {}): InventoryDto {
  return {
    chests: { wooden: 0, silver: 0, gold: 0 },
    boosters: { boost_5m: 0, boost_1h: 0, boost_8h: 0 },
    crests: [],
    ...over,
  };
}

const rewardOf = (r: QuestReward): RewardDto => ({
  resources: r.resources ? { gold: 0, wood: 0, stone: 0, food: 0, ...r.resources } : null,
  gems: r.gems ?? 0,
  chest: r.chest ?? null,
});

/** Задания нового игрока: ничего не выполнено, вход не получен. */
export function makeQuests(over: Partial<QuestsDto> = {}): QuestsDto {
  const dto = (q: QuestDef): QuestDto => ({
    id: q.id,
    kind: q.kind,
    metric: q.metric,
    target: q.target,
    progress: 0,
    reward: rewardOf(q.reward),
    claimed: false,
    claimable: false,
    route: q.route ?? null,
  });
  return {
    tutorial: TUTORIAL.map(dto),
    daily: DAILY.map(dto),
    achievements: ACHIEVEMENTS.map(dto),
    login: { day: 1, claimed: false, rewards: LOGIN_REWARDS.map(rewardOf) },
    dailyResetAt: '2099-01-01T00:00:00.000Z',
    claimable: 1,
    ...over,
  };
}

// ── Замок ───────────────────────────────────────────────────────────────────

import {
  ACHIEVEMENTS,
  DAILY,
  LOGIN_REWARDS,
  TUTORIAL,
  BUILDING_KEYS,
  MAX_HERO_LEVEL,
  MAX_SKILL_LEVEL,
  TECHS,
  TECH_KEYS,
  academyLevelFor,
  buildSeconds,
  buildingCost,
  cityDto,
  heroTrainCost,
  missingRequirements,
  heroXpToNext,
  techCost,
  techSeconds,
  type ArmyDto,
  type BuildingKey,
  type CastleDto,
  type HeroDto,
  type InventoryDto,
  type QuestDef,
  type QuestDto,
  type QuestReward,
  type QuestsDto,
  type RewardDto,
  type ResearchDto,
} from '@tc/shared';

const START_LEVELS: Partial<Record<BuildingKey, number>> = {
  castle: 1,
  farm: 1,
  sawmill: 1,
  quarry: 1,
  goldmine: 1,
  warehouse: 1,
};

export function makeArmy(over: Partial<ArmyDto> = {}): ArmyDto {
  return {
    units: [],
    count: 0,
    queued: 0,
    cap: 0,
    upkeepPerHour: 0,
    maxTier: 0,
    queue: [],
    queueMax: 4,
    marching: 0,
    woundedRoom: 0,
    ...over,
  };
}

/** Исследования нового игрока: Академии нет, все технологии на 0. */
export function makeResearch(over: Partial<ResearchDto> = {}, academy = 0): ResearchDto {
  return {
    academyLevel: academy,
    queueMax: 2,
    queue: [],
    techs: TECH_KEYS.map((key) => ({
      key,
      branch: TECHS[key].branch,
      level: 0,
      nextLevel: 1,
      cost: techCost(key, 1),
      seconds: techSeconds(key, 1),
      academyRequired: academyLevelFor(1),
      blocked: academy < academyLevelFor(1) ? ('academy_level' as const) : null,
    })),
    ...over,
  };
}

export function makeHero(over: Partial<HeroDto> = {}): HeroDto {
  return {
    level: 1,
    maxLevel: MAX_HERO_LEVEL,
    xp: 0,
    xpToNext: heroXpToNext(1),
    skillPoints: 1,
    skills: { combat: 0, defense: 0, economy: 0 },
    maxSkill: MAX_SKILL_LEVEL,
    items: [],
    bonuses: { attack: 0, defense: 0, production: 0 },
    train: { cost: heroTrainCost(1), xp: 60 },
    ...over,
  };
}
/** Замок нового игрока (как отдаёт сервер сразу после регистрации). Поля можно переопределить. */
export function makeCastle(over: Partial<CastleDto> = {}): CastleDto {
  const levels = START_LEVELS;
  return {
    serverTime: new Date().toISOString(),
    worldSpeed: 1,
    resources: { gold: 1000, wood: 1000, stone: 1000, food: 1000 },
    caps: { gold: 3000, wood: 3000, stone: 3000, food: 3000 },
    ratesPerHour: { gold: 300, wood: 400, stone: 350, food: 400 },
    gems: 50,
    shieldUntil: null,
    slots: { total: 1, used: 0, extraUnlocked: false, canUnlock: true, unlockCostGems: 250 },
    buildings: BUILDING_KEYS.map((key) => {
      const level = levels[key] ?? 0;
      const next = level + 1;
      const castleLevel = levels.castle ?? 1;
      const missing = level === 0 ? missingRequirements(key, levels, castleLevel) : [];
      return {
        key,
        level,
        nextLevel: next,
        cost: buildingCost(key, next),
        seconds: buildSeconds(key, next, castleLevel),
        blocked:
          missing.length > 0
            ? ('requires' as const)
            : key !== 'castle' && level >= castleLevel
              ? ('castle_level' as const)
              : null,
        missing,
      };
    }),
    tasks: [],
    army: makeArmy(),
    research: makeResearch(),
    hero: makeHero(),
    position: { x: 50, y: 50 },
    marches: [],
    marchesMax: 5,
    power: 500,
    city: cityDto([], 1),
    ...over,
  };
}
