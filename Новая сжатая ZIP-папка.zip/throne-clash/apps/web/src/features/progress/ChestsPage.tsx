import { useQuery } from '@tanstack/react-query';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  BOOSTER_KEYS,
  CHEST_KINDS,
  OUTCOME_ORDER,
  parseUnitId,
  type BoosterKey,
  type ChestKind,
  type ChestOpenDto,
} from '@tc/shared';
import { Icon } from '../../icons/Icon';
import { formatDurationT } from '../../lib/duration';
import { useToasts } from '../../store/toast';
import { Badge, Button, Panel, ScrollModal } from '../../ui';
import { errorMessage } from '../auth/errors';
import { useLiveCastle } from '../castle/useCastle';
import { chestApi } from './api';
import { ChestRewardText } from './RewardView';
import { useCastleResultMutation, useInventory } from './useProgress';

const BOOST_SECONDS: Record<BoosterKey, number> = {
  boost_5m: 300,
  boost_1h: 3600,
  boost_8h: 28_800,
};

interface Target {
  target: 'build' | 'train' | 'research';
  taskId: string;
  label: string;
}

export function ChestsPage() {
  const { t } = useTranslation();
  const push = useToasts((s) => s.push);
  const inv = useInventory();
  const odds = useQuery({
    queryKey: ['chests', 'odds'],
    queryFn: chestApi.odds,
    staleTime: 600_000,
  });
  const { castle } = useLiveCastle();
  const [opened, setOpened] = useState<ChestOpenDto | null>(null);
  const [boosting, setBoosting] = useState<BoosterKey | null>(null);
  const open = useCastleResultMutation(chestApi.open);
  const boost = useCastleResultMutation(chestApi.useBooster);
  const onError = (err: unknown) => push(errorMessage(t, err), 'error');

  if (inv.isPending)
    return (
      <p role="status" className="pt-8 text-center font-display text-lg">
        {t('common.loading')}
      </p>
    );
  if (inv.isError || !inv.data)
    return (
      <Panel title={t('nav.chests')} className="mx-auto max-w-md text-center">
        <p className="pt-2">{t('errors.ERR_NETWORK')}</p>
        <Button className="mt-3" onClick={() => void inv.refetch()}>
          {t('common.retry')}
        </Button>
      </Panel>
    );
  const items = inv.data;

  // Куда можно применить ускоритель: постройки, а в цепочках — идущая первой
  const targets: Target[] = [];
  if (castle) {
    for (const b of castle.tasks)
      targets.push({
        target: 'build',
        taskId: b.id,
        label: `${t(`building.${b.key}`)} → ${b.toLevel}`,
      });
    const train = castle.army.queue[0];
    if (train) {
      const u = parseUnitId(train.unit);
      targets.push({
        target: 'train',
        taskId: train.id,
        label: `${u ? `${t(`unit.${u.type}`)} T${u.tier}` : train.unit} × ${train.count}`,
      });
    }
    const research = castle.research.queue[0];
    if (research)
      targets.push({
        target: 'research',
        taskId: research.id,
        label: `${t(`tech.${research.tech}`)} → ${research.toLevel}`,
      });
  }

  return (
    <div className="mx-auto flex max-w-4xl flex-col gap-6">
      <h1 className="font-display text-2xl font-bold text-gold-light">{t('nav.chests')}</h1>

      <Panel title={t('chest.title')}>
        <ul className="grid gap-3 pt-2 sm:grid-cols-3">
          {CHEST_KINDS.map((kind: ChestKind) => {
            const n = items.chests[kind];
            return (
              <li
                key={kind}
                className="flex flex-col items-center gap-2 rounded-lg bg-black/25 p-4"
              >
                <Icon name="chest" size={40} />
                <p className="font-display font-bold">{t(`chest.kind.${kind}`)}</p>
                <Badge tone={n > 0 ? 'gold' : 'stone'}>×{n}</Badge>
                <Button
                  variant="gold"
                  disabled={n === 0 || open.isPending}
                  onClick={() =>
                    open.mutate(kind, {
                      onSuccess: (res) => setOpened(res),
                      onError,
                    })
                  }
                  aria-label={`${t('chest.open')}: ${t(`chest.kind.${kind}`)}`}
                >
                  {t('chest.open')}
                </Button>
              </li>
            );
          })}
        </ul>
        <p className="pt-3 text-sm">{t('chest.hint')}</p>
      </Panel>

      <Panel title={t('booster.title')}>
        <ul className="grid gap-3 pt-2 sm:grid-cols-3">
          {BOOSTER_KEYS.map((key) => {
            const n = items.boosters[key];
            return (
              <li key={key} className="flex flex-col items-center gap-2 rounded-lg bg-black/25 p-4">
                <Icon name="clock" size={32} />
                <p className="font-display font-bold">{t(`booster.${key}`)}</p>
                <Badge tone={n > 0 ? 'gold' : 'stone'}>×{n}</Badge>
                <Button
                  disabled={n === 0}
                  onClick={() => setBoosting(key)}
                  aria-label={`${t('booster.use')}: ${t(`booster.${key}`)}`}
                >
                  {t('booster.use')}
                </Button>
              </li>
            );
          })}
        </ul>
      </Panel>

      <Panel tone="parchment" title={t('chest.odds')}>
        <div
          className="overflow-x-auto pt-2"
          role="region"
          tabIndex={0}
          aria-label={t('chest.odds')}
        >
          <table className="w-full min-w-[420px] text-left text-sm">
            <caption className="sr-only">{t('chest.odds')}</caption>
            <thead>
              <tr className="border-b-2 border-stone">
                <th scope="col" className="py-2 pr-3">
                  {t('chest.reward')}
                </th>
                {CHEST_KINDS.map((k) => (
                  <th key={k} scope="col" className="px-2 py-2 text-right">
                    {t(`chest.kind.${k}`)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {OUTCOME_ORDER.map((o) => (
                <tr key={o} className="border-b border-stone/40">
                  <th scope="row" className="py-2 pr-3 font-semibold">
                    {t(`chest.outcome.${o}`)}
                  </th>
                  {CHEST_KINDS.map((k) => (
                    <td key={k} className="px-2 py-2 text-right tabular-nums">
                      {odds.data?.find((x) => x.kind === k)?.odds[o] ?? '—'}%
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="pt-2 text-sm">{t('chest.oddsNote')}</p>
      </Panel>

      <ScrollModal
        open={opened !== null}
        title={t('chest.opened')}
        onClose={() => setOpened(null)}
        footer={<Button onClick={() => setOpened(null)}>{t('common.close')}</Button>}
      >
        {opened && (
          <div className="flex flex-col items-center gap-3 py-2 text-center" role="status">
            <span className="pop-in">
              <Icon name="chest" size={48} />
            </span>
            <p className="font-display text-lg font-bold">{t(`chest.got.${opened.reward.type}`)}</p>
            <ChestRewardText reward={opened.reward} />
          </div>
        )}
      </ScrollModal>

      <ScrollModal
        open={boosting !== null}
        title={boosting ? t(`booster.${boosting}`) : ''}
        onClose={() => setBoosting(null)}
        footer={<Button onClick={() => setBoosting(null)}>{t('common.close')}</Button>}
      >
        {boosting && (
          <>
            <p className="pb-2 text-sm">
              {t('booster.cut', { time: formatDurationT(t, BOOST_SECONDS[boosting]) })}
            </p>
            {targets.length === 0 ? (
              <p>{t('booster.none')}</p>
            ) : (
              <ul className="flex flex-col gap-2">
                {targets.map((x) => (
                  <li
                    key={x.taskId}
                    className="flex items-center gap-2 rounded-lg bg-black/25 px-3 py-2"
                  >
                    <span className="flex-1 font-semibold">{x.label}</span>
                    <Button
                      variant="gold"
                      className="!min-h-[40px]"
                      disabled={boost.isPending}
                      onClick={() =>
                        boost.mutate(
                          { booster: boosting, target: x.target, taskId: x.taskId },
                          {
                            onSuccess: () => {
                              push(t('booster.applied'), 'success');
                              setBoosting(null);
                            },
                            onError,
                          },
                        )
                      }
                      aria-label={`${t('booster.use')}: ${x.label}`}
                    >
                      {t('booster.use')}
                    </Button>
                  </li>
                ))}
              </ul>
            )}
          </>
        )}
      </ScrollModal>
    </div>
  );
}
