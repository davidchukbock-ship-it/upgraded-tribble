import type {
  BoosterKey,
  BoosterUseDto,
  ChestKind,
  ChestOddsDto,
  ChestOpenDto,
  DonateBuyDto,
  DonateDto,
  FreePacksDto,
  InventoryDto,
  LeagueDto,
  LeagueMetric,
  LeagueScope,
  QuestsDto,
  RewardResultDto,
  ShopBuyDto,
  ShopDto,
} from '@tc/shared';
import { apiFetch } from '../../lib/api';

/** Новый ключ на каждое намерение игрока: повтор запроса при обрыве связи безопасен (D-06). */
const key = () => ({ 'Idempotency-Key': crypto.randomUUID() });
const post = <T>(path: string, body?: unknown) =>
  apiFetch<T>(path, { method: 'POST', ...(body !== undefined ? { body } : {}), headers: key() });

export const questApi = {
  list: () => apiFetch<QuestsDto>('/api/quests'),
  claim: (id: string) => post<RewardResultDto>(`/api/quests/${id}/claim`),
  claimLogin: () => post<RewardResultDto>('/api/daily/claim'),
};

export const freePackApi = {
  list: () => apiFetch<FreePacksDto>('/api/free-packs'),
  claim: (id: string) => post<RewardResultDto>(`/api/free-packs/${id}/claim`),
};

export const chestApi = {
  odds: () => apiFetch<ChestOddsDto[]>('/api/chests/odds'),
  inventory: () => apiFetch<InventoryDto>('/api/inventory'),
  open: (kind: ChestKind) => post<ChestOpenDto>(`/api/chests/${kind}/open`),
  useBooster: (v: {
    booster: BoosterKey;
    target: 'build' | 'train' | 'research';
    taskId: string;
  }) => post<BoosterUseDto>('/api/inventory/boosters/use', v),
};

export const shopApi = {
  get: () => apiFetch<ShopDto>('/api/shop'),
  buy: (itemId: string) => post<ShopBuyDto>('/api/shop/buy', { itemId }),
  checkout: (packId: string) =>
    apiFetch<{ url: string }>('/api/shop/checkout', { method: 'POST', body: { packId } }),
};

export const leagueApi = {
  get: (scope: LeagueScope, metric: LeagueMetric) =>
    apiFetch<LeagueDto>(`/api/leagues/current?scope=${scope}&metric=${metric}`),
  claim: () => post<RewardResultDto>('/api/leagues/rewards/claim'),
};

export const donateApi = {
  get: () => apiFetch<DonateDto>('/api/donate'),
  buy: (packId: string) => post<DonateBuyDto>('/api/donate/buy', { packId }),
};
