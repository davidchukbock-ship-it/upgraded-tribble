import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
import { useState } from 'react';
import type { QuestDto } from '@tc/shared';
import { formatDurationT } from '../../lib/duration';
import { useToasts } from '../../store/toast';
import { Badge, Button, Panel, ProgressBar, Tabs } from '../../ui';
import { cn } from '../../lib/cn';
import { errorMessage } from '../auth/errors';
import { useNow } from '../castle/useCastle';
import { questApi } from './api';
import { FreePacksPanel, packsReady } from './FreePacks';
import { RewardView } from './RewardView';
import { useCastleResultMutation, useFreePacks, useQuests } from './useProgress';

function QuestRow({
  quest,
  busy,
  onClaim,
}: {
  quest: QuestDto;
  busy: boolean;
  onClaim: (id: string) => void;
}) {
  const { t } = useTranslation();
  const title = t(`quests.item.${quest.id}`, { target: quest.target });
  return (
    <li
      className={cn(
        'panel-wood frame-pixel flex flex-col gap-2 px-4 py-3',
        quest.claimable && 'claimable-glow ring-2 ring-gold',
      )}
    >
      <div className="flex flex-wrap items-center gap-2">
        <span className={cn('flex-1 font-semibold', quest.claimed && 'opacity-70')}>{title}</span>
        {quest.claimed ? (
          <Badge tone="green">{t('quests.claimed')}</Badge>
        ) : quest.claimable ? (
          <Button
            variant="gold"
            className="!min-h-[40px]"
            disabled={busy}
            onClick={() => onClaim(quest.id)}
            aria-label={`${t('quests.claim')}: ${title}`}
          >
            {t('quests.claim')}
          </Button>
        ) : quest.route ? (
          <Link
            to={quest.route}
            className="rounded-lg bg-black/30 px-3 py-2 text-sm font-bold text-gold-light hover:bg-black/45"
          >
            {t('quests.go')}
          </Link>
        ) : null}
      </div>
      <ProgressBar
        label={title}
        value={quest.progress}
        max={quest.target}
        text={`${quest.progress} ${t('common.of')} ${quest.target}`}
      />
      <RewardView reward={quest.reward} />
    </li>
  );
}

export function QuestsPage() {
  const { t } = useTranslation();
  const push = useToasts((s) => s.push);
  const [tab, setTab] = useState('tutorial');
  const now = useNow();
  const q = useQuests();
  const free = useFreePacks();
  const claim = useCastleResultMutation(questApi.claim);
  const login = useCastleResultMutation(() => questApi.claimLogin());
  const busy = claim.isPending || login.isPending;

  if (q.isPending)
    return (
      <p role="status" className="pt-8 text-center font-display text-lg">
        {t('common.loading')}
      </p>
    );
  if (q.isError || !q.data)
    return (
      <Panel title={t('nav.quests')} className="mx-auto max-w-md text-center">
        <p className="pt-2">{t('errors.ERR_NETWORK')}</p>
        <Button className="mt-3" onClick={() => void q.refetch()}>
          {t('common.retry')}
        </Button>
      </Panel>
    );
  const data = q.data;
  const onError = (err: unknown) => push(errorMessage(t, err), 'error');
  const doClaim = (id: string) =>
    claim.mutate(id, {
      onSuccess: () => push(t('quests.received'), 'success'),
      onError,
    });
  const list = (items: QuestDto[]) => (
    <ul className="flex flex-col gap-3">
      {items.map((x) => (
        <QuestRow key={x.id} quest={x} busy={busy} onClaim={doClaim} />
      ))}
    </ul>
  );
  const ready = (items: QuestDto[]) => items.filter((x) => x.claimable).length;
  const label = (id: string, n: number) =>
    n > 0 ? `${t(`quests.tab.${id}`)} (${n})` : t(`quests.tab.${id}`);
  const resetIn = Math.max(0, (Date.parse(data.dailyResetAt) - now) / 1000);

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-6">
      <h1 className="font-display text-2xl font-bold text-gold-light">{t('nav.quests')}</h1>

      <Panel title={t('quests.login.title')}>
        <p className="pb-2 text-sm">{t('quests.login.text')}</p>
        <ol
          className="grid grid-cols-4 gap-1.5 sm:grid-cols-7"
          aria-label={t('quests.login.title')}
        >
          {data.login.rewards.map((r, i) => {
            const day = i + 1;
            const current = day === data.login.day;
            const done = day < data.login.day || (current && data.login.claimed);
            return (
              <li
                key={day}
                aria-current={current ? 'step' : undefined}
                className={cn(
                  'flex min-w-0 flex-col items-center gap-1 break-words rounded-lg border-2 px-1 py-2 text-center text-xs',
                  current ? 'border-gold bg-black/40' : 'border-transparent bg-black/25',
                  done && 'opacity-60',
                )}
              >
                <span className="font-display font-bold">{t('quests.login.day', { day })}</span>
                <span className="text-[11px] leading-tight">
                  {r.chest
                    ? t(`chest.kind.${r.chest}`)
                    : r.resources
                      ? `+${r.resources.gold}`
                      : `+${r.gems}`}
                </span>
                {done && <span aria-hidden="true">✓</span>}
              </li>
            );
          })}
        </ol>
        <div className="flex flex-wrap items-center gap-3 pt-3">
          {data.login.claimed ? (
            <Badge tone="green">{t('quests.login.done')}</Badge>
          ) : (
            <Button
              variant="gold"
              disabled={busy}
              onClick={() =>
                login.mutate(undefined, {
                  onSuccess: () => push(t('quests.received'), 'success'),
                  onError,
                })
              }
            >
              {t('quests.login.claim', { day: data.login.day })}
            </Button>
          )}
          <RewardView reward={data.login.rewards[data.login.day - 1]!} />
        </div>
      </Panel>

      <Tabs
        value={tab}
        onChange={setTab}
        items={[
          {
            id: 'free',
            label: label('free', packsReady(free.data?.packs ?? [], now)),
            content: <FreePacksPanel />,
          },
          {
            id: 'tutorial',
            label: label('tutorial', ready(data.tutorial)),
            content: list(data.tutorial),
          },
          {
            id: 'daily',
            label: label('daily', ready(data.daily)),
            content: (
              <div className="flex flex-col gap-3">
                <p className="text-sm" role="status">
                  {t('quests.resetIn', { time: formatDurationT(t, resetIn) })}
                </p>
                {list(data.daily)}
              </div>
            ),
          },
          {
            id: 'achievements',
            label: label('achievements', ready(data.achievements)),
            content: list(data.achievements),
          },
        ]}
      />
    </div>
  );
}
