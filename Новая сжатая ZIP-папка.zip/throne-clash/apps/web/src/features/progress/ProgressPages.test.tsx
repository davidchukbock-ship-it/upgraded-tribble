import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import {
  CHEST_ODDS,
  SHOP_CATALOG,
  type ChestOpenDto,
  type LeagueDto,
  type QuestDto,
  type QuestsDto,
  type RewardResultDto,
  type ShopDto,
} from '@tc/shared';
import { initI18n } from '../../lib/i18n';
import { useToasts } from '../../store/toast';
import {
  apiError,
  installFakeApi,
  json,
  makeCastle,
  makeInventory,
  makeQuests,
} from '../../test-utils/fake-api';
import { renderApp, resetAuth, signIn } from '../../test-utils/render';

beforeAll(async () => {
  await initI18n('ru');
});
beforeEach(() => {
  signIn();
  useToasts.setState({ items: [] });
});
afterEach(() => {
  resetAuth();
  vi.unstubAllGlobals();
});

const withQuest = (q: QuestsDto, id: string, over: Partial<QuestDto>): QuestsDto => {
  const patch = (list: QuestDto[]) => list.map((x) => (x.id === id ? { ...x, ...over } : x));
  return {
    ...q,
    tutorial: patch(q.tutorial),
    daily: patch(q.daily),
    achievements: patch(q.achievements),
  };
};

const rewardResult = (over: Partial<RewardResultDto> = {}): RewardResultDto => ({
  castle: makeCastle({ gems: 55 }),
  reward: { resources: null, gems: 5, chest: null },
  inventory: makeInventory(),
  ...over,
});

describe('экран заданий', () => {
  it('вкладки, серия входов и обратный отсчёт до сброса', async () => {
    installFakeApi({});
    renderApp('/quests');
    expect(await screen.findByRole('heading', { level: 1, name: 'Задания' })).toBeInTheDocument();
    const days = screen.getByRole('list', { name: 'Ежедневный вход' });
    expect(within(days).getAllByRole('listitem')).toHaveLength(7);
    expect(within(days).getAllByRole('listitem')[0]).toHaveAttribute('aria-current', 'step');
    expect(screen.getAllByRole('tab').map((t) => t.textContent)).toEqual([
      'Бесплатно',
      'Обучение',
      'Ежедневные',
      'Достижения',
    ]);
    await userEvent.click(screen.getByRole('tab', { name: 'Ежедневные' }));
    expect(screen.getByText(/Ежедневные задания обновятся через/)).toBeInTheDocument();
    expect(screen.getByText('Обучите 20 юнитов')).toBeInTheDocument();
  });

  it('бесплатные наборы: список, получение с ключом идемпотентности, обратный отсчёт', async () => {
    const reward = {
      resources: { gold: 150, wood: 150, stone: 100, food: 150 },
      gems: 0,
      chest: null,
    };
    let claimed = false;
    const { calls } = installFakeApi({
      'GET /api/free-packs': () =>
        json(200, {
          serverTime: new Date().toISOString(),
          claimable: claimed ? 0 : 1,
          packs: [
            {
              id: 'breeze',
              everyHours: 4,
              reward,
              claimed,
              nextAt: new Date(Date.now() + 3 * 3600_000).toISOString(),
            },
          ],
        }),
      'POST /api/free-packs/breeze/claim': () => {
        claimed = true;
        return json(200, rewardResult());
      },
    });
    renderApp('/quests');
    await userEvent.click(await screen.findByRole('tab', { name: /Бесплатно/ }));
    expect(await screen.findByText('Ветерок')).toBeInTheDocument();
    expect(screen.getByText('Раз в 4 ч')).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: 'Забрать: Ветерок' }));
    const post = await waitFor(() => {
      const c = calls.find((x) => x.method === 'POST');
      expect(c).toBeDefined();
      return c!;
    });
    expect(post.path).toBe('/api/free-packs/breeze/claim');
    expect(post.headers['Idempotency-Key']).toMatch(/^[0-9a-f-]{36}$/);
    expect(await screen.findByText(/Следующий через/)).toBeInTheDocument();
  });

  it('награда за вход: запрос с ключом идемпотентности, замок обновляется, задания перечитываются', async () => {
    let claimed = false;
    const { calls } = installFakeApi({
      'GET /api/quests': () =>
        json(
          200,
          makeQuests({
            login: { ...makeQuests().login, claimed },
            claimable: claimed ? 0 : 1,
          }),
        ),
      'POST /api/daily/claim': () => {
        claimed = true;
        return json(200, rewardResult());
      },
    });
    renderApp('/quests');
    await userEvent.click(await screen.findByRole('button', { name: 'Забрать награду: день 1' }));
    const post = await waitFor(() => {
      const c = calls.find((x) => x.method === 'POST');
      expect(c).toBeDefined();
      return c!;
    });
    expect(post.path).toBe('/api/daily/claim');
    expect(post.headers['Idempotency-Key']).toMatch(/^[0-9a-f-]{36}$/);
    expect(await screen.findByText('Сегодняшняя награда получена')).toBeInTheDocument();
    expect(useToasts.getState().items.map((i) => i.message)).toContain('Награда получена');
  });

  it('выполненное задание можно забрать; невыполненное ведёт на нужный экран', async () => {
    const base = makeQuests();
    const quests = withQuest(base, 't1_upgrade', { progress: 1, claimable: true });
    const { calls } = installFakeApi({
      'GET /api/quests': () => json(200, quests),
      'POST /api/quests/t1_upgrade/claim': () => json(200, rewardResult()),
    });
    renderApp('/quests');
    const claim = await screen.findByRole('button', {
      name: 'Забрать: Начните улучшение любого здания',
    });
    const row = screen.getByText('Постройте Казарму').closest('li')!;
    expect(within(row).getByRole('link', { name: 'Перейти' })).toHaveAttribute('href', '/castle');
    await userEvent.click(claim);
    await waitFor(() =>
      expect(calls.some((c) => c.path === '/api/quests/t1_upgrade/claim')).toBe(true),
    );
  });

  it('ошибка сервера показывается уведомлением', async () => {
    const quests = withQuest(makeQuests(), 't1_upgrade', { progress: 1, claimable: true });
    installFakeApi({
      'GET /api/quests': () => json(200, quests),
      'POST /api/quests/t1_upgrade/claim': () => apiError(409, 'ERR_CONFLICT'),
    });
    renderApp('/quests');
    await userEvent.click(
      await screen.findByRole('button', { name: /Забрать: Начните улучшение/ }),
    );
    await waitFor(() =>
      expect(useToasts.getState().items.map((i) => i.message)).toContain('Конфликт данных'),
    );
  });

  it('полученное отмечено, значок в меню показывает число наград, подсказка ведёт по шагам', async () => {
    const quests = withQuest(makeQuests({ claimable: 3 }), 't1_upgrade', {
      progress: 1,
      claimed: true,
    });
    installFakeApi({ 'GET /api/quests': () => json(200, quests) });
    renderApp('/castle');
    const banner = await screen.findByRole('complementary', { name: 'Обучение' });
    expect(within(banner).getByText('Шаг 2 из 10')).toBeInTheDocument();
    expect(within(banner).getByText('Постройте Казарму')).toBeInTheDocument();
    expect(within(banner).getByRole('link', { name: 'Перейти' })).toHaveAttribute(
      'href',
      '/castle',
    );
    // Значок «3» на кнопке меню
    expect((await screen.findAllByLabelText('Наград можно забрать: 3')).length).toBeGreaterThan(0);
  });

  it('готовый шаг туториала предлагает забрать награду', async () => {
    const quests = withQuest(makeQuests(), 't1_upgrade', { progress: 1, claimable: true });
    installFakeApi({ 'GET /api/quests': () => json(200, quests) });
    renderApp('/castle');
    const banner = await screen.findByRole('complementary', { name: 'Обучение' });
    expect(within(banner).getByRole('link', { name: 'Забрать награду' })).toHaveAttribute(
      'href',
      '/quests',
    );
  });

  it('ошибка загрузки: повтор', async () => {
    let fail = true;
    installFakeApi({
      'GET /api/quests': () => (fail ? apiError(500, 'ERR_INTERNAL') : json(200, makeQuests())),
    });
    renderApp('/quests');
    const retry = await screen.findByRole('button', { name: 'Повторить' });
    fail = false;
    await userEvent.click(retry);
    expect(await screen.findByRole('heading', { level: 1, name: 'Задания' })).toBeInTheDocument();
  });
});

const ODDS = (['wooden', 'silver', 'gold'] as const).map((kind) => ({
  kind,
  odds: CHEST_ODDS[kind],
  resourcePack: 800,
  gems: [5, 10] as [number, number],
}));

describe('экран сундуков', () => {
  it('показывает сундуки, ускорители и публичную таблицу шансов', async () => {
    installFakeApi({
      'GET /api/inventory': () =>
        json(200, makeInventory({ chests: { wooden: 2, silver: 0, gold: 0 } })),
      'GET /api/chests/odds': () => json(200, ODDS),
    });
    renderApp('/chests');
    expect(await screen.findByRole('heading', { level: 1, name: 'Сундуки' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Открыть: Деревянный сундук' })).toBeEnabled();
    expect(screen.getByRole('button', { name: 'Открыть: Серебряный сундук' })).toBeDisabled();
    const table = await screen.findByRole('table', { name: 'Шансы выпадения' });
    expect(within(table).getByRole('row', { name: /Пакет ресурсов 60% 45% 30%/ })).toBeDefined();
    expect(
      within(table).getByRole('row', { name: /Экипировка \(редкость 4–5\) 0% 3% 10%/ }),
    ).toBeDefined();
  });

  it('открытие сундука: запрос, окно с наградой, обновлённый инвентарь', async () => {
    let opened = false;
    const result: ChestOpenDto = {
      castle: makeCastle(),
      reward: { type: 'gems', gems: 7 },
      inventory: makeInventory(),
    };
    const { calls } = installFakeApi({
      'GET /api/inventory': () =>
        json(200, makeInventory({ chests: { wooden: opened ? 0 : 1, silver: 0, gold: 0 } })),
      'GET /api/chests/odds': () => json(200, ODDS),
      'POST /api/chests/wooden/open': () => {
        opened = true;
        return json(200, result);
      },
    });
    renderApp('/chests');
    await userEvent.click(
      await screen.findByRole('button', { name: 'Открыть: Деревянный сундук' }),
    );
    const dialog = await screen.findByRole('dialog', { name: 'Сундук открыт' });
    expect(within(dialog).getByText(/7 Кристаллы/)).toBeInTheDocument();
    expect(calls.find((c) => c.method === 'POST')?.headers['Idempotency-Key']).toBeDefined();
    await userEvent.click(within(dialog).getAllByRole('button', { name: 'Закрыть' })[0]!);
    await waitFor(() =>
      expect(screen.getByRole('button', { name: 'Открыть: Деревянный сундук' })).toBeDisabled(),
    );
  });

  it('ускоритель применяется к выбранной постройке', async () => {
    const task = {
      id: '11111111-1111-4111-8111-111111111111',
      key: 'farm' as const,
      toLevel: 2,
      startedAt: new Date().toISOString(),
      finishesAt: new Date(Date.now() + 600_000).toISOString(),
      speedupGems: 2,
      refund: { gold: 0, wood: 0, stone: 0, food: 0 },
    };
    const { calls } = installFakeApi({
      'GET /api/castle': () => json(200, makeCastle({ tasks: [task] })),
      'GET /api/inventory': () =>
        json(200, makeInventory({ boosters: { boost_5m: 1, boost_1h: 0, boost_8h: 0 } })),
      'GET /api/chests/odds': () => json(200, ODDS),
      'POST /api/inventory/boosters/use': () =>
        json(200, { castle: makeCastle(), inventory: makeInventory() }),
    });
    renderApp('/chests');
    await userEvent.click(
      await screen.findByRole('button', { name: 'Применить: Ускоритель 5 минут' }),
    );
    const dialog = await screen.findByRole('dialog');
    expect(within(dialog).getByText('Сокращает время задачи на 5м.')).toBeInTheDocument();
    await userEvent.click(within(dialog).getByRole('button', { name: /Применить: Ферма/ }));
    await waitFor(() => expect(calls.some((c) => c.method === 'POST')).toBe(true));
    expect(calls.find((c) => c.method === 'POST')?.body).toEqual({
      booster: 'boost_5m',
      target: 'build',
      taskId: task.id,
    });
  });

  it('без задач ускорителю применяться некуда', async () => {
    installFakeApi({
      'GET /api/inventory': () =>
        json(200, makeInventory({ boosters: { boost_5m: 0, boost_1h: 1, boost_8h: 0 } })),
      'GET /api/chests/odds': () => json(200, ODDS),
    });
    renderApp('/chests');
    await userEvent.click(
      await screen.findByRole('button', { name: 'Применить: Ускоритель 1 час' }),
    );
    expect(await screen.findByText(/Сейчас нет постройки/)).toBeInTheDocument();
  });
});

const shopDto = (over: Partial<ShopDto> = {}): ShopDto => ({
  gems: 60,
  inventory: makeInventory(),
  items: SHOP_CATALOG.map((i) => ({
    id: i.id,
    kind: i.kind,
    price: i.price,
    resources: i.resources ?? null,
    booster: i.booster ?? null,
    crest: i.crest ?? null,
    owned: false,
  })),
  ...over,
});

describe('магазин', () => {
  it('каталог: цены, нехватка кристаллов и купленное', async () => {
    const dto = shopDto();
    dto.items = dto.items.map((i) => (i.id === 'crest_wolf-night' ? { ...i, owned: true } : i));
    installFakeApi({ 'GET /api/shop': () => json(200, dto) });
    renderApp('/shop');
    expect(await screen.findByRole('heading', { level: 1, name: 'Магазин' })).toBeInTheDocument();
    expect(within(screen.getByRole('main')).getByRole('link', { name: 'Донат' })).toHaveAttribute(
      'href',
      '/donate',
    );
    expect(screen.getByRole('button', { name: 'Купить: Большой пакет' })).toBeDisabled();
    expect(screen.getByRole('button', { name: 'Купить: Большой пакет' })).toHaveTextContent(
      'Не хватает',
    );
    expect(screen.getByRole('button', { name: 'Купить: Малый пакет' })).toBeEnabled();
    const crest = screen.getByText('Герб: Ночной волк').closest('li')!;
    expect(within(crest).getByText('Куплено')).toBeInTheDocument();
  });

  it('дешёвая покупка идёт сразу, дорогая — после подтверждения', async () => {
    const { calls } = installFakeApi({
      'GET /api/shop': () => json(200, shopDto({ gems: 500 })),
      'POST /api/shop/buy': () =>
        json(200, { castle: makeCastle({ gems: 480 }), shop: shopDto({ gems: 480 }) }),
    });
    renderApp('/shop');
    await userEvent.click(await screen.findByRole('button', { name: 'Купить: Малый пакет' }));
    await waitFor(() => expect(calls.some((c) => c.method === 'POST')).toBe(true));
    expect(calls.find((c) => c.method === 'POST')?.body).toEqual({ itemId: 'pack_s' });
    await waitFor(() =>
      expect(useToasts.getState().items.map((i) => i.message)).toContain('Куплено: Малый пакет'),
    );

    await userEvent.click(screen.getByRole('button', { name: 'Купить: Большой пакет' }));
    const dialog = await screen.findByRole('alertdialog', { name: 'Подтвердите покупку' });
    expect(within(dialog).getByText(/за 350 кристаллов/)).toBeInTheDocument();
    await userEvent.click(within(dialog).getByRole('button', { name: 'Отмена' }));
    expect(calls.filter((c) => c.method === 'POST')).toHaveLength(1);

    await userEvent.click(screen.getByRole('button', { name: 'Купить: Большой пакет' }));
    await userEvent.click(
      within(await screen.findByRole('alertdialog')).getByRole('button', { name: 'Купить' }),
    );
    await waitFor(() => expect(calls.filter((c) => c.method === 'POST')).toHaveLength(2));
    expect(calls.filter((c) => c.method === 'POST')[1]?.body).toEqual({ itemId: 'pack_l' });
  });

  it('ошибка покупки — уведомление', async () => {
    installFakeApi({
      'GET /api/shop': () => json(200, shopDto()),
      'POST /api/shop/buy': () => apiError(422, 'ERR_INSUFFICIENT_RESOURCES'),
    });
    renderApp('/shop');
    await userEvent.click(await screen.findByRole('button', { name: 'Купить: Малый пакет' }));
    await waitFor(() =>
      expect(useToasts.getState().items.map((i) => i.message)).toContain('Не хватает ресурсов'),
    );
  });
});

const league = (over: Partial<LeagueDto> = {}): LeagueDto => ({
  seasonId: '2026-03-09',
  endsAt: new Date(Date.now() + 3 * 86_400_000).toISOString(),
  metric: 'points',
  scope: 'me',
  entries: [
    { place: 1, userId: 'u9', nickname: 'Борис', value: 340, isMe: false },
    { place: 2, userId: 'u1', nickname: 'Артур', value: 120, isMe: true },
  ],
  me: { place: 2, value: 120, points: 120 },
  pending: [],
  prize: { gems: 50, chest: 'silver' },
  ...over,
});

describe('лиги', () => {
  it('таблица подсвечивает меня, показывает место и приз', async () => {
    installFakeApi({
      'GET /api/leagues/current?scope=me&metric=points': () => json(200, league()),
    });
    renderApp('/leagues');
    expect(await screen.findByRole('heading', { level: 1, name: 'Лиги' })).toBeInTheDocument();
    const me = await screen.findByRole('row', { name: /Артур/ });
    expect(me).toHaveAttribute('aria-current', 'true');
    expect(screen.getByText(/До конца сезона: \d+д/)).toBeInTheDocument();
    expect(screen.getByText('Приз за текущее место:')).toBeInTheDocument();
  });

  it('смена фильтра и показателя запрашивает другую таблицу', async () => {
    const { calls } = installFakeApi({
      'GET /api/leagues/current?scope=me&metric=points': () => json(200, league()),
      'GET /api/leagues/current?scope=guild&metric=points': () =>
        json(200, league({ scope: 'guild', entries: [], me: null })),
      'GET /api/leagues/current?scope=guild&metric=wins': () =>
        json(200, league({ scope: 'guild', metric: 'wins', entries: [], me: null })),
    });
    renderApp('/leagues');
    await screen.findByRole('row', { name: /Артур/ });
    await userEvent.click(screen.getByRole('tab', { name: 'Братство' }));
    expect(await screen.findByText('Вы не состоите в братстве')).toBeInTheDocument();
    await userEvent.click(screen.getByRole('radio', { name: 'Победы' }));
    await waitFor(() =>
      expect(calls.some((c) => c.path === '/api/leagues/current?scope=guild&metric=wins')).toBe(
        true,
      ),
    );
  });

  it('призы за прошлые сезоны можно забрать', async () => {
    let pending = true;
    const { calls } = installFakeApi({
      'GET /api/leagues/current?scope=me&metric=points': () =>
        json(
          200,
          league({
            pending: pending
              ? [{ seasonId: '2026-03-02', place: 1, gems: 100, chest: 'gold' }]
              : [],
          }),
        ),
      'POST /api/leagues/rewards/claim': () => {
        pending = false;
        return json(200, rewardResult({ reward: { resources: null, gems: 100, chest: 'gold' } }));
      },
    });
    renderApp('/leagues');
    expect(await screen.findByText(/Сезон 2026-03-02 · 1-е место/)).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: 'Забрать призы' }));
    await waitFor(() => expect(calls.some((c) => c.method === 'POST')).toBe(true));
    await waitFor(() => expect(screen.queryByText('Призы за прошлые сезоны')).toBeNull());
  });
});

describe('герб в профиле', () => {
  it('купленные премиум-гербы можно выбрать', async () => {
    const { calls } = installFakeApi({
      'GET /api/inventory': () => json(200, makeInventory({ crests: ['lion-gold'] })),
      'PATCH /api/profile': () =>
        json(200, {
          user: { ...signInUser(), crest: 'lion-gold' },
          serverTime: new Date().toISOString(),
        }),
    });
    renderApp('/profile');
    await userEvent.click(await screen.findByRole('radio', { name: 'Золотой лев' }));
    await waitFor(() => expect(calls.some((c) => c.method === 'PATCH')).toBe(true));
    expect(calls.find((c) => c.method === 'PATCH')?.body).toEqual({ crest: 'lion-gold' });
  });
});

function signInUser() {
  return {
    id: 'u1',
    nickname: 'Артур',
    role: 'PLAYER',
    isGuest: false,
    email: 'hero@example.com',
    language: 'ru',
    crest: 'lion',
    createdAt: '2026-01-01T00:00:00.000Z',
  };
}
