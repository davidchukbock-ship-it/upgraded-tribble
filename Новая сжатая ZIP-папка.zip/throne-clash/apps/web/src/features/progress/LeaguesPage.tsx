import { useQuery } from '@tanstack/react-query';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { LEAGUE_METRICS, LEAGUE_SCOPES, type LeagueMetric, type LeagueScope } from '@tc/shared';
import { cn } from '../../lib/cn';
import { formatDurationT } from '../../lib/duration';
import { useToasts } from '../../store/toast';
import { Badge, Button, Panel, Tabs } from '../../ui';
import { errorMessage } from '../auth/errors';
import { useNow } from '../castle/useCastle';
import { leagueApi } from './api';
import { RewardView } from './RewardView';
import { useCastleResultMutation } from './useProgress';

export function LeaguesPage() {
  const { t } = useTranslation();
  const push = useToasts((s) => s.push);
  const now = useNow();
  const [scope, setScope] = useState<LeagueScope>('me');
  const [metric, setMetric] = useState<LeagueMetric>('points');
  const q = useQuery({
    queryKey: ['leagues', scope, metric],
    queryFn: () => leagueApi.get(scope, metric),
    staleTime: 15_000,
    placeholderData: (prev) => prev,
  });
  const claim = useCastleResultMutation(() => leagueApi.claim());

  if (q.isPending)
    return (
      <p role="status" className="pt-8 text-center font-display text-lg">
        {t('common.loading')}
      </p>
    );
  if (q.isError || !q.data)
    return (
      <Panel title={t('nav.leagues')} className="mx-auto max-w-md text-center">
        <p className="pt-2">{t('errors.ERR_NETWORK')}</p>
        <Button className="mt-3" onClick={() => void q.refetch()}>
          {t('common.retry')}
        </Button>
      </Panel>
    );
  const d = q.data;
  const left = Math.max(0, (Date.parse(d.endsAt) - now) / 1000);

  const table = (
    <>
      {d.entries.length === 0 ? (
        <p>{scope === 'guild' ? t('leagues.noGuild') : t('leagues.empty')}</p>
      ) : (
        <div className="overflow-x-auto" role="region" tabIndex={0} aria-label={t('nav.leagues')}>
          <table className="w-full min-w-[300px] text-left text-sm">
            <caption className="sr-only">
              {t(`leagues.scope.${scope}`)}, {t(`leagues.metric.${metric}`)}
            </caption>
            <thead>
              <tr className="border-b-2 border-stone">
                <th scope="col" className="w-14 py-2">
                  {t('leagues.place')}
                </th>
                <th scope="col" className="py-2">
                  {t('leagues.player')}
                </th>
                <th scope="col" className="py-2 text-right">
                  {t(`leagues.metric.${metric}`)}
                </th>
              </tr>
            </thead>
            <tbody>
              {d.entries.map((e) => (
                <tr
                  key={e.userId}
                  aria-current={e.isMe ? 'true' : undefined}
                  className={cn('border-b border-stone/40', e.isMe && 'bg-gold/25 font-bold')}
                >
                  <td className="py-2 tabular-nums">{e.place}</td>
                  <td className="py-2">
                    {e.nickname}
                    {e.isMe && <span className="sr-only"> ({t('leagues.you')})</span>}
                  </td>
                  <td className="py-2 text-right tabular-nums">{e.value}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-6">
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="font-display text-2xl font-bold text-gold-light">{t('nav.leagues')}</h1>
        <span className="ml-auto text-sm" role="status">
          {t('leagues.endsIn', { time: formatDurationT(t, left) })}
        </span>
      </div>

      {d.pending.length > 0 && (
        <Panel title={t('leagues.pending')}>
          <ul className="flex flex-col gap-1 pt-2 text-sm">
            {d.pending.map((p) => (
              <li key={p.seasonId} className="flex flex-wrap items-center gap-2">
                <span className="font-semibold">
                  {t('leagues.season', { id: p.seasonId })}
                  {p.place !== null && ` · ${t('leagues.placeN', { n: p.place })}`}
                </span>
                <RewardView reward={{ resources: null, gems: p.gems, chest: p.chest }} />
              </li>
            ))}
          </ul>
          <Button
            variant="gold"
            className="mt-3"
            disabled={claim.isPending}
            onClick={() =>
              claim.mutate(undefined, {
                onSuccess: () => push(t('quests.received'), 'success'),
                onError: (err) => push(errorMessage(t, err), 'error'),
              })
            }
          >
            {t('leagues.claim')}
          </Button>
        </Panel>
      )}

      <Panel title={t('leagues.mine')}>
        {d.me ? (
          <div className="flex flex-wrap items-center gap-x-6 gap-y-1 pt-1">
            <p>
              {t('leagues.myPlace')}: <strong>{d.me.place ?? '—'}</strong>
            </p>
            <p>
              {t(`leagues.metric.${metric}`)}: <strong>{d.me.value}</strong>
            </p>
            <p>
              {t('leagues.metric.points')}: <strong>{d.me.points}</strong>
            </p>
          </div>
        ) : (
          <p>{t('leagues.notRanked')}</p>
        )}
        <div className="flex flex-wrap items-center gap-2 pt-2 text-sm">
          <span>{t('leagues.prize')}:</span>
          {d.prize.gems > 0 ? (
            <RewardView reward={{ resources: null, gems: d.prize.gems, chest: d.prize.chest }} />
          ) : (
            <Badge tone="stone">{t('leagues.noPrize')}</Badge>
          )}
        </div>
        <p className="pt-1 text-xs">{t('leagues.prizeNote')}</p>
      </Panel>

      <Tabs
        value={scope}
        onChange={(id) => setScope(id as LeagueScope)}
        items={LEAGUE_SCOPES.map((s) => ({
          id: s,
          label: t(`leagues.scope.${s}`),
          content: (
            <div className="flex flex-col gap-3">
              <div
                role="radiogroup"
                aria-label={t('leagues.metricLabel')}
                className="flex flex-wrap gap-2"
              >
                {LEAGUE_METRICS.map((m) => (
                  <Button
                    key={m}
                    role="radio"
                    aria-checked={metric === m}
                    variant={metric === m ? 'gold' : 'primary'}
                    className="!min-h-[40px]"
                    onClick={() => setMetric(m)}
                  >
                    {t(`leagues.metric.${m}`)}
                  </Button>
                ))}
              </div>
              <Panel tone="parchment">{s === scope ? table : null}</Panel>
            </div>
          ),
        }))}
      />
    </div>
  );
}
