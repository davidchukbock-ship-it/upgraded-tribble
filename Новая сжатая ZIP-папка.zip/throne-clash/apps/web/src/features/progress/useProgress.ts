import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import type { CastleDto } from '@tc/shared';
import { useAuth } from '../../store/auth';
import { chestApi, freePackApi, questApi } from './api';

export const QUESTS_KEY = ['quests'] as const;
export const INVENTORY_KEY = ['inventory'] as const;
export const FREE_PACKS_KEY = ['free-packs'] as const;
const CASTLE_KEY = ['castle'] as const;

export function useQuests() {
  const authed = useAuth((s) => s.status === 'authenticated');
  return useQuery({
    queryKey: QUESTS_KEY,
    queryFn: questApi.list,
    enabled: authed,
    staleTime: 30_000,
    refetchOnWindowFocus: true,
  });
}

export function useFreePacks() {
  const authed = useAuth((s) => s.status === 'authenticated');
  return useQuery({
    queryKey: FREE_PACKS_KEY,
    queryFn: freePackApi.list,
    enabled: authed,
    staleTime: 60_000,
    refetchOnWindowFocus: true,
  });
}

export function useInventory() {
  const authed = useAuth((s) => s.status === 'authenticated');
  return useQuery({
    queryKey: INVENTORY_KEY,
    queryFn: chestApi.inventory,
    enabled: authed,
    staleTime: 30_000,
  });
}

/** Что затрагивает действие с наградой: замок (ресурсы, кристаллы), инвентарь, задания, магазин, лиги. */
export function useInvalidateProgress() {
  const client = useQueryClient();
  return () => {
    for (const key of ['quests', 'inventory', 'shop', 'leagues', 'free-packs'])
      void client.invalidateQueries({ queryKey: [key] });
  };
}

/**
 * Мутация с ответом вида `{ castle, ... }`: замок кладём в кэш сразу, остальное перечитываем.
 * При ошибке (например, награду уже забрали с другого устройства) состояние тоже обновляется.
 */
export function useCastleResultMutation<TVars, TData extends { castle: CastleDto }>(
  fn: (vars: TVars) => Promise<TData>,
) {
  const client = useQueryClient();
  const invalidate = useInvalidateProgress();
  return useMutation({
    mutationFn: fn,
    onSuccess: (data) => {
      client.setQueryData(CASTLE_KEY, data.castle);
      invalidate();
    },
    onError: () => {
      void client.invalidateQueries({ queryKey: CASTLE_KEY });
      invalidate();
    },
  });
}
