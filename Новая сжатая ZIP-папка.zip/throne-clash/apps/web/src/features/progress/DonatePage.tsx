import { useQuery } from '@tanstack/react-query';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { gemsPerUsd, type DonatePackDto } from '@tc/shared';
import { ArtIcon, NpcArt } from '../../art';
import { cn } from '../../lib/cn';
import { formatFull } from '../../lib/format';
import { useToasts } from '../../store/toast';
import { Badge, Button, ConfirmDialog } from '../../ui';
import { errorMessage } from '../auth/errors';
import { donateApi } from './api';
import { useCastleResultMutation } from './useProgress';

/** Цена пакета: только доллары США, других валют в игре нет. */
export function priceLabel(p: DonatePackDto): string {
  return `$${(p.usdCents / 100).toFixed(2)}`;
}

/** Сколько «драгоценных камней» рисовать на карточке: чем крупнее пакет, тем богаче куча. */
const PILE = [1, 2, 3, 4, 5, 6];

function GemPile({ n }: { n: number }) {
  return (
    <div className="relative flex h-28 items-end justify-center" aria-hidden="true">
      <div className="absolute bottom-0 h-5 w-32 rounded-[50%] bg-[radial-gradient(closest-side,rgba(143,216,255,0.45),rgba(0,0,0,0.35)_70%,transparent)]" />
      {Array.from({ length: n }, (_, i) => {
        const row = i < 3 ? 0 : 1;
        const col = i < 3 ? i : i - 3;
        const shift = row === 0 ? (col - 1) * 32 : (col - 0.5) * 32;
        return (
          <span
            key={i}
            className="absolute"
            style={{
              bottom: row === 0 ? 4 : 36,
              left: `calc(50% + ${shift}px - 20px)`,
              animationDelay: `${i * 0.35}s`,
            }}
          >
            <ArtIcon name="gems" size={row === 0 ? 42 : 36} className="donate-gem" />
          </span>
        );
      })}
    </div>
  );
}

/** Отдельный магазин донатов: пакеты кристаллов за реальные деньги. Оплата подключается провайдером на сервере (D-62). */
export function DonatePage() {
  const { t } = useTranslation();
  const push = useToasts((s) => s.push);
  const catalog = useQuery({ queryKey: ['donate'], queryFn: donateApi.get, staleTime: 10_000 });
  const buy = useCastleResultMutation((id: string) => donateApi.buy(id));
  const [asking, setAsking] = useState<DonatePackDto | null>(null);

  if (catalog.isPending)
    return (
      <p role="status" className="pt-8 text-center font-display text-lg">
        {t('common.loading')}
      </p>
    );
  if (catalog.isError || !catalog.data)
    return (
      <div className="mx-auto max-w-md text-center">
        <p>{t('errors.ERR_NETWORK')}</p>
        <Button className="mt-3" onClick={() => void catalog.refetch()}>
          {t('common.retry')}
        </Button>
      </div>
    );

  const { mode, packs, gems } = catalog.data;
  const enabled = mode === 'test';
  const nameOf = (p: DonatePackDto): string => t(`donate.pack.${p.id}`);

  const confirm = (p: DonatePackDto) =>
    buy.mutate(p.id, {
      onSuccess: (r) => {
        push(t('donate.done', { n: formatFull(r.granted) }), 'success');
        void catalog.refetch();
      },
      onError: (err) => push(errorMessage(t, err), 'error'),
    });

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-5">
      <header className="donate-hero panel-wood frame-pixel relative flex flex-wrap items-center gap-4 overflow-hidden px-5 py-4">
        <div className="min-w-0 flex-1">
          <h1 className="font-display text-2xl font-bold text-gold-light">{t('donate.title')}</h1>
          <p className="mt-1 text-sm">{t('donate.lead')}</p>
          <p className="mt-2 flex items-center gap-2 text-sm font-semibold" role="status">
            {t('donate.balance')}
            <ArtIcon name="gems" size={22} />
            <b className="text-[#8fd8ff]">{formatFull(gems)}</b>
          </p>
        </div>
        <NpcArt name="merchant" size={110} anim="idle" className="shrink-0" />
      </header>

      <aside
        role="note"
        className={cn(
          'rounded-lg border-2 px-4 py-3 text-sm',
          enabled ? 'border-gold/70 bg-gold/10' : 'border-stone bg-black/30',
        )}
      >
        <b className="font-display">{enabled ? t('donate.testTitle') : t('donate.offTitle')}</b>
        <p className="mt-1">{enabled ? t('donate.testText') : t('donate.offText')}</p>
      </aside>

      <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {packs.map((p, i) => (
          <li
            key={p.id}
            className={cn(
              'panel-wood frame-pixel relative flex flex-col gap-2 overflow-hidden p-4 text-center',
              p.tag && 'ring-2 ring-gold',
            )}
          >
            {p.tag && (
              <span className="absolute right-[-46px] top-4 z-10 w-40 rotate-45 bg-red py-0.5 text-center text-xs font-bold text-white shadow">
                {t(`donate.${p.tag}`)}
              </span>
            )}
            <GemPile n={PILE[i] ?? 1} />
            <h2 className="font-display text-lg font-bold text-gold-light">{nameOf(p)}</h2>
            <p className="text-2xl font-extrabold text-[#8fd8ff]">
              {t('donate.total', { n: formatFull(p.total) })}
            </p>
            {p.bonus > 0 ? (
              <Badge tone="green">{t('donate.bonus', { n: formatFull(p.bonus) })}</Badge>
            ) : (
              <span className="h-6" />
            )}
            <p className="text-xs opacity-80">{t('donate.perMoney', { n: gemsPerUsd(p) })}</p>
            <Button
              variant="gold"
              className="mt-auto"
              disabled={!enabled || buy.isPending}
              onClick={() => setAsking(p)}
              aria-label={`${t('donate.buy')}: ${nameOf(p)}, ${priceLabel(p)}`}
            >
              {priceLabel(p)}
            </Button>
          </li>
        ))}
      </ul>

      <p className="text-xs opacity-80">{t('donate.fine')}</p>

      <ConfirmDialog
        open={asking !== null}
        title={t('donate.confirmTitle')}
        message={
          asking
            ? t('donate.confirmText', {
                name: nameOf(asking),
                n: formatFull(asking.total),
                price: priceLabel(asking),
              })
            : ''
        }
        confirmLabel={t('donate.buy')}
        onCancel={() => setAsking(null)}
        onConfirm={() => {
          const p = asking;
          setAsking(null);
          if (p) confirm(p);
        }}
      />
    </div>
  );
}
