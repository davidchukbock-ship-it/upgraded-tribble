import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useQueryClient } from '@tanstack/react-query';
import type { FreePackDto } from '@tc/shared';
import { formatDurationT } from '../../lib/duration';
import { cn } from '../../lib/cn';
import { useToasts } from '../../store/toast';
import { Badge, Button } from '../../ui';
import { errorMessage } from '../auth/errors';
import { useNow } from '../castle/useCastle';
import { freePackApi } from './api';
import { RewardView } from './RewardView';
import { FREE_PACKS_KEY, useCastleResultMutation, useFreePacks } from './useProgress';

/** Получен ли набор в текущем окне: клиент сам замечает, что окно закончилось (по серверным часам). */
export const packClaimed = (p: FreePackDto, now: number): boolean =>
  p.claimed && (p.nextAt === null || now < Date.parse(p.nextAt));

/** Сколько наборов можно забрать прямо сейчас. */
export const packsReady = (packs: readonly FreePackDto[], now: number): number =>
  packs.filter((p) => !packClaimed(p, now)).length;

export function FreePacksPanel() {
  const { t } = useTranslation();
  const push = useToasts((s) => s.push);
  const client = useQueryClient();
  const now = useNow();
  const q = useFreePacks();
  const claim = useCastleResultMutation(freePackApi.claim);
  const packs = q.data?.packs ?? [];
  // Окно закончилось, пока страница открыта — перечитываем список
  const expired = packs.some((p) => p.claimed && p.nextAt !== null && now >= Date.parse(p.nextAt));
  useEffect(() => {
    if (expired) void client.invalidateQueries({ queryKey: FREE_PACKS_KEY });
  }, [expired, client]);

  if (q.isPending)
    return (
      <p role="status" className="text-center">
        {t('common.loading')}
      </p>
    );
  if (q.isError)
    return (
      <div className="text-center">
        <p>{t('errors.ERR_NETWORK')}</p>
        <Button className="mt-3" onClick={() => void q.refetch()}>
          {t('common.retry')}
        </Button>
      </div>
    );

  return (
    <div className="flex flex-col gap-3">
      <p className="text-sm">{t('freePacks.lead')}</p>
      <ul className="grid gap-3 sm:grid-cols-2">
        {packs.map((p) => {
          const done = packClaimed(p, now);
          const title = t(`freePacks.pack.${p.id}`);
          return (
            <li
              key={p.id}
              className={cn(
                'panel-wood frame-pixel flex flex-col gap-2 px-4 py-3',
                !done && 'claimable-glow ring-2 ring-gold',
              )}
            >
              <div className="flex flex-wrap items-center gap-2">
                <span className="flex-1 font-display font-bold">{title}</span>
                <Badge tone={p.everyHours === null ? 'gold' : 'stone'}>
                  {p.everyHours === null
                    ? t('freePacks.once')
                    : t('freePacks.every', { hours: p.everyHours })}
                </Badge>
              </div>
              <p className="text-xs opacity-90">{t(`freePacks.text.${p.id}`)}</p>
              <RewardView reward={p.reward} />
              {done ? (
                <p role="status" className="text-sm">
                  {p.nextAt
                    ? t('freePacks.nextIn', {
                        time: formatDurationT(t, (Date.parse(p.nextAt) - now) / 1000),
                      })
                    : t('freePacks.claimedForever')}
                </p>
              ) : (
                <Button
                  variant="gold"
                  className="!min-h-[40px]"
                  disabled={claim.isPending}
                  aria-label={`${t('quests.claim')}: ${title}`}
                  onClick={() =>
                    claim.mutate(p.id, {
                      onSuccess: () => push(t('quests.received'), 'success'),
                      onError: (err) => push(errorMessage(t, err), 'error'),
                    })
                  }
                >
                  {t('quests.claim')}
                </Button>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
