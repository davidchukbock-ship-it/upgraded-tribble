import { useQuery } from '@tanstack/react-query';
import { useState } from 'react';
import type { TFunction } from 'i18next';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
import type { ShopItemDto } from '@tc/shared';
import { Crest } from '../../icons/Crest';
import { Icon } from '../../icons/Icon';
import { formatFull } from '../../lib/format';
import { useToasts } from '../../store/toast';
import { ArtIcon } from '../../art';
import { Badge, Button, ConfirmDialog, Panel } from '../../ui';
import { errorMessage } from '../auth/errors';
import { shopApi } from './api';
import { useCastleResultMutation } from './useProgress';

const CONFIRM_FROM = 100;

function itemName(t: TFunction, i: ShopItemDto): string {
  if (i.kind === 'crest') return t('shop.crestName', { name: t(`crest.${i.crest}`) });
  return t(`shop.item.${i.id}`);
}

function Price({ gems }: { gems: number }) {
  const { t } = useTranslation();
  return (
    <span
      className="flex items-center gap-1 font-bold"
      aria-label={`${gems} ${t('resource.gems')}`}
    >
      <ArtIcon name="gems" size={20} />
      {formatFull(gems)}
    </span>
  );
}

export function ShopPage() {
  const { t } = useTranslation();
  const push = useToasts((s) => s.push);
  const shop = useQuery({ queryKey: ['shop'], queryFn: shopApi.get, staleTime: 30_000 });
  const buy = useCastleResultMutation(shopApi.buy);
  const [asking, setAsking] = useState<ShopItemDto | null>(null);

  if (shop.isPending)
    return (
      <p role="status" className="pt-8 text-center font-display text-lg">
        {t('common.loading')}
      </p>
    );
  if (shop.isError || !shop.data)
    return (
      <Panel title={t('nav.shop')} className="mx-auto max-w-md text-center">
        <p className="pt-2">{t('errors.ERR_NETWORK')}</p>
        <Button className="mt-3" onClick={() => void shop.refetch()}>
          {t('common.retry')}
        </Button>
      </Panel>
    );
  const { items, gems } = shop.data;

  const purchase = (item: ShopItemDto) =>
    buy.mutate(item.id, {
      onSuccess: () => push(t('shop.bought', { name: itemName(t, item) }), 'success'),
      onError: (err) => push(errorMessage(t, err), 'error'),
    });
  const tryBuy = (item: ShopItemDto) =>
    item.price >= CONFIRM_FROM ? setAsking(item) : purchase(item);

  const section = (kind: ShopItemDto['kind'], title: string) => {
    const list = items.filter((i) => i.kind === kind);
    return (
      <Panel title={title}>
        <ul
          className={
            kind === 'crest'
              ? 'grid grid-cols-2 gap-3 pt-2 sm:grid-cols-5'
              : 'grid gap-3 pt-2 sm:grid-cols-3'
          }
        >
          {list.map((i) => {
            const name = itemName(t, i);
            const cant = gems < i.price;
            return (
              <li
                key={i.id}
                className="flex flex-col items-center gap-2 rounded-lg bg-black/25 p-3 text-center"
              >
                {i.kind === 'crest' ? (
                  <Crest crest={i.crest!} size={48} />
                ) : i.kind === 'slot' ? (
                  <Icon name="castle" size={36} />
                ) : i.kind === 'booster' ? (
                  <Icon name="clock" size={36} />
                ) : (
                  <Icon name="chest" size={36} />
                )}
                <p className="text-sm font-bold">{name}</p>
                {i.kind === 'pack' && i.resources && (
                  <p className="text-xs">
                    {t('reward.eachResource', { amount: formatFull(i.resources.gold) })}
                  </p>
                )}
                {i.owned ? (
                  <Badge tone="green">{t('shop.owned')}</Badge>
                ) : (
                  <>
                    <Price gems={i.price} />
                    <Button
                      variant="gold"
                      className="!min-h-[40px]"
                      disabled={cant || buy.isPending}
                      onClick={() => tryBuy(i)}
                      aria-label={`${t('shop.buy')}: ${name}`}
                    >
                      {cant ? t('shop.notEnough') : t('shop.buy')}
                    </Button>
                  </>
                )}
              </li>
            );
          })}
        </ul>
      </Panel>
    );
  };

  return (
    <div className="mx-auto flex max-w-4xl flex-col gap-6">
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="font-display text-2xl font-bold text-gold-light">{t('nav.shop')}</h1>
        <span className="ml-auto flex items-center gap-2" role="status">
          {t('shop.balance')}
          <Price gems={gems} />
        </span>
      </div>
      <p className="text-sm">
        {t('shop.note')}{' '}
        <Link to="/donate" className="font-bold text-gold-light underline">
          {t('nav.donate')}
        </Link>
      </p>
      {section('pack', t('shop.packs'))}
      {section('booster', t('shop.boosters'))}
      {section('slot', t('shop.slot'))}
      {section('crest', t('shop.crests'))}

      <ConfirmDialog
        open={asking !== null}
        tone="gold"
        confirmLabel={t('shop.buy')}
        title={t('shop.confirmTitle')}
        message={
          asking ? t('shop.confirmText', { name: itemName(t, asking), price: asking.price }) : ''
        }
        onCancel={() => setAsking(null)}
        onConfirm={() => {
          if (asking) purchase(asking);
          setAsking(null);
        }}
      />
    </div>
  );
}
