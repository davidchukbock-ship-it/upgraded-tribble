import { useTranslation } from 'react-i18next';
import type { ChestReward, RewardDto } from '@tc/shared';
import { Icon } from '../../icons/Icon';
import { formatFull } from '../../lib/format';
import { ArtIcon } from '../../art';

const RES = ['gold', 'wood', 'stone', 'food'] as const;

/** Награда одной строкой: ресурсы, кристаллы, сундук. Текст для скринридера — в aria-label каждой части. */
export function RewardView({ reward }: { reward: RewardDto }) {
  const { t } = useTranslation();
  const parts: Array<{ key: string; icon: React.ReactNode; text: string }> = [];
  if (reward.resources) {
    // Если всех ресурсов поровну — одна запись «по N каждого»
    const values = RES.map((k) => reward.resources![k]);
    if (values.every((v) => v === values[0]) && values[0]! > 0) {
      parts.push({
        key: 'res',
        icon: <ArtIcon name="gold" size={20} />,
        text: t('reward.eachResource', { amount: formatFull(values[0]!) }),
      });
    } else {
      for (const k of RES) {
        const v = reward.resources[k];
        if (v > 0)
          parts.push({
            key: k,
            icon: <ArtIcon name={k} size={20} />,
            text: `${formatFull(v)} ${t(`resource.${k}`)}`,
          });
      }
    }
  }
  if (reward.gems > 0)
    parts.push({
      key: 'gems',
      icon: <ArtIcon name="gems" size={20} />,
      text: `${formatFull(reward.gems)} ${t('resource.gems')}`,
    });
  if (reward.chest)
    parts.push({
      key: 'chest',
      icon: <Icon name="chest" size={20} />,
      text: t(`chest.kind.${reward.chest}`),
    });
  return (
    <ul className="flex flex-wrap gap-x-3 gap-y-1 text-sm">
      {parts.map((p) => (
        <li key={p.key} className="flex items-center gap-1.5">
          {p.icon}
          <span>{p.text}</span>
        </li>
      ))}
    </ul>
  );
}

/** Что выпало из сундука. */
export function ChestRewardText({ reward }: { reward: ChestReward }) {
  const { t } = useTranslation();
  switch (reward.type) {
    case 'resources':
      return <RewardView reward={{ resources: reward.resources, gems: 0, chest: null }} />;
    case 'gems':
      return <RewardView reward={{ resources: null, gems: reward.gems, chest: null }} />;
    case 'booster':
      return <p>{t(`booster.${reward.booster}`)}</p>;
    case 'gear':
      return (
        <p>
          {t(`hero.slot.${reward.slot}`)} ★{reward.rarity}
        </p>
      );
  }
}
