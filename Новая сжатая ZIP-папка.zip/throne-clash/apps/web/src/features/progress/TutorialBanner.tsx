import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
import type { QuestDto } from '@tc/shared';
import { useQuests } from './useProgress';

/** Текущий шаг туториала: первый, за который ещё не получена награда. */
export function useTutorialStep(): { quest: QuestDto; index: number; total: number } | null {
  const q = useQuests();
  const list = q.data?.tutorial;
  if (!list) return null;
  const index = list.findIndex((x) => !x.claimed);
  return index === -1 ? null : { quest: list[index]!, index, total: list.length };
}

/** Подсказка «что делать дальше» над содержимым страницы. */
export function TutorialBanner() {
  const { t } = useTranslation();
  const step = useTutorialStep();
  if (!step) return null;
  const { quest, index, total } = step;
  const title = t(`quests.item.${quest.id}`, { target: quest.target });
  return (
    <aside
      aria-label={t('tutorial.label')}
      className="panel-wood frame-pixel mb-4 flex flex-wrap items-center gap-x-4 gap-y-1 px-4 py-2 text-sm"
    >
      <span className="font-display font-bold text-gold-light">
        {t('tutorial.step', { n: index + 1, total })}
      </span>
      <span className="min-w-[12rem] flex-1">{title}</span>
      {quest.claimable ? (
        <Link
          to="/quests"
          className="rounded-lg bg-gold px-3 py-2 font-bold text-ink hover:brightness-110"
        >
          {t('tutorial.claim')}
        </Link>
      ) : quest.route ? (
        <Link
          to={quest.route}
          className="rounded-lg bg-black/30 px-3 py-2 font-bold text-gold-light hover:bg-black/45"
        >
          {t('quests.go')}
        </Link>
      ) : null}
    </aside>
  );
}
