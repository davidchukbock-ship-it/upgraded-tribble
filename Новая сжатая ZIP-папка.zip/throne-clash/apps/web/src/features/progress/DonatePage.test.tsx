import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { DONATE_PACKS, donateTotal, type DonateDto, type DonateMode } from '@tc/shared';
import { initI18n } from '../../lib/i18n';
import { useToasts } from '../../store/toast';
import { apiError, installFakeApi, json, makeCastle } from '../../test-utils/fake-api';
import { renderApp, resetAuth, signIn } from '../../test-utils/render';

beforeAll(async () => {
  await initI18n('ru');
});
beforeEach(() => {
  signIn();
  useToasts.setState({ items: [] });
});
afterEach(() => {
  resetAuth();
  vi.unstubAllGlobals();
});

const donateDto = (mode: DonateMode): DonateDto => ({
  mode,
  gems: 50,
  packs: DONATE_PACKS.map((p) => ({ ...p, total: donateTotal(p) })),
});

describe('магазин донатов', () => {
  it('оплата выключена: пакеты видны с ценами, но кнопки покупки недоступны', async () => {
    installFakeApi({ 'GET /api/donate': () => json(200, donateDto('off')) });
    renderApp('/donate');
    expect(await screen.findByRole('heading', { level: 1, name: 'Донат' })).toBeInTheDocument();
    expect(screen.getByText('Оплата пока не подключена')).toBeInTheDocument();
    const buttons = screen.getAllByRole('button', { name: /^Купить:/ });
    expect(buttons).toHaveLength(DONATE_PACKS.length);
    for (const b of buttons) expect(b).toBeDisabled();
    expect(screen.getByText('Популярный')).toBeInTheDocument();
    expect(screen.getByText('Лучшая цена')).toBeInTheDocument();
    expect(screen.getByText('+3 500 бонус')).toBeInTheDocument();
  });

  it('тестовый режим: подтверждение → запрос покупки → тост о начислении', async () => {
    const after = makeCastle({ gems: 50 + 80 });
    const { calls } = installFakeApi({
      'GET /api/donate': () => json(200, donateDto('test')),
      'POST /api/donate/buy': () => json(200, { castle: after, granted: 80 }),
    });
    renderApp('/donate');
    expect(await screen.findByText('Тестовый режим')).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: /^Купить: Горсть/ }));
    const dlg = await screen.findByRole('alertdialog');
    expect(within(dlg).getByText(/Пакет «Горсть»: 80 кристаллов/)).toBeInTheDocument();
    await userEvent.click(within(dlg).getByRole('button', { name: 'Купить' }));
    await waitFor(() =>
      expect(calls.find((c) => c.path === '/api/donate/buy')?.body).toEqual({ packId: 'gems_s' }),
    );
    await waitFor(() =>
      expect(useToasts.getState().items.some((i) => i.message.includes('80'))).toBe(true),
    );
  });

  it('отмена подтверждения ничего не отправляет', async () => {
    const { calls } = installFakeApi({ 'GET /api/donate': () => json(200, donateDto('test')) });
    renderApp('/donate');
    await userEvent.click(await screen.findByRole('button', { name: /^Купить: Ларец/ }));
    await userEvent.click(
      within(await screen.findByRole('alertdialog')).getByRole('button', { name: 'Отмена' }),
    );
    expect(calls.some((c) => c.method === 'POST')).toBe(false);
  });

  it('сервер отказал (оплата выключена) → сообщение об ошибке, а не тишина', async () => {
    installFakeApi({
      'GET /api/donate': () => json(200, donateDto('test')),
      'POST /api/donate/buy': () => apiError(403, 'payments_disabled'),
    });
    renderApp('/donate');
    await userEvent.click(await screen.findByRole('button', { name: /^Купить: Горсть/ }));
    await userEvent.click(
      within(await screen.findByRole('alertdialog')).getByRole('button', { name: 'Купить' }),
    );
    await waitFor(() => expect(useToasts.getState().items.length).toBeGreaterThan(0));
  });
});
