import {
  settleCastle,
  type BuildingKey,
  type BuildingLevels,
  type CastleDto,
  type PendingBuild,
  type ResourceMap,
} from '@tc/shared';

export interface ProjectedCastle {
  resources: ResourceMap;
  levels: BuildingLevels;
  /** Постройки, которые по расчёту уже завершились, а сервер об этом ещё не сообщил. */
  finishedIds: string[];
}

/**
 * Прогноз состояния замка на момент nowMs: та же функция, что на сервере (D-08).
 * Клиент только показывает счёт вперёд; факт всегда определяет ответ сервера.
 */
export function projectCastle(castle: CastleDto, nowMs: number): ProjectedCastle {
  const levels: BuildingLevels = {};
  for (const b of castle.buildings) if (b.level > 0) levels[b.key] = b.level;
  const tasks: PendingBuild[] = castle.tasks.map((t) => ({
    id: t.id,
    key: t.key as BuildingKey,
    toLevel: t.toLevel,
    finishesAtMs: Date.parse(t.finishesAt),
  }));
  const res = settleCastle(
    {
      resources: castle.resources,
      updatedAtMs: Date.parse(castle.serverTime),
      levels,
      tasks,
      worldSpeed: castle.worldSpeed,
    },
    nowMs,
  );
  return {
    resources: res.resources,
    levels: res.levels,
    finishedIds: res.completed.map((t) => t.id),
  };
}
