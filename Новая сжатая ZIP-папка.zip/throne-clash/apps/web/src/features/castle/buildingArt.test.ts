import { describe, expect, it } from 'vitest';
import { BUILDING_KEYS } from '@tc/shared';
import { BUILDING_KINDS } from '../../art2/buildings';
import { BUILDING_ART } from './buildingArt';

describe('BUILDING_ART', () => {
  it('ссылается только на существующие картинки', () => {
    for (const kind of Object.values(BUILDING_ART)) expect(BUILDING_KINDS).toContain(kind);
  });

  it('покрывает почти все здания города (без стен и территории)', () => {
    const missing = BUILDING_KEYS.filter((k) => !BUILDING_ART[k]);
    expect(missing.sort()).toEqual(['territory', 'walls']);
  });
});
