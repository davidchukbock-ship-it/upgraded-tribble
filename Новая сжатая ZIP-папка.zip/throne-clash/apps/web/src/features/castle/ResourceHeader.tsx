import { ResourceBar } from '../../ui';
import { useLiveCastle } from './useCastle';

/** Полоса ресурсов над игровыми экранами: цифры тикают вперёд по расчёту сервера. */
export function ResourceHeader() {
  const { castle, projected } = useLiveCastle();
  if (!castle || !projected) return <div className="h-11" aria-hidden="true" />;
  return (
    <div>
      <ResourceBar
        items={[
          { key: 'gold', amount: projected.resources.gold, cap: castle.caps.gold },
          { key: 'wood', amount: projected.resources.wood, cap: castle.caps.wood },
          { key: 'stone', amount: projected.resources.stone, cap: castle.caps.stone },
          { key: 'food', amount: projected.resources.food, cap: castle.caps.food },
          { key: 'gems', amount: castle.gems },
        ]}
      />
    </div>
  );
}
