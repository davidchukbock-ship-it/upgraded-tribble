import type { BuildingKey } from '@tc/shared';
import type { BuildingKind } from '../../art2/buildings';

/** Какая анимированная картинка (art2) показывает здание игры; у остальных её пока нет. */
export const BUILDING_ART: Partial<Record<BuildingKey, BuildingKind>> = {
  castle: 'fort',
  barracks: 'barracks',
  farm: 'mill',
  sawmill: 'sawmill',
  quarry: 'quarry',
  goldmine: 'goldmine',
  warehouse: 'market',
  forge: 'smithy',
  academy: 'tavern',
  hospital: 'hospital',
  fishery: 'fishery',
  diamondmine: 'gemmine',
  magetower: 'mage',
  archertower: 'archertower',
  ballistatower: 'archertower',
  stormtower: 'stormtower',
};
