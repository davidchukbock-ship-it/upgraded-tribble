import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { useTranslation } from 'react-i18next';
import { freeCells, type BuildingDto, type BuildTaskDto, type StructureKind } from '@tc/shared';
import { CityPanel } from './CityPanel';
import { Icon } from '../../icons/Icon';
import { useToasts } from '../../store/toast';
import { ArtIcon, NavArt, type NavArtName } from '../../art';
import { Button, ConfirmDialog, Panel, TimerProgress } from '../../ui';
import { errorMessage } from '../auth/errors';
import { castleApi } from './api';
import { BuildingCatalog } from './BuildingCatalog';
import { BuildingModal } from './BuildingModal';
import { useEra } from '../../store/era';
import { IsoScene } from './scene/IsoScene';
import { viewBox } from './scene/layout';
import { useCastleMutation, useLiveCastle, useNow } from './useCastle';

type PanelKey = 'queue' | 'city' | 'catalog';

function QueueItem({
  task,
  gems,
  now,
  onSpeedup,
  onCancel,
  busy,
  onDone,
}: {
  task: BuildTaskDto;
  gems: number;
  now: number;
  onSpeedup: () => void;
  onCancel: () => void;
  busy: boolean;
  onDone: () => void;
}) {
  const { t } = useTranslation();
  const remaining = Math.max(0, Math.ceil((Date.parse(task.finishesAt) - now) / 1000));
  const cost = Math.max(1, Math.ceil(remaining / 300));
  return (
    <li className="flex flex-wrap items-center gap-x-3 gap-y-2 rounded-lg bg-black/25 px-3 py-2">
      <span className="flex min-w-[9rem] items-center gap-2 font-display text-sm font-bold">
        <Icon name={task.key} size={20} />
        {t(`building.${task.key}`)} → {task.toLevel}
      </span>
      <TimerProgress
        className="min-w-[8rem] flex-1"
        label={t('castle.timerLabel', { name: t(`building.${task.key}`) })}
        startsAtMs={Date.parse(task.startedAt)}
        endsAtMs={Date.parse(task.finishesAt)}
        onDone={onDone}
      />
      <Button
        variant="gold"
        className="!min-h-[36px] !px-3 !py-1 text-sm"
        disabled={busy || gems < cost}
        onClick={onSpeedup}
      >
        <ArtIcon name="gems" size={20} />
        {t('castle.speedup', { gems: cost })}
      </Button>
      <Button
        variant="danger"
        className="!min-h-[36px] !px-3 !py-1 text-sm"
        disabled={busy}
        onClick={onCancel}
      >
        {t('castle.cancel')}
      </Button>
    </li>
  );
}

export function CastlePage() {
  const era = useEra((s) => s.era);
  const { t } = useTranslation();
  const push = useToasts((s) => s.push);
  const { castle, projected, isPending, isError, refetch } = useLiveCastle();
  const nowMs = useNow();
  const sceneRef = useRef<HTMLDivElement>(null);
  const centered = useRef(false);
  const ready = castle !== undefined;
  useEffect(() => {
    // На телефоне сцена шире экрана: при первом показе прокручиваем к центру (к замку)
    const el = sceneRef.current;
    if (el && ready && !centered.current) {
      el.scrollLeft = (el.scrollWidth - el.clientWidth) / 2;
      centered.current = true;
    }
  }, [ready]);
  const [selected, setSelected] = useState<BuildingDto['key'] | null>(null);
  const [cancelTask, setCancelTask] = useState<BuildTaskDto | null>(null);

  const onError = (err: unknown) => push(errorMessage(t, err), 'error');
  const upgrade = useCastleMutation(castleApi.upgrade);
  const speedup = useCastleMutation(castleApi.speedup);
  const cancel = useCastleMutation(castleApi.cancel);
  const unlock = useCastleMutation(() => castleApi.unlockSlot());
  const place = useCastleMutation(castleApi.placeStructure);
  const removeStructure = useCastleMutation(castleApi.removeStructure);
  const [placing, setPlacing] = useState<StructureKind | null>(null);
  const [panel, setPanel] = useState<PanelKey | null>(null);
  const [demolish, setDemolish] = useState<string | null>(null);
  const busy =
    upgrade.isPending ||
    speedup.isPending ||
    cancel.isPending ||
    unlock.isPending ||
    place.isPending ||
    removeStructure.isPending;

  // Esc выходит из режима расстановки
  useEffect(() => {
    if (!placing) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setPlacing(null);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [placing]);

  if (isPending) {
    return (
      <p role="status" className="pt-8 text-center font-display text-lg">
        {t('common.loading')}
      </p>
    );
  }
  if (isError || !castle || !projected) {
    return (
      <Panel title={t('nav.castle')} className="mx-auto max-w-md text-center">
        <p className="pt-2">{t('errors.ERR_NETWORK')}</p>
        <Button className="mt-3" onClick={() => void refetch()}>
          {t('common.retry')}
        </Button>
      </Panel>
    );
  }

  const selectedBuilding = castle.buildings.find((b) => b.key === selected) ?? null;
  const territory = projected.levels.territory ?? 0;
  const placeAt = (kind: StructureKind, x: number, y: number) =>
    place.mutate(
      { kind, x, y },
      {
        onError,
        onSuccess: (res) => {
          push(t('city.built', { name: t(`structure.${kind}`) }), 'success');
          // Остаёмся в режиме, пока хватает ресурсов и есть куда ставить
          const c = res.city.catalog.find((k) => k.kind === kind);
          if (!c || c.blocked !== null) setPlacing(null);
        },
      },
    );
  const autoPlace = () => {
    const cell = placing
      ? freeCells(territory, castle.city.structures, placing ?? undefined)[0]
      : undefined;
    if (placing && cell) placeAt(placing, cell.x, cell.y);
  };
  const prosperityLabel =
    castle.city.prosperity > 0 ? `+${Math.round(castle.city.prosperity * 1000) / 10}%` : undefined;
  const demolishing = castle.city.structures.find((s) => s.id === demolish) ?? null;
  const vb = viewBox(territory);
  const toggle = (p: PanelKey) => setPanel(panel === p ? null : p);

  const queueBlock = (
    <section aria-label={t('castle.queue')} className="flex flex-col gap-2">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="font-display text-sm font-bold text-gold-light">{t('castle.queue')}</p>
        <span className="text-sm">
          {t('castle.slots', { used: castle.slots.used, total: castle.slots.total })}
        </span>
        {castle.slots.canUnlock && (
          <Button
            variant="gold"
            className="!min-h-[36px] !px-3 !py-1 text-sm"
            disabled={busy || castle.gems < castle.slots.unlockCostGems}
            onClick={() =>
              unlock.mutate(undefined, {
                onError,
                onSuccess: () => push(t('castle.slotUnlocked'), 'success'),
              })
            }
          >
            <ArtIcon name="gems" size={20} />
            {t('castle.unlockSlot', { gems: castle.slots.unlockCostGems })}
          </Button>
        )}
      </div>
      {castle.tasks.length === 0 ? (
        <p className="text-sm text-parchment/90">{t('castle.emptyQueue')}</p>
      ) : (
        <ul className="flex flex-col gap-2">
          {castle.tasks.map((task) => (
            <QueueItem
              key={task.id}
              task={task}
              gems={castle.gems}
              now={nowMs}
              busy={busy}
              onDone={() => void refetch()}
              onSpeedup={() =>
                speedup.mutate(task.id, {
                  onError,
                  onSuccess: () =>
                    push(t('castle.builtNow', { name: t(`building.${task.key}`) }), 'success'),
                })
              }
              onCancel={() => setCancelTask(task)}
            />
          ))}
        </ul>
      )}
    </section>
  );

  const chip = (p: PanelKey, label: string, art: NavArtName, badge?: string) => (
    <Button
      variant={panel === p ? 'gold' : 'primary'}
      className="!min-h-[40px] !px-3"
      aria-pressed={panel === p}
      onClick={() => toggle(p)}
    >
      <NavArt name={art} size={22} />
      {label}
      {badge && <span className="rounded-full bg-black/35 px-1.5 text-xs">{badge}</span>}
    </Button>
  );

  // Экран замка — сама сцена на весь экран; управление лежит поверх лёгкими плашками
  return createPortal(
    <div
      className="fixed inset-x-0 bottom-0 top-[var(--hdr,0px)] z-20 md:top-0"
      style={{ background: 'linear-gradient(#5fb4e8, #2f7fc0)' }}
    >
      <h1 className="sr-only">{t('nav.castle')}</h1>

      <div ref={sceneRef} className="absolute inset-0 isolate overflow-auto overscroll-contain">
        <div
          className="mx-auto"
          style={{
            height: '100%',
            aspectRatio: `${vb.w} / ${vb.h}`,
            minWidth: Math.max(760, Math.round(vb.w * 0.55)),
          }}
        >
          <IsoScene
            key={era}
            castle={castle}
            levels={projected.levels}
            now={nowMs}
            onOpen={setSelected}
            structures={castle.city.structures}
            placing={placing}
            onPlace={(x, y) => placing && placeAt(placing, x, y)}
            onPickStructure={setDemolish}
          />
        </div>
      </div>

      <div className="absolute left-3 top-2 md:top-[calc(var(--hdr,4rem)+0.5rem)] z-10 flex flex-wrap gap-1.5">
        {chip('queue', t('castle.queue'), 'castle', `${castle.slots.used}/${castle.slots.total}`)}
        {chip('city', t('city.short'), 'guild', prosperityLabel)}
        {chip('catalog', t('castle.catalog'), 'uikit')}
      </div>

      {placing && (
        <div
          role="status"
          className="glass absolute left-1/2 top-[4.5rem] md:top-[calc(var(--hdr,4rem)+4.5rem)] z-20 flex w-[min(30rem,calc(100%-1.5rem))] -translate-x-1/2 flex-wrap items-center gap-2 px-3 py-2 text-sm"
        >
          <span className="min-w-0 flex-1">
            {t('city.placing', { name: t(`structure.${placing}`) })}
          </span>
          <Button variant="gold" className="!min-h-[36px] !px-3 !py-1" onClick={autoPlace}>
            {t('city.auto')}
          </Button>
          <Button className="!min-h-[36px] !px-3 !py-1" onClick={() => setPlacing(null)}>
            {t('city.cancel')}
          </Button>
        </div>
      )}

      {panel && !placing && (
        <div className="glass absolute left-3 top-[4.5rem] md:top-[calc(var(--hdr,4rem)+4.5rem)] z-20 max-h-[calc(100%-var(--hdr,4rem)-6rem)] w-[min(34rem,calc(100%-1.5rem))] overflow-auto p-3">
          {panel === 'queue' && queueBlock}
          {panel === 'city' && (
            <CityPanel
              city={castle.city}
              have={projected.resources}
              busy={busy}
              onChoose={(kind) => {
                setPlacing(kind);
                setPanel(null);
              }}
              onRemove={(kind) => {
                const last = [...castle.city.structures].reverse().find((s) => s.kind === kind);
                if (last) setDemolish(last.id);
              }}
            />
          )}
          {panel === 'catalog' && (
            <BuildingCatalog
              startOpen
              buildings={castle.buildings}
              building={(k) => projected.levels[k] ?? 0}
              onOpen={(k) => {
                setSelected(k);
                setPanel(null);
              }}
            />
          )}
        </div>
      )}

      {selectedBuilding && (
        <BuildingModal
          building={selectedBuilding}
          castle={castle}
          resources={projected.resources}
          busy={upgrade.isPending}
          onClose={() => setSelected(null)}
          onUpgrade={(b) =>
            upgrade.mutate(b.key, {
              onError,
              onSuccess: () => {
                setSelected(null);
                push(t('castle.queued', { name: t(`building.${b.key}`) }), 'success');
              },
            })
          }
        />
      )}

      <ConfirmDialog
        open={demolishing !== null}
        title={t('city.demolishTitle')}
        message={
          demolishing ? t('city.demolishText', { name: t(`structure.${demolishing.kind}`) }) : ''
        }
        confirmLabel={t('city.remove')}
        onCancel={() => setDemolish(null)}
        onConfirm={() => {
          const s = demolishing;
          setDemolish(null);
          if (s) removeStructure.mutate(s.id, { onError });
        }}
      />

      <ConfirmDialog
        open={cancelTask !== null}
        title={t('castle.cancelTitle')}
        message={t('castle.cancelText')}
        confirmLabel={t('castle.cancel')}
        onCancel={() => setCancelTask(null)}
        onConfirm={() => {
          const task = cancelTask;
          setCancelTask(null);
          if (task) cancel.mutate(task.id, { onError });
        }}
      />
    </div>,
    document.body,
  );
}
