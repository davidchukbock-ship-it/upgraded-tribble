import { useTranslation } from 'react-i18next';
import { RESOURCE_KEYS, type ResourceMap } from '@tc/shared';
import { ArtIcon } from '../../art';
import { cn } from '../../lib/cn';
import { formatFull } from '../../lib/format';

/** Стоимость: недостающее подсвечено красным (и словом для скринридера — цвет не единственный признак). */
export function CostList({ cost, have }: { cost: ResourceMap; have: ResourceMap }) {
  const { t } = useTranslation();
  return (
    <ul className="flex flex-wrap gap-2">
      {RESOURCE_KEYS.filter((r) => cost[r] > 0).map((r) => {
        const lacking = Math.floor(have[r]) < cost[r];
        return (
          <li
            key={r}
            className={cn(
              'flex items-center gap-1.5 rounded-full border-2 px-2.5 py-1 text-sm font-semibold',
              lacking ? 'border-red bg-red/10 text-red' : 'border-wood-light/60',
            )}
          >
            <ArtIcon name={r} size={22} />
            <span>{formatFull(cost[r])}</span>
            <span className="sr-only">
              {t(`resource.${r}`)}
              {lacking ? `, ${t('castle.lacking')}` : ''}
            </span>
          </li>
        );
      })}
    </ul>
  );
}
