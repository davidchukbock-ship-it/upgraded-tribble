import { useTranslation } from 'react-i18next';
import {
  BUILDING_CLASS,
  PRODUCER_OF,
  RESOURCE_KEYS,
  fisheryFood,
  gemsPerHour,
  mageHeroXpBonus,
  mageResearchBonus,
  productionPerHour,
  shortfall,
  warehouseCap,
  type BuildingDto,
  type CastleDto,
  type ResourceKey,
  type ResourceMap,
} from '@tc/shared';
import { formatDurationT } from '../../lib/duration';
import { formatFull } from '../../lib/format';
import { Badge, Button, ScrollModal } from '../../ui';
import { AnimatedBuilding } from '../../art2/AnimatedBuilding';
import { BUILDING_ART } from './buildingArt';
import { CostList } from './CostList';

interface Props {
  building: BuildingDto;
  castle: CastleDto;
  /** Прогноз запасов на сейчас — от него зависит, хватает ли ресурсов. */
  resources: ResourceMap;
  busy: boolean;
  onUpgrade: (b: BuildingDto) => void;
  onClose: () => void;
}

/** Ресурс, который производит здание (если это производитель). */
const producedBy = (key: BuildingDto['key']): ResourceKey | undefined =>
  RESOURCE_KEYS.find((r) => PRODUCER_OF[r] === key);

export function BuildingModal({ building, castle, resources, busy, onUpgrade, onClose }: Props) {
  const { t } = useTranslation();
  const { key, level, nextLevel, cost, seconds, blocked, missing: needs } = building;
  const name = t(`building.${key}`);
  const produced = producedBy(key);
  const slotsFull = castle.slots.used >= castle.slots.total;
  const missing = cost ? shortfall(resources, cost) : {};
  const lacking = Object.keys(missing).length > 0;

  // Одна причина недоступности, самая важная; иначе — кнопка активна
  let reason: string | null = null;
  if (blocked === 'max_level') reason = t('castle.blocked.max_level');
  else if (blocked === 'in_progress') reason = t('castle.blocked.in_progress');
  else if (blocked === 'requires') reason = t('castle.blocked.requires');
  else if (blocked === 'castle_level')
    reason = t('castle.blocked.castle_level', { level: nextLevel ?? 0 });
  else if (slotsFull) reason = t('castle.blocked.slots_full');
  else if (lacking) reason = t('castle.blocked.lacking');

  const pctOf = (v: number): string => String(Math.round(v * 1000) / 10);
  const effect = (lvl: number): string | null => {
    if (produced)
      return `+${formatFull(productionPerHour(produced, lvl, castle.worldSpeed))}/${t('castle.perHour')}`;
    if (key === 'warehouse') return formatFull(warehouseCap(Math.max(1, lvl)));
    if (lvl < 1) return null;
    switch (key) {
      case 'fishery':
        return t('castle.effect.food', { value: formatFull(fisheryFood(lvl, castle.worldSpeed)) });
      case 'diamondmine':
        return t('castle.effect.gems', {
          value: (Math.round(gemsPerHour(lvl, castle.worldSpeed) * 10) / 10).toFixed(1),
        });
      case 'magetower':
        return `${t('castle.effect.research', { value: pctOf(mageResearchBonus(lvl)) })}, ${t('castle.effect.heroXp', { value: pctOf(mageHeroXpBonus(lvl)) })}`;
      case 'archertower':
        return t('castle.effect.defense', { value: pctOf(0.01 * lvl) });
      case 'ballistatower':
        return t('castle.effect.defenseCav', { value: pctOf(0.016 * lvl) });
      case 'stormtower':
        return t('castle.effect.defense', { value: pctOf(0.009 * lvl) });
      case 'territory':
        return t('castle.effect.island', { w: 20 + 4 * lvl, d: 19 + 4 * lvl });
      default:
        return null;
    }
  };
  const labelOf = (m: (typeof needs)[number]): string =>
    m.kind === 'territory'
      ? t('castle.requires.territory', { level: m.level })
      : m.kind === 'castle'
        ? t('castle.requires.castle', { level: m.level })
        : t('castle.requires.building', { name: t(`building.${m.key}`), level: m.level });
  const cur = level > 0 ? effect(level) : null;
  const next = nextLevel ? effect(nextLevel) : null;

  return (
    <ScrollModal
      open
      title={name}
      onClose={onClose}
      footer={
        nextLevel && (
          <Button
            variant="gold"
            disabled={reason !== null}
            loading={busy}
            onClick={() => onUpgrade(building)}
          >
            {level === 0 ? t('castle.build') : t('castle.upgradeTo', { level: nextLevel })}
          </Button>
        )
      }
    >
      {BUILDING_ART[key] && (
        <div className="mb-2 flex justify-center" data-testid="building-art">
          <AnimatedBuilding kind={BUILDING_ART[key]!} seed={level + 3} size={240} fps={24} />
        </div>
      )}
      <p className="mb-2">
        <Badge tone="stone">{t(`castle.class.${BUILDING_CLASS[key]}`)}</Badge>
      </p>
      <p className="text-sm">{t(`building.desc.${key}`)}</p>
      <dl className="mt-3 grid grid-cols-[auto_1fr] gap-x-4 gap-y-1 text-sm">
        <dt className="font-bold">{t('common.level')}</dt>
        <dd>
          {level}
          {nextLevel && ` → ${nextLevel}`}
        </dd>
        {(cur || next) && (
          <>
            <dt className="font-bold">
              {produced || key === 'warehouse'
                ? produced
                  ? t('castle.production')
                  : t('castle.capacity')
                : t('castle.effectLabel')}
            </dt>
            <dd>{[cur ?? '—', next].filter(Boolean).join(' → ')}</dd>
          </>
        )}
        {seconds !== null && (
          <>
            <dt className="font-bold">{t('castle.time')}</dt>
            <dd>{formatDurationT(t, seconds)}</dd>
          </>
        )}
      </dl>
      {cost && nextLevel && (
        <div className="mt-3">
          <p className="mb-1 font-display text-sm font-bold">{t('castle.cost')}</p>
          <CostList cost={cost} have={resources} />
        </div>
      )}
      {level === 0 && needs.length > 0 && (
        <div className="mt-3">
          <p className="mb-1 font-display text-sm font-bold">{t('castle.requires.title')}</p>
          <ul className="flex flex-col gap-1 text-sm">
            {needs.map((m) => (
              <li key={`${m.kind}-${'key' in m ? m.key : ''}`} className="text-red">
                ✕ {labelOf(m)}
              </li>
            ))}
          </ul>
        </div>
      )}
      {reason && (
        <p role="status" className="mt-3 text-sm font-semibold text-red">
          {reason}
        </p>
      )}
    </ScrollModal>
  );
}
