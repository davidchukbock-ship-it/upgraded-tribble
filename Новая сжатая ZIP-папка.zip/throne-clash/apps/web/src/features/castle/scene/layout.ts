import {
  BUILDING_REQUIRES,
  FOOTPRINT,
  GATE_X,
  ISLAND,
  MAX_TERRITORY,
  PLACEMENT,
  ROAD_COLS,
  ROAD_ROWS,
  TERRITORY_STEP,
  islandSize,
  type PlacedKey,
} from '@tc/shared';
import { iso, type P2 } from '../../../iso/project';

export { tierOf } from '../../../iso/tier';
export {
  GATE_X,
  ISLAND,
  MAX_TERRITORY,
  PLACEMENT,
  ROAD_COLS,
  ROAD_ROWS,
  TERRITORY_STEP,
  islandSize,
};

/** Уровень Земель, с которого участок здания входит в остров. */
export const plotTerritory = (key: PlacedKey): number => BUILDING_REQUIRES[key]?.territory ?? 0;

/** Насколько здание возвышается над землёй (для области нажатия). */
const HEIGHT: Record<PlacedKey, number> = {
  castle: 240,
  farm: 120,
  goldmine: 140,
  sawmill: 90,
  quarry: 110,
  warehouse: 80,
  forge: 130,
  academy: 190,
  hospital: 90,
  barracks: 100,
  fishery: 70,
  diamondmine: 120,
  magetower: 190,
  archertower: 150,
  ballistatower: 140,
  stormtower: 200,
};

const HIT_HEIGHT_SHARE = 0.45;

/** Область нажатия здания в координатах рисунка. */
export function buildingBox(key: PlacedKey): { x: number; y: number; w: number; h: number } {
  const p = PLACEMENT[key];
  const f = FOOTPRINT[key];
  const corners: P2[] = [
    iso(p.x, p.y + f.d, 0),
    iso(p.x + f.w, p.y, 0),
    iso(p.x + f.w, p.y + f.d, 0),
    // Верх области — лишь часть высоты: иначе шпили высоких зданий перекрывают соседей позади
    iso(p.x, p.y, HEIGHT[key] * HIT_HEIGHT_SHARE),
  ];
  const xs = corners.map((c) => c[0]);
  const ys = corners.map((c) => c[1]);
  return {
    x: Math.min(...xs),
    y: Math.min(...ys),
    w: Math.max(...xs) - Math.min(...xs),
    h: Math.max(...ys) - Math.min(...ys),
  };
}

/** Габариты рисунка: остров, стены, высокие башни сверху и небольшой запас воды вокруг. */
export function viewBox(territory = 0): { x: number; y: number; w: number; h: number } {
  // Показываем и следующий (ещё закрытый) слой земель, чтобы было видно, куда расти
  const size = islandSize(Math.min(MAX_TERRITORY, territory + 1));
  const left = iso(0, size.d)[0] - 70;
  const right = iso(size.w, 0)[0] + 70;
  const top = -215;
  const bottom = iso(size.w, size.d)[1] + 34 + 70;
  return { x: left, y: top, w: right - left, h: bottom - top };
}

/** Жители, которые ходят по дорогам (клетки). */
export const WALKERS: ReadonlyArray<{
  id: string;
  npc:
    | 'peasant'
    | 'farmer'
    | 'guard'
    | 'scholar'
    | 'blacksmith'
    | 'merchant'
    | 'captain'
    | 'healer'
    | 'elder';
  from: readonly [number, number];
  to: readonly [number, number];
  seconds: number;
}> = [
  { id: 'peasant', npc: 'peasant', from: [12.5, 18], to: [12.5, 6], seconds: 14 },
  { id: 'guard', npc: 'guard', from: [1.6, 5.5], to: [18, 5.5], seconds: 22 },
  { id: 'merchant', npc: 'merchant', from: [1.8, 11.5], to: [18, 11.5], seconds: 20 },
  { id: 'farmer', npc: 'farmer', from: [5.5, 5.6], to: [5.5, 10.6], seconds: 9 },
  { id: 'captain', npc: 'captain', from: [12.5, 12], to: [12.5, 16.5], seconds: 7 },
  { id: 'scholar', npc: 'scholar', from: [5.5, 11.8], to: [5.5, 16], seconds: 8 },
  { id: 'healer', npc: 'healer', from: [13.2, 11.5], to: [17, 11.5], seconds: 7 },
  { id: 'smith', npc: 'blacksmith', from: [13, 6], to: [13, 10.6], seconds: 8 },
];
