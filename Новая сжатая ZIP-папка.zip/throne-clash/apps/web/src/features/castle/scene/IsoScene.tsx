import { useMemo, type CSSProperties, type KeyboardEvent, type ReactNode } from 'react';
import { useTranslation } from 'react-i18next';
import {
  PRODUCER_OF,
  RESOURCE_KEYS,
  type BuildingKey,
  type BuildingLevels,
  freeCells,
  type CastleDto,
  type PlacedStructure,
  type ResourceKey,
  type StructureKind,
} from '@tc/shared';
import { IsoStructure } from '../../../iso/structures';
import { Ambient } from '../../../iso/ambient';
import { NpcArt } from '../../../art';
import { formatDurationT } from '../../../lib/duration';
import { formatFull } from '../../../lib/format';
import { useEra } from '../../../store/era';
import { useGfx } from '../../../store/gfx';
import { SceneBuilding, spriteScale } from '../../../art2/SceneBuilding';
import { SceneTree } from '../../../art2/SceneTree';
import { RESIDENT_CHIBI, SceneChibi } from '../../../art2/SceneChibi';
import { BUILDING_ART } from '../buildingArt';
import { FOOTPRINT, IsoBuilding, type PlacedKey } from '../../../iso/buildings';
import { iso, pts } from '../../../iso/project';
import { Box, PAL, Tower, faces } from '../../../iso/primitives';
import {
  Cobble,
  IsoDefs,
  IsoFlowers,
  IsoFountain,
  IsoLamp,
  IsoRock,
  IsoTree,
  roll,
} from '../../../iso/props';
import {
  GATE_X,
  MAX_TERRITORY,
  PLACEMENT,
  ROAD_COLS,
  ROAD_ROWS,
  WALKERS,
  buildingBox,
  islandSize,
  plotTerritory,
  tierOf,
  viewBox,
} from './layout';

interface SceneProps {
  castle: Pick<CastleDto, 'tasks' | 'ratesPerHour'>;
  /** Уровни с учётом расчёта на «сейчас» (достроенное уже отображается). */
  levels: BuildingLevels;
  now: number;
  onOpen: (key: BuildingKey) => void;
  /** Постройки города на свободных клетках (D-66). */
  structures?: readonly PlacedStructure[];
  /** Режим расстановки: выбранный вид, свободные клетки подсвечены и нажимаются. */
  placing?: StructureKind | null;
  onPlace?: (x: number, y: number) => void;
  onPickStructure?: (id: string) => void;
}

const RATE_OF: Partial<Record<BuildingKey, ResourceKey>> = Object.fromEntries(
  RESOURCE_KEYS.map((r) => [PRODUCER_OF[r], r]),
);

interface Box2 {
  x: number;
  y: number;
  w: number;
  h: number;
}

function Hotspot({
  kind,
  box,
  vb,
  level,
  castle,
  now,
  onOpen,
}: {
  kind: BuildingKey;
  box: Box2;
  vb: Box2;
  level: number;
  castle: Pick<CastleDto, 'tasks' | 'ratesPerHour'>;
  now: number;
  onOpen: (key: BuildingKey) => void;
}) {
  const { t } = useTranslation();
  const name = t(`building.${kind}`);
  const task = castle.tasks.find((x) => x.key === kind);
  const built = level > 0;
  const resource = RATE_OF[kind];
  const rate = resource ? castle.ratesPerHour[resource] : null;
  const second = !built
    ? t('castle.notBuilt')
    : rate !== null
      ? `+${formatFull(rate)}/${t('castle.perHour')}`
      : '';
  const remaining = task ? Math.max(0, Math.ceil((Date.parse(task.finishesAt) - now) / 1000)) : 0;
  const label = [
    name,
    built ? `${t('common.level')} ${level}` : t('castle.notBuilt'),
    task ? t('castle.blocked.in_progress') : null,
  ]
    .filter(Boolean)
    .join(', ');
  const onKey = (e: KeyboardEvent) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      onOpen(kind);
    }
  };
  const pct = (v: number, total: number): string => `${(v / total) * 100}%`;
  return (
    <div
      role="button"
      tabIndex={0}
      aria-label={label}
      className="hotspot group"
      style={{
        left: pct(box.x - vb.x, vb.w),
        top: pct(box.y - vb.y, vb.h),
        width: pct(box.w, vb.w),
        height: pct(box.h, vb.h),
        // Ближние здания выше дальних: нажатие достаётся тому, кто нарисован сверху
        zIndex: Math.max(1, Math.round(box.y + box.h - vb.y)),
      }}
      onClick={() => onOpen(kind)}
      onKeyDown={onKey}
    >
      <span className="sr-only">{second}</span>
      {built && !task && <span className="hotspot-badge">{level}</span>}
      {!built && !task && <span className="hotspot-badge hotspot-plus">+</span>}
      {task && <span className="hotspot-timer">{formatDurationT(t, remaining)}</span>}
      <span className="hotspot-label" aria-hidden="true">
        <b>{name}</b>
        {second && <i>{second}</i>}
      </span>
    </div>
  );
}

/** Море вокруг острова: градиент, блики волн и тень острова. */
function Sea({ vb, W, D }: { vb: Box2; W: number; D: number }) {
  const waves = useMemo(
    () =>
      Array.from({ length: 46 }, (_, i) => ({
        x: vb.x + roll(i, 1, 'wx') * vb.w,
        y: vb.y + vb.h * (0.35 + roll(i, 2, 'wy') * 0.65),
        s: 0.7 + roll(i, 3, 'ws') * 0.9,
        d: roll(i, 4, 'wd') * 3,
      })),
    [vb.x, vb.y, vb.w, vb.h],
  );
  const A = iso(0, 0);
  const B = iso(W, 0);
  const C = iso(W, D);
  const Dd = iso(0, D);
  return (
    <g>
      <rect x={vb.x} y={vb.y} width={vb.w} height={vb.h} fill="url(#ig-sea)" />
      {waves.map((w, i) => (
        <path
          key={i}
          className="scene-wave"
          style={{ animationDelay: `${w.d}s` }}
          d={`M${w.x} ${w.y}q${9 * w.s} -6 ${18 * w.s} 0 ${9 * w.s} 6 ${18 * w.s} 0`}
          fill="none"
          stroke="#fff"
          strokeWidth="2"
          strokeLinecap="round"
          opacity=".5"
        />
      ))}
      <polygon
        points={pts([
          [A[0], A[1] + 46],
          [B[0] + 26, B[1] + 56],
          [C[0], C[1] + 92],
          [Dd[0] - 26, Dd[1] + 56],
        ])}
        fill="#123a5a"
        opacity=".28"
      />
    </g>
  );
}

/** Остров: земляные борта с камнями и травяная поверхность из клеток. */
function Island({ W, D }: { W: number; D: number }) {
  const A = iso(0, 0);
  const B = iso(W, 0);
  const C = iso(W, D);
  const Dd = iso(0, D);
  const thick = 34;
  const tiles = useMemo(() => {
    const out: ReactNode[] = [];
    for (let y = 0; y < D; y++)
      for (let x = 0; x < W; x++) {
        const r = roll(x, y, 'g');
        const fill =
          (x + y) % 2 ? (r < 0.5 ? '#77bb58' : '#6fb352') : r < 0.5 ? '#6cb04f' : '#65a84a';
        out.push(
          <polygon
            key={`${x}-${y}`}
            points={pts([iso(x, y), iso(x + 1, y), iso(x + 1, y + 1), iso(x, y + 1)])}
            fill={fill}
          />,
        );
        if (r > 0.72) {
          const [sx, sy] = iso(x + 0.3 + r * 0.3, y + 0.5);
          out.push(
            <path
              key={`t${x}-${y}`}
              d={`M${sx} ${sy}l-2 -6M${sx} ${sy}l1 -8M${sx} ${sy}l4 -5`}
              stroke="#4d8f3f"
              strokeWidth="1.800"
              strokeLinecap="round"
              fill="none"
            />,
          );
        }
      }
    return out;
  }, [W, D]);
  const rocks = useMemo(
    () =>
      Array.from({ length: 16 }, (_, i) => ({
        t: (i + 0.5) / 16,
        s: 5 + roll(i, 9, 'rs') * 6,
        side: i % 2,
      })),
    [],
  );
  return (
    <g strokeLinejoin="round">
      <polygon
        points={pts([Dd, C, [C[0], C[1] + thick], [Dd[0], Dd[1] + thick]])}
        fill="url(#ig-soil)"
        stroke="#3a2412"
        strokeWidth="1.6"
      />
      <polygon
        points={pts([B, C, [C[0], C[1] + thick], [B[0], B[1] + thick]])}
        fill="url(#ig-soil-r)"
        stroke="#3a2412"
        strokeWidth="1.6"
      />
      {rocks.map((r, i) => {
        const p = r.side ? iso(r.t * W, D, 0) : iso(W, r.t * D, 0);
        return (
          <ellipse
            key={i}
            cx={p[0]}
            cy={p[1] + 14 + (i % 3) * 5}
            rx={r.s}
            ry={r.s * 0.6}
            fill={r.side ? '#8e7250' : '#6a5238'}
            opacity=".8"
          />
        );
      })}
      <polygon points={pts([A, B, C, Dd])} fill="#6cb04f" stroke="#3f7a35" strokeWidth="2.400" />
      {tiles}
      {/* травяной бортик по краю */}
      <polyline points={pts([Dd, C, B])} fill="none" stroke="#8fd06a" strokeWidth="4" />
    </g>
  );
}

/** Дороги и площадь. */
function Roads({ W, D }: { W: number; D: number }) {
  const tiles: ReactNode[] = [];
  const road = new Set<string>();
  for (const y of ROAD_ROWS) for (let x = 1; x < W - 1; x++) road.add(`${x}-${y}`);
  for (const x of ROAD_COLS) for (let y = ROAD_ROWS[0]!; y < D; y++) road.add(`${x}-${y}`);
  for (const key of road) {
    const [x, y] = key.split('-').map(Number) as [number, number];
    tiles.push(<Cobble key={key} x={x} y={y} tone={roll(x, y, 'c')} />);
  }
  return <g>{tiles}</g>;
}

const WALL_H = 34;

/**
 * Участок каменной стены между «опорами»: тело с кладкой, зубцы по внешнему краю и опора-контрфорс
 * каждые 2,5 клетки. С ростом ступени добавляются знамёна и башни на серединах стен.
 */
/** Современная эпоха: башни стен со вздутой плоской крышей вместо шпилей. Сцена пересоздаётся при смене эпохи. */
const rise = (n: number): number => (useEra.getState().era === 'modern' ? 5 : n);

function WallRun({
  axis,
  fixed,
  from,
  to,
  tier,
  outer,
}: {
  axis: 'x' | 'y';
  fixed: number;
  from: number;
  to: number;
  tier: number;
  outer: 'min' | 'max';
}) {
  const H = WALL_H + tier * 4;
  const T = 0.36;
  const step = 2.5;
  const n = Math.max(1, Math.round((to - from) / step));
  const len = (to - from) / n;
  const out: ReactNode[] = [];
  for (let i = 0; i < n; i++) {
    const a = from + i * len;
    const bodyX =
      axis === 'x' ? { x: a, y: fixed, w: len, d: T } : { x: fixed, y: a, w: T, d: len };
    out.push(<Box key={`b${i}`} {...bodyX} h={H} c={PAL.stone} bricks="stone" />);
    // зубцы: маленькие блоки через один вдоль внешнего края
    const crenels = Math.round(len / 0.4);
    for (let c = 0; c < crenels; c += 2) {
      const t = a + (c / crenels) * len;
      const w = len / crenels;
      const pos =
        axis === 'x'
          ? { x: t, y: outer === 'min' ? fixed : fixed + T - 0.1, w, d: 0.1 }
          : { x: outer === 'min' ? fixed : fixed + T - 0.1, y: t, w: 0.1, d: w };
      out.push(<Box key={`c${i}-${c}`} {...pos} h={7} z={H} c={PAL.stone} />);
    }
  }
  for (let i = 0; i <= n; i++) {
    const t = from + i * len - 0.22;
    const pos =
      axis === 'x'
        ? { x: t, y: fixed - 0.07, w: 0.44, d: 0.5 }
        : { x: fixed - 0.07, y: t, w: 0.5, d: 0.44 };
    out.push(<Box key={`p${i}`} {...pos} h={H + 8} c={PAL.stoneDark} bricks="stone" />);
    if (tier >= 1 && i % 2 === 1 && i < n) {
      const fx = axis === 'x' ? t + 0.22 : fixed + 0.18;
      const fy = axis === 'x' ? fixed + 0.18 : t + 0.22;
      out.push(
        <WallBanner
          key={`f${i}`}
          x={fx}
          y={fy}
          z={H + 8}
          color={tier >= 2 ? '#e0b030' : '#c0392b'}
        />,
      );
    }
  }
  return <>{out}</>;
}

function WallBanner({ x, y, z, color }: { x: number; y: number; z: number; color: string }) {
  const [sx, sy] = iso(x, y, z);
  return (
    <g>
      <line
        x1={sx}
        y1={sy}
        x2={sx}
        y2={sy - 20}
        stroke="#4a2c14"
        strokeWidth="2"
        strokeLinecap="round"
      />
      <path
        className="scene-flag"
        d={`M${sx} ${sy - 20}q7 -2 13 1 -3 4 0 8 -6 -2 -13 1Z`}
        fill={color}
        stroke="#3a1a0a"
        strokeWidth="1"
        strokeLinejoin="round"
      />
    </g>
  );
}

/** Сторожевая башня на середине стены (с третьей ступени). */
function MidTower({ x, y, tier, id }: { x: number; y: number; tier: number; id: string }) {
  const roof = [PAL.redRoof, PAL.blueRoof, PAL.purpleRoof, PAL.goldRoof][tier]!;
  return (
    <Tower
      cx={x}
      cy={y}
      r={0.5}
      h={64 + tier * 8}
      c={PAL.stone}
      roof={roof}
      roofRise={rise(28)}
      id={id}
    />
  );
}

/** Стены по краю острова: частокол (нулевой уровень) или каменные с опорами, знамёнами и башнями. */
function WallBack({ level, W, D }: { level: number; W: number; D: number }) {
  const tier = tierOf(level);
  const roof = [PAL.redRoof, PAL.blueRoof, PAL.purpleRoof, PAL.goldRoof][tier]!;
  if (level < 1)
    return (
      <g>
        {Array.from({ length: W * 2 }, (_, i) => (
          <Stake key={`a${i}`} x={i / 2 + 0.15} y={0.1} />
        ))}
        {Array.from({ length: D * 2 }, (_, i) => (
          <Stake key={`b${i}`} x={0.1} y={i / 2 + 0.15} />
        ))}
      </g>
    );
  return (
    <g>
      <WallRun axis="x" fixed={0} from={0.4} to={W - 0.4} tier={tier} outer="min" />
      <WallRun axis="y" fixed={0} from={0.4} to={D - 0.4} tier={tier} outer="min" />
      <Tower
        cx={0.3}
        cy={0.3}
        r={0.6}
        h={78 + tier * 8}
        c={PAL.stone}
        roof={roof}
        roofRise={rise(36)}
        id="tw-back"
      />
      {tier >= 2 && <MidTower x={W / 2} y={0.2} tier={tier} id="tw-mb1" />}
      {tier >= 2 && <MidTower x={0.2} y={D / 2} tier={tier} id="tw-mb2" />}
    </g>
  );
}

function Stake({ x, y }: { x: number; y: number }) {
  const [sx, sy] = iso(x, y, 0);
  return (
    <g>
      <path
        d={`M${sx - 4} ${sy}V${sy - 24}L${sx} ${sy - 32}L${sx + 4} ${sy - 24}V${sy}Z`}
        fill="#a8763c"
        stroke="#4a2c14"
        strokeWidth="1.200"
        strokeLinejoin="round"
      />
      <path d={`M${sx - 4} ${sy}V${sy - 24}L${sx} ${sy - 32}V${sy}Z`} fill="#c99a5b" />
    </g>
  );
}

function WallFront({ level, W, D }: { level: number; W: number; D: number }) {
  const tier = tierOf(level);
  const roof = [PAL.redRoof, PAL.blueRoof, PAL.purpleRoof, PAL.goldRoof][tier]!;
  const gw = 1.7;
  const g0 = GATE_X - gw / 2;
  const g1 = GATE_X + gw / 2;
  if (level < 1)
    return (
      <g>
        {Array.from({ length: W * 2 }, (_, i) =>
          i / 2 + 0.15 < g0 || i / 2 + 0.15 > g1 ? (
            <Stake key={`a${i}`} x={i / 2 + 0.15} y={D - 0.1} />
          ) : null,
        )}
        {Array.from({ length: D * 2 }, (_, i) => (
          <Stake key={`b${i}`} x={W - 0.1} y={i / 2 + 0.15} />
        ))}
        <Box
          x={g0}
          y={D - 0.35}
          w={gw}
          d={0.3}
          h={34}
          c={faces('#7a4a24')}
          bricks="wood"
          left={(len) => <path d={`M${len / 2} 0V34`} stroke="#2a1a0e" strokeWidth="2" />}
        />
      </g>
    );
  return (
    <g>
      <WallRun axis="x" fixed={D - 0.36} from={0.4} to={g0} tier={tier} outer="max" />
      <WallRun axis="x" fixed={D - 0.36} from={g1} to={W - 0.4} tier={tier} outer="max" />
      <WallRun axis="y" fixed={W - 0.36} from={0.4} to={D - 0.4} tier={tier} outer="max" />
      {/* сторожка над воротами */}
      <Box
        x={g0 - 0.3}
        y={D - 0.75}
        w={gw + 0.6}
        d={0.75}
        h={62 + tier * 6}
        c={PAL.stone}
        bricks="stone"
        left={(len) => (
          <g>
            <path d={`M${len / 2 - 20} 0V24a20 20 0 0 1 40 0V0Z`} fill="#1a0f08" />
            <path
              d={`M${len / 2 - 20} 10H${len / 2 + 20}M${len / 2 - 20} 20H${len / 2 + 20}M${len / 2} 0V44`}
              stroke="#6a5a4a"
              strokeWidth="2"
            />
          </g>
        )}
      />
      <WallBanner
        x={GATE_X}
        y={D - 0.4}
        z={62 + tier * 6}
        color={tier >= 2 ? '#e0b030' : '#c0392b'}
      />
      <Tower
        cx={0.3}
        cy={D - 0.3}
        r={0.6}
        h={82 + tier * 8}
        c={PAL.stone}
        roof={roof}
        roofRise={rise(36)}
        id="tw-l"
      />
      <Tower
        cx={W - 0.3}
        cy={D - 0.3}
        r={0.6}
        h={82 + tier * 8}
        c={PAL.stone}
        roof={roof}
        roofRise={rise(36)}
        id="tw-f"
      />
      <Tower
        cx={W - 0.3}
        cy={0.3}
        r={0.6}
        h={78 + tier * 8}
        c={PAL.stone}
        roof={roof}
        roofRise={rise(36)}
        id="tw-r"
      />
      {tier >= 2 && <MidTower x={W - 0.2} y={D / 2} tier={tier} id="tw-mf1" />}
      {tier >= 2 && <MidTower x={W / 2 + 4} y={D - 0.2} tier={tier} id="tw-mf2" />}
    </g>
  );
}

const TREES: ReadonlyArray<{
  x: number;
  y: number;
  k: 'oak' | 'pine' | 'bush' | 'birch';
  s?: number;
}> = [
  { x: 0.9, y: 5.9, k: 'oak' },
  { x: 0.8, y: 9.9, k: 'pine' },
  { x: 0.9, y: 13.4, k: 'birch' },
  { x: 1.0, y: 17.6, k: 'oak' },
  { x: 3.2, y: 18.2, k: 'bush' },
  { x: 5.0, y: 17.6, k: 'oak' },
  { x: 7.6, y: 18.2, k: 'bush' },
  { x: 10.4, y: 18, k: 'pine' },
  { x: 14.6, y: 17.6, k: 'bush' },
  { x: 16.4, y: 18.2, k: 'oak' },
  { x: 19.1, y: 17.2, k: 'pine' },
  { x: 19.1, y: 13.9, k: 'oak' },
  { x: 19.2, y: 9.5, k: 'birch' },
  { x: 19.1, y: 5.6, k: 'pine' },
  { x: 18.9, y: 4.6, k: 'bush' },
  { x: 12.2, y: 4.6, k: 'bush' },
  { x: 4.8, y: 4.4, k: 'bush' },
  { x: 8.2, y: 12.7, k: 'bush' },
  { x: 11.6, y: 13, k: 'bush' },
  { x: 17.5, y: 15, k: 'bush' },
  { x: 14.2, y: 15.2, k: 'birch' },
  { x: 4.4, y: 16.8, k: 'bush' },
];

function Walkers({ rich }: { rich: boolean }) {
  return (
    <g>
      {WALKERS.map((v) => {
        const a = iso(v.from[0], v.from[1]);
        const b = iso(v.to[0], v.to[1]);
        const style = {
          '--x0': `${a[0]}px`,
          '--y0': `${a[1]}px`,
          '--x1': `${b[0]}px`,
          '--y1': `${b[1]}px`,
          animationDuration: `${v.seconds}s`,
        } as CSSProperties;
        return (
          <g key={v.id} className="iso-walker" style={style}>
            <g className="iso-walker-flip" style={{ animationDuration: `${v.seconds * 2}s` }}>
              {(() => {
                const old = (
                  <g transform="translate(-26 -70)">
                    <NpcArt name={v.npc} size={52} anim="walk" />
                  </g>
                );
                const c = RESIDENT_CHIBI[v.npc];
                return rich && c ? (
                  <SceneChibi cls={c.cls} seed={c.seed} h={64} y={6} fallback={old} />
                ) : (
                  old
                );
              })()}
            </g>
          </g>
        );
      })}
    </g>
  );
}

/** Закрытая земля следующего уровня: та же местность под туманной дымкой и золотым пунктиром границы. */
function Fog({ W, D, W2, D2 }: { W: number; D: number; W2: number; D2: number }) {
  const strips: Array<[number, number, number, number]> = [
    [W, 0, W2 - W, D2],
    [0, D, W, D2 - D],
  ];
  return (
    <g>
      {strips.map(([x, y, w, d], i) => {
        const quad = pts([iso(x, y), iso(x + w, y), iso(x + w, y + d), iso(x, y + d)]);
        return (
          <g key={i}>
            <polygon points={quad} fill="#cfdccb" opacity=".5" />
            <polygon points={quad} fill="url(#ig-fog)" opacity=".55" />
          </g>
        );
      })}
      <polyline
        points={pts([iso(W, 0), iso(W, D), iso(0, D)])}
        fill="none"
        stroke="#f2cf6b"
        strokeWidth="3"
        strokeDasharray="10 8"
        strokeLinejoin="round"
        opacity=".95"
      />
    </g>
  );
}

/** Межевой столб «Расширить земли»: щит с плюсом и флажок. */
function TerritorySign({ x, y }: { x: number; y: number }) {
  const [sx, sy] = iso(x, y, 0);
  return (
    <g transform={`translate(${sx} ${sy})`}>
      <ellipse cx="0" cy="2" rx="22" ry="8" fill="#0b2a0b" opacity=".28" />
      <rect
        x="-3"
        y="-64"
        width="6"
        height="66"
        rx="2"
        fill="#7a4a24"
        stroke="#2a1a0e"
        strokeWidth="1.200"
      />
      <g className="scene-pulse" style={{ transformBox: 'fill-box', transformOrigin: 'center' }}>
        <path
          d="M-26 -84h52l5 10-5 10h-52l-5-10Z"
          fill="#e0b030"
          stroke="#5a3a10"
          strokeWidth="2"
          strokeLinejoin="round"
        />
        <path
          d="M-6 -90v32M-22 -74h32"
          stroke="#5a3a10"
          strokeWidth="6"
          strokeLinecap="round"
          transform="translate(6 0)"
        />
        <path
          d="M-6 -90v32M-22 -74h32"
          stroke="#fff6c0"
          strokeWidth="2.600"
          strokeLinecap="round"
          transform="translate(6 0)"
        />
      </g>
    </g>
  );
}

/**
 * Изометрическая сцена замка на острове. Остров растёт с уровнем Земель; за его краем виден закрытый
 * слой следующего уровня. Здания, стены и деревья рисуются в SVG, а поверх лежат настоящие кнопки:
 * клавиатура, скринридер и подсказки работают, а не «нарисованы».
 */
export function IsoScene({
  castle,
  levels,
  now,
  onOpen,
  structures = [],
  placing = null,
  onPlace,
  onPickStructure,
}: SceneProps) {
  const { t } = useTranslation();
  const gfxRich = useGfx((s) => s.mode === 'rich');
  const medieval = useEra((s) => s.era === 'medieval');
  const rich = gfxRich && medieval;
  const built = new Set(structures.map((s) => `${s.x}-${s.y}`));
  // Стоящая в клетке постройка вытесняет декор (деревья, цветы, камни, фонари)
  const clear = (x: number, y: number): boolean => !built.has(`${Math.floor(x)}-${Math.floor(y)}`);
  const territory = Math.min(MAX_TERRITORY, levels.territory ?? 0);
  const { w: W, d: D } = islandSize(territory);
  const next = islandSize(Math.min(MAX_TERRITORY, territory + 1));
  const vb = viewBox(territory);
  const busy = new Set(castle.tasks.map((x) => x.key));
  const keys = (Object.keys(PLACEMENT) as PlacedKey[]).filter((k) => plotTerritory(k) <= territory);
  const wallsLevel = levels.walls ?? 0;

  // Порядок рисования: дальние вперёд. Здания, деревья и мелочь сортируются вместе по x+y их ближнего угла.
  type Item = { d: number; node: ReactNode };
  const items: Item[] = [];
  for (const key of keys) {
    const p = PLACEMENT[key];
    const f = FOOTPRINT[key];
    const level = levels[key] ?? 0;
    items.push({
      d: p.x + f.w + p.y + f.d,
      node: (
        <IsoBuilding
          key={key}
          id={`b-${key}`}
          kind={key}
          ox={p.x}
          oy={p.y}
          tier={tierOf(Math.max(1, level))}
          built={level > 0}
          busy={busy.has(key)}
          worker={
            rich ? (
              <SceneChibi
                cls="smith"
                pose="attack"
                seed={2}
                h={60}
                x={22}
                y={68}
                speed={0.9}
                fallback={<NpcArt name="blacksmith" size={44} anim="attack" />}
              />
            ) : (
              <NpcArt name="blacksmith" size={44} anim="attack" />
            )
          }
          art={
            rich && BUILDING_ART[key]
              ? (fallback) => {
                  const [cx, cy] = iso(p.x + f.w / 2, p.y + f.d / 2, 0);
                  return (
                    <SceneBuilding
                      kind={BUILDING_ART[key]!}
                      seed={tierOf(Math.max(1, level)) + 3}
                      cx={cx}
                      cy={cy}
                      scale={spriteScale(f.w, f.d)}
                      fallback={fallback}
                    />
                  );
                }
              : undefined
          }
        />
      ),
    });
  }
  const trees = useMemo(() => {
    const out = [...TREES.filter((tr) => tr.x < next.w - 0.4 && tr.y < next.d - 0.4)];
    // новые земли зарастают лесом и кустами вокруг участков под здания
    const taken = (Object.keys(PLACEMENT) as PlacedKey[]).map((k) => ({
      ...PLACEMENT[k],
      ...FOOTPRINT[k],
    }));
    for (let gy = 1; gy < next.d - 0.5; gy += 1)
      for (let gx = 1; gx < next.w - 0.5; gx += 1) {
        if (gx < 19 && gy < 18) continue;
        const r = roll(gx, gy, 'nt');
        if (r > 0.3) continue;
        const x = gx + 0.2 + roll(gx, gy, 'ox') * 0.6;
        const y = gy + 0.2 + roll(gx, gy, 'oy') * 0.6;
        if (
          taken.some(
            (b) => x > b.x - 0.6 && x < b.x + b.w + 0.6 && y > b.y - 0.6 && y < b.y + b.d + 0.6,
          )
        )
          continue;
        out.push({ x, y, k: r < 0.08 ? 'pine' : r < 0.16 ? 'oak' : r < 0.22 ? 'birch' : 'bush' });
      }
    return out;
  }, [next.w, next.d]);
  const treeNode = (
    key: string,
    tr: { x: number; y: number; k: 'oak' | 'pine' | 'bush' | 'birch'; s?: number },
  ): ReactNode => {
    const old = <IsoTree key={key} x={tr.x} y={tr.y} s={tr.s ?? 1} kind={tr.k} />;
    return rich ? (
      <SceneTree key={key} x={tr.x} y={tr.y} s={tr.s ?? 1} kind={tr.k} fallback={old} />
    ) : (
      old
    );
  };
  const owned = (x: number, y: number): boolean => x < W - 0.3 && y < D - 0.3;
  for (const s of structures) {
    items.push({
      d: s.x + s.y + 1,
      node: (
        <g
          key={`st-${s.id}`}
          onClick={placing ? undefined : () => onPickStructure?.(s.id)}
          style={placing ? undefined : { cursor: 'pointer' }}
        >
          <IsoStructure kind={s.kind} gx={s.x} gy={s.y} />
        </g>
      ),
    });
  }
  trees
    .filter((tr) => owned(tr.x, tr.y) && clear(tr.x, tr.y))
    .forEach((tr, i) =>
      items.push({
        d: tr.x + tr.y,
        node: treeNode(`t${i}`, tr),
      }),
    );
  const lockedTrees = trees
    .filter((tr) => !owned(tr.x, tr.y))
    .sort((a, b) => a.x + a.y - (b.x + b.y));
  items.push({ d: 12.5 + 5.9, node: <IsoFountain key="fountain" x={12.5} y={5.5} /> });
  [
    [11.4, 7],
    [13.6, 7],
    [11.4, 10],
    [13.6, 10],
    [11.4, 14],
    [13.6, 14],
    [4.4, 8],
    [6.6, 5],
  ].forEach(([x, y], i) => {
    if (clear(x!, y!)) items.push({ d: x! + y!, node: <IsoLamp key={`l${i}`} x={x!} y={y!} /> });
  });
  [
    [5.8, 17.2],
    [15.4, 17.5],
    [8.6, 12.1],
    [18, 13.4],
  ].forEach(([x, y], i) => {
    if (clear(x!, y!)) items.push({ d: x! + y!, node: <IsoRock key={`r${i}`} x={x!} y={y!} /> });
  });
  items.sort((a, b) => a.d - b.d);
  const signAt = { x: W + 1.4, y: D / 2 };
  const signBox = {
    x: iso(signAt.x, signAt.y)[0] - 40,
    y: iso(signAt.x, signAt.y)[1] - 100,
    w: 80,
    h: 110,
  };

  return (
    <div
      className={`castle-scene relative w-full select-none${placing ? ' placing' : ''}`}
      style={{ aspectRatio: `${vb.w} / ${vb.h}`, minWidth: Math.max(760, Math.round(vb.w * 0.55)) }}
      role="group"
      aria-label={t('castle.sceneLabel')}
    >
      <svg
        viewBox={`${vb.x} ${vb.y} ${vb.w} ${vb.h}`}
        className="scene-svg absolute inset-0 h-full w-full"
        aria-hidden="true"
        focusable="false"
      >
        <IsoDefs />
        <Sea vb={vb} W={next.w} D={next.d} />
        <Ambient W={next.w} D={next.d} vb={vb} />
        <Island W={next.w} D={next.d} />
        {lockedTrees.map((tr, i) => treeNode(`lt${i}`, tr))}
        {territory < MAX_TERRITORY && <Fog W={W} D={D} W2={next.w} D2={next.d} />}
        <Roads W={W} D={D} />
        {[
          [6.4, 3.2],
          [13.2, 3.4],
          [7.4, 12.4],
          [10.5, 12.6],
          [15.2, 5.6],
          [16.4, 9.2],
          [16.6, 14.6],
          [9.8, 16.6],
          [3.5, 3.4],
        ]
          .filter(([x, y]) => clear(x!, y!))
          .map(([x, y], i) => (
            <IsoFlowers key={i} x={x!} y={y!} />
          ))}
        <WallBack level={wallsLevel} W={W} D={D} />
        {items.map((it) => it.node)}
        <WallFront level={wallsLevel} W={W} D={D} />
        {placing &&
          freeCells(territory, structures, placing).map((c) => (
            <polygon
              key={`fc-${c.x}-${c.y}`}
              points={pts([
                iso(c.x, c.y),
                iso(c.x + 1, c.y),
                iso(c.x + 1, c.y + 1),
                iso(c.x, c.y + 1),
              ])}
              className="free-cell"
              data-cell={`${c.x},${c.y}`}
              onClick={() => onPlace?.(c.x, c.y)}
            />
          ))}
        {territory < MAX_TERRITORY && <TerritorySign x={signAt.x} y={signAt.y} />}
        <Walkers rich={rich} />
      </svg>
      {keys.map((key) => (
        <Hotspot
          key={key}
          kind={key}
          box={buildingBox(key)}
          vb={vb}
          level={levels[key] ?? 0}
          castle={castle}
          now={now}
          onOpen={onOpen}
        />
      ))}
      {territory < MAX_TERRITORY && (
        <Hotspot
          kind="territory"
          box={signBox}
          vb={vb}
          level={territory}
          castle={castle}
          now={now}
          onOpen={onOpen}
        />
      )}
      <Hotspot
        kind="walls"
        box={{ x: iso(GATE_X, D)[0] - 60, y: iso(GATE_X, D)[1] - 90, w: 120, h: 110 }}
        vb={vb}
        level={wallsLevel}
        castle={castle}
        now={now}
        onOpen={onOpen}
      />
    </div>
  );
}
