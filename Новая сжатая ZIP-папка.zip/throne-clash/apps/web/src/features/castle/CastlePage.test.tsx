import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { buildingCost, cityDto, freeCells, type CastleDto } from '@tc/shared';
import { initI18n } from '../../lib/i18n';
import { useToasts } from '../../store/toast';
import { apiError, installFakeApi, json, makeCastle } from '../../test-utils/fake-api';
import { renderApp, resetAuth, signIn } from '../../test-utils/render';

beforeAll(async () => {
  await initI18n('ru');
});
beforeEach(() => {
  signIn();
  useToasts.setState({ items: [] });
});
afterEach(() => {
  resetAuth();
  vi.unstubAllGlobals();
});

const task = (over: Partial<CastleDto['tasks'][number]> = {}): CastleDto['tasks'][number] => ({
  id: '11111111-1111-4111-8111-111111111111',
  key: 'barracks',
  toLevel: 1,
  startedAt: new Date(Date.now() - 10_000).toISOString(),
  finishesAt: new Date(Date.now() + 80_000).toISOString(),
  speedupGems: 1,
  refund: { gold: 75, wood: 100, stone: 60, food: 50 },
  ...over,
});
const withTask = (over: Partial<CastleDto> = {}): CastleDto =>
  makeCastle({
    resources: { gold: 850, wood: 800, stone: 880, food: 900 },
    slots: { total: 1, used: 1, extraUnlocked: false, canUnlock: true, unlockCostGems: 250 },
    tasks: [task()],
    ...over,
  });

const openQueue = async () => {
  await userEvent.click(await screen.findByRole('button', { name: /^Стройка/ }));
  return screen.findByRole('region', { name: 'Стройка' });
};

const openBuilding = async (name: string) => {
  const card = await screen.findByRole('button', { name: new RegExp(name) });
  await userEvent.click(card);
  return screen.findByRole('dialog');
};

describe('экран замка', () => {
  it('показывает участки зданий с уровнями и ставками производителей', async () => {
    installFakeApi({});
    renderApp('/castle');
    const scene = await screen.findByRole('group', { name: 'Ваш замок: нажмите на здание' });
    // 10 стартовых участков + ворота (Стены) + столб расширения Земель; башни и пристань откроются с Землями
    expect(within(scene).getAllByRole('button')).toHaveLength(12);
    expect(within(scene).queryByRole('button', { name: /Рыбацкая/ })).toBeNull();
    expect(within(scene).getByRole('button', { name: /Ферма/ })).toHaveTextContent('+400/ч');
    expect(within(scene).getByRole('button', { name: /Казарма/ })).toHaveTextContent(
      'Не построено',
    );
    expect(within(scene).getByRole('button', { name: /Замок, Уровень 1/ })).toHaveTextContent('1');
  });

  it('здания доступны с клавиатуры: Enter открывает окно, Tab переходит к следующему', async () => {
    installFakeApi({});
    renderApp('/castle');
    const scene = await screen.findByRole('group', { name: 'Ваш замок: нажмите на здание' });
    const first = within(scene).getAllByRole('button')[0]!;
    first.focus();
    await userEvent.keyboard('{Enter}');
    expect(await screen.findByRole('dialog')).toBeInTheDocument();
    await userEvent.keyboard('{Escape}');
    await waitFor(() => expect(screen.queryByRole('dialog')).toBeNull());
  });

  it('полоса ресурсов показывает запасы и ёмкость; счёт идёт вперёд от момента ответа сервера', async () => {
    // сервер ответил час назад: за это время накопилось +300 золота
    installFakeApi({
      'GET /api/castle': () =>
        json(200, makeCastle({ serverTime: new Date(Date.now() - 3600_000).toISOString() })),
    });
    renderApp('/castle');
    // Счёт обновляется раз в секунду: ждём первого тика, а не полагаемся на скорость машины
    expect(
      await screen.findByLabelText('Золото: 1 300 из 3 000', {}, { timeout: 4000 }),
    ).toBeInTheDocument();
    expect(screen.getByLabelText('Кристаллы: 50')).toBeInTheDocument();
  });

  it('ошибка загрузки → сообщение и повтор', async () => {
    let fail = true;
    const { calls } = installFakeApi({
      'GET /api/castle': () => (fail ? apiError(500, 'ERR_INTERNAL') : json(200, makeCastle())),
    });
    renderApp('/castle');
    const retry = await screen.findByRole('button', { name: 'Повторить' });
    fail = false;
    await userEvent.click(retry);
    expect(
      await screen.findByRole('group', { name: 'Ваш замок: нажмите на здание' }),
    ).toBeInTheDocument();
    expect(calls.length).toBeGreaterThanOrEqual(2);
  });
});

describe('окно здания', () => {
  it('показывает описание, стоимость и время; кнопка «Построить» активна', async () => {
    installFakeApi({});
    renderApp('/castle');
    const dlg = await openBuilding('Казарма');
    expect(within(dlg).getByText(/Здесь обучаются войска/)).toBeInTheDocument();
    expect(within(dlg).getByText('1м 30с')).toBeInTheDocument();
    expect(within(dlg).getByText('150')).toBeInTheDocument(); // золото
    expect(within(dlg).getByRole('button', { name: 'Построить' })).toBeEnabled();
  });

  it('производитель: показывает рост выработки и уровень Замка как причину блокировки', async () => {
    installFakeApi({});
    renderApp('/castle');
    const dlg = await openBuilding('Ферма');
    expect(within(dlg).getByText('+400/ч → +468/ч')).toBeInTheDocument();
    expect(within(dlg).getByRole('button', { name: 'Улучшить до 2' })).toBeDisabled();
    expect(within(dlg).getByText('Нужен Замок уровня 2')).toBeInTheDocument();
  });

  it('нехватка ресурсов: недостающее помечено словами, кнопка выключена', async () => {
    installFakeApi({
      'GET /api/castle': () =>
        json(200, makeCastle({ resources: { gold: 50, wood: 1000, stone: 1000, food: 1000 } })),
    });
    renderApp('/castle');
    const dlg = await openBuilding('Казарма');
    expect(within(dlg).getByRole('button', { name: 'Построить' })).toBeDisabled();
    expect(within(dlg).getAllByText('Не хватает ресурсов').length).toBeGreaterThan(0);
    expect(within(dlg).getByText(/Золото, не хватает/)).toBeInTheDocument();
  });

  it('все слоты заняты → кнопка выключена с причиной', async () => {
    installFakeApi({ 'GET /api/castle': () => json(200, withTask()) });
    renderApp('/castle');
    const dlg = await openBuilding('Кузница');
    expect(within(dlg).getByRole('button', { name: 'Построить' })).toBeDisabled();
    expect(within(dlg).getByText('Все слоты стройки заняты')).toBeInTheDocument();
  });

  it('Esc закрывает окно', async () => {
    installFakeApi({});
    renderApp('/castle');
    await openBuilding('Казарма');
    await userEvent.keyboard('{Escape}');
    await waitFor(() => expect(screen.queryByRole('dialog')).toBeNull());
  });
});

describe('стройка', () => {
  it('«Построить» отправляет POST с уникальным Idempotency-Key, закрывает окно и показывает очередь', async () => {
    const { calls } = installFakeApi({
      'POST /api/castle/buildings/barracks/upgrade': () => json(200, withTask()),
    });
    renderApp('/castle');
    const dlg = await openBuilding('Казарма');
    await userEvent.click(within(dlg).getByRole('button', { name: 'Построить' }));

    await waitFor(() => expect(screen.queryByRole('dialog')).toBeNull());
    const call = calls.find((c) => c.method === 'POST')!;
    expect(call.headers['Idempotency-Key']).toMatch(/^[0-9a-f-]{36}$/);
    expect(call.headers['Authorization']).toBe('Bearer access-1');
    const queue = await openQueue();
    expect(within(queue).getByText(/Казарма → 1/)).toBeInTheDocument();
    expect(within(queue).getByRole('progressbar')).toBeInTheDocument();
    expect(within(queue).getByText('Слоты стройки: 1 из 1')).toBeInTheDocument();
    expect(screen.getByLabelText('Золото: 850 из 3 000', { exact: false })).toBeInTheDocument();
    expect(useToasts.getState().items[0]?.message).toContain('стройка начата');
  });

  it('два клика по разным зданиям дают разные ключи идемпотентности', async () => {
    const { calls } = installFakeApi({
      'POST /api/castle/buildings/barracks/upgrade': () => json(200, makeCastle()),
      'POST /api/castle/buildings/forge/upgrade': () => json(200, makeCastle()),
    });
    renderApp('/castle');
    await userEvent.click(
      within(await openBuilding('Казарма')).getByRole('button', { name: 'Построить' }),
    );
    await userEvent.click(
      within(await openBuilding('Кузница')).getByRole('button', { name: 'Построить' }),
    );
    await waitFor(() => expect(calls.filter((c) => c.method === 'POST')).toHaveLength(2));
    const keys = calls.filter((c) => c.method === 'POST').map((c) => c.headers['Idempotency-Key']);
    expect(new Set(keys).size).toBe(2);
  });

  it('сервер отказал (очередь заняли с другого устройства) → понятное сообщение и перезагрузка данных', async () => {
    let gets = 0;
    installFakeApi({
      'GET /api/castle': () => (++gets, json(200, makeCastle())),
      'POST /api/castle/buildings/barracks/upgrade': () => apiError(422, 'ERR_QUEUE_FULL'),
    });
    renderApp('/castle');
    await userEvent.click(
      within(await openBuilding('Казарма')).getByRole('button', { name: 'Построить' }),
    );
    await waitFor(() =>
      expect(useToasts.getState().items.map((i) => i.message)).toContain(
        'Все слоты стройки заняты',
      ),
    );
    await waitFor(() => expect(gets).toBeGreaterThanOrEqual(2));
  });

  it('постройка, завершившаяся по расчёту, вызывает запрос актуального состояния', async () => {
    let gets = 0;
    const finished = task({
      startedAt: new Date(Date.now() - 100_000).toISOString(),
      finishesAt: new Date(Date.now() - 5_000).toISOString(),
    });
    installFakeApi({
      'GET /api/castle': () =>
        ++gets === 1
          ? json(
              200,
              withTask({
                serverTime: new Date(Date.now() - 60_000).toISOString(),
                tasks: [finished],
              }),
            )
          : json(200, makeCastle()),
    });
    renderApp('/castle');
    await waitFor(() => expect(gets).toBeGreaterThanOrEqual(2), { timeout: 4000 });
  });
});

describe('очередь: ускорение и отмена', () => {
  it('ускорение за кристаллы отправляет POST и убирает задачу', async () => {
    const t = task();
    const { calls } = installFakeApi({
      'GET /api/castle': () => json(200, withTask({ tasks: [t] })),
      [`POST /api/castle/queue/${t.id}/speedup`]: () =>
        json(
          200,
          makeCastle({
            gems: 49,
            buildings: makeCastle().buildings.map((b) =>
              b.key === 'barracks' ? { ...b, level: 1 } : b,
            ),
          }),
        ),
    });
    renderApp('/castle');
    await openQueue();
    await userEvent.click(await screen.findByRole('button', { name: /Ускорить \(1\)/ }));
    await waitFor(() => expect(screen.queryByRole('progressbar')).toBeNull());
    expect(calls.find((c) => c.method === 'POST')?.headers['Idempotency-Key']).toBeTruthy();
    expect(screen.getByLabelText('Кристаллы: 49')).toBeInTheDocument();
  });

  it('ускорение недоступно, если кристаллов меньше цены', async () => {
    installFakeApi({ 'GET /api/castle': () => json(200, withTask({ gems: 0 })) });
    renderApp('/castle');
    await openQueue();
    expect(await screen.findByRole('button', { name: /Ускорить/ })).toBeDisabled();
  });

  it('отмена требует подтверждения; «Отмена» в диалоге ничего не отправляет', async () => {
    const t = task();
    const { calls } = installFakeApi({
      'GET /api/castle': () => json(200, withTask({ tasks: [t] })),
      [`POST /api/castle/queue/${t.id}/cancel`]: () => json(200, makeCastle()),
    });
    renderApp('/castle');
    await openQueue();
    await userEvent.click(await screen.findByRole('button', { name: 'Отменить' }));
    let dlg = await screen.findByRole('alertdialog');
    expect(within(dlg).getByText('Вернётся половина потраченных ресурсов.')).toBeInTheDocument();
    await userEvent.click(within(dlg).getByRole('button', { name: 'Отмена' }));
    await waitFor(() => expect(screen.queryByRole('alertdialog')).toBeNull());
    expect(calls.filter((c) => c.method === 'POST')).toHaveLength(0);

    await userEvent.click(screen.getByRole('button', { name: 'Отменить' }));
    dlg = await screen.findByRole('alertdialog');
    await userEvent.click(within(dlg).getByRole('button', { name: 'Отменить' }));
    await waitFor(() => expect(calls.filter((c) => c.method === 'POST')).toHaveLength(1));
    await waitFor(() => expect(screen.queryByRole('progressbar')).toBeNull());
  });

  it('второй слот: кнопка выключена без 250 кристаллов и работает с ними', async () => {
    const { calls } = installFakeApi({
      'GET /api/castle': () => json(200, makeCastle({ gems: 300 })),
      'POST /api/castle/slots/unlock': () =>
        json(
          200,
          makeCastle({
            gems: 50,
            slots: {
              total: 2,
              used: 0,
              extraUnlocked: true,
              canUnlock: false,
              unlockCostGems: 250,
            },
          }),
        ),
    });
    renderApp('/castle');
    await openQueue();
    const btn = await screen.findByRole('button', { name: /Второй слот \(250\)/ });
    expect(btn).toBeEnabled();
    await userEvent.click(btn);
    await waitFor(() => expect(screen.queryByRole('button', { name: /Второй слот/ })).toBeNull());
    expect(screen.getByText('Слоты стройки: 0 из 2')).toBeInTheDocument();
    expect(calls.filter((c) => c.method === 'POST')).toHaveLength(1);
  });

  it('второй слот выключен, если кристаллов мало', async () => {
    installFakeApi({});
    renderApp('/castle');
    await openQueue();
    expect(await screen.findByRole('button', { name: /Второй слот/ })).toBeDisabled();
  });
});

describe('стоимость соответствует формулам общего пакета', () => {
  it('в окне Казармы указаны цены из buildingCost', async () => {
    installFakeApi({});
    renderApp('/castle');
    const dlg = await openBuilding('Казарма');
    const c = buildingCost('barracks', 1);
    for (const v of [c.gold, c.wood, c.stone, c.food]) {
      expect(within(dlg).getByText(String(v))).toBeInTheDocument();
    }
  });
});

describe('земли, каталог и условия', () => {
  it('здание с невыполненными условиями: причина и список условий в окне', async () => {
    installFakeApi({});
    renderApp('/castle');
    await userEvent.click(await screen.findByText('Все здания'));
    const catalog = screen.getByRole('region', { name: 'Хозяйство' });
    await userEvent.click(within(catalog).getByRole('button', { name: /Рыбацкая/ }));
    const dlg = await screen.findByRole('dialog');
    expect(within(dlg).getByText('Условия')).toBeInTheDocument();
    expect(within(dlg).getByText(/Земли уровня 1/)).toBeInTheDocument();
    expect(within(dlg).getByRole('button', { name: 'Построить' })).toBeDisabled();
  });

  it('каталог сгруппирован по классам и открывает окно здания', async () => {
    installFakeApi({});
    renderApp('/castle');
    await userEvent.click(await screen.findByText('Все здания'));
    for (const cls of ['Основа', 'Хозяйство', 'Армия', 'Магия', 'Оборона']) {
      expect(screen.getByRole('region', { name: cls })).toBeInTheDocument();
    }
  });
});

describe('город на свободных клетках (D-66)', () => {
  const rich = { gold: 5000, wood: 5000, stone: 5000, food: 5000 };
  const withCity = (structures: CastleDto['city']['structures'] = []) =>
    makeCastle({ resources: rich, city: cityDto(structures, 5) });

  it('выбор вида → режим расстановки → «В первую свободную» шлёт POST с клеткой', async () => {
    const first = freeCells(0, [])[0]!;
    const placed = { id: '22222222-2222-4222-8222-222222222222', kind: 'house' as const, ...first };
    const { calls } = installFakeApi({
      'GET /api/castle': () => json(200, withCity()),
      'POST /api/castle/structures': () => json(200, withCity([placed])),
    });
    renderApp('/castle');
    await userEvent.click(await screen.findByRole('button', { name: /^Город/ }));
    await userEvent.click(screen.getByRole('button', { name: 'Построить: Жилой дом' }));
    expect(
      await screen.findByText(/Выберите свободную клетку на острове: Жилой дом/),
    ).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: 'В первую свободную' }));
    await waitFor(() => expect(calls.filter((c) => c.method === 'POST')).toHaveLength(1));
    const post = calls.find((c) => c.method === 'POST')!;
    expect(post.path).toBe('/api/castle/structures');
    expect(post.body).toEqual({ kind: 'house', ...first });
    expect(post.headers['Idempotency-Key']).toMatch(/^[0-9a-f-]{36}$/);
    expect(useToasts.getState().items[0]?.message).toContain('Построено: Жилой дом');
  });

  it('вид с низким уровнем Замка заблокирован; снос требует подтверждения', async () => {
    const first = freeCells(0, [])[0]!;
    const placed = { id: '22222222-2222-4222-8222-222222222222', kind: 'house' as const, ...first };
    const { calls } = installFakeApi({
      'GET /api/castle': () => json(200, withCity([placed])),
      [`DELETE /api/castle/structures/${placed.id}`]: () => json(200, withCity()),
    });
    renderApp('/castle');
    await userEvent.click(await screen.findByRole('button', { name: /^Город/ }));
    await userEvent.click(screen.getByRole('tab', { name: /^Торговля/ }));
    expect(screen.getByRole('button', { name: 'Построить: Банк' })).toBeDisabled();
    await userEvent.click(screen.getByRole('tab', { name: /^Жильё/ }));
    await userEvent.click(screen.getByRole('button', { name: 'Снести: Жилой дом' }));
    const dlg = await screen.findByRole('alertdialog');
    await userEvent.click(within(dlg).getByRole('button', { name: 'Отмена' }));
    expect(calls.some((c) => c.method === 'DELETE')).toBe(false);
    await userEvent.click(screen.getByRole('button', { name: 'Снести: Жилой дом' }));
    await userEvent.click(
      within(await screen.findByRole('alertdialog')).getByRole('button', { name: 'Снести' }),
    );
    await waitFor(() => expect(calls.some((c) => c.method === 'DELETE')).toBe(true));
  });
});
