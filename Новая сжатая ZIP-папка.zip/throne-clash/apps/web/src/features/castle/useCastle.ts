import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useEffect, useMemo, useState } from 'react';
import type { CastleDto } from '@tc/shared';
import { useAuth } from '../../store/auth';
import { useClock } from '../../store/clock';
import { castleApi } from './api';
import { projectCastle } from './projection';

const KEY = ['castle'] as const;

/** Секундный «тик» по серверным часам — для живых счётчиков. */
export function useNow(intervalMs = 1000): number {
  const now = useClock((s) => s.now);
  const [value, setValue] = useState(() => now());
  useEffect(() => {
    const id = setInterval(() => setValue(now()), intervalMs);
    return () => clearInterval(id);
  }, [now, intervalMs]);
  return value;
}

export function useCastleQuery() {
  const authed = useAuth((s) => s.status === 'authenticated');
  return useQuery({
    queryKey: KEY,
    queryFn: castleApi.get,
    enabled: authed,
    staleTime: 30_000,
    refetchOnWindowFocus: true,
  });
}

/** Замок с прогнозом ресурсов; когда расчётом завершилась постройка — запрашивает актуальные данные. */
export function useLiveCastle() {
  const query = useCastleQuery();
  const client = useQueryClient();
  const now = useNow();
  const castle = query.data;
  const projected = useMemo(() => (castle ? projectCastle(castle, now) : null), [castle, now]);
  const finished = projected?.finishedIds.join(',') ?? '';
  useEffect(() => {
    if (finished) void client.invalidateQueries({ queryKey: KEY });
  }, [finished, client]);
  return { ...query, castle, projected };
}

/** Изменяющие операции: ответ сервера сразу кладём в кэш — экран обновляется без лишнего запроса. */
export function useCastleMutation<TVars>(fn: (vars: TVars) => Promise<CastleDto>) {
  const client = useQueryClient();
  return useMutation({
    mutationFn: fn,
    onSuccess: (dto) => client.setQueryData(KEY, dto),
    // При ошибке (например, очередь заняли с другого устройства) подтягиваем актуальное состояние
    onError: () => void client.invalidateQueries({ queryKey: KEY }),
  });
}
