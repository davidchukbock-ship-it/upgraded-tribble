import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  STRUCTURE_DEFS,
  STRUCTURE_GROUPS,
  shortfall,
  type CityDto,
  type ResourceAmounts,
  type StructureGroup,
  type StructureKind,
  type StructureKindDto,
} from '@tc/shared';
import { formatFull } from '../../lib/format';
import { cn } from '../../lib/cn';
import { ArtIcon } from '../../art';
import { StructureThumb } from '../../iso/structures';
import { Badge, Button } from '../../ui';

const RES = ['gold', 'wood', 'stone', 'food'] as const;

function Cost({ cost, have }: { cost: ResourceAmounts; have: ResourceAmounts }) {
  const { t } = useTranslation();
  const lacking = shortfall(have, cost);
  const list = RES.filter((r) => cost[r] > 0);
  if (list.length === 0) return <span className="text-xs">{t('city.free')}</span>;
  return (
    <ul className="flex flex-wrap gap-x-2 gap-y-0.5 text-xs">
      {list.map((r) => (
        <li
          key={r}
          className={cn('flex items-center gap-0.5', lacking[r] !== undefined && 'text-red-300')}
          aria-label={`${t(`resource.${r}`)}: ${formatFull(cost[r])}${lacking[r] !== undefined ? `, ${t('castle.lacking')}` : ''}`}
        >
          <ArtIcon name={r} size={14} />
          {formatFull(cost[r])}
        </li>
      ))}
    </ul>
  );
}

/** Город на свободных клетках острова: каталог по разделам с миниатюрами, процветание, снос (D-66). */
export function CityPanel({
  city,
  have,
  busy,
  onChoose,
  onRemove,
}: {
  city: CityDto;
  have: ResourceAmounts;
  busy: boolean;
  onChoose: (kind: StructureKind) => void;
  onRemove: (kind: StructureKind) => void;
}) {
  const { t } = useTranslation();
  const [group, setGroup] = useState<StructureGroup>('housing');
  const pct = (v: number): string => `${Math.round(v * 1000) / 10}%`;
  const inGroup = city.catalog.filter((c) => STRUCTURE_DEFS[c.kind].group === group);

  const item = (c: StructureKindDto) => {
    const lacking = Object.keys(shortfall(have, c.cost)).length > 0;
    const locked = c.blocked === 'castle_level';
    return (
      <li
        key={c.kind}
        className={cn(
          'flex gap-3 rounded-xl border-l-4 bg-black/25 px-2 py-2',
          locked ? 'border-stone opacity-70' : 'border-green/70',
        )}
      >
        <div
          className={cn('flex w-14 shrink-0 items-center justify-center', locked && 'grayscale')}
        >
          <StructureThumb kind={c.kind} size={52} />
        </div>
        <div className="flex min-w-0 flex-1 flex-col gap-1">
          <div className="flex items-center justify-between gap-2">
            <span className="font-display text-sm font-bold">{t(`structure.${c.kind}`)}</span>
            <Badge tone={c.owned >= c.max ? 'stone' : 'green'}>
              {c.owned}/{c.max}
            </Badge>
          </div>
          <p className="text-xs opacity-90">
            {t(`structure.${c.kind}Text`)}
            {c.bonus > 0 ? ` · ${t('city.bonus', { value: pct(c.bonus) })}` : ''}
          </p>
          <Cost cost={c.cost} have={have} />
          <div className="mt-1 flex flex-wrap gap-2">
            <Button
              variant="gold"
              className="!min-h-[34px] !px-3 !py-1 text-sm"
              disabled={busy || c.blocked !== null || lacking}
              aria-label={`${t('city.build')}: ${t(`structure.${c.kind}`)}`}
              onClick={() => onChoose(c.kind)}
            >
              {locked
                ? t('city.needCastle', { level: c.castleRequired })
                : c.blocked === 'limit'
                  ? t('city.limit')
                  : lacking
                    ? t('castle.lacking')
                    : t('city.build')}
            </Button>
            {c.owned > 0 && (
              <Button
                className="!min-h-[34px] !px-3 !py-1 text-sm"
                disabled={busy}
                aria-label={`${t('city.remove')}: ${t(`structure.${c.kind}`)}`}
                onClick={() => onRemove(c.kind)}
              >
                {t('city.remove')}
              </Button>
            )}
          </div>
        </div>
      </li>
    );
  };

  return (
    <section aria-label={t('city.title')}>
      <h2 className="font-display text-base font-bold text-gold-light">{t('city.title')}</h2>
      <p className="pt-1 text-sm">
        {t('city.lead')}{' '}
        <b>{t('city.prosperity', { value: pct(city.prosperity), cap: pct(city.cap) })}</b>
      </p>
      <div role="tablist" aria-label={t('city.title')} className="mt-2 flex flex-wrap gap-1">
        {STRUCTURE_GROUPS.map((g) => {
          const total = city.catalog.filter((c) => STRUCTURE_DEFS[c.kind].group === g);
          const owned = total.reduce((s, c) => s + c.owned, 0);
          return (
            <button
              key={g}
              type="button"
              role="tab"
              aria-selected={group === g}
              onClick={() => setGroup(g)}
              className={cn(
                'min-h-[36px] rounded-lg px-3 font-display text-xs font-bold sm:text-sm',
                group === g ? 'bg-gold text-ink' : 'bg-black/25 hover:bg-black/40',
              )}
            >
              {t(`city.groups.${g}`)}
              {owned > 0 && <span className="ml-1 opacity-80">({owned})</span>}
            </button>
          );
        })}
      </div>
      <ul className="mt-3 grid gap-2 sm:grid-cols-2" role="tabpanel">
        {inGroup.map(item)}
      </ul>
    </section>
  );
}
