import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { BUILDING_CLASS, BUILDING_CLASSES, type BuildingClass, type BuildingDto } from '@tc/shared';
import { Icon } from '../../icons/Icon';
import { cn } from '../../lib/cn';
import { Badge } from '../../ui';

const TONE: Record<BuildingClass, string> = {
  core: 'border-gold/70',
  economy: 'border-green/70',
  military: 'border-red/70',
  magic: 'border-[#a86ad8]/80',
  defense: 'border-[#5a8fd8]/80',
};

/** Каталог всех зданий по классам: хозяйство, армия, магия, оборона. Нажатие открывает то же окно, что и на сцене. */
export function BuildingCatalog({
  buildings,
  building,
  onOpen,
  startOpen = false,
}: {
  buildings: readonly BuildingDto[];
  building: (key: BuildingDto['key']) => number;
  onOpen: (key: BuildingDto['key']) => void;
  startOpen?: boolean;
}) {
  const { t } = useTranslation();
  const [open, setOpen] = useState(startOpen);
  return (
    <details
      className="panel-wood frame-pixel group px-4 py-3"
      open={open}
      onToggle={(e) => setOpen(e.currentTarget.open)}
    >
      <summary className="cursor-pointer font-display text-base font-bold text-gold-light">
        {t('castle.catalog')}
      </summary>
      {open && (
        <div className="grid gap-4 pt-3 md:grid-cols-2 xl:grid-cols-3">
          {BUILDING_CLASSES.map((cls) => {
            const list = buildings.filter((b) => BUILDING_CLASS[b.key] === cls);
            if (list.length === 0) return null;
            return (
              <section
                key={cls}
                aria-label={t(`castle.class.${cls}`)}
                className="flex flex-col gap-2"
              >
                <h3 className="font-display text-sm font-bold text-gold-light">
                  {t(`castle.class.${cls}`)}
                </h3>
                <ul className="flex flex-col gap-1.5">
                  {list.map((b) => {
                    const level = building(b.key);
                    const locked = level === 0 && b.blocked === 'requires';
                    return (
                      <li key={b.key}>
                        <button
                          type="button"
                          onClick={() => onOpen(b.key)}
                          className={cn(
                            'flex min-h-[44px] w-full items-center gap-2 rounded-lg border-l-4 bg-black/25 px-3 py-1.5 text-left hover:bg-black/40',
                            TONE[cls],
                            locked && 'opacity-60',
                          )}
                        >
                          <Icon name={b.key} size={22} />
                          <span className="min-w-0 flex-1 truncate text-sm font-semibold">
                            {t(`building.${b.key}`)}
                          </span>
                          {level > 0 ? (
                            <Badge tone="green">{level}</Badge>
                          ) : locked ? (
                            <Badge tone="stone">{t('castle.blocked.requires')}</Badge>
                          ) : (
                            <Badge tone="stone">{t('castle.notBuilt')}</Badge>
                          )}
                        </button>
                      </li>
                    );
                  })}
                </ul>
              </section>
            );
          })}
        </div>
      )}
    </details>
  );
}
