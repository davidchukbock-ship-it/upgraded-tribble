import type { BuildingKey, CastleDto, StructureKind } from '@tc/shared';
import { apiFetch } from '../../lib/api';

/** Новый ключ на каждое намерение игрока: повтор запроса при обрыве связи безопасен (D-06). */
const withKey = (): { headers: Record<string, string> } => ({
  headers: { 'Idempotency-Key': crypto.randomUUID() },
});

export const castleApi = {
  get: () => apiFetch<CastleDto>('/api/castle'),
  upgrade: (key: BuildingKey) =>
    apiFetch<CastleDto>(`/api/castle/buildings/${key}/upgrade`, { method: 'POST', ...withKey() }),
  speedup: (taskId: string) =>
    apiFetch<CastleDto>(`/api/castle/queue/${taskId}/speedup`, { method: 'POST', ...withKey() }),
  cancel: (taskId: string) =>
    apiFetch<CastleDto>(`/api/castle/queue/${taskId}/cancel`, { method: 'POST', ...withKey() }),
  placeStructure: (v: { kind: StructureKind; x: number; y: number }) =>
    apiFetch<CastleDto>('/api/castle/structures', { method: 'POST', body: v, ...withKey() }),
  removeStructure: (id: string) =>
    apiFetch<CastleDto>(`/api/castle/structures/${id}`, { method: 'DELETE', ...withKey() }),
  unlockSlot: () =>
    apiFetch<CastleDto>('/api/castle/slots/unlock', { method: 'POST', ...withKey() }),
};
