import { describe, expect, it } from 'vitest';
import { makeCastle } from '../../test-utils/fake-api';
import { projectCastle } from './projection';

const T0 = Date.parse('2026-01-01T00:00:00.000Z');

describe('projectCastle', () => {
  it('копит ресурсы по ставкам с момента ответа сервера', () => {
    const castle = makeCastle({ serverTime: new Date(T0).toISOString() });
    const p = projectCastle(castle, T0 + 3600_000 / 2);
    expect(p.resources.gold).toBe(1150);
    expect(p.resources.food).toBe(1200);
    expect(p.finishedIds).toEqual([]);
  });

  it('не выходит за ёмкость склада', () => {
    const p = projectCastle(
      makeCastle({ serverTime: new Date(T0).toISOString() }),
      T0 + 100 * 3600_000,
    );
    expect(p.resources.gold).toBe(3000);
  });

  it('завершившаяся постройка повышает уровень и меняет ставку с момента окончания', () => {
    const castle = makeCastle({
      serverTime: new Date(T0).toISOString(),
      resources: { gold: 0, wood: 0, stone: 0, food: 0 },
      tasks: [
        {
          id: 't1',
          key: 'goldmine',
          toLevel: 2,
          startedAt: new Date(T0).toISOString(),
          finishesAt: new Date(T0 + 1800_000).toISOString(),
          speedupGems: 1,
          refund: { gold: 0, wood: 0, stone: 0, food: 0 },
        },
      ],
    });
    const p = projectCastle(castle, T0 + 3600_000);
    expect(p.levels.goldmine).toBe(2);
    expect(p.finishedIds).toEqual(['t1']);
    // полчаса по 300/ч и полчаса по 351/ч
    expect(p.resources.gold).toBeCloseTo(150 + 175.5, 6);
  });

  it('незавершённая постройка остаётся в очереди', () => {
    const castle = makeCastle({
      serverTime: new Date(T0).toISOString(),
      tasks: [
        {
          id: 't1',
          key: 'farm',
          toLevel: 2,
          startedAt: new Date(T0).toISOString(),
          finishesAt: new Date(T0 + 7200_000).toISOString(),
          speedupGems: 1,
          refund: { gold: 0, wood: 0, stone: 0, food: 0 },
        },
      ],
    });
    const p = projectCastle(castle, T0 + 3600_000);
    expect(p.levels.farm).toBe(1);
    expect(p.finishedIds).toEqual([]);
  });
});
