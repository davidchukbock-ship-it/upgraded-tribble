import type { CastleDto, SkillKey, TechKey, UnitId, UnitTier, UnitType } from '@tc/shared';
import { apiFetch } from '../../lib/api';

const withKey = (): { headers: Record<string, string> } => ({
  headers: { 'Idempotency-Key': crypto.randomUUID() },
});
const post = (path: string, body?: unknown) =>
  apiFetch<CastleDto>(path, {
    method: 'POST',
    ...(body !== undefined ? { body } : {}),
    ...withKey(),
  });

/** Все действия возвращают актуальное состояние замка целиком (армия, исследования и герой внутри). */
export const realmApi = {
  train: (v: { type: UnitType; tier: UnitTier; count: number }) => post('/api/army/train', v),
  cancelTrain: (id: string) => post(`/api/army/queue/${id}/cancel`),
  speedupTrain: (id: string) => post(`/api/army/queue/${id}/speedup`),
  startResearch: (key: TechKey) => post(`/api/research/${key}/start`),
  cancelResearch: (id: string) => post(`/api/research/queue/${id}/cancel`),
  speedupResearch: (id: string) => post(`/api/research/queue/${id}/speedup`),
  spendSkill: (key: SkillKey) => post(`/api/hero/skills/${key}`),
  equip: (itemId: string) => post('/api/hero/equip', { itemId }),
  trainHero: () => post('/api/hero/train'),
  heal: (v: { unit: UnitId; count: number }) => post('/api/army/heal', v),
};
