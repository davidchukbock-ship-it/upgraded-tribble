import { useTranslation } from 'react-i18next';
import type { TechBranch, TechDto } from '@tc/shared';
import { formatDurationT } from '../../lib/duration';
import { cn } from '../../lib/cn';
import { useToasts } from '../../store/toast';
import { ArtIcon } from '../../art';
import { Badge, Button, ConfirmDialog, Panel, ProgressBar } from '../../ui';
import { errorMessage } from '../auth/errors';
import { CostList } from '../castle/CostList';
import { useCastleMutation, useLiveCastle } from '../castle/useCastle';
import { useState } from 'react';
import { QueueRow } from './QueueRow';
import { realmApi } from './api';

const BRANCHES: readonly TechBranch[] = ['economy', 'military', 'defense'];

function TechCard({
  tech,
  academyLevel,
  resources,
  busy,
  queueFull,
  onStart,
}: {
  tech: TechDto;
  academyLevel: number;
  resources: Parameters<typeof CostList>[0]['have'];
  busy: boolean;
  queueFull: boolean;
  onStart: () => void;
}) {
  const { t } = useTranslation();
  const name = t(`tech.${tech.key}`);
  const lacking =
    tech.cost !== null &&
    (Math.floor(resources.gold) < tech.cost.gold || Math.floor(resources.wood) < tech.cost.wood);

  let reason: string | null = null;
  if (tech.blocked === 'max_level') reason = t('academy.blocked.max_level');
  else if (tech.blocked === 'in_progress') reason = t('academy.blocked.in_progress');
  else if (tech.blocked === 'academy_level') {
    reason =
      academyLevel === 0
        ? t('academy.blocked.no_academy')
        : t('academy.blocked.academy_level', { level: tech.academyRequired });
  } else if (queueFull) reason = t('academy.blocked.queue_full');
  else if (lacking) reason = t('castle.blocked.lacking');

  return (
    <li className="panel-wood frame-pixel flex flex-col gap-2 p-3">
      <div className="flex items-center gap-3">
        <span className="rounded-lg bg-black/35 p-1">
          <ArtIcon name={tech.key} size={40} />
        </span>
        <div className="flex-1">
          <h3 className="font-display text-base font-bold leading-tight text-gold-light">{name}</h3>
          <p className="text-xs text-parchment/85">{t(`tech.effect.${tech.key}`)}</p>
        </div>
        <Badge
          tone={tech.level > 0 ? 'gold' : 'stone'}
          aria-label={`${t('common.level')} ${tech.level}`}
        >
          {tech.level}/10
        </Badge>
      </div>
      <ProgressBar label={name} value={tech.level} max={10} className="h-3" />
      {tech.cost && tech.seconds !== null && (
        <>
          <CostList cost={tech.cost} have={resources} />
          <p className="text-sm">
            {t('castle.time')}: <b>{formatDurationT(t, tech.seconds)}</b>
          </p>
        </>
      )}
      <Button
        variant="gold"
        disabled={busy || reason !== null}
        onClick={onStart}
        aria-label={`${t('academy.study')}: ${name}`}
      >
        {tech.level === 0 ? t('academy.study') : t('academy.improve', { level: tech.nextLevel })}
      </Button>
      {reason && (
        <p role="status" className="text-xs font-semibold text-gold-light">
          {reason}
        </p>
      )}
    </li>
  );
}

export function AcademyPage() {
  const { t } = useTranslation();
  const push = useToasts((s) => s.push);
  const { castle, projected, isPending, isError, refetch } = useLiveCastle();
  const [cancelId, setCancelId] = useState<string | null>(null);
  const onError = (err: unknown) => push(errorMessage(t, err), 'error');
  const start = useCastleMutation(realmApi.startResearch);
  const cancel = useCastleMutation(realmApi.cancelResearch);
  const speedup = useCastleMutation(realmApi.speedupResearch);
  const busy = start.isPending || cancel.isPending || speedup.isPending;

  if (isPending)
    return (
      <p role="status" className="pt-8 text-center font-display text-lg">
        {t('common.loading')}
      </p>
    );
  if (isError || !castle || !projected) {
    return (
      <Panel title={t('nav.academy')} className="mx-auto max-w-md text-center">
        <p className="pt-2">{t('errors.ERR_NETWORK')}</p>
        <Button className="mt-3" onClick={() => void refetch()}>
          {t('common.retry')}
        </Button>
      </Panel>
    );
  }

  const r = castle.research;
  const queueFull = r.queue.length >= r.queueMax;

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6">
      <h1 className="font-display text-2xl font-bold text-gold-light">{t('nav.academy')}</h1>
      {r.academyLevel === 0 && (
        <p role="note" className="rounded-lg border-2 border-gold bg-black/30 px-4 py-3 text-sm">
          {t('academy.noAcademy')}
        </p>
      )}

      <section
        aria-label={t('academy.queue')}
        className="panel-wood frame-pixel flex flex-col gap-2 px-4 py-3"
      >
        <div className="flex items-center justify-between">
          <p className="font-display text-sm font-bold text-gold-light">{t('academy.queue')}</p>
          <span className="text-sm">
            {t('academy.queueSlots', { used: r.queue.length, max: r.queueMax })}
          </span>
        </div>
        {r.queue.length === 0 ? (
          <p className="text-sm text-parchment/90">{t('academy.emptyQueue')}</p>
        ) : (
          <ul className="flex flex-col gap-2">
            {r.queue.map((task) => (
              <QueueRow
                key={task.id}
                icon={<ArtIcon name={task.tech} size={28} />}
                title={`${t(`tech.${task.tech}`)} → ${task.toLevel}`}
                startedAt={task.startedAt}
                finishesAt={task.finishesAt}
                speedupGems={task.speedupGems}
                gems={castle.gems}
                busy={busy}
                timerLabel={t('academy.timerLabel', { name: t(`tech.${task.tech}`) })}
                onDone={() => void refetch()}
                onSpeedup={() => speedup.mutate(task.id, { onError })}
                onCancel={() => setCancelId(task.id)}
              />
            ))}
          </ul>
        )}
      </section>

      {BRANCHES.map((branch) => (
        <section key={branch} aria-label={t(`academy.branch.${branch}`)}>
          <h2 className={cn('mb-3 font-display text-lg font-bold text-parchment')}>
            {t(`academy.branch.${branch}`)}
          </h2>
          <ul className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {r.techs
              .filter((x) => x.branch === branch)
              .map((tech) => (
                <TechCard
                  key={tech.key}
                  tech={tech}
                  academyLevel={r.academyLevel}
                  resources={projected.resources}
                  busy={busy}
                  queueFull={queueFull}
                  onStart={() =>
                    start.mutate(tech.key, {
                      onError,
                      onSuccess: () =>
                        push(t('academy.startedToast', { name: t(`tech.${tech.key}`) }), 'success'),
                    })
                  }
                />
              ))}
          </ul>
        </section>
      ))}

      <ConfirmDialog
        open={cancelId !== null}
        title={t('academy.cancelTitle')}
        message={t('castle.cancelText')}
        confirmLabel={t('castle.cancel')}
        onCancel={() => setCancelId(null)}
        onConfirm={() => {
          const id = cancelId;
          setCancelId(null);
          if (id) cancel.mutate(id, { onError });
        }}
      />
    </div>
  );
}
