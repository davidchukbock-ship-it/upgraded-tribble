import { useTranslation } from 'react-i18next';
import {
  EQUIP_SLOTS,
  SKILL_KEYS,
  SKILL_PER_LEVEL,
  type CastleDto,
  type EquipSlot,
  type HeroItemDto,
  type SkillKey,
} from '@tc/shared';
import { formatFull } from '../../lib/format';
import { cn } from '../../lib/cn';
import { ArtIcon, HeroArt, type HeroGear } from '../../art';
import { useToasts } from '../../store/toast';
import { Badge, Button, Panel, ProgressBar } from '../../ui';
import { errorMessage } from '../auth/errors';
import { CostList } from '../castle/CostList';
import { useCastleMutation, useLiveCastle } from '../castle/useCastle';
import { realmApi } from './api';

/** Что надето: редкость предмета в каждом слоте и шлем, который открывается с уровнем героя. */
function heroGear(hero: CastleDto['hero']): HeroGear {
  const worn = (slot: EquipSlot): number =>
    hero.items.find((i) => i.slot === slot && i.equipped)?.rarity ?? 0;
  return {
    weapon: worn('weapon'),
    armor: worn('armor'),
    relic: worn('relic'),
    helmet: hero.level >= 30 ? 3 : hero.level >= 15 ? 2 : hero.level >= 5 ? 1 : 0,
  };
}

const pct = (v: number): string => `${Math.round(v * 1000) / 10}%`;

function Pips({ level, max }: { level: number; max: number }) {
  return (
    <span className="flex gap-1" aria-hidden="true">
      {Array.from({ length: max }, (_, i) => (
        <span
          key={i}
          className={cn(
            'h-3 w-5 rounded-sm border-2 border-black/50',
            i < level ? 'bg-gold' : 'bg-black/40',
          )}
        />
      ))}
    </span>
  );
}

function ItemRow({
  item,
  busy,
  onEquip,
}: {
  item: HeroItemDto;
  busy: boolean;
  onEquip: () => void;
}) {
  const { t } = useTranslation();
  const name = `${t(`hero.slot.${item.slot}`)} ★${item.rarity}`;
  return (
    <li className="flex items-center gap-2 rounded-lg bg-black/25 px-3 py-2 text-sm">
      <span className="flex-1 font-semibold">{name}</span>
      <span className="text-parchment/85">+{pct(item.rarity * 0.015)}</span>
      {item.equipped ? (
        <Badge tone="green">{t('hero.equipped')}</Badge>
      ) : (
        <Button
          variant="gold"
          className="!min-h-[36px] !px-3 !py-1 text-sm"
          disabled={busy}
          onClick={onEquip}
          aria-label={`${t('hero.equip')}: ${name}`}
        >
          {t('hero.equip')}
        </Button>
      )}
    </li>
  );
}

export function HeroPage() {
  const { t } = useTranslation();
  const push = useToasts((s) => s.push);
  const { castle, projected, isPending, isError, refetch } = useLiveCastle();
  const onError = (err: unknown) => push(errorMessage(t, err), 'error');
  const spend = useCastleMutation(realmApi.spendSkill);
  const equip = useCastleMutation(realmApi.equip);
  const train = useCastleMutation(() => realmApi.trainHero());
  const busy = spend.isPending || equip.isPending || train.isPending;

  if (isPending)
    return (
      <p role="status" className="pt-8 text-center font-display text-lg">
        {t('common.loading')}
      </p>
    );
  if (isError || !castle || !projected) {
    return (
      <Panel title={t('nav.hero')} className="mx-auto max-w-md text-center">
        <p className="pt-2">{t('errors.ERR_NETWORK')}</p>
        <Button className="mt-3" onClick={() => void refetch()}>
          {t('common.retry')}
        </Button>
      </Panel>
    );
  }

  const h = castle.hero;
  const atMax = h.level >= h.maxLevel;
  const lacking =
    Math.floor(projected.resources.gold) < h.train.cost.gold ||
    Math.floor(projected.resources.food) < h.train.cost.food;

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-6">
      <h1 className="font-display text-2xl font-bold text-gold-light">{t('nav.hero')}</h1>

      <div className="grid gap-6 md:grid-cols-[minmax(0,18rem)_1fr]">
        <section
          aria-label={t('hero.portrait')}
          className="panel-wood frame-pixel flex flex-col items-center gap-3 p-4"
        >
          <span className="rounded-lg bg-black/35 p-2">
            <HeroArt gear={heroGear(h)} size={176} title={t('nav.hero')} />
          </span>
          <p className="font-display text-lg font-bold">
            {t('common.level')} {h.level}
          </p>
          <div className="w-full">
            <ProgressBar
              label={t('hero.xp')}
              value={h.xp}
              max={Math.max(1, h.xpToNext)}
              text={
                atMax ? t('hero.maxLevel') : `${formatFull(h.xp)} / ${formatFull(h.xpToNext)} XP`
              }
            />
          </div>
          <dl className="grid w-full grid-cols-3 gap-2 text-center text-xs">
            {(['attack', 'defense', 'production'] as const).map((k) => (
              <div key={k} className="rounded bg-black/25 px-1 py-1">
                <dt className="text-parchment/80">{t(`hero.bonus.${k}`)}</dt>
                <dd className="font-bold text-parchment">+{pct(h.bonuses[k])}</dd>
              </div>
            ))}
          </dl>
        </section>

        <div className="flex flex-col gap-6">
          <Panel title={t('hero.skills')}>
            <p className="pt-2 text-sm" role="status">
              {t('hero.points', { count: h.skillPoints })}
            </p>
            <ul className="mt-2 flex flex-col gap-2">
              {SKILL_KEYS.map((k: SkillKey) => (
                <li
                  key={k}
                  className="flex flex-wrap items-center gap-3 rounded-lg bg-black/25 px-3 py-2"
                >
                  <ArtIcon name={k} size={34} />
                  <div className="min-w-[10rem] flex-1">
                    <p className="font-display text-sm font-bold">{t(`hero.skill.${k}`)}</p>
                    <p className="text-xs text-parchment/85">
                      {t(`hero.skillHint.${k}`, { value: pct(SKILL_PER_LEVEL[k]) })}
                    </p>
                  </div>
                  <Pips level={h.skills[k]} max={h.maxSkill} />
                  <span className="sr-only">{`${h.skills[k]} / ${h.maxSkill}`}</span>
                  <Button
                    variant="gold"
                    className="!min-h-[36px] !px-3 !py-1 text-sm"
                    disabled={busy || h.skillPoints < 1 || h.skills[k] >= h.maxSkill}
                    onClick={() => spend.mutate(k, { onError })}
                    aria-label={`${t('hero.improve')}: ${t(`hero.skill.${k}`)}`}
                  >
                    +1
                  </Button>
                </li>
              ))}
            </ul>
          </Panel>

          <Panel title={t('hero.equipment')} tone="parchment">
            <ul className="grid gap-2 pt-2 sm:grid-cols-3" aria-label={t('hero.slots')}>
              {EQUIP_SLOTS.map((slot) => {
                const worn = h.items.find((i) => i.slot === slot && i.equipped);
                return (
                  <li
                    key={slot}
                    className="rounded-lg border-2 border-wood-light/60 bg-white/40 p-3 text-center"
                  >
                    <p className="font-display text-sm font-bold">{t(`hero.slot.${slot}`)}</p>
                    <p className="text-sm">{worn ? `★${worn.rarity}` : t('hero.empty')}</p>
                  </li>
                );
              })}
            </ul>
            <h3 className="mt-3 font-display text-sm font-bold">{t('hero.bag')}</h3>
            {h.items.length === 0 ? (
              <p className="text-sm">{t('hero.bagEmpty')}</p>
            ) : (
              <ul className="mt-1 flex flex-col gap-2 text-parchment">
                {h.items.map((item) => (
                  <ItemRow
                    key={item.id}
                    item={item}
                    busy={busy}
                    onEquip={() => equip.mutate(item.id, { onError })}
                  />
                ))}
              </ul>
            )}
          </Panel>

          <Panel title={t('hero.trainTitle')}>
            <p className="pt-2 text-sm">{t('hero.trainText', { xp: h.train.xp })}</p>
            <div className="mt-2 flex flex-wrap items-center gap-3">
              <CostList cost={h.train.cost} have={projected.resources} />
              <Button
                variant="gold"
                disabled={busy || atMax || lacking}
                onClick={() =>
                  train.mutate(undefined, {
                    onError,
                    onSuccess: () => push(t('hero.trainedToast', { xp: h.train.xp }), 'success'),
                  })
                }
              >
                <ArtIcon name="gold" size={20} />
                {t('hero.train')}
              </Button>
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}
