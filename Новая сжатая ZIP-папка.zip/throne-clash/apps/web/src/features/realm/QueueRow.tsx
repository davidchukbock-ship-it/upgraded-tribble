import type { ReactNode } from 'react';
import { useTranslation } from 'react-i18next';
import { ArtIcon } from '../../art';
import { Button, TimerProgress } from '../../ui';

interface Props {
  icon: ReactNode;
  title: string;
  startedAt: string;
  finishesAt: string;
  /** null — партия ещё ждёт своей очереди, ускорить нельзя. */
  speedupGems: number | null;
  gems: number;
  busy: boolean;
  timerLabel: string;
  onSpeedup: () => void;
  onCancel: () => void;
  onDone: () => void;
}

/** Строка очереди (обучение, исследование): значок, название, таймер, «Ускорить», «Отменить». */
export function QueueRow(p: Props) {
  const { t } = useTranslation();
  const waiting = p.speedupGems === null;
  return (
    <li className="flex flex-wrap items-center gap-x-3 gap-y-2 rounded-lg bg-black/25 px-3 py-2">
      <span className="flex min-w-[10rem] items-center gap-2 font-display text-sm font-bold">
        {p.icon}
        {p.title}
      </span>
      {waiting ? (
        <span className="min-w-[8rem] flex-1 text-sm text-parchment/85">{t('realm.waiting')}</span>
      ) : (
        <TimerProgress
          className="min-w-[8rem] flex-1"
          label={p.timerLabel}
          startsAtMs={Date.parse(p.startedAt)}
          endsAtMs={Date.parse(p.finishesAt)}
          onDone={p.onDone}
        />
      )}
      {!waiting && (
        <Button
          variant="gold"
          className="!min-h-[36px] !px-3 !py-1 text-sm"
          disabled={p.busy || p.gems < (p.speedupGems ?? 0)}
          onClick={p.onSpeedup}
        >
          <ArtIcon name="gems" size={20} />
          {t('castle.speedup', { gems: p.speedupGems })}
        </Button>
      )}
      <Button
        variant="danger"
        className="!min-h-[36px] !px-3 !py-1 text-sm"
        disabled={p.busy}
        onClick={p.onCancel}
      >
        {t('castle.cancel')}
      </Button>
    </li>
  );
}
