import { describe, expect, it } from 'vitest';
import { armyCap, trainCost, type BuildingKey, type CastleDto } from '@tc/shared';
import { makeArmy, makeCastle, makeResearch } from '../../test-utils/fake-api';
import { drillBonus, maxAffordable, trainBlock } from './army-helpers';

const withLevels = (
  levels: Partial<Record<BuildingKey, number>>,
  over: Partial<CastleDto> = {},
) => {
  const base = makeCastle();
  return makeCastle({
    buildings: base.buildings.map((b) => ({ ...b, level: levels[b.key] ?? b.level })),
    ...over,
  });
};

const rich = { gold: 1e6, wood: 1e6, stone: 1e6, food: 1e6 };

describe('trainBlock', () => {
  it('без Казармы обучать нельзя', () => {
    expect(trainBlock(makeCastle(), rich, 'infantry', 1, 1)).toBe('no_barracks');
  });

  it('высокая ступень закрыта низкой Казармой', () => {
    const c = withLevels({ barracks: 1 }, { army: makeArmy({ cap: armyCap(1) }) });
    expect(trainBlock(c, rich, 'infantry', 2, 1)).toBe('tier_locked');
    expect(trainBlock(c, rich, 'infantry', 1, 1)).toBeNull();
  });

  it('очередь из четырёх партий заполнена', () => {
    const queue = Array.from({ length: 4 }, (_, i) => ({
      id: `id-${i}`,
    })) as unknown as CastleDto['army']['queue'];
    const c = withLevels({ barracks: 5 }, { army: makeArmy({ queue }) });
    expect(trainBlock(c, rich, 'infantry', 1, 1)).toBe('queue_full');
  });

  it('лимит армии считает и обученных, и стоящих в очереди', () => {
    const cap = armyCap(5);
    const c = withLevels({ barracks: 5 }, { army: makeArmy({ count: cap - 5, queued: 3 }) });
    expect(trainBlock(c, rich, 'infantry', 1, 2)).toBeNull();
    expect(trainBlock(c, rich, 'infantry', 1, 3)).toBe('army_cap');
  });

  it('не хватает ресурсов', () => {
    const c = withLevels({ barracks: 5 });
    const need = trainCost('infantry', 1, 10);
    expect(trainBlock(c, { ...rich, gold: need.gold - 1 }, 'infantry', 1, 10)).toBe('lacking');
    expect(trainBlock(c, { ...rich, gold: need.gold }, 'infantry', 1, 10)).toBeNull();
  });
});

describe('maxAffordable', () => {
  it('ограничен ресурсами, если места в армии много', () => {
    const unit = trainCost('infantry', 1, 1);
    const stock = { ...rich, gold: unit.gold * 7 + 0.9 };
    expect(maxAffordable('infantry', 1, stock, 10_000, 0, 0)).toBe(7);
  });

  it('ограничен местом в армии, если ресурсов много', () => {
    expect(maxAffordable('infantry', 1, rich, 100, 60, 30)).toBe(10);
  });

  it('никогда не отрицателен', () => {
    expect(maxAffordable('infantry', 1, rich, 100, 100, 50)).toBe(0);
    expect(maxAffordable('infantry', 1, { gold: 0, wood: 0, stone: 0, food: 0 }, 100, 0, 0)).toBe(
      0,
    );
  });
});

describe('drillBonus', () => {
  it('3% за уровень Муштры', () => {
    expect(drillBonus(makeCastle())).toBe(0);
    const research = makeResearch();
    const c = makeCastle({
      research: {
        ...research,
        techs: research.techs.map((t) => (t.key === 'drill' ? { ...t, level: 4 } : t)),
      },
    });
    expect(drillBonus(c)).toBeCloseTo(0.12, 10);
  });
});
