import {
  armyCap,
  maxTierFor,
  trainCost,
  unitStats,
  type CastleDto,
  type ResourceMap,
  type UnitTier,
  type UnitType,
} from '@tc/shared';

/** Сколько юнитов данного вида и тира можно поставить сейчас: не больше, чем хватает ресурсов и места в армии. */
export function maxAffordable(
  type: UnitType,
  tier: UnitTier,
  resources: ResourceMap,
  cap: number,
  count: number,
  queued: number,
): number {
  const c = unitStats(type, tier).cost;
  let byRes = Infinity;
  for (const r of ['gold', 'wood', 'stone', 'food'] as const) {
    if (c[r] > 0) byRes = Math.min(byRes, Math.floor(Math.floor(resources[r]) / c[r]));
  }
  const free = Math.max(0, cap - count - queued);
  return Math.max(0, Math.min(byRes === Infinity ? free : byRes, free));
}

export type TrainBlock =
  'no_barracks' | 'tier_locked' | 'queue_full' | 'army_cap' | 'lacking' | null;

/** Почему сейчас нельзя обучить: та же логика, что на сервере, — но сервер всё равно перепроверит. */
export function trainBlock(
  castle: CastleDto,
  resources: ResourceMap,
  type: UnitType,
  tier: UnitTier,
  count: number,
): TrainBlock {
  const barracks = castle.buildings.find((b) => b.key === 'barracks')?.level ?? 0;
  if (barracks < 1) return 'no_barracks';
  if (tier > maxTierFor(barracks)) return 'tier_locked';
  if (castle.army.queue.length >= castle.army.queueMax) return 'queue_full';
  if (castle.army.count + castle.army.queued + castle.army.marching + count > armyCap(barracks))
    return 'army_cap';
  const cost = trainCost(type, tier, count);
  for (const r of ['gold', 'wood', 'stone', 'food'] as const)
    if (Math.floor(resources[r]) < cost[r]) return 'lacking';
  return null;
}

/** Сокращение времени обучения от Муштры (3% за уровень). */
export function drillBonus(castle: CastleDto): number {
  return (castle.research.techs.find((t) => t.key === 'drill')?.level ?? 0) * 0.03;
}

/** Скидка на лечение от «Медицины» (5% за уровень). */
export function healDiscount(castle: CastleDto): number {
  return (castle.research.techs.find((t) => t.key === 'medicine')?.level ?? 0) * 0.05;
}
