import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import {
  armyCap,
  type BuildingKey,
  type CastleDto,
  type HeroDto,
  type HeroItemDto,
} from '@tc/shared';
import { initI18n } from '../../lib/i18n';
import { useToasts } from '../../store/toast';
import {
  apiError,
  installFakeApi,
  json,
  makeArmy,
  makeCastle,
  makeHero,
  makeResearch,
} from '../../test-utils/fake-api';
import { renderApp, resetAuth, signIn } from '../../test-utils/render';

beforeAll(async () => {
  await initI18n('ru');
});
beforeEach(() => {
  signIn();
  useToasts.setState({ items: [] });
});
afterEach(() => {
  resetAuth();
  vi.unstubAllGlobals();
});

const built = (levels: Partial<Record<BuildingKey, number>>, over: Partial<CastleDto> = {}) => {
  const base = makeCastle();
  return makeCastle({
    buildings: base.buildings.map((b) => ({ ...b, level: levels[b.key] ?? b.level })),
    ...over,
  });
};

const trainTask = (
  over: Partial<CastleDto['army']['queue'][number]> = {},
): CastleDto['army']['queue'][number] => ({
  id: '22222222-2222-4222-8222-222222222222',
  unit: 'infantry_1',
  count: 20,
  startedAt: new Date(Date.now() - 5_000).toISOString(),
  finishesAt: new Date(Date.now() + 60_000).toISOString(),
  speedupGems: 1,
  refund: { gold: 10, wood: 0, stone: 0, food: 5 },
  ...over,
});

describe('экран армии', () => {
  it('без Казармы: подсказка и выключенная кнопка «Обучить»', async () => {
    installFakeApi({});
    renderApp('/army');
    const list = await screen.findByRole('list', { name: 'Набор войск' });
    expect(within(list).getAllByRole('listitem').length).toBeGreaterThanOrEqual(4);
    expect(within(list).getAllByText('Постройте Казарму в замке')).toHaveLength(4);
    for (const b of within(list).getAllByRole('button', { name: 'Обучить' })) {
      expect(b).toBeDisabled();
    }
  });

  it('высокая ступень показывает, с какой Казармы открывается', async () => {
    installFakeApi({
      'GET /api/castle': () => json(200, built({ barracks: 1 }, { army: makeArmy({ cap: 250 }) })),
    });
    renderApp('/army');
    const list = await screen.findByRole('list', { name: 'Набор войск' });
    const first = within(list).getAllByRole('listitem')[0]!;
    await userEvent.click(within(first).getByRole('radio', { name: /Ступень 2/ }));
    expect(within(first).getByText('Ступень откроется с Казармы 5')).toBeInTheDocument();
    expect(within(first).getByRole('button', { name: 'Обучить' })).toBeDisabled();
  });

  it('«Обучить» шлёт POST с ключом идемпотентности и показывает очередь из ответа', async () => {
    const after = built(
      { barracks: 5 },
      { army: makeArmy({ cap: armyCap(5), queued: 10, queue: [trainTask({ count: 10 })] }) },
    );
    const { calls } = installFakeApi({
      'GET /api/castle': () => json(200, built({ barracks: 5 }, { army: makeArmy({ cap: 900 }) })),
      'POST /api/army/train': () => json(200, after),
    });
    renderApp('/army');
    const list = await screen.findByRole('list', { name: 'Набор войск' });
    const first = within(list).getAllByRole('listitem')[0]!;
    await userEvent.click(within(first).getByRole('button', { name: 'Обучить' }));

    await waitFor(() => expect(calls.filter((c) => c.method === 'POST')).toHaveLength(1));
    const call = calls.find((c) => c.method === 'POST')!;
    expect(call.headers['Idempotency-Key']).toMatch(/^[0-9a-f-]{36}$/);
    expect(call.body).toEqual({ type: 'infantry', tier: 1, count: 10 });
    const queue = screen.getByRole('region', { name: 'Обучение' });
    expect(await within(queue).findByRole('progressbar')).toBeInTheDocument();
    expect(useToasts.getState().items[0]?.message).toContain('обучение началось');
  });

  it('«Макс.» подставляет максимум по ресурсам и месту в армии', async () => {
    installFakeApi({
      'GET /api/castle': () =>
        json(200, built({ barracks: 1 }, { army: makeArmy({ cap: 250, count: 240 }) })),
    });
    renderApp('/army');
    const list = await screen.findByRole('list', { name: 'Набор войск' });
    const first = within(list).getAllByRole('listitem')[0]!;
    await userEvent.click(within(first).getByRole('button', { name: 'Макс.' }));
    expect(within(first).getByRole('textbox')).toHaveValue('10');
  });

  it('поле количества принимает только цифры', async () => {
    installFakeApi({
      'GET /api/castle': () => json(200, built({ barracks: 5 }, { army: makeArmy({ cap: 900 }) })),
    });
    renderApp('/army');
    const list = await screen.findByRole('list', { name: 'Набор войск' });
    const input = within(within(list).getAllByRole('listitem')[0]!).getByRole('textbox');
    await userEvent.clear(input);
    await userEvent.type(input, '1a2b3');
    expect(input).toHaveValue('123');
  });

  it('сервер отказал → сообщение об ошибке', async () => {
    installFakeApi({
      'GET /api/castle': () => json(200, built({ barracks: 5 }, { army: makeArmy({ cap: 900 }) })),
      'POST /api/army/train': () => apiError(422, 'ERR_QUEUE_FULL'),
    });
    renderApp('/army');
    const list = await screen.findByRole('list', { name: 'Набор войск' });
    await userEvent.click(
      within(within(list).getAllByRole('listitem')[0]!).getByRole('button', { name: 'Обучить' }),
    );
    await waitFor(() => expect(useToasts.getState().items.length).toBeGreaterThan(0));
  });

  it('отмена обучения требует подтверждения', async () => {
    const t = trainTask();
    const state = built({ barracks: 5 }, { army: makeArmy({ cap: 900, queued: 20, queue: [t] }) });
    const { calls } = installFakeApi({
      'GET /api/castle': () => json(200, state),
      [`POST /api/army/queue/${t.id}/cancel`]: () =>
        json(200, built({ barracks: 5 }, { army: makeArmy({ cap: 900 }) })),
    });
    renderApp('/army');
    await userEvent.click(await screen.findByRole('button', { name: 'Отменить' }));
    const dlg = await screen.findByRole('alertdialog');
    await userEvent.click(within(dlg).getByRole('button', { name: 'Отмена' }));
    await waitFor(() => expect(screen.queryByRole('alertdialog')).toBeNull());
    expect(calls.filter((c) => c.method === 'POST')).toHaveLength(0);

    await userEvent.click(screen.getByRole('button', { name: 'Отменить' }));
    await userEvent.click(
      within(await screen.findByRole('alertdialog')).getByRole('button', { name: 'Отменить' }),
    );
    await waitFor(() => expect(calls.filter((c) => c.method === 'POST')).toHaveLength(1));
    await waitFor(() => expect(screen.queryByRole('progressbar')).toBeNull());
  });

  it('ожидающая партия без таймера и без «Ускорить»', async () => {
    const waiting = trainTask({ speedupGems: null });
    installFakeApi({
      'GET /api/castle': () =>
        json(
          200,
          built({ barracks: 5 }, { army: makeArmy({ cap: 900, queued: 20, queue: [waiting] }) }),
        ),
    });
    renderApp('/army');
    expect(await screen.findByText('Ждёт своей очереди')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: /Ускорить/ })).toBeNull();
  });
});

describe('Академия', () => {
  it('без Академии — пояснение и выключенные кнопки', async () => {
    installFakeApi({});
    renderApp('/academy');
    expect(
      await screen.findByText('Постройте Академию в замке, чтобы изучать технологии.'),
    ).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Изучить: Земледелие' })).toBeDisabled();
  });

  it('с Академией «Изучить» шлёт POST и показывает исследование в очереди', async () => {
    const research = makeResearch({}, 3);
    const after = built(
      { academy: 3 },
      {
        research: {
          ...research,
          queue: [
            {
              id: '33333333-3333-4333-8333-333333333333',
              tech: 'farming',
              toLevel: 1,
              startedAt: new Date(Date.now() - 1000).toISOString(),
              finishesAt: new Date(Date.now() + 90_000).toISOString(),
              speedupGems: 1,
              refund: { gold: 5, wood: 5, stone: 0, food: 0 },
            },
          ],
        },
      },
    );
    const { calls } = installFakeApi({
      'GET /api/castle': () => json(200, built({ academy: 3 }, { research })),
      'POST /api/research/farming/start': () => json(200, after),
    });
    renderApp('/academy');
    const btn = await screen.findByRole('button', { name: 'Изучить: Земледелие' });
    expect(btn).toBeEnabled();
    await userEvent.click(btn);
    await waitFor(() => expect(calls.filter((c) => c.method === 'POST')).toHaveLength(1));
    expect(calls.find((c) => c.method === 'POST')?.headers['Idempotency-Key']).toBeTruthy();
    const queue = screen.getByRole('region', { name: 'Исследования' });
    expect(await within(queue).findByRole('progressbar')).toBeInTheDocument();
    expect(within(queue).getByText(/Земледелие → 1/)).toBeInTheDocument();
  });

  it('технология выше уровня Академии называет нужный уровень', async () => {
    const base = makeResearch({}, 1);
    const research = {
      ...base,
      techs: base.techs.map((t) =>
        t.key === 'farming'
          ? { ...t, level: 1, nextLevel: 2, academyRequired: 3, blocked: 'academy_level' as const }
          : t,
      ),
    };
    installFakeApi({ 'GET /api/castle': () => json(200, built({ academy: 1 }, { research })) });
    renderApp('/academy');
    expect(await screen.findByText('Нужна Академия 3')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Изучить: Земледелие' })).toBeDisabled();
  });

  it('полная очередь блокирует остальные кнопки', async () => {
    const base = makeResearch({}, 3);
    const task = (id: string, tech: 'farming' | 'drill') => ({
      id,
      tech,
      toLevel: 1,
      startedAt: new Date(Date.now() - 1000).toISOString(),
      finishesAt: new Date(Date.now() + 90_000).toISOString(),
      speedupGems: tech === 'farming' ? 1 : null,
      refund: { gold: 1, wood: 1, stone: 0, food: 0 },
    });
    const research = {
      ...base,
      queue: [
        task('44444444-4444-4444-8444-444444444444', 'farming'),
        task('55555555-5555-4555-8555-555555555555', 'drill'),
      ],
    };
    installFakeApi({ 'GET /api/castle': () => json(200, built({ academy: 3 }, { research })) });
    renderApp('/academy');
    expect((await screen.findAllByText('Очередь исследований заполнена')).length).toBeGreaterThan(
      0,
    );
  });
});

describe('Герой', () => {
  const item = (over: Partial<HeroItemDto> = {}): HeroItemDto => ({
    id: '66666666-6666-4666-8666-666666666666',
    slot: 'weapon',
    rarity: 3,
    equipped: false,
    ...over,
  });
  const heroState = (over: Partial<HeroDto> = {}) =>
    json(200, makeCastle({ hero: makeHero(over) }));

  it('показывает уровень, очки навыков и бонусы', async () => {
    installFakeApi({
      'GET /api/castle': () =>
        heroState({ level: 3, skillPoints: 2, skills: { combat: 1, defense: 0, economy: 0 } }),
    });
    renderApp('/hero');
    expect(await screen.findByText('Очков навыков: 2')).toBeInTheDocument();
    expect(screen.getByText('Уровень 3')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Улучшить: Боевой' })).toBeEnabled();
  });

  it('без очков навыков «+1» выключены', async () => {
    installFakeApi({ 'GET /api/castle': () => heroState({ skillPoints: 0 }) });
    renderApp('/hero');
    for (const name of ['Боевой', 'Защитный', 'Хозяйственный']) {
      expect(await screen.findByRole('button', { name: `Улучшить: ${name}` })).toBeDisabled();
    }
  });

  it('вложение очка отправляет POST и обновляет навык', async () => {
    const { calls } = installFakeApi({
      'GET /api/castle': () => heroState({ skillPoints: 1 }),
      'POST /api/hero/skills/combat': () =>
        heroState({ skillPoints: 0, skills: { combat: 1, defense: 0, economy: 0 } }),
    });
    renderApp('/hero');
    await userEvent.click(await screen.findByRole('button', { name: 'Улучшить: Боевой' }));
    await waitFor(() => expect(screen.getByText('Очков навыков: 0')).toBeInTheDocument());
    expect(calls.filter((c) => c.method === 'POST')).toHaveLength(1);
    expect(calls[calls.length - 1]?.headers['Idempotency-Key']).toBeTruthy();
  });

  it('пустая сумка объясняет, откуда берутся предметы', async () => {
    installFakeApi({});
    renderApp('/hero');
    expect(await screen.findByText(/предметы выпадают из сундуков/)).toBeInTheDocument();
  });

  it('предмет из сумки надевается; надетый помечен', async () => {
    const it1 = item();
    const { calls } = installFakeApi({
      'GET /api/castle': () =>
        heroState({ items: [it1, item({ id: 'x', slot: 'armor', equipped: true })] }),
      'POST /api/hero/equip': () => heroState({ items: [{ ...it1, equipped: true }] }),
    });
    renderApp('/hero');
    expect(await screen.findByText('Надето')).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: /Надеть: Оружие/ }));
    await waitFor(() => expect(calls.filter((c) => c.method === 'POST')).toHaveLength(1));
    expect(calls.find((c) => c.method === 'POST')?.body).toEqual({ itemId: it1.id });
  });

  it('тренировка: кнопка работает при достатке ресурсов и шлёт POST', async () => {
    const { calls } = installFakeApi({
      'POST /api/hero/train': () => heroState({ xp: 60 }),
    });
    renderApp('/hero');
    const btn = await screen.findByRole('button', { name: 'Тренировать' });
    expect(btn).toBeEnabled();
    await userEvent.click(btn);
    await waitFor(() => expect(calls.filter((c) => c.method === 'POST')).toHaveLength(1));
    expect(useToasts.getState().items[0]?.message).toContain('60');
  });

  it('тренировка выключена при нехватке ресурсов и на максимальном уровне', async () => {
    installFakeApi({
      'GET /api/castle': () =>
        json(
          200,
          makeCastle({
            resources: { gold: 0, wood: 0, stone: 0, food: 0 },
            hero: makeHero(),
          }),
        ),
    });
    const { unmount } = renderApp('/hero');
    expect(await screen.findByRole('button', { name: 'Тренировать' })).toBeDisabled();
    unmount();

    installFakeApi({ 'GET /api/castle': () => heroState({ level: 50 }) });
    renderApp('/hero');
    expect(await screen.findByRole('button', { name: 'Тренировать' })).toBeDisabled();
    expect(screen.getByText('Максимальный уровень')).toBeInTheDocument();
  });
});

describe('госпиталь', () => {
  const wounded = (over: Partial<CastleDto> = {}) =>
    built(
      { barracks: 5, hospital: 2 },
      {
        army: makeArmy({
          cap: 900,
          woundedRoom: 192,
          units: [{ id: 'infantry_1', count: 5, wounded: 8 }],
          count: 5,
        }),
        ...over,
      },
    );

  it('раненые лечатся кнопкой: POST /army/heal с ключом идемпотентности', async () => {
    const after = built(
      { barracks: 5, hospital: 2 },
      {
        army: makeArmy({
          cap: 900,
          units: [{ id: 'infantry_1', count: 13, wounded: 0 }],
          count: 13,
        }),
      },
    );
    const { calls } = installFakeApi({
      'GET /api/castle': () => json(200, wounded()),
      'POST /api/army/heal': () => json(200, after),
    });
    renderApp('/army');
    const btn = await screen.findByRole('button', { name: /Вылечить: Пехота T1/ });
    expect(btn).toBeEnabled();
    expect(screen.getByText('Свободно мест: 192')).toBeInTheDocument();
    await userEvent.click(btn);
    await waitFor(() => expect(calls.filter((c) => c.method === 'POST')).toHaveLength(1));
    const post = calls.find((c) => c.method === 'POST')!;
    expect(post.body).toEqual({ unit: 'infantry_1', count: 8 });
    expect(post.headers['Idempotency-Key']).toBeTruthy();
    expect(await screen.findByText('Раненых нет.')).toBeInTheDocument();
  });

  it('без денег лечение выключено; без раненых показана пометка', async () => {
    installFakeApi({
      'GET /api/castle': () =>
        json(200, wounded({ resources: { gold: 0, wood: 0, stone: 0, food: 0 } })),
    });
    renderApp('/army');
    expect(await screen.findByRole('button', { name: /Вылечить: Пехота T1/ })).toBeDisabled();
  });

  it('лимит армии учитывает отряды в походах', async () => {
    installFakeApi({
      'GET /api/castle': () =>
        json(
          200,
          built({ barracks: 1 }, { army: makeArmy({ cap: 250, count: 100, marching: 145 }) }),
        ),
    });
    renderApp('/army');
    const list = await screen.findByRole('list', { name: 'Набор войск' });
    const first = within(list).getAllByRole('listitem')[0]!;
    await userEvent.click(within(first).getByRole('button', { name: 'Макс.' }));
    expect(within(first).getByRole('textbox')).toHaveValue('5'); // 250 − 100 − 145
    expect(screen.getByText('В походах')).toBeInTheDocument();
  });
});
