import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  ATTACK_MULT,
  UNIT_TIERS,
  UNIT_TYPES,
  RESOURCE_KEYS,
  armyCap,
  healCost,
  barracksLevelForTier,
  parseUnitId,
  trainCost,
  trainSeconds,
  unitStats,
  type CastleDto,
  type ResourceMap,
  type UnitTier,
  type UnitType,
} from '@tc/shared';
import { formatDurationT } from '../../lib/duration';
import { formatFull } from '../../lib/format';
import { cn } from '../../lib/cn';
import { useToasts } from '../../store/toast';
import { ArtIcon, UnitArt, type FigureAnim } from '../../art';
import { Button, ConfirmDialog, Panel } from '../../ui';
import { errorMessage } from '../auth/errors';
import { CostList } from '../castle/CostList';
import { useCastleMutation, useLiveCastle } from '../castle/useCastle';
import { drillBonus, healDiscount, maxAffordable, trainBlock } from './army-helpers';
import { QueueRow } from './QueueRow';
import { realmApi } from './api';

function Portrait({
  type,
  tier,
  size,
  anim = 'none',
}: {
  type: UnitType;
  tier: UnitTier;
  size: number;
  anim?: FigureAnim;
}) {
  const { t } = useTranslation();
  return <UnitArt type={type} tier={tier} size={size} title={t(`unit.${type}`)} anim={anim} />;
}

function UnitCard({
  type,
  castle,
  resources,
  busy,
  onTrain,
}: {
  type: UnitType;
  castle: CastleDto;
  resources: ResourceMap;
  busy: boolean;
  onTrain: (v: { type: UnitType; tier: UnitTier; count: number }) => void;
}) {
  const { t } = useTranslation();
  const [tier, setTier] = useState<UnitTier>(1);
  const [raw, setRaw] = useState('10');
  const barracks = castle.buildings.find((b) => b.key === 'barracks')?.level ?? 0;
  const count = Math.max(0, Math.min(100_000, Math.floor(Number(raw) || 0)));
  const s = unitStats(type, tier);
  const block = count < 1 ? 'lacking' : trainBlock(castle, resources, type, tier, count);
  const cost = trainCost(type, tier, Math.max(1, count));
  const seconds = trainSeconds(
    type,
    tier,
    Math.max(1, count),
    Math.max(1, barracks),
    drillBonus(castle),
    castle.worldSpeed,
  );
  const max = maxAffordable(
    type,
    tier,
    resources,
    armyCap(barracks),
    castle.army.count,
    castle.army.queued + castle.army.marching,
  );

  return (
    <li className="panel-wood frame-pixel flex flex-col gap-3 p-4">
      <div className="flex items-center gap-3">
        <span className="rounded-lg bg-black/35 p-1">
          <Portrait type={type} tier={tier} size={64} anim="idle" />
        </span>
        <div>
          <h3 className="font-display text-lg font-bold text-gold-light">{t(`unit.${type}`)}</h3>
          <p className="text-xs text-parchment/85">{t(`army.role.${type}`)}</p>
        </div>
      </div>

      <div role="radiogroup" aria-label={t('army.tier')} className="flex gap-1">
        {UNIT_TIERS.map((n) => {
          const locked = barracks < barracksLevelForTier(n);
          return (
            <button
              key={n}
              type="button"
              role="radio"
              aria-checked={tier === n}
              aria-label={`${t('army.tier')} ${n}${locked ? `, ${t('army.needBarracks', { level: barracksLevelForTier(n) })}` : ''}`}
              onClick={() => setTier(n)}
              className={cn(
                'flex min-h-[40px] flex-1 items-center justify-center gap-1 rounded-md border-2 font-display text-sm font-bold',
                tier === n
                  ? 'border-gold bg-gold text-ink'
                  : 'border-stone bg-black/30 text-parchment',
                locked && tier !== n && 'opacity-60',
              )}
            >
              {locked && <ArtIcon name="lock" size={14} />}
              {n}
            </button>
          );
        })}
      </div>

      <dl className="grid grid-cols-3 gap-x-3 gap-y-1 text-center text-xs">
        {(
          [
            ['atk', s.atk],
            ['def', s.def],
            ['hp', s.hp],
            ['speed', s.secPerTile],
            ['cargo', s.cargo],
            ['upkeep', s.upkeep],
          ] as const
        ).map(([k, v]) => (
          <div key={k} className="rounded bg-black/25 px-1 py-1">
            <dt className="text-parchment/80">{t(`army.stat.${k}`)}</dt>
            <dd className="font-bold text-parchment">{v}</dd>
          </div>
        ))}
      </dl>

      <div className="flex items-end gap-2">
        <label className="flex min-w-0 flex-1 flex-col gap-1 text-sm">
          <span className="font-display font-bold">{t('army.count')}</span>
          <input
            inputMode="numeric"
            value={raw}
            onChange={(e) => setRaw(e.target.value.replace(/[^\d]/g, '').slice(0, 6))}
            className="min-h-[40px] w-full min-w-0 rounded-lg border-2 border-wood-light bg-white/80 px-3 text-ink"
          />
        </label>
        <Button
          variant="gold"
          className="shrink-0 !min-h-[40px] !px-3"
          onClick={() => setRaw(String(max))}
          disabled={max < 1}
        >
          {t('army.max')}
        </Button>
      </div>

      <CostList cost={cost} have={resources} />
      <p className="text-sm">
        {t('castle.time')}: <b>{formatDurationT(t, seconds)}</b>
      </p>

      <Button disabled={busy || block !== null} onClick={() => onTrain({ type, tier, count })}>
        {t('army.train')}
      </Button>
      {block && block !== 'lacking' && (
        <p role="status" className="text-sm font-semibold text-gold-light">
          {block === 'no_barracks' && t('army.blocked.no_barracks')}
          {block === 'tier_locked' &&
            t('army.blocked.tier_locked', { level: barracksLevelForTier(tier) })}
          {block === 'queue_full' && t('army.blocked.queue_full')}
          {block === 'army_cap' && t('army.blocked.army_cap')}
        </p>
      )}
    </li>
  );
}

export function ArmyPage() {
  const { t } = useTranslation();
  const push = useToasts((s) => s.push);
  const { castle, projected, isPending, isError, refetch } = useLiveCastle();
  const [cancelId, setCancelId] = useState<string | null>(null);
  const onError = (err: unknown) => push(errorMessage(t, err), 'error');
  const train = useCastleMutation(realmApi.train);
  const cancel = useCastleMutation(realmApi.cancelTrain);
  const speedup = useCastleMutation(realmApi.speedupTrain);
  const heal = useCastleMutation(realmApi.heal);
  const busy = train.isPending || cancel.isPending || speedup.isPending || heal.isPending;

  if (isPending)
    return (
      <p role="status" className="pt-8 text-center font-display text-lg">
        {t('common.loading')}
      </p>
    );
  if (isError || !castle || !projected) {
    return (
      <Panel title={t('nav.army')} className="mx-auto max-w-md text-center">
        <p className="pt-2">{t('errors.ERR_NETWORK')}</p>
        <Button className="mt-3" onClick={() => void refetch()}>
          {t('common.retry')}
        </Button>
      </Panel>
    );
  }

  const a = castle.army;
  const barracks = castle.buildings.find((b) => b.key === 'barracks')?.level ?? 0;

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6">
      <h1 className="font-display text-2xl font-bold text-gold-light">{t('nav.army')}</h1>

      <section
        aria-label={t('army.summary')}
        className="panel-wood frame-pixel grid gap-3 p-4 sm:grid-cols-5"
      >
        {(
          [
            ['army.size', `${formatFull(a.count)} / ${formatFull(a.cap)}`],
            ['army.queued', formatFull(a.queued)],
            ['army.marchingLabel', formatFull(a.marching)],
            ['army.upkeep', `${formatFull(a.upkeepPerHour)}/${t('castle.perHour')}`],
            ['army.barracks', barracks > 0 ? String(barracks) : '—'],
          ] as const
        ).map(([k, v]) => (
          <div key={k} className="rounded-lg bg-black/25 px-3 py-2">
            <p className="text-xs text-parchment/80">{t(k)}</p>
            <p className="font-display text-lg font-bold">{v}</p>
          </div>
        ))}
      </section>

      <section
        aria-label={t('army.queue')}
        className="panel-wood frame-pixel flex flex-col gap-2 px-4 py-3"
      >
        <div className="flex items-center justify-between">
          <p className="font-display text-sm font-bold text-gold-light">{t('army.queue')}</p>
          <span className="text-sm">
            {t('army.queueSlots', { used: a.queue.length, max: a.queueMax })}
          </span>
        </div>
        {a.queue.length === 0 ? (
          <p className="text-sm text-parchment/90">{t('army.emptyQueue')}</p>
        ) : (
          <ul className="flex flex-col gap-2">
            {a.queue.map((task) => {
              const parsed = parseUnitId(task.unit);
              const type = parsed?.type ?? 'infantry';
              return (
                <QueueRow
                  key={task.id}
                  icon={
                    <span className="flex h-14 w-16 shrink-0 items-center justify-center overflow-hidden rounded bg-black/30">
                      <UnitArt
                        type={type}
                        tier={parsed?.tier ?? 1}
                        size={type === 'cavalry' || type === 'siege' ? 40 : 48}
                        anim="walk"
                      />
                    </span>
                  }
                  title={`${t(`unit.${type}`)} T${parsed?.tier ?? 1} × ${formatFull(task.count)}`}
                  startedAt={task.startedAt}
                  finishesAt={task.finishesAt}
                  speedupGems={task.speedupGems}
                  gems={castle.gems}
                  busy={busy}
                  timerLabel={t('army.timerLabel', { name: t(`unit.${type}`) })}
                  onDone={() => void refetch()}
                  onSpeedup={() => speedup.mutate(task.id, { onError })}
                  onCancel={() => setCancelId(task.id)}
                />
              );
            })}
          </ul>
        )}
      </section>

      <section
        aria-label={t('army.woundedTitle')}
        className="panel-wood frame-pixel flex flex-col gap-2 px-4 py-3"
      >
        <div className="flex items-center justify-between">
          <p className="font-display text-sm font-bold text-gold-light">{t('army.woundedTitle')}</p>
          <span className="text-sm">{t('army.woundedRoom', { count: a.woundedRoom })}</span>
        </div>
        {a.units.every((u) => u.wounded === 0) ? (
          <p className="text-sm text-parchment/90">{t('army.noWounded')}</p>
        ) : (
          <ul className="flex flex-col gap-2">
            {a.units
              .filter((u) => u.wounded > 0)
              .map((u) => {
                const parsed = parseUnitId(u.id);
                if (!parsed) return null;
                const name = `${t(`unit.${parsed.type}`)} T${parsed.tier}`;
                const cost = healCost(parsed.type, parsed.tier, u.wounded, healDiscount(castle));
                const lacking = RESOURCE_KEYS.some(
                  (k) => Math.floor(projected.resources[k]) < cost[k],
                );
                return (
                  <li
                    key={u.id}
                    className="flex flex-wrap items-center gap-x-3 gap-y-2 rounded-lg bg-black/25 px-3 py-2"
                  >
                    <span className="min-w-[10rem] flex-1 font-display text-sm font-bold">
                      {name} × {formatFull(u.wounded)}
                    </span>
                    <CostList cost={cost} have={projected.resources} />
                    <Button
                      variant="gold"
                      className="!min-h-[36px] !px-3 !py-1 text-sm"
                      disabled={busy || lacking}
                      aria-label={`${t('army.heal')}: ${name}`}
                      onClick={() =>
                        heal.mutate(
                          { unit: u.id, count: u.wounded },
                          {
                            onError,
                            onSuccess: () =>
                              push(t('army.healToast', { name, count: u.wounded }), 'success'),
                          },
                        )
                      }
                    >
                      {t('army.healAll')}
                    </Button>
                  </li>
                );
              })}
          </ul>
        )}
      </section>

      <ul className="grid gap-4 md:grid-cols-2 xl:grid-cols-4" aria-label={t('army.recruit')}>
        {UNIT_TYPES.map((type) => (
          <UnitCard
            key={type}
            type={type}
            castle={castle}
            resources={projected.resources}
            busy={busy}
            onTrain={(v) =>
              train.mutate(v, {
                onError,
                onSuccess: () =>
                  push(
                    t('army.queuedToast', { name: t(`unit.${v.type}`), count: v.count }),
                    'success',
                  ),
              })
            }
          />
        ))}
      </ul>

      <div className="grid gap-6 lg:grid-cols-2">
        <Panel title={t('army.roster')}>
          {a.units.length === 0 ? (
            <p className="pt-2 text-sm">{t('army.noUnits')}</p>
          ) : (
            <ul className="grid gap-2 pt-2 sm:grid-cols-2">
              {a.units.map((u) => {
                const parsed = parseUnitId(u.id);
                if (!parsed) return null;
                return (
                  <li
                    key={u.id}
                    className="flex items-center gap-2 rounded-lg bg-black/25 px-3 py-2"
                  >
                    <Portrait type={parsed.type} tier={parsed.tier} size={32} />
                    <span className="flex-1 text-sm">
                      {t(`unit.${parsed.type}`)} T{parsed.tier}
                    </span>
                    <b>{formatFull(u.count)}</b>
                    {u.wounded > 0 && (
                      <span className="flex items-center gap-1 text-xs" title={t('army.wounded')}>
                        <ArtIcon name="heart" size={18} />
                        {formatFull(u.wounded)}
                      </span>
                    )}
                  </li>
                );
              })}
            </ul>
          )}
        </Panel>

        <Panel title={t('army.rps')} tone="parchment">
          <p className="pt-2 text-sm">{t('army.rpsHint')}</p>
          <table className="mt-2 w-full text-center text-sm">
            <caption className="sr-only">{t('army.rps')}</caption>
            <thead>
              <tr>
                <th scope="col" className="p-1" />
                {UNIT_TYPES.map((d) => (
                  <th key={d} scope="col" className="p-1 font-display text-xs">
                    {t(`unit.${d}`)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {UNIT_TYPES.map((att) => (
                <tr key={att}>
                  <th scope="row" className="p-1 text-left font-display text-xs">
                    {t(`unit.${att}`)}
                  </th>
                  {UNIT_TYPES.map((def) => {
                    const m = ATTACK_MULT[att][def];
                    return (
                      <td
                        key={def}
                        className={cn(
                          'p-1 font-bold',
                          m > 1 ? 'text-[#2f6a14]' : m < 1 ? 'text-red' : '',
                        )}
                      >
                        ×{m}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </Panel>
      </div>

      <ConfirmDialog
        open={cancelId !== null}
        title={t('army.cancelTitle')}
        message={t('castle.cancelText')}
        confirmLabel={t('castle.cancel')}
        onCancel={() => setCancelId(null)}
        onConfirm={() => {
          const id = cancelId;
          setCancelId(null);
          if (id) cancel.mutate(id, { onError });
        }}
      />
    </div>
  );
}
