/**
 * Рыбалка (D-67): пять десятков секунд азарта. Клюёт рыба, нужно нажать «Подсечь», пока бегунок в зелёной зоне.
 * Чем ценнее рыба, тем уже зона. Чистые функции — их проверяют тесты, а вид рисует FishingGame.
 */
export interface Fish {
  id: 'sardine' | 'cod' | 'tuna' | 'golden';
  points: number;
  /** Ширина зелёной зоны (доля полосы). */
  zone: number;
  /** Вес при случайном выборе. */
  weight: number;
  color: string;
}

export const FISH: readonly Fish[] = [
  { id: 'sardine', points: 1, zone: 0.3, weight: 50, color: '#9fb6c8' },
  { id: 'cod', points: 3, zone: 0.2, weight: 30, color: '#c9a86a' },
  { id: 'tuna', points: 5, zone: 0.13, weight: 15, color: '#4f74b8' },
  { id: 'golden', points: 12, zone: 0.08, weight: 5, color: '#f2c94c' },
];

export const CASTS = 10;

export function pickFish(r: number): Fish {
  const total = FISH.reduce((s, f) => s + f.weight, 0);
  let acc = r * total;
  for (const f of FISH) {
    acc -= f.weight;
    if (acc < 0) return f;
  }
  return FISH[0]!;
}

/** Зелёная зона в случайном месте полосы. */
export function zoneFor(fish: Fish, r: number): { from: number; to: number } {
  const from = 0.05 + r * (0.9 - fish.zone);
  return { from, to: from + fish.zone };
}

/** Положение бегунка (0…1) в момент t: «пилообразно» туда-обратно. */
export function markerAt(tSec: number, speed: number): number {
  const p = (tSec * speed) % 2;
  return p <= 1 ? p : 2 - p;
}

export const isHit = (marker: number, zone: { from: number; to: number }): boolean =>
  marker >= zone.from && marker <= zone.to;

export function medal(score: number): 'none' | 'bronze' | 'silver' | 'gold' {
  return score >= 35 ? 'gold' : score >= 22 ? 'silver' : score >= 10 ? 'bronze' : 'none';
}
