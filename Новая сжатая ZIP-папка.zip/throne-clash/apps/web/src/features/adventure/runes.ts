import { mulberry32 } from '@tc/shared';

/** «Память рун» (D-67): найди пары. Колода перемешивается детерминированно по зерну. */
export const PAIRS = 8;

export function deal(seed: number): number[] {
  const rng = mulberry32(seed);
  const cards = Array.from({ length: PAIRS * 2 }, (_, i) => i % PAIRS);
  for (let i = cards.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [cards[i], cards[j]] = [cards[j]!, cards[i]!];
  }
  return cards;
}

export const isMatch = (cards: readonly number[], a: number, b: number): boolean =>
  a !== b && cards[a] !== undefined && cards[a] === cards[b];

/** Звёзды за число ходов: 3 — почти идеально. */
export const stars = (moves: number): 1 | 2 | 3 => (moves <= 11 ? 3 : moves <= 16 ? 2 : 1);
