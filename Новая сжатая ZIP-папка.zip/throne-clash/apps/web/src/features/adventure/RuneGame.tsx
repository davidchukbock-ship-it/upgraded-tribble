import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { ArtIcon, type IconName } from '../../art';
import { playSfx } from '../../audio/useSoundtrack';
import { cn } from '../../lib/cn';
import { useAdventure } from '../../store/adventure';
import { Button } from '../../ui';
import { Confetti } from './Confetti';
import { PAIRS, deal, isMatch, stars } from './runes';

const FACES: readonly IconName[] = [
  'gold',
  'wood',
  'stone',
  'food',
  'gems',
  'shield',
  'hammer',
  'heart',
];

const GLYPHS = ['ᚠ', 'ᚢ', 'ᚦ', 'ᚨ', 'ᚱ', 'ᚲ', 'ᚷ', 'ᚹ'] as const;

/** «Память рун» на весь экран: древний зал, светящиеся плиты, переворот карт с эффектом. */
export function RuneGame() {
  const { t } = useTranslation();
  const best = useAdventure((s) => s.runeMoves);
  const report = useAdventure((s) => s.reportRunes);
  const [seed, setSeed] = useState(() => 1 + Math.floor(Math.random() * 1_000_000));
  const cards = deal(seed);
  const [open, setOpen] = useState<number[]>([]);
  const [matched, setMatched] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [sparkle, setSparkle] = useState<number[]>([]);
  const [wrong, setWrong] = useState<number[]>([]);
  const [streak, setStreak] = useState(0);
  const done = matched.length === PAIRS * 2;

  useEffect(() => {
    if (open.length !== 2) return;
    const [a, b] = open as [number, number];
    const id = setTimeout(() => {
      if (isMatch(cards, a, b)) {
        setMatched((m) => [...m, a, b]);
        setSparkle([a, b]);
        setStreak((n) => n + 1);
        playSfx('match');
        setOpen([]);
      } else {
        setWrong([a, b]);
        setStreak(0);
        playSfx('thud');
        setTimeout(() => {
          setWrong([]);
          setOpen([]);
        }, 420);
      }
    }, 750);
    return () => clearTimeout(id);
    // cards зависит только от seed
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, seed]);

  useEffect(() => {
    if (!done) return;
    report(moves);
    playSfx('victory');
    const id = setTimeout(() => playSfx('cheer'), 500);
    return () => clearTimeout(id);
  }, [done, moves, report]);

  const flip = (i: number) => {
    if (open.length >= 2 || open.includes(i) || matched.includes(i)) return;
    playSfx('flip');
    const next = [...open, i];
    setOpen(next);
    if (next.length === 2) setMoves((m) => m + 1);
  };
  const restart = () => {
    setSeed(1 + Math.floor(Math.random() * 1_000_000));
    setOpen([]);
    setMatched([]);
    setSparkle([]);
    setWrong([]);
    setStreak(0);
    setMoves(0);
  };

  return (
    <div
      className="absolute inset-0 flex items-center justify-center overflow-auto"
      style={{
        background:
          'radial-gradient(60% 50% at 50% 40%, rgba(242,207,107,.22), transparent 70%), linear-gradient(#101c34, #0a1224)',
      }}
    >
      <svg
        className="absolute inset-0 h-full w-full"
        viewBox="0 0 1000 600"
        preserveAspectRatio="xMidYMid slice"
        aria-hidden="true"
        focusable="false"
      >
        <defs>
          <radialGradient id="rn-glow">
            <stop offset="0" stopColor="#ffb347" stopOpacity=".55" />
            <stop offset="1" stopColor="#ffb347" stopOpacity="0" />
          </radialGradient>
        </defs>
        {[80, 200, 800, 920].map((x) => (
          <g key={x}>
            <rect
              x={x - 22}
              y="60"
              width="44"
              height="470"
              fill="#1b2c4a"
              stroke="#0a1224"
              strokeWidth="2"
            />
            <rect
              x={x - 32}
              y="40"
              width="64"
              height="26"
              fill="#243a60"
              stroke="#0a1224"
              strokeWidth="2"
            />
            <rect
              x={x - 32}
              y="524"
              width="64"
              height="26"
              fill="#243a60"
              stroke="#0a1224"
              strokeWidth="2"
            />
            <path d={`M${x - 8} 70V520`} stroke="#3a5a8a" strokeWidth="3" opacity=".6" />
          </g>
        ))}
        {[140, 860].map((x) => (
          <g key={x}>
            <rect x={x - 4} y="250" width="8" height="40" fill="#5a3620" />
            <g transform={`translate(${x} 250)`}>
              <g className="st-flame">
                <path
                  d="M0 -34C-12 -18-14 -6-6 4H6C14-6 12-18 0-34Z"
                  fill="#ff7a2f"
                  stroke="#7a2a0a"
                  strokeWidth="1.500"
                />
                <path d="M0 -20C-5 -12-5 -4 0 2 5-4 5-12 0-20Z" fill="#ffd06a" />
              </g>
            </g>
            <circle cx={x} cy="240" r="110" fill="url(#rn-glow)" className="rune-torch" />
          </g>
        ))}
        {Array.from({ length: 16 }, (_, i) => (
          <circle
            key={`em${i}`}
            cx={60 + ((i * 61) % 880)}
            cy={590}
            r={1.5 + (i % 2)}
            fill="#ffb347"
            className="rune-ember"
            style={{ animationDelay: `${-(i % 8) * 0.9}s`, animationDuration: `${5 + (i % 4)}s` }}
          />
        ))}
        {Array.from({ length: 24 }, (_, i) => (
          <circle
            key={i}
            cx={(i * 83) % 1000}
            cy={(i * 47) % 600}
            r={1.5 + (i % 3)}
            fill="#f2cf6b"
            className="bd-firefly"
            style={{ animationDelay: `${(i % 8) * 0.5}s` }}
            opacity=".6"
          />
        ))}
      </svg>
      <div className="glass absolute left-1/2 top-2 md:top-[calc(var(--hdr,4rem)+0.5rem)] z-10 flex -translate-x-1/2 flex-wrap items-center justify-center gap-x-4 gap-y-1 px-4 py-1.5 text-sm">
        <span className="font-display font-bold text-gold-light">{t('runes.title')}</span>
        <span aria-live="polite">{t('runes.moves', { n: moves })}</span>
        <span className="opacity-80">{t('runes.best', { n: best })}</span>
      </div>

      {streak >= 2 && (
        <p
          key={streak}
          role="status"
          className="rune-streak absolute left-1/2 top-[3.6rem] z-10 -translate-x-1/2 font-display text-2xl font-extrabold text-gold-light md:top-[calc(var(--hdr,4rem)+3.6rem)]"
        >
          {t('runes.streak', { n: streak })}
        </p>
      )}
      <ul
        data-testid="runes-board"
        className="grid w-[min(92vw,68vh,34rem)] grid-cols-4 gap-2 pt-16 sm:gap-3"
      >
        {cards.map((v, i) => {
          const shown = open.includes(i) || matched.includes(i);
          const face = FACES[v] ?? 'gold';
          return (
            <li
              key={`${seed}-${i}`}
              className="rune-scene rune-deal aspect-square"
              style={{ animationDelay: `${i * 45}ms` }}
            >
              <button
                type="button"
                onClick={() => flip(i)}
                aria-label={
                  shown
                    ? t(`resource.${face}`, { defaultValue: face })
                    : t('runes.card', { n: i + 1 })
                }
                aria-pressed={shown}
                className={cn(
                  'rune-card h-full w-full',
                  shown && 'rune-flipped',
                  sparkle.includes(i) && 'rune-glow',
                  wrong.includes(i) && 'rune-shake',
                  matched.includes(i) && 'rune-float',
                )}
              >
                <span className="rune-face rune-back">
                  <span
                    className="rune-glyph text-3xl text-gold-light"
                    style={{ animationDelay: `${(i % 5) * 0.4}s` }}
                  >
                    {GLYPHS[i % GLYPHS.length]}
                  </span>
                </span>
                <span className={cn('rune-face rune-front', matched.includes(i) && 'rune-done')}>
                  <ArtIcon name={face} size={52} />
                </span>
              </button>
              {sparkle.includes(i) && (
                <span key={`b${moves}`} className="rune-burst" aria-hidden="true">
                  {Array.from({ length: 8 }, (_, k) => (
                    <i
                      key={k}
                      style={{ ['--a' as string]: `${k * 45}deg` } as React.CSSProperties}
                    />
                  ))}
                </span>
              )}
            </li>
          );
        })}
      </ul>

      {done && <Confetti />}
      <div className="absolute inset-x-0 bottom-4 z-10 flex justify-center">
        {done ? (
          <div
            role="status"
            className="glass flex flex-wrap items-center justify-center gap-3 px-4 py-2"
          >
            <p className="font-display text-lg font-bold">
              {t('runes.done', { n: moves })} {'★'.repeat(stars(moves))}
            </p>
            <Button variant="gold" onClick={restart}>
              {t('runes.again')}
            </Button>
          </div>
        ) : (
          <Button onClick={restart}>{t('runes.shuffle')}</Button>
        )}
      </div>
    </div>
  );
}
