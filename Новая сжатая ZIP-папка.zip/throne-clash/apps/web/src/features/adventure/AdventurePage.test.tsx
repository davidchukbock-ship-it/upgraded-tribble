import { act, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { initI18n } from '../../lib/i18n';
import { useAdventure } from '../../store/adventure';
import { installFakeApi } from '../../test-utils/fake-api';
import { renderApp, resetAuth, signIn } from '../../test-utils/render';
import { PAIRS, deal } from './runes';

beforeAll(async () => {
  await initI18n('ru');
});
beforeEach(() => {
  signIn();
  localStorage.clear();
  useAdventure.setState({ arenaWave: 0, fishing: 0, runeMoves: 0 });
  installFakeApi({});
});
afterEach(() => {
  resetAuth();
  vi.useRealTimers();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

describe('приключения (D-67)', () => {
  it('три игры на вкладках; сервер не спрашивается', async () => {
    const { calls } = installFakeApi({});
    renderApp('/play');
    expect(await screen.findByRole('tab', { name: 'Арена' })).toHaveAttribute(
      'aria-selected',
      'true',
    );
    await userEvent.click(screen.getByRole('tab', { name: 'Рыбалка' }));
    expect(screen.getByRole('button', { name: 'Забросить' })).toBeInTheDocument();
    await userEvent.click(screen.getByRole('tab', { name: 'Руны' }));
    expect(screen.getAllByRole('button', { name: /Закрытая карта/ })).toHaveLength(PAIRS * 2);
    expect(calls.filter((c) => c.method !== 'GET')).toHaveLength(0);
  });

  it('арена: очки командования ограничивают отряд, бой доходит до итога и пишет рекорд при победе', async () => {
    renderApp('/play');
    const arena = await screen.findByTestId('arena');
    expect(within(arena).getByText(/Очки командования: 6 из 8/)).toBeInTheDocument();
    // докупаем до потолка: 8 очков, дальше «+» выключен
    const more = within(arena).getByRole('button', { name: 'Добавить: Пехота' });
    await userEvent.click(more);
    await userEvent.click(more);
    expect(within(arena).getByText(/Очки командования: 8 из 8/)).toBeInTheDocument();
    expect(more).toBeDisabled();
    // выбор локации
    await userEvent.click(within(arena).getByRole('radio', { name: /Тёмный лес/ }));
    expect(within(arena).getByText(/лучники стреляют из укрытий/i)).toBeInTheDocument();

    vi.useFakeTimers({ shouldAdvanceTime: true });
    await userEvent.click(within(arena).getByRole('button', { name: 'В бой!' }));
    expect(within(arena).getByText('Отряды выдвигаются…')).toBeInTheDocument();
    // Цепочка таймеров идёт через перерисовки React: двигаем время небольшими шагами
    for (let i = 0; i < 30; i++)
      await act(async () => {
        await vi.advanceTimersByTimeAsync(1000);
      });
    expect(screen.getByText(/Победа!|Поражение/)).toBeInTheDocument();
    if (screen.queryByText('Победа!')) expect(useAdventure.getState().arenaWave).toBe(1);
  });

  it('руны: пара остаётся открытой, разные карты закрываются, финиш пишет рекорд', async () => {
    vi.spyOn(Math, 'random').mockReturnValue(0.5);
    renderApp('/play');
    await userEvent.click(await screen.findByRole('tab', { name: 'Руны' }));
    const seed = 1 + Math.floor(0.5 * 1_000_000);
    const cards = deal(seed);
    vi.useFakeTimers({ shouldAdvanceTime: true });
    const btn = (i: number) => {
      const items = within(screen.getByTestId('runes-board')).getAllByRole('listitem');
      return items[i]!.querySelector('button')!;
    };
    // промах: первая карта и любая с другим значением
    const other = cards.findIndex((v) => v !== cards[0]);
    await userEvent.click(btn(0));
    await userEvent.click(btn(other));
    await act(async () => {
      await vi.advanceTimersByTimeAsync(1300);
    });
    expect(btn(0)).toHaveAttribute('aria-pressed', 'false');
    // все пары подряд
    for (let v = 0; v < PAIRS; v++) {
      const [a, b] = cards.flatMap((c, i) => (c === v ? [i] : [])) as [number, number];
      await userEvent.click(btn(a));
      await userEvent.click(btn(b));
      await act(async () => {
        await vi.advanceTimersByTimeAsync(900);
      });
    }
    expect(await screen.findByText(/Все пары найдены за 9 ходов/)).toBeInTheDocument();
    expect(useAdventure.getState().runeMoves).toBe(9);
  });

  it('рыбалка: заброс → поклёвка → подсечка даёт сообщение', async () => {
    vi.spyOn(Math, 'random').mockReturnValue(0);
    renderApp('/play');
    await userEvent.click(await screen.findByRole('tab', { name: 'Рыбалка' }));
    vi.useFakeTimers({ shouldAdvanceTime: true });
    await userEvent.click(screen.getByRole('button', { name: 'Забросить' }));
    expect(screen.getByText('Ждём поклёвку…')).toBeInTheDocument();
    await act(async () => {
      await vi.advanceTimersByTimeAsync(3000);
    });
    const hook = screen.getByRole('button', { name: 'Подсечь!' });
    await userEvent.click(hook);
    expect(screen.getByText(/Поймана рыба|Сорвалась/)).toBeInTheDocument();
    expect(screen.getByText(/Заброс 1 из 10/)).toBeInTheDocument();
  });
});
