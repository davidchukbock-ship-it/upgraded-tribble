import type { ReactNode } from 'react';
import type { ArenaLocation } from '@tc/shared';

/**
 * Фоны локаций для боя на арене и для карточек выбора: небо, дали, земля и приметы места.
 * Всё нарисовано кодом (SVG); на 1000×360, растягивается по контейнеру.
 */
const OUT = '#1c2a1e';

function Pine({ x, y, s = 1, snow = false }: { x: number; y: number; s?: number; snow?: boolean }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <rect x="-4" y="-6" width="8" height="16" fill="#5a3a20" />
      <path
        d="M0 -62 -22 -22h44Z"
        fill={snow ? '#e8f2f8' : '#2f7a3c'}
        stroke={OUT}
        strokeWidth="1.500"
        strokeLinejoin="round"
      />
      <path
        d="M0 -42 -28 4h56Z"
        fill={snow ? '#dbe9f2' : '#256a33'}
        stroke={OUT}
        strokeWidth="1.500"
        strokeLinejoin="round"
      />
      {snow && <path d="M-14 -18l14-22 14 22Z" fill="#fff" opacity=".7" />}
    </g>
  );
}

function Oak({
  x,
  y,
  s = 1,
  color = '#4f9a3a',
}: {
  x: number;
  y: number;
  s?: number;
  color?: string;
}) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <rect x="-5" y="-14" width="10" height="26" fill="#6a4426" stroke={OUT} strokeWidth="1.400" />
      <circle cx="0" cy="-34" r="26" fill={color} stroke={OUT} strokeWidth="1.500" />
      <circle cx="-10" cy="-42" r="12" fill="#fff" opacity=".14" />
    </g>
  );
}

function Column({
  x,
  y,
  h,
  broken = false,
}: {
  x: number;
  y: number;
  h: number;
  broken?: boolean;
}) {
  return (
    <g transform={`translate(${x} ${y})`}>
      <rect x="-18" y="-8" width="36" height="10" fill="#bdb7a6" stroke={OUT} strokeWidth="1.500" />
      <path
        d={broken ? `M-12 -8V${-h}l6 8 6-6 6 10 6-8V-8Z` : `M-12 -8V${-h}h24V-8Z`}
        fill="#d8d2c0"
        stroke={OUT}
        strokeWidth="1.500"
        strokeLinejoin="round"
      />
      {!broken && (
        <rect
          x="-18"
          y={-h - 8}
          width="36"
          height="10"
          fill="#bdb7a6"
          stroke={OUT}
          strokeWidth="1.500"
        />
      )}
      <path d={`M-4 -8V${-h + 4}`} stroke="#fff" strokeOpacity=".5" strokeWidth="3" />
    </g>
  );
}

function Cloud({ x, y, s = 1, d = 0 }: { x: number; y: number; s?: number; d?: number }) {
  return (
    <g className="bd-cloud" style={{ animationDelay: `${-d}s` }}>
      <g transform={`translate(${x} ${y}) scale(${s})`} fill="#fff" opacity=".88">
        <ellipse cx="0" cy="0" rx="48" ry="16" />
        <ellipse cx="-24" cy="-10" rx="26" ry="16" />
        <ellipse cx="14" cy="-14" rx="30" ry="18" />
      </g>
    </g>
  );
}

function Birds({ y = 90 }: { y?: number }) {
  return (
    <g
      className="bd-birds"
      opacity=".7"
      stroke="#22303a"
      strokeWidth="2"
      fill="none"
      strokeLinecap="round"
    >
      {[0, 1, 2].map((i) => (
        <path key={i} d={`M${i * 26} ${y + (i % 2) * 10}q6-8 12 0q6-8 12 0`} />
      ))}
    </g>
  );
}

const SCENES: Record<ArenaLocation, () => ReactNode> = {
  meadow: () => (
    <>
      <rect width="1000" height="360" fill="url(#bd-meadow-sky)" />
      <circle cx="820" cy="80" r="40" fill="#fff6c0" opacity=".9" />
      <circle cx="820" cy="80" r="64" fill="#fff6c0" opacity=".25" />
      <Cloud x={200} y={70} s={1.1} d={0} />
      <Cloud x={560} y={44} s={0.8} d={30} />
      <Cloud x={900} y={120} s={0.7} d={60} />
      <Birds />
      <path d="M0 200Q150 130 320 190T640 180T1000 170V360H0Z" fill="#7cc26a" />
      <path d="M0 240Q200 190 420 235T1000 220V360H0Z" fill="#5fae4e" />
      <rect y="262" width="1000" height="98" fill="url(#bd-meadow-ground)" />
      <Oak x={90} y={250} s={1.2} />
      <Oak x={940} y={244} s={1.1} color="#5fae4e" />
      <Oak x={520} y={208} s={0.7} />
      {Array.from({ length: 22 }, (_, i) => (
        <circle
          key={i}
          cx={30 + i * 45 + ((i * 17) % 20)}
          cy={280 + ((i * 13) % 70)}
          r="3"
          fill={['#ffd76a', '#ff8fa3', '#fff'][i % 3]}
        />
      ))}
    </>
  ),
  forest: () => (
    <>
      <rect width="1000" height="360" fill="url(#bd-forest-sky)" />
      <path
        d="M0 210 40 120 90 200 150 100 210 205 280 90 340 200 420 110 480 205 550 95 620 200 700 115 770 205 850 100 920 200 1000 120V360H0Z"
        fill="#1f5a34"
        opacity=".75"
      />
      <rect y="255" width="1000" height="105" fill="url(#bd-forest-ground)" />
      {[40, 150, 260, 380, 610, 720, 830, 950].map((x, i) => (
        <Pine key={x} x={x} y={262 + (i % 3) * 8} s={1.1 + (i % 2) * 0.3} />
      ))}
      {Array.from({ length: 14 }, (_, i) => (
        <circle
          key={i}
          cx={60 + i * 68}
          cy={120 + ((i * 37) % 120)}
          r="2"
          fill="#d6ff8a"
          opacity=".85"
          className="bd-firefly"
          style={{ animationDelay: `${(i % 6) * 0.5}s` }}
        />
      ))}
    </>
  ),
  ruins: () => (
    <>
      <rect width="1000" height="360" fill="url(#bd-ruins-sky)" />
      <circle cx="160" cy="80" r="46" fill="#fff0c0" opacity=".85" />
      <Cloud x={520} y={70} s={0.9} d={10} />
      <Cloud x={860} y={110} s={0.6} d={50} />
      <Birds y={120} />
      <path d="M0 230Q250 170 500 220T1000 200V360H0Z" fill="#a89f88" />
      <rect y="262" width="1000" height="98" fill="url(#bd-ruins-ground)" />
      <Column x={110} y={270} h={110} />
      <Column x={200} y={276} h={64} broken />
      <Column x={790} y={272} h={120} />
      <Column x={890} y={278} h={70} broken />
      <path d="M330 268V210a55 55 0 0 1 110 0v58" fill="none" stroke="#cfc7b1" strokeWidth="18" />
      <path
        d="M330 268V210a55 55 0 0 1 110 0v58"
        fill="none"
        stroke={OUT}
        strokeWidth="1.500"
        opacity=".5"
      />
      <path d="M560 268V232l28-8 20 12v32Z" fill="#c8c0aa" stroke={OUT} strokeWidth="1.500" />
    </>
  ),
  snow: () => (
    <>
      <rect width="1000" height="360" fill="url(#bd-snow-sky)" />
      <Cloud x={300} y={60} s={1} d={5} />
      <Cloud x={760} y={40} s={1.2} d={40} />
      <path
        d="M0 210 120 90 200 170 320 60 440 190 560 110 700 200 820 80 1000 200V360H0Z"
        fill="#c9dbe8"
      />
      <path
        d="M320 60 280 110l36-14 20 20 14-34Z M820 80 780 128l34-14 22 18 12-32Z M120 90 84 140l34-12 18 14 10-30Z"
        fill="#fff"
      />
      <rect y="258" width="1000" height="102" fill="url(#bd-snow-ground)" />
      {[70, 210, 330, 700, 860, 960].map((x, i) => (
        <Pine key={x} x={x} y={266 + (i % 2) * 10} s={1 + (i % 3) * 0.2} snow />
      ))}
      {Array.from({ length: 34 }, (_, i) => (
        <circle
          key={i}
          cx={(i * 61) % 1000}
          cy={(i * 47) % 300}
          r={1.5 + (i % 3)}
          fill="#fff"
          opacity=".85"
          className="bd-snowflake"
          style={{ animationDelay: `${(i % 9) * 0.6}s` }}
        />
      ))}
    </>
  ),
  volcano: () => (
    <>
      <rect width="1000" height="360" fill="url(#bd-volcano-sky)" />
      <g fill="#2a1a20" opacity=".55">
        <ellipse
          className="bd-cloud"
          style={{ animationDelay: '-8s' }}
          cx="200"
          cy="60"
          rx="90"
          ry="22"
        />
        <ellipse
          className="bd-cloud"
          style={{ animationDelay: '-40s' }}
          cx="760"
          cy="90"
          rx="110"
          ry="26"
        />
      </g>
      <path
        d="M180 260 420 60h160l240 200Z"
        fill="#3b2a2a"
        stroke={OUT}
        strokeWidth="1.500"
        strokeLinejoin="round"
      />
      <path d="M420 60h160l-30 26h-100Z" fill="#ff7a2f" />
      <path
        d="M500 86c-10 40-30 70-24 110M520 90c14 40 10 70 32 106"
        stroke="#ff9a3c"
        strokeWidth="6"
        fill="none"
        strokeLinecap="round"
      />
      <ellipse cx="500" cy="52" rx="90" ry="30" fill="#5a3a3a" opacity=".55" />
      <rect y="262" width="1000" height="98" fill="url(#bd-volcano-ground)" />
      <path
        d="M0 300Q200 280 380 306T760 300 1000 312"
        stroke="#ff7a2f"
        strokeWidth="9"
        fill="none"
        strokeLinecap="round"
      />
      <path
        d="M0 300Q200 280 380 306T760 300 1000 312"
        stroke="#ffd06a"
        strokeWidth="3"
        fill="none"
        strokeLinecap="round"
      />
      {Array.from({ length: 22 }, (_, i) => (
        <circle
          key={i}
          cx={(i * 47 + 20) % 1000}
          cy={120 + ((i * 41) % 200)}
          r="2"
          fill="#ffb347"
          className="bd-ember"
          style={{ animationDelay: `${(i % 7) * 0.5}s` }}
        />
      ))}
    </>
  ),
};

export function Backdrop({ id, className }: { id: ArenaLocation; className?: string }) {
  return (
    <svg
      viewBox="0 0 1000 360"
      preserveAspectRatio="xMidYMid slice"
      className={className ?? 'absolute inset-0 h-full w-full'}
      aria-hidden="true"
      focusable="false"
    >
      <defs>
        <linearGradient id="bd-meadow-sky" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor="#6cc0f0" />
          <stop offset="1" stopColor="#d8f0ff" />
        </linearGradient>
        <linearGradient id="bd-meadow-ground" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor="#6db85a" />
          <stop offset="1" stopColor="#3f8a3a" />
        </linearGradient>
        <linearGradient id="bd-forest-sky" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor="#1e3a3a" />
          <stop offset="1" stopColor="#4a7a58" />
        </linearGradient>
        <linearGradient id="bd-forest-ground" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor="#2f6a3a" />
          <stop offset="1" stopColor="#1c3f26" />
        </linearGradient>
        <linearGradient id="bd-forest-mist" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor="#bfe8c8" stopOpacity="0" />
          <stop offset="0.6" stopColor="#bfe8c8" stopOpacity="0.32" />
          <stop offset="1" stopColor="#bfe8c8" stopOpacity="0" />
        </linearGradient>
        <linearGradient id="bd-ruins-sky" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor="#e8c890" />
          <stop offset="1" stopColor="#f6e6c0" />
        </linearGradient>
        <linearGradient id="bd-ruins-ground" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor="#b8ae94" />
          <stop offset="1" stopColor="#8f866e" />
        </linearGradient>
        <linearGradient id="bd-snow-sky" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor="#9ec4e0" />
          <stop offset="1" stopColor="#e4f1fa" />
        </linearGradient>
        <linearGradient id="bd-snow-ground" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor="#f2f8fc" />
          <stop offset="1" stopColor="#cfe0ec" />
        </linearGradient>
        <linearGradient id="bd-volcano-sky" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor="#3a1a26" />
          <stop offset="1" stopColor="#d9562a" />
        </linearGradient>
        <linearGradient id="bd-volcano-ground" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor="#4a3030" />
          <stop offset="1" stopColor="#241616" />
        </linearGradient>
      </defs>
      {SCENES[id]()}
    </svg>
  );
}
