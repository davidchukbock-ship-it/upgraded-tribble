import { useMemo, type CSSProperties } from 'react';

const COLORS = ['#f2cf6b', '#ff6a5a', '#5ad1ff', '#7ee27a', '#c98bff', '#ffffff'];

/** Конфетти победы: чисто CSS, кусочки падают и гаснут. Отключается при prefers-reduced-motion. */
export function Confetti({ count = 64 }: { count?: number }) {
  const pieces = useMemo(
    () =>
      Array.from({ length: count }, (_, i) => ({
        key: i,
        style: {
          '--x': `${(i * 37) % 100}%`,
          '--d': `${((i * 13) % 20) / 10}s`,
          '--t': `${2.4 + ((i * 7) % 15) / 10}s`,
          '--r': `${(i * 47) % 360}deg`,
          '--c': COLORS[i % COLORS.length],
          '--s': `${((i * 29) % 90) - 45}px`,
        } as CSSProperties,
      })),
    [count],
  );
  return (
    <div className="confetti" aria-hidden="true">
      {pieces.map((p) => (
        <i key={p.key} style={p.style} />
      ))}
    </div>
  );
}
