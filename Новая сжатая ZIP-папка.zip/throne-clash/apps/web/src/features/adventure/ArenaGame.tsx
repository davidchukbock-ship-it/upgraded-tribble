import { useEffect, useMemo, useState, type CSSProperties } from 'react';
import { useTranslation } from 'react-i18next';
import {
  ARENA_LOCATIONS,
  ARENA_PACK,
  ARENA_TIER,
  LOCATION_MODS,
  PACK_COST,
  UNIT_TYPES,
  budgetFor,
  emptyPacks,
  enemyPacks,
  fightArena,
  spent,
  type ArenaLocation,
  type Packs,
  type UnitType,
} from '@tc/shared';
import { UnitArt } from '../../art';
import { playSfx } from '../../audio/useSoundtrack';
import { cn } from '../../lib/cn';
import { useAdventure } from '../../store/adventure';
import { Button, ProgressBar } from '../../ui';
import { Backdrop } from './Backdrop';
import { Confetti } from './Confetti';

type Phase = 'setup' | 'march' | 'fight' | 'result';

interface Fig {
  key: string;
  type: UnitType;
  row: number;
}

const lineup = (p: Packs): Fig[] =>
  UNIT_TYPES.filter((t) => p[t] > 0).flatMap((t, ti) =>
    Array.from({ length: figuresFor(p[t]) }, (_, i) => ({
      key: `${t}-${i}`,
      type: t,
      row: (ti + i) % 3,
    })),
  );

/** Сколько фигур рисовать для отряда: чем больше пачек, тем гуще строй. */
const figuresFor = (packs: number): number => Math.min(4, Math.ceil(packs / 2));

/**
 * Войско на поле. Ближний бой (пехота, конница, осада) выбегает вперёд на удар и возвращается,
 * стрелки остаются позади и бьют залпами, павшие валятся на землю.
 */
function Army({
  packs,
  alive,
  beat,
  phase,
  enemy,
  size,
  hurt,
  cheer,
  defeated,
}: {
  packs: Packs;
  /** Доля живых (0…1): лишние фигуры падают. */
  alive: number;
  /** 0 — рывок вперёд, 1 — удар, 2 — возврат. */
  beat: number;
  phase: Phase;
  enemy?: boolean;
  size: number;
  hurt: boolean;
  cheer: boolean;
  defeated: boolean;
}) {
  const figs = lineup(packs);
  const total = figs.length;
  const standing = defeated ? 0 : Math.ceil(total * alive - 1e-9);
  const scale = total > 10 ? 0.74 : total > 6 ? 0.86 : 1;
  const px = size * scale;
  const fighting = phase === 'fight';
  const lunge = fighting && beat <= 1;
  const mode = (ranged: boolean): 'walk' | 'attack' | 'cheer' | 'idle' =>
    phase === 'march'
      ? 'walk'
      : fighting
        ? ranged
          ? beat === 1
            ? 'attack'
            : 'idle'
          : beat === 1
            ? 'attack'
            : 'walk'
        : cheer
          ? 'cheer'
          : 'idle';
  const group = (list: Fig[], ranged: boolean) => (
    <div
      className={cn('arena-group flex items-end', enemy && 'flex-row-reverse')}
      style={
        {
          transform:
            !ranged && lunge
              ? `translateX(calc(var(--dir) * ${beat === 0 ? 10 : 11.5}vw))`
              : undefined,
          transition: `transform ${beat === 0 ? '0.36s' : '0.4s'} cubic-bezier(0.3, 0, 0.2, 1)`,
        } as CSSProperties
      }
    >
      {list.map((f) => {
        const i = figs.indexOf(f);
        const dead = i >= standing;
        return (
          <span
            key={f.key}
            className={cn('arena-fig inline-flex', dead && 'arena-fig-dead')}
            style={
              {
                marginLeft: -px * 0.16,
                marginBottom: f.row * px * 0.09,
                transform: enemy ? 'scaleX(-1)' : undefined,
                filter: enemy ? 'hue-rotate(160deg) saturate(1.15)' : undefined,
              } as CSSProperties
            }
          >
            <span
              className={cn('inline-flex', hurt && beat === 1 && !dead && 'arena-hurt')}
              style={{ ['--pdir' as string]: enemy ? 1 : -1 } as CSSProperties}
            >
              <UnitArt
                type={f.type}
                tier={ARENA_TIER}
                size={f.type === 'cavalry' || f.type === 'siege' ? px * 0.9 : px}
                anim={dead ? 'idle' : mode(ranged)}
                delay={(i % 4) * 0.13}
              />
            </span>
          </span>
        );
      })}
    </div>
  );
  const ranged = figs.filter((f) => f.type === 'archer');
  const melee = figs.filter((f) => f.type !== 'archer');
  return (
    <div className={cn('arena-army flex items-end gap-[2vw]', enemy && 'flex-row-reverse')}>
      {ranged.length > 0 && group(ranged, true)}
      {melee.length > 0 && group(melee, false)}
    </div>
  );
}

function Stepper({
  type,
  value,
  canAdd,
  onChange,
}: {
  type: UnitType;
  value: number;
  canAdd: boolean;
  onChange: (v: number) => void;
}) {
  const { t } = useTranslation();
  return (
    <li className="flex items-center gap-2 rounded-xl bg-black/30 px-2 py-1.5">
      <UnitArt type={type} tier={ARENA_TIER} size={40} />
      <div className="min-w-0 flex-1">
        <p className="truncate font-display text-xs font-bold sm:text-sm">{t(`unit.${type}`)}</p>
        <p className="text-[11px] opacity-80">
          {t('arena.packInfo', { n: ARENA_PACK, cost: PACK_COST[type] })}
        </p>
      </div>
      <Button
        className="!min-h-[38px] !w-9 !px-0"
        aria-label={`${t('arena.less')}: ${t(`unit.${type}`)}`}
        disabled={value <= 0}
        onClick={() => onChange(value - 1)}
      >
        −
      </Button>
      <span className="w-6 text-center font-display text-base font-bold" aria-live="polite">
        {value}
      </span>
      <Button
        variant="gold"
        className="!min-h-[38px] !w-9 !px-0"
        aria-label={`${t('arena.more')}: ${t(`unit.${type}`)}`}
        disabled={!canAdd}
        onClick={() => onChange(value + 1)}
      >
        +
      </Button>
    </li>
  );
}

/** Знамя у края поля: древко и колышущееся полотнище. */
function Banner({ side, color }: { side: 'left' | 'right'; color: string }) {
  return (
    <svg
      className={cn(
        'arena-banner-flag absolute bottom-[24%] z-[1] h-40 w-16',
        side === 'left' ? 'left-[1.5vw]' : 'right-[1.5vw]',
      )}
      viewBox="0 0 64 160"
      aria-hidden="true"
      focusable="false"
      style={side === 'right' ? { transform: 'scaleX(-1)' } : undefined}
    >
      <rect
        x="8"
        y="6"
        width="5"
        height="150"
        rx="2"
        fill="#5a3620"
        stroke="#2a1a0e"
        strokeWidth="1.500"
      />
      <path
        className="arena-cloth"
        d="M13 12h42l-8 20 8 20H13Z"
        fill={color}
        stroke="#1c1010"
        strokeWidth="1.500"
        strokeLinejoin="round"
      />
      <path
        d="M20 22h26M20 34h20"
        stroke="#fff"
        strokeOpacity=".55"
        strokeWidth="3"
        strokeLinecap="round"
      />
      <circle cx="10.500" cy="5" r="4" fill="#e0b030" stroke="#2a1a0e" />
    </svg>
  );
}

const useFigureSize = (): number => {
  const [w, setW] = useState(() => (typeof window === 'undefined' ? 1200 : window.innerWidth));
  useEffect(() => {
    const on = (): void => setW(window.innerWidth);
    window.addEventListener('resize', on);
    return () => window.removeEventListener('resize', on);
  }, []);
  return w < 700 ? 84 : w < 1100 ? 108 : 138;
};

/** Одиночная Арена на весь экран: локация — сцена, отряды выходят, сходятся и бьются. Ничего не уходит на сервер. */
export function ArenaGame() {
  const { t } = useTranslation();
  const best = useAdventure((s) => s.arenaWave);
  const report = useAdventure((s) => s.reportArena);
  const size = useFigureSize();
  const [phase, setPhase] = useState<Phase>('setup');
  const [location, setLocation] = useState<ArenaLocation>('meadow');
  const [wave, setWave] = useState(1);
  const [seed, setSeed] = useState(() => 1 + Math.floor(Math.random() * 1_000_000));
  const [mine, setMine] = useState<Packs>(() => ({ ...emptyPacks(), infantry: 3, archer: 3 }));
  const [step, setStep] = useState(0);

  const budget = budgetFor(wave);
  const used = spent(mine);
  const enemy = useMemo(() => enemyPacks(wave, seed), [wave, seed]);
  const fight = useMemo(
    () => (phase === 'setup' ? null : fightArena({ mine, wave, location, seed })),
    // бой считаем один раз при выходе из подготовки
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [phase === 'setup'],
  );
  const rounds = fight?.result.rounds.length ?? 0;
  const res = fight?.result;

  // Ход схватки: марш, затем раунды из трёх тактов (рывок → удар → возврат), затем итог
  const [beat, setBeat] = useState(0);
  useEffect(() => {
    if (phase === 'march') {
      playSfx('march');
      const id = setTimeout(() => {
        setStep(1);
        setBeat(0);
        setPhase('fight');
      }, 1700);
      return () => clearTimeout(id);
    }
    if (phase !== 'fight') return;
    const r = res?.rounds[step - 1];
    setBeat(0);
    const ids: ReturnType<typeof setTimeout>[] = [];
    if (mine.archer > 0 || enemy.archer > 0) ids.push(setTimeout(() => playSfx('arrow'), 60));
    ids.push(
      setTimeout(() => {
        setBeat(1);
        playSfx('slash');
        playSfx('clash');
        if (r && r.attackerLosses + r.defenderLosses > 0)
          ids.push(setTimeout(() => playSfx('thud'), 140));
      }, 380),
    );
    ids.push(setTimeout(() => setBeat(2), 1050));
    ids.push(
      setTimeout(() => {
        if (step >= rounds) setPhase('result');
        else setStep((v) => v + 1);
      }, 1500),
    );
    return () => ids.forEach(clearTimeout);
    // step и phase управляют таймерами; mine/enemy/res не меняются в бою
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, step]);

  useEffect(() => {
    if (phase !== 'result' || !fight) return;
    playSfx(fight.won ? 'victory' : 'defeat');
    if (!fight.won) return;
    const id = setTimeout(() => playSfx('cheer'), 500);
    report(wave); // рекорд — последняя пройденная волна
    return () => clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase]);

  const start = () => {
    setStep(0);
    setPhase('march');
  };
  const nextWave = () => {
    setWave((w) => w + 1);
    setSeed(1 + Math.floor(Math.random() * 1_000_000));
    setPhase('setup');
  };
  const restart = () => {
    setWave(1);
    setSeed(1 + Math.floor(Math.random() * 1_000_000));
    setMine({ ...emptyPacks(), infantry: 3, archer: 3 });
    setPhase('setup');
  };

  const totalMine = res ? Object.values(res.attacker.start).reduce((s, n) => s + (n ?? 0), 0) : 0;
  const totalEnemy = res ? Object.values(res.defender.start).reduce((s, n) => s + (n ?? 0), 0) : 0;
  const cur = res && step > 0 ? res.rounds[Math.min(step, rounds) - 1] : undefined;
  const prev = res && step > 1 ? res.rounds[Math.min(step, rounds) - 2] : undefined;
  const inBattle = phase === 'fight' || phase === 'result';
  // Потери проявляются в момент удара (такт 1), а не в начале раунда
  const shown = phase === 'fight' && beat < 1 ? prev : cur;
  const aliveMine = inBattle ? (shown?.attackerAlive ?? totalMine) : totalMine;
  const aliveEnemy = inBattle ? (shown?.defenderAlive ?? totalEnemy) : totalEnemy;
  const won = fight?.won ?? false;
  const log = cur;
  const engaged = phase !== 'setup';
  const impact = phase === 'fight' && beat === 1;

  return (
    <div className="absolute inset-0 overflow-hidden" data-testid="arena">
      <Backdrop id={location} />

      {/* поле боя: отряды выходят из углов, сходятся, бьются и возвращаются */}
      <div
        key={impact ? `hit${step}` : 'calm'}
        className={cn('arena-field absolute inset-x-0', impact && 'arena-shake')}
        style={{
          bottom: phase === 'setup' ? '46%' : '26%',
          transform: impact ? 'scale(1.035)' : undefined,
        }}
        role="img"
        aria-label={t('arena.stageLabel', { name: t(`arena.loc.${location}`) })}
      >
        <div className="flex items-end justify-between px-[4vw]">
          <div
            className={cn('arena-side', engaged && 'arena-side-in')}
            style={{ ['--dir' as string]: 1 } as CSSProperties}
          >
            <Army
              packs={mine}
              alive={totalMine ? aliveMine / totalMine : 1}
              beat={beat}
              phase={phase}
              size={size}
              hurt={(log?.attackerLosses ?? 0) > 0}
              cheer={won}
              defeated={phase === 'result' && !won}
            />
            {impact && log && log.attackerLosses > 0 && (
              <span key={`m${step}`} className="arena-pop">
                −{log.attackerLosses}
              </span>
            )}
          </div>
          <div
            className={cn('arena-side', engaged && 'arena-side-in')}
            style={{ ['--dir' as string]: -1 } as CSSProperties}
          >
            <Army
              packs={enemy}
              alive={totalEnemy ? aliveEnemy / totalEnemy : 1}
              beat={beat}
              phase={phase}
              enemy
              size={size}
              hurt={(log?.defenderLosses ?? 0) > 0}
              cheer={!won}
              defeated={phase === 'result' && won}
            />
            {impact && log && log.defenderLosses > 0 && (
              <span key={`e${step}`} className="arena-pop">
                −{log.defenderLosses}
              </span>
            )}
          </div>
        </div>
      </div>
      {impact && (
        <i
          key={`spark${step}`}
          className="arena-spark"
          style={{ bottom: '33%' }}
          aria-hidden="true"
        />
      )}
      {phase === 'fight' && beat === 0 && (
        <div key={`fx${step}`} className="arena-fx" style={{ bottom: '38%' }} aria-hidden="true">
          {mine.archer > 0 &&
            [0, 1, 2, 3].map((i) => (
              <i
                key={`a${i}`}
                className="arena-arrow"
                style={{ animationDelay: `${i * 0.09}s`, top: `${i * 12}px` }}
              />
            ))}
          {enemy.archer > 0 &&
            [0, 1, 2, 3].map((i) => (
              <i
                key={`b${i}`}
                className="arena-arrow arena-arrow-back"
                style={{ animationDelay: `${0.1 + i * 0.09}s`, top: `${i * 12 + 6}px` }}
              />
            ))}
        </div>
      )}
      {(phase === 'march' || (phase === 'fight' && beat !== 1)) && (
        <div className="arena-dust-row" style={{ bottom: '25%' }} aria-hidden="true">
          {Array.from({ length: 14 }, (_, i) => (
            <i
              key={`${phase}-${beat}-${i}`}
              style={{
                left: `${(i % 7) * 4 + (i < 7 ? 6 : 68) + (phase === 'fight' ? 14 : 0)}%`,
                animationDelay: `${(i % 5) * 0.12}s`,
              }}
            />
          ))}
        </div>
      )}
      {phase === 'result' && won && <Confetti />}
      <Banner side="left" color="#3f68b4" />
      <Banner side="right" color="#b33a2a" />

      <div className="glass absolute left-1/2 top-2 md:top-[calc(var(--hdr,4rem)+0.5rem)] z-10 flex -translate-x-1/2 flex-col items-center gap-1 px-4 py-1.5 text-sm">
        <p className="font-display font-bold text-gold-light">
          {t('arena.wave', { n: wave })}{' '}
          <span className="font-normal opacity-80">· {t('arena.best', { n: best })}</span>
        </p>
        {engaged && res && (
          <div className="flex w-[min(34rem,80vw)] items-center gap-3">
            <ProgressBar
              className="flex-1"
              value={aliveMine}
              max={Math.max(1, totalMine)}
              label={t('arena.you')}
              text={`${t('arena.you')}: ${aliveMine}`}
            />
            <ProgressBar
              className="flex-1"
              value={aliveEnemy}
              max={Math.max(1, totalEnemy)}
              label={t('arena.enemy')}
              text={`${t('arena.enemy')}: ${aliveEnemy}`}
            />
          </div>
        )}
      </div>

      {phase === 'result' && (
        <div className="absolute left-1/2 top-[38%] z-10 flex -translate-x-1/2 -translate-y-1/2 flex-col items-center gap-3">
          <p
            role="status"
            className={cn(
              'arena-banner rounded-2xl px-8 py-3 font-display text-3xl font-bold text-white shadow-xl',
              won ? 'bg-green-btn' : 'bg-red',
            )}
          >
            {won ? t('arena.victory') : t('arena.defeat')}
          </p>
          <div className="flex flex-wrap justify-center gap-2">
            {won ? (
              <Button variant="gold" onClick={nextWave}>
                {t('arena.next')}
              </Button>
            ) : (
              <Button variant="gold" onClick={restart}>
                {t('arena.again')}
              </Button>
            )}
            {won && <Button onClick={restart}>{t('arena.restart')}</Button>}
          </div>
        </div>
      )}

      {inBattle && log && (
        <p className="glass absolute bottom-3 left-3 z-10 max-w-[70vw] px-3 py-1.5 text-sm">
          {t('arena.round', { n: log.round, mine: log.attackerLosses, enemy: log.defenderLosses })}
        </p>
      )}
      {phase === 'march' && (
        <p className="glass absolute bottom-3 left-3 z-10 px-3 py-1.5 text-sm">
          {t('arena.marching')}
        </p>
      )}

      {phase === 'setup' && (
        <section
          aria-label={t('arena.army')}
          className="glass absolute inset-x-3 bottom-3 z-10 mx-auto flex max-h-[46%] max-w-4xl flex-col gap-2 overflow-auto p-3"
        >
          <div
            role="radiogroup"
            aria-label={t('arena.location')}
            className="flex gap-2 overflow-x-auto pb-1"
          >
            {ARENA_LOCATIONS.map((id) => (
              <button
                key={id}
                type="button"
                role="radio"
                aria-checked={location === id}
                onClick={() => setLocation(id)}
                className={cn(
                  'relative h-14 w-24 shrink-0 overflow-hidden rounded-lg border-2',
                  location === id ? 'border-gold' : 'border-transparent opacity-75',
                )}
              >
                <Backdrop id={id} />
                <span className="absolute inset-x-0 bottom-0 bg-black/65 px-1 text-[11px] font-bold leading-4 text-white">
                  {t(`arena.loc.${id}`)}
                </span>
              </button>
            ))}
          </div>
          <p className="text-xs opacity-90">
            {t(`arena.locText.${location}`)}{' '}
            {UNIT_TYPES.filter((u) => LOCATION_MODS[location].attack[u] !== 0).map((u) => (
              <b
                key={u}
                className={
                  LOCATION_MODS[location].attack[u] > 0 ? 'text-green-300' : 'text-red-300'
                }
              >
                {t(`unit.${u}`)} {LOCATION_MODS[location].attack[u] > 0 ? '+' : ''}
                {Math.round(LOCATION_MODS[location].attack[u] * 100)}%{' '}
              </b>
            ))}
          </p>
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="text-sm font-bold" aria-live="polite">
              {t('arena.points', { used, budget })}
            </span>
            <span className="text-xs opacity-80">
              {t('arena.enemyScout', {
                list: UNIT_TYPES.filter((u) => enemy[u] > 0)
                  .map((u) => `${t(`unit.${u}`)} ×${enemy[u]}`)
                  .join(', '),
              })}
            </span>
          </div>
          <ul className="grid gap-2 sm:grid-cols-2">
            {UNIT_TYPES.map((u) => (
              <Stepper
                key={u}
                type={u}
                value={mine[u]}
                canAdd={used + PACK_COST[u] <= budget}
                onChange={(v) => setMine((m) => ({ ...m, [u]: v }))}
              />
            ))}
          </ul>
          <div>
            <Button variant="gold" disabled={used === 0} onClick={start}>
              {t('arena.fight')}
            </Button>
          </div>
        </section>
      )}
    </div>
  );
}
