import { useCallback, useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { NpcArt } from '../../art';
import { cn } from '../../lib/cn';
import { useAdventure } from '../../store/adventure';
import { playSfx } from '../../audio/useSoundtrack';
import { Button } from '../../ui';
import { CASTS, isHit, markerAt, medal, pickFish, zoneFor, type Fish } from './fishing';

type Phase = 'idle' | 'waiting' | 'bite' | 'done';
type Motion = { k: 'cast' | 'reel' | 'flee'; p: number };
const LAND = { x: 640, y: 330 };
const ease = (p: number): number => 1 - (1 - p) * (1 - p);
const arc = (a: { x: number; y: number }, b: { x: number; y: number }, p: number, h: number) => ({
  x: a.x + (b.x - a.x) * p,
  y: a.y + (b.y - a.y) * p - h * Math.sin(Math.PI * p),
});
const BITE_MS = 4200;
const SPEED = 0.85;

function FishShape({
  fish,
  x,
  y,
  flip = false,
}: {
  fish: Fish;
  x: number;
  y: number;
  flip?: boolean;
}) {
  return (
    <g transform={`translate(${x} ${y}) scale(${flip ? -1 : 1} 1)`}>
      <g className="fs-tail">
        <path
          d="M14 0L36 -15Q32 0 36 15Z"
          fill={fish.color}
          stroke="#1c2a3e"
          strokeWidth="1.500"
          strokeLinejoin="round"
        />
      </g>
      <path
        d="M-26 0Q-6 -16 18 -2Q18 2 18 2Q-6 16 -26 0Z"
        fill={fish.color}
        stroke="#1c2a3e"
        strokeWidth="1.500"
        strokeLinejoin="round"
      />
      <path d="M-6 -10L2 -20L8 -8Z" fill={fish.color} stroke="#1c2a3e" strokeWidth="1.200" />
      <path d="M-12 6Q-2 12 4 8" stroke="#fff" strokeOpacity=".35" strokeWidth="2" fill="none" />
      <circle cx="-16" cy="-2" r="2.500" fill="#fff" stroke="#1c2a3e" />
      <path d="M-4 -8Q4 0 -4 8" stroke="#fff" strokeOpacity=".5" strokeWidth="2" fill="none" />
    </g>
  );
}

/** Одиночная «Рыбалка» на весь экран: закинь удочку и подсеки рыбу, пока бегунок в зелёной зоне. */
export function FishingGame() {
  const { t } = useTranslation();
  const best = useAdventure((s) => s.fishing);
  const report = useAdventure((s) => s.reportFishing);
  const [phase, setPhase] = useState<Phase>('idle');
  const [casts, setCasts] = useState(0);
  const [score, setScore] = useState(0);
  const [fish, setFish] = useState<Fish | null>(null);
  const [zone, setZone] = useState({ from: 0.4, to: 0.6 });
  const [marker, setMarker] = useState(0);
  const [msg, setMsg] = useState('');
  const [catchKey, setCatchKey] = useState(0);
  const [joy, setJoy] = useState(false);
  const [mv, setMv] = useState<Motion | null>(null);
  const [fishP, setFishP] = useState(0);
  const [prize, setPrize] = useState<Fish | null>(null);
  const mvRaf = useRef(0);

  const runMotion = useCallback((k: Motion['k'], ms: number) => {
    cancelAnimationFrame(mvRaf.current);
    const start = performance.now();
    const step = () => {
      const p = Math.min(1, (performance.now() - start) / ms);
      if (p >= 1) return setMv(null);
      setMv({ k, p });
      mvRaf.current = requestAnimationFrame(step);
    };
    step();
  }, []);
  useEffect(() => () => cancelAnimationFrame(mvRaf.current), []);
  const t0 = useRef(0);
  const raf = useRef(0);

  const finishCast = useCallback(
    (caught: Fish | null) => {
      cancelAnimationFrame(raf.current);
      const next = casts + 1;
      const add = caught?.points ?? 0;
      setScore((s) => s + add);
      setMsg(
        caught
          ? t('fishing.caught', { fish: t(`fishing.fish.${caught.id}`), n: caught.points })
          : t('fishing.escaped'),
      );
      if (caught) {
        setCatchKey((k) => k + 1);
        setPrize(caught);
        runMotion('reel', 950);
        playSfx('splash');
        setTimeout(() => {
          setJoy(true);
          playSfx(caught.id === 'golden' ? 'chest' : 'coin');
          playSfx('cheer');
        }, 900);
        setTimeout(() => {
          setJoy(false);
          setPrize(null);
        }, 2600);
      } else {
        runMotion('flee', 800);
        playSfx('error');
      }
      setCasts(next);
      if (next >= CASTS) {
        setPhase('done');
        report(score + add);
        setTimeout(() => playSfx(medal(score + add) === 'none' ? 'defeat' : 'victory'), 700);
      } else setPhase('idle');
    },
    [casts, score, report, t, runMotion],
  );

  // Ожидание поклёвки
  useEffect(() => {
    if (phase !== 'waiting') return;
    const id = setTimeout(
      () => {
        const f = pickFish(Math.random());
        setFish(f);
        setZone(zoneFor(f, Math.random()));
        t0.current = performance.now();
        setFishP(0);
        setPhase('bite');
        playSfx('bite');
      },
      800 + Math.random() * 1800,
    );
    return () => clearTimeout(id);
  }, [phase]);

  // Бегунок и таймаут поклёвки
  useEffect(() => {
    if (phase !== 'bite') return;
    const tick = () => {
      const dt = performance.now() - t0.current;
      if (dt > BITE_MS) return finishCast(null);
      setMarker(markerAt(dt / 1000, SPEED));
      setFishP(Math.min(1, dt / 750));
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf.current);
  }, [phase, finishCast]);

  const hook = useCallback(() => {
    if (phase === 'idle') {
      setMsg('');
      setPhase('waiting');
      runMotion('cast', 700);
      playSfx('slash');
      setTimeout(() => playSfx('splash'), 620);
    } else if (phase === 'bite' && fish) {
      finishCast(isHit(marker, zone) ? fish : null);
    }
  }, [phase, fish, marker, zone, finishCast, runMotion]);

  // Пробел — то же, что и кнопка
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (
        e.code === 'Space' &&
        (phase === 'idle' || phase === 'bite') &&
        document.activeElement?.tagName !== 'BUTTON'
      ) {
        e.preventDefault();
        hook();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [phase, hook]);

  const restart = () => {
    setPhase('idle');
    setCasts(0);
    setScore(0);
    setFish(null);
    setMsg('');
  };
  const m = medal(score);
  const out = phase !== 'idle' && phase !== 'done';
  const bend = mv?.k === 'reel' ? 26 * Math.sin(Math.PI * mv.p) : phase === 'bite' ? 6 : 0;
  const tip = { x: 470, y: 130 + bend };
  const rest = { x: 498, y: 214 };
  const pos = mv
    ? mv.k === 'cast'
      ? arc(tip, LAND, ease(mv.p), 150)
      : arc(LAND, tip, ease(mv.p), 60)
    : out
      ? LAND
      : rest;
  const bx = pos.x;
  const by = pos.y;
  const fishAt = {
    x: bx + 270 * (1 - ease(fishP)) - 10,
    y: by + 60 + 60 * (1 - ease(fishP)),
  };
  const fleeing = mv?.k === 'flee' ? mv.p : 0;

  return (
    <div
      className="absolute inset-0 overflow-hidden"
      role="img"
      aria-label={t('fishing.sceneLabel')}
    >
      <svg
        viewBox="0 0 1000 560"
        preserveAspectRatio="xMidYMid slice"
        className="absolute inset-0 h-full w-full"
        aria-hidden="true"
        focusable="false"
      >
        <defs>
          <linearGradient id="fs-sky" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0" stopColor="#ff9f5a" />
            <stop offset="1" stopColor="#ffe3b0" />
          </linearGradient>
          <linearGradient id="fs-sea" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0" stopColor="#3f9ad0" />
            <stop offset="1" stopColor="#0f3d6a" />
          </linearGradient>
        </defs>
        <rect width="1000" height="560" fill="url(#fs-sky)" />
        <circle cx="780" cy="170" r="70" fill="#fff3c0" opacity=".95" />
        <path d="M0 230Q160 200 300 226T600 220T1000 214V250H0Z" fill="#6a7fa0" opacity=".55" />
        <rect y="240" width="1000" height="320" fill="url(#fs-sea)" />
        {[0, 1, 2, 3].map((i) => (
          <path
            key={`ray${i}`}
            d={`M${140 + i * 240} 250l60 0l-90 310l-60 0Z`}
            fill="#fff"
            opacity=".07"
            className="fs-ray"
            style={{ animationDelay: `${-i * 2.2}s` }}
          />
        ))}
        {Array.from({ length: 14 }, (_, i) => (
          <circle
            key={`bub${i}`}
            cx={90 + ((i * 137) % 860)}
            cy={540}
            r={2 + (i % 3)}
            fill="none"
            stroke="#d8f2ff"
            strokeOpacity=".7"
            className="fs-bubble"
            style={{ animationDelay: `${-(i % 7) * 1.3}s`, animationDuration: `${7 + (i % 5)}s` }}
          />
        ))}
        <path
          d="M0 242q125-12 250 0t250 0 250 0 250 0"
          stroke="#fff"
          strokeOpacity=".55"
          strokeWidth="3"
          fill="none"
        />
        <path
          d="M640 250h130"
          stroke="#fff3c0"
          strokeOpacity=".6"
          strokeWidth="6"
          strokeLinecap="round"
        />
        {Array.from({ length: 22 }, (_, i) => (
          <path
            key={i}
            d={`M${30 + i * 46} ${290 + (i % 5) * 46}q14-8 28 0t28 0`}
            stroke="#fff"
            strokeOpacity=".35"
            strokeWidth="2.500"
            fill="none"
            className="scene-wave"
            style={{ animationDelay: `${(i % 6) * 0.4}s` }}
          />
        ))}
        {/* далёкий остров, облака, чайки, блики и тени рыб */}
        <path d="M700 240q40-38 90-30t70 30Z" fill="#4a5f7a" opacity=".55" />
        <path d="M740 240q20-22 50-18t40 18Z" fill="#3f5670" opacity=".6" />
        {[
          [140, 90, 1],
          [520, 60, 0.8],
          [880, 130, 0.9],
        ].map(([x, y, sc], i) => (
          <g key={i} className="bd-cloud" style={{ animationDelay: `${-i * 25}s` }}>
            <g transform={`translate(${x} ${y}) scale(${sc})`} fill="#fff" opacity=".8">
              <ellipse cx="0" cy="0" rx="52" ry="16" />
              <ellipse cx="-26" cy="-10" rx="28" ry="16" />
              <ellipse cx="16" cy="-14" rx="32" ry="18" />
            </g>
          </g>
        ))}
        <g
          className="fs-gulls"
          fill="none"
          stroke="#2b3340"
          strokeWidth="2.200"
          strokeLinecap="round"
        >
          {[0, 1, 2].map((i) => (
            <path key={i} d={`M${i * 34} ${i % 2 ? 26 : 8}q8-9 16 0q8-9 16 0`} />
          ))}
        </g>
        <g opacity=".5">
          {[0, 1, 2, 3, 4].map((i) => (
            <rect
              key={i}
              x={690 + i * 8}
              y={252 + i * 16}
              width={90 - i * 14}
              height="4"
              rx="2"
              fill="#fff3c0"
              className="scene-wave"
              style={{ animationDelay: `${i * 0.3}s` }}
            />
          ))}
        </g>
        {[0, 1, 2].map((i) => (
          <g
            key={i}
            className="fs-shadow"
            style={{ animationDelay: `${-i * 9}s`, animationDuration: `${26 + i * 5}s` }}
          >
            <ellipse cx="0" cy={400 + i * 40} rx={26 + i * 6} ry="8" fill="#0a2a4a" opacity=".35" />
            <path d={`M${26 + i * 6} ${400 + i * 40}l14-8v16Z`} fill="#0a2a4a" opacity=".35" />
          </g>
        ))}
        {/* лодка качается */}
        <g className="iso-boat-bob">
          <path
            d="M60 268h330l-40 46H100Z"
            fill="#8a5a34"
            stroke="#2a1a0e"
            strokeWidth="2.500"
            strokeLinejoin="round"
          />
          <path d="M84 282h284" stroke="#e0b030" strokeWidth="4" />
          <path
            d={`M250 256Q${370} ${180 + bend * 0.2} ${tip.x} ${tip.y}`}
            stroke="#5a3620"
            strokeWidth="6"
            strokeLinecap="round"
            fill="none"
          />
          <foreignObject x="150" y="150" width="150" height="150">
            <NpcArt
              name="farmer"
              size={140}
              anim={joy ? 'cheer' : phase === 'bite' ? 'attack' : 'idle'}
            />
          </foreignObject>
        </g>
        {/* леска и поплавок */}
        <path
          d={`M${tip.x} ${tip.y}Q${(tip.x + bx) / 2 + 10} ${Math.max(tip.y, by) + (mv ? 10 : 40)} ${bx} ${by}`}
          stroke="#fff"
          strokeOpacity=".85"
          strokeWidth="1.800"
          fill="none"
        />
        <circle
          cx={bx}
          cy={by}
          r="9"
          fill="#e0342c"
          stroke="#fff"
          strokeWidth="3"
          className={mv ? undefined : phase === 'bite' ? 'fs-bobber-bite' : 'fs-bobber'}
        />
        {(out || mv?.k === 'reel' || mv?.k === 'flee') && (
          <g
            key={`ring${casts}${mv?.k ?? ''}`}
            className="fs-ring"
            style={{ transformOrigin: `${LAND.x}px ${LAND.y + 4}px` }}
          >
            <ellipse
              cx={LAND.x}
              cy={LAND.y + 4}
              rx="22"
              ry="7"
              fill="none"
              stroke="#fff"
              strokeWidth="2"
            />
          </g>
        )}
        {phase === 'bite' && fish && (
          <g opacity={0.55 + 0.45 * ease(fishP)}>
            <FishShape fish={fish} x={fishAt.x} y={fishAt.y} />
          </g>
        )}
        {mv?.k === 'flee' && fish && (
          <g opacity={1 - fleeing}>
            <FishShape fish={fish} x={LAND.x + 40 + 260 * fleeing} y={LAND.y + 60 + 30 * fleeing} />
          </g>
        )}
        {mv?.k === 'reel' && prize && <FishShape fish={prize} x={bx} y={by + 16} />}
        {!mv && joy && prize && (
          <g key={`hang${catchKey}`}>
            <path
              d={`M${tip.x} ${tip.y}V${tip.y + 36}`}
              stroke="#fff"
              strokeOpacity=".85"
              strokeWidth="1.800"
            />
            <g className="fs-dangle" style={{ transformOrigin: `${tip.x}px ${tip.y}px` }}>
              <FishShape fish={prize} x={tip.x} y={tip.y + 52} />
            </g>
            <text
              x={tip.x + 70}
              y={tip.y - 6}
              className="fs-pop"
              fill="#ffe27a"
              stroke="#5a3620"
              strokeWidth="1"
              fontSize="34"
              fontWeight="800"
              textAnchor="middle"
            >
              +{prize.points}
            </text>
          </g>
        )}
        {phase === 'idle' && <FishShape fish={FISH_SHADOW} x={820} y={430} flip />}
        {catchKey > 0 && mv?.k === 'reel' && mv.p < 0.25 && (
          <g key={`drops${catchKey}`} aria-hidden="true">
            {Array.from({ length: 9 }, (_, i) => (
              <circle
                key={i}
                cx={LAND.x}
                cy={LAND.y}
                r="4"
                fill="#bfe8ff"
                className="fs-drop"
                style={
                  {
                    ['--dx' as string]: `${(i - 4) * 16}px`,
                    animationDelay: `${(i % 3) * 0.05}s`,
                  } as React.CSSProperties
                }
              />
            ))}
          </g>
        )}
      </svg>

      <div className="glass absolute left-1/2 top-2 md:top-[calc(var(--hdr,4rem)+0.5rem)] z-10 flex -translate-x-1/2 flex-wrap items-center justify-center gap-x-4 gap-y-1 px-4 py-1.5 text-sm">
        <span className="font-display font-bold text-gold-light">{t('fishing.title')}</span>
        <span aria-live="polite">
          {t('fishing.status', { casts: Math.min(casts, CASTS), total: CASTS, score })}
        </span>
        <span className="opacity-80">{t('fishing.best', { n: best })}</span>
      </div>

      <div className="glass absolute inset-x-3 bottom-3 z-10 mx-auto flex max-w-2xl flex-col items-center gap-2 p-3">
        {phase === 'bite' && (
          <div className="w-full">
            <p className="mb-1 text-sm font-bold">{t('fishing.bite')}</p>
            <div
              className="relative h-8 overflow-hidden rounded-full border-2 border-black/50 bg-black/40"
              role="img"
              aria-label={t('fishing.barLabel')}
            >
              <div
                className="absolute inset-y-0 bg-green-500/80"
                style={{ left: `${zone.from * 100}%`, width: `${(zone.to - zone.from) * 100}%` }}
              />
              <div
                className="absolute inset-y-0 w-1.5 -translate-x-1/2 bg-white shadow"
                style={{ left: `${marker * 100}%` }}
              />
            </div>
          </div>
        )}
        <p role="status" className="min-h-[1.5rem] text-sm font-semibold">
          {phase === 'waiting' ? t('fishing.waiting') : msg}
        </p>
        {phase === 'done' ? (
          <div className="flex flex-wrap items-center justify-center gap-3">
            <p className="font-display text-lg font-bold">
              {t('fishing.final', { n: score })}{' '}
              {m !== 'none' && <span>· {t(`fishing.medal.${m}`)}</span>}
            </p>
            <Button variant="gold" onClick={restart}>
              {t('fishing.again')}
            </Button>
          </div>
        ) : (
          <Button
            variant="gold"
            disabled={phase === 'waiting'}
            className={cn(phase === 'bite' && 'animate-pulse')}
            onClick={hook}
          >
            {phase === 'bite' ? t('fishing.hook') : t('fishing.cast')}
          </Button>
        )}
      </div>
    </div>
  );
}

const FISH_SHADOW: Fish = { id: 'sardine', points: 0, zone: 0, weight: 0, color: '#2b5a86' };
