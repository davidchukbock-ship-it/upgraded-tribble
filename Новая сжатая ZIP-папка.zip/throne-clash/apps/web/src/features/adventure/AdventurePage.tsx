import { useState } from 'react';
import { createPortal } from 'react-dom';
import { useTranslation } from 'react-i18next';
import { cn } from '../../lib/cn';
import { ArenaGame } from './ArenaGame';
import { FishingGame } from './FishingGame';
import { RuneGame } from './RuneGame';

const GAMES = ['arena', 'fishing', 'runes'] as const;
type Game = (typeof GAMES)[number];

/**
 * Приключения: одиночные игры вне мультиплеера, каждая на весь экран. Ничего не уходит на сервер
 * и не влияет на замок (D-67). Выбор игры — лёгкие вкладки в углу поверх сцены.
 */
export function AdventurePage() {
  const { t } = useTranslation();
  const [game, setGame] = useState<Game>('arena');
  return createPortal(
    <div className="fixed inset-x-0 bottom-0 top-[var(--hdr,0px)] z-20 md:top-0 bg-[#0b1626]">
      <h1 className="sr-only">{t('nav.adventure')}</h1>
      {game === 'arena' && <ArenaGame />}
      {game === 'fishing' && <FishingGame />}
      {game === 'runes' && <RuneGame />}
      <div
        role="tablist"
        aria-label={t('nav.adventure')}
        className="glass absolute left-3 top-2 md:top-[calc(var(--hdr,4rem)+0.5rem)] z-30 flex gap-1 p-1"
      >
        {GAMES.map((id) => (
          <button
            key={id}
            type="button"
            role="tab"
            aria-selected={game === id}
            onClick={() => setGame(id)}
            className={cn(
              'min-h-[38px] rounded-lg px-3 font-display text-sm font-bold',
              game === id ? 'bg-gold text-ink' : 'text-parchment hover:bg-white/10',
            )}
          >
            {t(`adventure.${id}`)}
          </button>
        ))}
      </div>
    </div>,
    document.body,
  );
}
