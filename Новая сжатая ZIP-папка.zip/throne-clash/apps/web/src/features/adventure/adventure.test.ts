import { describe, expect, it } from 'vitest';
import { CASTS, FISH, isHit, markerAt, medal, pickFish, zoneFor } from './fishing';
import { PAIRS, deal, isMatch, stars } from './runes';

describe('рыбалка', () => {
  it('выбор рыбы по весам: границы шкалы и редкость', () => {
    expect(pickFish(0).id).toBe('sardine');
    expect(pickFish(0.999).id).toBe('golden');
    let golden = 0;
    for (let i = 0; i < 1000; i++) if (pickFish(i / 1000).id === 'golden') golden++;
    expect(golden).toBeGreaterThan(20);
    expect(golden).toBeLessThan(90);
  });

  it('чем ценнее рыба, тем уже зона; зона всегда внутри полосы', () => {
    const widths = FISH.map((f) => f.zone);
    expect([...widths].sort((a, b) => b - a)).toEqual(widths);
    for (const f of FISH)
      for (const r of [0, 0.5, 1]) {
        const z = zoneFor(f, r);
        expect(z.from).toBeGreaterThanOrEqual(0);
        expect(z.to).toBeLessThanOrEqual(1);
        expect(z.to - z.from).toBeCloseTo(f.zone, 9);
      }
  });

  it('бегунок ходит туда-обратно в пределах 0…1; попадание считается по зоне', () => {
    expect(markerAt(0, 1)).toBe(0);
    expect(markerAt(1, 1)).toBe(1);
    expect(markerAt(1.5, 1)).toBeCloseTo(0.5, 9);
    for (let t = 0; t < 9; t += 0.37) {
      const m = markerAt(t, 0.9);
      expect(m).toBeGreaterThanOrEqual(0);
      expect(m).toBeLessThanOrEqual(1);
    }
    expect(isHit(0.5, { from: 0.4, to: 0.6 })).toBe(true);
    expect(isHit(0.7, { from: 0.4, to: 0.6 })).toBe(false);
  });

  it('медали и число забросов', () => {
    expect(CASTS).toBe(10);
    expect(medal(0)).toBe('none');
    expect(medal(10)).toBe('bronze');
    expect(medal(22)).toBe('silver');
    expect(medal(35)).toBe('gold');
  });
});

describe('память рун', () => {
  it('колода из пар, воспроизводима по зерну, зерно меняет порядок', () => {
    const a = deal(5);
    expect(deal(5)).toEqual(a);
    expect(deal(6)).not.toEqual(a);
    expect(a).toHaveLength(PAIRS * 2);
    for (let v = 0; v < PAIRS; v++) expect(a.filter((x) => x === v)).toHaveLength(2);
  });

  it('пара — две разные карты с одним значением; звёзды по ходам', () => {
    const cards = [0, 1, 0, 1];
    expect(isMatch(cards, 0, 2)).toBe(true);
    expect(isMatch(cards, 0, 1)).toBe(false);
    expect(isMatch(cards, 0, 0)).toBe(false);
    expect(stars(8)).toBe(3);
    expect(stars(14)).toBe(2);
    expect(stars(30)).toBe(1);
  });
});
