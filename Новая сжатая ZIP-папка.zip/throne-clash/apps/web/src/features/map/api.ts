import type {
  CastleDto,
  MapOverviewDto,
  MapSearchResultDto,
  MapTilesDto,
  MarchType,
  ReportDto,
  ReportPageDto,
  UnitCounts,
} from '@tc/shared';
import { apiFetch } from '../../lib/api';

export const mapApi = {
  tiles: (x: number, y: number, size: number) =>
    apiFetch<MapTilesDto>(`/api/map/tiles?x=${x}&y=${y}&size=${size}`),
  overview: () => apiFetch<MapOverviewDto>('/api/map/overview'),
  search: (q: string) =>
    apiFetch<MapSearchResultDto[]>(`/api/map/search?q=${encodeURIComponent(q)}`),
};

export interface SendMarch {
  type: MarchType;
  target: { x: number; y: number };
  units: UnitCounts;
}

export const marchApi = {
  send: (v: SendMarch) =>
    apiFetch<CastleDto>('/api/marches', {
      method: 'POST',
      body: v,
      headers: { 'Idempotency-Key': crypto.randomUUID() },
    }),
};

export const reportApi = {
  list: (page: number, pageSize = 20) =>
    apiFetch<ReportPageDto>(`/api/reports?page=${page}&pageSize=${pageSize}`),
  get: (id: string) => apiFetch<ReportDto>(`/api/reports/${id}`),
};
