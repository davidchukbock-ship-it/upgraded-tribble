import { useEffect, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { MAP_SIZE } from '@tc/shared';
import { mapApi } from './api';

const COLOR: Record<string, string> = {
  p: '#8ccf68',
  f: '#3f9a45',
  m: '#a3a19b',
  w: '#3b8fd6',
  d: '#e4cf8f',
  s: '#5f8a4f',
  o: '#2a6aac',
  l: '#4a93d0',
  r: '#5aa6dc',
};

export interface MiniView {
  x: number;
  y: number;
  /** Сторона видимой области в клетках. */
  span: number;
}

/**
 * Мини-карта всего мира: рельеф (грубо, с сервера), ваш замок и видимая область.
 * Нажатие переносит обзор в эту точку. Для клавиатуры есть поиск координат в панели карты.
 */
export function MiniMap({
  home,
  view,
  onJump,
  size = 132,
}: {
  home: { x: number; y: number } | null;
  view: MiniView | null;
  onJump: (x: number, y: number) => void;
  size?: number;
}) {
  const { t } = useTranslation();
  const q = useQuery({
    queryKey: ['map', 'overview'],
    queryFn: mapApi.overview,
    staleTime: Infinity,
    retry: false,
  });
  const ref = useRef<HTMLCanvasElement>(null);
  const data = q.data;
  useEffect(() => {
    const cv = ref.current;
    if (!cv || !data) return;
    const ctx = cv.getContext('2d');
    if (!ctx) return; // jsdom и старые браузеры: мини-карта необязательна
    for (let j = 0; j < data.cols; j++)
      for (let i = 0; i < data.cols; i++) {
        ctx.fillStyle = COLOR[data.terrain[j * data.cols + i] ?? 'p'] ?? COLOR['p']!;
        ctx.fillRect(i, j, 1, 1);
      }
  }, [data]);
  if (!data) return null;
  const k = size / MAP_SIZE;
  return (
    <div
      className="glass absolute bottom-3 right-3 z-10 p-1.5"
      role="group"
      aria-label={t('map.minimap')}
    >
      <div
        className="relative cursor-crosshair overflow-hidden rounded-md"
        style={{ width: size, height: size }}
        data-testid="minimap"
        onClick={(e) => {
          const r = e.currentTarget.getBoundingClientRect();
          const x = Math.round(((e.clientX - r.left) / r.width) * MAP_SIZE);
          const y = Math.round(((e.clientY - r.top) / r.height) * MAP_SIZE);
          onJump(Math.min(MAP_SIZE - 1, Math.max(0, x)), Math.min(MAP_SIZE - 1, Math.max(0, y)));
        }}
      >
        <canvas
          ref={ref}
          width={data.cols}
          height={data.cols}
          className="h-full w-full"
          aria-hidden="true"
        />
        {view && (
          <span
            aria-hidden="true"
            className="pointer-events-none absolute border-2 border-white/90 bg-white/15"
            style={{
              left: (view.x - view.span / 2) * k,
              top: (view.y - view.span / 2) * k,
              width: Math.max(6, view.span * k),
              height: Math.max(6, view.span * k),
            }}
          />
        )}
        {home && (
          <span
            aria-hidden="true"
            className="pointer-events-none absolute h-2.5 w-2.5 -translate-x-1/2 -translate-y-1/2 rounded-full border border-black bg-gold"
            style={{ left: home.x * k, top: home.y * k }}
          />
        )}
      </div>
    </div>
  );
}
