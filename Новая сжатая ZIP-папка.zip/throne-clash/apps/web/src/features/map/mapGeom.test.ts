import { describe, expect, it } from 'vitest';
import {
  PAD_TOP,
  TILE_H,
  TILE_W,
  mapDims,
  pickTile,
  tileCenter,
  tilePoly,
  rotateCell,
  tileTop,
  unrotateCell,
  worldDelta,
  type Rot,
} from './mapGeom';

describe('геометрия изометрической карты', () => {
  it('центр клетки попадает в эту же клетку (прямое и обратное преобразование совпадают)', () => {
    for (const size of [5, 15, 24]) {
      for (let cy = 0; cy < size; cy++)
        for (let cx = 0; cx < size; cx++) {
          const [x, y] = tileCenter(cx, cy, size);
          expect(pickTile(x, y, size)).toEqual({ cx, cy });
        }
    }
  });

  it('углы ромба лежат в пределах холста', () => {
    const size = 12;
    const d = mapDims(size);
    for (let cy = 0; cy < size; cy++)
      for (let cx = 0; cx < size; cx++)
        for (const [x, y] of tilePoly(cx, cy, size)) {
          expect(x).toBeGreaterThanOrEqual(0);
          expect(x).toBeLessThanOrEqual(d.width);
          expect(y).toBeGreaterThanOrEqual(PAD_TOP);
          expect(y).toBeLessThanOrEqual(d.height);
        }
  });

  it('клетка (0,0) — верхняя вершина; соседи сдвинуты на полширины и полвысоты', () => {
    const size = 10;
    const [x0, y0] = tileTop(0, 0, size);
    expect(x0).toBe(mapDims(size).offX);
    const [x1, y1] = tileTop(1, 0, size);
    expect([x1 - x0, y1 - y0]).toEqual([TILE_W / 2, TILE_H / 2]);
    const [x2, y2] = tileTop(0, 1, size);
    expect([x2 - x0, y2 - y0]).toEqual([-TILE_W / 2, TILE_H / 2]);
  });

  it('за пределами окна выбрать клетку нельзя', () => {
    expect(pickTile(-50, 300, 10)).toBeNull();
    expect(pickTile(300, 10, 10)).toBeNull();
    expect(pickTile(9999, 9999, 10)).toBeNull();
  });

  it('поворот: четыре четверти возвращают клетку на место, обратный поворот точен', () => {
    const ROTS: Rot[] = [0, 1, 2, 3];
    for (const size of [5, 12]) {
      for (let cy = 0; cy < size; cy++)
        for (let cx = 0; cx < size; cx++) {
          let c: [number, number] = [cx, cy];
          for (let i = 0; i < 4; i++) c = rotateCell(c[0], c[1], size, 1);
          expect(c).toEqual([cx, cy]);
          for (const rot of ROTS) {
            const [rx, ry] = rotateCell(cx, cy, size, rot);
            expect(rx).toBeGreaterThanOrEqual(0);
            expect(rx).toBeLessThan(size);
            expect(unrotateCell(rx, ry, size, rot)).toEqual([cx, cy]);
          }
        }
    }
  });

  it('поворот: центр клетки попадает в ту же клетку при любом повороте', () => {
    for (const rot of [0, 1, 2, 3] as Rot[])
      for (const size of [6, 15])
        for (let cy = 0; cy < size; cy++)
          for (let cx = 0; cx < size; cx++) {
            const [x, y] = tileCenter(cx, cy, size, rot);
            expect(pickTile(x, y, size, rot)).toEqual({ cx, cy });
          }
  });

  it('поворот: углы остаются на холсте, а соседние клетки остаются соседними на экране', () => {
    const size = 9;
    const d = mapDims(size);
    for (const rot of [1, 2, 3] as Rot[]) {
      for (let cy = 0; cy < size; cy++)
        for (let cx = 0; cx < size; cx++)
          for (const [x, y] of tilePoly(cx, cy, size, rot)) {
            expect(x).toBeGreaterThanOrEqual(0);
            expect(x).toBeLessThanOrEqual(d.width);
            expect(y).toBeGreaterThanOrEqual(PAD_TOP);
          }
      const a = tileCenter(3, 4, size, rot);
      const b = tileCenter(4, 4, size, rot);
      expect(Math.hypot(a[0] - b[0], a[1] - b[1])).toBeCloseTo(
        Math.hypot(TILE_W / 2, TILE_H / 2),
        6,
      );
    }
  });

  it('worldDelta: экранный сдвиг переводится в мировой и возвращается четырьмя поворотами', () => {
    expect(worldDelta(1, 0, 0)).toEqual([1, 0]);
    expect(worldDelta(1, 0, 1)).toEqual([0, -1]);
    expect(worldDelta(1, 0, 2)).toEqual([-1, 0]);
    expect(worldDelta(1, 0, 3)).toEqual([0, 1]);
    // проверка согласованности с геометрией: сдвиг вправо по экрану = сдвиг на worldDelta по клеткам
    const size = 10;
    for (const rot of [0, 1, 2, 3] as Rot[]) {
      const [dx, dy] = worldDelta(1, 0, rot);
      const a = tileCenter(4, 4, size, rot);
      const b = tileCenter(4 + dx, 4 + dy, size, rot);
      const r0a = tileCenter(4, 4, size, 0);
      const r0b = tileCenter(5, 4, size, 0);
      expect([b[0] - a[0], b[1] - a[1]]).toEqual([r0b[0] - r0a[0], r0b[1] - r0a[1]]);
    }
  });
});
