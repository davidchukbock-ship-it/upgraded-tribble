import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import type { CastleDto, MapCellDto, ReportDto, ReportPageDto } from '@tc/shared';
import { initI18n } from '../../lib/i18n';
import { useToasts } from '../../store/toast';
import { apiError, installFakeApi, json, makeArmy, makeCastle } from '../../test-utils/fake-api';
import { renderApp, resetAuth, signIn } from '../../test-utils/render';
import { actionsFor } from './MapPage';

beforeAll(async () => {
  await initI18n('ru');
});
beforeEach(() => {
  signIn();
  useToasts.setState({ items: [] });
});
afterEach(() => {
  resetAuth();
  vi.unstubAllGlobals();
});

type Over = Record<string, Partial<MapCellDto>>;
const tiles = (x0: number, y0: number, size: number, over: Over = {}) => ({
  serverTime: new Date().toISOString(),
  x: x0,
  y: y0,
  size,
  cells: Array.from({ length: size * size }, (_, i): MapCellDto => {
    const x = x0 + (i % size);
    const y = y0 + Math.floor(i / size);
    return {
      x,
      y,
      terrain: 'plain',
      kind: 'empty',
      level: 0,
      resource: null,
      castle: null,
      busyUntil: null,
      remaining: null,
      ...over[`${x},${y}`],
    };
  }),
});

const WORLD: Over = {
  '50,50': { castle: { nickname: 'Артур', isMe: true, shielded: false } },
  '53,50': { castle: { nickname: 'Борис', isMe: false, shielded: false } },
  '55,50': { castle: { nickname: 'Щитов', isMe: false, shielded: true } },
  '45,45': { kind: 'camp', level: 3 },
  '46,45': { kind: 'camp', level: 3, busyUntil: '2030-01-01T00:00:00.000Z' },
  '57,57': { kind: 'resource', level: 2, resource: 'wood', remaining: 10_000 },
};
const TILES_URL = 'GET /api/map/tiles?x=30&y=30&size=40';

const withArmy = (over: Partial<CastleDto> = {}) =>
  makeCastle({
    army: makeArmy({
      units: [
        { id: 'cavalry_1', count: 10, wounded: 0 },
        { id: 'infantry_1', count: 20, wounded: 0 },
      ],
      count: 30,
    }),
    ...over,
  });

const march = (over: Partial<CastleDto['marches'][number]> = {}): CastleDto['marches'][number] => ({
  id: '99999999-9999-4999-8999-999999999999',
  type: 'scout',
  target: { x: 53, y: 50 },
  targetName: 'Борис',
  units: { cavalry_1: 5 },
  loot: { gold: 0, wood: 0, stone: 0, food: 0 },
  state: 'outbound',
  startedAt: new Date(Date.now() - 5000).toISOString(),
  arriveAt: new Date(Date.now() + 60_000).toISOString(),
  returnAt: new Date(Date.now() + 120_000).toISOString(),
  reportId: null,
  ...over,
});

/** Курсор — клавиатурой: стрелки по клеткам, Enter открывает клетку. */
async function openCell(dx: number, dy: number) {
  const grid = await screen.findByRole('application');
  await waitFor(() => expect(screen.getByTestId('map-surface')).toBeInTheDocument());
  grid.focus();
  for (let i = 0; i < Math.abs(dx); i++)
    await userEvent.keyboard(dx > 0 ? '{ArrowRight}' : '{ArrowLeft}');
  for (let i = 0; i < Math.abs(dy); i++)
    await userEvent.keyboard(dy > 0 ? '{ArrowDown}' : '{ArrowUp}');
  await userEvent.keyboard('{Enter}');
  return screen.findByRole('dialog');
}

describe('actionsFor', () => {
  const base = tiles(0, 0, 1).cells[0]!;
  it('что можно сделать с клеткой', () => {
    expect(actionsFor(base)).toEqual([]);
    expect(actionsFor({ ...base, castle: { nickname: 'A', isMe: true, shielded: false } })).toEqual(
      [],
    );
    expect(
      actionsFor({ ...base, castle: { nickname: 'A', isMe: false, shielded: false } }),
    ).toEqual(['scout', 'attack']);
    expect(actionsFor({ ...base, kind: 'camp', level: 2 })).toEqual(['monster']);
    expect(actionsFor({ ...base, kind: 'camp', level: 2, busyUntil: 'x' })).toEqual([]);
    expect(actionsFor({ ...base, kind: 'resource', level: 1, resource: 'gold' })).toEqual([
      'gather',
    ]);
  });
});

describe('экран карты', () => {
  it('показывает участок вокруг замка, легенду и подсказку клавиатуры', async () => {
    installFakeApi({ [TILES_URL]: () => json(200, tiles(30, 30, 40, WORLD)) });
    renderApp('/map');
    expect(
      await screen.findByRole('application', { name: /Стрелки — по клеткам/ }),
    ).toBeInTheDocument();
    expect(await screen.findByText('30–69, 30–69')).toBeInTheDocument();
    expect(await screen.findByText(/50, 50: Замок: Артур/)).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: 'Найти' }));
    expect(screen.getByText('Обозначения')).toBeInTheDocument();
  });

  it('стрелки двигают курсор, подпись читает клетку под ним', async () => {
    installFakeApi({ [TILES_URL]: () => json(200, tiles(30, 30, 40, WORLD)) });
    renderApp('/map');
    const grid = await screen.findByRole('application');
    await screen.findByTestId('map-surface');
    grid.focus();
    for (let i = 0; i < 3; i++) await userEvent.keyboard('{ArrowRight}');
    expect(await screen.findByText(/53, 50: Замок: Борис/)).toBeInTheDocument();
  });

  it('поворот карты: кнопки и клавиши Q/E; стрелки остаются «экранными», выбор запоминается', async () => {
    localStorage.removeItem('tc.mapRot');
    installFakeApi({ [TILES_URL]: () => json(200, tiles(30, 30, 40, WORLD)) });
    renderApp('/map');
    const grid = await screen.findByRole('application');
    await screen.findByTestId('map-surface');
    await userEvent.click(screen.getByRole('button', { name: 'Повернуть вправо (E)' }));
    expect(localStorage.getItem('tc.mapRot')).toBe('1');
    grid.focus();
    await userEvent.keyboard('q');
    expect(localStorage.getItem('tc.mapRot')).toBe('0');
    // четыре поворота подряд возвращают исходный вид
    for (let i = 0; i < 4; i++) await userEvent.keyboard('e');
    expect(localStorage.getItem('tc.mapRot')).toBe('0');
    // при повороте на 90° экранное «вправо» — это сдвиг по мировой оси y
    await userEvent.keyboard('e');
    await userEvent.keyboard('{ArrowRight}');
    expect(await screen.findByText(/50, 49:/)).toBeInTheDocument();
    localStorage.removeItem('tc.mapRot');
  });

  it('разведка: только конница, отправка шлёт POST с ключом и показывает поход в списке', async () => {
    const { calls } = installFakeApi({
      'GET /api/castle': () => json(200, withArmy()),
      [TILES_URL]: () => json(200, tiles(30, 30, 40, WORLD)),
      'POST /api/marches': () => json(200, withArmy({ marches: [march()] })),
    });
    renderApp('/map');
    const dlg = await openCell(3, 0);
    expect(within(dlg).getByText('Замок: Борис')).toBeInTheDocument();
    await userEvent.click(within(dlg).getByRole('radio', { name: 'Разведка' }));
    // пехота недоступна для разведки
    expect(within(dlg).getByLabelText(/Пехота T1/)).toBeDisabled();
    const cav = within(dlg).getByLabelText(/Кавалерия T1/);
    await userEvent.type(cav, '5');
    expect(within(dlg).getByText(/В пути/)).toBeInTheDocument();
    await userEvent.click(dlg.querySelector('button[type="submit"]')!);

    await waitFor(() => expect(calls.filter((c) => c.method === 'POST')).toHaveLength(1));
    const post = calls.find((c) => c.method === 'POST')!;
    expect(post.body).toEqual({ type: 'scout', target: { x: 53, y: 50 }, units: { cavalry_1: 5 } });
    expect(post.headers['Idempotency-Key']).toMatch(/^[0-9a-f-]{36}$/);
    await waitFor(() => expect(screen.queryByRole('dialog')).toBeNull());
    await userEvent.click(screen.getByRole('button', { name: /^Походы/ }));
    const list = await screen.findByRole('region', { name: 'Походы' });
    expect(await within(list).findByText(/Разведка → Борис/)).toBeInTheDocument();
    expect(within(list).getByRole('progressbar')).toBeInTheDocument();
    expect(useToasts.getState().items[0]?.message).toContain('Отряд отправлен');
  });

  it('нападение на игрока под щитом заблокировано с объяснением', async () => {
    installFakeApi({
      'GET /api/castle': () => json(200, withArmy()),
      [TILES_URL]: () => json(200, tiles(30, 30, 40, WORLD)),
    });
    renderApp('/map');
    const dlg = await openCell(5, 0);
    expect(within(dlg).getByText('под щитом')).toBeInTheDocument();
    await userEvent.click(within(dlg).getByRole('radio', { name: 'Напасть' }));
    await userEvent.type(within(dlg).getByLabelText(/Пехота T1/), '3');
    expect(within(dlg).getByText('Игрок под щитом: нападать нельзя')).toBeInTheDocument();
    const submit = dlg.querySelector('button[type="submit"]')!;
    expect(submit).toBeDisabled();
  });

  it('кнопка «Все» подставляет весь запас; без войск отправить нельзя', async () => {
    installFakeApi({
      'GET /api/castle': () => json(200, withArmy()),
      [TILES_URL]: () => json(200, tiles(30, 30, 40, WORLD)),
    });
    renderApp('/map');
    const dlg = await openCell(3, 0);
    expect(within(dlg).getByText('Выберите войска')).toBeInTheDocument();
    await userEvent.click(within(dlg).getByRole('radio', { name: 'Напасть' }));
    await userEvent.click(within(dlg).getByRole('button', { name: /Все: Пехота/ }));
    expect(within(dlg).getByLabelText(/Пехота T1/)).toHaveValue('20');
    expect(dlg.querySelector('button[type="submit"]')).toBeEnabled();
  });

  it('лагерь: можно напасть; повержённый лагерь — без действий; ресурсная точка — сбор с грузом', async () => {
    installFakeApi({
      'GET /api/castle': () => json(200, withArmy()),
      [TILES_URL]: () => json(200, tiles(30, 30, 40, WORLD)),
    });
    renderApp('/map');
    let dlg = await openCell(-5, -5);
    expect(within(dlg).getByText('Лагерь монстров, ур. 3')).toBeInTheDocument();
    expect(dlg.querySelector('button[type="submit"]')).toHaveTextContent('Напасть на лагерь');
    await userEvent.keyboard('{Escape}');
    await waitFor(() => expect(screen.queryByRole('dialog')).toBeNull());

    (await screen.findByRole('application')).focus();
    await userEvent.keyboard('{ArrowRight}{Enter}');
    dlg = await screen.findByRole('dialog');
    expect(within(dlg).getByText('Возродится через')).toBeInTheDocument();
    expect(dlg.querySelector('button[type="submit"]')).toBeNull();
    await userEvent.keyboard('{Escape}');
    await waitFor(() => expect(screen.queryByRole('dialog')).toBeNull());
  });

  it('сбор: показывает запас точки и груз выбранного отряда', async () => {
    installFakeApi({
      'GET /api/castle': () => json(200, withArmy()),
      [TILES_URL]: () => json(200, tiles(30, 30, 40, WORLD)),
    });
    renderApp('/map');
    const dlg = await openCell(7, 7);
    expect(within(dlg).getByText(/Дерево: точка, ур. 2/)).toBeInTheDocument();
    expect(within(dlg).getByText('10 000')).toBeInTheDocument();
    await userEvent.type(within(dlg).getByLabelText(/Кавалерия T1/), '5');
    expect(within(dlg).getByText(/Груз/)).toBeInTheDocument();
    expect(dlg.querySelector('button[type="submit"]')).toHaveTextContent('Собрать');
  });

  it('ошибка сервера показывается сообщением', async () => {
    installFakeApi({
      'GET /api/castle': () => json(200, withArmy()),
      [TILES_URL]: () => json(200, tiles(30, 30, 40, WORLD)),
      'POST /api/marches': () => apiError(422, 'ERR_SHIELD_ACTIVE'),
    });
    renderApp('/map');
    const dlg = await openCell(3, 0);
    await userEvent.type(within(dlg).getByLabelText(/Кавалерия T1/), '2');
    await userEvent.click(within(dlg).getByRole('radio', { name: 'Напасть' }));
    await userEvent.type(within(dlg).getByLabelText(/Кавалерия T1/), '2');
    await userEvent.click(dlg.querySelector('button[type="submit"]')!);
    await waitFor(() =>
      expect(useToasts.getState().items.map((i) => i.message)).toContain(
        'Игрок под щитом: нападать нельзя',
      ),
    );
  });

  it('переход по координатам и поиск по нику', async () => {
    const q = encodeURIComponent('бор');
    const { calls } = installFakeApi({
      [TILES_URL]: () => json(200, tiles(30, 30, 40, WORLD)),
      'GET /api/map/tiles?x=0&y=0&size=40': () => json(200, tiles(0, 0, 40)),
      'GET /api/map/tiles?x=33&y=30&size=40': () => json(200, tiles(33, 30, 40, WORLD)),
      [`GET /api/map/search?q=${q}`]: () => json(200, [{ x: 53, y: 50, nickname: 'Борис' }]),
    });
    renderApp('/map');
    await screen.findByText('30–69, 30–69');
    await userEvent.click(screen.getByRole('button', { name: 'Найти' }));
    await userEvent.type(screen.getByLabelText('x'), '5');
    await userEvent.type(screen.getByLabelText('y'), '5');
    await userEvent.click(screen.getByRole('button', { name: 'Перейти' }));
    expect(await screen.findByText('0–39, 0–39')).toBeInTheDocument();

    await userEvent.type(screen.getByLabelText('Ник или «x,y»'), 'бор');
    const results = await screen.findByRole('list', { name: 'Результаты поиска' });
    await userEvent.click(within(results).getByRole('button', { name: /Борис — 53, 50/ }));
    expect(await screen.findByText('33–72, 30–69')).toBeInTheDocument();
    expect(calls.some((c) => c.path.startsWith('/api/map/search'))).toBe(true);
  });

  it('«К моему замку» возвращает к своей клетке; масштаб переключается 40 ↔ 24', async () => {
    installFakeApi({
      [TILES_URL]: () => json(200, tiles(30, 30, 40, WORLD)),
      'GET /api/map/tiles?x=38&y=38&size=24': () => json(200, tiles(38, 38, 24, WORLD)),
    });
    renderApp('/map');
    await screen.findByText('30–69, 30–69');
    await userEvent.click(screen.getByRole('button', { name: 'Крупнее' }));
    expect(await screen.findByText('38–61, 38–61')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Мельче' })).toBeInTheDocument();
  });

  it('пустой список походов и полный список', async () => {
    installFakeApi({ [TILES_URL]: () => json(200, tiles(30, 30, 40, WORLD)) });
    renderApp('/map');
    await userEvent.click(await screen.findByRole('button', { name: /^Походы/ }));
    expect(
      await screen.findByText('Отряды никуда не идут. Выберите клетку на карте.'),
    ).toBeInTheDocument();
    expect(screen.getByText('Отрядов в пути: 0 из 5')).toBeInTheDocument();
  });
});

const report = (over: Partial<ReportDto> = {}): ReportDto => ({
  id: '11111111-1111-4111-8111-111111111111',
  kind: 'battle',
  role: 'attacker',
  outcome: 'win',
  createdAt: '2026-01-01T10:00:00.000Z',
  target: { x: 53, y: 50 },
  opponent: 'Борис',
  read: false,
  detail: {
    rounds: [
      { round: 1, attackerLosses: 3, defenderLosses: 40, attackerAlive: 197, defenderAlive: 0 },
    ],
    attacker: {
      start: { infantry_3: 200 },
      remaining: { infantry_3: 197 },
      fallen: { infantry_3: 3 },
    },
    defender: { start: { infantry_1: 40 }, remaining: {}, fallen: { infantry_1: 40 } },
    loot: { gold: 500, wood: 400, stone: 0, food: 300 },
    heroXp: 24,
    wounded: { infantry_3: 1 },
    dead: { infantry_3: 2 },
    scout: null,
    gathered: null,
    campLevel: null,
  },
  ...over,
});

describe('отчёты', () => {
  it('пустой список объясняет, откуда взять отчёты', async () => {
    const page: ReportPageDto = { items: [], page: 1, pageSize: 20, total: 0, unread: 0 };
    installFakeApi({ 'GET /api/reports?page=1&pageSize=20': () => json(200, page) });
    renderApp('/reports');
    expect(
      await screen.findByText('Отчётов пока нет. Отправьте отряд с карты.'),
    ).toBeInTheDocument();
  });

  it('список: заголовок по исходу, новые помечены, есть ссылка на отчёт; страницы', async () => {
    const { detail: _detail, ...one } = report();
    void _detail;
    const p1: ReportPageDto = {
      items: [
        one,
        {
          ...one,
          id: '22222222-2222-4222-8222-222222222222',
          role: 'defender',
          outcome: 'loss',
          read: true,
          opponent: 'Борис',
        },
      ],
      page: 1,
      pageSize: 20,
      total: 45,
      unread: 1,
    };
    const { calls } = installFakeApi({
      'GET /api/reports?page=1&pageSize=20': () => json(200, p1),
      'GET /api/reports?page=2&pageSize=20': () => json(200, { ...p1, page: 2, items: [] }),
    });
    renderApp('/reports');
    expect(await screen.findByText('Победа в нападении')).toBeInTheDocument();
    expect(screen.getByText('Замок разорён')).toBeInTheDocument();
    expect(screen.getByText('Всего: 45, новых: 1')).toBeInTheDocument();
    expect(screen.getAllByText('Новый')).toHaveLength(1);
    expect(screen.getAllByRole('link', { name: /\(53, 50\)/ })).toHaveLength(2);
    expect(screen.getByRole('button', { name: 'Назад' })).toBeDisabled();
    await userEvent.click(screen.getByRole('button', { name: 'Дальше' }));
    await waitFor(() => expect(calls.some((c) => c.path.includes('page=2'))).toBe(true));
    expect(await screen.findByText('2 / 3')).toBeInTheDocument();
  });

  it('подробности боя: войска, раунды, добыча, потери', async () => {
    const r = report();
    installFakeApi({ [`GET /api/reports/${r.id}`]: () => json(200, r) });
    renderApp(`/reports/${r.id}`);
    expect(await screen.findByRole('heading', { name: 'Победа в нападении' })).toBeInTheDocument();
    expect(screen.getByRole('region', { name: 'Ваши войска' })).toHaveTextContent('Пехота T3');
    expect(screen.getByRole('region', { name: 'Защитники' })).toHaveTextContent('Пехота T1');
    expect(screen.getByText('Золото:').parentElement).toHaveTextContent('500');
    expect(screen.getByText('Опыт героя:').parentElement).toHaveTextContent('24');
    expect(screen.getByText('Погибли').parentElement).toHaveTextContent('Пехота T3: 2');
    expect(screen.getByText('Ранены').parentElement).toHaveTextContent('Пехота T3: 1');
  });

  it('разведка и сбор показывают свои данные', async () => {
    const scout = report({
      id: '33333333-3333-4333-8333-333333333333',
      kind: 'scout',
      outcome: 'done',
      detail: {
        ...report().detail,
        attacker: null,
        defender: null,
        rounds: [],
        loot: { gold: 0, wood: 0, stone: 0, food: 0 },
        heroXp: 0,
        scout: {
          units: { infantry_1: 198 },
          resources: { gold: 2000, wood: 1500, stone: 900, food: 700 },
        },
      },
    });
    installFakeApi({ [`GET /api/reports/${scout.id}`]: () => json(200, scout) });
    renderApp(`/reports/${scout.id}`);
    expect(
      await screen.findByText('Численность приблизительная, погрешность до 10%.'),
    ).toBeInTheDocument();
    expect(screen.getByText(/Пехота T1:/)).toHaveTextContent('198');
    expect(screen.getByText('Золото:').parentElement).toHaveTextContent('2 000');
  });

  it('сбор ресурсов', async () => {
    const g = report({
      id: '44444444-4444-4444-8444-444444444444',
      kind: 'gather',
      outcome: 'done',
      detail: {
        ...report().detail,
        attacker: null,
        defender: null,
        rounds: [],
        loot: { gold: 0, wood: 0, stone: 0, food: 0 },
        heroXp: 0,
        gathered: { resource: 'wood', amount: 4000 },
      },
    });
    installFakeApi({ [`GET /api/reports/${g.id}`]: () => json(200, g) });
    renderApp(`/reports/${g.id}`);
    expect(await screen.findByRole('heading', { name: 'Сбор ресурсов' })).toBeInTheDocument();
    expect(screen.getByText('Дерево:').parentElement).toHaveTextContent('4 000');
  });

  it('чужой или несуществующий отчёт — понятное сообщение и ссылка назад', async () => {
    installFakeApi({
      '/api/reports/55555555-5555-4555-8555-555555555555': () => json(404, {}),
    } as never);
    installFakeApi({
      'GET /api/reports/55555555-5555-4555-8555-555555555555': () => apiError(404, 'ERR_NOT_FOUND'),
    });
    renderApp('/reports/55555555-5555-4555-8555-555555555555');
    expect(await screen.findByText('Отчёт не найден')).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'К списку отчётов' })).toHaveAttribute(
      'href',
      '/reports',
    );
  });
});
