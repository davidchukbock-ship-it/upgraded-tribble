import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Link, useParams } from 'react-router-dom';
import {
  RESOURCE_KEYS,
  parseUnitId,
  type ReportDto,
  type ReportSummaryDto,
  type UnitCounts,
} from '@tc/shared';
import { formatFull } from '../../lib/format';
import { Badge, Button, Panel } from '../../ui';
import { reportApi } from './api';
import { BattleScene } from './BattleScene';
import { dateLocale } from '../../lib/locales';

const when = (iso: string, lang: string): string =>
  new Date(iso).toLocaleString(dateLocale(lang), {
    day: '2-digit',
    month: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });

function useUnitLabel() {
  const { t } = useTranslation();
  return (id: string): string => {
    const p = parseUnitId(id);
    return p ? `${t(`unit.${p.type}`)} T${p.tier}` : id;
  };
}

function UnitList({ units, empty }: { units: UnitCounts; empty: string }) {
  const label = useUnitLabel();
  const rows = Object.entries(units).filter(([, n]) => (n ?? 0) > 0);
  if (rows.length === 0) return <span className="opacity-80">{empty}</span>;
  return (
    <ul className="text-sm">
      {rows.map(([id, n]) => (
        <li key={id}>
          {label(id)}: <b>{formatFull(n ?? 0)}</b>
        </li>
      ))}
    </ul>
  );
}

export function reportTitleKey(r: Pick<ReportSummaryDto, 'kind' | 'role' | 'outcome'>): string {
  if (r.kind === 'battle') return `report.title.battle.${r.role}.${r.outcome}`;
  if (r.kind === 'monster') return `report.title.monster.${r.outcome}`;
  return `report.title.${r.kind}`;
}

function ReportList() {
  const { t, i18n } = useTranslation();
  const [page, setPage] = useState(1);
  const q = useQuery({ queryKey: ['reports', page], queryFn: () => reportApi.list(page) });

  if (q.isPending)
    return (
      <p role="status" className="pt-8 text-center font-display text-lg">
        {t('common.loading')}
      </p>
    );
  if (q.isError || !q.data)
    return (
      <Panel title={t('nav.reports')} className="mx-auto max-w-md text-center">
        <p className="pt-2">{t('errors.ERR_NETWORK')}</p>
        <Button className="mt-3" onClick={() => void q.refetch()}>
          {t('common.retry')}
        </Button>
      </Panel>
    );
  const { items, total, unread, pageSize } = q.data;
  const pages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-4">
      <h1 className="font-display text-2xl font-bold text-gold-light">{t('nav.reports')}</h1>
      <p className="text-sm" role="status">
        {t('report.summary', { total, unread })}
      </p>
      {items.length === 0 ? (
        <Panel title={t('nav.reports')}>
          <p className="pt-2">{t('report.empty')}</p>
        </Panel>
      ) : (
        <ul className="flex flex-col gap-2">
          {items.map((r) => (
            <li key={r.id}>
              <Link
                to={`/reports/${r.id}`}
                className="panel-wood frame-pixel flex flex-wrap items-center gap-x-3 gap-y-1 px-4 py-3 hover:brightness-110"
              >
                <span className="font-display text-base font-bold">{t(reportTitleKey(r))}</span>
                <span className="text-sm opacity-90">
                  ({r.target.x}, {r.target.y}){r.opponent ? ` · ${r.opponent}` : ''}
                </span>
                {!r.read && <Badge tone="red">{t('report.new')}</Badge>}
                <span className="ml-auto text-sm opacity-80">
                  {when(r.createdAt, i18n.language)}
                </span>
              </Link>
            </li>
          ))}
        </ul>
      )}
      {pages > 1 && (
        <nav aria-label={t('report.pages')} className="flex items-center justify-center gap-3">
          <Button disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
            {t('report.prev')}
          </Button>
          <span className="text-sm">
            {page} / {pages}
          </span>
          <Button disabled={page >= pages} onClick={() => setPage((p) => p + 1)}>
            {t('report.next')}
          </Button>
        </nav>
      )}
    </div>
  );
}

function Side({
  title,
  start,
  remaining,
  fallen,
}: {
  title: string;
  start: UnitCounts;
  remaining: UnitCounts;
  fallen: UnitCounts;
}) {
  const { t } = useTranslation();
  const label = useUnitLabel();
  const ids = Object.keys(start);
  return (
    <section className="rounded-lg bg-black/25 p-3" aria-label={title}>
      <h3 className="font-display text-sm font-bold text-gold-light">{title}</h3>
      {ids.length === 0 ? (
        <p className="text-sm opacity-80">{t('report.noUnits')}</p>
      ) : (
        <table className="mt-1 w-full text-left text-sm">
          <thead>
            <tr className="opacity-80">
              <th scope="col" className="font-normal">
                {t('report.unit')}
              </th>
              <th scope="col" className="text-right font-normal">
                {t('report.was')}
              </th>
              <th scope="col" className="text-right font-normal">
                {t('report.left')}
              </th>
              <th scope="col" className="text-right font-normal">
                {t('report.lost')}
              </th>
            </tr>
          </thead>
          <tbody>
            {ids.map((id) => (
              <tr key={id}>
                <th scope="row" className="font-semibold">
                  {label(id)}
                </th>
                <td className="text-right">{formatFull(start[id as keyof UnitCounts] ?? 0)}</td>
                <td className="text-right">{formatFull(remaining[id as keyof UnitCounts] ?? 0)}</td>
                <td className="text-right">{formatFull(fallen[id as keyof UnitCounts] ?? 0)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </section>
  );
}

function ReportBody({ r }: { r: ReportDto }) {
  const { t } = useTranslation();
  const d = r.detail;
  const gotLoot = RESOURCE_KEYS.some((k) => d.loot[k] > 0);
  const iAttack = r.role === 'attacker';
  return (
    <div className="flex flex-col gap-4">
      {(r.kind === 'battle' || r.kind === 'monster') && d.attacker && (
        <BattleScene
          attacker={d.attacker.start}
          defender={d.defender?.start ?? null}
          campLevel={r.kind === 'monster' ? d.campLevel : null}
          attackerWon={r.role === 'attacker' ? r.outcome === 'win' : r.outcome !== 'win'}
        />
      )}
      {(d.attacker || d.defender) && (
        <div className="grid gap-3 md:grid-cols-2">
          {d.attacker && (
            <Side title={iAttack ? t('report.yourSide') : t('report.attackers')} {...d.attacker} />
          )}
          {d.defender && (
            <Side
              title={
                r.kind === 'monster'
                  ? t('report.monsters', { level: d.campLevel ?? 0 })
                  : iAttack
                    ? t('report.defenders')
                    : t('report.yourSide')
              }
              {...d.defender}
            />
          )}
        </div>
      )}

      {d.rounds.length > 0 && (
        <Panel title={t('report.rounds')}>
          <table className="mt-2 w-full text-left text-sm">
            <thead>
              <tr className="opacity-80">
                <th scope="col" className="font-normal">
                  #
                </th>
                <th scope="col" className="text-right font-normal">
                  {t('report.attackersLost')}
                </th>
                <th scope="col" className="text-right font-normal">
                  {t('report.defendersLost')}
                </th>
              </tr>
            </thead>
            <tbody>
              {d.rounds.map((x) => (
                <tr key={x.round}>
                  <th scope="row">{x.round}</th>
                  <td className="text-right">{formatFull(x.attackerLosses)}</td>
                  <td className="text-right">{formatFull(x.defenderLosses)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Panel>
      )}

      {(gotLoot || d.heroXp > 0) && (
        <Panel title={t('report.loot')}>
          <ul className="flex flex-wrap gap-x-4 gap-y-1 pt-2 text-sm">
            {RESOURCE_KEYS.filter((k) => d.loot[k] > 0).map((k) => (
              <li key={k}>
                {t(`resource.${k}`)}: <b>{formatFull(d.loot[k])}</b>
              </li>
            ))}
            {d.heroXp > 0 && (
              <li>
                {t('report.heroXp')}: <b>{formatFull(d.heroXp)}</b>
              </li>
            )}
          </ul>
        </Panel>
      )}

      {r.kind === 'battle' || r.kind === 'monster' ? (
        <Panel title={t('report.yourLosses')}>
          <div className="grid gap-3 pt-2 sm:grid-cols-2">
            <div>
              <h3 className="font-display text-sm font-bold">{t('report.dead')}</h3>
              <UnitList units={d.dead} empty={t('report.none')} />
            </div>
            <div>
              <h3 className="font-display text-sm font-bold">{t('report.wounded')}</h3>
              <UnitList units={d.wounded} empty={t('report.none')} />
            </div>
          </div>
        </Panel>
      ) : null}

      {d.scout && (
        <Panel title={t('report.scouted')}>
          <p className="pt-2 text-sm opacity-90">{t('report.scoutNote')}</p>
          <div className="grid gap-3 pt-2 sm:grid-cols-2">
            <div>
              <h3 className="font-display text-sm font-bold">{t('report.defenders')}</h3>
              <UnitList units={d.scout.units} empty={t('report.none')} />
            </div>
            <div>
              <h3 className="font-display text-sm font-bold">{t('report.stock')}</h3>
              <ul className="text-sm">
                {RESOURCE_KEYS.map((k) => (
                  <li key={k}>
                    {t(`resource.${k}`)}: <b>{formatFull(d.scout!.resources[k])}</b>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </Panel>
      )}

      {d.gathered && (
        <Panel title={t('report.gathered')}>
          <p className="pt-2 text-sm">
            {t(`resource.${d.gathered.resource}`)}: <b>{formatFull(d.gathered.amount)}</b>
          </p>
        </Panel>
      )}
    </div>
  );
}

function ReportDetail({ id }: { id: string }) {
  const { t, i18n } = useTranslation();
  const client = useQueryClient();
  const q = useQuery({ queryKey: ['report', id], queryFn: () => reportApi.get(id), retry: false });
  useEffect(() => {
    // Открытый отчёт считается прочитанным — обновляем счётчики в списке
    if (q.data) void client.invalidateQueries({ queryKey: ['reports'] });
  }, [q.data, client]);

  if (q.isPending)
    return (
      <p role="status" className="pt-8 text-center font-display text-lg">
        {t('common.loading')}
      </p>
    );
  if (q.isError || !q.data)
    return (
      <Panel title={t('nav.reports')} className="mx-auto max-w-md text-center">
        <p className="pt-2">{t('report.notFound')}</p>
        <Link className="mt-3 inline-block underline" to="/reports">
          {t('report.back')}
        </Link>
      </Panel>
    );
  const r = q.data;
  return (
    <div className="mx-auto flex max-w-4xl flex-col gap-4">
      <Link className="text-sm underline" to="/reports">
        ← {t('report.back')}
      </Link>
      <h1 className="font-display text-2xl font-bold text-gold-light">{t(reportTitleKey(r))}</h1>
      <p className="text-sm opacity-90">
        ({r.target.x}, {r.target.y}){r.opponent ? ` · ${r.opponent}` : ''} ·{' '}
        {when(r.createdAt, i18n.language)}
      </p>
      <ReportBody r={r} />
    </div>
  );
}

export function ReportsPage() {
  const { id } = useParams();
  return id ? <ReportDetail id={id} /> : <ReportList />;
}
