import { hashSeed, RESOURCE_KEYS, type MapCellDto, type ResourceKey } from '@tc/shared';

/**
 * Как выглядит клетка карты. Вид клетки — чистая функция от её данных, чтобы карта не «мерцала»
 * при обновлении и это можно было проверить тестом.
 */

const roll = (x: number, y: number, salt: string): number =>
  (hashSeed(`${x}:${y}:${salt}`) % 1000) / 1000;

export type Ground = 'grass' | 'forest' | 'hills' | 'water' | 'sand' | 'swamp' | 'sea' | 'river';

/** Земля, по которой нельзя пройти пешком, но можно плыть (берег рисуется пеной). */
export const isOpenWater = (g: Ground): boolean => g === 'water' || g === 'sea';

/** Земля под клеткой и оттенок 0…1 (лёгкая пестрота травы). */
export function groundOf(c: Pick<MapCellDto, 'x' | 'y' | 'terrain'>): {
  ground: Ground;
  shade: number;
} {
  const shade = roll(c.x, c.y, 'shade');
  if (c.terrain === 'water' || c.terrain === 'lake') return { ground: 'water', shade };
  if (c.terrain === 'sea') return { ground: 'sea', shade };
  if (c.terrain === 'river') return { ground: 'river', shade };
  if (c.terrain === 'desert') return { ground: 'sand', shade };
  if (c.terrain === 'swamp') return { ground: 'swamp', shade };
  if (c.terrain === 'mountain') return { ground: 'hills', shade };
  if (c.terrain === 'forest') return { ground: 'forest', shade };
  return { ground: 'grass', shade };
}

export type Decor = 'oak' | 'pine' | 'bush' | 'flowers' | 'peak' | 'cactus' | 'reed';

/** Украшение поверх земли: деревья в лесу, пики в горах, кусты и цветы на равнине. */
export function decorOf(
  c: Pick<MapCellDto, 'x' | 'y' | 'terrain' | 'kind'> & { road?: boolean | undefined },
): Decor | null {
  if (c.kind !== 'empty' || c.road) return null;
  const r = roll(c.x, c.y, 'decor');
  if (c.terrain === 'forest') return r < 0.6 ? 'oak' : 'pine';
  if (c.terrain === 'mountain') return 'peak';
  if (c.terrain === 'plain') return r > 0.97 ? 'bush' : r > 0.9 ? 'flowers' : null;
  if (c.terrain === 'desert') return r > 0.93 ? 'cactus' : null;
  if (c.terrain === 'swamp') return r > 0.78 ? 'reed' : null;
  return null;
}

/** Кто стоит на клетке. Лагерь: 0 — разбойники, 1 — налётчики, 2 — орда с полководцем. */
export type Marker =
  | { type: 'castle'; mine: boolean; shielded: boolean; dim: false }
  | { type: 'camp'; tier: 0 | 1 | 2; variant: 0 | 1; level: number; dim: boolean }
  | { type: 'node'; resource: ResourceKey; level: number; dim: boolean };

export function markerOf(c: MapCellDto): Marker | null {
  if (c.castle)
    return { type: 'castle', mine: c.castle.isMe, shielded: c.castle.shielded, dim: false };
  if (c.kind === 'camp') {
    const tier = c.level <= 4 ? 0 : c.level <= 8 ? 1 : 2;
    return {
      type: 'camp',
      tier,
      variant: roll(c.x, c.y, 'camp') < 0.5 ? 0 : 1,
      level: c.level,
      dim: c.busyUntil !== null,
    };
  }
  if (
    c.kind === 'resource' &&
    c.resource &&
    (RESOURCE_KEYS as readonly string[]).includes(c.resource)
  ) {
    return { type: 'node', resource: c.resource, level: c.level, dim: c.remaining === 0 };
  }
  return null;
}
