/** Геометрия изометрической карты: окно size×size клеток рисуется ромбом 64×32 на клетку. */
export const TILE_W = 64;
export const TILE_H = 32;
/** Запас сверху под высокие деревья, горы и замки. */
export const PAD_TOP = 120;
/** Земляной борт под нижними краями окна. */
export const SOIL = 26;

export interface Dims {
  width: number;
  height: number;
  /** Сдвиг по x: экранная координата вершины ромба клетки (0, 0). */
  offX: number;
}

export function mapDims(size: number): Dims {
  return {
    width: size * TILE_W,
    height: size * TILE_H + PAD_TOP + SOIL + 8,
    offX: (size * TILE_W) / 2,
  };
}

/** Поворот обзора: сколько четвертей оборота по часовой стрелке (0…3). */
export type Rot = 0 | 1 | 2 | 3;

/** Клетка окна → её место в повёрнутой сетке. Окно size × size поворачивается вокруг центра. */
export function rotateCell(cx: number, cy: number, size: number, rot: Rot): [number, number] {
  const n = size - 1;
  switch (rot) {
    case 1:
      return [n - cy, cx];
    case 2:
      return [n - cx, n - cy];
    case 3:
      return [cy, n - cx];
    default:
      return [cx, cy];
  }
}

/** Обратный поворот: место в повёрнутой сетке → клетка окна. */
export function unrotateCell(rx: number, ry: number, size: number, rot: Rot): [number, number] {
  const n = size - 1;
  switch (rot) {
    case 1:
      return [ry, n - rx];
    case 2:
      return [n - rx, n - ry];
    case 3:
      return [n - ry, rx];
    default:
      return [rx, ry];
  }
}

/** Мировой сдвиг, которому на экране соответствует сдвиг (vx, vy) в неповёрнутом виде. */
export function worldDelta(vx: number, vy: number, rot: Rot): [number, number] {
  switch (rot) {
    case 1:
      return [vy || 0, -vx || 0];
    case 2:
      return [-vx || 0, -vy || 0];
    case 3:
      return [-vy || 0, vx || 0];
    default:
      return [vx, vy];
  }
}

/** Верхняя вершина ромба клетки (cx, cy) внутри окна при повороте rot. */
export function tileTop(cx: number, cy: number, size: number, rot: Rot = 0): [number, number] {
  const { offX } = mapDims(size);
  const [rx, ry] = rot === 0 ? [cx, cy] : rotateCell(cx, cy, size, rot);
  return [offX + (rx - ry) * (TILE_W / 2), PAD_TOP + (rx + ry) * (TILE_H / 2)];
}

/** Центр ромба клетки. */
export function tileCenter(cx: number, cy: number, size: number, rot: Rot = 0): [number, number] {
  const [x, y] = tileTop(cx, cy, size, rot);
  return [x, y + TILE_H / 2];
}

/** Углы ромба: верх, право, низ, лево. */
export function tilePoly(
  cx: number,
  cy: number,
  size: number,
  rot: Rot = 0,
): Array<[number, number]> {
  const [x, y] = tileTop(cx, cy, size, rot);
  return [
    [x, y],
    [x + TILE_W / 2, y + TILE_H / 2],
    [x, y + TILE_H],
    [x - TILE_W / 2, y + TILE_H / 2],
  ];
}

/** Клетка под точкой холста без ограничения окном (может быть отрицательной или больше размера). */
export function tileAt(
  px: number,
  py: number,
  size: number,
  rot: Rot = 0,
): { cx: number; cy: number } {
  const { offX } = mapDims(size);
  const a = (px - offX) / (TILE_W / 2);
  const b = (py - PAD_TOP) / (TILE_H / 2);
  const rx = Math.floor((a + b) / 2);
  const ry = Math.floor((b - a) / 2);
  if (rot === 0) return { cx: rx, cy: ry };
  const [cx, cy] = unrotateCell(rx, ry, size, rot);
  return { cx, cy };
}

/** Клетка под точкой (px, py) в координатах холста; null — вне окна. */
export function pickTile(
  px: number,
  py: number,
  size: number,
  rot: Rot = 0,
): { cx: number; cy: number } | null {
  const { cx, cy } = tileAt(px, py, size, rot);
  if (cx < 0 || cy < 0 || cx >= size || cy >= size) return null;
  return { cx, cy };
}
