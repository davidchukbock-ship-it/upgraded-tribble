import { renderToStaticMarkup } from 'react-dom/server';
import { useEffect, useRef, useState } from 'react';
import { MAP_SIZE, type MapCellDto, type ResourceKey } from '@tc/shared';
import { NpcArt, OUTLINE, type NpcName } from '../../art';
import { IsoBuilding } from '../../iso/buildings';
import { IsoDefs } from '../../iso/props';
import { fortSprite, treeSprite } from '../../art2/sprites';
import {
  PAD_TOP,
  SOIL,
  TILE_H,
  TILE_W,
  mapDims,
  rotateCell,
  tileCenter,
  tilePoly,
  type Rot,
} from './mapGeom';
import { decorOf, groundOf, isOpenWater, markerOf, type Decor, type Marker } from './terrain';

type Ctx = CanvasRenderingContext2D;
type Pt = readonly [number, number];

const GROUND = {
  grass: ['#7cc05c', '#72b656'],
  forest: ['#4e9a45', '#468f3f'],
  hills: ['#a39d8d', '#988f80'],
  water: ['#4a93d0', '#4088c8'],
  sand: ['#e4cf8f', '#dcc584'],
  swamp: ['#5f8a4f', '#567f48'],
  sea: ['#2f74b8', '#2a6aac'],
  river: ['#5aa6dc', '#519dd6'],
} as const;

/** Враги на карте по ступени лагеря и варианту. */
const CAMP_NPC: Record<0 | 1 | 2, readonly [NpcName, NpcName]> = {
  0: ['bandit', 'thief'],
  1: ['raider', 'shaman'],
  2: ['warlord', 'ogre'],
};

const cache = new Map<string, Promise<HTMLImageElement>>();

function toImage(key: string, svg: string): Promise<HTMLImageElement> {
  let p = cache.get(key);
  if (!p) {
    p = new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error(`Не загрузилась картинка для карты: ${key}`));
      img.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg.replace('<svg', '<svg xmlns="http://www.w3.org/2000/svg"'))}`;
    });
    cache.set(key, p);
    p.catch(() => cache.delete(key));
  }
  return p;
}

const npcImage = (name: NpcName): Promise<HTMLImageElement> =>
  toImage(`npc:${name}`, renderToStaticMarkup(<NpcArt name={name} size={96} anim="none" />));

/** Замок для карты: то же здание, что в городе, но уменьшенное. */
const castleImage = (mine: boolean): Promise<HTMLImageElement> =>
  toImage(
    `castle:${mine}`,
    renderToStaticMarkup(
      <svg viewBox="-150 -250 320 420" width="320" height="420">
        <IsoDefs />
        <IsoBuilding
          kind="castle"
          id={`m${mine}`}
          ox={0}
          oy={0}
          tier={mine ? 3 : 1}
          built
          busy={false}
          worker={null}
        />
      </svg>,
    ),
  );

function poly(ctx: Ctx, list: readonly Pt[], fill: string | CanvasGradient, stroke = true): void {
  ctx.beginPath();
  list.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
  ctx.closePath();
  ctx.fillStyle = fill;
  ctx.fill();
  if (stroke) {
    ctx.lineWidth = 1.3;
    ctx.lineJoin = 'round';
    ctx.strokeStyle = 'rgba(30,18,8,.6)';
    ctx.stroke();
  }
}

function disc(
  ctx: Ctx,
  x: number,
  y: number,
  r: number,
  fill: string | CanvasGradient,
  outline = true,
): void {
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fillStyle = fill;
  ctx.fill();
  if (outline) {
    ctx.lineWidth = 1.3;
    ctx.strokeStyle = 'rgba(30,18,8,.6)';
    ctx.stroke();
  }
}

function ball(ctx: Ctx, x: number, y: number, r: number, light: string, dark: string): void {
  const g = ctx.createRadialGradient(x - r * 0.35, y - r * 0.4, r * 0.1, x, y, r);
  g.addColorStop(0, light);
  g.addColorStop(1, dark);
  disc(ctx, x, y, r, g);
}

function shadow(ctx: Ctx, x: number, y: number, rx: number): void {
  ctx.beginPath();
  ctx.ellipse(x, y, rx, rx * 0.42, 0, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(8,30,8,.28)';
  ctx.fill();
}

function drawDecor(ctx: Ctx, kind: Decor, x: number, y: number, seed: number): void {
  const s = 0.85 + seed * 0.35;
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  const tree = kind === 'oak' || kind === 'pine' ? treeSprite(kind, seed) : null;
  if (tree) {
    ctx.drawImage(tree, -36, -84, 72, 84);
  } else if (kind === 'oak') {
    shadow(ctx, 2, 0, 17);
    ctx.fillStyle = '#7a5230';
    ctx.fillRect(-3, -18, 6, 20);
    ball(ctx, -11, -28, 13, '#9ad66e', '#3c8a3a');
    ball(ctx, 11, -28, 13, '#a8dc78', '#3f8f3c');
    ball(ctx, 0, -40, 15, '#b0e082', '#428f3c');
  } else if (kind === 'pine') {
    shadow(ctx, 2, 0, 15);
    ctx.fillStyle = '#5a3620';
    ctx.fillRect(-2.5, -10, 5, 12);
    for (const [top, half, base] of [
      [-60, 14, -32],
      [-46, 18, -16],
      [-32, 22, -2],
    ] as const) {
      const g = ctx.createLinearGradient(-half, 0, half, 0);
      g.addColorStop(0, '#52b25c');
      g.addColorStop(1, '#2c7438');
      poly(
        ctx,
        [
          [0, top],
          [half, base],
          [-half, base],
        ],
        g,
      );
    }
  } else if (kind === 'peak') {
    const h = 34 + seed * 26;
    shadow(ctx, 2, 6, 30);
    const L: Pt = [-30, 2];
    const B: Pt = [0, 16];
    const R: Pt = [30, 2];
    const T: Pt = [0, -12];
    const P: Pt = [-2 + seed * 6, -h];
    poly(ctx, [L, T, R, P], '#7a7468');
    poly(ctx, [L, B, P], '#c2bcae');
    poly(ctx, [B, R, P], '#8f887a');
    poly(
      ctx,
      [
        [P[0], P[1]],
        [P[0] + 9, P[1] + h * 0.28],
        [P[0] + 2, P[1] + h * 0.22],
        [P[0] - 3, P[1] + h * 0.3],
        [P[0] - 9, P[1] + h * 0.26],
      ],
      '#f6f8fc',
      false,
    );
  } else if (kind === 'cactus') {
    shadow(ctx, 1, 2, 10);
    ctx.fillStyle = '#4f9a4a';
    ctx.strokeStyle = 'rgba(30,60,20,.7)';
    ctx.lineWidth = 1.2;
    for (const [rx, ry, w, h] of [
      [-3, -26, 6, 28],
      [-11, -18, 5, 12],
      [6, -20, 5, 12],
    ] as const) {
      ctx.beginPath();
      ctx.roundRect(rx, ry, w, h, 3);
      ctx.fill();
      ctx.stroke();
    }
  } else if (kind === 'reed') {
    shadow(ctx, 0, 2, 9);
    ctx.strokeStyle = '#7fa35a';
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    for (const [dx, lean] of [
      [-5, -3],
      [0, 1],
      [5, 4],
    ] as const) {
      ctx.beginPath();
      ctx.moveTo(dx, 2);
      ctx.quadraticCurveTo(dx + lean / 2, -12, dx + lean, -22);
      ctx.stroke();
    }
    ctx.fillStyle = '#8a5a30';
    ctx.fillRect(-1, -26, 3, 9);
  } else if (kind === 'bush') {
    shadow(ctx, 1, 2, 12);
    ball(ctx, -6, -6, 8, '#9ad66e', '#3c8a3a');
    ball(ctx, 6, -6, 8, '#a8dc78', '#3f8f3c');
    ball(ctx, 0, -12, 9, '#b0e082', '#428f3c');
  } else {
    for (const [dx, dy, c] of [
      [-10, -2, '#ffe27a'],
      [3, -6, '#fff'],
      [10, 2, '#ff9ab0'],
      [-3, 4, '#fff'],
    ] as const) {
      disc(ctx, dx, dy, 3, c, false);
      disc(ctx, dx, dy, 1.1, '#c98a1a', false);
    }
  }
  ctx.restore();
}

const INK = 'rgba(30,18,8,.65)';

function lin(ctx: Ctx, x0: number, y0: number, x1: number, y1: number, a: string, b: string) {
  const g = ctx.createLinearGradient(x0, y0, x1, y1);
  g.addColorStop(0, a);
  g.addColorStop(1, b);
  return g;
}

/** Куб в изометрии: верх и две боковые грани. (x, y) — центр нижнего ромба. */
function cube(
  ctx: Ctx,
  x: number,
  y: number,
  w: number,
  h: number,
  top: string,
  left: string,
  right: string,
): void {
  const d = w / 2;
  const t = d / 2;
  poly(
    ctx,
    [
      [x - d, y - h],
      [x, y - h + t],
      [x, y + t],
      [x - d, y],
    ],
    left,
  );
  poly(
    ctx,
    [
      [x, y - h + t],
      [x + d, y - h],
      [x + d, y],
      [x, y + t],
    ],
    right,
  );
  poly(
    ctx,
    [
      [x, y - h - t],
      [x + d, y - h],
      [x, y - h + t],
      [x - d, y - h],
    ],
    top,
  );
}

/** Бревно, лежащее вдоль изометрической оси, с торцом. */
function logPiece(ctx: Ctx, x: number, y: number): void {
  ctx.save();
  ctx.translate(x, y);
  ctx.transform(1, 0.45, 0, 1, 0, 0);
  ctx.fillStyle = lin(ctx, 0, -7, 0, 7, '#c08a52', '#85552a');
  ctx.strokeStyle = INK;
  ctx.lineWidth = 1.3;
  ctx.beginPath();
  ctx.roundRect(-16, -7, 32, 14, 7);
  ctx.fill();
  ctx.stroke();
  ctx.restore();
  ctx.beginPath();
  ctx.ellipse(x + 14, y + 6.3, 5, 6.5, 0, 0, Math.PI * 2);
  ctx.fillStyle = '#ecd19a';
  ctx.fill();
  ctx.strokeStyle = INK;
  ctx.stroke();
  ctx.beginPath();
  ctx.ellipse(x + 14, y + 6.3, 2.3, 3.2, 0, 0, Math.PI * 2);
  ctx.strokeStyle = 'rgba(120,80,40,.7)';
  ctx.stroke();
}

function pickaxe(ctx: Ctx, x: number, y: number): void {
  ctx.strokeStyle = '#6b4424';
  ctx.lineWidth = 3;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.lineTo(x + 10, y - 26);
  ctx.stroke();
  ctx.strokeStyle = '#8c8c94';
  ctx.lineWidth = 3.5;
  ctx.beginPath();
  ctx.moveTo(x + 2, y - 28);
  ctx.quadraticCurveTo(x + 10, y - 34, x + 19, y - 26);
  ctx.stroke();
}

/** Ресурсная точка: узнаваемый объёмный объект, а не плоское пятно. */
function drawNode(ctx: Ctx, res: ResourceKey, x: number, y: number): void {
  // тёмное пятно земли под объектом
  ctx.beginPath();
  ctx.ellipse(x, y + 2, 30, 13, 0, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(70,50,20,.32)';
  ctx.fill();
  if (res === 'gold') {
    // рудничный вход в скале, рядом тележка с золотом
    poly(
      ctx,
      [
        [x - 26, y + 2],
        [x - 20, y - 22],
        [x - 4, y - 34],
        [x + 14, y - 26],
        [x + 22, y + 2],
        [x, y + 10],
      ],
      lin(ctx, x - 26, y - 34, x + 22, y + 10, '#b3ad9f', '#6f6a5e'),
    );
    poly(
      ctx,
      [
        [x - 10, y + 4],
        [x - 10, y - 14],
        [x, y - 20],
        [x + 10, y - 14],
        [x + 10, y + 4],
        [x, y + 9],
      ],
      '#2b1d12',
    );
    ctx.strokeStyle = '#8a5a2c';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(x - 12, y + 4);
    ctx.lineTo(x - 12, y - 15);
    ctx.lineTo(x, y - 22);
    ctx.lineTo(x + 12, y - 15);
    ctx.lineTo(x + 12, y + 4);
    ctx.stroke();
    cube(ctx, x + 22, y + 10, 18, 9, '#9a6a3c', '#7a5230', '#5e3c20');
    for (const [dx, dy] of [
      [-4, -13],
      [3, -14],
      [-1, -18],
    ] as const)
      ball(ctx, x + 22 + dx, y + 1 + dy + 4, 4.6, '#fff2a8', '#c9961a');
    for (const [dx, dy] of [
      [-18, 6],
      [-12, 9],
    ] as const)
      ball(ctx, x + dx, y + dy, 3.6, '#fff2a8', '#c9961a');
  } else if (res === 'wood') {
    // поленница: 3 + 2 + 1 брёвна, рядом пень с топором
    for (const [dx, dy] of [
      [-12, 0],
      [2, 6],
      [16, 12],
    ] as const)
      logPiece(ctx, x + dx - 6, y + dy - 4);
    for (const [dx, dy] of [
      [-5, -8],
      [9, -2],
    ] as const)
      logPiece(ctx, x + dx - 6, y + dy - 8);
    logPiece(ctx, x + 2 - 6, y - 14 - 4);
    cube(ctx, x - 26, y + 8, 14, 9, '#e8c88e', '#9a6a3c', '#7a5230');
    ctx.strokeStyle = '#6b4424';
    ctx.lineWidth = 2.6;
    ctx.beginPath();
    ctx.moveTo(x - 26, y - 4);
    ctx.lineTo(x - 18, y - 22);
    ctx.stroke();
    ctx.fillStyle = '#9ca0a8';
    ctx.fillRect(x - 24, y - 26, 10, 6);
  } else if (res === 'stone') {
    // каменоломня: глыбы, тёсаные блоки и кирка
    poly(
      ctx,
      [
        [x - 28, y + 4],
        [x - 22, y - 14],
        [x - 8, y - 24],
        [x + 8, y - 16],
        [x + 12, y + 2],
        [x - 8, y + 10],
      ],
      lin(ctx, x - 28, y - 24, x + 12, y + 10, '#c9c5ba', '#857f73'),
    );
    poly(
      ctx,
      [
        [x - 8, y + 10],
        [x + 12, y + 2],
        [x + 8, y - 16],
        [x - 8, y - 24],
        [x - 10, y - 8],
      ],
      'rgba(60,56,48,.45)',
      false,
    );
    poly(
      ctx,
      [
        [x - 22, y - 14],
        [x - 8, y - 24],
        [x - 12, y - 10],
      ],
      '#e6e2d6',
      false,
    );
    cube(ctx, x + 18, y + 8, 18, 12, '#d9d5c9', '#a8a396', '#7d786c');
    cube(ctx, x + 10, y + 14, 14, 8, '#d9d5c9', '#a8a396', '#7d786c');
    pickaxe(ctx, x - 2, y + 12);
  } else {
    // ферма: стог и колосья в ограде
    poly(
      ctx,
      [
        [x, y - 12],
        [x + 30, y + 2],
        [x, y + 16],
        [x - 30, y + 2],
      ],
      '#8a6238',
      false,
    );
    for (let i = -3; i <= 3; i++)
      for (let j = -1; j <= 1; j++) {
        const px = x + i * 7 + j * 3;
        const py = y + 3 + j * 6 - i * 0.6;
        ctx.strokeStyle = '#d8a31c';
        ctx.lineWidth = 2.2;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(px, py);
        ctx.lineTo(px, py - 9);
        ctx.stroke();
        ctx.fillStyle = '#f2cf4a';
        ctx.fillRect(px - 1.5, py - 14, 3, 6);
      }
    // стог
    poly(
      ctx,
      [
        [x + 14, y - 2],
        [x + 22, y - 26],
        [x + 30, y - 2],
        [x + 22, y + 4],
      ],
      lin(ctx, x + 14, y - 26, x + 30, y + 4, '#f3d467', '#c9962a'),
    );
    ctx.strokeStyle = 'rgba(120,80,20,.6)';
    ctx.lineWidth = 1.2;
    for (const k of [-10, -16, -4] as const) {
      ctx.beginPath();
      ctx.moveTo(x + 17, y + k);
      ctx.lineTo(x + 27, y + k);
      ctx.stroke();
    }
  }
}

function levelBadge(ctx: Ctx, level: number, x: number, y: number): void {
  disc(ctx, x, y, 10, '#2a1a0e', false);
  disc(ctx, x, y, 8.5, '#f2cf6b', false);
  ctx.fillStyle = '#2a1a0e';
  ctx.font = 'bold 11px Inter, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(String(level), x, y + 0.5);
}

/** Шатёр: два полотнища со скатом, вход, растяжки и флаг. */
function tent(ctx: Ctx, x: number, y: number, k: number, cloth: readonly [string, string]): void {
  const w = 26 * k;
  const h = 34 * k;
  poly(
    ctx,
    [
      [x - w, y + 2],
      [x, y + 13 * k],
      [x, y - h],
      [x - w * 0.15, y - h + 4],
    ],
    lin(ctx, x - w, y - h, x, y + 13, cloth[0], cloth[1]),
  );
  poly(
    ctx,
    [
      [x, y + 13 * k],
      [x + w, y + 2],
      [x + w * 0.15, y - h + 4],
      [x, y - h],
    ],
    lin(ctx, x, y - h, x + w, y + 13, cloth[1], '#6b4a2a'),
  );
  poly(
    ctx,
    [
      [x - 7 * k, y + 10 * k],
      [x, y + 13 * k],
      [x + 7 * k, y + 10 * k],
      [x, y - 6 * k],
    ],
    '#2b1d12',
    false,
  );
  ctx.strokeStyle = 'rgba(255,255,255,.55)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(x - w * 0.55, y + 5 * k);
  ctx.lineTo(x - 2, y - h * 0.55);
  ctx.moveTo(x + w * 0.55, y + 5 * k);
  ctx.lineTo(x + 2, y - h * 0.55);
  ctx.stroke();
  ctx.strokeStyle = '#5a3620';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(x, y - h);
  ctx.lineTo(x, y - h - 12 * k);
  ctx.stroke();
  poly(
    ctx,
    [
      [x, y - h - 12 * k],
      [x + 13 * k, y - h - 8 * k],
      [x, y - h - 3 * k],
    ],
    '#b32626',
  );
}

function campfire(ctx: Ctx, x: number, y: number): void {
  ctx.strokeStyle = '#5a3620';
  ctx.lineWidth = 3;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(x - 6, y + 2);
  ctx.lineTo(x + 6, y - 2);
  ctx.moveTo(x - 6, y - 2);
  ctx.lineTo(x + 6, y + 2);
  ctx.stroke();
  poly(
    ctx,
    [
      [x, y - 14],
      [x + 5, y - 4],
      [x, y],
      [x - 5, y - 4],
    ],
    '#ff8a2a',
    false,
  );
  poly(
    ctx,
    [
      [x, y - 9],
      [x + 2.5, y - 3],
      [x, y - 1],
      [x - 2.5, y - 3],
    ],
    '#ffd36a',
    false,
  );
}

function stakes(ctx: Ctx, x: number, y: number, n: number, dx: number, dy: number): void {
  for (let i = 0; i < n; i++) {
    const px = x + dx * i;
    const py = y + dy * i;
    poly(
      ctx,
      [
        [px - 3, py + 2],
        [px - 3, py - 14],
        [px, py - 19],
        [px + 3, py - 14],
        [px + 3, py + 2],
      ],
      lin(ctx, px - 3, 0, px + 3, 0, '#b07a42', '#7a5230'),
    );
  }
}

/** Лагерь: чем выше ступень, тем больше шатров, частокол и сторожевая вышка. */
function drawTent(ctx: Ctx, x: number, y: number, tier: 0 | 1 | 2 = 0): void {
  ctx.beginPath();
  ctx.ellipse(x, y + 4, 40, 17, 0, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(70,50,20,.3)';
  ctx.fill();
  if (tier >= 1) {
    stakes(ctx, x - 36, y - 2, 5, 7, 3.5);
    stakes(ctx, x + 4, y + 16, 5, 7, -3.5);
  }
  if (tier >= 2) {
    // сторожевая вышка
    cube(ctx, x + 30, y + 2, 14, 30, '#b07a42', '#8a5a2c', '#6b4424');
    poly(
      ctx,
      [
        [x + 21, y - 32],
        [x + 30, y - 46],
        [x + 39, y - 32],
      ],
      '#b32626',
    );
  }
  tent(
    ctx,
    x,
    y,
    tier === 0 ? 0.95 : 1.1,
    tier === 2 ? ['#7a3030', '#4f1c1c'] : ['#d8b27a', '#a77a44'],
  );
  if (tier >= 1) tent(ctx, x - 26, y + 10, 0.7, ['#c9a06a', '#96693a']);
  campfire(ctx, x + 14, y + 14);
}

function drawMarker(
  ctx: Ctx,
  m: Marker,
  x: number,
  y: number,
  imgs: {
    castleMine: HTMLImageElement | null;
    castleOther: HTMLImageElement | null;
    npc: ReadonlyMap<string, HTMLImageElement>;
  },
): void {
  ctx.save();
  if (m.dim) ctx.globalAlpha = 0.45;
  if (m.type === 'castle') {
    // подсветка своего замка золотым ромбом
    if (m.mine) {
      poly(
        ctx,
        [
          [x, y - 17],
          [x + 34, y],
          [x, y + 17],
          [x - 34, y],
        ],
        'rgba(242,207,107,.35)',
        false,
      );
      ctx.strokeStyle = '#f2cf6b';
      ctx.lineWidth = 3;
      ctx.stroke();
    }
    const fort = fortSprite(m.mine);
    const img = m.mine ? imgs.castleMine : imgs.castleOther;
    if (fort) ctx.drawImage(fort, x - 52, y - 66, 104, 104);
    else if (img) ctx.drawImage(img, x - 58, y - 110, 116, 152);
    else disc(ctx, x, y - 10, 12, m.mine ? '#f2cf6b' : '#3f68b4');
    if (m.shielded) {
      disc(ctx, x + 36, y - 60, 11, '#3f86c4');
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.moveTo(x + 36, y - 67);
      ctx.lineTo(x + 42, y - 64);
      ctx.lineTo(x + 42, y - 58);
      ctx.lineTo(x + 36, y - 53);
      ctx.lineTo(x + 30, y - 58);
      ctx.lineTo(x + 30, y - 64);
      ctx.closePath();
      ctx.fill();
    }
  } else if (m.type === 'node') {
    drawNode(ctx, m.resource, x, y);
    levelBadge(ctx, m.level, x + 22, y - 26);
  } else {
    drawTent(ctx, x - 12, y, m.tier);
    const img = imgs.npc.get(CAMP_NPC[m.tier][m.variant === 0 ? 0 : 1]);
    if (img) ctx.drawImage(img, x + 6, y - 40, 50, 56);
    else disc(ctx, x + 14, y - 10, 8, '#b32626');
    levelBadge(ctx, m.level, x - 26, y - 34);
  }
  ctx.restore();
}

interface Props {
  cells: readonly MapCellDto[];
  size: number;
  /** Поворот обзора на четверть оборота (0…3). */
  rot?: Rot;
  className?: string;
}

const DIRS = [
  [1, 0],
  [0, 1],
  [-1, 0],
  [0, -1],
] as const;

/** Две вершины ромба, ближайшие к центру соседней клетки: общее ребро при любом повороте. */
function sharedEdge(poly4: ReadonlyArray<Pt>, nb: Pt): [Pt, Pt] {
  const d = (p: Pt): number => Math.hypot(p[0] - nb[0], p[1] - nb[1]);
  const sorted = [...poly4].sort((a, b) => d(a) - d(b));
  return [sorted[0]!, sorted[1]!];
}

/** Изометрическая карта на холсте: ромбы-клетки, объёмные горы и деревья, замки и лагеря. */
export function MapCanvas({ cells, size, rot = 0, className }: Props) {
  const ref = useRef<HTMLCanvasElement>(null);
  const [imgs, setImgs] = useState<{
    castleMine: HTMLImageElement | null;
    castleOther: HTMLImageElement | null;
    npc: ReadonlyMap<string, HTMLImageElement>;
  } | null>(null);
  const dims = mapDims(size);

  useEffect(() => {
    let alive = true;
    const names: NpcName[] = ['bandit', 'thief', 'raider', 'shaman', 'warlord', 'ogre'];
    void Promise.all([
      castleImage(true),
      castleImage(false),
      ...names.map((n) => npcImage(n).then((i) => [n, i] as const)),
    ]).then(
      ([mine, other, ...list]) => {
        if (!alive) return;
        setImgs({
          castleMine: mine as HTMLImageElement,
          castleOther: other as HTMLImageElement,
          npc: new Map(list as Array<readonly [string, HTMLImageElement]>),
        });
      },
      () => undefined, // без картинок карта остаётся кликабельной — маркеры рисуются кружками
    );
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    const canvas = ref.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx || cells.length === 0) return;
    const x0 = Math.min(...cells.map((c) => c.x));
    const y0 = Math.min(...cells.map((c) => c.y));
    const rel = cells.map((c) => ({ c, cx: c.x - x0, cy: c.y - y0 }));
    const at = new Map(rel.map((r) => [`${r.cx},${r.cy}`, r.c]));
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // 1. земля и земляной борт снизу
    const depth = (cx: number, cy: number): number => {
      const [rx, ry] = rotateCell(cx, cy, size, rot);
      return rx + ry;
    };
    rel.sort((a, b) => depth(a.cx, a.cy) - depth(b.cx, b.cy));
    for (const { c, cx, cy } of rel) {
      const { ground, shade } = groundOf(c);
      const base = GROUND[ground][(cx + cy + (shade > 0.6 ? 1 : 0)) % 2]!;
      const poly4 = tilePoly(cx, cy, size, rot);
      poly(ctx, poly4, base, false);
      ctx.lineWidth = 1;
      ctx.strokeStyle = base;
      ctx.stroke();
      // земляной борт только на настоящем краю мира и только с нижней (по экрану) стороны
      {
        const [ccx, ccy] = tileCenter(cx, cy, size, rot);
        for (const [dx, dy] of DIRS) {
          const wx = c.x + dx;
          const wy = c.y + dy;
          if (wx >= 0 && wy >= 0 && wx < MAP_SIZE && wy < MAP_SIZE) continue;
          const nb = tileCenter(cx + dx, cy + dy, size, rot);
          if (nb[1] <= ccy) continue;
          const [v1, v2] = sharedEdge(poly4, nb);
          poly(
            ctx,
            [v1, v2, [v2[0], v2[1] + SOIL], [v1[0], v1[1] + SOIL]],
            nb[0] < ccx ? '#8a6238' : '#6a4526',
          );
        }
      }
      // пёстрая трава
      if (ground === 'grass' && shade > 0.62) {
        const [px, py] = tileCenter(cx, cy, size, rot);
        ctx.strokeStyle = 'rgba(60,120,50,.55)';
        ctx.lineWidth = 1.6;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(px - 8 + shade * 12, py);
        ctx.lineTo(px - 10 + shade * 12, py - 6);
        ctx.moveTo(px - 8 + shade * 12, py);
        ctx.lineTo(px - 5 + shade * 12, py - 7);
        ctx.stroke();
      }
      // пена у берега
      if (isOpenWater(ground)) {
        for (const [dx, dy] of DIRS) {
          const n = at.get(`${cx + dx},${cy + dy}`);
          if (n && !isOpenWater(groundOf(n).ground) && groundOf(n).ground !== 'river') {
            const [v1, v2] = sharedEdge(poly4, tileCenter(cx + dx, cy + dy, size, rot));
            ctx.strokeStyle = 'rgba(255,255,255,.85)';
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(v1[0], v1[1]);
            ctx.lineTo(v2[0], v2[1]);
            ctx.stroke();
          }
        }
        ctx.strokeStyle = 'rgba(255,255,255,.35)';
        ctx.lineWidth = 1.5;
        const [px, py] = tileCenter(cx, cy, size, rot);
        ctx.beginPath();
        ctx.moveTo(px - 10 + shade * 8, py);
        ctx.quadraticCurveTo(px - 4 + shade * 8, py - 4, px + 2 + shade * 8, py);
        ctx.quadraticCurveTo(px + 8 + shade * 8, py + 4, px + 14 + shade * 8, py);
        ctx.stroke();
      }
    }
    // 1б. дороги: полотно от центра клетки к соседним дорожным клеткам; над водой и горами — мост
    const roadPass = (pass: 'edge' | 'fill'): void => {
      for (const { c, cx, cy } of rel) {
        if (!c.road) continue;
        const [px, py] = tileCenter(cx, cy, size, rot);
        const bridge = c.terrain === 'river' || c.terrain === 'lake' || c.terrain === 'water';
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.strokeStyle = pass === 'edge' ? 'rgba(70,46,20,.85)' : bridge ? '#b98d54' : '#d9b97e';
        ctx.lineWidth = pass === 'edge' ? 15 : 10;
        ctx.beginPath();
        ctx.moveTo(px, py);
        ctx.lineTo(px, py);
        for (const [dx, dy] of [
          [1, 0],
          [0, 1],
          [-1, 0],
          [0, -1],
        ] as const) {
          if (!at.get(`${cx + dx},${cy + dy}`)?.road) continue;
          const [nx, ny] = tileCenter(cx + dx, cy + dy, size, rot);
          ctx.moveTo(px, py);
          ctx.lineTo((px + nx) / 2, (py + ny) / 2);
        }
        ctx.stroke();
      }
    };
    roadPass('edge');
    roadPass('fill');
    // 2. украшения и маркеры: дальние раньше ближних
    const stuff = imgs ?? {
      castleMine: null,
      castleOther: null,
      npc: new Map<string, HTMLImageElement>(),
    };
    for (const { c, cx, cy } of rel) {
      const [px, py] = tileCenter(cx, cy, size, rot);
      const decor = decorOf(c);
      if (decor)
        drawDecor(
          ctx,
          decor,
          px,
          py + (decor === 'flowers' ? 0 : 8),
          ((c.x * 7 + c.y * 13) % 10) / 10,
        );
      const m = markerOf(c);
      if (m) drawMarker(ctx, m, px, py + 6, stuff);
    }
  }, [cells, imgs, size, rot]);

  return (
    <canvas
      ref={ref}
      width={dims.width}
      height={dims.height}
      aria-hidden="true"
      className={className}
      style={{ width: dims.width, height: dims.height, maxWidth: 'none', display: 'block' }}
    />
  );
}

export { OUTLINE, PAD_TOP, TILE_H, TILE_W };
