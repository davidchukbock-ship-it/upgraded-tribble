import { keepPreviousData, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  useCallback,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type KeyboardEvent,
  type PointerEvent as ReactPointerEvent,
} from 'react';
import { createPortal } from 'react-dom';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
import {
  MAP_SIZE,
  cargoOf,
  gatherSeconds,
  isOnlyCavalry,
  parseUnitId,
  techEffects,
  totalUnits,
  travelSeconds,
  type CastleDto,
  type MapCellDto,
  type MarchDto,
  type MarchType,
  type UnitCounts,
} from '@tc/shared';
import { ArtIcon, NpcArt, type NpcName } from '../../art';
import { formatDurationT } from '../../lib/duration';
import { formatFull } from '../../lib/format';
import { cn } from '../../lib/cn';
import { useToasts } from '../../store/toast';
import { Badge, Button, Panel, ScrollModal, TimerProgress } from '../../ui';
import { errorMessage } from '../auth/errors';
import { useCastleMutation, useLiveCastle } from '../castle/useCastle';
import { mapApi, marchApi } from './api';
import { MapCanvas } from './MapCanvas';
import { MiniMap, type MiniView } from './MiniMap';
import {
  TILE_H,
  TILE_W,
  mapDims,
  pickTile,
  tileAt,
  tileCenter,
  tilePoly,
  worldDelta,
  type Rot,
} from './mapGeom';

const SMALL = 24;
const LARGE = 40;
const initialSize = (): number =>
  typeof window !== 'undefined' && window.innerWidth < 640 ? SMALL : LARGE;

const ROT_KEY = 'tc.mapRot';
function loadRot(): Rot {
  try {
    const v = Number(localStorage.getItem(ROT_KEY));
    return v === 1 || v === 2 || v === 3 ? v : 0;
  } catch {
    return 0;
  }
}

type Action = 'attack' | 'scout' | 'monster' | 'gather';

/** Что можно сделать с клеткой. */
export function actionsFor(cell: MapCellDto): Action[] {
  if (cell.castle) return cell.castle.isMe ? [] : ['scout', 'attack'];
  if (cell.kind === 'camp') return cell.busyUntil ? [] : ['monster'];
  if (cell.kind === 'resource') return ['gather'];
  return [];
}

/** Ссылка на набор технологий «Тактика»: сокращение пути. */
const tacticsOf = (castle: CastleDto): number =>
  techEffects({ tactics: castle.research.techs.find((x) => x.key === 'tactics')?.level ?? 0 })
    .travelTime;

function cellTitle(t: (k: string, o?: Record<string, unknown>) => string, c: MapCellDto): string {
  if (c.castle) return t('map.castleOf', { name: c.castle.nickname });
  if (c.kind === 'camp') return t('map.camp', { level: c.level });
  if (c.kind === 'resource')
    return t('map.node', { res: t(`resource.${c.resource}`), level: c.level });
  return c.road
    ? `${t(`map.terrain.${c.terrain}`)} · ${t('map.road')}`
    : t(`map.terrain.${c.terrain}`);
}

// ── Отправка отряда ──────────────────────────────────────────────────────────

function MarchForm({
  castle,
  cell,
  action,
  onSent,
}: {
  castle: CastleDto;
  cell: MapCellDto;
  action: Action;
  onSent: () => void;
}) {
  const { t } = useTranslation();
  const push = useToasts((s) => s.push);
  const [counts, setCounts] = useState<Record<string, string>>({});
  const send = useCastleMutation(marchApi.send);

  const available = castle.army.units.filter((u) => u.count > 0);
  const chosen: UnitCounts = {};
  for (const u of available) {
    const n = Math.min(u.count, Math.max(0, Math.floor(Number(counts[u.id]) || 0)));
    if (n > 0 && (action !== 'scout' || parseUnitId(u.id)?.type === 'cavalry')) chosen[u.id] = n;
  }
  const total = totalUnits(chosen);
  const from = castle.position;
  const seconds =
    from && total > 0
      ? travelSeconds(from, cell, chosen, tacticsOf(castle), castle.worldSpeed)
      : null;
  const cargo = cargoOf(chosen);

  let blocked: string | null = null;
  if (castle.marches.length >= castle.marchesMax) blocked = t('map.blocked.full');
  else if (action === 'attack' && cell.castle?.shielded) blocked = t('map.blocked.shield');
  else if (total < 1) blocked = t('map.blocked.noUnits');
  else if (action === 'scout' && !isOnlyCavalry(chosen)) blocked = t('map.blocked.scout');

  return (
    <form
      className="mt-3 flex flex-col gap-3"
      onSubmit={(e) => {
        e.preventDefault();
        if (blocked) return;
        send.mutate(
          { type: action as MarchType, target: { x: cell.x, y: cell.y }, units: chosen },
          {
            onError: (err) => push(errorMessage(t, err), 'error'),
            onSuccess: () => {
              push(t('map.sent', { x: cell.x, y: cell.y }), 'success');
              onSent();
            },
          },
        );
      }}
    >
      {available.length === 0 ? (
        <p className="text-sm">{t('map.blocked.noArmy')}</p>
      ) : (
        <ul className="flex flex-col gap-2" aria-label={t('map.units')}>
          {available.map((u) => {
            const parsed = parseUnitId(u.id);
            const disabled = action === 'scout' && parsed?.type !== 'cavalry';
            return (
              <li key={u.id} className="flex items-center gap-2 text-sm">
                <label className="flex-1 font-semibold" htmlFor={`m-${u.id}`}>
                  {parsed ? `${t(`unit.${parsed.type}`)} T${parsed.tier}` : u.id}{' '}
                  <span className="font-normal opacity-80">
                    ({t('map.have')} {formatFull(u.count)})
                  </span>
                </label>
                <input
                  id={`m-${u.id}`}
                  inputMode="numeric"
                  disabled={disabled}
                  value={disabled ? '' : (counts[u.id] ?? '')}
                  placeholder="0"
                  onChange={(e) =>
                    setCounts((c) => ({
                      ...c,
                      [u.id]: e.target.value.replace(/[^\d]/g, '').slice(0, 6),
                    }))
                  }
                  className="min-h-[40px] w-24 rounded-lg border-2 border-wood-light bg-white/80 px-3 text-ink disabled:opacity-40"
                />
                <Button
                  type="button"
                  className="!min-h-[40px] !px-2 text-sm"
                  disabled={disabled}
                  onClick={() => setCounts((c) => ({ ...c, [u.id]: String(u.count) }))}
                  aria-label={`${t('map.all')}: ${parsed ? t(`unit.${parsed.type}`) : u.id}`}
                >
                  {t('map.all')}
                </Button>
              </li>
            );
          })}
        </ul>
      )}
      <p className="text-sm">
        {seconds !== null && (
          <>
            {t('map.travel')}: <b>{formatDurationT(t, seconds)}</b>
            {action === 'gather' && (
              <>
                {' · '}
                {t('map.load')}: <b>{formatFull(cargo)}</b> (
                {formatDurationT(t, gatherSeconds(cargo))})
              </>
            )}
          </>
        )}
      </p>
      <Button type="submit" variant="gold" disabled={blocked !== null || send.isPending}>
        {t(`map.action.${action}`)}
      </Button>
      {blocked && total >= 0 && (
        <p role="status" className="text-sm font-semibold">
          {blocked}
        </p>
      )}
    </form>
  );
}

/** Иллюстрация клетки: кто или что здесь находится. */
function CellPortrait({ cell }: { cell: MapCellDto }) {
  const camp = cell.kind === 'camp';
  const tier = cell.level <= 4 ? 0 : cell.level <= 8 ? 1 : 2;
  const names: NpcName[] = camp
    ? tier === 0
      ? ['bandit', 'thief', 'banditArcher']
      : tier === 1
        ? ['raider', 'shaman', 'raider']
        : ['ogre', 'warlord', 'shaman']
    : cell.castle
      ? [cell.castle.isMe ? 'king' : 'guard']
      : [];
  if (names.length === 0 && !(cell.kind === 'resource' && cell.resource)) return null;
  return (
    <div
      className="mb-3 flex items-end justify-center gap-1 rounded-lg px-2 pt-2"
      style={{ background: 'linear-gradient(#9bd0f2, #d7ecf8 55%, #5aa84c 56%)' }}
      aria-hidden="true"
    >
      {cell.kind === 'resource' && cell.resource && (
        <ArtIcon name={cell.resource} size={72} className="mb-2" />
      )}
      {names.map((n, i) => (
        <NpcArt
          key={`${n}${i}`}
          name={n}
          size={n === 'ogre' || n === 'warlord' ? 92 : 76}
          anim="attack"
          delay={i * 0.3}
        />
      ))}
    </div>
  );
}

function CellDialog({
  cell,
  castle,
  onClose,
}: {
  cell: MapCellDto;
  castle: CastleDto;
  onClose: () => void;
}) {
  const { t } = useTranslation();
  const actions = actionsFor(cell);
  const [action, setAction] = useState<Action | null>(actions[0] ?? null);
  const now = Date.now();
  return (
    <ScrollModal open title={cellTitle(t, cell)} onClose={onClose}>
      <CellPortrait cell={cell} />
      <dl className="grid grid-cols-2 gap-x-3 gap-y-1 text-sm">
        <dt className="opacity-80">{t('map.coords')}</dt>
        <dd>
          {cell.x}, {cell.y}
        </dd>
        <dt className="opacity-80">{t('map.landscape')}</dt>
        <dd>
          {t(`map.terrain.${cell.terrain}`)}
          {cell.road ? ` · ${t('map.road')}` : ''}
        </dd>
        {cell.castle && (
          <>
            <dt className="opacity-80">{t('map.owner')}</dt>
            <dd>
              {cell.castle.nickname}{' '}
              {cell.castle.isMe && <Badge tone="green">{t('map.you')}</Badge>}
              {cell.castle.shielded && <Badge tone="stone">{t('map.shielded')}</Badge>}
            </dd>
          </>
        )}
        {cell.kind === 'resource' && (
          <>
            <dt className="opacity-80">{t('map.stock')}</dt>
            <dd>{formatFull(cell.remaining ?? 0)}</dd>
          </>
        )}
        {cell.busyUntil && (
          <>
            <dt className="opacity-80">{t('map.respawn')}</dt>
            <dd>{formatDurationT(t, Math.max(0, (Date.parse(cell.busyUntil) - now) / 1000))}</dd>
          </>
        )}
      </dl>
      {cell.castle?.isMe && <p className="mt-3 text-sm">{t('map.yourCastle')}</p>}
      {actions.length > 1 && (
        <div role="radiogroup" aria-label={t('map.actionChoice')} className="mt-3 flex gap-2">
          {actions.map((a) => (
            <button
              key={a}
              type="button"
              role="radio"
              aria-checked={action === a}
              onClick={() => setAction(a)}
              className={cn(
                'min-h-[40px] flex-1 rounded-md border-2 px-2 font-display text-sm font-bold',
                action === a
                  ? 'border-gold bg-gold text-ink'
                  : 'border-stone bg-black/30 text-parchment',
              )}
            >
              {t(`map.action.${a}`)}
            </button>
          ))}
        </div>
      )}
      {action && actions.includes(action) && (
        <MarchForm castle={castle} cell={cell} action={action} onSent={onClose} />
      )}
    </ScrollModal>
  );
}

// ── Мои походы ───────────────────────────────────────────────────────────────

function MarchRow({ m, onDone }: { m: MarchDto; onDone: () => void }) {
  const { t } = useTranslation();
  const out = m.state === 'outbound';
  return (
    <li className="flex flex-wrap items-center gap-x-3 gap-y-2 rounded-lg bg-black/25 px-3 py-2">
      <span className="min-w-[10rem] font-display text-sm font-bold">
        {t(`map.action.${m.type}`)} → {m.targetName ?? `${m.target.x}, ${m.target.y}`}
        <span className="block text-xs font-normal opacity-85">
          {out ? t('map.outbound') : t('map.returning')} · {formatFull(totalUnits(m.units))}
        </span>
      </span>
      <TimerProgress
        className="min-w-[8rem] flex-1"
        label={t('map.marchTimer', { x: m.target.x, y: m.target.y })}
        startsAtMs={Date.parse(out ? m.startedAt : m.arriveAt)}
        endsAtMs={Date.parse(out ? m.arriveAt : m.returnAt)}
        onDone={onDone}
      />
      {m.reportId && (
        <Link className="text-sm underline" to={`/reports/${m.reportId}`}>
          {t('report.open')}
        </Link>
      )}
    </li>
  );
}

// ── Страница ─────────────────────────────────────────────────────────────────

const clamp = (n: number, max: number): number => Math.min(Math.max(0, Math.floor(n)), max);

export function MapPage() {
  const { t } = useTranslation();
  const client = useQueryClient();
  const { castle, isPending, isError, refetch } = useLiveCastle();
  const [size, setSize] = useState(initialSize);
  const [origin, setOrigin] = useState<{ x: number; y: number } | null>(null);
  const [cursor, setCursor] = useState<{ x: number; y: number } | null>(null);
  const [selected, setSelected] = useState<{ x: number; y: number } | null>(null);
  const [goto, setGoto] = useState({ x: '', y: '' });
  const [q, setQ] = useState('');
  const [view, setView] = useState<MiniView | null>(null);
  /** Поворот обзора на четверть оборота: смотреть на мир с другой стороны. */
  const [rot, setRot] = useState<Rot>(loadRot);
  const [panel, setPanel] = useState<'find' | 'marches' | null>(null);
  const viewRef = useRef<HTMLDivElement>(null);
  /** Клетка, на которую нужно навести окно после загрузки (переход, «к замку»). */
  const anchor = useRef<{ x: number; y: number } | null>(null);
  /** Начало показанного окна: по нему сохраняем положение прокрутки при смене окна. */
  const shown = useRef<{ x: number; y: number; size: number } | null>(null);
  const drag = useRef<{ x: number; y: number; left: number; top: number } | null>(null);

  // Первый показ: центрируем на своём замке
  const home = castle?.position ?? null;
  useEffect(() => {
    if (home && origin === null) {
      const half = Math.floor(size / 2);
      setOrigin({
        x: clamp(home.x - half, MAP_SIZE - size),
        y: clamp(home.y - half, MAP_SIZE - size),
      });
      setCursor({ x: home.x, y: home.y });
      anchor.current = { x: home.x, y: home.y };
    }
  }, [home, origin, size]);

  const tiles = useQuery({
    queryKey: ['map', origin?.x, origin?.y, size],
    queryFn: () => mapApi.tiles(origin!.x, origin!.y, size),
    enabled: origin !== null,
    placeholderData: keepPreviousData,
    refetchInterval: 20_000,
    staleTime: 5_000,
  });
  const search = useQuery({
    queryKey: ['map-search', q],
    queryFn: () => mapApi.search(q),
    enabled: q.trim().length >= 2,
  });

  const data = tiles.data;
  const byPos = useMemo(
    () => new Map((data?.cells ?? []).map((c) => [`${c.x},${c.y}`, c])),
    [data],
  );
  const cellAt = (p: { x: number; y: number } | null): MapCellDto | null =>
    p ? (byPos.get(`${p.x},${p.y}`) ?? null) : null;

  // Наводим окно на нужную клетку или сохраняем положение прокрутки, когда окно сместилось
  useLayoutEffect(() => {
    const el = viewRef.current;
    if (!el || !data) return;
    const prev = shown.current;
    const a = anchor.current;
    if (
      a &&
      a.x >= data.x &&
      a.x < data.x + data.size &&
      a.y >= data.y &&
      a.y < data.y + data.size
    ) {
      const [cx, cy] = tileCenter(a.x - data.x, a.y - data.y, data.size, rot);
      el.scrollLeft = cx - el.clientWidth / 2;
      el.scrollTop = cy - el.clientHeight / 2;
      anchor.current = null;
    } else if (prev && (prev.x !== data.x || prev.y !== data.y)) {
      // та же клетка мира до и после сдвига окна: прокрутка следует за ней при любом повороте
      const wx = prev.x + Math.floor(prev.size / 2);
      const wy = prev.y + Math.floor(prev.size / 2);
      const [ox, oy] = tileCenter(wx - prev.x, wy - prev.y, prev.size, rot);
      const [nx, ny] = tileCenter(wx - data.x, wy - data.y, data.size, rot);
      el.scrollLeft += nx - ox;
      el.scrollTop += ny - oy;
    }
    shown.current = { x: data.x, y: data.y, size: data.size };
  }, [data, rot]);

  // Бесконечный обзор: у края окна подгружаем новое окно вокруг центра видимой области
  const onScroll = useCallback(() => {
    const el = viewRef.current;
    if (!el || !data) return;
    const mid = tileAt(
      el.scrollLeft + el.clientWidth / 2,
      el.scrollTop + el.clientHeight / 2,
      data.size,
      rot,
    );
    const span = (el.clientWidth / TILE_W + el.clientHeight / TILE_H) / 2;
    setView((v) => {
      const nv = { x: data.x + mid.cx, y: data.y + mid.cy, span };
      return v &&
        Math.abs(v.x - nv.x) < 1 &&
        Math.abs(v.y - nv.y) < 1 &&
        Math.abs(v.span - span) < 1
        ? v
        : nv;
    });
    const margin = 260;
    const near =
      el.scrollLeft < margin ||
      el.scrollTop < margin ||
      el.scrollLeft + el.clientWidth > el.scrollWidth - margin ||
      el.scrollTop + el.clientHeight > el.scrollHeight - margin;
    if (!near) return;
    const c = tileAt(
      el.scrollLeft + el.clientWidth / 2,
      el.scrollTop + el.clientHeight / 2,
      data.size,
      rot,
    );
    const half = Math.floor(data.size / 2);
    const nx = clamp(data.x + c.cx - half, MAP_SIZE - data.size);
    const ny = clamp(data.y + c.cy - half, MAP_SIZE - data.size);
    setOrigin((cur) =>
      cur && (Math.abs(cur.x - nx) > 3 || Math.abs(cur.y - ny) > 3) ? { x: nx, y: ny } : cur,
    );
  }, [data, rot]);

  if (isPending) {
    return (
      <p role="status" className="pt-8 text-center font-display text-lg">
        {t('common.loading')}
      </p>
    );
  }
  if (isError || !castle) {
    return (
      <Panel title={t('nav.map')} className="mx-auto max-w-md text-center">
        <p className="pt-2">{t('errors.ERR_NETWORK')}</p>
        <Button className="mt-3" onClick={() => void refetch()}>
          {t('common.retry')}
        </Button>
      </Panel>
    );
  }

  const move = (dx: number, dy: number) => {
    const el = viewRef.current;
    if (el && typeof el.scrollBy === 'function')
      el.scrollBy({
        left: dx * el.clientWidth * 0.4,
        top: dy * el.clientHeight * 0.4,
        behavior: 'smooth',
      });
  };
  const showAt = (x: number, y: number) => {
    anchor.current = { x, y };
    const half = Math.floor(size / 2);
    setOrigin({ x: clamp(x - half, MAP_SIZE - size), y: clamp(y - half, MAP_SIZE - size) });
    setCursor({ x, y });
  };

  /** Прокручивает окно так, чтобы клетка была на виду. */
  const reveal = (x: number, y: number) => {
    const el = viewRef.current;
    if (!el || !data) return;
    const [px, py] = tileCenter(x - data.x, y - data.y, data.size, rot);
    const pad = 90;
    if (typeof el.scrollTo !== 'function') return;
    if (
      px < el.scrollLeft + pad ||
      px > el.scrollLeft + el.clientWidth - pad ||
      py < el.scrollTop + pad ||
      py > el.scrollTop + el.clientHeight - pad
    )
      el.scrollTo({
        left: px - el.clientWidth / 2,
        top: py - el.clientHeight / 2,
        behavior: 'smooth',
      });
  };

  /** Поворачивает обзор на четверть оборота вокруг центра видимой области. */
  const rotate = (dir: 1 | -1) => {
    const centre = view ? { x: Math.round(view.x), y: Math.round(view.y) } : (cursor ?? home);
    if (centre) anchor.current = { x: centre.x, y: centre.y };
    const next = ((rot + dir + 4) % 4) as Rot;
    setRot(next);
    try {
      localStorage.setItem(ROT_KEY, String(next));
    } catch {
      /* не критично */
    }
  };

  const onKey = (e: KeyboardEvent<HTMLDivElement>) => {
    if (!cursor || !data) return;
    const d: Record<string, [number, number]> = {
      ArrowLeft: [-1, 0],
      ArrowRight: [1, 0],
      ArrowUp: [0, -1],
      ArrowDown: [0, 1],
    };
    const raw = d[e.key];
    const step = raw ? worldDelta(raw[0], raw[1], rot) : undefined;
    if (e.key === 'q' || e.key === 'Q') {
      e.preventDefault();
      rotate(-1);
    } else if (e.key === 'e' || e.key === 'E') {
      e.preventDefault();
      rotate(1);
    } else if (step) {
      e.preventDefault();
      const nx = clamp(cursor.x + step[0], MAP_SIZE - 1);
      const ny = clamp(cursor.y + step[1], MAP_SIZE - 1);
      setCursor({ x: nx, y: ny });
      if (nx < data.x || nx >= data.x + data.size || ny < data.y || ny >= data.y + data.size)
        showAt(nx, ny);
      else reveal(nx, ny);
    } else if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      setSelected(cursor);
    }
  };

  const pick = (clientX: number, clientY: number, rect: DOMRect) => {
    if (!data) return;
    // холст масштабируется по ширине: переводим экранную точку в координаты рисунка и обратно в клетку
    const k = mapDims(data.size).width / rect.width;
    const hit = pickTile((clientX - rect.left) * k, (clientY - rect.top) * k, data.size, rot);
    if (!hit) return;
    const x = data.x + hit.cx;
    const y = data.y + hit.cy;
    setCursor({ x, y });
    setSelected({ x, y });
  };

  const selectedCell = cellAt(selected);
  const cursorCell = cellAt(cursor);

  // Карта на весь экран под верхней полосой; в портале, чтобы анимация страницы не сдвигала fixed-слой
  return createPortal(
    <div className="fixed inset-x-0 bottom-0 top-[var(--hdr,0px)] z-20 md:top-0">
      <h1 className="sr-only">{t('nav.map')}</h1>

      <div>
        <section aria-label={t('map.title')} className="absolute inset-0">
          <div className="glass absolute left-3 top-2 md:top-[calc(var(--hdr,4rem)+0.5rem)] z-10 flex max-w-[calc(100%-9rem)] flex-wrap items-center gap-1.5 p-1.5">
            <Button
              className="!min-h-[40px] !px-3"
              onClick={() => move(-1, 0)}
              aria-label={t('map.left')}
            >
              ←
            </Button>
            <Button
              className="!min-h-[40px] !px-3"
              onClick={() => move(0, -1)}
              aria-label={t('map.up')}
            >
              ↑
            </Button>
            <Button
              className="!min-h-[40px] !px-3"
              onClick={() => move(0, 1)}
              aria-label={t('map.down')}
            >
              ↓
            </Button>
            <Button
              className="!min-h-[40px] !px-3"
              onClick={() => move(1, 0)}
              aria-label={t('map.right')}
            >
              →
            </Button>
            <Button
              className="!min-h-[40px] !px-3"
              onClick={() => rotate(-1)}
              aria-label={t('map.rotateLeft')}
              title={t('map.rotateLeft')}
            >
              ⟲
            </Button>
            <Button
              className="!min-h-[40px] !px-3"
              onClick={() => rotate(1)}
              aria-label={t('map.rotateRight')}
              title={t('map.rotateRight')}
            >
              ⟳
            </Button>
            {home && (
              <Button
                variant="gold"
                className="!min-h-[40px]"
                onClick={() => showAt(home.x, home.y)}
              >
                {t('map.toCastle')}
              </Button>
            )}
            <Button
              className="!min-h-[40px]"
              onClick={() => {
                const next = size === LARGE ? SMALL : LARGE;
                setSize(next);
                if (cursor) {
                  anchor.current = { x: cursor.x, y: cursor.y };
                  const half = Math.floor(next / 2);
                  setOrigin({
                    x: clamp(cursor.x - half, MAP_SIZE - next),
                    y: clamp(cursor.y - half, MAP_SIZE - next),
                  });
                }
              }}
            >
              {size === LARGE ? t('map.zoomIn') : t('map.zoomOut')}
            </Button>
            <span className="ml-auto text-sm" aria-live="polite">
              {data
                ? `${data.x}–${data.x + data.size - 1}, ${data.y}–${data.y + data.size - 1}`
                : ''}
            </span>
          </div>

          {/* Карта рисуется на холсте; клавиатурный доступ — стрелками по клеткам, Enter открывает клетку */}
          <div
            role="application"
            tabIndex={0}
            aria-label={t('map.gridHelp')}
            onKeyDown={onKey}
            className="absolute inset-0 overflow-hidden outline-offset-[-4px] focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold"
            style={{ background: 'linear-gradient(#5fb4e8, #2f7fc0)' }}
          >
            {data ? (
              <div
                ref={viewRef}
                role="region"
                tabIndex={0}
                aria-label={t('map.viewport')}
                onScroll={onScroll}
                onPointerDown={(e: ReactPointerEvent<HTMLDivElement>) => {
                  if (e.pointerType !== 'mouse') return;
                  drag.current = {
                    x: e.clientX,
                    y: e.clientY,
                    left: e.currentTarget.scrollLeft,
                    top: e.currentTarget.scrollTop,
                  };
                }}
                onPointerMove={(e: ReactPointerEvent<HTMLDivElement>) => {
                  const d = drag.current;
                  if (!d || e.buttons !== 1) return;
                  e.currentTarget.scrollLeft = d.left - (e.clientX - d.x);
                  e.currentTarget.scrollTop = d.top - (e.clientY - d.y);
                }}
                onPointerUp={() => setTimeout(() => (drag.current = null), 0)}
                className="map-viewport h-full cursor-grab overflow-auto overscroll-contain active:cursor-grabbing"
              >
                <div
                  onClick={(e) => {
                    const d = drag.current;
                    // перетаскивание не считается щелчком
                    if (d && (Math.abs(e.clientX - d.x) > 5 || Math.abs(e.clientY - d.y) > 5))
                      return;
                    pick(e.clientX, e.clientY, e.currentTarget.getBoundingClientRect());
                  }}
                  className="relative"
                  style={{ width: mapDims(data.size).width, height: mapDims(data.size).height }}
                  data-testid="map-surface"
                >
                  <MapCanvas cells={data.cells} size={data.size} rot={rot} />
                  {cursor &&
                    cursor.x >= data.x &&
                    cursor.x < data.x + data.size &&
                    cursor.y >= data.y &&
                    cursor.y < data.y + data.size && (
                      <svg
                        aria-hidden="true"
                        viewBox={`0 0 ${mapDims(data.size).width} ${mapDims(data.size).height}`}
                        className="pointer-events-none absolute inset-0 h-full w-full"
                      >
                        <polygon
                          points={tilePoly(cursor.x - data.x, cursor.y - data.y, data.size, rot)
                            .map((p) => p.join(','))
                            .join(' ')}
                          fill="rgba(242,207,107,.22)"
                          stroke="#f2cf6b"
                          strokeWidth="3"
                          strokeLinejoin="round"
                        />
                      </svg>
                    )}
                </div>
              </div>
            ) : (
              <p role="status" className="p-8 text-center">
                {t('common.loading')}
              </p>
            )}
          </div>
          <p
            role="status"
            className={
              cursorCell
                ? 'glass absolute bottom-3 left-3 z-10 max-w-[55%] px-3 py-1.5 text-sm'
                : 'sr-only'
            }
          >
            {cursorCell ? `${cursor?.x}, ${cursor?.y}: ${cellTitle(t, cursorCell)}` : ''}
          </p>
          <MiniMap home={home} view={view} onJump={showAt} />
          <div className="absolute right-3 top-2 md:top-[calc(var(--hdr,4rem)+0.5rem)] z-20 flex gap-1.5">
            <Button
              variant="gold"
              className="!min-h-[40px] !px-3"
              aria-pressed={panel === 'find'}
              onClick={() => setPanel(panel === 'find' ? null : 'find')}
            >
              {t('map.find')}
            </Button>
            <Button
              variant="gold"
              className="!min-h-[40px] !px-3"
              aria-pressed={panel === 'marches'}
              onClick={() => setPanel(panel === 'marches' ? null : 'marches')}
            >
              {t('map.marches')} ({castle.marches.length})
            </Button>
          </div>
        </section>

        {panel === 'find' && (
          <div className="glass absolute right-3 top-[4.5rem] md:top-[calc(var(--hdr,4rem)+4.5rem)] z-20 flex max-h-[calc(100%-var(--hdr,4rem)-6rem)] w-[min(22rem,calc(100%-1.5rem))] flex-col gap-4 overflow-auto p-3">
            <div>
              <h2 className="font-display text-sm font-bold text-gold-light">{t('map.find')}</h2>
              <form
                className="flex items-end gap-2 pt-2"
                onSubmit={(e) => {
                  e.preventDefault();
                  const x = Number(goto.x);
                  const y = Number(goto.y);
                  if (
                    Number.isInteger(x) &&
                    Number.isInteger(y) &&
                    x >= 0 &&
                    y >= 0 &&
                    x < MAP_SIZE &&
                    y < MAP_SIZE
                  )
                    showAt(x, y);
                }}
              >
                {(['x', 'y'] as const).map((k) => (
                  <label key={k} className="flex flex-1 flex-col gap-1 text-sm">
                    <span className="font-display font-bold uppercase">{k}</span>
                    <input
                      inputMode="numeric"
                      value={goto[k]}
                      onChange={(e) =>
                        setGoto((g) => ({
                          ...g,
                          [k]: e.target.value.replace(/[^\d]/g, '').slice(0, 2),
                        }))
                      }
                      className="min-h-[40px] w-full min-w-0 rounded-lg border-2 border-wood-light bg-white/80 px-2 text-ink"
                    />
                  </label>
                ))}
                <Button type="submit" className="shrink-0 !min-h-[40px]">
                  {t('map.go')}
                </Button>
              </form>
              <label className="mt-3 flex flex-col gap-1 text-sm">
                <span className="font-display font-bold">{t('map.search')}</span>
                <input
                  value={q}
                  onChange={(e) => setQ(e.target.value.slice(0, 40))}
                  placeholder={t('map.searchHint')}
                  className="min-h-[40px] rounded-lg border-2 border-wood-light bg-white/80 px-3 text-ink"
                />
              </label>
              {q.trim().length >= 2 && search.data && (
                <ul className="mt-2 flex flex-col gap-1" aria-label={t('map.results')}>
                  {search.data.length === 0 && <li className="text-sm">{t('map.nothing')}</li>}
                  {search.data.map((r) => (
                    <li key={`${r.x},${r.y}`}>
                      <button
                        type="button"
                        className="min-h-[40px] w-full rounded-lg bg-black/25 px-3 text-left text-sm hover:bg-black/40"
                        onClick={() => showAt(r.x, r.y)}
                      >
                        {r.nickname ?? t('map.cellAt')} — {r.x}, {r.y}
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div>
              <h2 className="font-display text-sm font-bold text-gold-light">{t('map.legend')}</h2>
              <ul className="grid grid-cols-2 gap-1 pt-2 text-sm">
                <li>{t('map.legendCastle')}</li>
                <li>{t('map.legendCamp')}</li>
                <li>{t('map.legendNode')}</li>
                <li>{t('map.legendShield')}</li>
                <li>{t('map.legendRoad')}</li>
              </ul>
            </div>
          </div>
        )}
      </div>

      {panel === 'marches' && (
        <section
          aria-label={t('map.marches')}
          className="glass absolute right-3 top-[4.5rem] md:top-[calc(var(--hdr,4rem)+4.5rem)] z-20 flex max-h-[calc(100%-var(--hdr,4rem)-6rem)] w-[min(24rem,calc(100%-1.5rem))] flex-col gap-2 overflow-auto px-3 py-3"
        >
          <div className="flex items-center justify-between">
            <p className="font-display text-sm font-bold text-gold-light">{t('map.marches')}</p>
            <span className="text-sm">
              {t('map.marchSlots', { used: castle.marches.length, max: castle.marchesMax })}
            </span>
          </div>
          {castle.marches.length === 0 ? (
            <p className="text-sm text-parchment/90">{t('map.noMarches')}</p>
          ) : (
            <ul className="flex flex-col gap-2">
              {castle.marches.map((m) => (
                <MarchRow
                  key={m.id}
                  m={m}
                  onDone={() => {
                    void client.invalidateQueries({ queryKey: ['castle'] });
                    void client.invalidateQueries({ queryKey: ['map'] });
                  }}
                />
              ))}
            </ul>
          )}
        </section>
      )}

      {selectedCell && (
        <CellDialog cell={selectedCell} castle={castle} onClose={() => setSelected(null)} />
      )}
    </div>,
    document.body,
  );
}
