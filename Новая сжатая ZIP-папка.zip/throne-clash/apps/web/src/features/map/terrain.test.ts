import { describe, expect, it } from 'vitest';
import type { MapCellDto } from '@tc/shared';
import { decorOf, groundOf, markerOf } from './terrain';

const cell = (over: Partial<MapCellDto> = {}): MapCellDto => ({
  x: 5,
  y: 7,
  terrain: 'plain',
  kind: 'empty',
  level: 0,
  resource: null,
  castle: null,
  busyUntil: null,
  remaining: null,
  ...over,
});

describe('вид клеток карты', () => {
  it('детерминирован: одна и та же клетка всегда выглядит одинаково', () => {
    for (const terrain of ['plain', 'forest', 'mountain', 'water'] as const) {
      for (let i = 0; i < 200; i++) {
        const c = cell({ x: i % 20, y: Math.floor(i / 20), terrain });
        expect(groundOf(c)).toEqual(groundOf(c));
        expect(decorOf(c)).toEqual(decorOf(c));
        expect(groundOf(c).shade).toBeGreaterThanOrEqual(0);
        expect(groundOf(c).shade).toBeLessThan(1);
      }
    }
  });

  it('земля соответствует местности', () => {
    expect(groundOf(cell({ terrain: 'water' })).ground).toBe('water');
    expect(groundOf(cell({ terrain: 'mountain' })).ground).toBe('hills');
    expect(groundOf(cell({ terrain: 'forest' })).ground).toBe('forest');
    expect(groundOf(cell({ terrain: 'plain' })).ground).toBe('grass');
  });

  it('карта v2: пустыня — песок, болото, море, озеро и река — вода; дорога не украшается', () => {
    expect(groundOf(cell({ terrain: 'desert' })).ground).toBe('sand');
    expect(groundOf(cell({ terrain: 'swamp' })).ground).toBe('swamp');
    expect(groundOf(cell({ terrain: 'sea' })).ground).toBe('sea');
    expect(groundOf(cell({ terrain: 'lake' })).ground).toBe('water');
    expect(groundOf(cell({ terrain: 'river' })).ground).toBe('river');
    const decors = new Set<string | null>();
    for (let i = 0; i < 300; i++) {
      decors.add(decorOf(cell({ x: i, y: 7, terrain: 'desert' })));
      expect(['reed', null]).toContain(decorOf(cell({ x: i, y: 7, terrain: 'swamp' })));
      expect(decorOf(cell({ x: i, y: 7, terrain: 'sea' }))).toBeNull();
      expect(decorOf({ ...cell({ x: i, y: 7, terrain: 'plain' }), road: true })).toBeNull();
    }
    expect(decors.has('cactus')).toBe(true);
  });

  it('вода не украшается; в лесу деревья у каждой клетки, в горах — пики', () => {
    expect(decorOf(cell({ terrain: 'water' }))).toBeNull();
    for (let i = 0; i < 100; i++) {
      expect(['oak', 'pine']).toContain(decorOf(cell({ x: i, y: 3, terrain: 'forest' })));
      expect(decorOf(cell({ x: i, y: 3, terrain: 'mountain' }))).toBe('peak');
    }
    // на клетке с лагерем или точкой ландшафт не рисуется поверх маркера
    expect(decorOf(cell({ terrain: 'forest', kind: 'camp' }))).toBeNull();
  });

  it('маркеры: свой и чужой замок различаются, лагерь тускнеет после победы, точка — при истощении', () => {
    const mine = markerOf(cell({ castle: { nickname: 'A', isMe: true, shielded: false } }));
    const other = markerOf(cell({ castle: { nickname: 'B', isMe: false, shielded: true } }));
    expect(mine).toMatchObject({ type: 'castle', mine: true, shielded: false });
    expect(other).toMatchObject({ type: 'castle', mine: false, shielded: true });
    expect(markerOf(cell())).toBeNull();

    const camp = cell({ kind: 'camp', level: 3 });
    expect(markerOf(camp)).toMatchObject({ type: 'camp', tier: 0, dim: false });
    expect(markerOf({ ...camp, busyUntil: '2030-01-01T00:00:00.000Z' })).toMatchObject({
      dim: true,
    });
    expect(markerOf({ ...camp, level: 6 })).toMatchObject({ tier: 1 });
    expect(markerOf({ ...camp, level: 10 })).toMatchObject({ tier: 2 });

    const node = cell({ kind: 'resource', level: 2, resource: 'wood', remaining: 100 });
    expect(markerOf(node)).toMatchObject({ type: 'node', resource: 'wood', dim: false });
    expect(markerOf({ ...node, remaining: 0 })).toMatchObject({ dim: true });
  });
});
