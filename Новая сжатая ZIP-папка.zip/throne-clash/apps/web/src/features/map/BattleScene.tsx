import { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { parseUnitId, type UnitCounts, type UnitTier } from '@tc/shared';
import { BattleArena } from '../../art2/BattleArena';
import type { BattleSetup, Fighter } from '../../art2/battle';
import type { ChibiClass, Rarity } from '../../art2/chibi';

/** Сколько фигур показать для отряда: чем больше отряд, тем гуще строй. */
const figuresFor = (n: number): number => (n <= 0 ? 0 : n < 15 ? 1 : n < 150 ? 2 : 3);

const CLASS_OF_UNIT: Record<string, ChibiClass> = {
  infantry: 'knight',
  archer: 'archer',
  cavalry: 'king',
  siege: 'mage',
};
const rarityOf = (tier: UnitTier): Rarity =>
  tier >= 5 ? 'legendary' : tier === 4 ? 'epic' : tier === 3 ? 'rare' : 'common';

/** Отряды игрока → бойцы на поле: до трёх видов войск, гуще строй у больших отрядов. */
export function armyFighters(units: UnitCounts): Fighter[] {
  const stacks = Object.entries(units)
    .map(([id, n]) => ({ parsed: parseUnitId(id), n: n ?? 0, id }))
    .filter(
      (s): s is { parsed: NonNullable<typeof s.parsed>; n: number; id: string } =>
        s.parsed !== null && s.n > 0,
    )
    .sort((a, b) => b.n - a.n)
    .slice(0, 3);
  const out: Fighter[] = [];
  for (const s of stacks) {
    const { type, tier } = s.parsed;
    for (let i = 0; i < figuresFor(s.n); i++)
      out.push({
        cls: CLASS_OF_UNIT[type] ?? 'knight',
        rarity: rarityOf(tier),
        tier,
        seed: out.length + 1,
      });
  }
  return out;
}

const MONSTERS: Record<0 | 1 | 2, readonly ChibiClass[]> = {
  0: ['rogue', 'rogue', 'archer'],
  1: ['peasant', 'mage', 'rogue'],
  2: ['king', 'knight', 'mage', 'peasant'],
};

/** Защитники лагеря: разбойники → налётчики → орда, число фигур растёт с уровнем. */
export function campFighters(level: number): Fighter[] {
  const tier = level <= 4 ? 0 : level <= 8 ? 1 : 2;
  const count = Math.min(5, 2 + Math.floor(level / 4));
  const list = MONSTERS[tier];
  return Array.from({ length: count }, (_, i) => ({
    cls: list[i % list.length]!,
    rarity: 'common' as const,
    tier: tier + 1,
    seed: 40 + i,
  }));
}

/**
 * Живая схватка к отчёту: слева атакующие, справа защитники; ближний бой, стрелы и магия,
 * побеждённые падают, победители ликуют. Чисто украшение — все цифры остаются в таблицах ниже.
 */
export function BattleScene({
  attacker,
  defender,
  campLevel,
  attackerWon,
}: {
  attacker: UnitCounts;
  defender: UnitCounts | null;
  campLevel: number | null;
  attackerWon: boolean;
}) {
  const { t } = useTranslation();
  const victory = attackerWon ? t('report.sceneVictory') : t('report.sceneDefeat');
  const setup = useMemo<BattleSetup | null>(() => {
    const left = armyFighters(attacker).slice(0, 6);
    const right = (
      campLevel !== null ? campFighters(campLevel) : armyFighters(defender ?? {})
    ).slice(0, 6);
    if (left.length === 0 || right.length === 0) return null;
    return {
      left,
      right,
      winner: attackerWon ? 'left' : 'right',
      seed: left.length * 7 + right.length,
      victoryText: victory,
    };
  }, [attacker, defender, campLevel, attackerWon, victory]);
  if (!setup) return null;
  return (
    <div className="flex justify-center overflow-hidden rounded-xl border-2 border-black/50">
      <BattleArena setup={setup} width={640} label={t('report.sceneLabel')} />
    </div>
  );
}
