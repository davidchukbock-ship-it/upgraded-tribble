import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
import { Badge, Button, Panel } from '../../ui';
import { notificationApi } from './api';
import { describeNotification } from './notify';
import { dateLocale } from '../../lib/locales';

const when = (iso: string, lang: string): string =>
  new Date(iso).toLocaleString(dateLocale(lang), {
    day: '2-digit',
    month: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });

export function NotificationsPage() {
  const { t, i18n } = useTranslation();
  const client = useQueryClient();
  const [page, setPage] = useState(1);
  const q = useQuery({
    queryKey: ['notifications', page],
    queryFn: () => notificationApi.list(page),
  });
  const read = useMutation({
    mutationFn: (ids?: string[]) => notificationApi.read(ids),
    onSuccess: () => void client.invalidateQueries({ queryKey: ['notifications'] }),
  });

  if (q.isPending)
    return (
      <p role="status" className="pt-8 text-center font-display text-lg">
        {t('common.loading')}
      </p>
    );
  if (q.isError || !q.data)
    return (
      <Panel title={t('nav.notifications')} className="mx-auto max-w-md text-center">
        <p className="pt-2">{t('errors.ERR_NETWORK')}</p>
        <Button className="mt-3" onClick={() => void q.refetch()}>
          {t('common.retry')}
        </Button>
      </Panel>
    );
  const { items, total, unread, pageSize } = q.data;
  const pages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-4">
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="font-display text-2xl font-bold text-gold-light">
          {t('nav.notifications')}
        </h1>
        <span className="text-sm" role="status">
          {t('notif.summary', { total, unread })}
        </span>
        <Button
          className="ml-auto !min-h-[40px]"
          disabled={unread === 0 || read.isPending}
          onClick={() => read.mutate(undefined)}
        >
          {t('notif.markAll')}
        </Button>
      </div>
      {items.length === 0 ? (
        <Panel title={t('nav.notifications')}>
          <p className="pt-2">{t('notif.empty')}</p>
        </Panel>
      ) : (
        <ul className="flex flex-col gap-2">
          {items.map((n) => {
            const d = describeNotification(t, n);
            return (
              <li key={n.id}>
                <Link
                  to={d.href}
                  onClick={() => {
                    if (!n.read) read.mutate([n.id]);
                  }}
                  className="panel-wood frame-pixel flex flex-wrap items-center gap-x-3 gap-y-1 px-4 py-3 hover:brightness-110"
                >
                  <span className={n.read ? 'opacity-80' : 'font-bold'}>{d.text}</span>
                  {!n.read && <Badge tone="red">{t('report.new')}</Badge>}
                  <span className="ml-auto text-sm opacity-80">
                    {when(n.createdAt, i18n.language)}
                  </span>
                </Link>
              </li>
            );
          })}
        </ul>
      )}
      {pages > 1 && (
        <nav aria-label={t('report.pages')} className="flex items-center justify-center gap-3">
          <Button disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
            {t('report.prev')}
          </Button>
          <span className="text-sm">
            {page} / {pages}
          </span>
          <Button disabled={page >= pages} onClick={() => setPage((p) => p + 1)}>
            {t('report.next')}
          </Button>
        </nav>
      )}
    </div>
  );
}
