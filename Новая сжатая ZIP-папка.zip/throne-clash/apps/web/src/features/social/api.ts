import type {
  CastleDto,
  ChatMessageDto,
  GuildListDto,
  GuildRole,
  MyGuildDto,
  NotificationPageDto,
} from '@tc/shared';
import { apiFetch } from '../../lib/api';

const key = () => ({ 'Idempotency-Key': crypto.randomUUID() });

export const guildApi = {
  mine: () => apiFetch<MyGuildDto>('/api/guilds/mine'),
  list: (q: string, page: number) =>
    apiFetch<GuildListDto>(`/api/guilds?q=${encodeURIComponent(q)}&page=${page}&pageSize=10`),
  create: (name: string, description: string) =>
    apiFetch<MyGuildDto>('/api/guilds', {
      method: 'POST',
      body: { name, description },
      headers: key(),
    }),
  apply: (id: string) => apiFetch<void>(`/api/guilds/${id}/apply`, { method: 'POST' }),
  withdraw: (id: string) => apiFetch<void>(`/api/guilds/${id}/apply`, { method: 'DELETE' }),
  decide: (id: string, accept: boolean) =>
    apiFetch<void>(`/api/guilds/applications/${id}/${accept ? 'accept' : 'reject'}`, {
      method: 'POST',
    }),
  setRole: (userId: string, role: GuildRole) =>
    apiFetch<void>(`/api/guilds/members/${userId}/role`, { method: 'POST', body: { role } }),
  kick: (userId: string) => apiFetch<void>(`/api/guilds/members/${userId}`, { method: 'DELETE' }),
  leave: () => apiFetch<void>('/api/guilds/leave', { method: 'POST' }),
  donate: (amount: number) =>
    apiFetch<CastleDto>('/api/guilds/treasury/donate', {
      method: 'POST',
      body: { amount },
      headers: key(),
    }),
  help: (ownerId: string, taskId: string) =>
    apiFetch<{ seconds: number }>(`/api/guilds/help/${ownerId}/${taskId}`, { method: 'POST' }),
};

export const chatApi = {
  history: (channel: string) =>
    apiFetch<ChatMessageDto[]>(`/api/chat/${encodeURIComponent(channel)}/history`),
  send: (channel: string, text: string) =>
    apiFetch<ChatMessageDto>(`/api/chat/${encodeURIComponent(channel)}/messages`, {
      method: 'POST',
      body: { text },
    }),
  report: (messageId: string, reason: string) =>
    apiFetch<void>('/api/chat/report', { method: 'POST', body: { messageId, reason } }),
};

export const notificationApi = {
  list: (page: number) =>
    apiFetch<NotificationPageDto>(`/api/notifications?page=${page}&pageSize=20`),
  read: (ids?: string[]) =>
    apiFetch<{ marked: number }>('/api/notifications/read', {
      method: 'POST',
      body: ids ? { ids } : {},
    }),
};
