import type { TFunction } from 'i18next';
import { parseUnitId, type NotificationDto } from '@tc/shared';

/** Текст и адрес перехода для уведомления. */
export function describeNotification(
  t: TFunction,
  n: Pick<NotificationDto, 'kind' | 'payload'>,
): { text: string; href: string } {
  const p = n.payload;
  const s = (k: string): string => String(p[k] ?? '');
  switch (n.kind) {
    case 'build.done':
      return {
        text: t('notif.build.done', {
          building: t(`building.${s('building')}`),
          level: s('level'),
        }),
        href: '/castle',
      };
    case 'train.done': {
      const u = parseUnitId(s('unit'));
      return {
        text: t('notif.train.done', {
          unit: u ? `${t(`unit.${u.type}`)} T${u.tier}` : s('unit'),
          count: s('count'),
        }),
        href: '/army',
      };
    }
    case 'research.done':
      return {
        text: t('notif.research.done', { tech: t(`tech.${s('tech')}`), level: s('level') }),
        href: '/academy',
      };
    case 'march.returned':
      return {
        text: t('notif.march.returned', {
          march: t(`map.action.${s('march')}`),
          x: s('x'),
          y: s('y'),
        }),
        href: p['reportId'] ? `/reports/${s('reportId')}` : '/map',
      };
    case 'march.attacked':
      return {
        text: t(p['won'] ? 'notif.march.attackedWon' : 'notif.march.attackedLost', {
          attacker: s('attacker'),
        }),
        href: p['reportId'] ? `/reports/${s('reportId')}` : '/reports',
      };
    case 'guild.application':
      return {
        text: t('notif.guild.application', { nickname: s('nickname'), guild: s('guild') }),
        href: '/guild',
      };
    case 'guild.accepted':
      return { text: t('notif.guild.accepted', { guild: s('guild') }), href: '/guild' };
    case 'guild.kicked':
      return { text: t('notif.guild.kicked', { guild: s('guild') }), href: '/guild' };
    case 'guild.help':
      return {
        text: t('notif.guild.help', {
          helper: s('helper'),
          building: t(`building.${s('building')}`),
          seconds: s('seconds'),
        }),
        href: '/castle',
      };
    case 'season.reward':
      return { text: t('notif.season.reward', { seasonId: s('seasonId') }), href: '/leagues' };
    case 'chat.dm':
      return {
        text: t('notif.chat.dm', { from: s('from'), text: s('text') }),
        href: p['fromId'] ? `/chat?dm=${s('fromId')}` : '/chat',
      };
  }
}
