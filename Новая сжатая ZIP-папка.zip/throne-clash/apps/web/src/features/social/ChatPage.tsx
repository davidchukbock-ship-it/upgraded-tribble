import { useQuery } from '@tanstack/react-query';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useSearchParams } from 'react-router-dom';
import { useRealtime } from '../../store/realtime';
import { Panel, Tabs } from '../../ui';
import { guildApi } from './api';
import { ChatPanel } from './ChatPanel';

export function ChatPage() {
  const { t } = useTranslation();
  const [params, setParams] = useSearchParams();
  const peers = useRealtime((s) => s.peers);
  const online = useRealtime((s) => s.online);
  const status = useRealtime((s) => s.status);
  const dm = params.get('dm');
  const [tab, setTab] = useState(dm ? `dm:${dm}` : 'world');
  const mine = useQuery({ queryKey: ['guild'], queryFn: guildApi.mine, retry: false });

  // Ссылка из уведомления (`?dm=<id>`) открывает нужный личный чат
  useEffect(() => {
    if (dm) setTab(`dm:${dm}`);
  }, [dm]);

  const openDm = (userId: string, nickname: string) => {
    useRealtime.getState().addPeer(userId, nickname);
    setTab(`dm:${userId}`);
    setParams({ dm: userId });
  };
  const peerIds = new Set(Object.keys(peers));
  if (dm) peerIds.add(dm);

  const inGuild = mine.data?.guild !== undefined && mine.data.guild !== null;
  const items = [
    {
      id: 'world',
      label: t('chat.world'),
      content: <ChatPanel channel="world" label={t('chat.world')} onOpenDm={openDm} />,
    },
    {
      id: 'guild',
      label: t('chat.guild'),
      content: inGuild ? (
        <ChatPanel channel="guild" label={t('chat.guild')} onOpenDm={openDm} />
      ) : (
        <p className="pt-2 text-sm">{t('chat.noGuild')}</p>
      ),
    },
    ...[...peerIds].map((id) => ({
      id: `dm:${id}`,
      label: peers[id] ?? t('chat.player'),
      content: <ChatPanel channel={`dm:${id}`} label={peers[id] ?? t('chat.player')} />,
    })),
  ];

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-4">
      <h1 className="font-display text-2xl font-bold text-gold-light">{t('nav.chat')}</h1>
      <p className="text-sm" role="status">
        {status === 'open' ? t('chat.online', { count: online }) : t('chat.offline')}
      </p>
      <Panel title={t('nav.chat')}>
        <Tabs items={items} value={tab} onChange={setTab} />
      </Panel>
    </div>
  );
}
