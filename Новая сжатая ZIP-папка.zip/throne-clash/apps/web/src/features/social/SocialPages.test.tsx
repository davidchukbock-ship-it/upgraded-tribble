import { act, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import type {
  ChatMessageDto,
  GuildDto,
  MyGuildDto,
  NotificationDto,
  NotificationPageDto,
} from '@tc/shared';
import { initI18n } from '../../lib/i18n';
import { useRealtime } from '../../store/realtime';
import { useToasts } from '../../store/toast';
import { apiError, installFakeApi, json, makeCastle } from '../../test-utils/fake-api';
import { asWebSocket, FakeSocket } from '../../test-utils/fake-socket';
import { renderApp, resetAuth, signIn } from '../../test-utils/render';
import { describeNotification } from './notify';
import { setRealtimeEnabled } from './useRealtimeConnection';

beforeAll(async () => {
  await initI18n('ru');
});
beforeEach(() => {
  signIn(); // пользователь u1
  useToasts.setState({ items: [] });
  useRealtime.getState().reset();
  FakeSocket.reset();
});
afterEach(() => {
  resetAuth();
  vi.unstubAllGlobals();
  setRealtimeEnabled(false);
});

const guild = (over: Partial<GuildDto> = {}): GuildDto => ({
  id: '11111111-1111-4111-8111-111111111111',
  name: 'Волки Севера',
  description: 'Мы сильны',
  level: 2,
  members: 2,
  capacity: 24,
  leaderName: 'Артур',
  treasury: 60_000,
  myRole: 'leader',
  memberList: [
    { userId: 'u1', nickname: 'Артур', role: 'leader', joinedAt: '2026-01-01T00:00:00.000Z' },
    { userId: 'u2', nickname: 'Борис', role: 'member', joinedAt: '2026-01-02T00:00:00.000Z' },
  ],
  applications: [],
  helpRequests: [],
  ...over,
});
const mine = (g: GuildDto | null, applications: MyGuildDto['applications'] = []): MyGuildDto => ({
  guild: g,
  applications,
});

const withCastle5 = () =>
  makeCastle({
    buildings: makeCastle().buildings.map((b) => (b.key === 'castle' ? { ...b, level: 5 } : b)),
  });

const list = (items: object[] = [], total = items.length) => ({
  items,
  page: 1,
  pageSize: 10,
  total,
});
const g1 = {
  id: '22222222-2222-4222-8222-222222222222',
  name: 'Дозор',
  description: '',
  level: 1,
  members: 3,
  capacity: 22,
  leaderName: 'Кая',
};

describe('братство: нет братства', () => {
  it('гостю создание закрыто с объяснением', async () => {
    signIn({
      user: {
        id: 'u1',
        nickname: 'Гость',
        role: 'PLAYER',
        isGuest: true,
        email: null,
        language: 'ru',
        crest: 'lion',
        createdAt: '2026-01-01T00:00:00.000Z',
      },
    });
    installFakeApi({
      'GET /api/guilds/mine': () => json(200, mine(null)),
      'GET /api/guilds?q=&page=1&pageSize=10': () => json(200, list()),
    });
    renderApp('/guild');
    expect(
      await screen.findByText('Гостям братства недоступны: привяжите email в профиле'),
    ).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Создать' })).toBeDisabled();
  });

  it('Замок ниже 5 → причина; с Замком 5, золотом и названием создание отправляет POST', async () => {
    let castle = makeCastle();
    const { calls } = installFakeApi({
      'GET /api/castle': () => json(200, castle),
      'GET /api/guilds/mine': () => json(200, mine(null)),
      'GET /api/guilds?q=&page=1&pageSize=10': () => json(200, list([g1])),
      'POST /api/guilds': () => json(200, mine(guild())),
    });
    const view = renderApp('/guild');
    await userEvent.type((await screen.findAllByLabelText('Название'))[0]!, 'Волки Севера');
    expect(await screen.findByText('Нужен Замок 5 уровня')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Создать' })).toBeDisabled();
    view.unmount();

    castle = withCastle5();
    renderApp('/guild');
    const name = (await screen.findAllByLabelText('Название'))[0]!;
    expect(screen.getByRole('button', { name: 'Создать' })).toBeDisabled();
    expect(await screen.findByText('Название — от 3 символов')).toBeInTheDocument();
    await userEvent.type(name, 'Волки Севера');
    const btn = screen.getByRole('button', { name: 'Создать' });
    await waitFor(() => expect(btn).toBeEnabled());
    await userEvent.click(btn);
    await waitFor(() => expect(calls.filter((c) => c.method === 'POST')).toHaveLength(1));
    const post = calls.find((c) => c.method === 'POST')!;
    expect(post.body).toEqual({ name: 'Волки Севера', description: '' });
    expect(post.headers['Idempotency-Key']).toMatch(/^[0-9a-f-]{36}$/);
  });

  it('список братств: заявка отправляется; уже поданные помечены; полное братство недоступно', async () => {
    const full = { ...g1, id: '33333333-3333-4333-8333-333333333333', name: 'Полные', members: 22 };
    const { calls } = installFakeApi({
      'GET /api/guilds/mine': () =>
        json(200, mine(null, [{ guildId: full.id, guildName: 'Полные' }])),
      'GET /api/guilds?q=&page=1&pageSize=10': () => json(200, list([g1, full])),
      [`POST /api/guilds/${g1.id}/apply`]: () => json(204, null),
    });
    renderApp('/guild');
    const apply = await screen.findByRole('button', { name: 'Подать заявку: Дозор' });
    expect(screen.getByText('Заявка подана')).toBeInTheDocument();
    await userEvent.click(apply);
    await waitFor(() =>
      expect(calls.some((c) => c.method === 'POST' && c.path.endsWith('/apply'))).toBe(true),
    );
  });

  it('поиск подставляет запрос; свои заявки можно отозвать', async () => {
    const gid = g1.id;
    const { calls } = installFakeApi({
      'GET /api/guilds/mine': () => json(200, mine(null, [{ guildId: gid, guildName: 'Дозор' }])),
      'GET /api/guilds?q=&page=1&pageSize=10': () => json(200, list([g1])),
      [`GET /api/guilds?q=${encodeURIComponent('кая')}&page=1&pageSize=10`]: () =>
        json(200, list([])),
      [`DELETE /api/guilds/${gid}/apply`]: () => json(204, null),
    });
    renderApp('/guild');
    await userEvent.click(await screen.findByRole('button', { name: 'Отозвать: Дозор' }));
    await waitFor(() => expect(calls.some((c) => c.method === 'DELETE')).toBe(true));
    await userEvent.type(screen.getAllByLabelText('Название')[1]!, 'кая');
    expect(await screen.findByText('Братства не найдены')).toBeInTheDocument();
  });

  it('ошибка сервера показывается сообщением', async () => {
    installFakeApi({
      'GET /api/castle': () => json(200, withCastle5()),
      'GET /api/guilds/mine': () => json(200, mine(null)),
      'GET /api/guilds?q=&page=1&pageSize=10': () => json(200, list()),
      'POST /api/guilds': () => apiError(409, 'ERR_CONFLICT'),
    });
    renderApp('/guild');
    await userEvent.type((await screen.findAllByLabelText('Название'))[0]!, 'Волки Севера');
    const btn = screen.getByRole('button', { name: 'Создать' });
    await waitFor(() => expect(btn).toBeEnabled());
    await userEvent.click(btn);
    await waitFor(() =>
      expect(useToasts.getState().items.map((i) => i.message)).toContain('Конфликт данных'),
    );
  });
});

describe('братство: состав', () => {
  it('глава видит роли и управляет участниками; исключение требует подтверждения', async () => {
    const { calls } = installFakeApi({
      'GET /api/guilds/mine': () => json(200, mine(guild())),
      'POST /api/guilds/members/u2/role': () => json(204, null),
      'DELETE /api/guilds/members/u2': () => json(204, null),
    });
    renderApp('/guild');
    expect(
      await screen.findByRole('heading', { name: 'Волки Севера', level: 1 }),
    ).toBeInTheDocument();
    expect(screen.getByText('Уровень 2 · 2/24 · глава Артур')).toBeInTheDocument();
    const members = screen.getByRole('list', { name: 'Состав' });
    expect(within(members).getAllByText('Глава').length).toBeGreaterThan(0);

    await userEvent.click(screen.getByRole('button', { name: 'В офицеры: Борис' }));
    await waitFor(() =>
      expect(calls.find((c) => c.method === 'POST')?.body).toEqual({ role: 'officer' }),
    );

    await userEvent.click(screen.getByRole('button', { name: 'Исключить: Борис' }));
    const dlg = await screen.findByRole('alertdialog');
    expect(within(dlg).getByText('Борис покинет братство.')).toBeInTheDocument();
    await userEvent.click(within(dlg).getByRole('button', { name: 'Отмена' }));
    expect(calls.some((c) => c.method === 'DELETE')).toBe(false);
    await userEvent.click(screen.getByRole('button', { name: 'Исключить: Борис' }));
    await userEvent.click(
      within(await screen.findByRole('alertdialog')).getByRole('button', { name: 'Исключить' }),
    );
    await waitFor(() => expect(calls.some((c) => c.method === 'DELETE')).toBe(true));
  });

  it('участник не видит управления и вкладки заявок', async () => {
    installFakeApi({ 'GET /api/guilds/mine': () => json(200, mine(guild({ myRole: 'member' }))) });
    renderApp('/guild');
    await screen.findByRole('heading', { name: 'Волки Севера', level: 1 });
    expect(screen.queryByRole('button', { name: /Исключить/ })).toBeNull();
    expect(screen.queryByRole('tab', { name: /Заявки/ })).toBeNull();
  });

  it('заявки: принять и отклонить', async () => {
    const apps = [
      { id: 'a1', userId: 'u3', nickname: 'Вера', createdAt: '2026-01-03T00:00:00.000Z' },
    ];
    const { calls } = installFakeApi({
      'GET /api/guilds/mine': () => json(200, mine(guild({ applications: apps }))),
      'POST /api/guilds/applications/a1/accept': () => json(204, null),
      'POST /api/guilds/applications/a1/reject': () => json(204, null),
    });
    renderApp('/guild');
    await userEvent.click(await screen.findByRole('tab', { name: /Заявки \(1\)/ }));
    await userEvent.click(screen.getByRole('button', { name: 'Принять: Вера' }));
    await waitFor(() => expect(calls.some((c) => c.path.endsWith('/accept'))).toBe(true));
    await userEvent.click(screen.getByRole('button', { name: 'Отклонить: Вера' }));
    await waitFor(() => expect(calls.some((c) => c.path.endsWith('/reject'))).toBe(true));
  });

  it('помощь с постройкой: кнопка работает один раз на стройку', async () => {
    const req = {
      userId: 'u2',
      nickname: 'Борис',
      taskId: '44444444-4444-4444-8444-444444444444',
      building: 'barracks' as const,
      toLevel: 2,
      finishesAt: '2030-01-01T00:00:00.000Z',
      helps: 1,
      maxHelps: 10,
      helpSeconds: 36,
      canHelp: true,
    };
    const { calls } = installFakeApi({
      'GET /api/guilds/mine': () =>
        json(
          200,
          mine(
            guild({
              helpRequests: [
                req,
                { ...req, taskId: '55555555-5555-4555-8555-555555555555', canHelp: false },
              ],
            }),
          ),
        ),
      [`POST /api/guilds/help/u2/${req.taskId}`]: () => json(200, { seconds: 36 }),
    });
    renderApp('/guild');
    await userEvent.click(await screen.findByRole('tab', { name: 'Помощь' }));
    expect(screen.getAllByText(/Помогли 1 из 10/)).toHaveLength(2);
    const btns = screen.getAllByRole('button', { name: 'Помочь: Борис' });
    expect(btns[0]).toBeEnabled();
    expect(btns[1]).toBeDisabled();
    await userEvent.click(btns[0]!);
    await waitFor(() => expect(calls.some((c) => c.path.includes('/guilds/help/'))).toBe(true));
    expect(useToasts.getState().items[0]?.message).toContain('36');
  });

  it('казна: взнос ограничен золотом и минимумом; уровень и прогресс показаны', async () => {
    const { calls } = installFakeApi({
      'GET /api/castle': () =>
        json(200, makeCastle({ resources: { gold: 1000, wood: 0, stone: 0, food: 0 } })),
      'GET /api/guilds/mine': () => json(200, mine(guild())),
      'POST /api/guilds/treasury/donate': () => json(200, makeCastle()),
    });
    renderApp('/guild');
    await userEvent.click(await screen.findByRole('tab', { name: 'Казна' }));
    expect(screen.getByText('60 000')).toBeInTheDocument();
    const btn = screen.getByRole('button', { name: 'Внести' });
    expect(btn).toBeDisabled();
    await userEvent.type(screen.getByLabelText('Сумма золота'), '5000');
    expect(btn).toBeDisabled(); // золота 1000
    await userEvent.clear(screen.getByLabelText('Сумма золота'));
    await userEvent.type(screen.getByLabelText('Сумма золота'), '500');
    expect(btn).toBeEnabled();
    await userEvent.click(btn);
    await waitFor(() =>
      expect(calls.find((c) => c.method === 'POST')?.body).toEqual({ amount: 500 }),
    );
  });

  it('выход: глава с соратниками получает предупреждение; подтверждение шлёт POST', async () => {
    const { calls } = installFakeApi({
      'GET /api/guilds/mine': () => json(200, mine(guild())),
      'POST /api/guilds/leave': () => json(204, null),
    });
    renderApp('/guild');
    await userEvent.click(await screen.findByRole('button', { name: 'Выйти' }));
    const dlg = await screen.findByRole('alertdialog');
    expect(
      within(dlg).getByText('Вы глава: сначала передайте главенство другому участнику.'),
    ).toBeInTheDocument();
    await userEvent.click(within(dlg).getByRole('button', { name: 'Выйти' }));
    await waitFor(() => expect(calls.some((c) => c.path === '/api/guilds/leave')).toBe(true));
  });
});

const msg = (over: Partial<ChatMessageDto> = {}): ChatMessageDto => ({
  id: '99999999-9999-4999-8999-999999999991',
  channel: 'world',
  userId: 'u2',
  nickname: 'Борис',
  text: 'привет всем',
  createdAt: '2026-01-01T10:00:00.000Z',
  ...over,
});

describe('чат', () => {
  it('история подгружается; отправка идёт запасным путём HTTP, когда WebSocket выключен', async () => {
    const { calls } = installFakeApi({
      'GET /api/guilds/mine': () => json(200, mine(null)),
      'GET /api/chat/world/history': () => json(200, [msg()]),
      'POST /api/chat/world/messages': () =>
        json(
          200,
          msg({
            id: '99999999-9999-4999-8999-999999999992',
            userId: 'u1',
            nickname: 'Артур',
            text: 'ответ',
          }),
        ),
    });
    renderApp('/chat');
    const log = await screen.findByRole('log', { name: 'Мировой' });
    expect(await within(log).findByText('привет всем')).toBeInTheDocument();
    await userEvent.type(screen.getByPlaceholderText('Сообщение…'), 'ответ');
    await userEvent.click(screen.getByRole('button', { name: 'Отправить' }));
    expect(await within(log).findByText('ответ')).toBeInTheDocument();
    expect(calls.find((c) => c.method === 'POST')?.body).toEqual({ text: 'ответ' });
    expect(screen.getByPlaceholderText('Сообщение…')).toHaveValue('');
  });

  it('с открытым WebSocket сообщение уходит по сокету, а входящие появляются сразу', async () => {
    setRealtimeEnabled(true, asWebSocket);
    const { calls } = installFakeApi({
      'GET /api/guilds/mine': () => json(200, mine(null)),
      'GET /api/chat/world/history': () => json(200, []),
    });
    renderApp('/chat');
    await waitFor(() => expect(FakeSocket.instances).toHaveLength(1));
    const ws = FakeSocket.last;
    act(() => ws.open());
    expect(ws.sent[0]).toMatchObject({ type: 'auth', token: 'access-1' });
    act(() => ws.receive({ type: 'ready', userId: 'u1', online: 5 }));
    expect(await screen.findByText('Сейчас в игре: 5')).toBeInTheDocument();

    await userEvent.type(screen.getByPlaceholderText('Сообщение…'), 'по сокету');
    await userEvent.click(screen.getByRole('button', { name: 'Отправить' }));
    expect(ws.sent.at(-1)).toEqual({ type: 'chat.send', channel: 'world', text: 'по сокету' });
    expect(calls.filter((c) => c.method === 'POST')).toHaveLength(0);

    act(() => ws.receive({ type: 'chat.message', message: msg({ text: 'входящее' }) }));
    expect(await screen.findByText('входящее')).toBeInTheDocument();
    act(() => ws.receive({ type: 'error', code: 'ERR_RATE_LIMITED', retryAfterSeconds: 7 }));
    await waitFor(() =>
      expect(useToasts.getState().items.map((i) => i.message)).toContain(
        'Слишком много попыток. Подождите 7 с',
      ),
    );
  });

  it('клик по нику открывает личный чат; у него своя лента', async () => {
    const dmId = '77777777-7777-4777-8777-777777777777';
    installFakeApi({
      'GET /api/guilds/mine': () => json(200, mine(null)),
      'GET /api/chat/world/history': () => json(200, [msg({ userId: dmId })]),
      [`GET /api/chat/${encodeURIComponent(`dm:${dmId}`)}/history`]: () => json(200, []),
    });
    renderApp('/chat');
    await userEvent.click(await screen.findByRole('button', { name: 'Написать: Борис' }));
    expect(await screen.findByRole('tab', { name: 'Борис', selected: true })).toBeInTheDocument();
    expect(await screen.findByRole('log', { name: 'Борис' })).toBeInTheDocument();
  });

  it('жалоба: диалог с причиной шлёт POST /chat/report', async () => {
    const m = msg();
    const { calls } = installFakeApi({
      'GET /api/guilds/mine': () => json(200, mine(null)),
      'GET /api/chat/world/history': () => json(200, [m]),
      'POST /api/chat/report': () => json(204, null),
    });
    renderApp('/chat');
    await userEvent.click(
      await screen.findByRole('button', { name: 'Пожаловаться на сообщение игрока Борис' }),
    );
    const dlg = await screen.findByRole('dialog');
    const send = within(dlg).getByRole('button', { name: 'Пожаловаться' });
    expect(send).toBeDisabled();
    await userEvent.type(within(dlg).getByLabelText('Причина'), 'спам');
    await userEvent.click(send);
    await waitFor(() =>
      expect(calls.find((c) => c.path === '/api/chat/report')?.body).toEqual({
        messageId: m.id,
        reason: 'спам',
      }),
    );
    expect(useToasts.getState().items[0]?.message).toBe('Жалоба отправлена');
  });

  it('чат братства без братства объясняет, что делать; со ссылкой ?dm= открывается личный чат', async () => {
    const dmId = '88888888-8888-4888-8888-888888888888';
    installFakeApi({
      'GET /api/guilds/mine': () => json(200, mine(null)),
      'GET /api/chat/world/history': () => json(200, []),
      [`GET /api/chat/${encodeURIComponent(`dm:${dmId}`)}/history`]: () => json(200, []),
    });
    renderApp(`/chat?dm=${dmId}`);
    expect(await screen.findByRole('tab', { name: 'Игрок', selected: true })).toBeInTheDocument();
    await userEvent.click(screen.getByRole('tab', { name: 'Братство' }));
    expect(
      await screen.findByText('Чат братства доступен после вступления в братство.'),
    ).toBeInTheDocument();
  });
});

const note = (over: Partial<NotificationDto> = {}): NotificationDto => ({
  id: '00000000-0000-4000-8000-000000000001',
  kind: 'build.done',
  payload: { building: 'forge', level: 2 },
  read: false,
  createdAt: '2026-01-01T10:00:00.000Z',
  ...over,
});
const notePage = (
  items: NotificationDto[],
  unread = items.filter((i) => !i.read).length,
  total = items.length,
): NotificationPageDto => ({
  items,
  page: 1,
  pageSize: 20,
  total,
  unread,
});

describe('уведомления', () => {
  it('текст по видам: здание, отряд, исследование, поход, нападение, братство, личное', () => {
    const t = ((k: string, o?: Record<string, unknown>) =>
      `${k}|${JSON.stringify(o ?? {})}`) as never;
    const kinds: Array<[NotificationDto['kind'], NotificationDto['payload'], string]> = [
      ['build.done', { building: 'forge', level: 3 }, '/castle'],
      ['train.done', { unit: 'infantry_2', count: 5 }, '/army'],
      ['research.done', { tech: 'farming', level: 1 }, '/academy'],
      ['march.returned', { march: 'gather', x: 1, y: 2, reportId: 'r1' }, '/reports/r1'],
      ['march.attacked', { attacker: 'X', won: true, reportId: 'r2' }, '/reports/r2'],
      ['guild.application', { nickname: 'A', guild: 'G' }, '/guild'],
      ['guild.accepted', { guild: 'G' }, '/guild'],
      ['guild.kicked', { guild: 'G' }, '/guild'],
      ['guild.help', { helper: 'H', building: 'farm', seconds: 30 }, '/castle'],
      ['chat.dm', { from: 'F', fromId: 'u9', text: 'hi' }, '/chat?dm=u9'],
    ];
    for (const [kind, payload, href] of kinds) {
      const d = describeNotification(t, { kind, payload });
      expect(d.href).toBe(href);
      expect(d.text).toContain(`notif.${kind}`.replace('march.attacked', 'march.attackedWon'));
    }
    expect(
      describeNotification(t, { kind: 'march.attacked', payload: { attacker: 'X', won: false } })
        .text,
    ).toContain('attackedLost');
    expect(
      describeNotification(t, { kind: 'march.returned', payload: { march: 'scout', x: 1, y: 1 } })
        .href,
    ).toBe('/map');
  });

  it('колокольчик показывает число непрочитанных', async () => {
    installFakeApi({
      'GET /api/notifications?page=1&pageSize=20': () =>
        json(200, notePage([note(), note({ id: '00000000-0000-4000-8000-000000000002' })])),
      'GET /api/guilds/mine': () => json(200, mine(null)),
    });
    renderApp('/guild');
    expect(
      await screen.findByRole('link', { name: 'Уведомления, непрочитанных: 2' }),
    ).toBeInTheDocument();
  });

  it('лента: пустая, с текстами, «прочитать все» и клик по элементу помечает его', async () => {
    const items = [
      note(),
      note({
        id: '00000000-0000-4000-8000-000000000002',
        kind: 'guild.accepted',
        payload: { guild: 'Дозор' },
      }),
    ];
    const { calls } = installFakeApi({
      'GET /api/notifications?page=1&pageSize=20': () => json(200, notePage(items)),
      'POST /api/notifications/read': () => json(200, { marked: 1 }),
      'GET /api/castle': () => json(200, makeCastle()),
    });
    renderApp('/notifications');
    expect(await screen.findByText('Построено: Кузница, уровень 2')).toBeInTheDocument();
    expect(screen.getByText('Вас приняли в братство «Дозор»')).toBeInTheDocument();
    expect(screen.getByText('Всего: 2, новых: 2')).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: 'Прочитать все' }));
    await waitFor(() =>
      expect(calls.find((c) => c.path === '/api/notifications/read')?.body).toEqual({}),
    );
  });

  it('пустая лента', async () => {
    installFakeApi({ 'GET /api/notifications?page=1&pageSize=20': () => json(200, notePage([])) });
    renderApp('/notifications');
    expect(await screen.findByText('Пока ничего нового.')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Прочитать все' })).toBeDisabled();
  });

  it('уведомление по WebSocket показывает всплывающее сообщение и обновляет счётчик', async () => {
    setRealtimeEnabled(true, asWebSocket);
    let unread = 0;
    installFakeApi({
      'GET /api/notifications?page=1&pageSize=20': () =>
        json(200, notePage(unread ? [note()] : [], unread)),
      'GET /api/guilds/mine': () => json(200, mine(null)),
    });
    renderApp('/guild');
    await waitFor(() => expect(FakeSocket.instances).toHaveLength(1));
    act(() => FakeSocket.last.open());
    act(() => FakeSocket.last.receive({ type: 'ready', userId: 'u1', online: 1 }));
    unread = 1;
    act(() => FakeSocket.last.receive({ type: 'notification', notification: note() }));
    await waitFor(() =>
      expect(useToasts.getState().items.map((i) => i.message)).toContain(
        'Построено: Кузница, уровень 2',
      ),
    );
    expect(
      await screen.findByRole('link', { name: 'Уведомления, непрочитанных: 1' }),
    ).toBeInTheDocument();
  });
});
