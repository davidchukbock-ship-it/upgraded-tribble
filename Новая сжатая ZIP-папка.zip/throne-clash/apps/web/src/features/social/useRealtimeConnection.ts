import { useQueryClient } from '@tanstack/react-query';
import { useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { isBuildKind, RealtimeClient } from '../../lib/realtime';
import { useAuth } from '../../store/auth';
import { useRealtime } from '../../store/realtime';
import { useToasts } from '../../store/toast';
import { describeNotification } from './notify';

let active: RealtimeClient | null = null;
// В тестах соединение по умолчанию выключено (нет сервера); тест включает его и подставляет поддельный сокет
let enabled = import.meta.env.MODE !== 'test';
let socketImpl: typeof WebSocket | undefined;

export function setRealtimeEnabled(on: boolean, impl?: typeof WebSocket): void {
  enabled = on;
  socketImpl = impl;
}

/** Отправка в чат по WebSocket; false — соединения нет, вызывающий должен использовать HTTP. */
export function sendViaSocket(channel: string, text: string): boolean {
  return active?.send(channel, text) ?? false;
}

function wsUrl(): string {
  const base: string = import.meta.env.VITE_API_URL ?? '';
  const origin = base || window.location.origin;
  return `${origin.replace(/^http/, 'ws')}/ws`;
}

/**
 * Держит WebSocket, пока игрок вошёл: сообщения чата → хранилище, уведомления → всплывающая подсказка
 * и обновление данных экранов (замок, отчёты, братство).
 */
export function useRealtimeConnection(): void {
  const authed = useAuth((s) => s.status === 'authenticated');
  const token = useAuth((s) => s.accessToken);
  const { t } = useTranslation();
  const client = useQueryClient();
  const tRef = useRef(t);
  tRef.current = t;

  useEffect(() => {
    if (!authed || !enabled) return;
    const rt = useRealtime.getState();
    rt.setStatus('connecting');
    const c = new RealtimeClient(
      { url: wsUrl(), ...(socketImpl ? { WebSocketImpl: socketImpl } : {}) },
      {
        getToken: () => useAuth.getState().accessToken,
        onOpen: () => useRealtime.getState().setStatus('open'),
        onClose: () => useRealtime.getState().setStatus('closed'),
        onMessage: (msg) => {
          const s = useRealtime.getState();
          if (msg.type === 'ready' || msg.type === 'presence') s.setOnline(msg.online);
          else if (msg.type === 'chat.message') s.push(msg.message);
          else if (msg.type === 'error') {
            const key = `errors.${msg.code}`;
            useToasts
              .getState()
              .push(
                msg.code === 'ERR_RATE_LIMITED' && msg.retryAfterSeconds
                  ? tRef.current('errors.rateLimitedWait', { seconds: msg.retryAfterSeconds })
                  : tRef.current(key, { defaultValue: tRef.current('errors.ERR_INTERNAL') }),
                'error',
              );
          } else if (msg.type === 'notification') {
            const n = msg.notification;
            useToasts.getState().push(describeNotification(tRef.current, n).text, 'info');
            void client.invalidateQueries({ queryKey: ['notifications'] });
            if (isBuildKind(n)) {
              void client.invalidateQueries({ queryKey: ['castle'] });
              void client.invalidateQueries({ queryKey: ['reports'] });
            }
            if (n.kind.startsWith('guild.')) {
              void client.invalidateQueries({ queryKey: ['guild'] });
              if (n.kind === 'guild.help') void client.invalidateQueries({ queryKey: ['castle'] });
            }
          }
        },
      },
    );
    active = c;
    c.start();
    return () => {
      c.stop();
      if (active === c) active = null;
      useRealtime.getState().reset();
    };
  }, [authed, client]);

  useEffect(() => {
    active?.reauth();
  }, [token]);
}
