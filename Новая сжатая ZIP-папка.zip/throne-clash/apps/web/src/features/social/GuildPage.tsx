import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState, type FormEvent } from 'react';
import { useTranslation } from 'react-i18next';
import {
  GUILD_CREATE_COST,
  GUILD_DESC_MAX,
  GUILD_MIN_CASTLE,
  GUILD_NAME_MAX,
  GUILD_NAME_MIN,
  MIN_DONATION,
  type GuildDto,
  type GuildRole,
  type GuildSummaryDto,
} from '@tc/shared';
import { formatDurationT } from '../../lib/duration';
import { formatFull } from '../../lib/format';
import { useAuth } from '../../store/auth';
import { useToasts } from '../../store/toast';
import { Badge, Button, ConfirmDialog, Panel, ProgressBar, Tabs } from '../../ui';
import { errorMessage } from '../auth/errors';
import { useLiveCastle } from '../castle/useCastle';
import { guildApi } from './api';
import { ChatPanel } from './ChatPanel';

const inputCls =
  'min-h-[44px] w-full min-w-0 rounded-lg border-2 border-wood-light bg-white/80 px-3 text-ink';

function useGuildAction<T>(fn: (v: T) => Promise<unknown>, okMessage?: string) {
  const { t } = useTranslation();
  const client = useQueryClient();
  const push = useToasts((s) => s.push);
  return useMutation({
    mutationFn: fn,
    onSuccess: () => {
      void client.invalidateQueries({ queryKey: ['guild'] });
      void client.invalidateQueries({ queryKey: ['castle'] });
      if (okMessage) push(t(okMessage), 'success');
    },
    onError: (err) => {
      push(errorMessage(t, err), 'error');
      void client.invalidateQueries({ queryKey: ['guild'] });
    },
  });
}

// ── Нет братства: создать или найти ─────────────────────────────────────────

function Browse({ applied }: { applied: ReadonlySet<string> }) {
  const { t } = useTranslation();
  const [q, setQ] = useState('');
  const [page, setPage] = useState(1);
  const list = useQuery({
    queryKey: ['guild', 'list', q, page],
    queryFn: () => guildApi.list(q, page),
    retry: false,
  });
  const apply = useGuildAction((id: string) => guildApi.apply(id), 'guild.applied');
  const pages = list.data ? Math.max(1, Math.ceil(list.data.total / list.data.pageSize)) : 1;
  return (
    <Panel title={t('guild.find')}>
      <label className="mt-2 flex flex-col gap-1 text-sm">
        <span className="font-display font-bold">{t('guild.search')}</span>
        <input
          value={q}
          onChange={(e) => {
            setQ(e.target.value.slice(0, 40));
            setPage(1);
          }}
          className={inputCls}
        />
      </label>
      {list.data && list.data.items.length === 0 && (
        <p className="mt-3 text-sm">{t('guild.nothing')}</p>
      )}
      <ul className="mt-3 flex flex-col gap-2" aria-label={t('guild.find')}>
        {list.data?.items.map((g: GuildSummaryDto) => (
          <li
            key={g.id}
            className="flex flex-wrap items-center gap-x-3 gap-y-1 rounded-lg bg-black/25 px-3 py-2"
          >
            <div className="min-w-[10rem] flex-1">
              <p className="font-display font-bold">{g.name}</p>
              <p className="text-xs opacity-85">
                {t('guild.summary', {
                  level: g.level,
                  members: g.members,
                  capacity: g.capacity,
                  leader: g.leaderName,
                })}
              </p>
              {g.description && <p className="text-xs">{g.description}</p>}
            </div>
            {applied.has(g.id) ? (
              <Badge tone="stone">{t('guild.appliedBadge')}</Badge>
            ) : (
              <Button
                variant="gold"
                className="!min-h-[36px] !px-3 !py-1 text-sm"
                disabled={apply.isPending || g.members >= g.capacity}
                aria-label={`${t('guild.apply')}: ${g.name}`}
                onClick={() => apply.mutate(g.id)}
              >
                {g.members >= g.capacity ? t('guild.full') : t('guild.apply')}
              </Button>
            )}
          </li>
        ))}
      </ul>
      {pages > 1 && (
        <div className="mt-3 flex items-center justify-center gap-3">
          <Button disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
            {t('report.prev')}
          </Button>
          <span className="text-sm">
            {page} / {pages}
          </span>
          <Button disabled={page >= pages} onClick={() => setPage((p) => p + 1)}>
            {t('report.next')}
          </Button>
        </div>
      )}
    </Panel>
  );
}

function CreateForm() {
  const { t } = useTranslation();
  const { castle, projected } = useLiveCastle();
  const guest = useAuth((s) => s.user?.isGuest ?? false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const create = useGuildAction(
    (v: { name: string; description: string }) => guildApi.create(v.name, v.description),
    'guild.created',
  );
  const castleLevel = castle?.buildings.find((b) => b.key === 'castle')?.level ?? 0;
  let blocked: string | null = null;
  if (guest) blocked = t('guild.blocked.guest');
  else if (castleLevel < GUILD_MIN_CASTLE)
    blocked = t('guild.blocked.castle', { level: GUILD_MIN_CASTLE });
  else if (projected && Math.floor(projected.resources.gold) < GUILD_CREATE_COST)
    blocked = t('guild.blocked.gold', { gold: formatFull(GUILD_CREATE_COST) });
  else if (name.trim().length < GUILD_NAME_MIN)
    blocked = t('guild.blocked.name', { min: GUILD_NAME_MIN });

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!blocked) create.mutate({ name: name.trim(), description: description.trim() });
  };
  return (
    <Panel title={t('guild.create')}>
      <p className="pt-2 text-sm">
        {t('guild.createHint', { level: GUILD_MIN_CASTLE, gold: formatFull(GUILD_CREATE_COST) })}
      </p>
      <form className="mt-3 flex flex-col gap-3" onSubmit={submit}>
        <label className="flex flex-col gap-1 text-sm">
          <span className="font-display font-bold">{t('guild.name')}</span>
          <input
            value={name}
            maxLength={GUILD_NAME_MAX}
            onChange={(e) => setName(e.target.value)}
            className={inputCls}
          />
        </label>
        <label className="flex flex-col gap-1 text-sm">
          <span className="font-display font-bold">{t('guild.description')}</span>
          <input
            value={description}
            maxLength={GUILD_DESC_MAX}
            onChange={(e) => setDescription(e.target.value)}
            className={inputCls}
          />
        </label>
        <Button type="submit" variant="gold" disabled={blocked !== null || create.isPending}>
          {t('guild.createButton')}
        </Button>
        {blocked && (
          <p role="status" className="text-sm font-semibold">
            {blocked}
          </p>
        )}
      </form>
    </Panel>
  );
}

// ── Есть братство ───────────────────────────────────────────────────────────

function Members({ g }: { g: GuildDto }) {
  const { t } = useTranslation();
  const me = useAuth((s) => s.user?.id);
  const [kick, setKick] = useState<{ userId: string; nickname: string } | null>(null);
  const setRole = useGuildAction((v: { userId: string; role: GuildRole }) =>
    guildApi.setRole(v.userId, v.role),
  );
  const doKick = useGuildAction((userId: string) => guildApi.kick(userId), 'guild.kickedToast');
  const leader = g.myRole === 'leader';
  return (
    <>
      <ul className="flex flex-col gap-2 pt-2" aria-label={t('guild.tab.members')}>
        {g.memberList.map((m) => {
          const canKick =
            m.userId !== me &&
            (leader ? m.role !== 'leader' : g.myRole === 'officer' && m.role === 'member');
          return (
            <li
              key={m.userId}
              className="flex flex-wrap items-center gap-2 rounded-lg bg-black/25 px-3 py-2"
            >
              <span className="min-w-[8rem] flex-1 font-semibold">
                {m.nickname}{' '}
                {m.userId === me && <span className="opacity-70">({t('map.you')})</span>}
              </span>
              <Badge tone={m.role === 'leader' ? 'gold' : m.role === 'officer' ? 'green' : 'stone'}>
                {t(`guild.role.${m.role}`)}
              </Badge>
              {leader && m.userId !== me && (
                <>
                  {m.role !== 'leader' && (
                    <Button
                      className="!min-h-[36px] !px-2 text-sm"
                      onClick={() =>
                        setRole.mutate({
                          userId: m.userId,
                          role: m.role === 'officer' ? 'member' : 'officer',
                        })
                      }
                      aria-label={`${m.role === 'officer' ? t('guild.demote') : t('guild.promote')}: ${m.nickname}`}
                    >
                      {m.role === 'officer' ? t('guild.demote') : t('guild.promote')}
                    </Button>
                  )}
                  <Button
                    className="!min-h-[36px] !px-2 text-sm"
                    onClick={() => setRole.mutate({ userId: m.userId, role: 'leader' })}
                    aria-label={`${t('guild.makeLeader')}: ${m.nickname}`}
                  >
                    {t('guild.makeLeader')}
                  </Button>
                </>
              )}
              {canKick && (
                <Button
                  variant="danger"
                  className="!min-h-[36px] !px-2 text-sm"
                  onClick={() => setKick({ userId: m.userId, nickname: m.nickname })}
                  aria-label={`${t('guild.kick')}: ${m.nickname}`}
                >
                  {t('guild.kick')}
                </Button>
              )}
            </li>
          );
        })}
      </ul>
      <ConfirmDialog
        open={kick !== null}
        title={t('guild.kickTitle')}
        message={kick ? t('guild.kickText', { name: kick.nickname }) : ''}
        confirmLabel={t('guild.kick')}
        onCancel={() => setKick(null)}
        onConfirm={() => {
          const target = kick;
          setKick(null);
          if (target) doKick.mutate(target.userId);
        }}
      />
    </>
  );
}

function Applications({ g }: { g: GuildDto }) {
  const { t } = useTranslation();
  const decide = useGuildAction((v: { id: string; accept: boolean }) =>
    guildApi.decide(v.id, v.accept),
  );
  if (g.applications.length === 0)
    return <p className="pt-2 text-sm">{t('guild.noApplications')}</p>;
  return (
    <ul className="flex flex-col gap-2 pt-2" aria-label={t('guild.tab.applications')}>
      {g.applications.map((a) => (
        <li
          key={a.id}
          className="flex flex-wrap items-center gap-2 rounded-lg bg-black/25 px-3 py-2"
        >
          <span className="min-w-[8rem] flex-1 font-semibold">{a.nickname}</span>
          <Button
            variant="gold"
            className="!min-h-[36px] !px-3 text-sm"
            disabled={decide.isPending}
            aria-label={`${t('guild.accept')}: ${a.nickname}`}
            onClick={() => decide.mutate({ id: a.id, accept: true })}
          >
            {t('guild.accept')}
          </Button>
          <Button
            variant="danger"
            className="!min-h-[36px] !px-3 text-sm"
            disabled={decide.isPending}
            aria-label={`${t('guild.reject')}: ${a.nickname}`}
            onClick={() => decide.mutate({ id: a.id, accept: false })}
          >
            {t('guild.reject')}
          </Button>
        </li>
      ))}
    </ul>
  );
}

function Help({ g }: { g: GuildDto }) {
  const { t } = useTranslation();
  const push = useToasts((s) => s.push);
  const help = useGuildAction(async (v: { ownerId: string; taskId: string }) => {
    const r = await guildApi.help(v.ownerId, v.taskId);
    push(t('guild.helped', { seconds: r.seconds }), 'success');
  });
  if (g.helpRequests.length === 0) return <p className="pt-2 text-sm">{t('guild.noHelp')}</p>;
  return (
    <ul className="flex flex-col gap-2 pt-2" aria-label={t('guild.tab.help')}>
      {g.helpRequests.map((h) => (
        <li
          key={h.taskId}
          className="flex flex-wrap items-center gap-2 rounded-lg bg-black/25 px-3 py-2"
        >
          <span className="min-w-[10rem] flex-1 text-sm">
            <b>{h.nickname}</b>: {t(`building.${h.building}`)} → {h.toLevel}
            <span className="block text-xs opacity-85">
              {t('guild.helpMeta', {
                helps: h.helps,
                max: h.maxHelps,
                seconds: formatDurationT(t, h.helpSeconds),
              })}
            </span>
          </span>
          <Button
            variant="gold"
            className="!min-h-[36px] !px-3 text-sm"
            disabled={!h.canHelp || help.isPending}
            aria-label={`${t('guild.help')}: ${h.nickname}`}
            onClick={() => help.mutate({ ownerId: h.userId, taskId: h.taskId })}
          >
            {h.canHelp ? t('guild.help') : t('guild.helpedBadge')}
          </Button>
        </li>
      ))}
    </ul>
  );
}

function Treasury({ g }: { g: GuildDto }) {
  const { t } = useTranslation();
  const { projected } = useLiveCastle();
  const [amount, setAmount] = useState('');
  const donate = useGuildAction((n: number) => guildApi.donate(n), 'guild.donated');
  const value = Math.floor(Number(amount) || 0);
  const gold = projected ? Math.floor(projected.resources.gold) : 0;
  const perLevel = 50_000;
  const into = g.treasury % perLevel;
  return (
    <div className="pt-2">
      <p className="text-sm">
        {t('guild.treasury')}: <b>{formatFull(g.treasury)}</b>
      </p>
      {g.level < 10 && (
        <div className="mt-2">
          <ProgressBar
            label={t('guild.nextLevel')}
            value={into}
            max={perLevel}
            text={`${formatFull(into)} / ${formatFull(perLevel)}`}
          />
        </div>
      )}
      <form
        className="mt-3 flex items-end gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          if (value >= MIN_DONATION && value <= gold) donate.mutate(value);
          setAmount('');
        }}
      >
        <label className="flex min-w-0 flex-1 flex-col gap-1 text-sm">
          <span className="font-display font-bold">{t('guild.donateAmount')}</span>
          <input
            inputMode="numeric"
            value={amount}
            onChange={(e) => setAmount(e.target.value.replace(/[^\d]/g, '').slice(0, 8))}
            className={inputCls}
          />
        </label>
        <Button
          type="submit"
          variant="gold"
          className="shrink-0"
          disabled={value < MIN_DONATION || value > gold || donate.isPending}
        >
          {t('guild.donate')}
        </Button>
      </form>
      <p className="mt-2 text-xs opacity-85">{t('guild.donateHint', { min: MIN_DONATION })}</p>
    </div>
  );
}

function InGuild({ g }: { g: GuildDto }) {
  const { t } = useTranslation();
  const [tab, setTab] = useState('members');
  const [leaving, setLeaving] = useState(false);
  const leave = useGuildAction(() => guildApi.leave(), 'guild.left');
  const staff = g.myRole !== 'member';
  const items = [
    { id: 'members', label: t('guild.tab.members'), content: <Members g={g} /> },
    ...(staff
      ? [
          {
            id: 'applications',
            label: `${t('guild.tab.applications')}${g.applications.length ? ` (${g.applications.length})` : ''}`,
            content: <Applications g={g} />,
          },
        ]
      : []),
    { id: 'help', label: t('guild.tab.help'), content: <Help g={g} /> },
    { id: 'treasury', label: t('guild.tab.treasury'), content: <Treasury g={g} /> },
    {
      id: 'chat',
      label: t('guild.tab.chat'),
      content: <ChatPanel channel="guild" label={t('chat.guild')} />,
    },
  ];
  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-4">
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="font-display text-2xl font-bold text-gold-light">{g.name}</h1>
        <Badge tone="gold">{t(`guild.role.${g.myRole}`)}</Badge>
        <Button variant="danger" className="ml-auto !min-h-[40px]" onClick={() => setLeaving(true)}>
          {t('guild.leave')}
        </Button>
      </div>
      <p className="text-sm">
        {t('guild.summary', {
          level: g.level,
          members: g.members,
          capacity: g.capacity,
          leader: g.leaderName,
        })}
      </p>
      {g.description && <p className="text-sm opacity-90">{g.description}</p>}
      <Panel title={g.name}>
        <Tabs items={items} value={tab} onChange={setTab} />
      </Panel>
      <ConfirmDialog
        open={leaving}
        title={t('guild.leaveTitle')}
        message={
          g.myRole === 'leader' && g.members > 1 ? t('guild.leaveLeader') : t('guild.leaveText')
        }
        confirmLabel={t('guild.leave')}
        onCancel={() => setLeaving(false)}
        onConfirm={() => {
          setLeaving(false);
          leave.mutate(undefined);
        }}
      />
    </div>
  );
}

export function GuildPage() {
  const { t } = useTranslation();
  const withdraw = useGuildAction((id: string) => guildApi.withdraw(id));
  const mine = useQuery({
    queryKey: ['guild'],
    queryFn: guildApi.mine,
    retry: false,
    refetchInterval: 30_000,
  });

  if (mine.isPending)
    return (
      <p role="status" className="pt-8 text-center font-display text-lg">
        {t('common.loading')}
      </p>
    );
  if (mine.isError || !mine.data)
    return (
      <Panel title={t('nav.guild')} className="mx-auto max-w-md text-center">
        <p className="pt-2">{t('errors.ERR_NETWORK')}</p>
        <Button className="mt-3" onClick={() => void mine.refetch()}>
          {t('common.retry')}
        </Button>
      </Panel>
    );
  if (mine.data.guild) return <InGuild g={mine.data.guild} />;

  const applied = new Set(mine.data.applications.map((a) => a.guildId));
  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-4">
      <h1 className="font-display text-2xl font-bold text-gold-light">{t('nav.guild')}</h1>
      <p className="text-sm">{t('guild.none')}</p>
      {mine.data.applications.length > 0 && (
        <Panel title={t('guild.myApplications')}>
          <ul className="flex flex-col gap-2 pt-2">
            {mine.data.applications.map((a) => (
              <li
                key={a.guildId}
                className="flex items-center gap-2 rounded-lg bg-black/25 px-3 py-2"
              >
                <span className="flex-1 font-semibold">{a.guildName}</span>
                <Button
                  className="!min-h-[36px] !px-3 text-sm"
                  disabled={withdraw.isPending}
                  aria-label={`${t('guild.withdraw')}: ${a.guildName}`}
                  onClick={() => withdraw.mutate(a.guildId)}
                >
                  {t('guild.withdraw')}
                </Button>
              </li>
            ))}
          </ul>
        </Panel>
      )}
      <CreateForm />
      <Browse applied={applied} />
    </div>
  );
}
