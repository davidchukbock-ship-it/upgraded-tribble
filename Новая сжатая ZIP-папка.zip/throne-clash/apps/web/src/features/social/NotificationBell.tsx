import { useQuery } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
import { NavArt } from '../../art';
import { notificationApi } from './api';

/** Колокольчик с числом непрочитанных: ведёт в ленту уведомлений. */
export function NotificationBell() {
  const { t } = useTranslation();
  const q = useQuery({
    queryKey: ['notifications', 1],
    queryFn: () => notificationApi.list(1),
    staleTime: 60_000,
    retry: false,
  });
  const unread = q.data?.unread ?? 0;
  return (
    <Link
      to="/notifications"
      aria-label={unread > 0 ? t('notif.bellUnread', { count: unread }) : t('notif.bell')}
      className="panel-wood relative flex h-11 w-11 shrink-0 items-center justify-center rounded-full"
    >
      <NavArt name="notifications" size={32} />
      {unread > 0 && (
        <span
          aria-hidden="true"
          className="absolute -right-1 -top-1 min-w-[20px] rounded-full bg-red px-1 text-center text-xs font-bold leading-5 text-white"
        >
          {unread > 99 ? '99+' : unread}
        </span>
      )}
    </Link>
  );
}
