import { useMutation, useQuery } from '@tanstack/react-query';
import { useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { CHAT_MAX_LEN, type ChatMessageDto } from '@tc/shared';
import { useAuth } from '../../store/auth';
import { useRealtime } from '../../store/realtime';
import { useToasts } from '../../store/toast';
import { Button, ScrollModal } from '../../ui';
import { errorMessage } from '../auth/errors';
import { chatApi } from './api';
import { sendViaSocket } from './useRealtimeConnection';

const time = (iso: string): string =>
  new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

interface Props {
  channel: string;
  /** Подпись области для скринридера. */
  label: string;
  /** Клик по нику автора открывает личный чат. */
  onOpenDm?: (userId: string, nickname: string) => void;
}

/** Лента сообщений канала + поле ввода. Новые сообщения приходят по WebSocket, история — по HTTP. */
export function ChatPanel({ channel, label, onOpenDm }: Props) {
  const { t } = useTranslation();
  const push = useToasts((s) => s.push);
  const me = useAuth((s) => s.user?.id);
  const messages = useRealtime((s) => s.messages[channel]) ?? [];
  const [text, setText] = useState('');
  const [reporting, setReporting] = useState<ChatMessageDto | null>(null);
  const [reason, setReason] = useState('');
  const endRef = useRef<HTMLLIElement>(null);

  const history = useQuery({
    queryKey: ['chat', channel],
    queryFn: () => chatApi.history(channel),
    staleTime: 15_000,
    retry: false,
  });
  useEffect(() => {
    if (history.data) useRealtime.getState().merge(channel, history.data);
  }, [history.data, channel]);
  useEffect(() => {
    endRef.current?.scrollIntoView?.({ block: 'end' });
  }, [messages.length]);

  const send = useMutation({
    mutationFn: (value: string) => chatApi.send(channel, value),
    onSuccess: (m) => useRealtime.getState().push(m),
    onError: (err) => push(errorMessage(t, err), 'error'),
  });
  const report = useMutation({
    mutationFn: (v: { id: string; reason: string }) => chatApi.report(v.id, v.reason),
    onSuccess: () => {
      push(t('chat.reported'), 'success');
      setReporting(null);
      setReason('');
    },
    onError: (err) => push(errorMessage(t, err), 'error'),
  });

  const submit = () => {
    const value = text.trim();
    if (!value) return;
    setText('');
    // По WebSocket, если он открыт; иначе запасной путь через HTTP
    if (!sendViaSocket(channel, value)) send.mutate(value);
  };

  return (
    <div className="flex flex-col gap-2">
      <div
        role="log"
        aria-label={label}
        aria-live="polite"
        tabIndex={0}
        className="h-72 overflow-y-auto rounded-lg bg-black/30 p-3 text-sm"
      >
        <ul className="flex flex-col gap-1">
          {messages.length === 0 && <li className="opacity-80">{t('chat.empty')}</li>}
          {messages.map((m) => (
            <li key={m.id} className="break-words">
              <span className="opacity-70">{time(m.createdAt)} </span>
              {m.userId !== me && onOpenDm ? (
                <button
                  type="button"
                  className="font-bold text-gold-light underline decoration-dotted"
                  onClick={() => onOpenDm(m.userId, m.nickname)}
                  aria-label={t('chat.writeTo', { name: m.nickname })}
                >
                  {m.nickname}
                </button>
              ) : (
                <b className="text-gold-light">{m.nickname}</b>
              )}
              : <span>{m.text}</span>
              {m.userId !== me && (
                <button
                  type="button"
                  className="ml-2 text-xs opacity-60 hover:opacity-100"
                  onClick={() => setReporting(m)}
                  aria-label={t('chat.reportFrom', { name: m.nickname })}
                >
                  ⚑
                </button>
              )}
            </li>
          ))}
          <li ref={endRef} aria-hidden="true" />
        </ul>
      </div>
      <form
        className="flex items-end gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          submit();
        }}
      >
        <label className="flex min-w-0 flex-1 flex-col gap-1 text-sm">
          <span className="sr-only">{t('chat.message')}</span>
          <input
            value={text}
            maxLength={CHAT_MAX_LEN}
            onChange={(e) => setText(e.target.value)}
            placeholder={t('chat.placeholder')}
            className="min-h-[44px] w-full min-w-0 rounded-lg border-2 border-wood-light bg-white/80 px-3 text-ink"
          />
        </label>
        <Button type="submit" variant="gold" className="shrink-0" disabled={text.trim() === ''}>
          {t('chat.send')}
        </Button>
      </form>

      <ScrollModal
        open={reporting !== null}
        title={t('chat.reportTitle')}
        onClose={() => setReporting(null)}
        footer={
          <Button
            variant="danger"
            disabled={reason.trim() === '' || report.isPending}
            onClick={() => reporting && report.mutate({ id: reporting.id, reason: reason.trim() })}
          >
            {t('chat.reportSend')}
          </Button>
        }
      >
        {reporting && (
          <>
            <p className="text-sm">
              <b>{reporting.nickname}</b>: {reporting.text}
            </p>
            <label className="mt-3 flex flex-col gap-1 text-sm">
              <span className="font-display font-bold">{t('chat.reportReason')}</span>
              <input
                value={reason}
                maxLength={200}
                onChange={(e) => setReason(e.target.value)}
                className="min-h-[40px] rounded-lg border-2 border-wood-light bg-white/80 px-3 text-ink"
              />
            </label>
          </>
        )}
      </ScrollModal>
    </div>
  );
}
