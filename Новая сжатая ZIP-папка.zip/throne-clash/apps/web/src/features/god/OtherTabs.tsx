import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  ALL_UNIT_IDS,
  BALANCE_KEYS,
  BALANCE_MAX,
  BALANCE_MIN,
  type BattleResult,
  type UnitCounts,
} from '@tc/shared';
import { useToasts } from '../../store/toast';
import { errorMessage } from '../auth/errors';
import { Json, OpsButton, OpsInput, OpsPanel, OpsSelect, when } from '../admin/ops';
import { godApi } from './api';
import { DoubleConfirm } from './confirm';

function useNotify() {
  const { t } = useTranslation();
  const push = useToasts((s) => s.push);
  return {
    ok: () => push(t('god.done'), 'success'),
    fail: (err: unknown) => push(errorMessage(t, err), 'error'),
  };
}

export function WorldTab() {
  const { t } = useTranslation();
  const n = useNotify();
  const [guildId, setGuildId] = useState('');
  const [ask, setAsk] = useState(false);
  const cell = useMutation({
    mutationFn: (v: { x: number; y: number }) => godApi.cellReset(v.x, v.y),
    onSuccess: n.ok,
    onError: n.fail,
  });
  const announce = useMutation({
    mutationFn: (text: string) => godApi.announce(text),
    onSuccess: n.ok,
    onError: n.fail,
  });
  const del = useMutation({
    mutationFn: () => godApi.deleteGuild(guildId.trim()),
    onSuccess: n.ok,
    onError: n.fail,
  });
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <OpsPanel title={t('god.cellReset')}>
        <p className="pb-2 text-xs text-slate-300">{t('god.cellResetHint')}</p>
        <form
          className="flex items-end gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            const f = new FormData(e.currentTarget);
            cell.mutate({ x: Number(f.get('x')), y: Number(f.get('y')) });
          }}
        >
          <OpsInput name="x" type="number" min={0} max={99} defaultValue={50} label="X" />
          <OpsInput name="y" type="number" min={0} max={99} defaultValue={50} label="Y" />
          <OpsButton type="submit" tone="ok">
            {t('god.apply')}
          </OpsButton>
        </form>
      </OpsPanel>
      <OpsPanel title={t('god.announce')}>
        <form
          className="flex items-end gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            const text = String(new FormData(e.currentTarget).get('text') ?? '');
            announce.mutate(text);
            e.currentTarget.reset();
          }}
        >
          <OpsInput
            name="text"
            label={t('god.announceText')}
            className="flex-1"
            required
            maxLength={300}
          />
          <OpsButton type="submit" tone="ok">
            {t('god.send')}
          </OpsButton>
        </form>
      </OpsPanel>
      <OpsPanel title={t('god.guildDelete')}>
        <div className="flex items-end gap-2">
          <OpsInput
            label={t('god.guildId')}
            value={guildId}
            onChange={(e) => setGuildId(e.target.value)}
            className="flex-1"
          />
          <OpsButton
            tone="danger"
            disabled={guildId.trim().length < 8}
            onClick={() => setAsk(true)}
          >
            {t('god.delete')}
          </OpsButton>
        </div>
      </OpsPanel>
      <DoubleConfirm
        open={ask}
        title={t('god.guildDelete')}
        message={t('god.guildDeleteWarn')}
        onCancel={() => setAsk(false)}
        onConfirm={() => {
          setAsk(false);
          del.mutate();
        }}
      />
    </div>
  );
}

interface Row {
  unit: string;
  count: number;
}

function ArmyEditor({
  title,
  rows,
  onChange,
}: {
  title: string;
  rows: Row[];
  onChange: (r: Row[]) => void;
}) {
  const { t } = useTranslation();
  return (
    <fieldset className="flex flex-col gap-2 rounded-md bg-slate-900 p-3">
      <legend className="px-1 text-sm font-bold">{title}</legend>
      {rows.map((r, i) => (
        <div key={i} className="grid grid-cols-[1fr_6rem_auto] items-end gap-2">
          <OpsSelect
            label={t('god.unit')}
            value={r.unit}
            onChange={(e) =>
              onChange(rows.map((x, j) => (j === i ? { ...x, unit: e.target.value } : x)))
            }
          >
            {ALL_UNIT_IDS.map((u) => (
              <option key={u} value={u}>
                {u}
              </option>
            ))}
          </OpsSelect>
          <OpsInput
            label={t('god.count')}
            type="number"
            min={0}
            value={r.count}
            onChange={(e) =>
              onChange(rows.map((x, j) => (j === i ? { ...x, count: Number(e.target.value) } : x)))
            }
          />
          <OpsButton
            onClick={() => onChange(rows.filter((_, j) => j !== i))}
            aria-label={`${t('god.delete')} ${i + 1}`}
          >
            ×
          </OpsButton>
        </div>
      ))}
      <OpsButton
        className="self-start"
        onClick={() => onChange([...rows, { unit: 'infantry_1', count: 10 }])}
      >
        + {t('god.addRow')}
      </OpsButton>
    </fieldset>
  );
}

const toCounts = (rows: Row[]): UnitCounts => {
  const out: UnitCounts = {};
  for (const r of rows)
    if (r.count > 0)
      out[r.unit as keyof UnitCounts] = (out[r.unit as keyof UnitCounts] ?? 0) + r.count;
  return out;
};

export function SimulatorTab() {
  const { t } = useTranslation();
  const n = useNotify();
  const [att, setAtt] = useState<Row[]>([{ unit: 'infantry_1', count: 30 }]);
  const [def, setDef] = useState<Row[]>([{ unit: 'archer_1', count: 30 }]);
  const [force, setForce] = useState('');
  const [seed, setSeed] = useState(1);
  const [out, setOut] = useState<{
    seed: number;
    forcedBonus: number;
    result: BattleResult;
  } | null>(null);
  const sim = useMutation({
    mutationFn: () =>
      godApi.simulate({
        attacker: toCounts(att),
        defender: toCounts(def),
        attackerBonus: { attack: 0, defense: 0 },
        defenderBonus: { attack: 0, defense: 0 },
        seed,
        ...(force ? { force: force as 'attacker' | 'defender' } : {}),
      }),
    onSuccess: setOut,
    onError: n.fail,
  });
  return (
    <div className="flex flex-col gap-4">
      <p className="text-sm text-slate-300">{t('god.simHint')}</p>
      <div className="grid gap-4 lg:grid-cols-2">
        <ArmyEditor title={t('god.attacker')} rows={att} onChange={setAtt} />
        <ArmyEditor title={t('god.defender')} rows={def} onChange={setDef} />
      </div>
      <div className="flex flex-wrap items-end gap-3">
        <OpsInput
          label="seed"
          type="number"
          min={0}
          value={seed}
          onChange={(e) => setSeed(Number(e.target.value))}
          className="w-32"
        />
        <OpsSelect
          label={t('god.force')}
          value={force}
          onChange={(e) => setForce(e.target.value)}
          className="w-48"
        >
          <option value="">{t('god.forceNone')}</option>
          <option value="attacker">{t('god.attacker')}</option>
          <option value="defender">{t('god.defender')}</option>
        </OpsSelect>
        <OpsButton tone="ok" onClick={() => sim.mutate()} disabled={sim.isPending}>
          {t('god.simulate')}
        </OpsButton>
      </div>
      {out && (
        <OpsPanel title={t('god.simResult')}>
          <p role="status" className="pb-2 text-lg font-bold">
            {t('god.winner')}:{' '}
            {t(out.result.winner === 'attacker' ? 'god.attacker' : 'god.defender')} ·{' '}
            {t('god.rounds')}: {out.result.rounds.length}
            {out.forcedBonus > 0 && (
              <span className="text-amber-300">
                {' '}
                · {t('god.forced', { bonus: Math.round(out.forcedBonus * 100) })}
              </span>
            )}
          </p>
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <h3 className="text-sm font-bold">{t('god.attacker')}</h3>
              <Json
                value={{
                  remaining: out.result.attacker.remaining,
                  fallen: out.result.attacker.fallen,
                }}
              />
            </div>
            <div>
              <h3 className="text-sm font-bold">{t('god.defender')}</h3>
              <Json
                value={{
                  remaining: out.result.defender.remaining,
                  fallen: out.result.defender.fallen,
                }}
              />
            </div>
          </div>
        </OpsPanel>
      )}
    </div>
  );
}

export function BalanceTab() {
  const { t, i18n } = useTranslation();
  const n = useNotify();
  const client = useQueryClient();
  const q = useQuery({ queryKey: ['god', 'balance'], queryFn: godApi.balance });
  const [draft, setDraft] = useState<Record<string, number> | null>(null);
  const [json, setJson] = useState('');
  const [ask, setAsk] = useState<null | 'reset'>(null);
  const done = () => {
    n.ok();
    setDraft(null);
    void client.invalidateQueries({ queryKey: ['god', 'balance'] });
    void client.invalidateQueries({ queryKey: ['god', 'audit'] });
  };
  const apply = useMutation({
    mutationFn: (b: Record<string, number>) => godApi.setBalance(b),
    onSuccess: done,
    onError: n.fail,
  });
  const rollback = useMutation({
    mutationFn: (id: string) => godApi.rollback(id),
    onSuccess: done,
    onError: n.fail,
  });
  if (!q.data) return <p role="status">{t('common.loading')}</p>;
  const current = draft ?? q.data.balance;
  return (
    <div className="flex flex-col gap-4">
      <OpsPanel title={t('god.balance')}>
        <p className="pb-2 text-xs text-slate-300">
          {t('god.balanceHint', { min: BALANCE_MIN, max: BALANCE_MAX })}
        </p>
        <form
          className="grid grid-cols-2 gap-2 sm:grid-cols-5"
          onSubmit={(e) => {
            e.preventDefault();
            apply.mutate(current);
          }}
        >
          {BALANCE_KEYS.map((k) => (
            <OpsInput
              key={k}
              label={t(`god.balanceKeys.${k}`)}
              type="number"
              step="0.05"
              min={BALANCE_MIN}
              max={BALANCE_MAX}
              value={current[k] ?? 1}
              onChange={(e) => setDraft({ ...current, [k]: Number(e.target.value) })}
            />
          ))}
          <div className="col-span-2 flex items-end gap-2 sm:col-span-5">
            <OpsButton type="submit" tone="ok" disabled={apply.isPending}>
              {t('god.apply')}
            </OpsButton>
            <OpsButton tone="danger" onClick={() => setAsk('reset')}>
              {t('god.balanceReset')}
            </OpsButton>
          </div>
        </form>
      </OpsPanel>
      <OpsPanel title={t('god.revisions')}>
        <ul className="flex flex-col gap-1">
          {q.data.revisions.map((r) => (
            <li
              key={r.id}
              className="flex flex-wrap items-center gap-2 rounded bg-slate-900 p-2 text-sm"
            >
              <span className="font-mono text-xs">{when(r.createdAt, i18n.language)}</span>
              <span className="flex-1 truncate text-xs text-slate-300">{r.note ?? ''}</span>
              <OpsButton
                onClick={() => rollback.mutate(r.id)}
                aria-label={`${t('god.rollback')} ${when(r.createdAt, i18n.language)}`}
              >
                {t('god.rollback')}
              </OpsButton>
            </li>
          ))}
          {q.data.revisions.length === 0 && <li className="text-sm">{t('admin.none')}</li>}
        </ul>
      </OpsPanel>
      <OpsPanel title={t('god.balanceJson')}>
        <label htmlFor="balance-json" className="text-xs font-semibold text-slate-300">
          JSON
        </label>
        <textarea
          id="balance-json"
          rows={5}
          value={json}
          onChange={(e) => setJson(e.target.value)}
          className="mt-1 w-full rounded-md border border-slate-500 bg-slate-900 p-2 font-mono text-xs text-slate-100"
        />
        <div className="mt-2 flex gap-2">
          <OpsButton onClick={() => setJson(JSON.stringify(q.data.balance, null, 2))}>
            {t('god.export')}
          </OpsButton>
          <OpsButton
            tone="ok"
            onClick={() => {
              try {
                apply.mutate(JSON.parse(json) as Record<string, number>);
              } catch {
                n.fail(new Error('json'));
              }
            }}
          >
            {t('god.import')}
          </OpsButton>
        </div>
      </OpsPanel>
      <DoubleConfirm
        open={ask === 'reset'}
        title={t('god.balanceReset')}
        message={t('god.balanceResetWarn')}
        onCancel={() => setAsk(null)}
        onConfirm={() => {
          setAsk(null);
          apply.mutate(Object.fromEntries(BALANCE_KEYS.map((k) => [k, 1])));
        }}
      />
    </div>
  );
}

export function DebugTab() {
  const { t } = useTranslation();
  const n = useNotify();
  const q = useQuery({
    queryKey: ['god', 'debug'],
    queryFn: godApi.debug,
    refetchInterval: 10_000,
  });
  const [ask, setAsk] = useState(false);
  const reseed = useMutation({ mutationFn: godApi.reseed, onSuccess: n.ok, onError: n.fail });
  if (!q.data) return <p role="status">{t('common.loading')}</p>;
  const d = q.data;
  const row = (label: string, value: string | number) => (
    <div key={label} className="rounded-md bg-slate-900 p-3">
      <dt className="text-xs text-slate-300">{label}</dt>
      <dd className="font-mono text-lg">{value}</dd>
    </div>
  );
  return (
    <div className="flex flex-col gap-4">
      <OpsPanel title={t('god.debug')}>
        <dl className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {row(t('god.uptime'), `${Math.floor(d.uptimeSeconds / 60)} min`)}
          {row(t('god.memory'), `${d.memoryMb} MB`)}
          {row(t('admin.stats.online'), d.online)}
          {row('Redis', d.redis)}
          {row(t('admin.stats.total'), d.counts.users)}
          {row(t('nav.castle'), d.counts.castles)}
          {row(t('nav.guild'), d.counts.guilds)}
          {row(t('nav.chat'), d.counts.chatMessages)}
        </dl>
      </OpsPanel>
      <OpsPanel title={t('god.reseed')}>
        <p className="pb-2 text-xs text-slate-300">{t('god.reseedHint')}</p>
        <OpsButton tone="danger" onClick={() => setAsk(true)}>
          {t('god.reseed')}
        </OpsButton>
      </OpsPanel>
      <DoubleConfirm
        open={ask}
        title={t('god.reseed')}
        message={t('god.reseedHint')}
        onCancel={() => setAsk(false)}
        onConfirm={() => {
          setAsk(false);
          reseed.mutate();
        }}
      />
    </div>
  );
}
