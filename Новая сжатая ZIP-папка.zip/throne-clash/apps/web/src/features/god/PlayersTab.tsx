import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState, type FormEvent } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import {
  ALL_UNIT_IDS,
  BUILDING_KEYS,
  CHEST_KINDS,
  BOOSTER_KEYS,
  EQUIP_SLOTS,
  GOD_RESOURCES,
  MAX_BUILDING_LEVEL,
  TECH_KEYS,
  type GodAction,
} from '@tc/shared';
import { useAuth } from '../../store/auth';
import { useToasts } from '../../store/toast';
import { Badge } from '../../ui';
import { OpsButton, OpsInput, OpsPanel, OpsSelect, Pager } from '../admin/ops';
import { errorMessage } from '../auth/errors';
import { godApi } from './api';
import { DoubleConfirm } from './confirm';

/** Действие над игроком: общая мутация с обновлением карточки и уведомлением. */
export function useGodAct(targetId: string | null) {
  const { t } = useTranslation();
  const push = useToasts((s) => s.push);
  const client = useQueryClient();
  return useMutation({
    mutationFn: (action: GodAction) => godApi.act(targetId!, action),
    onSuccess: () => {
      push(t('god.done'), 'success');
      void client.invalidateQueries({ queryKey: ['god', 'player'] });
      void client.invalidateQueries({ queryKey: ['god', 'audit'] });
    },
    onError: (err) => push(errorMessage(t, err), 'error'),
  });
}

const num = (f: FormData, name: string): number => Number(f.get(name) ?? 0);

function Form({
  title,
  onSubmit,
  children,
}: {
  title: string;
  onSubmit: (f: FormData) => void;
  children: React.ReactNode;
}) {
  const { t } = useTranslation();
  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    onSubmit(new FormData(e.currentTarget));
  };
  return (
    <form
      onSubmit={submit}
      aria-label={title}
      className="flex flex-col gap-2 rounded-md bg-slate-900 p-3"
    >
      <h3 className="text-sm font-bold text-slate-200">{title}</h3>
      <div className="grid grid-cols-2 gap-2">{children}</div>
      <OpsButton type="submit" tone="ok" className="self-start">
        {t('god.apply')}
      </OpsButton>
    </form>
  );
}

function PlayerCard({ id }: { id: string }) {
  const { t, i18n } = useTranslation();
  const push = useToasts((s) => s.push);
  const client = useQueryClient();
  const navigate = useNavigate();
  const q = useQuery({ queryKey: ['god', 'player', id], queryFn: () => godApi.player(id) });
  const act = useGodAct(id);
  const [ask, setAsk] = useState<null | { kind: 'reset' | 'restore' | 'ban'; sid?: string }>(null);
  const moderate = useMutation({
    mutationFn: (op: () => Promise<unknown>) => op(),
    onSuccess: () => {
      push(t('god.done'), 'success');
      void client.invalidateQueries({ queryKey: ['god'] });
    },
    onError: (err) => push(errorMessage(t, err), 'error'),
  });
  const snapshot = useMutation({
    mutationFn: (label: string) => godApi.snapshot(id, label),
    onSuccess: () => {
      push(t('god.done'), 'success');
      void client.invalidateQueries({ queryKey: ['god', 'player', id] });
    },
    onError: (err) => push(errorMessage(t, err), 'error'),
  });
  const impersonate = useMutation({
    mutationFn: () => godApi.impersonate(id),
    onSuccess: (res) => {
      // Дальше вся игра открывается от имени игрока; баннер в шапке напоминает об этом
      useAuth.getState().setSession(res);
      void client.clear();
      navigate('/castle');
    },
    onError: (err) => push(errorMessage(t, err), 'error'),
  });
  const restore = useMutation({
    mutationFn: (sid: string) => godApi.restore(id, sid),
    onSuccess: () => {
      push(t('god.done'), 'success');
      void client.invalidateQueries({ queryKey: ['god'] });
    },
    onError: (err) => push(errorMessage(t, err), 'error'),
  });

  if (q.isPending) return <p role="status">{t('common.loading')}</p>;
  if (q.isError || !q.data) return <p role="alert">{t('errors.ERR_NETWORK')}</p>;
  const { user, castle, inventory, godTouched, snapshots } = q.data;
  const a = (action: GodAction) => act.mutate(action);
  const banned = user.bannedUntil !== null && Date.parse(user.bannedUntil) > Date.now();
  const built = castle.buildings.filter((b) => b.level > 0);

  return (
    <div className="flex flex-col gap-4">
      <OpsPanel
        title={user.nickname}
        actions={
          <>
            {godTouched && <Badge tone="red">{t('god.touched')}</Badge>}
            <Badge tone="stone">{user.role}</Badge>
          </>
        }
      >
        <dl className="grid grid-cols-2 gap-2 text-sm sm:grid-cols-4">
          {(['gold', 'wood', 'stone', 'food'] as const).map((k) => (
            <div key={k}>
              <dt className="text-xs text-slate-300">{t(`resource.${k}`)}</dt>
              <dd className="font-mono">{Math.floor(castle.resources[k])}</dd>
            </div>
          ))}
          <div>
            <dt className="text-xs text-slate-300">{t('resource.gems')}</dt>
            <dd className="font-mono">{castle.gems}</dd>
          </div>
          <div>
            <dt className="text-xs text-slate-300">{t('god.power')}</dt>
            <dd className="font-mono">{castle.power}</dd>
          </div>
          <div>
            <dt className="text-xs text-slate-300">{t('god.position')}</dt>
            <dd className="font-mono">
              {castle.position ? `${castle.position.x}, ${castle.position.y}` : '—'}
            </dd>
          </div>
          <div>
            <dt className="text-xs text-slate-300">{t('nav.hero')}</dt>
            <dd className="font-mono">{castle.hero.level}</dd>
          </div>
        </dl>
        <p className="pt-2 text-xs text-slate-300">
          {built.map((b) => `${t(`building.${b.key}`)} ${b.level}`).join(' · ')}
        </p>
        <p className="pt-1 text-xs text-slate-300">
          {t('god.army')}: {castle.army.count} · {t('nav.chests')}: {inventory.chests.wooden}/
          {inventory.chests.silver}/{inventory.chests.gold}
          {' · '}
          {i18n.language.toUpperCase()}
        </p>
      </OpsPanel>

      <OpsPanel title={t('god.quick')}>
        <div className="flex flex-wrap gap-2">
          <OpsButton onClick={() => a({ type: 'fill' })}>{t('god.fill')}</OpsButton>
          <OpsButton onClick={() => a({ type: 'finish' })}>{t('god.finish')}</OpsButton>
          <OpsButton onClick={() => a({ type: 'resurrect' })}>{t('god.resurrect')}</OpsButton>
          <OpsButton onClick={() => a({ type: 'research_all' })}>{t('god.researchAll')}</OpsButton>
          {[
            ['+1h', 3600],
            ['+1d', 86_400],
            ['+7d', 7 * 86_400],
          ].map(([label, seconds]) => (
            <OpsButton key={label} onClick={() => a({ type: 'time', seconds: Number(seconds) })}>
              {t('god.time')} {label}
            </OpsButton>
          ))}
          <OpsButton tone="danger" onClick={() => setAsk({ kind: 'reset' })}>
            {t('god.reset')}
          </OpsButton>
        </div>
      </OpsPanel>

      <div className="grid gap-4 lg:grid-cols-2">
        <Form
          title={t('god.resources')}
          onSubmit={(f) =>
            a({
              type: 'resources',
              op: f.get('op') as 'give' | 'take' | 'set',
              resource: f.get('resource') as (typeof GOD_RESOURCES)[number],
              amount: num(f, 'amount'),
            })
          }
        >
          <OpsSelect name="op" label={t('god.op')} defaultValue="give">
            {(['give', 'take', 'set'] as const).map((o) => (
              <option key={o} value={o}>
                {t(`god.ops.${o}`)}
              </option>
            ))}
          </OpsSelect>
          <OpsSelect name="resource" label={t('god.resource')}>
            {GOD_RESOURCES.map((r) => (
              <option key={r} value={r}>
                {t(`resource.${r}`)}
              </option>
            ))}
          </OpsSelect>
          <OpsInput
            name="amount"
            type="number"
            min={0}
            max={1_000_000_000}
            defaultValue={100_000}
            label={t('god.amount')}
            className="col-span-2"
          />
        </Form>

        <Form
          title={t('god.building')}
          onSubmit={(f) =>
            a({
              type: 'building',
              key: f.get('key') as (typeof BUILDING_KEYS)[number],
              level: num(f, 'level'),
            })
          }
        >
          <OpsSelect name="key" label={t('god.buildingKey')}>
            {BUILDING_KEYS.map((k) => (
              <option key={k} value={k}>
                {t(`building.${k}`)}
              </option>
            ))}
          </OpsSelect>
          <OpsInput
            name="level"
            type="number"
            min={0}
            max={MAX_BUILDING_LEVEL}
            defaultValue={10}
            label={t('common.level')}
          />
        </Form>

        <Form
          title={t('god.armyTitle')}
          onSubmit={(f) => a({ type: 'army', unit: String(f.get('unit')), count: num(f, 'count') })}
        >
          <OpsSelect name="unit" label={t('god.unit')}>
            {ALL_UNIT_IDS.map((u) => (
              <option key={u} value={u}>
                {u}
              </option>
            ))}
          </OpsSelect>
          <OpsInput
            name="count"
            type="number"
            min={1}
            max={1_000_000}
            defaultValue={500}
            label={t('god.count')}
          />
        </Form>

        <Form
          title={t('god.researchTitle')}
          onSubmit={(f) =>
            a({
              type: 'research',
              tech: f.get('tech') as (typeof TECH_KEYS)[number],
              level: num(f, 'level'),
            })
          }
        >
          <OpsSelect name="tech" label={t('god.tech')}>
            {TECH_KEYS.map((k) => (
              <option key={k} value={k}>
                {t(`tech.${k}`)}
              </option>
            ))}
          </OpsSelect>
          <OpsInput
            name="level"
            type="number"
            min={0}
            max={10}
            defaultValue={5}
            label={t('common.level')}
          />
        </Form>

        <Form
          title={t('god.heroTitle')}
          onSubmit={(f) => a({ type: 'hero', level: num(f, 'level') })}
        >
          <OpsInput
            name="level"
            type="number"
            min={1}
            max={50}
            defaultValue={20}
            label={t('common.level')}
            className="col-span-2"
          />
        </Form>

        <Form
          title={t('god.gear')}
          onSubmit={(f) =>
            a({
              type: 'hero_gear',
              slot: f.get('slot') as (typeof EQUIP_SLOTS)[number],
              rarity: num(f, 'rarity') as 1 | 2 | 3 | 4 | 5,
            })
          }
        >
          <OpsSelect name="slot" label={t('god.slot')}>
            {EQUIP_SLOTS.map((s) => (
              <option key={s} value={s}>
                {t(`hero.slot.${s}`)}
              </option>
            ))}
          </OpsSelect>
          <OpsSelect name="rarity" label={t('god.rarity')} defaultValue="5">
            {[1, 2, 3, 4, 5].map((r) => (
              <option key={r} value={r}>
                ★{r}
              </option>
            ))}
          </OpsSelect>
        </Form>

        <Form
          title={t('god.teleport')}
          onSubmit={(f) => a({ type: 'teleport', x: num(f, 'x'), y: num(f, 'y') })}
        >
          <OpsInput name="x" type="number" min={0} max={99} defaultValue={50} label="X" />
          <OpsInput name="y" type="number" min={0} max={99} defaultValue={50} label="Y" />
        </Form>

        <Form
          title={t('god.shield')}
          onSubmit={(f) => a({ type: 'shield', hours: num(f, 'hours') })}
        >
          <OpsInput
            name="hours"
            type="number"
            min={0}
            max={720}
            defaultValue={72}
            label={t('god.hours')}
            className="col-span-2"
          />
        </Form>

        <Form
          title={t('god.chestTitle')}
          onSubmit={(f) =>
            a({
              type: 'chest',
              kind: f.get('kind') as (typeof CHEST_KINDS)[number],
              count: num(f, 'count'),
            })
          }
        >
          <OpsSelect name="kind" label={t('chest.title')}>
            {CHEST_KINDS.map((k) => (
              <option key={k} value={k}>
                {t(`chest.kind.${k}`)}
              </option>
            ))}
          </OpsSelect>
          <OpsInput
            name="count"
            type="number"
            min={1}
            max={100}
            defaultValue={5}
            label={t('god.count')}
          />
        </Form>

        <Form
          title={t('god.boosterTitle')}
          onSubmit={(f) =>
            a({ type: 'booster', booster: String(f.get('booster')), count: num(f, 'count') })
          }
        >
          <OpsSelect name="booster" label={t('booster.title')}>
            {BOOSTER_KEYS.map((k) => (
              <option key={k} value={k}>
                {t(`booster.${k}`)}
              </option>
            ))}
          </OpsSelect>
          <OpsInput
            name="count"
            type="number"
            min={1}
            max={100}
            defaultValue={5}
            label={t('god.count')}
          />
        </Form>
      </div>

      <OpsPanel title={t('god.snapshots')}>
        <form
          className="mb-3 flex items-end gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            const f = new FormData(e.currentTarget);
            snapshot.mutate(String(f.get('label') ?? ''));
            e.currentTarget.reset();
          }}
        >
          <OpsInput
            name="label"
            label={t('god.snapshotLabel')}
            className="flex-1"
            required
            maxLength={60}
          />
          <OpsButton type="submit" tone="ok">
            {t('god.save')}
          </OpsButton>
        </form>
        <ul className="flex flex-col gap-1">
          {snapshots.map((s) => (
            <li key={s.id} className="flex items-center gap-2 rounded bg-slate-900 p-2 text-sm">
              <span className="flex-1">
                {s.label}{' '}
                <span className="text-xs text-slate-400">
                  {new Date(s.createdAt).toLocaleString(i18n.language)}
                </span>
              </span>
              <OpsButton
                tone="danger"
                onClick={() => setAsk({ kind: 'restore', sid: s.id })}
                aria-label={`${t('god.restore')}: ${s.label}`}
              >
                {t('god.restore')}
              </OpsButton>
            </li>
          ))}
          {snapshots.length === 0 && <li className="text-sm">{t('admin.none')}</li>}
        </ul>
      </OpsPanel>

      <OpsPanel title={t('god.moderation')}>
        <div className="flex flex-wrap gap-2">
          {banned ? (
            <OpsButton onClick={() => moderate.mutate(() => godApi.unban(id))}>
              {t('admin.unban')}
            </OpsButton>
          ) : (
            <OpsButton tone="danger" onClick={() => setAsk({ kind: 'ban' })}>
              {t('admin.ban')}
            </OpsButton>
          )}
          <OpsButton onClick={() => moderate.mutate(() => godApi.mute(id, 60, 'god mode'))}>
            {t('admin.mute')} 1h
          </OpsButton>
          <OpsButton onClick={() => moderate.mutate(() => godApi.unmute(id))}>
            {t('admin.unmute')}
          </OpsButton>
          {user.role !== 'OWNER' && (
            <OpsButton
              onClick={() =>
                moderate.mutate(() => godApi.role(id, user.role === 'ADMIN' ? 'PLAYER' : 'ADMIN'))
              }
            >
              {user.role === 'ADMIN' ? t('god.demote') : t('god.promote')}
            </OpsButton>
          )}
          {user.role === 'PLAYER' && (
            <OpsButton tone="ok" onClick={() => impersonate.mutate()}>
              {t('god.impersonate')}
            </OpsButton>
          )}
        </div>
      </OpsPanel>

      <DoubleConfirm
        open={ask?.kind === 'reset'}
        title={t('god.reset')}
        message={t('god.resetWarn', { name: user.nickname })}
        onCancel={() => setAsk(null)}
        onConfirm={() => {
          setAsk(null);
          a({ type: 'reset' });
        }}
      />
      <DoubleConfirm
        open={ask?.kind === 'restore'}
        title={t('god.restore')}
        message={t('god.restoreWarn', { name: user.nickname })}
        onCancel={() => setAsk(null)}
        onConfirm={() => {
          const sid = ask?.sid;
          setAsk(null);
          if (sid) restore.mutate(sid);
        }}
      />
      <DoubleConfirm
        open={ask?.kind === 'ban'}
        title={t('admin.ban')}
        message={t('god.banWarn', { name: user.nickname })}
        onCancel={() => setAsk(null)}
        onConfirm={() => {
          setAsk(null);
          moderate.mutate(() => godApi.ban(id, null, 'god mode'));
        }}
      />
    </div>
  );
}

export function PlayersTab({
  target,
  onTarget,
}: {
  target: string | null;
  onTarget: (id: string) => void;
}) {
  const { t } = useTranslation();
  const [q, setQ] = useState('');
  const [term, setTerm] = useState('');
  const [page, setPage] = useState(1);
  const list = useQuery({
    queryKey: ['god', 'players', term, page],
    queryFn: () => godApi.players(term, page),
  });
  return (
    <div className="grid gap-4 lg:grid-cols-[18rem_1fr]">
      <OpsPanel title={t('admin.players')} className="self-start">
        <form
          role="search"
          className="mb-2 flex items-end gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            setPage(1);
            setTerm(q.trim());
          }}
        >
          <OpsInput
            className="flex-1"
            label={t('admin.search')}
            value={q}
            onChange={(e) => setQ(e.target.value)}
            maxLength={60}
          />
          <OpsButton type="submit">{t('admin.find')}</OpsButton>
        </form>
        <ul className="flex flex-col gap-1">
          {list.data?.items.map((u) => (
            <li key={u.id}>
              <button
                type="button"
                aria-pressed={target === u.id}
                onClick={() => onTarget(u.id)}
                className={`flex min-h-[40px] w-full items-center gap-2 rounded px-2 text-left text-sm hover:bg-slate-600 ${target === u.id ? 'bg-sky-800' : 'bg-slate-900'}`}
              >
                <span className="flex-1 truncate">{u.nickname}</span>
                {u.role !== 'PLAYER' && <Badge tone="stone">{u.role}</Badge>}
              </button>
            </li>
          ))}
        </ul>
        {list.data && (
          <Pager
            page={page}
            total={list.data.total}
            pageSize={list.data.pageSize}
            onPage={setPage}
          />
        )}
      </OpsPanel>
      {target ? <PlayerCard id={target} key={target} /> : <p>{t('god.pickPlayer')}</p>}
    </div>
  );
}
