import type {
  AdminUserDto,
  AdminUserPageDto,
  AuthResponse,
  AuditPageDto,
  BalanceDto,
  BattleResult,
  GodActResultDto,
  GodAction,
  GodDebugDto,
  GodPlayerDto,
  GodSessionDto,
  UnitCounts,
} from '@tc/shared';
import { apiFetch } from '../../lib/api';

const key = () => ({ 'Idempotency-Key': crypto.randomUUID() });
const post = <T>(path: string, body?: unknown, headers?: Record<string, string>) =>
  apiFetch<T>(`/api/god${path}`, {
    method: 'POST',
    ...(path === '/login' ? { noRefresh: true } : {}),
    ...(body !== undefined ? { body } : {}),
    ...(headers ? { headers } : {}),
  });

export interface SimulateInput {
  attacker: UnitCounts;
  defender: UnitCounts;
  attackerBonus: { attack: number; defense: number };
  defenderBonus: { attack: number; defense: number };
  seed: number;
  force?: 'attacker' | 'defender';
}

/** Режим бога: сессия держится в httpOnly-cookie, поэтому запросы идут с credentials (см. apiFetch). */
export const godApi = {
  login: (password: string, totp?: string) =>
    post<GodSessionDto>('/login', { password, ...(totp ? { totp } : {}) }),
  session: () => apiFetch<GodSessionDto>('/api/god/session', { noRefresh: true }),
  logout: () => post<void>('/logout'),
  players: (q: string, page = 1) =>
    apiFetch<AdminUserPageDto>(
      `/api/god/players?q=${encodeURIComponent(q)}&page=${page}&pageSize=8`,
    ),
  player: (id: string) => apiFetch<GodPlayerDto>(`/api/god/players/${id}`),
  act: (id: string, action: GodAction) =>
    post<GodActResultDto>(`/players/${id}/act`, action, key()),
  snapshot: (id: string, label: string) =>
    post<{ id: string; label: string; createdAt: string }>(`/players/${id}/snapshots`, { label }),
  restore: (id: string, snapshotId: string) =>
    post<GodActResultDto>(`/players/${id}/snapshots/${snapshotId}/restore`, undefined, key()),
  ban: (id: string, hours: number | null, reason: string) =>
    post<AdminUserDto>(`/players/${id}/ban`, { hours, reason }),
  unban: (id: string) => post<AdminUserDto>(`/players/${id}/unban`),
  mute: (id: string, minutes: number, reason: string) =>
    post<AdminUserDto>(`/players/${id}/mute`, { minutes, reason }),
  unmute: (id: string) => post<AdminUserDto>(`/players/${id}/unmute`),
  role: (id: string, role: 'PLAYER' | 'ADMIN') =>
    post<AdminUserDto>(`/players/${id}/role`, { role }),
  impersonate: (id: string) => post<AuthResponse>(`/players/${id}/impersonate`),
  cellReset: (x: number, y: number) => post<void>('/map/cell-reset', { x, y }),
  simulate: (input: SimulateInput) =>
    post<{ seed: number; forcedBonus: number; result: BattleResult }>('/simulate', input),
  deleteGuild: (id: string) => apiFetch<void>(`/api/god/guilds/${id}`, { method: 'DELETE' }),
  announce: (text: string) => post<void>('/chat/announce', { text }),
  balance: () => apiFetch<BalanceDto>('/api/god/balance'),
  setBalance: (b: Record<string, number>) =>
    apiFetch<BalanceDto>('/api/god/balance', { method: 'PUT', body: b }),
  rollback: (revisionId: string) => post<BalanceDto>('/balance/rollback', { revisionId }),
  audit: (page: number, targetUserId?: string) =>
    apiFetch<AuditPageDto>(
      `/api/god/audit?page=${page}&pageSize=15${targetUserId ? `&targetUserId=${targetUserId}` : ''}`,
    ),
  debug: () => apiFetch<GodDebugDto>('/api/god/debug'),
  reseed: () => post<{ bots: number; demos: number }>('/debug/reseed'),
};
