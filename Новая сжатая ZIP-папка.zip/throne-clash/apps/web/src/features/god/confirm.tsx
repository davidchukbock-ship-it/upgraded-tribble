import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { ScrollModal } from '../../ui';
import { OpsButton, OpsInput } from '../admin/ops';

/**
 * Двойное подтверждение разрушительных действий: сначала кнопка, затем окно, где нужно набрать слово GOD.
 * Случайный клик или Enter ничего не удалит.
 */
export function DoubleConfirm({
  open,
  title,
  message,
  onCancel,
  onConfirm,
}: {
  open: boolean;
  title: string;
  message: string;
  onCancel: () => void;
  onConfirm: () => void;
}) {
  const { t } = useTranslation();
  const [word, setWord] = useState('');
  const close = () => {
    setWord('');
    onCancel();
  };
  return (
    <ScrollModal open={open} alert title={title} onClose={close}>
      <div className="flex flex-col gap-3 rounded-lg bg-slate-800 p-3 text-slate-100">
        <p>{message}</p>
        <OpsInput
          label={t('god.confirmType')}
          value={word}
          onChange={(e) => setWord(e.target.value)}
          autoComplete="off"
          data-autofocus
        />
        <div className="flex justify-end gap-2">
          <OpsButton onClick={close}>{t('common.cancel')}</OpsButton>
          <OpsButton
            tone="danger"
            disabled={word.trim().toUpperCase() !== 'GOD'}
            onClick={() => {
              setWord('');
              onConfirm();
            }}
          >
            {t('common.confirm')}
          </OpsButton>
        </div>
      </div>
    </ScrollModal>
  );
}
