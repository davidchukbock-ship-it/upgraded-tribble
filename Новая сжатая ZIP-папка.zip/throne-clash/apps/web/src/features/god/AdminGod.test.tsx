import { act, cleanup, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import type { AdminStatsDto, AdminUserDto, GodPlayerDto } from '@tc/shared';
import { initI18n } from '../../lib/i18n';
import { useToasts } from '../../store/toast';
import {
  apiError,
  installFakeApi,
  json,
  makeCastle,
  makeInventory,
  makeUser,
} from '../../test-utils/fake-api';
import { renderApp, resetAuth, signIn } from '../../test-utils/render';

beforeAll(async () => {
  await initI18n('ru');
});
beforeEach(() => useToasts.setState({ items: [] }));
afterEach(() => {
  resetAuth();
  vi.unstubAllGlobals();
});

const adminUser = (over: Partial<AdminUserDto> = {}): AdminUserDto => ({
  id: 'u2',
  nickname: 'Борис',
  email: 'b@example.com',
  role: 'PLAYER',
  isGuest: false,
  isBot: false,
  bannedUntil: null,
  banReason: null,
  mutedUntil: null,
  createdAt: '2026-01-01T00:00:00.000Z',
  lastLoginAt: null,
  ...over,
});
const page = <T,>(items: T[]) => ({ items, page: 1, pageSize: 10, total: items.length });
const flow = { gold: 5, wood: 6, stone: 7, food: 8, gems: 9 };
const stats: AdminStatsDto = {
  users: { total: 42, guests: 3, bots: 24, banned: 1, muted: 2 },
  activity: { new24h: 5, new7d: 9, active24h: 7, online: 4 },
  economy: { gained: flow, spent: flow },
  reportsOpen: 2,
};
const asAdmin = () => signIn({ user: makeUser({ role: 'ADMIN' }) });
const asOwner = () => signIn({ user: makeUser({ role: 'OWNER', id: 'o1', nickname: 'Хозяин' }) });

describe('админ-панель', () => {
  it('игроку сообщается о нехватке прав и запросов не делает', async () => {
    signIn();
    const { calls } = installFakeApi({});
    renderApp('/admin');
    expect(await screen.findByRole('alert')).toHaveTextContent('Недостаточно прав');
    expect(calls).toHaveLength(0);
  });

  it('пункт «Админка» есть в меню администратора и отсутствует у игрока', async () => {
    asAdmin();
    installFakeApi({ 'GET /api/admin/stats': () => json(200, stats) });
    renderApp('/admin');
    await userEvent.click(await screen.findByRole('button', { name: 'Настройки и меню' }));
    expect(await screen.findByRole('link', { name: 'Админка' })).toBeInTheDocument();
    cleanup();
    resetAuth();
    signIn();
    installFakeApi({});
    renderApp('/castle');
    await userEvent.click(await screen.findByRole('button', { name: 'Настройки и меню' }));
    await screen.findByRole('dialog');
    expect(screen.queryByRole('link', { name: 'Админка' })).toBeNull();
  });

  it('сводка: игроки, активность и экономика', async () => {
    asAdmin();
    installFakeApi({ 'GET /api/admin/stats': () => json(200, stats) });
    renderApp('/admin');
    expect(
      await screen.findByRole('heading', { level: 1, name: 'Панель администратора' }),
    ).toBeInTheDocument();
    expect(await screen.findByText('42')).toBeInTheDocument();
    const table = screen.getByRole('table', { name: 'Экономика за 24 часа' });
    expect(within(table).getByRole('row', { name: /Золото 5 5/ })).toBeInTheDocument();
    expect(screen.getByText('Действия режима бога не учитываются.')).toBeInTheDocument();
  });

  it('блокировка: форма с причиной отправляет запрос, ошибка сервера показывается', async () => {
    asAdmin();
    const { calls } = installFakeApi({
      'GET /api/admin/stats': () => json(200, stats),
      'GET /api/admin/users?page=1&pageSize=10': () => json(200, page([adminUser()])),
      'POST /api/admin/users/u2/ban': () =>
        json(200, adminUser({ bannedUntil: '2099-01-01T00:00:00.000Z' })),
    });
    renderApp('/admin');
    await userEvent.click(await screen.findByRole('tab', { name: 'Игроки' }));
    await userEvent.click(await screen.findByRole('button', { name: 'Бан: Борис' }));
    const dialog = await screen.findByRole('dialog');
    await userEvent.type(within(dialog).getByLabelText('Причина'), 'читерство');
    await userEvent.click(within(dialog).getByRole('button', { name: 'Подтвердить' }));
    await waitFor(() => expect(calls.some((c) => c.method === 'POST')).toBe(true));
    expect(calls.find((c) => c.method === 'POST')?.body).toEqual({
      hours: 24,
      reason: 'читерство',
    });
  });

  it('заблокированный: показан бан и причина, доступно «Снять бан»', async () => {
    asAdmin();
    const { calls } = installFakeApi({
      'GET /api/admin/stats': () => json(200, stats),
      'GET /api/admin/users?page=1&pageSize=10': () =>
        json(
          200,
          page([adminUser({ bannedUntil: '2099-01-01T00:00:00.000Z', banReason: 'спам' })]),
        ),
      'POST /api/admin/users/u2/unban': () => json(200, adminUser()),
    });
    renderApp('/admin');
    await userEvent.click(await screen.findByRole('tab', { name: 'Игроки' }));
    expect(await screen.findByText('спам')).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: 'Снять бан: Борис' }));
    await waitFor(() => expect(calls.some((c) => c.path.endsWith('/unban'))).toBe(true));
  });

  it('кристаллы поддержки: идемпотентный запрос', async () => {
    asAdmin();
    const { calls } = installFakeApi({
      'GET /api/admin/stats': () => json(200, stats),
      'GET /api/admin/users?page=1&pageSize=10': () => json(200, page([adminUser()])),
      'POST /api/admin/users/u2/grant': () => json(200, makeCastle()),
    });
    renderApp('/admin');
    await userEvent.click(await screen.findByRole('tab', { name: 'Игроки' }));
    await userEvent.click(await screen.findByRole('button', { name: 'Кристаллы: Борис' }));
    const dialog = await screen.findByRole('dialog');
    await userEvent.type(within(dialog).getByLabelText('Причина'), 'компенсация');
    await userEvent.click(within(dialog).getByRole('button', { name: 'Подтвердить' }));
    await waitFor(() => expect(calls.some((c) => c.method === 'POST')).toBe(true));
    const post = calls.find((c) => c.method === 'POST')!;
    expect(post.body).toEqual({ amount: 100, reason: 'компенсация' });
    expect(post.headers['Idempotency-Key']).toMatch(/^[0-9a-f-]{36}$/);
  });

  it('поиск игроков, жалобы, журнал и аудит', async () => {
    asAdmin();
    const { calls } = installFakeApi({
      'GET /api/admin/stats': () => json(200, stats),
      'GET /api/admin/users?q=%D0%B1%D0%BE%D1%80&page=1&pageSize=10': () =>
        json(200, page([adminUser()])),
      'GET /api/admin/users?page=1&pageSize=10': () => json(200, page([])),
      'GET /api/admin/reports?page=1&pageSize=10': () =>
        json(
          200,
          page([
            {
              id: 'r1',
              reason: 'оскорбление',
              createdAt: '2026-01-01T00:00:00.000Z',
              reporter: { id: 'u1', nickname: 'Артур' },
              author: { id: 'u2', nickname: 'Борис' },
              message: {
                id: 'm1',
                channel: 'world',
                text: 'плохие слова',
                createdAt: '2026-01-01T00:00:00.000Z',
              },
            },
          ]),
        ),
      'GET /api/admin/logs?page=1&pageSize=15': () =>
        json(
          200,
          page([
            {
              kind: 'action_flood',
              userId: 'u2',
              nickname: 'Борис',
              ip: '1.2.3.4',
              details: { path: '/x' },
              createdAt: '2026-01-01T00:00:00.000Z',
            },
          ]),
        ),
      'GET /api/admin/logs?kind=chat_flood&page=1&pageSize=15': () => json(200, page([])),
      'GET /api/admin/audit?page=1&pageSize=15': () =>
        json(
          200,
          page([
            {
              id: 'a1',
              scope: 'admin',
              actor: { id: 'o', nickname: 'Модератор' },
              action: 'ban',
              target: { id: 'u2', nickname: 'Борис' },
              params: { reason: 'x' },
              before: null,
              after: null,
              ip: '1.1.1.1',
              createdAt: '2026-01-01T00:00:00.000Z',
            },
          ]),
        ),
    });
    renderApp('/admin');
    await userEvent.click(await screen.findByRole('tab', { name: 'Игроки' }));
    await userEvent.type(await screen.findByLabelText('Поиск'), 'бор');
    await userEvent.click(screen.getByRole('button', { name: 'Найти' }));
    expect(await screen.findByText('b@example.com', { exact: false })).toBeInTheDocument();

    await userEvent.click(screen.getByRole('tab', { name: 'Жалобы' }));
    expect(await screen.findByText('плохие слова')).toBeInTheDocument();
    expect(screen.getByText(/Жалоба от Артур: оскорбление/)).toBeInTheDocument();

    await userEvent.click(screen.getByRole('tab', { name: 'Журнал' }));
    expect(await screen.findByRole('cell', { name: 'action_flood' })).toBeInTheDocument();
    await userEvent.selectOptions(screen.getByLabelText('Вид события'), 'chat_flood');
    await waitFor(() => expect(calls.some((c) => c.path.includes('kind=chat_flood'))).toBe(true));

    await userEvent.click(screen.getByRole('tab', { name: 'Аудит' }));
    expect(await screen.findByText('ban', { selector: 'span.font-mono' })).toBeInTheDocument();
    expect(screen.getByText('Модератор')).toBeInTheDocument();
  });
});

const player = (over: Partial<GodPlayerDto> = {}): GodPlayerDto => ({
  user: adminUser(),
  castle: makeCastle(),
  inventory: makeInventory(),
  godTouched: false,
  snapshots: [],
  ...over,
});
const SESSION = { expiresAt: '2099-01-01T00:00:00.000Z', totpRequired: false };
const godRoutes = (extra: Parameters<typeof installFakeApi>[0] = {}) => ({
  'GET /api/god/session': () => json(200, SESSION),
  'GET /api/god/players?q=&page=1&pageSize=8': () =>
    json(200, page([adminUser({ id: 'o1', nickname: 'Хозяин', role: 'OWNER' }), adminUser()])),
  'GET /api/god/players/o1': () =>
    json(200, player({ user: adminUser({ id: 'o1', nickname: 'Хозяин', role: 'OWNER' }) })),
  'GET /api/god/players/u2': () => json(200, player()),
  ...extra,
});

describe('режим бога: допуск на клиенте', () => {
  it('обычного игрока и администратора отправляет на главную, запросов к /api/god не делает', async () => {
    for (const sign of [() => signIn(), asAdmin]) {
      sign();
      const { calls } = installFakeApi({});
      const { router, unmount } = renderApp('/god');
      await waitFor(() => expect(router.state.location.pathname).toBe('/'));
      expect(calls.filter((c) => c.path.includes('/api/god'))).toHaveLength(0);
      unmount();
      resetAuth();
    }
  });

  it('режим выключен на сервере (404) — ведёт себя как несуществующая страница', async () => {
    asOwner();
    installFakeApi({ 'GET /api/god/session': () => apiError(404, 'ERR_NOT_FOUND') });
    const { router } = renderApp('/god');
    await waitFor(() => expect(router.state.location.pathname).toBe('/'));
  });

  it('без сессии режима бога — форма входа; неверный пароль — сообщение', async () => {
    asOwner();
    const { calls } = installFakeApi({
      'GET /api/god/session': () => apiError(401, 'ERR_UNAUTHORIZED'),
      'POST /api/god/login': () => apiError(401, 'ERR_INVALID_CREDENTIALS'),
    });
    renderApp('/god');
    expect(await screen.findByRole('heading', { name: 'Вход в режим бога' })).toBeInTheDocument();
    expect(document.querySelector('meta[name="robots"]')?.getAttribute('content')).toContain(
      'noindex',
    );
    await userEvent.type(screen.getByLabelText('Пароль режима бога'), 'wrong-wrong');
    await userEvent.click(screen.getByRole('button', { name: 'Войти' }));
    await waitFor(() =>
      expect(useToasts.getState().items.map((i) => i.message)).toContain('Неверные данные'),
    );
    expect(calls.find((c) => c.method === 'POST')?.body).toEqual({ password: 'wrong-wrong' });
  });

  it('блокировка после неудач показывает срок', async () => {
    asOwner();
    installFakeApi({
      'GET /api/god/session': () => apiError(401, 'ERR_UNAUTHORIZED'),
      'POST /api/god/login': () => apiError(429, 'ERR_RATE_LIMITED', { retryAfterSeconds: 900 }),
    });
    renderApp('/god');
    await userEvent.type(await screen.findByLabelText('Пароль режима бога'), 'x');
    await userEvent.click(screen.getByRole('button', { name: 'Войти' }));
    await waitFor(() =>
      expect(useToasts.getState().items.map((i) => i.message)).toContain(
        'Слишком много попыток: вход закрыт на 15 мин',
      ),
    );
  });

  it('верный пароль (и код) открывает панель', async () => {
    asOwner();
    let logged = false;
    const { calls } = installFakeApi({
      ...godRoutes(),
      'GET /api/god/session': () =>
        logged ? json(200, SESSION) : apiError(401, 'ERR_UNAUTHORIZED'),
      'POST /api/god/login': () => {
        logged = true;
        return json(200, SESSION);
      },
    });
    renderApp('/god');
    await userEvent.type(await screen.findByLabelText('Пароль режима бога'), 'correct-password');
    await userEvent.type(screen.getByLabelText('Код TOTP (если включён)'), '123456');
    await userEvent.click(screen.getByRole('button', { name: 'Войти' }));
    expect(await screen.findByText('GOD MODE')).toBeInTheDocument();
    expect(calls.find((c) => c.method === 'POST')?.body).toEqual({
      password: 'correct-password',
      totp: '123456',
    });
  });
});

describe('режим бога: панель', () => {
  it('выбор игрока и выдача ресурсов: тело запроса и ключ идемпотентности', async () => {
    asOwner();
    const { calls } = installFakeApi({
      ...godRoutes(),
      'POST /api/god/players/u2/act': () => json(200, { castle: makeCastle() }),
    });
    renderApp('/god');
    await userEvent.click(await screen.findByRole('button', { name: /Борис/ }));
    const form = await screen.findByRole('form', { name: 'Ресурсы' });
    await userEvent.selectOptions(within(form).getByLabelText('Ресурс'), 'gems');
    await userEvent.clear(within(form).getByLabelText('Количество'));
    await userEvent.type(within(form).getByLabelText('Количество'), '777');
    await userEvent.click(within(form).getByRole('button', { name: 'Применить' }));
    await waitFor(() => expect(calls.some((c) => c.method === 'POST')).toBe(true));
    const post = calls.find((c) => c.method === 'POST')!;
    expect(post.body).toEqual({ type: 'resources', op: 'give', resource: 'gems', amount: 777 });
    expect(post.headers['Idempotency-Key']).toMatch(/^[0-9a-f-]{36}$/);
  });

  it('быстрые действия и время', async () => {
    asOwner();
    const { calls } = installFakeApi({
      ...godRoutes(),
      'POST /api/god/players/o1/act': () => json(200, { castle: makeCastle() }),
    });
    renderApp('/god');
    await userEvent.click(await screen.findByRole('button', { name: 'Завершить все очереди' }));
    await userEvent.click(screen.getByRole('button', { name: 'Время +1d' }));
    await waitFor(() => expect(calls.filter((c) => c.method === 'POST')).toHaveLength(2));
    expect(calls.filter((c) => c.method === 'POST').map((c) => c.body)).toEqual([
      { type: 'finish' },
      { type: 'time', seconds: 86_400 },
    ]);
  });

  it('сброс замка требует набрать GOD', async () => {
    asOwner();
    const { calls } = installFakeApi({
      ...godRoutes(),
      'POST /api/god/players/o1/act': () => json(200, { castle: makeCastle() }),
    });
    renderApp('/god');
    await userEvent.click(await screen.findByRole('button', { name: 'Сбросить замок' }));
    const dialog = await screen.findByRole('alertdialog');
    const confirm = within(dialog).getByRole('button', { name: 'Подтвердить' });
    expect(confirm).toBeDisabled();
    await userEvent.type(within(dialog).getByLabelText('Для подтверждения наберите GOD'), 'god');
    expect(confirm).toBeEnabled();
    expect(calls.filter((c) => c.method === 'POST')).toHaveLength(0);
    await userEvent.click(confirm);
    await waitFor(() => expect(calls.some((c) => c.method === 'POST')).toBe(true));
    expect(calls.find((c) => c.method === 'POST')?.body).toEqual({ type: 'reset' });
  });

  it('палитра Ctrl+K разбирает команду и выполняет над выбранным игроком', async () => {
    asOwner();
    const { calls } = installFakeApi({
      ...godRoutes(),
      'POST /api/god/players/o1/act': () => json(200, { castle: makeCastle() }),
    });
    renderApp('/god');
    await screen.findByText('GOD MODE');
    await userEvent.keyboard('{Control>}k{/Control}');
    const dialog = await screen.findByRole('dialog', { name: 'Палитра команд' });
    const input = within(dialog).getByLabelText('Команда');
    await userEvent.type(input, 'dance now');
    expect(within(dialog).getByRole('button', { name: 'Выполнить' })).toBeDisabled();
    await userEvent.clear(input);
    await userEvent.type(input, 'give gold 1m');
    expect(within(dialog).getByText('→ give gold 1000000')).toBeInTheDocument();
    await userEvent.click(within(dialog).getByRole('button', { name: 'Выполнить' }));
    await waitFor(() => expect(calls.some((c) => c.method === 'POST')).toBe(true));
    expect(calls.find((c) => c.method === 'POST')?.body).toEqual({
      type: 'resources',
      op: 'give',
      resource: 'gold',
      amount: 1_000_000,
    });
  });

  it('вход под игроком: токен подменяет сессию, баннер напоминает и возвращает владельца', async () => {
    asOwner();
    const token = `h.${btoa(JSON.stringify({ act: { sub: 'o1' } }))}.s`;
    installFakeApi({
      ...godRoutes(),
      'POST /api/god/players/u2/impersonate': () =>
        json(200, {
          accessToken: token,
          expiresIn: 600,
          user: makeUser({ id: 'u2', nickname: 'Борис' }),
          serverTime: new Date().toISOString(),
        }),
      'POST /api/auth/refresh': () =>
        json(200, {
          accessToken: 'owner-token',
          expiresIn: 900,
          user: makeUser({ role: 'OWNER', id: 'o1' }),
          serverTime: new Date().toISOString(),
        }),
    });
    const { router } = renderApp('/god');
    await userEvent.click(await screen.findByRole('button', { name: /Борис/ }));
    await userEvent.click(await screen.findByRole('button', { name: 'Войти под игроком' }));
    const banner = await screen.findByRole('alert');
    expect(banner).toHaveTextContent('Вы действуете от имени игрока Борис');
    expect(router.state.location.pathname).toBe('/castle');
    await userEvent.click(within(banner).getByRole('button', { name: 'Выйти из чужого аккаунта' }));
    await waitFor(() => expect(router.state.location.pathname).toBe('/god'));
  });

  it('выход закрывает сессию', async () => {
    asOwner();
    let out = false;
    const { calls } = installFakeApi({
      ...godRoutes(),
      'GET /api/god/session': () => (out ? apiError(401, 'ERR_UNAUTHORIZED') : json(200, SESSION)),
      'POST /api/god/logout': () => {
        out = true;
        return json(204, null);
      },
    });
    renderApp('/god');
    await userEvent.click(await screen.findByRole('button', { name: 'Выйти' }));
    await waitFor(() => expect(calls.some((c) => c.path === '/api/god/logout')).toBe(true));
  });

  it('автовыход по бездействию', async () => {
    asOwner();
    vi.useFakeTimers({ shouldAdvanceTime: true });
    try {
      const { calls } = installFakeApi({
        ...godRoutes(),
        'POST /api/god/logout': () => json(204, null),
      });
      renderApp('/god');
      await screen.findByText('GOD MODE');
      await act(async () => {
        await vi.advanceTimersByTimeAsync(30 * 60_000 + 1000);
      });
      await waitFor(() => expect(calls.some((c) => c.path === '/api/god/logout')).toBe(true));
    } finally {
      vi.useRealTimers();
    }
  });

  it('симулятор, баланс, аудит, отладка', async () => {
    asOwner();
    const rev = {
      id: 'r1',
      createdAt: '2026-01-01T00:00:00.000Z',
      note: 'manual',
      balance: { buildCost: 2 },
    };
    const bal = {
      balance: {
        buildCost: 1,
        buildTime: 1,
        trainCost: 1,
        trainTime: 1,
        researchCost: 1,
        researchTime: 1,
        production: 1,
        attack: 1,
        defense: 1,
        health: 1,
      },
      updatedAt: null,
      revisions: [rev],
    };
    const { calls } = installFakeApi({
      ...godRoutes(),
      'POST /api/god/simulate': () =>
        json(200, {
          seed: 1,
          forcedBonus: 0.5,
          result: {
            winner: 'attacker',
            rounds: [{}, {}],
            attacker: { remaining: {}, fallen: {} },
            defender: { remaining: {}, fallen: {} },
          },
        }),
      'GET /api/god/balance': () => json(200, bal),
      'PUT /api/god/balance': () => json(200, bal),
      'POST /api/god/balance/rollback': () => json(200, bal),
      'GET /api/god/audit?page=1&pageSize=15': () => json(200, page([])),
      'GET /api/god/debug': () =>
        json(200, {
          uptimeSeconds: 120,
          memoryMb: 90,
          online: 3,
          counts: { users: 10, castles: 9, marches: 0, guilds: 1, chatMessages: 5 },
          redis: 'off',
          serverTime: new Date().toISOString(),
        }),
    });
    renderApp('/god');
    await userEvent.click(await screen.findByRole('tab', { name: 'Симулятор боя' }));
    await userEvent.selectOptions(screen.getByLabelText('Принудительный исход'), 'attacker');
    await userEvent.click(screen.getByRole('button', { name: 'Провести бой' }));
    expect(await screen.findByText(/Победитель: Нападающий · Раундов: 2/)).toBeInTheDocument();
    expect(screen.getByText(/исход подогнан бонусом \+50%/)).toBeInTheDocument();
    expect(calls.find((c) => c.path === '/api/god/simulate')?.body).toMatchObject({
      force: 'attacker',
      seed: 1,
    });

    await userEvent.click(screen.getByRole('tab', { name: 'Баланс' }));
    const cost = await screen.findByLabelText('Цена построек');
    await userEvent.clear(cost);
    await userEvent.type(cost, '2');
    await userEvent.click(screen.getByRole('button', { name: 'Применить' }));
    await waitFor(() => expect(calls.some((c) => c.method === 'PUT')).toBe(true));
    expect((calls.find((c) => c.method === 'PUT')?.body as Record<string, number>).buildCost).toBe(
      2,
    );
    await userEvent.click(screen.getAllByRole('button', { name: /Откатить/ })[0]!);
    await waitFor(() => expect(calls.some((c) => c.path.endsWith('/rollback'))).toBe(true));

    await userEvent.click(screen.getByRole('tab', { name: 'Аудит' }));
    expect(await screen.findByText('Ничего нет')).toBeInTheDocument();
    await userEvent.click(screen.getByRole('tab', { name: 'Отладка' }));
    expect(await screen.findByText('90 MB')).toBeInTheDocument();
  });

  it('мир: сброс клетки и объявление', async () => {
    asOwner();
    const { calls } = installFakeApi({
      ...godRoutes(),
      'POST /api/god/map/cell-reset': () => json(204, null),
      'POST /api/god/chat/announce': () => json(204, null),
    });
    renderApp('/god');
    await userEvent.click(await screen.findByRole('tab', { name: 'Мир' }));
    await userEvent.click(screen.getByRole('button', { name: 'Применить' }));
    await waitFor(() => expect(calls.some((c) => c.path.endsWith('cell-reset'))).toBe(true));
    expect(calls.find((c) => c.path.endsWith('cell-reset'))?.body).toEqual({ x: 50, y: 50 });
    await userEvent.type(screen.getByLabelText('Текст'), 'Перезагрузка');
    await userEvent.click(screen.getByRole('button', { name: 'Отправить' }));
    await waitFor(() => expect(calls.some((c) => c.path.endsWith('announce'))).toBe(true));
  });
});

describe('горячая клавиша владельца', () => {
  it('Ctrl+Shift+G открывает режим бога у владельца и ничего не делает у игрока', async () => {
    asOwner();
    installFakeApi({ ...godRoutes() });
    const { router, unmount } = renderApp('/castle');
    await userEvent.keyboard('{Control>}{Shift>}g{/Shift}{/Control}');
    await waitFor(() => expect(router.state.location.pathname).toBe('/god'));
    unmount();
    resetAuth();
    signIn();
    installFakeApi({});
    const second = renderApp('/castle');
    await userEvent.keyboard('{Control>}{Shift>}g{/Shift}{/Control}');
    expect(second.router.state.location.pathname).toBe('/castle');
  });
});
