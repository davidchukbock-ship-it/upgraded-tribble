import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useCallback, useEffect, useRef, useState, type FormEvent } from 'react';
import { useTranslation } from 'react-i18next';
import { Link, Navigate } from 'react-router-dom';
import { describeGodAction, parseGodCommand } from '@tc/shared';
import { ApiError } from '../../lib/api';
import { isImpersonating, useAuth } from '../../store/auth';
import { useToasts } from '../../store/toast';
import { ScrollModal, Tabs, ToastHost } from '../../ui';
import { AuditTable } from '../admin/AdminPage';
import { OpsButton, OpsInput, OpsPanel } from '../admin/ops';
import { errorMessage } from '../auth/errors';
import { godApi } from './api';
import { BalanceTab, DebugTab, SimulatorTab, WorldTab } from './OtherTabs';
import { PlayersTab, useGodAct } from './PlayersTab';

/** Без действий дольше этого времени панель сама закрывается (как и серверная сессия). */
const IDLE_MS = 30 * 60_000;

const EXAMPLES = [
  'give gold 1000000',
  'build barracks 20',
  'time +1d',
  'teleport 50 50',
  'spawn army cavalry 500',
  'research all',
  'hero 30',
  'finish',
];

function useNoIndex() {
  useEffect(() => {
    const meta = document.createElement('meta');
    meta.name = 'robots';
    meta.content = 'noindex, nofollow';
    document.head.appendChild(meta);
    return () => meta.remove();
  }, []);
}

/** Ctrl+K: строка команд над выбранным игроком. */
function CommandPalette({
  open,
  onClose,
  target,
}: {
  open: boolean;
  onClose: () => void;
  target: string | null;
}) {
  const { t } = useTranslation();
  const [text, setText] = useState('');
  const [error, setError] = useState<string | null>(null);
  const act = useGodAct(target);
  const parsed = text.trim() ? parseGodCommand(text) : null;
  const run = (e: FormEvent) => {
    e.preventDefault();
    if (!parsed || !parsed.ok) return setError(t('god.badCommand'));
    if (!target) return setError(t('god.pickPlayer'));
    setError(null);
    act.mutate(parsed.action, {
      onSuccess: () => {
        setText('');
        onClose();
      },
    });
  };
  return (
    <ScrollModal open={open} title={t('god.palette')} onClose={onClose}>
      <form
        onSubmit={run}
        className="flex flex-col gap-3 rounded-lg bg-slate-800 p-3 text-slate-100"
      >
        <OpsInput
          label={t('god.command')}
          value={text}
          onChange={(e) => {
            setText(e.target.value);
            setError(null);
          }}
          placeholder="give gold 1000000"
          autoComplete="off"
          data-autofocus
        />
        <p className="text-xs" role="status">
          {parsed?.ok ? `→ ${describeGodAction(parsed.action)}` : (error ?? ' ')}
        </p>
        <ul className="flex flex-wrap gap-1" aria-label={t('god.examples')}>
          {EXAMPLES.map((ex) => (
            <li key={ex}>
              <button
                type="button"
                className="rounded bg-slate-700 px-2 py-1 font-mono text-xs hover:bg-slate-600"
                onClick={() => setText(ex)}
              >
                {ex}
              </button>
            </li>
          ))}
        </ul>
        <div className="flex justify-end">
          <OpsButton type="submit" tone="ok" disabled={act.isPending || !parsed?.ok}>
            {t('god.run')}
          </OpsButton>
        </div>
      </form>
    </ScrollModal>
  );
}

function Panel({ ownerId, onExit }: { ownerId: string; onExit: () => void }) {
  const { t } = useTranslation();
  const [tab, setTab] = useState('players');
  const [target, setTarget] = useState<string | null>(ownerId);
  const [palette, setPalette] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const exit = useMutation({ mutationFn: godApi.logout, onSettled: onExit });

  // Автовыход по бездействию: любое действие пользователя сбрасывает отсчёт
  const arm = useCallback(() => {
    clearTimeout(timer.current);
    timer.current = setTimeout(() => exit.mutate(), IDLE_MS);
  }, [exit]);
  useEffect(() => {
    arm();
    const events = ['keydown', 'pointerdown'] as const;
    for (const e of events) window.addEventListener(e, arm);
    return () => {
      clearTimeout(timer.current);
      for (const e of events) window.removeEventListener(e, arm);
    };
  }, [arm]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setPalette(true);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-4 p-3 md:p-6">
      <header className="flex flex-wrap items-center gap-3">
        <span className="rounded bg-red-700 px-3 py-1 font-mono text-sm font-bold tracking-widest text-white">
          GOD MODE
        </span>
        <h1 className="font-body text-xl font-bold text-slate-100">{t('god.title')}</h1>
        <OpsButton className="ml-auto" onClick={() => setPalette(true)}>
          {t('god.palette')}{' '}
          <kbd className="ml-1 rounded bg-slate-800 px-1 font-mono text-xs">Ctrl K</kbd>
        </OpsButton>
        <Link
          to="/castle"
          className="rounded-md bg-slate-600 px-3 py-2 text-sm font-semibold text-white hover:bg-slate-500"
        >
          {t('god.toGame')}
        </Link>
        <OpsButton tone="danger" onClick={() => exit.mutate()}>
          {t('god.exit')}
        </OpsButton>
      </header>
      <Tabs
        value={tab}
        onChange={setTab}
        items={[
          {
            id: 'players',
            label: t('god.tab.players'),
            content: <PlayersTab target={target} onTarget={setTarget} />,
          },
          { id: 'world', label: t('god.tab.world'), content: <WorldTab /> },
          { id: 'sim', label: t('god.tab.sim'), content: <SimulatorTab /> },
          { id: 'balance', label: t('god.tab.balance'), content: <BalanceTab /> },
          {
            id: 'audit',
            label: t('god.tab.audit'),
            content: (
              <OpsPanel title={t('god.audit')}>
                <AuditTable scopeLabel load={(p) => godApi.audit(p)} queryKey="god" />
              </OpsPanel>
            ),
          },
          { id: 'debug', label: t('god.tab.debug'), content: <DebugTab /> },
        ]}
      />
      <CommandPalette open={palette} onClose={() => setPalette(false)} target={target} />
    </div>
  );
}

function Login({ onDone }: { onDone: () => void }) {
  const { t } = useTranslation();
  const push = useToasts((s) => s.push);
  const login = useMutation({
    mutationFn: (v: { password: string; totp: string }) =>
      godApi.login(v.password, v.totp || undefined),
    onSuccess: onDone,
    onError: (err) => {
      if (err instanceof ApiError && err.status === 429) {
        const wait =
          (err.details as { retryAfterSeconds?: number } | undefined)?.retryAfterSeconds ?? 900;
        push(t('god.blocked', { minutes: Math.ceil(wait / 60) }), 'error');
      } else if (err instanceof ApiError && err.status === 401)
        push(t('god.wrongCredentials'), 'error');
      else push(errorMessage(t, err), 'error');
    },
  });
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        const f = new FormData(e.currentTarget);
        login.mutate({
          password: String(f.get('password') ?? ''),
          totp: String(f.get('totp') ?? '').trim(),
        });
      }}
      className="mx-auto mt-16 flex w-full max-w-sm flex-col gap-3 rounded-lg border border-slate-600 bg-slate-800 p-5 text-slate-100"
    >
      <span className="self-start rounded bg-red-700 px-3 py-1 font-mono text-sm font-bold tracking-widest text-white">
        GOD MODE
      </span>
      <h1 className="font-body text-xl font-bold">{t('god.loginTitle')}</h1>
      <OpsInput
        name="password"
        type="password"
        label={t('god.password')}
        autoComplete="current-password"
        required
        data-autofocus
      />
      <OpsInput
        name="totp"
        inputMode="numeric"
        pattern="\d{6}"
        maxLength={6}
        label={t('god.totp')}
        autoComplete="one-time-code"
      />
      <OpsButton type="submit" tone="danger" disabled={login.isPending}>
        {t('god.enter')}
      </OpsButton>
    </form>
  );
}

/**
 * Режим бога `/god`. На эту страницу нет ссылок в интерфейсе игры; не-владелец видит то же, что и по
 * любому несуществующему адресу. Все проверки — на сервере, клиент лишь показывает форму и панель.
 */
export function GodPage() {
  useNoIndex();
  const { t } = useTranslation();
  const client = useQueryClient();
  const user = useAuth((s) => s.user);
  const status = useAuth((s) => s.status);
  const impersonating = useAuth((s) => isImpersonating(s.accessToken));
  const isOwner = user?.role === 'OWNER';
  const session = useQuery({
    queryKey: ['god', 'session'],
    queryFn: godApi.session,
    enabled: isOwner,
    retry: false,
    refetchOnWindowFocus: false,
  });

  if (status === 'unknown')
    return (
      <p role="status" className="pt-16 text-center text-slate-200">
        {t('common.loading')}
      </p>
    );
  // Владелец вошёл под игроком (страница уходит на /castle): не считать это чужим доступом
  if (impersonating) return null;
  if (!isOwner) return <Navigate to="/" replace />;
  if (session.isPending)
    return (
      <p role="status" className="pt-16 text-center text-slate-200">
        {t('common.loading')}
      </p>
    );
  // Режим выключен на сервере: 404 — ведём себя как на несуществующем адресе
  if (session.error instanceof ApiError && session.error.status === 404)
    return <Navigate to="/" replace />;

  const authed = !!session.data;
  return (
    <div className="min-h-screen border-4 border-red-700 bg-slate-900" data-god="true">
      {authed ? (
        <Panel
          ownerId={user!.id}
          onExit={() => {
            void client.invalidateQueries({ queryKey: ['god'] });
            void client.removeQueries({ queryKey: ['god'] });
          }}
        />
      ) : (
        <Login onDone={() => void session.refetch()} />
      )}
      <ToastHost />
    </div>
  );
}
