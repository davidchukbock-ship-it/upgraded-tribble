import type {
  AdminStatsDto,
  AdminUserDto,
  AdminUserPageDto,
  AuditPageDto,
  CastleDto,
  ChatReportDto,
  SecurityLogEntryDto,
} from '@tc/shared';
import { apiFetch } from '../../lib/api';

const key = () => ({ 'Idempotency-Key': crypto.randomUUID() });
const qs = (o: Record<string, string | number | undefined>): string => {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(o)) if (v !== undefined && v !== '') p.set(k, String(v));
  return p.toString();
};

export interface Page<T> {
  items: T[];
  page: number;
  pageSize: number;
  total: number;
}

export const adminApi = {
  stats: () => apiFetch<AdminStatsDto>('/api/admin/stats'),
  users: (q: string, page: number) =>
    apiFetch<AdminUserPageDto>(`/api/admin/users?${qs({ q, page, pageSize: 10 })}`),
  ban: (id: string, hours: number | null, reason: string) =>
    apiFetch<AdminUserDto>(`/api/admin/users/${id}/ban`, {
      method: 'POST',
      body: { hours, reason },
    }),
  unban: (id: string) => apiFetch<AdminUserDto>(`/api/admin/users/${id}/unban`, { method: 'POST' }),
  mute: (id: string, minutes: number, reason: string) =>
    apiFetch<AdminUserDto>(`/api/admin/users/${id}/mute`, {
      method: 'POST',
      body: { minutes, reason },
    }),
  unmute: (id: string) =>
    apiFetch<AdminUserDto>(`/api/admin/users/${id}/unmute`, { method: 'POST' }),
  grant: (id: string, amount: number, reason: string) =>
    apiFetch<CastleDto>(`/api/admin/users/${id}/grant`, {
      method: 'POST',
      body: { amount, reason },
      headers: key(),
    }),
  logs: (kind: string, page: number) =>
    apiFetch<Page<SecurityLogEntryDto>>(`/api/admin/logs?${qs({ kind, page, pageSize: 15 })}`),
  reports: (page: number) =>
    apiFetch<Page<ChatReportDto>>(`/api/admin/reports?${qs({ page, pageSize: 10 })}`),
  audit: (page: number) => apiFetch<AuditPageDto>(`/api/admin/audit?${qs({ page, pageSize: 15 })}`),
};
