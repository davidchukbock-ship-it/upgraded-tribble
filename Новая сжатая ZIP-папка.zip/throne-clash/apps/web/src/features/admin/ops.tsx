import {
  useId,
  type ButtonHTMLAttributes,
  type ReactNode,
  type SelectHTMLAttributes,
  type InputHTMLAttributes,
} from 'react';
import { useTranslation } from 'react-i18next';
import { cn } from '../../lib/cn';
import { dateLocale } from '../../lib/locales';

/**
 * Служебные компоненты админки и режима бога. Холодная сине-серая палитра намеренно отличается от тёплого
 * игрового интерфейса: сразу видно, что вы в служебной зоне (docs/ASSETS.md).
 */
export function OpsPanel({
  title,
  children,
  className,
  actions,
}: {
  title: string;
  children: ReactNode;
  className?: string;
  actions?: ReactNode;
}) {
  return (
    <section
      className={cn(
        'rounded-lg border border-slate-600 bg-slate-800 p-4 text-slate-100',
        className,
      )}
    >
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <h2 className="font-body text-base font-bold uppercase tracking-wide text-sky-300">
          {title}
        </h2>
        <div className="ml-auto flex flex-wrap gap-2">{actions}</div>
      </div>
      {children}
    </section>
  );
}

type Tone = 'default' | 'danger' | 'ok';
const TONE: Record<Tone, string> = {
  default: 'bg-slate-600 hover:bg-slate-500 text-white',
  danger: 'bg-red-700 hover:bg-red-600 text-white',
  ok: 'bg-emerald-700 hover:bg-emerald-600 text-white',
};

export function OpsButton({
  tone = 'default',
  className,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { tone?: Tone }) {
  return (
    <button
      type="button"
      className={cn(
        'min-h-[40px] rounded-md px-3 py-1.5 font-body text-sm font-semibold focus-visible:outline focus-visible:outline-2 focus-visible:outline-sky-300 disabled:cursor-not-allowed disabled:opacity-50',
        TONE[tone],
        className,
      )}
      {...rest}
    />
  );
}

const FIELD =
  'min-h-[40px] w-full rounded-md border border-slate-500 bg-slate-900 px-2 py-1 font-body text-sm text-slate-100 placeholder:text-slate-400 focus-visible:outline focus-visible:outline-2 focus-visible:outline-sky-300';

export function OpsInput({
  label,
  className,
  ...rest
}: InputHTMLAttributes<HTMLInputElement> & { label: string }) {
  const id = useId();
  return (
    <div className={cn('flex flex-col gap-1', className)}>
      <label htmlFor={id} className="text-xs font-semibold text-slate-300">
        {label}
      </label>
      <input id={id} className={FIELD} {...rest} />
    </div>
  );
}

export function OpsSelect({
  label,
  className,
  children,
  ...rest
}: SelectHTMLAttributes<HTMLSelectElement> & { label: string }) {
  const id = useId();
  return (
    <div className={cn('flex flex-col gap-1', className)}>
      <label htmlFor={id} className="text-xs font-semibold text-slate-300">
        {label}
      </label>
      <select id={id} className={FIELD} {...rest}>
        {children}
      </select>
    </div>
  );
}

export function Pager({
  page,
  total,
  pageSize,
  onPage,
}: {
  page: number;
  total: number;
  pageSize: number;
  onPage: (p: number) => void;
}) {
  const { t } = useTranslation();
  const pages = Math.max(1, Math.ceil(total / pageSize));
  if (pages <= 1) return null;
  return (
    <nav
      aria-label={t('report.pages')}
      className="mt-3 flex items-center justify-center gap-3 text-sm"
    >
      <OpsButton disabled={page <= 1} onClick={() => onPage(page - 1)}>
        {t('report.prev')}
      </OpsButton>
      <span>
        {page} / {pages}
      </span>
      <OpsButton disabled={page >= pages} onClick={() => onPage(page + 1)}>
        {t('report.next')}
      </OpsButton>
    </nav>
  );
}

export const when = (iso: string | null, lang: string): string =>
  iso
    ? new Date(iso).toLocaleString(dateLocale(lang), {
        day: '2-digit',
        month: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      })
    : '—';

/** Компактный вывод произвольных данных журнала. */
export function Json({ value }: { value: unknown }) {
  if (value === null || value === undefined) return <span className="text-slate-400">—</span>;
  return (
    <pre className="max-h-40 overflow-auto whitespace-pre-wrap break-words rounded bg-slate-900 p-2 font-mono text-xs text-slate-200">
      {JSON.stringify(value, null, 1)}
    </pre>
  );
}
