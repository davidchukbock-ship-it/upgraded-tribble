import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState, type FormEvent } from 'react';
import { useTranslation } from 'react-i18next';
import type { AdminUserDto, AuditPageDto } from '@tc/shared';
import { useAuth } from '../../store/auth';
import { useToasts } from '../../store/toast';
import { Badge, ScrollModal, Tabs } from '../../ui';
import { errorMessage } from '../auth/errors';
import { adminApi } from './api';
import { Json, OpsButton, OpsInput, OpsPanel, OpsSelect, Pager, when } from './ops';

type DialogKind = 'ban' | 'mute' | 'grant';

function StatsTab() {
  const { t } = useTranslation();
  const q = useQuery({
    queryKey: ['admin', 'stats'],
    queryFn: adminApi.stats,
    refetchInterval: 30_000,
  });
  if (!q.data) return <p role="status">{t('common.loading')}</p>;
  const s = q.data;
  const cell = (label: string, value: number) => (
    <div key={label} className="rounded-md bg-slate-900 p-3">
      <dt className="text-xs text-slate-300">{label}</dt>
      <dd className="font-display text-2xl font-bold text-sky-200">{value}</dd>
    </div>
  );
  const keys = ['gold', 'wood', 'stone', 'food', 'gems'] as const;
  return (
    <div className="flex flex-col gap-4">
      <OpsPanel title={t('admin.stats.players')}>
        <dl className="grid grid-cols-2 gap-2 sm:grid-cols-5">
          {cell(t('admin.stats.total'), s.users.total)}
          {cell(t('admin.stats.guests'), s.users.guests)}
          {cell(t('admin.stats.bots'), s.users.bots)}
          {cell(t('admin.stats.banned'), s.users.banned)}
          {cell(t('admin.stats.muted'), s.users.muted)}
        </dl>
      </OpsPanel>
      <OpsPanel title={t('admin.stats.activity')}>
        <dl className="grid grid-cols-2 gap-2 sm:grid-cols-5">
          {cell(t('admin.stats.new24h'), s.activity.new24h)}
          {cell(t('admin.stats.new7d'), s.activity.new7d)}
          {cell(t('admin.stats.active24h'), s.activity.active24h)}
          {cell(t('admin.stats.online'), s.activity.online)}
          {cell(t('admin.stats.reports'), s.reportsOpen)}
        </dl>
      </OpsPanel>
      <OpsPanel title={t('admin.stats.economy')}>
        <p className="pb-2 text-xs text-slate-300">{t('admin.stats.economyNote')}</p>
        <div
          className="overflow-x-auto"
          role="region"
          tabIndex={0}
          aria-label={t('admin.stats.economy')}
        >
          <table className="w-full min-w-[320px] text-left text-sm">
            <caption className="sr-only">{t('admin.stats.economy')}</caption>
            <thead>
              <tr className="border-b border-slate-600">
                <th scope="col" className="py-1">
                  {t('admin.stats.resource')}
                </th>
                <th scope="col" className="py-1 text-right">
                  {t('admin.stats.gained')}
                </th>
                <th scope="col" className="py-1 text-right">
                  {t('admin.stats.spent')}
                </th>
              </tr>
            </thead>
            <tbody>
              {keys.map((k) => (
                <tr key={k} className="border-b border-slate-700">
                  <th scope="row" className="py-1 font-semibold">
                    {t(`resource.${k}`)}
                  </th>
                  <td className="py-1 text-right tabular-nums">{s.economy.gained[k]}</td>
                  <td className="py-1 text-right tabular-nums">{s.economy.spent[k]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </OpsPanel>
    </div>
  );
}

function ActionDialog({
  kind,
  user,
  onClose,
}: {
  kind: DialogKind;
  user: AdminUserDto;
  onClose: () => void;
}) {
  const { t } = useTranslation();
  const push = useToasts((s) => s.push);
  const client = useQueryClient();
  const run = useMutation({
    mutationFn: (v: { amount: number | null; reason: string }): Promise<unknown> => {
      if (kind === 'ban') return adminApi.ban(user.id, v.amount, v.reason);
      if (kind === 'mute') return adminApi.mute(user.id, v.amount ?? 10, v.reason);
      return adminApi.grant(user.id, v.amount ?? 1, v.reason);
    },
    onSuccess: () => {
      push(t('admin.done'), 'success');
      void client.invalidateQueries({ queryKey: ['admin'] });
      onClose();
    },
    onError: (err) => push(errorMessage(t, err), 'error'),
  });
  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const raw = String(f.get('amount') ?? '');
    const forever = kind === 'ban' && f.get('forever') === 'on';
    run.mutate({ amount: forever ? null : Number(raw), reason: String(f.get('reason') ?? '') });
  };
  return (
    <ScrollModal open title={`${t(`admin.dialog.${kind}`)}: ${user.nickname}`} onClose={onClose}>
      <form
        onSubmit={submit}
        className="flex flex-col gap-3 rounded-lg bg-slate-800 p-3 text-slate-100"
      >
        <OpsInput
          name="amount"
          type="number"
          min={1}
          defaultValue={kind === 'grant' ? 100 : kind === 'mute' ? 30 : 24}
          label={t(`admin.dialog.${kind}Amount`)}
        />
        {kind === 'ban' && (
          <label className="flex items-center gap-2 text-sm">
            <input name="forever" type="checkbox" className="h-4 w-4" />
            {t('admin.dialog.forever')}
          </label>
        )}
        <OpsInput
          name="reason"
          label={t('admin.dialog.reason')}
          required
          minLength={3}
          maxLength={200}
        />
        <div className="flex justify-end gap-2">
          <OpsButton onClick={onClose}>{t('common.cancel')}</OpsButton>
          <OpsButton
            type="submit"
            tone={kind === 'grant' ? 'ok' : 'danger'}
            disabled={run.isPending}
          >
            {t('common.confirm')}
          </OpsButton>
        </div>
      </form>
    </ScrollModal>
  );
}

function PlayersTab() {
  const { t, i18n } = useTranslation();
  const push = useToasts((s) => s.push);
  const client = useQueryClient();
  const [q, setQ] = useState('');
  const [term, setTerm] = useState('');
  const [page, setPage] = useState(1);
  const [dialog, setDialog] = useState<{ kind: DialogKind; user: AdminUserDto } | null>(null);
  const list = useQuery({
    queryKey: ['admin', 'users', term, page],
    queryFn: () => adminApi.users(term, page),
  });
  const quick = useMutation({
    mutationFn: (v: { id: string; op: 'unban' | 'unmute' }) =>
      v.op === 'unban' ? adminApi.unban(v.id) : adminApi.unmute(v.id),
    onSuccess: () => {
      push(t('admin.done'), 'success');
      void client.invalidateQueries({ queryKey: ['admin'] });
    },
    onError: (err) => push(errorMessage(t, err), 'error'),
  });
  const now = Date.now();
  const active = (iso: string | null) => iso !== null && Date.parse(iso) > now;
  return (
    <OpsPanel title={t('admin.players')}>
      <form
        role="search"
        className="mb-3 flex items-end gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          setPage(1);
          setTerm(q.trim());
        }}
      >
        <OpsInput
          className="flex-1"
          label={t('admin.search')}
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder={t('admin.searchHint')}
          maxLength={60}
        />
        <OpsButton type="submit">{t('admin.find')}</OpsButton>
      </form>
      {list.isPending ? (
        <p role="status">{t('common.loading')}</p>
      ) : (
        <ul className="flex flex-col gap-2">
          {list.data?.items.map((u) => (
            <li
              key={u.id}
              className="flex flex-wrap items-center gap-2 rounded-md bg-slate-900 p-2"
            >
              <div className="min-w-[10rem] flex-1">
                <p className="font-semibold">
                  {u.nickname} {u.isBot && <Badge tone="stone">bot</Badge>}{' '}
                  {u.role !== 'PLAYER' && <Badge>{u.role}</Badge>}{' '}
                  {active(u.bannedUntil) && <Badge tone="red">{t('admin.banned')}</Badge>}{' '}
                  {active(u.mutedUntil) && <Badge tone="stone">{t('admin.muted')}</Badge>}
                </p>
                <p className="text-xs text-slate-300">
                  {u.email ?? t('profile.noEmail')} · {t('admin.lastLogin')}:{' '}
                  {when(u.lastLoginAt, i18n.language)}
                </p>
                {active(u.bannedUntil) && u.banReason && (
                  <p className="text-xs text-red-300">{u.banReason}</p>
                )}
              </div>
              <div className="flex flex-wrap gap-1.5">
                {active(u.bannedUntil) ? (
                  <OpsButton
                    onClick={() => quick.mutate({ id: u.id, op: 'unban' })}
                    aria-label={`${t('admin.unban')}: ${u.nickname}`}
                  >
                    {t('admin.unban')}
                  </OpsButton>
                ) : (
                  <OpsButton
                    tone="danger"
                    onClick={() => setDialog({ kind: 'ban', user: u })}
                    aria-label={`${t('admin.ban')}: ${u.nickname}`}
                  >
                    {t('admin.ban')}
                  </OpsButton>
                )}
                {active(u.mutedUntil) ? (
                  <OpsButton
                    onClick={() => quick.mutate({ id: u.id, op: 'unmute' })}
                    aria-label={`${t('admin.unmute')}: ${u.nickname}`}
                  >
                    {t('admin.unmute')}
                  </OpsButton>
                ) : (
                  <OpsButton
                    onClick={() => setDialog({ kind: 'mute', user: u })}
                    aria-label={`${t('admin.mute')}: ${u.nickname}`}
                  >
                    {t('admin.mute')}
                  </OpsButton>
                )}
                <OpsButton
                  tone="ok"
                  onClick={() => setDialog({ kind: 'grant', user: u })}
                  aria-label={`${t('admin.grant')}: ${u.nickname}`}
                >
                  {t('admin.grant')}
                </OpsButton>
              </div>
            </li>
          ))}
          {list.data?.items.length === 0 && <li>{t('admin.none')}</li>}
        </ul>
      )}
      {list.data && (
        <Pager page={page} total={list.data.total} pageSize={list.data.pageSize} onPage={setPage} />
      )}
      {dialog && <ActionDialog {...dialog} onClose={() => setDialog(null)} />}
    </OpsPanel>
  );
}

function ReportsTab() {
  const { t, i18n } = useTranslation();
  const [page, setPage] = useState(1);
  const q = useQuery({
    queryKey: ['admin', 'reports', page],
    queryFn: () => adminApi.reports(page),
  });
  if (!q.data) return <p role="status">{t('common.loading')}</p>;
  return (
    <OpsPanel title={t('admin.reports')}>
      {q.data.items.length === 0 ? (
        <p>{t('admin.noReports')}</p>
      ) : (
        <ul className="flex flex-col gap-2">
          {q.data.items.map((r) => (
            <li key={r.id} className="rounded-md bg-slate-900 p-3 text-sm">
              <p>
                <strong>{r.author.nickname}</strong> · {r.message.channel} ·{' '}
                {when(r.message.createdAt, i18n.language)}
              </p>
              <p className="my-1 rounded bg-slate-800 p-2">{r.message.text}</p>
              <p className="text-xs text-slate-300">
                {t('admin.reportedBy', { name: r.reporter.nickname })}: {r.reason}
              </p>
            </li>
          ))}
        </ul>
      )}
      <Pager page={page} total={q.data.total} pageSize={q.data.pageSize} onPage={setPage} />
    </OpsPanel>
  );
}

const LOG_KINDS = [
  '',
  'action_flood',
  'rate_limited',
  'idempotency_mismatch',
  'chat_flood',
  'admin_denied',
  'login_locked',
  'god_login_failed',
  'god_login_blocked',
  'god_login',
];

function LogsTab() {
  const { t, i18n } = useTranslation();
  const [page, setPage] = useState(1);
  const [kind, setKind] = useState('');
  const q = useQuery({
    queryKey: ['admin', 'logs', kind, page],
    queryFn: () => adminApi.logs(kind, page),
  });
  return (
    <OpsPanel title={t('admin.logs')}>
      <OpsSelect
        className="mb-3 max-w-xs"
        label={t('admin.logKind')}
        value={kind}
        onChange={(e) => {
          setKind(e.target.value);
          setPage(1);
        }}
      >
        {LOG_KINDS.map((k) => (
          <option key={k} value={k}>
            {k || t('admin.allKinds')}
          </option>
        ))}
      </OpsSelect>
      {!q.data ? (
        <p role="status">{t('common.loading')}</p>
      ) : (
        <div className="overflow-x-auto" role="region" tabIndex={0} aria-label={t('admin.logs')}>
          <table className="w-full min-w-[520px] text-left text-sm">
            <caption className="sr-only">{t('admin.logs')}</caption>
            <thead>
              <tr className="border-b border-slate-600">
                <th scope="col" className="py-1">
                  {t('admin.time')}
                </th>
                <th scope="col" className="py-1">
                  {t('admin.kind')}
                </th>
                <th scope="col" className="py-1">
                  {t('leagues.player')}
                </th>
                <th scope="col" className="py-1">
                  IP
                </th>
                <th scope="col" className="py-1">
                  {t('admin.details')}
                </th>
              </tr>
            </thead>
            <tbody>
              {q.data.items.map((e, i) => (
                <tr key={`${e.createdAt}-${i}`} className="border-b border-slate-700 align-top">
                  <td className="py-1 pr-2 whitespace-nowrap">
                    {when(e.createdAt, i18n.language)}
                  </td>
                  <td className="py-1 pr-2 font-mono text-xs">{e.kind}</td>
                  <td className="py-1 pr-2">{e.nickname ?? '—'}</td>
                  <td className="py-1 pr-2 font-mono text-xs">{e.ip ?? '—'}</td>
                  <td className="py-1">
                    <Json value={e.details} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {q.data.items.length === 0 && <p className="py-2">{t('admin.none')}</p>}
        </div>
      )}
      {q.data && (
        <Pager page={page} total={q.data.total} pageSize={q.data.pageSize} onPage={setPage} />
      )}
    </OpsPanel>
  );
}

export function AuditTable({
  scopeLabel,
  load = adminApi.audit,
  queryKey = 'admin',
}: {
  scopeLabel?: boolean;
  load?: (page: number) => Promise<AuditPageDto>;
  queryKey?: string;
}) {
  const { t, i18n } = useTranslation();
  const [page, setPage] = useState(1);
  const q = useQuery({ queryKey: [queryKey, 'audit', page], queryFn: () => load(page) });
  if (!q.data) return <p role="status">{t('common.loading')}</p>;
  return (
    <div>
      <ul className="flex flex-col gap-2">
        {q.data.items.map((e) => (
          <li key={e.id} className="rounded-md bg-slate-900 p-2 text-sm">
            <p>
              <span className="font-mono text-xs text-slate-300">
                {when(e.createdAt, i18n.language)}
              </span>{' '}
              {scopeLabel && <Badge tone="stone">{e.scope}</Badge>}{' '}
              <strong>{e.actor?.nickname ?? '—'}</strong> →{' '}
              <span className="font-mono">{e.action}</span>
              {e.target && <> · {e.target.nickname}</>}
            </p>
            <details className="text-xs">
              <summary className="cursor-pointer text-sky-300">{t('admin.details')}</summary>
              <Json value={{ params: e.params, before: e.before, after: e.after, ip: e.ip }} />
            </details>
          </li>
        ))}
        {q.data.items.length === 0 && <li>{t('admin.none')}</li>}
      </ul>
      <Pager page={page} total={q.data.total} pageSize={q.data.pageSize} onPage={setPage} />
    </div>
  );
}

/** Панель администратора `/admin`: только роли ADMIN и OWNER; права проверяет сервер при каждом запросе. */
export function AdminPage() {
  const { t } = useTranslation();
  const role = useAuth((s) => s.user?.role);
  const [tab, setTab] = useState('stats');
  if (role !== 'ADMIN' && role !== 'OWNER')
    return (
      <p role="alert" className="pt-16 text-center font-display text-lg">
        {t('admin.forbidden')}
      </p>
    );
  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-4 rounded-xl border-2 border-sky-400 bg-slate-900 p-4 text-slate-100">
      <div className="flex items-center gap-3">
        <h1 className="font-body text-2xl font-bold text-sky-300">{t('admin.title')}</h1>
        <Badge tone="stone">{role}</Badge>
      </div>
      <Tabs
        value={tab}
        onChange={setTab}
        items={[
          { id: 'stats', label: t('admin.tab.stats'), content: <StatsTab /> },
          { id: 'players', label: t('admin.tab.players'), content: <PlayersTab /> },
          { id: 'reports', label: t('admin.tab.reports'), content: <ReportsTab /> },
          { id: 'logs', label: t('admin.tab.logs'), content: <LogsTab /> },
          {
            id: 'audit',
            label: t('admin.tab.audit'),
            content: (
              <OpsPanel title={t('admin.audit')}>
                <AuditTable />
              </OpsPanel>
            ),
          },
        ]}
      />
    </div>
  );
}
