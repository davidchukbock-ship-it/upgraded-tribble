import { useMutation } from '@tanstack/react-query';
import { useState, type FormEvent } from 'react';
import { useTranslation } from 'react-i18next';
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { loginBodySchema, registerBodySchema, type Locale } from '@tc/shared';
import { setLocale } from '../../lib/i18n';
import { asLocale } from '../../lib/locales';
import { useAuth } from '../../store/auth';
import { Button, Panel, TextField } from '../../ui';
import { authApi } from './api';
import { errorMessage } from './errors';
import { fieldErrors, type FieldErrors } from './validation';

function useAfterLogin() {
  const navigate = useNavigate();
  const location = useLocation();
  const from = (location.state as { from?: string } | null)?.from ?? '/castle';
  return (language: Locale) => {
    setLocale(language);
    navigate(from, { replace: true });
  };
}

function Shell({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mx-auto max-w-md pt-8">
      <Panel tone="parchment" title={title}>
        {children}
      </Panel>
    </div>
  );
}

function GuestButton({ onDone }: { onDone: (language: Locale) => void }) {
  const { t, i18n } = useTranslation();
  const guest = useMutation({
    mutationFn: () => authApi.guest(asLocale(i18n.language)),
    onSuccess: (res) => onDone(res.user.language),
  });
  return (
    <div className="mt-4 border-t-2 border-wood-light/40 pt-4 text-center">
      <Button variant="gold" onClick={() => guest.mutate()} loading={guest.isPending}>
        {t('auth.playAsGuest')}
      </Button>
      <p className="mt-2 text-xs text-ink/80">{t('auth.guestHint')}</p>
      {guest.isError && (
        <p role="alert" className="mt-2 text-sm font-semibold text-red">
          {errorMessage(t, guest.error)}
        </p>
      )}
    </div>
  );
}

export function LoginPage() {
  const { t } = useTranslation();
  const status = useAuth((s) => s.status);
  const afterLogin = useAfterLogin();
  const [errors, setErrors] = useState<FieldErrors>({});
  const login = useMutation({
    mutationFn: authApi.login,
    onSuccess: (res) => afterLogin(res.user.language),
  });

  if (status === 'authenticated') return <Navigate to="/castle" replace />;

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const parsed = loginBodySchema.safeParse({
      email: data.get('email'),
      password: data.get('password'),
    });
    if (!parsed.success) return setErrors(fieldErrors(parsed.error));
    setErrors({});
    login.mutate(parsed.data);
  };
  const err = (k: string) => (errors[k] ? t(errors[k].key, errors[k].values) : undefined);

  return (
    <Shell title={t('auth.loginTitle')}>
      <form onSubmit={onSubmit} noValidate className="flex flex-col gap-4">
        <TextField
          name="email"
          type="email"
          autoComplete="email"
          label={t('auth.email')}
          error={err('email')}
        />
        <TextField
          name="password"
          type="password"
          autoComplete="current-password"
          label={t('auth.password')}
          error={err('password')}
        />
        {login.isError && (
          <p role="alert" className="text-sm font-semibold text-red">
            {errorMessage(t, login.error)}
          </p>
        )}
        <Button type="submit" loading={login.isPending}>
          {t('auth.login')}
        </Button>
      </form>
      <p className="mt-4 text-center text-sm">
        {t('auth.noAccount')}{' '}
        <Link to="/register" className="font-bold underline">
          {t('auth.register')}
        </Link>
      </p>
      <GuestButton onDone={afterLogin} />
    </Shell>
  );
}

export function RegisterPage() {
  const { t, i18n } = useTranslation();
  const status = useAuth((s) => s.status);
  const afterLogin = useAfterLogin();
  const [errors, setErrors] = useState<FieldErrors>({});
  const register = useMutation({
    mutationFn: authApi.register,
    onSuccess: (res) => afterLogin(res.user.language),
  });

  if (status === 'authenticated') return <Navigate to="/castle" replace />;

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const parsed = registerBodySchema.safeParse({
      email: data.get('email'),
      nickname: data.get('nickname'),
      password: data.get('password'),
      language: asLocale(i18n.language),
    });
    if (!parsed.success) return setErrors(fieldErrors(parsed.error));
    setErrors({});
    register.mutate(parsed.data);
  };
  const err = (k: string) => (errors[k] ? t(errors[k].key, errors[k].values) : undefined);
  // Конфликты с сервера показываем у конкретного поля
  const serverCode = register.error && 'code' in register.error ? String(register.error.code) : '';
  const emailTaken = serverCode === 'ERR_EMAIL_TAKEN' ? errorMessage(t, register.error) : undefined;
  const nickTaken =
    serverCode === 'ERR_NICKNAME_TAKEN' ? errorMessage(t, register.error) : undefined;
  const general =
    register.isError && !emailTaken && !nickTaken ? errorMessage(t, register.error) : undefined;

  return (
    <Shell title={t('auth.registerTitle')}>
      <form onSubmit={onSubmit} noValidate className="flex flex-col gap-4">
        <TextField
          name="email"
          type="email"
          autoComplete="email"
          label={t('auth.email')}
          error={err('email') ?? emailTaken}
        />
        <TextField
          name="nickname"
          autoComplete="nickname"
          label={t('auth.nickname')}
          hint={t('auth.nicknameHint')}
          error={err('nickname') ?? nickTaken}
        />
        <TextField
          name="password"
          type="password"
          autoComplete="new-password"
          label={t('auth.password')}
          hint={t('auth.passwordHint')}
          error={err('password')}
        />
        {general && (
          <p role="alert" className="text-sm font-semibold text-red">
            {general}
          </p>
        )}
        <Button type="submit" loading={register.isPending}>
          {t('auth.register')}
        </Button>
      </form>
      <p className="mt-4 text-center text-sm">
        {t('auth.haveAccount')}{' '}
        <Link to="/login" className="font-bold underline">
          {t('auth.login')}
        </Link>
      </p>
      <GuestButton onDone={afterLogin} />
    </Shell>
  );
}
