import type {
  AuthResponse,
  LoginBody,
  Locale,
  MeResponse,
  RegisterBody,
  UpdateProfileBody,
} from '@tc/shared';
import { apiFetch } from '../../lib/api';
import { useAuth } from '../../store/auth';

/** Применяет ответ входа: сохраняет сессию. Язык аккаунта подхватывает вызывающий код. */
function accept(res: AuthResponse): AuthResponse {
  useAuth.getState().setSession(res);
  return res;
}

export const authApi = {
  register: (body: RegisterBody) =>
    apiFetch<AuthResponse>('/api/auth/register', { method: 'POST', body, anonymous: true }).then(
      accept,
    ),
  login: (body: LoginBody) =>
    apiFetch<AuthResponse>('/api/auth/login', { method: 'POST', body, anonymous: true }).then(
      accept,
    ),
  guest: (language: Locale) =>
    apiFetch<AuthResponse>('/api/auth/guest', {
      method: 'POST',
      body: { language },
      anonymous: true,
    }).then(accept),
  upgrade: (body: { email: string; password: string }) =>
    apiFetch<MeResponse>('/api/auth/upgrade', { method: 'POST', body }).then((r) => {
      useAuth.getState().setUser(r.user);
      return r;
    }),
  updateProfile: (body: UpdateProfileBody) =>
    apiFetch<MeResponse>('/api/profile', { method: 'PATCH', body }).then((r) => {
      useAuth.getState().setUser(r.user);
      return r;
    }),
  logout: async () => {
    try {
      await apiFetch<void>('/api/auth/logout', { method: 'POST', anonymous: true, csrf: true });
    } finally {
      // Даже если сервер недоступен, локальную сессию закрываем
      useAuth.getState().clear();
    }
  },
  logoutAll: async () => {
    try {
      await apiFetch<void>('/api/auth/logout-all', { method: 'POST' });
    } finally {
      useAuth.getState().clear();
    }
  },
};
