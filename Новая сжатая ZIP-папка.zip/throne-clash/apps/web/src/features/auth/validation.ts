import type { ZodError } from 'zod';

export type FieldErrors = Record<string, { key: string; values?: Record<string, unknown> }>;

/**
 * Превращает ошибки zod (те же схемы, что на сервере) в ключи локализации.
 * Сообщения задаём в схемах кодами ('common_password'), встроенные — по типу проблемы.
 */
export function fieldErrors(error: ZodError): FieldErrors {
  const out: FieldErrors = {};
  for (const issue of error.issues) {
    const field = String(issue.path[0] ?? '_');
    if (out[field]) continue; // показываем первую ошибку поля
    if (issue.code === 'too_small') {
      out[field] = { key: 'validation.tooShort', values: { min: Number(issue.minimum) } };
    } else if (issue.code === 'too_big') {
      out[field] = { key: 'validation.tooLong', values: { max: Number(issue.maximum) } };
    } else if (issue.code === 'invalid_string' && issue.validation === 'email') {
      out[field] = { key: 'validation.email' };
    } else if (issue.code === 'custom' || issue.code === 'invalid_string') {
      out[field] = { key: `validation.${issue.message}` };
    } else {
      out[field] = { key: 'validation.invalid' };
    }
  }
  return out;
}
