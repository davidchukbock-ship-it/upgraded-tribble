import { useTranslation } from 'react-i18next';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../../store/auth';

/** Закрытые экраны: пока сессия восстанавливается — заставка, без входа — на /login с возвратом. */
export function RequireAuth() {
  const status = useAuth((s) => s.status);
  const location = useLocation();
  const { t } = useTranslation();
  if (status === 'unknown') {
    return (
      <p role="status" className="pt-16 text-center font-display text-lg">
        {t('common.loading')}
      </p>
    );
  }
  if (status === 'anonymous')
    return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  return <Outlet />;
}
