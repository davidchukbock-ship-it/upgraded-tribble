import { screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { initI18n } from '../../lib/i18n';
import { useAuth } from '../../store/auth';
import { apiError, installFakeApi, json, makeAuth, makeUser } from '../../test-utils/fake-api';
import { renderApp, resetAuth } from '../../test-utils/render';

beforeAll(async () => {
  await initI18n('ru');
});
beforeEach(() => useAuth.getState().clear());
afterEach(() => {
  resetAuth();
  vi.unstubAllGlobals();
});

describe('вход', () => {
  it('пустая форма не уходит на сервер и показывает ошибки у полей', async () => {
    const { calls } = installFakeApi({});
    renderApp('/login');
    await userEvent.click(screen.getByRole('button', { name: 'Войти' }));
    expect(screen.getByLabelText('Email')).toHaveAttribute('aria-invalid', 'true');
    expect(screen.getAllByRole('alert').length).toBeGreaterThanOrEqual(2);
    expect(calls).toHaveLength(0);
  });

  it('успех: сессия сохранена, переход в замок, язык аккаунта применён', async () => {
    const { calls } = installFakeApi({
      'POST /api/auth/login': () => json(200, makeAuth({ user: makeUser({ language: 'ru' }) })),
    });
    const { router } = renderApp('/login');
    await userEvent.type(screen.getByLabelText('Email'), ' Hero@Example.com ');
    await userEvent.type(screen.getByLabelText('Пароль'), 'Correct horse 42');
    await userEvent.click(screen.getByRole('button', { name: 'Войти' }));
    await waitFor(() => expect(router.state.location.pathname).toBe('/castle'));
    expect(calls[0]?.body).toEqual({ email: 'hero@example.com', password: 'Correct horse 42' });
    expect(useAuth.getState().status).toBe('authenticated');
  });

  it('возвращает на запрошенный экран после входа', async () => {
    installFakeApi({ 'POST /api/auth/login': () => json(200, makeAuth()) });
    const { router } = renderApp('/army'); // → /login с from=/army
    await userEvent.type(await screen.findByLabelText('Email'), 'hero@example.com');
    await userEvent.type(screen.getByLabelText('Пароль'), 'x');
    await userEvent.click(screen.getByRole('button', { name: 'Войти' }));
    await waitFor(() => expect(router.state.location.pathname).toBe('/army'));
  });

  it('неверные данные и блокировка показываются понятным текстом', async () => {
    let n = 0;
    installFakeApi({
      'POST /api/auth/login': () =>
        ++n === 1
          ? apiError(401, 'ERR_INVALID_CREDENTIALS')
          : apiError(429, 'ERR_RATE_LIMITED', { retryAfterSeconds: 600 }),
    });
    renderApp('/login');
    await userEvent.type(screen.getByLabelText('Email'), 'hero@example.com');
    await userEvent.type(screen.getByLabelText('Пароль'), 'wrong');
    await userEvent.click(screen.getByRole('button', { name: 'Войти' }));
    expect(await screen.findByText('Неверный email или пароль')).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: 'Войти' }));
    expect(await screen.findByText(/Подождите 600 с/)).toBeInTheDocument();
  });

  it('гость: один клик — и игра начата', async () => {
    const { calls } = installFakeApi({
      'POST /api/auth/guest': () =>
        json(
          201,
          makeAuth({ user: makeUser({ isGuest: true, email: null, nickname: 'Гость-ABCDE' }) }),
        ),
    });
    const { router } = renderApp('/login');
    await userEvent.click(screen.getByRole('button', { name: 'Играть как гость' }));
    await waitFor(() => expect(router.state.location.pathname).toBe('/castle'));
    expect(calls[0]?.body).toEqual({ language: 'ru' });
    expect(useAuth.getState().user?.isGuest).toBe(true);
  });
});

describe('регистрация', () => {
  const fill = async (over: Partial<Record<'email' | 'nick' | 'pass', string>> = {}) => {
    await userEvent.type(screen.getByLabelText('Email'), over.email ?? 'new@example.com');
    await userEvent.type(screen.getByLabelText('Ник'), over.nick ?? 'Артур');
    await userEvent.type(screen.getByLabelText('Пароль'), over.pass ?? 'Correct horse 42');
    await userEvent.click(screen.getByRole('button', { name: 'Зарегистрироваться' }));
  };

  it('клиентская проверка использует правила сервера (частый пароль, зарезервированный ник)', async () => {
    const { calls } = installFakeApi({});
    renderApp('/register');
    await fill({ nick: 'Admin', pass: 'password123' });
    expect(await screen.findByText('Этот ник зарезервирован')).toBeInTheDocument();
    expect(screen.getByText('Слишком простой пароль')).toBeInTheDocument();
    expect(calls).toHaveLength(0);
  });

  it('успех отправляет нормализованные данные и язык интерфейса', async () => {
    const { calls } = installFakeApi({ 'POST /api/auth/register': () => json(201, makeAuth()) });
    const { router } = renderApp('/register');
    await fill({ email: 'New@Example.com' });
    await waitFor(() => expect(router.state.location.pathname).toBe('/castle'));
    expect(calls[0]?.body).toEqual({
      email: 'new@example.com',
      nickname: 'Артур',
      password: 'Correct horse 42',
      language: 'ru',
    });
  });

  it('конфликт email и ника показываются у своих полей', async () => {
    let n = 0;
    installFakeApi({
      'POST /api/auth/register': () =>
        ++n === 1 ? apiError(409, 'ERR_EMAIL_TAKEN') : apiError(409, 'ERR_NICKNAME_TAKEN'),
    });
    renderApp('/register');
    await fill();
    const email = await screen.findByLabelText('Email');
    await waitFor(() =>
      expect(email).toHaveAccessibleDescription('Этот email уже зарегистрирован'),
    );
    await userEvent.click(screen.getByRole('button', { name: 'Зарегистрироваться' }));
    const nick = screen.getByLabelText('Ник');
    await waitFor(() => expect(nick).toHaveAccessibleDescription(/Этот ник уже занят/));
  });
});
