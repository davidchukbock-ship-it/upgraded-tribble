import { ApiError, hasSessionHint, isTransient, refreshSession } from '../../lib/api';
import { setLocale } from '../../lib/i18n';
import { useAuth } from '../../store/auth';

/**
 * Восстановление сессии при загрузке страницы: если браузер помнит вход, тихо меняем refresh-cookie
 * на access-токен. Без признака сессии не делаем лишний запрос, который вернул бы 401.
 */
export async function bootstrapSession(): Promise<void> {
  if (!hasSessionHint()) {
    useAuth.getState().clear();
    return;
  }
  // Временный сбой (лимит 429, 5xx, нет связи) не должен разлогинивать: пробуем ещё, с паузой
  for (let attempt = 0; attempt <= RETRY_DELAYS_MS.length; attempt++) {
    try {
      await refreshSession();
    } catch (err) {
      const delay = RETRY_DELAYS_MS[attempt];
      if (!isTransient(err) || delay === undefined) break;
      const hinted = err instanceof ApiError ? retryAfterMs(err) : 0;
      await new Promise((r) => setTimeout(r, Math.min(Math.max(delay, hinted), 5000)));
      continue;
    }
    const user = useAuth.getState().user;
    try {
      if (user) setLocale(user.language);
    } catch {
      /* язык интерфейса не должен ломать вход */
    }
    return;
  }
  // Не удалось восстановить: экран входа (cookie остаётся, следующая загрузка попробует снова)
  useAuth.getState().clear();
}

export const RETRY_DELAYS_MS: readonly number[] = [500, 1500, 3000];

const retryAfterMs = (err: ApiError): number => {
  const s = (err.details as { retryAfterSeconds?: number } | undefined)?.retryAfterSeconds;
  return s ? s * 1000 : 0;
};
