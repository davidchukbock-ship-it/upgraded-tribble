import { cleanup, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { initI18n } from '../../lib/i18n';
import { useAuth } from '../../store/auth';
import { apiError, installFakeApi, json, makeAuth, makeUser } from '../../test-utils/fake-api';
import { renderApp, resetAuth, signIn } from '../../test-utils/render';

beforeAll(async () => {
  await initI18n('ru');
});
beforeEach(() => signIn());
afterEach(() => {
  resetAuth();
  vi.unstubAllGlobals();
});

const me = (over = {}) =>
  json(200, { user: makeUser(over), serverTime: '2026-01-01T00:00:00.000Z' });

describe('профиль', () => {
  it('показывает ник, email и не показывает форму привязки не-гостю', () => {
    installFakeApi({});
    renderApp('/profile');
    expect(screen.getByRole('heading', { level: 1, name: /Артур/ })).toBeInTheDocument();
    expect(screen.getByText('hero@example.com')).toBeInTheDocument();
    expect(screen.queryByText('Сохраните прогресс')).toBeNull();
  });

  it('смена герба отправляет PATCH и обновляет выбор', async () => {
    const { calls } = installFakeApi({ 'PATCH /api/profile': () => me({ crest: 'wolf' }) });
    renderApp('/profile');
    const group = screen.getByRole('radiogroup', { name: 'Герб' });
    expect(within(group).getByRole('radio', { name: 'Лев' })).toBeChecked();
    await userEvent.click(within(group).getByRole('radio', { name: 'Волк' }));
    await waitFor(() => expect(within(group).getByRole('radio', { name: 'Волк' })).toBeChecked());
    expect(calls[0]?.body).toEqual({ crest: 'wolf' });
    expect(calls[0]?.headers['Authorization']).toBe('Bearer access-1');
  });

  it('смена языка применяется сразу и сохраняется на сервере', async () => {
    const { calls } = installFakeApi({ 'PATCH /api/profile': () => me({ language: 'en' }) });
    renderApp('/profile');
    await userEvent.click(screen.getByRole('radio', { name: 'English' }));
    await waitFor(() => expect(document.documentElement.lang).toBe('en'));
    expect(calls[0]?.body).toEqual({ language: 'en' });
    cleanup();
    await initI18n('ru');
  });

  it('кулдаун ника показывается под полем, а не всплывающим уведомлением', async () => {
    installFakeApi({
      'PATCH /api/profile': () =>
        apiError(422, 'ERR_REQUIREMENT_NOT_MET', {
          reason: 'nickname_cooldown',
          retryAfterSeconds: 3600,
        }),
    });
    renderApp('/profile');
    const field = screen.getByLabelText('Ник');
    await userEvent.clear(field);
    await userEvent.type(field, 'Новый Ник');
    await userEvent.click(screen.getByRole('button', { name: 'Сохранить' }));
    expect(await screen.findByText(/раз в сутки. Подождите 3600 с/)).toBeInTheDocument();
  });

  it('некорректный ник отсекается на клиенте без запроса', async () => {
    const { calls } = installFakeApi({});
    renderApp('/profile');
    const field = screen.getByLabelText('Ник');
    await userEvent.clear(field);
    await userEvent.type(field, 'x');
    await userEvent.click(screen.getByRole('button', { name: 'Сохранить' }));
    expect(await screen.findByText('Минимум символов: 3')).toBeInTheDocument();
    expect(calls).toHaveLength(0);
  });

  it('гость видит форму привязки; после успеха email появляется в профиле', async () => {
    useAuth
      .getState()
      .setSession(
        makeAuth({ user: makeUser({ isGuest: true, email: null, nickname: 'Гость-ABCDE' }) }),
      );
    const { calls } = installFakeApi({
      'POST /api/auth/upgrade': () =>
        me({ isGuest: false, email: 'g@example.com', nickname: 'Гость-ABCDE' }),
    });
    renderApp('/profile');
    expect(screen.getByText('Сохраните прогресс')).toBeInTheDocument();
    const form = screen.getByText('Сохраните прогресс').closest('section')!;
    await userEvent.type(within(form).getByLabelText('Email'), 'g@example.com');
    await userEvent.type(within(form).getByLabelText('Пароль'), 'Correct horse 42');
    await userEvent.click(within(form).getByRole('button', { name: 'Привязать' }));
    await waitFor(() => expect(screen.getByText('g@example.com')).toBeInTheDocument());
    expect(calls[0]?.body).toEqual({ email: 'g@example.com', password: 'Correct horse 42' });
    expect(screen.queryByText('Сохраните прогресс')).toBeNull();
  });

  it('выход: запрос с CSRF, сессия очищена, переход на /login — даже если сервер недоступен', async () => {
    document.cookie = 'tc_csrf=abc; path=/';
    const { calls } = installFakeApi({
      'POST /api/auth/logout': () => apiError(500, 'ERR_INTERNAL'),
    });
    const { router } = renderApp('/profile');
    await userEvent.click(screen.getByRole('button', { name: 'Выйти' }));
    await waitFor(() => expect(router.state.location.pathname).toBe('/login'));
    expect(useAuth.getState().status).toBe('anonymous');
    expect(calls[0]?.headers['X-CSRF-Token']).toBe('abc');
    document.cookie = 'tc_csrf=; path=/; max-age=0';
  });

  it('выход на всех устройствах', async () => {
    const { calls } = installFakeApi({ 'POST /api/auth/logout-all': () => json(204, null) });
    const { router } = renderApp('/profile');
    await userEvent.click(screen.getByRole('button', { name: 'Выйти на всех устройствах' }));
    await waitFor(() => expect(router.state.location.pathname).toBe('/login'));
    expect(calls[0]?.headers['Authorization']).toBe('Bearer access-1');
  });
});
