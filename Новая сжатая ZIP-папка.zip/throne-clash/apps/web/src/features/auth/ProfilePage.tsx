import { useMutation } from '@tanstack/react-query';
import { useState, type FormEvent } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import {
  DEFAULT_CRESTS,
  LOCALES,
  nicknameSchema,
  upgradeGuestBodySchema,
  type Locale,
} from '@tc/shared';
import { Crest } from '../../icons/Crest';
import { useInventory } from '../progress/useProgress';
import { cn } from '../../lib/cn';
import { setLocale } from '../../lib/i18n';
import { LOCALE_NAMES } from '../../lib/locales';
import { useAuth } from '../../store/auth';
import { useToasts } from '../../store/toast';
import { Badge, Button, Panel, SoundSettings, TextField } from '../../ui';
import { authApi } from './api';
import { errorMessage } from './errors';
import { fieldErrors, type FieldErrors } from './validation';

export function ProfilePage() {
  const { t } = useTranslation();
  const user = useAuth((s) => s.user);
  const push = useToasts((s) => s.push);
  const owned = useInventory().data?.crests ?? [];
  const navigate = useNavigate();
  const [nickError, setNickError] = useState<string | undefined>();
  const [upgradeErrors, setUpgradeErrors] = useState<FieldErrors>({});

  const update = useMutation({
    mutationFn: authApi.updateProfile,
    onSuccess: (res, vars) => {
      if (vars.language) setLocale(res.user.language);
      push(t('profile.saved'), 'success');
    },
    // Ошибка смены ника — под полем, остальные — всплывающим уведомлением
    onError: (err, vars) =>
      vars.nickname ? setNickError(errorMessage(t, err)) : push(errorMessage(t, err), 'error'),
  });
  const upgrade = useMutation({
    mutationFn: authApi.upgrade,
    onSuccess: () => push(t('profile.upgraded'), 'success'),
  });
  const logout = useMutation({
    mutationFn: authApi.logout,
    onSettled: () => navigate('/login', { replace: true }),
  });
  const logoutAll = useMutation({
    mutationFn: authApi.logoutAll,
    onSettled: () => navigate('/login', { replace: true }),
  });

  if (!user) return null;

  const onNickname = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const parsed = nicknameSchema.safeParse(new FormData(e.currentTarget).get('nickname'));
    if (!parsed.success) {
      const f = fieldErrors(parsed.error)['_'];
      return setNickError(f ? t(f.key, f.values) : t('validation.invalid'));
    }
    setNickError(undefined);
    update.mutate({ nickname: parsed.data });
  };

  const onUpgrade = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const parsed = upgradeGuestBodySchema.safeParse({
      email: data.get('email'),
      password: data.get('password'),
    });
    if (!parsed.success) return setUpgradeErrors(fieldErrors(parsed.error));
    setUpgradeErrors({});
    upgrade.mutate(parsed.data);
  };
  const upErr = (k: string) =>
    upgradeErrors[k] ? t(upgradeErrors[k].key, upgradeErrors[k].values) : undefined;

  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-8">
      <h1 className="flex items-center gap-3 font-display text-2xl font-bold text-gold-light">
        <Crest crest={user.crest} size={40} />
        {user.nickname}
        {user.isGuest && <Badge tone="stone">{t('profile.guest')}</Badge>}
        {user.role !== 'PLAYER' && <Badge tone="red">{user.role}</Badge>}
      </h1>

      <Panel tone="parchment" title={t('profile.account')}>
        <dl className="grid grid-cols-[auto_1fr] gap-x-4 gap-y-1 pt-2 text-sm">
          <dt className="font-bold">{t('auth.email')}</dt>
          <dd>{user.email ?? t('profile.noEmail')}</dd>
        </dl>
        <form
          onSubmit={onNickname}
          noValidate
          className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-end"
        >
          <div className="flex-1">
            <TextField
              key={user.nickname}
              name="nickname"
              label={t('auth.nickname')}
              defaultValue={user.nickname}
              hint={t('profile.nicknameHint')}
              error={nickError}
            />
          </div>
          <Button type="submit" loading={update.isPending && !!update.variables?.nickname}>
            {t('common.save')}
          </Button>
        </form>
      </Panel>

      <Panel tone="parchment" title={t('profile.crest')}>
        <div
          role="radiogroup"
          aria-label={t('profile.crest')}
          className="flex flex-wrap gap-3 pt-2"
        >
          {[...DEFAULT_CRESTS, ...owned].map((c) => (
            <button
              key={c}
              type="button"
              role="radio"
              aria-checked={user.crest === c}
              aria-label={t(`crest.${c}`)}
              onClick={() => user.crest !== c && update.mutate({ crest: c })}
              className={cn(
                'flex min-h-[64px] min-w-[64px] items-center justify-center rounded-lg border-4 p-2',
                user.crest === c
                  ? 'border-gold bg-black/10'
                  : 'border-transparent hover:bg-black/10',
              )}
            >
              <Crest crest={c} size={44} />
            </button>
          ))}
        </div>
      </Panel>

      <Panel tone="parchment" title={t('audio.title')}>
        <SoundSettings />
      </Panel>

      <Panel tone="parchment" title={t('common.language')}>
        <div
          role="radiogroup"
          aria-label={t('common.language')}
          className="flex flex-wrap gap-3 pt-2"
        >
          {LOCALES.map((l: Locale) => (
            <Button
              key={l}
              role="radio"
              aria-checked={user.language === l}
              variant={user.language === l ? 'gold' : 'primary'}
              onClick={() => user.language !== l && update.mutate({ language: l })}
            >
              {LOCALE_NAMES[l]}
            </Button>
          ))}
        </div>
      </Panel>

      {user.isGuest && (
        <Panel tone="parchment" title={t('profile.upgradeTitle')}>
          <p className="pt-2 text-sm">{t('profile.upgradeText')}</p>
          <form onSubmit={onUpgrade} noValidate className="mt-3 flex flex-col gap-3">
            <TextField
              name="email"
              type="email"
              autoComplete="email"
              label={t('auth.email')}
              error={upErr('email')}
            />
            <TextField
              name="password"
              type="password"
              autoComplete="new-password"
              label={t('auth.password')}
              hint={t('auth.passwordHint')}
              error={upErr('password')}
            />
            {upgrade.isError && (
              <p role="alert" className="text-sm font-semibold text-red">
                {errorMessage(t, upgrade.error)}
              </p>
            )}
            <Button type="submit" variant="gold" loading={upgrade.isPending}>
              {t('profile.upgrade')}
            </Button>
          </form>
        </Panel>
      )}

      <Panel title={t('profile.session')}>
        <div className="flex flex-wrap gap-3 pt-2">
          <Button variant="danger" onClick={() => logout.mutate()} loading={logout.isPending}>
            {t('profile.logout')}
          </Button>
          <Button variant="danger" onClick={() => logoutAll.mutate()} loading={logoutAll.isPending}>
            {t('profile.logoutAll')}
          </Button>
        </div>
      </Panel>
    </div>
  );
}
