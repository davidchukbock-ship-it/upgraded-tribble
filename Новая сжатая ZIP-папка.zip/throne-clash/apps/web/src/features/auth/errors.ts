import type { TFunction } from 'i18next';
import { ApiError } from '../../lib/api';

/** Понятный пользователю текст по коду ошибки API; неизвестные коды — общее сообщение. */
export function errorMessage(t: TFunction, err: unknown): string {
  if (!(err instanceof ApiError)) return t('errors.ERR_INTERNAL');
  const d = err.details as { retryAfterSeconds?: number; reason?: string } | undefined;
  if (err.code === 'ERR_RATE_LIMITED' && d?.retryAfterSeconds) {
    return t('errors.rateLimitedWait', { seconds: d.retryAfterSeconds });
  }
  if (err.code === 'ERR_REQUIREMENT_NOT_MET' && d?.reason === 'nickname_cooldown') {
    return t('errors.nicknameCooldown', { seconds: d.retryAfterSeconds ?? 0 });
  }
  if (err.code === 'ERR_REQUIREMENT_NOT_MET' && d?.reason) {
    return t(`errors.reason.${d.reason}`, { defaultValue: t('errors.ERR_REQUIREMENT_NOT_MET') });
  }
  return t(`errors.${err.code}`, { defaultValue: t('errors.ERR_INTERNAL') });
}
