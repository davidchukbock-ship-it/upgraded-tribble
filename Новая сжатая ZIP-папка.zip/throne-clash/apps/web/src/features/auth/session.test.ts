import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { useAuth } from '../../store/auth';
import { apiError, installFakeApi, json, makeAuth, makeUser } from '../../test-utils/fake-api';
import { RETRY_DELAYS_MS, bootstrapSession } from './session';

beforeEach(() => useAuth.setState({ status: 'unknown', accessToken: null, user: null }));
afterEach(() => {
  vi.unstubAllGlobals();
  document.cookie = 'tc_csrf=; path=/; max-age=0';
});

describe('bootstrapSession: временные сбои', () => {
  it('429 при восстановлении: повторяет и входит, а не отправляет на экран входа', async () => {
    document.cookie = 'tc_csrf=abc; path=/';
    vi.useFakeTimers();
    let n = 0;
    const { calls } = installFakeApi({
      'POST /api/auth/refresh': () =>
        ++n < 3
          ? apiError(429, 'ERR_RATE_LIMITED', { retryAfterSeconds: 1 })
          : json(200, makeAuth()),
    });
    const done = bootstrapSession();
    await vi.advanceTimersByTimeAsync(10_000);
    await done;
    vi.useRealTimers();
    expect(calls).toHaveLength(3);
    expect(useAuth.getState().status).toBe('authenticated');
  });

  it('после всех попыток сбой считается недоступностью: экран входа, без исключения', async () => {
    document.cookie = 'tc_csrf=abc; path=/';
    vi.useFakeTimers();
    const { calls } = installFakeApi({
      'POST /api/auth/refresh': () => apiError(503, 'ERR_INTERNAL'),
    });
    const done = bootstrapSession();
    await vi.advanceTimersByTimeAsync(20_000);
    await done;
    vi.useRealTimers();
    expect(calls).toHaveLength(RETRY_DELAYS_MS.length + 1);
    expect(useAuth.getState().status).toBe('anonymous');
  });

  it('401 не повторяется', async () => {
    document.cookie = 'tc_csrf=abc; path=/';
    const { calls } = installFakeApi({
      'POST /api/auth/refresh': () => apiError(401, 'ERR_UNAUTHORIZED'),
    });
    await bootstrapSession();
    expect(calls).toHaveLength(1);
  });
});

describe('bootstrapSession', () => {
  it('без признака сессии — сразу anonymous и ни одного запроса', async () => {
    const { calls } = installFakeApi({});
    await bootstrapSession();
    expect(useAuth.getState().status).toBe('anonymous');
    expect(calls).toHaveLength(0);
  });

  it('с признаком сессии обменивает refresh-cookie на токен и применяет язык', async () => {
    document.cookie = 'tc_csrf=abc; path=/';
    installFakeApi({
      'POST /api/auth/refresh': () => json(200, makeAuth({ user: makeUser({ language: 'ru' }) })),
    });
    await bootstrapSession();
    expect(useAuth.getState()).toMatchObject({ status: 'authenticated', accessToken: 'access-1' });
  });

  it('просроченная сессия → anonymous без исключения наружу', async () => {
    document.cookie = 'tc_csrf=abc; path=/';
    installFakeApi({ 'POST /api/auth/refresh': () => apiError(401, 'ERR_UNAUTHORIZED') });
    await expect(bootstrapSession()).resolves.toBeUndefined();
    expect(useAuth.getState().status).toBe('anonymous');
  });
});
