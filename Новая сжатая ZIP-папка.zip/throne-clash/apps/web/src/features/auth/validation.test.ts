import { describe, expect, it } from 'vitest';
import { loginBodySchema, registerBodySchema } from '@tc/shared';
import { fieldErrors } from './validation';

const errorsOf = (body: unknown) => {
  const r = registerBodySchema.safeParse(body);
  if (r.success) throw new Error('expected failure');
  return fieldErrors(r.error);
};
const base = { email: 'a@b.co', password: 'Correct horse 42', nickname: 'Артур' };

describe('fieldErrors', () => {
  it('короткий пароль → ключ с числом', () => {
    expect(errorsOf({ ...base, password: 'abc' })['password']).toEqual({
      key: 'validation.tooShort',
      values: { min: 8 },
    });
  });
  it('длинный ник → tooLong', () => {
    expect(errorsOf({ ...base, nickname: 'x'.repeat(30) })['nickname']).toEqual({
      key: 'validation.tooLong',
      values: { max: 20 },
    });
  });
  it('плохой email', () => {
    expect(errorsOf({ ...base, email: 'nope' })['email']).toEqual({ key: 'validation.email' });
  });
  it('кастомные коды схем → ключи локализации', () => {
    expect(errorsOf({ ...base, password: 'password123' })['password']?.key).toBe(
      'validation.common_password',
    );
    expect(errorsOf({ ...base, nickname: 'Admin' })['nickname']?.key).toBe('validation.reserved');
    expect(errorsOf({ ...base, nickname: '<b>x</b>' })['nickname']?.key).toBe(
      'validation.bad_chars',
    );
  });
  it('по одной ошибке на поле, несколько полей сразу', () => {
    const e = errorsOf({ email: 'x', password: 'a', nickname: '' });
    expect(Object.keys(e).sort()).toEqual(['email', 'nickname', 'password']);
  });
  it('пустая форма входа (null из FormData) даёт ошибки, а не исключение', () => {
    const r = loginBodySchema.safeParse({ email: null, password: null });
    expect(r.success).toBe(false);
    if (!r.success) expect(Object.keys(fieldErrors(r.error)).sort()).toEqual(['email', 'password']);
  });
});
