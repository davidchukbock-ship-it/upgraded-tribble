import { describe, expect, it, vi } from 'vitest';
import { BARS, barEvents, barSeconds, freq, midi, trackForPath, TRACK_IDS } from './music';
import { SFX, SFX_NAMES } from './sfx';
import { AudioEngine } from './engine';

describe('партитуры', () => {
  it('нота → MIDI и частота', () => {
    expect(midi('C4')).toBe(60);
    expect(midi('A4')).toBe(69);
    expect(midi('C#5')).toBe(73);
    expect(midi('Bb3')).toBe(58);
    expect(freq(69)).toBeCloseTo(440);
    expect(freq(57)).toBeCloseTo(220);
    expect(() => midi('H4')).toThrow();
  });

  it('каждый такт каждой темы непустой и укладывается в четыре доли', () => {
    for (const id of TRACK_IDS) {
      for (let bar = 0; bar < BARS; bar++) {
        const ev = barEvents(id, bar);
        expect(ev.length).toBeGreaterThan(4);
        for (const e of ev) {
          expect(e.beat).toBeGreaterThanOrEqual(0);
          expect(e.beat).toBeLessThan(4);
          expect(e.dur).toBeGreaterThan(0);
          expect(e.vel).toBeGreaterThan(0);
          expect(e.vel).toBeLessThanOrEqual(1);
          if (['pad', 'arp', 'bass', 'lead', 'stab'].includes(e.voice))
            expect(e.midi).toBeGreaterThan(20);
        }
      }
    }
  });

  it('цикл замыкается: такт 8 совпадает с тактом 0; детерминизм', () => {
    for (const id of TRACK_IDS) {
      expect(barEvents(id, BARS)).toEqual(barEvents(id, 0));
      expect(barEvents(id, 3)).toEqual(barEvents(id, 3));
    }
  });

  it('темы различаются по темпу и составу голосов', () => {
    expect(barSeconds('battle')).toBeLessThan(barSeconds('map'));
    expect(barSeconds('map')).toBeLessThan(barSeconds('castle'));
    const voices = (id: 'castle' | 'map' | 'battle') =>
      new Set(barEvents(id, 0).map((e) => e.voice));
    expect(voices('castle').has('kick')).toBe(false);
    expect(voices('castle').has('arp')).toBe(true);
    expect(voices('battle').has('kick')).toBe(true);
    expect(voices('battle').has('stab')).toBe(true);
  });

  it('тема выбирается по экрану; на служебных экранах тишина', () => {
    expect(trackForPath('/castle')).toBe('castle');
    expect(trackForPath('/map')).toBe('map');
    expect(trackForPath('/reports/abc')).toBe('battle');
    expect(trackForPath('/god')).toBeNull();
    expect(trackForPath('/admin')).toBeNull();
  });

  it('звуки интерфейса описаны для всех имён и не выходят за разумные пределы', () => {
    expect(SFX_NAMES.length).toBeGreaterThanOrEqual(10);
    for (const name of SFX_NAMES) {
      const steps = SFX[name];
      expect(steps.length).toBeGreaterThan(0);
      for (const s of steps) {
        expect(s.at).toBeGreaterThanOrEqual(0);
        expect(s.at + s.dur).toBeLessThan(2);
        expect(s.gain).toBeGreaterThan(0);
        expect(s.gain).toBeLessThanOrEqual(0.5);
      }
    }
  });
});

/** Минимальная подделка WebAudio: считает созданные узлы и запущенные источники. */
function fakeContext() {
  const log = { started: 0, oscillators: 0, sources: 0, gains: 0 };
  const param = () => ({
    value: 0,
    setValueAtTime: vi.fn(),
    linearRampToValueAtTime: vi.fn(),
    exponentialRampToValueAtTime: vi.fn(),
    setTargetAtTime: vi.fn(),
    cancelScheduledValues: vi.fn(),
  });
  const node = (extra: object = {}) => {
    const n: Record<string, unknown> = { connect: vi.fn(() => n), disconnect: vi.fn(), ...extra };
    return n;
  };
  const ctx = {
    currentTime: 0,
    sampleRate: 8000,
    destination: {},
    state: 'running',
    resume: vi.fn(async () => undefined),
    suspend: vi.fn(async () => undefined),
    close: vi.fn(async () => undefined),
    createGain: vi.fn(() => {
      log.gains++;
      return node({ gain: param() });
    }),
    createOscillator: vi.fn(() => {
      log.oscillators++;
      return node({
        type: 'sine',
        frequency: param(),
        start: () => void log.started++,
        stop: vi.fn(),
      });
    }),
    createBiquadFilter: vi.fn(() => node({ type: 'lowpass', frequency: param() })),
    createBufferSource: vi.fn(() => {
      log.sources++;
      return node({ start: () => void log.started++, stop: vi.fn() });
    }),
    createBuffer: vi.fn((_c: number, len: number) => ({
      getChannelData: () => new Float32Array(len),
    })),
  };
  return { ctx: ctx as unknown as AudioContext, log, raw: ctx };
}

describe('синтезатор', () => {
  it('без поддержки WebAudio молчит и не падает', () => {
    const e = new AudioEngine(null);
    expect(e.available).toBe(false);
    expect(() => {
      e.unlock();
      e.play('castle');
      e.sfx('click');
    }).not.toThrow();
  });

  it('звук не создаётся до нажатия пользователя', () => {
    const f = fakeContext();
    const factory = vi.fn(() => f.ctx);
    const e = new AudioEngine(factory);
    e.play('castle');
    e.sfx('click');
    expect(factory).not.toHaveBeenCalled();
    expect(e.unlocked).toBe(false);
  });

  it('после нажатия играет звуки; отключённые звуки молчат', () => {
    const f = fakeContext();
    const e = new AudioEngine(() => f.ctx);
    e.unlock();
    expect(e.unlocked).toBe(true);
    e.sfx('confirm');
    expect(f.log.oscillators).toBe(SFX.confirm.length);
    const before = f.log.oscillators;
    e.setPrefs({ music: true, sfx: false, musicVolume: 0.5, sfxVolume: 0.6 });
    e.sfx('confirm');
    expect(f.log.oscillators).toBe(before);
  });

  it('тема ставится в очередь, планировщик заполняет такты, смена темы гасит прежнюю', () => {
    vi.useFakeTimers();
    try {
      const f = fakeContext();
      const e = new AudioEngine(() => f.ctx);
      e.unlock();
      e.play('map');
      vi.advanceTimersByTime(300);
      expect(f.log.started).toBeGreaterThan(20);
      e.play('battle');
      expect(f.raw.createGain).toHaveBeenCalled();
      e.play(null);
      vi.advanceTimersByTime(2000);
      e.setHidden(true);
      e.setHidden(false);
      expect(f.raw.suspend).toHaveBeenCalled();
      expect(f.raw.resume).toHaveBeenCalled();
      e.dispose();
    } finally {
      vi.useRealTimers();
    }
  });
});
