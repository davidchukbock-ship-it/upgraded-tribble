/** Короткие звуки интерфейса: описание набором «шагов» синтеза (чистые данные, без WebAudio). */

export type SfxName =
  | 'click'
  | 'confirm'
  | 'error'
  | 'coin'
  | 'build'
  | 'levelup'
  | 'chest'
  | 'clash'
  | 'victory'
  | 'defeat'
  | 'notify'
  | 'slash'
  | 'arrow'
  | 'thud'
  | 'splash'
  | 'bite'
  | 'flip'
  | 'match'
  | 'cheer'
  | 'march'
  | 'chirp';

export interface SfxStep {
  /** Задержка от начала звука, секунды. */
  at: number;
  kind: 'tone' | 'noise';
  /** Частота (для tone) или центр полосы (для noise), Гц. */
  freq: number;
  /** Конечная частота — плавный сдвиг. */
  freqEnd?: number;
  dur: number;
  gain: number;
  wave?: OscillatorType;
}

const tone = (
  at: number,
  freq: number,
  dur: number,
  gain: number,
  wave: OscillatorType = 'sine',
  freqEnd?: number,
): SfxStep => ({
  at,
  kind: 'tone',
  freq,
  freqEnd,
  dur,
  gain,
  wave,
});
const noise = (at: number, freq: number, dur: number, gain: number): SfxStep => ({
  at,
  kind: 'noise',
  freq,
  dur,
  gain,
});

export const SFX: Readonly<Record<SfxName, readonly SfxStep[]>> = {
  click: [tone(0, 620, 0.06, 0.16, 'triangle', 420)],
  confirm: [tone(0, 523, 0.09, 0.18, 'triangle'), tone(0.08, 784, 0.16, 0.18, 'triangle')],
  error: [tone(0, 196, 0.16, 0.22, 'sawtooth', 150), tone(0.12, 165, 0.22, 0.22, 'sawtooth', 120)],
  coin: [tone(0, 988, 0.07, 0.16, 'square'), tone(0.06, 1319, 0.24, 0.16, 'square')],
  build: [
    noise(0, 900, 0.05, 0.4),
    tone(0, 180, 0.09, 0.25, 'square', 90),
    noise(0.18, 900, 0.05, 0.35),
    tone(0.18, 210, 0.09, 0.22, 'square', 100),
  ],
  levelup: [
    tone(0, 523, 0.12, 0.2, 'triangle'),
    tone(0.1, 659, 0.12, 0.2, 'triangle'),
    tone(0.2, 784, 0.12, 0.2, 'triangle'),
    tone(0.3, 1047, 0.4, 0.22, 'triangle'),
  ],
  chest: [
    noise(0, 400, 0.12, 0.3),
    tone(0.1, 392, 0.14, 0.2, 'triangle'),
    tone(0.2, 587, 0.14, 0.2, 'triangle'),
    tone(0.3, 784, 0.14, 0.2, 'triangle'),
    tone(0.4, 1175, 0.45, 0.22, 'triangle'),
  ],
  clash: [
    noise(0, 3200, 0.14, 0.4),
    tone(0, 1400, 0.25, 0.16, 'square', 900),
    tone(0.02, 2100, 0.2, 0.1, 'triangle', 1500),
  ],
  victory: [
    tone(0, 392, 0.16, 0.22, 'sawtooth'),
    tone(0.16, 392, 0.16, 0.22, 'sawtooth'),
    tone(0.32, 392, 0.16, 0.22, 'sawtooth'),
    tone(0.48, 523, 0.5, 0.25, 'sawtooth'),
    tone(0.48, 659, 0.5, 0.18, 'sawtooth'),
    tone(0.48, 784, 0.5, 0.18, 'sawtooth'),
  ],
  defeat: [
    tone(0, 330, 0.25, 0.22, 'sawtooth', 300),
    tone(0.25, 262, 0.25, 0.22, 'sawtooth', 240),
    tone(0.5, 196, 0.6, 0.24, 'sawtooth', 150),
  ],
  notify: [tone(0, 880, 0.08, 0.14, 'sine'), tone(0.1, 1175, 0.2, 0.14, 'sine')],
  // Бой и игры (D-67)
  slash: [noise(0, 4200, 0.09, 0.32), tone(0, 1800, 0.12, 0.1, 'triangle', 700)],
  arrow: [noise(0, 5200, 0.16, 0.16), tone(0, 900, 0.16, 0.06, 'sine', 2400)],
  thud: [tone(0, 140, 0.16, 0.3, 'sine', 60), noise(0, 260, 0.1, 0.3)],
  splash: [
    noise(0, 1400, 0.22, 0.34),
    tone(0.03, 420, 0.18, 0.1, 'sine', 180),
    noise(0.12, 2200, 0.12, 0.16),
  ],
  bite: [
    tone(0, 1568, 0.07, 0.16, 'sine'),
    tone(0.09, 1568, 0.07, 0.16, 'sine'),
    tone(0.18, 2093, 0.16, 0.16, 'sine'),
  ],
  flip: [noise(0, 2600, 0.05, 0.18), tone(0, 480, 0.07, 0.1, 'triangle', 720)],
  match: [
    tone(0, 659, 0.1, 0.18, 'triangle'),
    tone(0.09, 880, 0.1, 0.18, 'triangle'),
    tone(0.18, 1319, 0.26, 0.2, 'triangle'),
  ],
  cheer: [
    noise(0, 1200, 0.5, 0.14),
    tone(0, 300, 0.4, 0.08, 'sawtooth', 420),
    tone(0.1, 380, 0.4, 0.08, 'sawtooth', 520),
  ],
  chirp: [
    tone(0, 3100, 0.05, 0.05, 'sine', 3900),
    tone(0.08, 3500, 0.05, 0.05, 'sine', 4200),
    tone(0.17, 3000, 0.07, 0.05, 'sine', 3800),
  ],
  march: [
    noise(0, 380, 0.06, 0.22),
    noise(0.16, 340, 0.06, 0.2),
    noise(0.32, 380, 0.06, 0.22),
    noise(0.48, 340, 0.06, 0.2),
  ],
};

export const SFX_NAMES = Object.keys(SFX) as SfxName[];
