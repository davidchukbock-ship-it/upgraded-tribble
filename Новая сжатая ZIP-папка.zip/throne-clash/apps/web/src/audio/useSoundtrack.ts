import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { engine } from './engine';
import { trackForPath } from './music';
import type { SfxName } from './sfx';
import { useAudio } from '../store/audio';
import { useToasts } from '../store/toast';

/** Играет тему экрана, включает звук после первого нажатия и озвучивает кнопки и уведомления. */
export function useSoundtrack(): void {
  const { pathname } = useLocation();
  const music = useAudio((s) => s.music);
  const sfx = useAudio((s) => s.sfx);
  const musicVolume = useAudio((s) => s.musicVolume);
  const sfxVolume = useAudio((s) => s.sfxVolume);

  useEffect(() => {
    engine.setPrefs({ music, sfx, musicVolume, sfxVolume });
  }, [music, sfx, musicVolume, sfxVolume]);

  useEffect(() => {
    engine.play(trackForPath(pathname));
  }, [pathname]);

  useEffect(() => {
    const unlock = (): void => engine.unlock();
    const click = (e: Event): void => {
      unlock();
      const el = (e.target as Element | null)?.closest(
        'button, a, [role="button"], [role="radio"], [role="tab"]',
      );
      if (el && !el.hasAttribute('disabled') && !el.closest('[data-nosound]')) engine.sfx('click');
    };
    const visibility = (): void => engine.setHidden(document.hidden);
    document.addEventListener('click', click, true);
    document.addEventListener('keydown', unlock, true);
    document.addEventListener('visibilitychange', visibility);
    return () => {
      document.removeEventListener('click', click, true);
      document.removeEventListener('keydown', unlock, true);
      document.removeEventListener('visibilitychange', visibility);
    };
  }, []);

  useEffect(() => {
    let seen = useToasts.getState().items.length;
    return useToasts.subscribe((s) => {
      if (s.items.length > seen) {
        const tone = s.items[s.items.length - 1]?.tone;
        const name: SfxName =
          tone === 'error' ? 'error' : tone === 'success' ? 'confirm' : 'notify';
        engine.sfx(name);
      }
      seen = s.items.length;
    });
  }, []);
}

/** Звук события (например, победы) из любого места. */
export const playSfx = (name: SfxName): void => engine.sfx(name);
