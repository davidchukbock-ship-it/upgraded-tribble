/**
 * Музыка игры — не записи, а партитуры: короткие циклы по 8 тактов, которые синтезатор играет в браузере.
 * Здесь только чистые данные и функции (без WebAudio), поэтому их можно проверять тестами.
 */

export type TrackId = 'castle' | 'map' | 'battle';
export type Voice = 'pad' | 'arp' | 'bass' | 'lead' | 'kick' | 'snare' | 'hat' | 'shaker' | 'stab';

export interface NoteEvent {
  /** Начало внутри такта, в долях (0…4). */
  beat: number;
  /** Длительность, доли. */
  dur: number;
  voice: Voice;
  /** Нота MIDI (для ударных не нужна). */
  midi?: number;
  /** Громкость 0…1. */
  vel: number;
}

const NAMES: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };

/** «C#4» → 61. */
export function midi(name: string): number {
  const m = /^([A-G])([#b]?)(-?\d)$/.exec(name);
  if (!m) throw new Error(`Не нота: ${name}`);
  const base = NAMES[m[1]!]!;
  const acc = m[2] === '#' ? 1 : m[2] === 'b' ? -1 : 0;
  return 12 * (Number(m[3]) + 1) + base + acc;
}

type Quality = 'maj' | 'min';
interface Chord {
  root: number;
  q: Quality;
}
const ch = (name: string, q: Quality): Chord => ({ root: midi(name), q });
const triad = (c: Chord): number[] => [c.root, c.root + (c.q === 'maj' ? 4 : 3), c.root + 7];

type Melody = ReadonlyArray<readonly [beat: number, note: string, dur: number]>;

interface Track {
  id: TrackId;
  bpm: number;
  chords: readonly Chord[];
  lead: readonly Melody[];
  drums: 'none' | 'march' | 'battle';
  /** Играют ли арпеджио и ритмичный бас. */
  arp: boolean;
  bass: 'long' | 'eighths';
}

export const BARS = 8;

const TRACKS: Record<TrackId, Track> = {
  // Спокойная, «уютная» тема замка: C-мажор, арпеджио и флейта
  castle: {
    id: 'castle',
    bpm: 78,
    chords: [
      ch('C3', 'maj'),
      ch('A2', 'min'),
      ch('F2', 'maj'),
      ch('G2', 'maj'),
      ch('C3', 'maj'),
      ch('E3', 'min'),
      ch('F2', 'maj'),
      ch('G2', 'maj'),
    ],
    lead: [
      [
        [0, 'E5', 1.5],
        [1.5, 'G5', 0.5],
        [2, 'A5', 2],
      ],
      [
        [0, 'G5', 1],
        [1, 'E5', 1],
        [2, 'C5', 2],
      ],
      [
        [0, 'A5', 1.5],
        [1.5, 'G5', 0.5],
        [2, 'F5', 2],
      ],
      [
        [0, 'G5', 2],
        [2, 'D5', 1],
        [3, 'E5', 1],
      ],
      [
        [0, 'E5', 1.5],
        [1.5, 'G5', 0.5],
        [2, 'C6', 2],
      ],
      [
        [0, 'B5', 1],
        [1, 'G5', 1],
        [2, 'E5', 2],
      ],
      [
        [0, 'F5', 1],
        [1, 'A5', 1],
        [2, 'G5', 1],
        [3, 'F5', 1],
      ],
      [
        [0, 'D5', 1],
        [1, 'E5', 1],
        [2, 'D5', 2],
      ],
    ],
    drums: 'none',
    arp: true,
    bass: 'long',
  },
  // Тема карты: D-дорийский, размеренный марш и бодрая мелодия
  map: {
    id: 'map',
    bpm: 98,
    chords: [
      ch('D3', 'min'),
      ch('C3', 'maj'),
      ch('A#2', 'maj'),
      ch('C3', 'maj'),
      ch('D3', 'min'),
      ch('G2', 'min'),
      ch('C3', 'maj'),
      ch('A2', 'maj'),
    ],
    lead: [
      [
        [0, 'D5', 1],
        [1.5, 'F5', 0.5],
        [2, 'A5', 1],
        [3, 'G5', 1],
      ],
      [
        [0, 'E5', 1],
        [1.5, 'G5', 0.5],
        [2, 'C6', 1.5],
      ],
      [
        [0, 'D5', 1],
        [1, 'F5', 1],
        [2, 'A5', 1],
        [3, 'F5', 1],
      ],
      [
        [0, 'G5', 1.5],
        [1.5, 'E5', 0.5],
        [2, 'C5', 2],
      ],
      [
        [0, 'D5', 1],
        [1.5, 'F5', 0.5],
        [2, 'A5', 1],
        [3, 'C6', 1],
      ],
      [
        [0, 'A#5', 1],
        [1, 'G5', 1],
        [2, 'D5', 2],
      ],
      [
        [0, 'E5', 0.5],
        [0.5, 'G5', 0.5],
        [1, 'C6', 1],
        [2, 'B5', 1],
        [3, 'G5', 1],
      ],
      [
        [0, 'A5', 1.5],
        [1.5, 'E5', 0.5],
        [2, 'A4', 2],
      ],
    ],
    drums: 'march',
    arp: false,
    bass: 'eighths',
  },
  // Боевая тема: A-минор, быстрый пульс и медные акценты
  battle: {
    id: 'battle',
    bpm: 128,
    chords: [
      ch('A2', 'min'),
      ch('A2', 'min'),
      ch('F2', 'maj'),
      ch('G2', 'maj'),
      ch('A2', 'min'),
      ch('C3', 'maj'),
      ch('F2', 'maj'),
      ch('E2', 'maj'),
    ],
    lead: [
      [
        [0, 'A5', 0.5],
        [0.5, 'C6', 0.5],
        [1, 'B5', 1],
        [2, 'A5', 2],
      ],
      [
        [0, 'E5', 0.5],
        [0.5, 'A5', 0.5],
        [1, 'G5', 1],
        [2, 'E5', 2],
      ],
      [
        [0, 'F5', 0.5],
        [0.5, 'A5', 0.5],
        [1, 'C6', 1],
        [2, 'A5', 2],
      ],
      [
        [0, 'G5', 0.5],
        [0.5, 'B5', 0.5],
        [1, 'D6', 1],
        [2, 'B5', 2],
      ],
      [
        [0, 'A5', 0.5],
        [0.5, 'C6', 0.5],
        [1, 'E6', 1],
        [2, 'D6', 1],
        [3, 'C6', 1],
      ],
      [
        [0, 'G5', 1],
        [1, 'E5', 1],
        [2, 'C5', 2],
      ],
      [
        [0, 'A5', 1],
        [1, 'F5', 1],
        [2, 'C5', 1],
        [3, 'F5', 1],
      ],
      [
        [0, 'G#5', 1],
        [1, 'B5', 1],
        [2, 'E5', 2],
      ],
    ],
    drums: 'battle',
    arp: false,
    bass: 'eighths',
  },
};

export const trackBpm = (id: TrackId): number => TRACKS[id].bpm;
/** Длительность такта, секунды. */
export const barSeconds = (id: TrackId): number => (4 * 60) / TRACKS[id].bpm;

const mel = (t: Track, bar: number): Melody => t.lead[bar % BARS]!;

/** Все ноты одного такта (bar — номер такта с начала, цикл — 8). Чистая функция. */
export function barEvents(id: TrackId, bar: number): NoteEvent[] {
  const t = TRACKS[id];
  const i = ((bar % BARS) + BARS) % BARS;
  const chord = t.chords[i]!;
  const tones = triad(chord);
  const ev: NoteEvent[] = [];
  const add = (e: NoteEvent): void => void ev.push(e);

  // Аккорды: плавный «подклад»
  for (const n of tones)
    add({ beat: 0, dur: 4, voice: 'pad', midi: n + 12, vel: t.drums === 'battle' ? 0.5 : 0.7 });

  // Басс
  if (t.bass === 'long') {
    add({ beat: 0, dur: 2, voice: 'bass', midi: chord.root, vel: 0.9 });
    add({ beat: 2, dur: 2, voice: 'bass', midi: chord.root + 7, vel: 0.7 });
  } else {
    for (let b = 0; b < 8; b += 1) {
      const up = b % 4 === 2 ? 7 : b % 4 === 3 ? 12 : 0;
      add({
        beat: b / 2,
        dur: 0.45,
        voice: 'bass',
        midi: chord.root + up,
        vel: b % 2 === 0 ? 0.95 : 0.65,
      });
    }
  }

  // Арпеджио: восьмые по звукам аккорда
  if (t.arp) {
    const seq = [0, 1, 2, 1, 2, 1, 0, 1];
    for (let b = 0; b < 8; b += 1)
      add({
        beat: b / 2,
        dur: 0.5,
        voice: 'arp',
        midi: tones[seq[b]!]! + 24,
        vel: b % 2 === 0 ? 0.8 : 0.5,
      });
  }

  // Мелодия
  for (const [beat, note, dur] of mel(t, i))
    add({ beat, dur, voice: 'lead', midi: midi(note), vel: 0.85 });

  // Ударные
  if (t.drums === 'march') {
    for (const b of [0, 2]) add({ beat: b, dur: 0.2, voice: 'kick', vel: 0.9 });
    for (const b of [1, 3]) add({ beat: b, dur: 0.15, voice: 'snare', vel: 0.55 });
    for (let b = 0; b < 8; b += 1)
      add({ beat: b / 2, dur: 0.1, voice: 'shaker', vel: b % 2 ? 0.35 : 0.2 });
  } else if (t.drums === 'battle') {
    for (let b = 0; b < 4; b += 1) add({ beat: b, dur: 0.2, voice: 'kick', vel: 1 });
    for (const b of [1, 3]) add({ beat: b, dur: 0.15, voice: 'snare', vel: 0.85 });
    for (let b = 0; b < 16; b += 1)
      add({ beat: b / 4, dur: 0.06, voice: 'hat', vel: b % 4 === 2 ? 0.55 : 0.28 });
    for (const b of [1.5, 3.5])
      for (const n of tones) add({ beat: b, dur: 0.4, voice: 'stab', midi: n + 12, vel: 0.6 });
  }
  return ev;
}

export const TRACK_IDS: readonly TrackId[] = ['castle', 'map', 'battle'];

/** Какая тема играет на экране. null — тишина (служебные экраны). */
export function trackForPath(pathname: string): TrackId | null {
  if (
    pathname.startsWith('/god') ||
    pathname.startsWith('/admin') ||
    pathname === '/ui-kit' ||
    pathname === '/art'
  )
    return null;
  if (pathname.startsWith('/reports') || pathname.startsWith('/play')) return 'battle';
  if (
    pathname.startsWith('/map') ||
    pathname.startsWith('/leagues') ||
    pathname.startsWith('/army')
  )
    return 'map';
  return 'castle';
}

/** Частота ноты MIDI, Гц. */
export const freq = (m: number): number => 440 * 2 ** ((m - 69) / 12);
