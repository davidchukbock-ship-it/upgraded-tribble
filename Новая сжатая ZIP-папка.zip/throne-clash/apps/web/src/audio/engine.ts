import { BARS, barEvents, barSeconds, freq, type NoteEvent, type TrackId } from './music';
import { SFX, type SfxName, type SfxStep } from './sfx';

export interface AudioPrefs {
  music: boolean;
  sfx: boolean;
  musicVolume: number;
  sfxVolume: number;
}

type Ctx = AudioContext;

/**
 * Синтезатор: играет партитуры из music.ts и короткие звуки из sfx.ts через WebAudio.
 * Звук запускается только после первого нажатия пользователя (правило браузеров), без файлов и лицензий.
 */
export class AudioEngine {
  private ctx: Ctx | null = null;
  private master: GainNode | null = null;
  private musicOut: GainNode | null = null;
  private sfxOut: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  private bus: { id: TrackId; gain: GainNode } | null = null;
  private wanted: TrackId | null = null;
  private nextBarAt = 0;
  private bar = 0;
  private timer: ReturnType<typeof setInterval> | null = null;
  private prefs: AudioPrefs = { music: true, sfx: true, musicVolume: 0.5, sfxVolume: 0.6 };

  constructor(private readonly factory: (() => Ctx) | null = defaultFactory()) {}

  get available(): boolean {
    return this.factory !== null;
  }
  get unlocked(): boolean {
    return this.ctx !== null;
  }

  /** Вызывать из обработчика нажатия: создаёт контекст и снимает блокировку автозапуска. */
  unlock(): void {
    if (!this.factory) return;
    if (!this.ctx) {
      try {
        this.ctx = this.factory();
      } catch {
        return;
      }
      const c = this.ctx;
      this.master = c.createGain();
      this.master.gain.value = 0.9;
      this.master.connect(c.destination);
      this.musicOut = c.createGain();
      this.musicOut.connect(this.master);
      this.sfxOut = c.createGain();
      this.sfxOut.connect(this.master);
      this.noise = makeNoise(c);
      this.applyPrefs();
    }
    void this.ctx.resume?.();
    this.sync();
  }

  setPrefs(p: AudioPrefs): void {
    this.prefs = p;
    this.applyPrefs();
    this.sync();
  }

  private applyPrefs(): void {
    if (!this.ctx || !this.musicOut || !this.sfxOut) return;
    const t = this.ctx.currentTime;
    this.musicOut.gain.setTargetAtTime(
      this.prefs.music ? this.prefs.musicVolume * 1.1 : 0,
      t,
      0.15,
    );
    this.sfxOut.gain.setTargetAtTime(this.prefs.sfx ? this.prefs.sfxVolume : 0, t, 0.05);
  }

  /** Какая тема должна играть (null — тишина). Переключение плавное. */
  play(id: TrackId | null): void {
    this.wanted = id;
    this.sync();
  }

  /** Приостановить/продолжить при сворачивании вкладки. */
  setHidden(hidden: boolean): void {
    if (!this.ctx) return;
    if (hidden) void this.ctx.suspend?.();
    else void this.ctx.resume?.();
  }

  private sync(): void {
    const c = this.ctx;
    if (!c || !this.musicOut) return;
    const want = this.prefs.music ? this.wanted : null;
    if (this.bus && this.bus.id !== want) this.fadeOut(this.bus.gain);
    if (this.bus && this.bus.id !== want) this.bus = null;
    if (want && !this.bus) {
      const gain = c.createGain();
      gain.gain.setValueAtTime(0, c.currentTime);
      gain.gain.linearRampToValueAtTime(1, c.currentTime + 1.4);
      gain.connect(this.musicOut);
      this.bus = { id: want, gain };
      this.bar = 0;
      this.nextBarAt = c.currentTime + 0.1;
    }
    if (this.bus && !this.timer) this.timer = setInterval(() => this.tick(), 120);
    if (!this.bus && this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  private fadeOut(g: GainNode): void {
    const c = this.ctx!;
    g.gain.cancelScheduledValues(c.currentTime);
    g.gain.setValueAtTime(g.gain.value, c.currentTime);
    g.gain.linearRampToValueAtTime(0, c.currentTime + 1.1);
    setTimeout(() => g.disconnect(), 1500);
  }

  private tick(): void {
    const c = this.ctx;
    const bus = this.bus;
    if (!c || !bus) return;
    while (this.nextBarAt < c.currentTime + 0.9) {
      const spb = barSeconds(bus.id) / 4;
      for (const e of barEvents(bus.id, this.bar))
        this.note(bus, e, this.nextBarAt + e.beat * spb, spb);
      this.nextBarAt += barSeconds(bus.id);
      this.bar = (this.bar + 1) % BARS;
    }
  }

  private note(bus: { id: TrackId; gain: GainNode }, e: NoteEvent, at: number, spb: number): void {
    const c = this.ctx!;
    const dur = Math.max(0.05, e.dur * spb);
    const out = bus.gain;
    switch (e.voice) {
      case 'pad':
        this.osc(out, 'triangle', freq(e.midi!), at, dur, 0.05 * e.vel, {
          attack: 0.6,
          release: 0.9,
          lp: 1500,
        });
        this.osc(out, 'sine', freq(e.midi! - 12), at, dur, 0.03 * e.vel, {
          attack: 0.8,
          release: 1,
        });
        break;
      case 'arp':
        this.osc(out, 'triangle', freq(e.midi!), at, dur, 0.09 * e.vel, {
          attack: 0.005,
          release: 0.35,
          lp: 3200,
        });
        break;
      case 'bass':
        this.osc(
          out,
          bus.id === 'castle' ? 'sine' : 'sawtooth',
          freq(e.midi!),
          at,
          dur,
          (bus.id === 'castle' ? 0.16 : 0.1) * e.vel,
          { attack: 0.01, release: 0.12, lp: bus.id === 'castle' ? 400 : 700 },
        );
        break;
      case 'lead':
        if (bus.id === 'castle') {
          this.osc(out, 'sine', freq(e.midi!), at, dur, 0.13 * e.vel, {
            attack: 0.06,
            release: 0.25,
            vibrato: 5,
          });
        } else if (bus.id === 'map') {
          this.osc(out, 'square', freq(e.midi!), at, dur, 0.055 * e.vel, {
            attack: 0.01,
            release: 0.18,
            lp: 2400,
          });
        } else {
          this.osc(out, 'sawtooth', freq(e.midi!), at, dur, 0.06 * e.vel, {
            attack: 0.01,
            release: 0.12,
            lp: 3000,
          });
        }
        break;
      case 'stab':
        this.osc(out, 'sawtooth', freq(e.midi!), at, dur, 0.035 * e.vel, {
          attack: 0.01,
          release: 0.15,
          lp: 1800,
        });
        break;
      case 'kick': {
        const o = c.createOscillator();
        const g = c.createGain();
        o.frequency.setValueAtTime(130, at);
        o.frequency.exponentialRampToValueAtTime(42, at + 0.16);
        g.gain.setValueAtTime(0.5 * e.vel, at);
        g.gain.exponentialRampToValueAtTime(0.001, at + 0.22);
        o.connect(g).connect(out);
        o.start(at);
        o.stop(at + 0.25);
        break;
      }
      case 'snare':
        this.noiseHit(out, at, 0.16, 0.22 * e.vel, 1800, 'bandpass');
        break;
      case 'hat':
        this.noiseHit(out, at, 0.05, 0.1 * e.vel, 7500, 'highpass');
        break;
      case 'shaker':
        this.noiseHit(out, at, 0.06, 0.09 * e.vel, 6000, 'highpass');
        break;
    }
  }

  private osc(
    dest: AudioNode,
    type: OscillatorType,
    f: number,
    at: number,
    dur: number,
    gain: number,
    o: { attack: number; release: number; lp?: number; vibrato?: number },
  ): void {
    const c = this.ctx!;
    const osc = c.createOscillator();
    osc.type = type;
    osc.frequency.setValueAtTime(f, at);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, at);
    g.gain.linearRampToValueAtTime(gain, at + Math.min(o.attack, dur));
    g.gain.setValueAtTime(gain, at + Math.max(0, dur - 0.02));
    g.gain.exponentialRampToValueAtTime(0.0001, at + dur + o.release);
    let node: AudioNode = osc;
    if (o.lp) {
      const lp = c.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.value = o.lp;
      node.connect(lp);
      node = lp;
    }
    node.connect(g).connect(dest);
    if (o.vibrato) {
      const lfo = c.createOscillator();
      const depth = c.createGain();
      lfo.frequency.value = o.vibrato;
      depth.gain.value = f * 0.006;
      lfo.connect(depth).connect(osc.frequency);
      lfo.start(at);
      lfo.stop(at + dur + o.release + 0.05);
    }
    osc.start(at);
    osc.stop(at + dur + o.release + 0.05);
  }

  private noiseHit(
    dest: AudioNode,
    at: number,
    dur: number,
    gain: number,
    f: number,
    type: BiquadFilterType,
  ): void {
    const c = this.ctx!;
    if (!this.noise) return;
    const src = c.createBufferSource();
    src.buffer = this.noise;
    const flt = c.createBiquadFilter();
    flt.type = type;
    flt.frequency.value = f;
    const g = c.createGain();
    g.gain.setValueAtTime(gain, at);
    g.gain.exponentialRampToValueAtTime(0.001, at + dur);
    src.connect(flt).connect(g).connect(dest);
    src.start(at);
    src.stop(at + dur + 0.02);
  }

  /** Короткий звук интерфейса. Молчит, пока звук не разблокирован или выключен. */
  sfx(name: SfxName): void {
    const c = this.ctx;
    if (!c || !this.sfxOut || !this.prefs.sfx) return;
    const t0 = c.currentTime + 0.005;
    for (const s of SFX[name]) this.step(s, t0);
  }

  private step(s: SfxStep, t0: number): void {
    const c = this.ctx!;
    const out = this.sfxOut!;
    const at = t0 + s.at;
    if (s.kind === 'noise') {
      this.noiseHit(out, at, s.dur, s.gain, s.freq, 'bandpass');
      return;
    }
    const o = c.createOscillator();
    o.type = s.wave ?? 'sine';
    o.frequency.setValueAtTime(s.freq, at);
    if (s.freqEnd) o.frequency.exponentialRampToValueAtTime(s.freqEnd, at + s.dur);
    const g = c.createGain();
    g.gain.setValueAtTime(s.gain, at);
    g.gain.exponentialRampToValueAtTime(0.001, at + s.dur);
    o.connect(g).connect(out);
    o.start(at);
    o.stop(at + s.dur + 0.03);
  }

  /**
   * Отрисовка темы в готовый буфер (OfflineAudioContext) — для предпрослушивания и тестов:
   * планировщик не нужен, все ноты ставятся сразу.
   */
  renderOffline(c: Ctx, id: TrackId, bars: number): void {
    this.ctx = c;
    this.master = c.createGain();
    this.master.gain.value = 0.9;
    this.master.connect(c.destination);
    this.musicOut = c.createGain();
    this.musicOut.gain.value = this.prefs.musicVolume * 1.1;
    this.musicOut.connect(this.master);
    this.noise = makeNoise(c);
    const gain = c.createGain();
    gain.connect(this.musicOut);
    const bus = { id, gain };
    const spb = barSeconds(id) / 4;
    for (let bar = 0; bar < bars; bar++)
      for (const e of barEvents(id, bar))
        this.note(bus, e, bar * barSeconds(id) + e.beat * spb, spb);
  }

  dispose(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    void this.ctx?.close?.();
    this.ctx = null;
  }
}

function makeNoise(c: Ctx): AudioBuffer {
  const len = c.sampleRate * 1;
  const buf = c.createBuffer(1, len, c.sampleRate);
  const d = buf.getChannelData(0);
  let seed = 1234567;
  for (let i = 0; i < len; i++) {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    d[i] = (seed / 0xffffffff) * 2 - 1;
  }
  return buf;
}

function defaultFactory(): (() => Ctx) | null {
  if (typeof window === 'undefined') return null;
  const w = window as unknown as {
    AudioContext?: typeof AudioContext;
    webkitAudioContext?: typeof AudioContext;
  };
  const Ctor = w.AudioContext ?? w.webkitAudioContext;
  return Ctor ? () => new Ctor() : null;
}

export const engine = new AudioEngine();
