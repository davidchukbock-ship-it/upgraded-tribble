// @vitest-environment node
import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';

/** D-17: пары «текст/фон» интерфейса обязаны проходить WCAG AA (4.5:1). */
const css = readFileSync(new URL('./index.css', import.meta.url), 'utf8');
const token = (name: string): string => {
  const m = new RegExp(`--${name}:\\s*(#[0-9a-fA-F]{6})`).exec(css);
  if (!m?.[1]) throw new Error(`token --${name} not found`);
  return m[1];
};

function luminance(hex: string): number {
  const c = [1, 3, 5].map((i) => {
    const v = parseInt(hex.slice(i, i + 2), 16) / 255;
    return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
  }) as [number, number, number];
  return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
}
const contrast = (a: string, b: string): number => {
  const [hi, lo] = [luminance(a), luminance(b)].sort((x, y) => y - x) as [number, number];
  return (hi + 0.05) / (lo + 0.05);
};

describe('контраст палитры', () => {
  const pairs: Array<[string, string, string]> = [
    ['белый на основной кнопке', '#ffffff', token('green-btn')],
    ['белый на опасной кнопке', '#ffffff', token('red')],
    ['тёмный на золотой кнопке', token('ink'), token('gold')],
    ['пергамент на дереве', token('parchment'), token('wood')],
    ['чернила на пергаменте', token('ink'), token('parchment')],
    ['пергамент на тёмном камне', token('parchment'), token('stone-dark')],
    ['светлое золото на тёмном дереве', token('gold-light'), token('wood-dark')],
  ];
  it.each(pairs)('%s ≥ 4.5', (_n, fg, bg) => {
    expect(contrast(fg, bg)).toBeGreaterThanOrEqual(4.5);
  });
});
