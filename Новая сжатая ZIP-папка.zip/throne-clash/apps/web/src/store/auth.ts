import { create } from 'zustand';
import type { AuthResponse, UserDto } from '@tc/shared';

/**
 * Состояние сессии. Access-токен живёт только в памяти (D-05): при перезагрузке страницы
 * его восстанавливает refresh-cookie, до этого статус — 'unknown'.
 */
/** Токен выдан владельцем, действующим от имени игрока (вход из режима бога): в нём есть claim `act`. */
export function isImpersonating(token: string | null): boolean {
  if (!token) return false;
  try {
    const payload = JSON.parse(
      atob(token.split('.')[1]!.replace(/-/g, '+').replace(/_/g, '/')),
    ) as {
      act?: unknown;
    };
    return payload.act !== undefined;
  } catch {
    return false;
  }
}

export type AuthStatus = 'unknown' | 'anonymous' | 'authenticated';

interface AuthState {
  status: AuthStatus;
  accessToken: string | null;
  user: UserDto | null;
  setSession: (res: Pick<AuthResponse, 'accessToken' | 'user'>) => void;
  setUser: (user: UserDto) => void;
  clear: () => void;
}

export const useAuth = create<AuthState>((set) => ({
  status: 'unknown',
  accessToken: null,
  user: null,
  setSession: ({ accessToken, user }) => set({ status: 'authenticated', accessToken, user }),
  setUser: (user) => set({ user }),
  clear: () => set({ status: 'anonymous', accessToken: null, user: null }),
}));
