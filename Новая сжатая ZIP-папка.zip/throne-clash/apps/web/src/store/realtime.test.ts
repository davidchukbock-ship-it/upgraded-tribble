import { beforeEach, describe, expect, it } from 'vitest';
import type { ChatMessageDto } from '@tc/shared';
import { useRealtime } from './realtime';

const msg = (id: number, over: Partial<ChatMessageDto> = {}): ChatMessageDto => ({
  id: `m${String(id).padStart(3, '0')}`,
  channel: 'world',
  userId: 'u',
  nickname: 'A',
  text: `t${id}`,
  createdAt: new Date(1_700_000_000_000 + id * 1000).toISOString(),
  ...over,
});

beforeEach(() => useRealtime.getState().reset());

describe('хранилище чата', () => {
  it('сообщения складываются по каналам, без дублей и по времени', () => {
    const s = useRealtime.getState();
    s.push(msg(2));
    s.push(msg(1));
    s.push(msg(2));
    s.push(msg(5, { channel: 'guild' }));
    const st = useRealtime.getState();
    expect(st.messages['world']!.map((m) => m.id)).toEqual(['m001', 'm002']);
    expect(st.messages['guild']).toHaveLength(1);
  });

  it('история сливается с уже пришедшими сообщениями', () => {
    const s = useRealtime.getState();
    s.push(msg(3));
    s.merge('world', [msg(1), msg(2), msg(3)]);
    expect(useRealtime.getState().messages['world']!.map((m) => m.id)).toEqual([
      'm001',
      'm002',
      'm003',
    ]);
  });

  it('хранится не больше 100 последних', () => {
    useRealtime.getState().merge(
      'world',
      Array.from({ length: 130 }, (_, i) => msg(i)),
    );
    const list = useRealtime.getState().messages['world']!;
    expect(list).toHaveLength(100);
    expect(list[0]!.id).toBe('m030');
    expect(list.at(-1)!.id).toBe('m129');
  });

  it('собеседники, онлайн, статус и сброс', () => {
    const s = useRealtime.getState();
    s.addPeer('u2', 'Борис');
    s.setOnline(7);
    s.setStatus('open');
    expect(useRealtime.getState()).toMatchObject({
      peers: { u2: 'Борис' },
      online: 7,
      status: 'open',
    });
    s.reset();
    expect(useRealtime.getState()).toMatchObject({
      peers: {},
      online: 0,
      status: 'idle',
      messages: {},
    });
  });
});
