import { create } from 'zustand';

/**
 * Синхронизация с серверным временем (D-03): клиент хранит смещение «сервер − мои часы»,
 * обновляется по заголовку X-Server-Time каждого ответа. Таймеры рисуются по серверному времени.
 */
interface ClockState {
  offsetMs: number;
  syncFromServer: (serverIso: string, receivedAtMs?: number) => void;
  now: () => number;
}

export const useClock = create<ClockState>((set, get) => ({
  offsetMs: 0,
  syncFromServer: (serverIso, receivedAtMs = Date.now()) => {
    const server = Date.parse(serverIso);
    if (Number.isFinite(server)) set({ offsetMs: server - receivedAtMs });
  },
  now: () => Date.now() + get().offsetMs,
}));
