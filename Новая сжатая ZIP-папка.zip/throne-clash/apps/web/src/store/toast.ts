import { create } from 'zustand';

export type ToastTone = 'info' | 'success' | 'error';
export interface ToastItem {
  id: number;
  tone: ToastTone;
  message: string;
}

interface ToastState {
  items: ToastItem[];
  push: (message: string, tone?: ToastTone, ttlMs?: number) => number;
  dismiss: (id: number) => void;
}

let seq = 0;

export const useToasts = create<ToastState>((set, get) => ({
  items: [],
  push: (message, tone = 'info', ttlMs = 4000) => {
    const id = ++seq;
    // Не более 4 одновременно: старые вытесняются
    set((s) => ({ items: [...s.items, { id, tone, message }].slice(-4) }));
    if (ttlMs > 0) setTimeout(() => get().dismiss(id), ttlMs);
    return id;
  },
  dismiss: (id) => set((s) => ({ items: s.items.filter((t) => t.id !== id) })),
}));
