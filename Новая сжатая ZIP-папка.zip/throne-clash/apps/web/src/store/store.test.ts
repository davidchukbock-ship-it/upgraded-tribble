import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { useClock } from './clock';
import { useToasts } from './toast';

describe('useClock', () => {
  afterEach(() => useClock.setState({ offsetMs: 0 }));

  it('считает смещение относительно серверного времени', () => {
    useClock
      .getState()
      .syncFromServer('2030-01-01T00:00:10.000Z', Date.parse('2030-01-01T00:00:00.000Z'));
    expect(useClock.getState().offsetMs).toBe(10_000);
  });

  it('игнорирует некорректный заголовок', () => {
    useClock.getState().syncFromServer('мусор');
    expect(useClock.getState().offsetMs).toBe(0);
  });
});

describe('useToasts', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    useToasts.setState({ items: [] });
  });
  afterEach(() => vi.useRealTimers());

  it('убирает уведомление по таймеру', () => {
    useToasts.getState().push('hi', 'info', 1000);
    expect(useToasts.getState().items).toHaveLength(1);
    vi.advanceTimersByTime(1001);
    expect(useToasts.getState().items).toHaveLength(0);
  });

  it('держит не более 4 штук', () => {
    for (let i = 0; i < 6; i++) useToasts.getState().push(String(i), 'info', 0);
    expect(useToasts.getState().items.map((t) => t.message)).toEqual(['2', '3', '4', '5']);
  });
});
