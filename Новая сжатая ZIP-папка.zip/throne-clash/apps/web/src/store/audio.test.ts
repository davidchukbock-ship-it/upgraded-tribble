import { beforeEach, describe, expect, it } from 'vitest';
import { loadPrefs, useAudio } from './audio';

describe('настройки звука', () => {
  beforeEach(() => localStorage.clear());

  it('по умолчанию музыка и звуки включены', () => {
    expect(loadPrefs()).toEqual({ music: true, sfx: true, musicVolume: 0.5, sfxVolume: 0.6 });
  });

  it('сохраняются и читаются из браузера', () => {
    useAudio.getState().set({ music: false, musicVolume: 0.2 });
    expect(loadPrefs()).toEqual({ music: false, sfx: true, musicVolume: 0.2, sfxVolume: 0.6 });
  });

  it('испорченные данные заменяются значениями по умолчанию', () => {
    localStorage.setItem('tc.audio', '{"music":"да","musicVolume":7}');
    expect(loadPrefs().music).toBe(true);
    expect(loadPrefs().musicVolume).toBe(0.5);
    localStorage.setItem('tc.audio', 'не json');
    expect(loadPrefs().sfx).toBe(true);
  });
});
