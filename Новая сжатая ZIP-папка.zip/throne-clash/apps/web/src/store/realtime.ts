import { create } from 'zustand';
import type { ChatMessageDto } from '@tc/shared';

export type RealtimeStatus = 'idle' | 'connecting' | 'open' | 'closed';

const KEEP = 100;

interface RealtimeState {
  status: RealtimeStatus;
  /** Игроков онлайн. */
  online: number;
  /** Сообщения по каналам (`world`, `guild`, `dm:<id>`), старые первыми. */
  messages: Record<string, ChatMessageDto[]>;
  /** Собеседники личных чатов, открытых в этом сеансе: id → ник. */
  peers: Record<string, string>;
  setStatus: (s: RealtimeStatus) => void;
  setOnline: (n: number) => void;
  push: (m: ChatMessageDto) => void;
  /** История с сервера сливается с уже пришедшими сообщениями без дублей. */
  merge: (channel: string, list: readonly ChatMessageDto[]) => void;
  addPeer: (userId: string, nickname: string) => void;
  reset: () => void;
}

const combine = (a: readonly ChatMessageDto[], b: readonly ChatMessageDto[]): ChatMessageDto[] => {
  const seen = new Map<string, ChatMessageDto>();
  for (const m of [...a, ...b]) seen.set(m.id, m);
  return [...seen.values()]
    .sort((x, y) => x.createdAt.localeCompare(y.createdAt) || (x.id < y.id ? -1 : 1))
    .slice(-KEEP);
};

export const useRealtime = create<RealtimeState>((set) => ({
  status: 'idle',
  online: 0,
  messages: {},
  peers: {},
  setStatus: (status) => set({ status }),
  setOnline: (online) => set({ online }),
  push: (m) =>
    set((s) => ({
      messages: { ...s.messages, [m.channel]: combine(s.messages[m.channel] ?? [], [m]) },
    })),
  merge: (channel, list) =>
    set((s) => ({
      messages: { ...s.messages, [channel]: combine(s.messages[channel] ?? [], list) },
    })),
  addPeer: (userId, nickname) => set((s) => ({ peers: { ...s.peers, [userId]: nickname } })),
  reset: () => set({ status: 'idle', online: 0, messages: {}, peers: {} }),
}));
