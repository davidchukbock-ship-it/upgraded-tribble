import { create } from 'zustand';

const KEY = 'tc.adventure';

/** Рекорды одиночных игр лежат в браузере: это личное дело игрока, на игровую экономику они не влияют (D-67). */
export interface AdventureBests {
  arenaWave: number;
  fishing: number;
  /** Меньше ходов — лучше; 0 — ещё не проходил. */
  runeMoves: number;
}

const EMPTY: AdventureBests = { arenaWave: 0, fishing: 0, runeMoves: 0 };

const num = (v: unknown): number =>
  typeof v === 'number' && Number.isFinite(v) && v >= 0 ? Math.floor(v) : 0;

export function loadBests(): AdventureBests {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return EMPTY;
    const p = JSON.parse(raw) as Partial<AdventureBests>;
    return { arenaWave: num(p.arenaWave), fishing: num(p.fishing), runeMoves: num(p.runeMoves) };
  } catch {
    return EMPTY;
  }
}

interface State extends AdventureBests {
  reportArena: (wave: number) => void;
  reportFishing: (score: number) => void;
  reportRunes: (moves: number) => void;
}

export const useAdventure = create<State>((set, get) => {
  const save = () => {
    const { arenaWave, fishing, runeMoves } = get();
    try {
      localStorage.setItem(KEY, JSON.stringify({ arenaWave, fishing, runeMoves }));
    } catch {
      /* хранилище недоступно — рекорд живёт до перезагрузки */
    }
  };
  return {
    ...loadBests(),
    reportArena: (wave) => {
      if (wave > get().arenaWave) {
        set({ arenaWave: wave });
        save();
      }
    },
    reportFishing: (score) => {
      if (score > get().fishing) {
        set({ fishing: score });
        save();
      }
    },
    reportRunes: (moves) => {
      const cur = get().runeMoves;
      if (moves > 0 && (cur === 0 || moves < cur)) {
        set({ runeMoves: moves });
        save();
      }
    },
  };
});
