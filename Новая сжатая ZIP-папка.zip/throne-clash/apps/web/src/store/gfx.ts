import { create } from 'zustand';

const KEY = 'tc.gfx';
export type GfxMode = 'rich' | 'classic';

function load(): GfxMode {
  try {
    return localStorage.getItem(KEY) === 'classic' ? 'classic' : 'rich';
  } catch {
    return 'rich';
  }
}

interface GfxState {
  mode: GfxMode;
  set: (m: GfxMode) => void;
}

/** Вид графики — личная настройка: «богатая» (анимированные постройки art2) или «классика» (лёгкий SVG). */
export const useGfx = create<GfxState>((set) => ({
  mode: load(),
  set: (mode) => {
    set({ mode });
    try {
      localStorage.setItem(KEY, mode);
    } catch {
      /* хранилище недоступно */
    }
  },
}));
