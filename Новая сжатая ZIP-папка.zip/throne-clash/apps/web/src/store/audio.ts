import { create } from 'zustand';
import type { AudioPrefs } from '../audio/engine';

const KEY = 'tc.audio';
const DEFAULTS: AudioPrefs = { music: true, sfx: true, musicVolume: 0.5, sfxVolume: 0.6 };

const clamp = (v: unknown, d: number): number =>
  typeof v === 'number' && v >= 0 && v <= 1 ? v : d;

/** Настройки звука лежат в браузере: это личное удобство игрока, а не данные аккаунта. */
export function loadPrefs(): AudioPrefs {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULTS;
    const p = JSON.parse(raw) as Partial<AudioPrefs>;
    return {
      music: typeof p.music === 'boolean' ? p.music : DEFAULTS.music,
      sfx: typeof p.sfx === 'boolean' ? p.sfx : DEFAULTS.sfx,
      musicVolume: clamp(p.musicVolume, DEFAULTS.musicVolume),
      sfxVolume: clamp(p.sfxVolume, DEFAULTS.sfxVolume),
    };
  } catch {
    return DEFAULTS;
  }
}

interface AudioState extends AudioPrefs {
  set: (patch: Partial<AudioPrefs>) => void;
}

export const useAudio = create<AudioState>((set, get) => ({
  ...loadPrefs(),
  set: (patch) => {
    set(patch);
    const { music, sfx, musicVolume, sfxVolume } = get();
    try {
      localStorage.setItem(KEY, JSON.stringify({ music, sfx, musicVolume, sfxVolume }));
    } catch {
      /* хранилище недоступно — настройка живёт до перезагрузки */
    }
  },
}));
