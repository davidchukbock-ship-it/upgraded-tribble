import { create } from 'zustand';
import { applyEra, ERA_IDS, type EraId } from '../iso/era';

const KEY = 'tc.era';

function load(): EraId {
  try {
    const v = localStorage.getItem(KEY);
    return ERA_IDS.find((e) => e === v) ?? 'medieval';
  } catch {
    return 'medieval';
  }
}

interface EraState {
  era: EraId;
  set: (era: EraId) => void;
}

/** Облик мира — личная настройка игрока (в браузере), как и звук. */
export const useEra = create<EraState>((set) => {
  const initial = load();
  applyEra(initial);
  return {
    era: initial,
    set: (era) => {
      applyEra(era);
      set({ era });
      try {
        localStorage.setItem(KEY, era);
      } catch {
        /* хранилище недоступно */
      }
    },
  };
});
