import { beforeEach, describe, expect, it } from 'vitest';
import { PAL } from '../iso/primitives';
import { useEra } from './era';

beforeEach(() => {
  localStorage.clear();
  useEra.getState().set('medieval');
});

describe('облик мира', () => {
  it('переключение меняет палитру и запоминается в браузере', () => {
    const before = PAL.stone.left;
    useEra.getState().set('modern');
    expect(useEra.getState().era).toBe('modern');
    expect(PAL.stone.left).not.toBe(before);
    expect(localStorage.getItem('tc.era')).toBe('modern');
    useEra.getState().set('medieval');
    expect(PAL.stone.left).toBe(before);
  });
});
