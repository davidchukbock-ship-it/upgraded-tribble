/**
 * Изометрические постройки art2 со «слоем жизни»: статичная картинка рисуется один раз,
 * а `overlay(ctx, t)` каждый кадр добавляет движущееся — дым, пламя, лопасти, флаги, искры.
 */
import { flag, flame, flicker, glow, smoke, sparks } from './anim';
import {
  FORT_PENNANT,
  P,
  aoStrip,
  barrel,
  cone,
  drawBase as drawPlot,
  gable,
  renderFort,
  wallBox,
} from './fort';
import {
  INK,
  PALETTE,
  line,
  linear,
  makeCanvas,
  poly,
  rng,
  softShadow,
  type Ctx,
  type Pt,
} from './kit';
import { beam3d, windowGlow } from './materials';

export type BuildingKind =
  | 'fort'
  | 'mill'
  | 'smithy'
  | 'tavern'
  | 'market'
  | 'mage'
  | 'barracks'
  | 'sawmill'
  | 'goldmine'
  | 'quarry'
  | 'gemmine'
  | 'fishery'
  | 'archertower'
  | 'stormtower'
  | 'hospital';
export const BUILDING_KINDS: readonly BuildingKind[] = [
  'fort',
  'mill',
  'smithy',
  'tavern',
  'market',
  'mage',
  'barracks',
  'sawmill',
  'goldmine',
  'quarry',
  'gemmine',
  'fishery',
  'archertower',
  'stormtower',
  'hospital',
];

export interface AnimatedBuilding {
  /** Статичный слой (логический размер 480×480, плотность ×2). */
  base: HTMLCanvasElement;
  /** Движущийся слой; ctx уже в логических координатах 480×480. */
  overlay: (ctx: Ctx, t: number) => void;
}

/** Режим «без основания»: рисуется только постройка — для городской сцены, где земля уже есть. */
let flat = false;
const ground = (ctx: Ctx, seed: number): void => {
  if (!flat) drawPlot(ctx, seed);
};

export const BUILDING_SIZE = { w: 480, h: 480 } as const;

type Overlay = AnimatedBuilding['overlay'];

// ── Общие детали ────────────────────────────────────────────────────────────

function chimney(ctx: Ctx, x: number, y: number, z: number, h: number, seed: number): Pt {
  wallBox(ctx, x, y, z, 0.7, 0.7, h, 'stone', seed);
  return P(x + 0.35, y + 0.35, z + h);
}

function crate(ctx: Ctx, x: number, y: number, s = 1): void {
  wallBox(ctx, x, y, 0, 0.7 * s, 0.7 * s, 16 * s, 'plank', Math.floor(x * 7 + y * 13));
}

function shadowOf(ctx: Ctx, x0: number, y0: number, x1: number, y1: number): void {
  softShadow(
    ctx,
    [P(x0, y0), P(x1, y0), P(x1 + 0.2, y1), P(x0, y1)].map(([x, y]) => [x + 10, y + 6] as Pt),
    9,
  );
}

// ── Мельница ────────────────────────────────────────────────────────────────

function mill(seed: number): AnimatedBuilding {
  const { canvas, ctx } = makeCanvas(480, 480, 2);
  const r = rng(seed);
  ground(ctx, seed);
  // пшеничные грядки
  for (const [x0, y0] of [
    [0.6, 5.6],
    [0.6, 7.0],
  ] as const) {
    const a = P(x0, y0);
    const b = P(x0 + 3.6, y0);
    const c = P(x0 + 3.6, y0 + 1.1);
    const d = P(x0, y0 + 1.1);
    poly(ctx, [a, b, c, d], '#d9b04a');
    for (let i = 0; i < 22; i++) {
      const p = P(x0 + 0.15 + i * 0.16, y0 + 0.2 + r() * 0.7);
      line(ctx, [p[0], p[1]], [p[0] + r() * 2 - 1, p[1] - 7], '#f2d577', 1.6);
    }
  }
  shadowOf(ctx, 3.0, 2.0, 6.2, 5.2);
  const bx = 3.2;
  const by = 2.2;
  const bw = 2.6;
  wallBox(ctx, bx, by, 0, bw, bw, 92, 'stone', seed + 1, {
    left: (len, hh) => {
      windowGlow(ctx, len / 2 - 8, hh - 52, 16, 22);
      ctx.fillStyle = '#4a2d12';
      ctx.beginPath();
      ctx.roundRect(len / 2 - 11, hh - 26, 22, 26, [10, 10, 0, 0]);
      ctx.fill();
    },
  });
  aoStrip(ctx, 'left', bx, by, 0, bw, bw, 92);
  // деревянный «колпак» и крыша
  wallBox(ctx, bx - 0.1, by - 0.1, 92, bw + 0.2, bw + 0.2, 22, 'timber', seed + 2);
  gable(
    ctx,
    {
      x0: bx - 0.1,
      x1: bx + bw + 0.1,
      y0: by - 0.1,
      y1: by + bw + 0.1,
      z: 114,
      rise: 40,
      axis: 'x',
      over: 0.35,
    },
    seed + 3,
  );
  // ось лопастей
  const hub = P(bx + bw / 2, by + bw + 0.12, 78);
  ctx.beginPath();
  ctx.arc(hub[0], hub[1], 7, 0, Math.PI * 2);
  ctx.fillStyle = '#6b421a';
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.strokeStyle = INK;
  ctx.stroke();
  crate(ctx, 6.6, 5.6);
  barrel(ctx, 6.0, 7.0);
  const overlay: Overlay = (c, t) => {
    const [hx, hy] = hub;
    c.save();
    c.translate(hx, hy);
    c.scale(0.86, 1); // лёгкий разворот плоскости
    c.rotate(t * 0.8);
    for (let i = 0; i < 4; i++) {
      c.save();
      c.rotate((i * Math.PI) / 2);
      c.fillStyle = '#8a5a2c';
      c.fillRect(-2.5, -90, 5, 90);
      c.lineWidth = 1.8;
      c.strokeStyle = INK;
      c.strokeRect(-2.5, -90, 5, 90);
      // парусина
      c.beginPath();
      c.rect(2.5, -88, 20, 58);
      c.fillStyle = '#f3e8c8';
      c.fill();
      c.stroke();
      c.strokeStyle = 'rgba(120,90,50,.5)';
      c.lineWidth = 1;
      for (let k = 1; k < 4; k++) {
        c.beginPath();
        c.moveTo(2.5, -88 + k * 14);
        c.lineTo(22.5, -88 + k * 14);
        c.stroke();
      }
      c.restore();
    }
    c.restore();
    c.beginPath();
    c.arc(hx, hy, 5.5, 0, Math.PI * 2);
    c.fillStyle = PALETTE.gold;
    c.fill();
    c.lineWidth = 1.8;
    c.strokeStyle = INK;
    c.stroke();
  };
  return { base: canvas, overlay };
}

// ── Кузница ─────────────────────────────────────────────────────────────────

function smithy(seed: number): AnimatedBuilding {
  const { canvas, ctx } = makeCanvas(480, 480, 2);
  ground(ctx, seed);
  shadowOf(ctx, 1.6, 1.6, 7.0, 6.0);
  const hx = 1.8;
  const hy = 1.8;
  const hw = 4.6;
  const hd = 3.6;
  wallBox(ctx, hx, hy, 0, hw, hd, 52, 'stone', seed + 1, {
    left: (len, hh) => {
      // открытая топка: тёмный проём, внутри горит оверлей
      ctx.fillStyle = '#2a1a12';
      ctx.beginPath();
      ctx.roundRect(len * 0.42, hh - 40, 56, 40, [16, 16, 0, 0]);
      ctx.fill();
      ctx.lineWidth = 2.4;
      ctx.strokeStyle = INK;
      ctx.stroke();
      windowGlow(ctx, len * 0.12, hh - 44, 16, 22, false);
    },
    right: (len, hh) => windowGlow(ctx, len / 2 - 8, hh - 40, 16, 22, false),
  });
  aoStrip(ctx, 'left', hx, hy, 0, hw, hd, 52);
  // положение топки в экране: грань left, u = 0.42·len+28, v = hh-18
  const forge = P(hx + hw * 0.56, hy + hd, 18);
  gable(
    ctx,
    {
      x0: hx - 0.1,
      x1: hx + hw + 0.1,
      y0: hy - 0.1,
      y1: hy + hd + 0.1,
      z: 52,
      rise: 40,
      axis: 'x',
      over: 0.4,
    },
    seed + 2,
  );
  const top = chimney(ctx, hx + 0.3, hy + 0.4, 50, 70, seed + 4);
  // наковальня, уголь, ящики
  const [ax, ay] = P(hx + hw * 0.56 + 0.1, hy + hd + 1.1);
  ctx.fillStyle = '#4a4e57';
  ctx.beginPath();
  ctx.moveTo(ax - 14, ay - 12);
  ctx.lineTo(ax + 16, ay - 12);
  ctx.lineTo(ax + 8, ay - 6);
  ctx.lineTo(ax + 6, ay);
  ctx.lineTo(ax - 6, ay);
  ctx.lineTo(ax - 8, ay - 6);
  ctx.closePath();
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.strokeStyle = INK;
  ctx.stroke();
  crate(ctx, 7.0, 5.0);
  barrel(ctx, 7.2, 6.4);
  barrel(ctx, 0.9, 6.8);
  const overlay: Overlay = (c, t) => {
    smoke(c, top[0], top[1] - 2, t, seed);
    flame(c, forge[0], forge[1] - 4, t, 1.15, 1);
    glow(c, forge[0], forge[1] - 14, 46, 'rgba(255,150,50,1)', 0.28 * flicker(t, 2));
    sparks(c, ax, ay - 14, t, seed + 3);
    // молот, бьющий по наковальне
    const a = Math.max(0, Math.sin(t * 5.2));
    c.save();
    c.translate(ax + 26, ay - 44);
    c.rotate(-0.9 + a * 1.1);
    c.fillStyle = '#8a5a2c';
    c.fillRect(-2, 0, 4, 34);
    c.fillStyle = '#6d7480';
    c.fillRect(-8, -6, 16, 10);
    c.lineWidth = 1.6;
    c.strokeStyle = INK;
    c.strokeRect(-8, -6, 16, 10);
    c.restore();
  };
  return { base: canvas, overlay };
}

// ── Таверна ─────────────────────────────────────────────────────────────────

function tavern(seed: number): AnimatedBuilding {
  const { canvas, ctx } = makeCanvas(480, 480, 2);
  ground(ctx, seed);
  shadowOf(ctx, 1.4, 1.4, 7.4, 6.6);
  const hx = 1.6;
  const hy = 1.6;
  const hw = 5.0;
  const hd = 4.0;
  wallBox(ctx, hx, hy, 0, hw, hd, 44, 'stone', seed + 1, {
    left: (len, hh) => {
      ctx.fillStyle = '#4a2d12';
      ctx.beginPath();
      ctx.roundRect(len * 0.42, hh - 34, 26, 34, [12, 12, 0, 0]);
      ctx.fill();
      ctx.lineWidth = 2.2;
      ctx.strokeStyle = INK;
      ctx.stroke();
      windowGlow(ctx, len * 0.12, hh - 34, 18, 20);
      windowGlow(ctx, len * 0.72, hh - 34, 18, 20);
    },
    right: (len, hh) => windowGlow(ctx, len / 2 - 9, hh - 34, 18, 20),
  });
  aoStrip(ctx, 'left', hx, hy, 0, hw, hd, 44);
  wallBox(ctx, hx - 0.12, hy - 0.12, 44, hw + 0.24, hd + 0.24, 38, 'timber', seed + 2, {
    left: (len) => {
      windowGlow(ctx, len * 0.18, 9, 16, 22);
      windowGlow(ctx, len * 0.46, 9, 16, 22);
      windowGlow(ctx, len * 0.74, 9, 16, 22);
    },
    right: (len) => windowGlow(ctx, len / 2 - 8, 9, 16, 22),
  });
  gable(
    ctx,
    {
      x0: hx - 0.12,
      x1: hx + hw + 0.12,
      y0: hy - 0.12,
      y1: hy + hd + 0.12,
      z: 82,
      rise: 46,
      axis: 'x',
      over: 0.45,
    },
    seed + 3,
  );
  const top = chimney(ctx, hx + 3.5, hy + 0.5, 100, 40, seed + 4);
  // вывеска на кронштейне у входа
  const sign = P(hx + hw * 0.42 + 0.3, hy + hd + 0.05, 46);
  crate(ctx, 7.3, 5.4);
  barrel(ctx, 7.4, 6.6);
  barrel(ctx, 0.9, 6.8);
  const overlay: Overlay = (c, t) => {
    smoke(c, top[0], top[1], t, seed + 1, 5);
    // кронштейн и качающаяся вывеска с кружкой
    c.save();
    c.translate(sign[0], sign[1] - 8);
    line(c, [0, 0], [26, 0], INK, 4);
    line(c, [0, 0], [26, 0], '#8a5a2c', 2);
    c.translate(26, 0);
    c.rotate(Math.sin(t * 2.2) * 0.12);
    line(c, [0, 0], [-8, 6], INK, 1.4);
    line(c, [0, 0], [8, 6], INK, 1.4);
    c.fillStyle = '#d9a441';
    c.beginPath();
    c.roundRect(-14, 6, 28, 24, 4);
    c.fill();
    c.lineWidth = 2;
    c.strokeStyle = INK;
    c.stroke();
    c.fillStyle = '#f7f2e0';
    c.fillRect(-6, 12, 9, 12);
    c.strokeRect(-6, 12, 9, 12);
    c.beginPath();
    c.arc(5, 18, 4, -Math.PI / 2, Math.PI / 2);
    c.stroke();
    c.restore();
    // мерцание окон
    for (const u of [0.18, 0.46, 0.74]) {
      const p = P(hx + hw * u + 0.3, hy + hd + 0.15, 66);
      glow(c, p[0], p[1], 26, 'rgba(255,190,70,1)', 0.22 * flicker(t, u * 10));
    }
  };
  return { base: canvas, overlay };
}

// ── Рынок ───────────────────────────────────────────────────────────────────

function stall(ctx: Ctx, x: number, y: number, colors: [string, string], seed: number): Pt {
  const w = 2.3;
  const d = 1.6;
  const h = 44;
  // прилавок
  wallBox(ctx, x, y + d - 0.6, 0, w, 0.6, 18, 'plank', seed);
  // столбы
  for (const [px, py] of [
    [x + 0.1, y + 0.1],
    [x + w - 0.1, y + 0.1],
    [x + 0.1, y + d],
    [x + w - 0.1, y + d],
  ]) {
    const a = P(px!, py!, 0);
    const b = P(px!, py!, h);
    line(ctx, [a[0], a[1]], [b[0], b[1]], INK, 5);
    line(ctx, [a[0], a[1]], [b[0], b[1]], '#8a5a2c', 2.6);
  }
  // полосатый навес
  const stripes = 6;
  for (let i = 0; i < stripes; i++) {
    const u0 = i / stripes;
    const u1 = (i + 1) / stripes;
    poly(
      ctx,
      [
        P(x + w * u0, y + d + 0.35, h - 4),
        P(x + w * u1, y + d + 0.35, h - 4),
        P(x + w * u1, y - 0.1, h + 10),
        P(x + w * u0, y - 0.1, h + 10),
      ],
      i % 2 ? colors[0] : colors[1],
    );
  }
  // товары
  for (let i = 0; i < 5; i++) {
    const p = P(x + 0.3 + i * 0.4, y + d - 0.3, 18);
    ctx.beginPath();
    ctx.arc(p[0], p[1] - 4, 5, 0, Math.PI * 2);
    ctx.fillStyle = ['#d8382f', '#f2cf6b', '#7bc954', '#e9863a', '#d8382f'][i]!;
    ctx.fill();
    ctx.lineWidth = 1.4;
    ctx.strokeStyle = INK;
    ctx.stroke();
  }
  return P(x + w / 2, y + d / 2, h + 26);
}

function market(seed: number): AnimatedBuilding {
  const { canvas, ctx } = makeCanvas(480, 480, 2);
  ground(ctx, seed);
  // площадь: светлая брусчатка
  poly(ctx, [P(0.6, 0.6), P(8.4, 0.6), P(8.4, 8.4), P(0.6, 8.4)], '#d9c9a2', 0);
  for (let i = 0; i < 40; i++) {
    const p = P(0.8 + ((i * 37) % 76) / 10, 0.8 + ((i * 53) % 76) / 10);
    ctx.beginPath();
    ctx.ellipse(p[0], p[1], 6, 2.6, 0, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(120,95,60,.35)';
    ctx.lineWidth = 1;
    ctx.stroke();
  }
  const tops: Pt[] = [];
  tops.push(stall(ctx, 1.0, 1.2, ['#d8382f', '#fff3d6'], seed + 1));
  tops.push(stall(ctx, 4.5, 1.0, ['#2e5fa8', '#fff3d6'], seed + 2));
  tops.push(stall(ctx, 1.4, 5.0, ['#3f9a4a', '#fff3d6'], seed + 3));
  // центральный колодец/фонтан
  const c = P(6.2, 5.6);
  ctx.beginPath();
  ctx.ellipse(c[0], c[1], 30, 14, 0, 0, Math.PI * 2);
  ctx.fillStyle = '#a9a396';
  ctx.fill();
  ctx.lineWidth = 2.4;
  ctx.strokeStyle = INK;
  ctx.stroke();
  ctx.beginPath();
  ctx.ellipse(c[0], c[1] - 2, 24, 10, 0, 0, Math.PI * 2);
  ctx.fillStyle = '#56a9e0';
  ctx.fill();
  crate(ctx, 7.0, 7.0);
  barrel(ctx, 4.6, 7.4);
  const overlay: Overlay = (g, t) => {
    tops.forEach((p, i) => {
      line(g, [p[0] + 4, p[1] + 30], [p[0] + 4, p[1]], INK, 4);
      flag(
        g,
        p[0] + 4,
        p[1] - 2,
        t + i,
        26,
        14,
        ['#d8382f', '#2e5fa8', '#3f9a4a'][i]!,
        PALETTE.gold,
      );
    });
    // фонтан: струя и рябь
    for (let i = 0; i < 6; i++) {
      const a = (t * 0.9 + i / 6) % 1;
      g.beginPath();
      g.arc(c[0] + (a - 0.5) * 18, c[1] - 6 - Math.sin(a * Math.PI) * 18, 2.2, 0, Math.PI * 2);
      g.fillStyle = 'rgba(200,235,255,.9)';
      g.fill();
    }
    const k = (t * 0.7) % 1;
    g.beginPath();
    g.ellipse(c[0], c[1] - 2, 6 + k * 18, 2.5 + k * 7, 0, 0, Math.PI * 2);
    g.strokeStyle = `rgba(255,255,255,${0.8 - k * 0.8})`;
    g.lineWidth = 1.4;
    g.stroke();
  };
  return { base: canvas, overlay };
}

// ── Башня мага ──────────────────────────────────────────────────────────────

function mage(seed: number): AnimatedBuilding {
  const { canvas, ctx } = makeCanvas(480, 480, 2);
  ground(ctx, seed);
  // руны на земле
  const c0 = P(4.5, 5.6);
  ctx.save();
  ctx.translate(c0[0], c0[1]);
  ctx.scale(1, 0.5);
  ctx.strokeStyle = 'rgba(120,200,255,.75)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, 0, 70, 0, Math.PI * 2);
  ctx.moveTo(62, 0);
  ctx.arc(0, 0, 62, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();
  shadowOf(ctx, 3.2, 2.2, 6.0, 5.0);
  const bx = 3.3;
  const by = 2.3;
  const bw = 2.4;
  wallBox(ctx, bx - 0.25, by - 0.25, 0, bw + 0.5, bw + 0.5, 22, 'stone', seed + 1);
  wallBox(ctx, bx, by, 22, bw, bw, 100, 'stone', seed + 2, {
    left: (len, hh) => {
      ctx.fillStyle = '#2b2a55';
      ctx.beginPath();
      ctx.roundRect(len / 2 - 11, hh - 28, 22, 28, [11, 11, 0, 0]);
      ctx.fill();
      ctx.lineWidth = 2.2;
      ctx.strokeStyle = INK;
      ctx.stroke();
      windowGlow(ctx, len / 2 - 7, hh - 76, 14, 22);
    },
    right: (len, hh) => windowGlow(ctx, len / 2 - 7, hh - 70, 14, 22),
  });
  aoStrip(ctx, 'left', bx, by, 22, bw, bw, 100);
  // верхний этаж — шире
  wallBox(ctx, bx - 0.2, by - 0.2, 122, bw + 0.4, bw + 0.4, 34, 'stone', seed + 3, {
    left: (len, hh) => windowGlow(ctx, len / 2 - 8, hh / 2 - 10, 16, 20),
    right: (len, hh) => windowGlow(ctx, len / 2 - 8, hh / 2 - 10, 16, 20),
  });
  // верхняя плита под крышей
  poly(
    ctx,
    [
      P(bx - 0.2, by - 0.2, 156),
      P(bx + bw + 0.2, by - 0.2, 156),
      P(bx + bw + 0.2, by + bw + 0.2, 156),
      P(bx - 0.2, by + bw + 0.2, 156),
    ],
    '#8d887c',
  );
  // синяя остроконечная крыша
  const [cx, cy] = P(bx + bw / 2, by + bw / 2, 156);
  const apexY = cy - 78;
  const rx = 42;
  ctx.beginPath();
  ctx.moveTo(cx, apexY);
  ctx.quadraticCurveTo(cx - rx * 0.4, cy - 34, cx - rx, cy);
  ctx.ellipse(cx, cy, rx, rx * 0.5, 0, Math.PI, 0, true);
  ctx.quadraticCurveTo(cx + rx * 0.4, cy - 34, cx, apexY);
  ctx.closePath();
  const g = ctx.createLinearGradient(cx - rx, 0, cx + rx, 0);
  g.addColorStop(0, '#6c7cff');
  g.addColorStop(0.55, '#3a3fb8');
  g.addColorStop(1, '#22235f');
  ctx.fillStyle = g;
  ctx.fill();
  ctx.lineWidth = 2.6;
  ctx.strokeStyle = INK;
  ctx.stroke();
  for (const [dx, dy] of [
    [-12, -22],
    [10, -34],
    [-2, -52],
  ] as const) {
    ctx.fillStyle = PALETTE.gold;
    ctx.beginPath();
    ctx.arc(cx + dx, cy + dy, 2.4, 0, Math.PI * 2);
    ctx.fill();
  }
  beam3d(ctx, P(bx - 0.2, by + bw + 0.2, 122), P(bx + bw + 0.2, by + bw + 0.2, 122), 4);
  const overlay: Overlay = (c, t) => {
    // парящий кристалл над шпилем
    const fy = apexY - 26 + Math.sin(t * 2) * 4;
    glow(c, cx, fy, 40, 'rgba(120,220,255,1)', 0.45 + Math.sin(t * 3) * 0.12);
    c.save();
    c.translate(cx, fy);
    c.rotate(Math.sin(t * 1.4) * 0.2);
    c.beginPath();
    c.moveTo(0, -14);
    c.lineTo(8, 0);
    c.lineTo(0, 14);
    c.lineTo(-8, 0);
    c.closePath();
    const gg = c.createLinearGradient(-8, -14, 8, 14);
    gg.addColorStop(0, '#ffffff');
    gg.addColorStop(0.5, '#8be8ff');
    gg.addColorStop(1, '#3a7bd5');
    c.fillStyle = gg;
    c.fill();
    c.lineWidth = 2;
    c.strokeStyle = INK;
    c.stroke();
    c.restore();
    // искры, кружащие вокруг
    for (let i = 0; i < 6; i++) {
      const a = t * 1.3 + (i * Math.PI * 2) / 6;
      const px = cx + Math.cos(a) * 28;
      const py = fy + Math.sin(a) * 10;
      c.beginPath();
      c.arc(px, py, 1.8 + Math.sin(t * 6 + i) * 0.6, 0, Math.PI * 2);
      c.fillStyle = 'rgba(200,245,255,.95)';
      c.fill();
    }
    // руны на земле пульсируют
    const a = 0.25 + (Math.sin(t * 2.4) + 1) * 0.12;
    glow(c, c0[0], c0[1], 84, 'rgba(120,200,255,1)', a);
  };
  return { base: canvas, overlay };
}

// ── Казармы ─────────────────────────────────────────────────────────────────

function barracks(seed: number): AnimatedBuilding {
  const { canvas, ctx } = makeCanvas(480, 480, 2);
  ground(ctx, seed);
  shadowOf(ctx, 1.0, 1.4, 7.8, 5.2);
  // тренировочная площадка
  poly(ctx, [P(0.5, 5.4), P(8.5, 5.4), P(8.5, 8.6), P(0.5, 8.6)], '#c9ab72', 0);
  const hx = 1.0;
  const hy = 1.4;
  const hw = 6.8;
  const hd = 3.4;
  wallBox(ctx, hx, hy, 0, hw, hd, 50, 'timber', seed + 1, {
    left: (len, hh) => {
      for (const u of [0.14, 0.78]) windowGlow(ctx, len * u, hh - 40, 16, 22);
      ctx.fillStyle = '#4a2d12';
      ctx.beginPath();
      ctx.roundRect(len * 0.44, hh - 38, 32, 38, [14, 14, 0, 0]);
      ctx.fill();
      ctx.lineWidth = 2.4;
      ctx.strokeStyle = INK;
      ctx.stroke();
    },
    right: (len, hh) => windowGlow(ctx, len / 2 - 8, hh - 40, 16, 22),
  });
  aoStrip(ctx, 'left', hx, hy, 0, hw, hd, 50);
  gable(
    ctx,
    {
      x0: hx - 0.1,
      x1: hx + hw + 0.1,
      y0: hy - 0.1,
      y1: hy + hd + 0.1,
      z: 50,
      rise: 38,
      axis: 'x',
      over: 0.45,
    },
    seed + 2,
  );
  // мишень-манекен и стойка с копьями
  const d = P(3.0, 7.0);
  line(ctx, [d[0], d[1]], [d[0], d[1] - 44], INK, 6);
  line(ctx, [d[0], d[1]], [d[0], d[1] - 44], '#8a5a2c', 3.4);
  line(ctx, [d[0] - 16, d[1] - 34], [d[0] + 16, d[1] - 34], INK, 5);
  line(ctx, [d[0] - 16, d[1] - 34], [d[0] + 16, d[1] - 34], '#8a5a2c', 2.6);
  ctx.beginPath();
  ctx.arc(d[0], d[1] - 52, 9, 0, Math.PI * 2);
  ctx.fillStyle = '#d9b04a';
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.strokeStyle = INK;
  ctx.stroke();
  const rack = P(6.6, 6.4);
  for (let i = 0; i < 4; i++) {
    line(ctx, [rack[0] - 14 + i * 9, rack[1]], [rack[0] - 10 + i * 9, rack[1] - 46], INK, 3.4);
    line(
      ctx,
      [rack[0] - 14 + i * 9, rack[1]],
      [rack[0] - 10 + i * 9, rack[1] - 46],
      '#8a5a2c',
      1.6,
    );
    poly(
      ctx,
      [
        [rack[0] - 13 + i * 9, rack[1] - 54],
        [rack[0] - 7 + i * 9, rack[1] - 46],
        [rack[0] - 14 + i * 9, rack[1] - 46],
      ],
      '#cfd6de',
    );
  }
  const flagBase = [P(hx + 0.4, hy + hd, 50), P(hx + hw - 0.4, hy + hd, 50)];
  const torch = P(hx + hw * 0.44 + 0.2, hy + hd + 0.1, 40);
  const overlay: Overlay = (c, t) => {
    flagBase.forEach((p, i) => {
      line(c, [p[0], p[1]], [p[0], p[1] - 56], INK, 4);
      line(c, [p[0], p[1]], [p[0], p[1] - 56], '#8a5a2c', 2);
      flag(c, p[0], p[1] - 56, t + i * 1.3, 30, 18, i ? '#2e5fa8' : '#d8382f', PALETTE.gold);
    });
    flame(c, torch[0] - 22, torch[1] + 6, t, 0.55, 3);
    glow(c, torch[0] - 22, torch[1] - 4, 30, 'rgba(255,170,60,1)', 0.3 * flicker(t, 4));
  };
  return { base: canvas, overlay };
}

// ── Лесопилка ───────────────────────────────────────────────────────────────

function sawmill(seed: number): AnimatedBuilding {
  const { canvas, ctx } = makeCanvas(480, 480, 2);
  const r = rng(seed);
  ground(ctx, seed);
  shadowOf(ctx, 1.4, 1.4, 7.4, 5.6);
  // задняя стена, навес на столбах, верстак
  wallBox(ctx, 1.6, 1.6, 0, 5.4, 0.35, 62, 'plank', seed + 1);
  for (const [x, y] of [
    [1.6, 5.3],
    [7.0, 5.3],
  ] as const) {
    const a = P(x, y, 0);
    const b = P(x, y, 62);
    line(ctx, [a[0], a[1]], [b[0], b[1]], INK, 7);
    line(ctx, [a[0], a[1]], [b[0], b[1]], '#8a5a2c', 4);
  }
  gable(
    ctx,
    { x0: 1.4, x1: 7.2, y0: 1.4, y1: 5.5, z: 62, rise: 34, axis: 'x', over: 0.4 },
    seed + 2,
  );
  wallBox(ctx, 2.6, 3.6, 0, 3.4, 1.1, 22, 'plank', seed + 3);
  const saw = P(4.3, 4.75, 30);
  // поленница и брёвна
  for (let row = 0; row < 3; row++)
    for (let i = 0; i < 4 - row; i++) {
      const p = P(6.4 + i * 0.22 + row * 0.11, 6.2 + i * 0.22 - row * 0.11, 10 + row * 9);
      ctx.beginPath();
      ctx.ellipse(p[0], p[1], 8, 4.6, 0, 0, Math.PI * 2);
      ctx.fillStyle = '#c38a4a';
      ctx.fill();
      ctx.lineWidth = 1.8;
      ctx.strokeStyle = INK;
      ctx.stroke();
      ctx.beginPath();
      ctx.ellipse(p[0], p[1], 4, 2.3, 0, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(90,50,20,.6)';
      ctx.stroke();
    }
  barrel(ctx, 0.9, 6.6);
  void r;
  const overlay: Overlay = (c, t) => {
    // пильный диск
    c.save();
    c.translate(saw[0], saw[1]);
    c.scale(1, 0.8);
    c.rotate(t * 14);
    c.beginPath();
    const teeth = 14;
    for (let i = 0; i < teeth * 2; i++) {
      const a = (i / (teeth * 2)) * Math.PI * 2;
      const rad = i % 2 ? 13 : 17;
      c.lineTo(Math.cos(a) * rad, Math.sin(a) * rad);
    }
    c.closePath();
    c.fillStyle = '#c7ccd6';
    c.fill();
    c.lineWidth = 1.8;
    c.strokeStyle = INK;
    c.stroke();
    c.beginPath();
    c.arc(0, 0, 3.4, 0, Math.PI * 2);
    c.fillStyle = '#6d7480';
    c.fill();
    c.restore();
    // опилки
    for (let i = 0; i < 9; i++) {
      const a = (t * 1.5 + i / 9) % 1;
      c.beginPath();
      c.arc(
        saw[0] + 8 + a * 26,
        saw[1] + 6 - Math.sin(a * Math.PI) * 14 + a * 14,
        1.5,
        0,
        Math.PI * 2,
      );
      c.fillStyle = `rgba(240,210,150,${1 - a})`;
      c.fill();
    }
  };
  return { base: canvas, overlay };
}

// ── Шахта / карьер (золото, камень, алмазы) ─────────────────────────────────

type MineVariant = 'gold' | 'stone' | 'gems';

function mine(seed: number, variant: MineVariant): AnimatedBuilding {
  const { canvas, ctx } = makeCanvas(480, 480, 2);
  ground(ctx, seed);
  const c = P(4.5, 3.4);
  const facet = (pts: Array<[number, number]>, a: string, b: string): void => {
    poly(
      ctx,
      pts.map(([x, y]) => [c[0] + x, c[1] + y] as Pt),
      linear(ctx, c[0] - 100, c[1] - 100, c[0] + 100, c[1] + 40, [
        [0, a],
        [1, b],
      ]),
    );
  };
  const stoneA = variant === 'stone' ? '#d8d2c4' : '#b5afa3';
  facet(
    [
      [-118, 20],
      [-76, -52],
      [-24, -104],
      [14, -58],
      [0, 40],
    ],
    stoneA,
    '#8a8478',
  );
  facet(
    [
      [14, -58],
      [58, -96],
      [116, -20],
      [122, 14],
      [0, 44],
      [0, 40],
    ],
    '#a39d90',
    '#5f5a50',
  );
  facet(
    [
      [-24, -104],
      [8, -120],
      [58, -96],
      [14, -58],
    ],
    '#e3ded2',
    '#b5afa3',
  );
  // жилы
  const vein = variant === 'gold' ? '#ffd24a' : variant === 'gems' ? '#6fe0ff' : '#efe9dc';
  ctx.fillStyle = vein;
  for (const [x, y] of [
    [-60, -18],
    [-34, -44],
    [44, -40],
    [70, -10],
    [-82, 8],
  ] as const) {
    ctx.beginPath();
    ctx.moveTo(c[0] + x, c[1] + y - 7);
    ctx.lineTo(c[0] + x + 5, c[1] + y);
    ctx.lineTo(c[0] + x, c[1] + y + 7);
    ctx.lineTo(c[0] + x - 5, c[1] + y);
    ctx.closePath();
    ctx.fill();
    ctx.lineWidth = 1.4;
    ctx.strokeStyle = INK;
    ctx.stroke();
  }
  // вход: тёмный проём с креплением
  ctx.beginPath();
  ctx.moveTo(c[0] - 26, c[1] + 40);
  ctx.lineTo(c[0] - 26, c[1] + 6);
  ctx.quadraticCurveTo(c[0], c[1] - 22, c[0] + 26, c[1] + 6);
  ctx.lineTo(c[0] + 26, c[1] + 44);
  ctx.closePath();
  ctx.fillStyle = '#1d1410';
  ctx.fill();
  ctx.lineWidth = 3;
  ctx.strokeStyle = INK;
  ctx.stroke();
  for (const dx of [-28, 28])
    line(ctx, [c[0] + dx, c[1] + 46], [c[0] + dx, c[1] + 4], '#8a5a2c', 7);
  line(ctx, [c[0] - 32, c[1] + 2], [c[0] + 32, c[1] + 2], '#8a5a2c', 7);
  // рельсы к тележке
  const r0 = P(3.9, 4.5);
  const r1 = P(5.4, 7.4);
  line(ctx, [r0[0] - 8, r0[1]], [r1[0] - 8, r1[1]], INK, 3);
  line(ctx, [r0[0] + 8, r0[1]], [r1[0] + 8, r1[1]], INK, 3);
  for (let i = 0; i <= 8; i++) {
    const k = i / 8;
    const x = r0[0] + (r1[0] - r0[0]) * k;
    const y = r0[1] + (r1[1] - r0[1]) * k;
    line(ctx, [x - 11, y], [x + 11, y], '#8a5a2c', 3);
  }
  crate(ctx, 7.0, 4.4);
  barrel(ctx, 1.2, 6.8);
  const glint =
    variant === 'gold'
      ? 'rgba(255,240,150,1)'
      : variant === 'gems'
        ? 'rgba(170,240,255,1)'
        : 'rgba(255,255,255,1)';
  const overlay: Overlay = (g, t) => {
    // тележка ездит по рельсам
    const k = (Math.sin(t * 0.9) + 1) / 2;
    const x = r0[0] + (r1[0] - r0[0]) * (0.2 + 0.7 * k);
    const y = r0[1] + (r1[1] - r0[1]) * (0.2 + 0.7 * k);
    g.beginPath();
    g.roundRect(x - 15, y - 20, 30, 18, 3);
    g.fillStyle = '#6d7480';
    g.fill();
    g.lineWidth = 2;
    g.strokeStyle = INK;
    g.stroke();
    g.fillStyle = vein;
    g.beginPath();
    g.arc(x - 6, y - 22, 5, 0, Math.PI * 2);
    g.arc(x + 4, y - 23, 6, 0, Math.PI * 2);
    g.fill();
    for (const cc of [
      [x - 10, y - 2],
      [x + 10, y - 2],
    ] as const) {
      g.beginPath();
      g.arc(cc[0], cc[1], 4, 0, Math.PI * 2);
      g.fillStyle = '#2a2a30';
      g.fill();
    }
    // мерцание жил и фонарь у входа
    [
      [-60, -18],
      [-34, -44],
      [44, -40],
      [70, -10],
    ].forEach(([dx, dy], i) => {
      const a = Math.max(0, Math.sin(t * 2.4 + i * 1.7)) ** 6;
      glow(g, c[0] + dx!, c[1] + dy!, 18, glint, a * 0.9);
    });
    glow(g, c[0] + 34, c[1] + 18, 26, 'rgba(255,190,80,1)', 0.35 * flicker(t, 7));
  };
  return { base: canvas, overlay };
}

// ── Рыбацкая пристань ───────────────────────────────────────────────────────

function fishery(seed: number): AnimatedBuilding {
  const { canvas, ctx } = makeCanvas(480, 480, 2);
  ground(ctx, seed);
  // водоём на передней правой половине
  const wpts: Pt[] = [P(3.2, 4.0), P(8.6, 4.0), P(8.6, 8.6), P(3.2, 8.6)];
  poly(
    ctx,
    wpts,
    linear(ctx, 0, wpts[0]![1], 0, wpts[2]![1], [
      [0, PALETTE.water[0]],
      [1, PALETTE.water[1]],
    ]),
  );
  // хижина
  shadowOf(ctx, 1.0, 1.2, 4.0, 4.0);
  wallBox(ctx, 1.0, 1.2, 0, 3.0, 2.6, 42, 'plank', seed + 1, {
    left: (len, hh) => {
      windowGlow(ctx, len * 0.16, hh - 30, 14, 18);
      ctx.fillStyle = '#4a2d12';
      ctx.beginPath();
      ctx.roundRect(len * 0.56, hh - 34, 22, 34, [10, 10, 0, 0]);
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.strokeStyle = INK;
      ctx.stroke();
    },
  });
  gable(
    ctx,
    { x0: 0.9, x1: 4.1, y0: 1.1, y1: 3.9, z: 42, rise: 32, axis: 'x', over: 0.4 },
    seed + 2,
  );
  const top = chimney(ctx, 1.3, 1.5, 40, 50, seed + 3);
  // причал
  for (let i = 0; i < 9; i++) {
    const a = P(3.4 + i * 0.5, 5.6, 6);
    const b = P(3.4 + i * 0.5, 6.4, 6);
    poly(
      ctx,
      [a, b, [b[0] + 12, b[1] - 6], [a[0] + 12, a[1] - 6]],
      i % 2 ? '#b58348' : '#a06f3a',
      1.6,
    );
  }
  for (let i = 0; i < 4; i++) {
    const p = P(3.6 + i * 1.3, 6.4, 0);
    line(ctx, [p[0], p[1] + 10], [p[0], p[1] - 4], INK, 6);
    line(ctx, [p[0], p[1] + 10], [p[0], p[1] - 4], '#6b421a', 3);
  }
  // сети на стойках
  const n = P(1.2, 5.4);
  line(ctx, [n[0], n[1]], [n[0], n[1] - 40], INK, 5);
  line(ctx, [n[0] + 50, n[1] + 22], [n[0] + 50, n[1] - 18], INK, 5);
  for (let i = 0; i <= 6; i++)
    line(
      ctx,
      [n[0] + i * 8, n[1] + i * 3.6 - 34],
      [n[0] + i * 8, n[1] + i * 3.6 - 4],
      'rgba(120,90,50,.7)',
      1.2,
    );
  for (let i = 0; i <= 4; i++)
    line(ctx, [n[0], n[1] - 34 + i * 7], [n[0] + 50, n[1] - 12 + i * 7], 'rgba(120,90,50,.7)', 1.2);
  barrel(ctx, 0.9, 7.0);
  const w0 = P(6.4, 7.0);
  const overlay: Overlay = (g, t) => {
    smoke(g, top[0], top[1], t, seed, 5);
    // рябь
    for (let i = 0; i < 6; i++) {
      const a = (t * 0.4 + i / 6) % 1;
      g.beginPath();
      g.ellipse(
        w0[0] - 40 + i * 24,
        w0[1] - 20 + ((i * 37) % 30),
        4 + a * 16,
        (4 + a * 16) * 0.42,
        0,
        0,
        Math.PI * 2,
      );
      g.strokeStyle = `rgba(255,255,255,${0.6 * (1 - a)})`;
      g.lineWidth = 1.4;
      g.stroke();
    }
    // лодка покачивается
    g.save();
    g.translate(w0[0] + 10, w0[1] - 6 + Math.sin(t * 2) * 2.4);
    g.rotate(Math.sin(t * 1.6) * 0.06);
    g.beginPath();
    g.moveTo(-30, -6);
    g.quadraticCurveTo(-20, 12, 0, 12);
    g.quadraticCurveTo(22, 12, 32, -8);
    g.lineTo(-30, -6);
    g.fillStyle = '#b57d42';
    g.fill();
    g.lineWidth = 2.2;
    g.strokeStyle = INK;
    g.stroke();
    line(g, [0, -6], [0, -34], INK, 4);
    line(g, [0, -6], [0, -34], '#8a5a2c', 2);
    poly(
      g,
      [
        [2, -34],
        [24, -10],
        [2, -10],
      ],
      '#f3e8c8',
      1.8,
    );
    g.restore();
    // прыгающая рыбка
    const f = (t * 0.35) % 1;
    if (f < 0.3) {
      const k = f / 0.3;
      g.save();
      g.translate(w0[0] - 34 + k * 26, w0[1] + 8 - Math.sin(k * Math.PI) * 26);
      g.rotate(Math.cos(k * Math.PI) * -0.9);
      g.beginPath();
      g.ellipse(0, 0, 8, 3.6, 0, 0, Math.PI * 2);
      g.fillStyle = '#ff9a4a';
      g.fill();
      g.lineWidth = 1.4;
      g.strokeStyle = INK;
      g.stroke();
      g.restore();
    }
  };
  return { base: canvas, overlay };
}

// ── Башни: стрелковая и штормовая ───────────────────────────────────────────

function watchtower(seed: number, storm: boolean): AnimatedBuilding {
  const { canvas, ctx } = makeCanvas(480, 480, 2);
  ground(ctx, seed);
  shadowOf(ctx, 3.0, 2.6, 6.0, 5.6);
  const bx = 3.3;
  const by = 2.8;
  const bw = 2.4;
  wallBox(ctx, bx - 0.25, by - 0.25, 0, bw + 0.5, bw + 0.5, 26, 'stone', seed + 1);
  wallBox(ctx, bx, by, 26, bw, bw, 110, 'stone', seed + 2, {
    left: (len, hh) => {
      ctx.fillStyle = '#2a1a12';
      ctx.beginPath();
      ctx.roundRect(len / 2 - 11, hh - 30, 22, 30, [11, 11, 0, 0]);
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.strokeStyle = INK;
      ctx.stroke();
      ctx.fillStyle = '#1d1410';
      ctx.fillRect(len / 2 - 3, hh - 84, 6, 20);
    },
    right: (len, hh) => {
      ctx.fillStyle = '#1d1410';
      ctx.fillRect(len / 2 - 3, hh - 70, 6, 20);
    },
  });
  aoStrip(ctx, 'left', bx, by, 26, bw, bw, 110);
  // боевая площадка с зубцами
  wallBox(ctx, bx - 0.3, by - 0.3, 136, bw + 0.6, bw + 0.6, 12, 'stone', seed + 3);
  const z = 148;
  for (let i = 0; i < 3; i++) {
    wallBox(
      ctx,
      bx - 0.3 + i * 1.02,
      by + bw + 0.3 - 0.35,
      z,
      0.5,
      0.35,
      12,
      'stone',
      seed + 4 + i,
    );
    wallBox(
      ctx,
      bx + bw + 0.3 - 0.35,
      by - 0.3 + i * 1.02,
      z,
      0.35,
      0.5,
      12,
      'stone',
      seed + 8 + i,
    );
  }
  const tip = P(bx + bw / 2, by + bw / 2, z);
  if (storm) {
    // кристалл-проводник
    ctx.beginPath();
    ctx.moveTo(tip[0], tip[1] - 62);
    ctx.lineTo(tip[0] + 12, tip[1] - 30);
    ctx.lineTo(tip[0], tip[1] - 6);
    ctx.lineTo(tip[0] - 12, tip[1] - 30);
    ctx.closePath();
    ctx.fillStyle = linear(ctx, tip[0] - 12, tip[1] - 62, tip[0] + 12, tip[1] - 6, [
      [0, '#ffffff'],
      [0.5, '#b39bff'],
      [1, '#5b3fd0'],
    ]);
    ctx.fill();
    ctx.lineWidth = 2.4;
    ctx.strokeStyle = INK;
    ctx.stroke();
  } else {
    // шатёр над площадкой
    cone(ctx, tip[0], tip[1] - 6, 46, 50, seed + 12);
  }
  barrel(ctx, 6.6, 5.8);
  const overlay: Overlay = (g, t) => {
    if (storm) {
      const cyc = (t * 0.55) % 1;
      const on = cyc < 0.18;
      glow(
        g,
        tip[0],
        tip[1] - 34,
        34,
        'rgba(160,140,255,1)',
        0.35 + (on ? 0.5 : Math.sin(t * 4) * 0.08),
      );
      if (on) {
        const r2 = rng(Math.floor(t * 0.55) + 3);
        g.strokeStyle = '#f2eaff';
        g.lineWidth = 3;
        g.shadowColor = '#b39bff';
        g.shadowBlur = 12;
        for (let b = 0; b < 2; b++) {
          g.beginPath();
          let x = tip[0];
          let y = tip[1] - 62;
          g.moveTo(x, y);
          for (let i = 0; i < 6; i++) {
            x += (r2() - 0.5) * 34 + (b ? 10 : -10);
            y -= 14 + r2() * 10;
            g.lineTo(x, y);
          }
          g.stroke();
        }
        g.shadowBlur = 0;
      }
    } else {
      // стрела периодически летит из бойницы на площадке
      const cyc = (t * 0.6) % 1;
      if (cyc < 0.5) {
        const k = cyc / 0.5;
        const x = tip[0] + 10 + k * 120;
        const y = tip[1] + 6 - Math.sin(k * Math.PI) * 40 + k * 50;
        g.save();
        g.translate(x, y);
        g.rotate(-0.5 + k * 1.3);
        line(g, [-14, 0], [10, 0], INK, 3.4);
        line(g, [-14, 0], [10, 0], '#e8d8a8', 1.6);
        poly(
          g,
          [
            [10, -3],
            [18, 0],
            [10, 3],
          ],
          '#cfd6de',
          1,
        );
        g.restore();
      }
      flag(g, tip[0] - 2, tip[1] - 92, t, 28, 15, PALETTE.royal, PALETTE.gold);
    }
  };
  return { base: canvas, overlay };
}

// ── Госпиталь ───────────────────────────────────────────────────────────────

function hospital(seed: number): AnimatedBuilding {
  const { canvas, ctx } = makeCanvas(480, 480, 2);
  ground(ctx, seed);
  shadowOf(ctx, 1.4, 1.4, 7.2, 5.8);
  // грядки трав
  for (const [x0, y0] of [
    [0.7, 6.2],
    [4.2, 6.6],
  ] as const) {
    poly(ctx, [P(x0, y0), P(x0 + 2.6, y0), P(x0 + 2.6, y0 + 1.1), P(x0, y0 + 1.1)], '#6a4a2a', 0);
    for (let i = 0; i < 8; i++) {
      const p = P(x0 + 0.2 + i * 0.3, y0 + 0.55);
      ctx.beginPath();
      ctx.arc(p[0], p[1] - 6, 4.2, 0, Math.PI * 2);
      ctx.fillStyle = ['#6fd05a', '#9be06a', '#f07aa0'][i % 3]!;
      ctx.fill();
      ctx.lineWidth = 1.2;
      ctx.strokeStyle = INK;
      ctx.stroke();
    }
  }
  const hx = 1.4;
  const hy = 1.4;
  const hw = 5.6;
  const hd = 3.6;
  wallBox(ctx, hx, hy, 0, hw, hd, 52, 'timber', seed + 1, {
    left: (len, hh) => {
      for (const u of [0.12, 0.3, 0.66, 0.84]) windowGlow(ctx, len * u, hh - 40, 14, 20);
      ctx.fillStyle = '#4a2d12';
      ctx.beginPath();
      ctx.roundRect(len * 0.46, hh - 38, 26, 38, [12, 12, 0, 0]);
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.strokeStyle = INK;
      ctx.stroke();
    },
    right: (len, hh) => windowGlow(ctx, len / 2 - 7, hh - 40, 14, 20),
  });
  aoStrip(ctx, 'left', hx, hy, 0, hw, hd, 52);
  gable(
    ctx,
    {
      x0: hx - 0.1,
      x1: hx + hw + 0.1,
      y0: hy - 0.1,
      y1: hy + hd + 0.1,
      z: 52,
      rise: 40,
      axis: 'x',
      over: 0.45,
    },
    seed + 2,
  );
  // красный крест над входом
  const cp = P(hx + hw * 0.5 + 0.1, hy + hd + 0.05, 66);
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(cp[0], cp[1], 15, 0, Math.PI * 2);
  ctx.fill();
  ctx.lineWidth = 2.2;
  ctx.strokeStyle = INK;
  ctx.stroke();
  ctx.fillStyle = '#d8382f';
  ctx.fillRect(cp[0] - 3.5, cp[1] - 10, 7, 20);
  ctx.fillRect(cp[0] - 10, cp[1] - 3.5, 20, 7);
  const top = chimney(ctx, hx + 0.4, hy + 0.5, 60, 40, seed + 3);
  barrel(ctx, 7.3, 6.4);
  const overlay: Overlay = (g, t) => {
    smoke(g, top[0], top[1], t, seed, 4);
    // исцеляющие плюсики поднимаются над крышей
    for (let i = 0; i < 5; i++) {
      const a = (t * 0.35 + i / 5) % 1;
      const x = cp[0] - 70 + i * 34 + Math.sin(t * 2 + i) * 4;
      const y = cp[1] + 10 - a * 70;
      g.save();
      g.globalAlpha = Math.sin(a * Math.PI);
      g.fillStyle = '#7dff8a';
      g.fillRect(x - 1.8, y - 6, 3.6, 12);
      g.fillRect(x - 6, y - 1.8, 12, 3.6);
      g.restore();
    }
  };
  return { base: canvas, overlay };
}

// ── Форт (анимируется вымпел, дым и свет) ───────────────────────────────────

function fort(seed: number): AnimatedBuilding {
  const base = renderFort({ seed, dynamic: true, flat, level: Math.min(3, Math.max(1, seed % 4)) });
  const overlay: Overlay = (c, t) => {
    const [px, py] = FORT_PENNANT;
    line(c, [px, py + 62], [px, py + 40], INK, 3.4);
    line(c, [px, py + 40], [px, py + 18], INK, 3.4);
    line(c, [px, py + 62], [px, py + 18], '#6b421a', 1.8);
    flag(c, px, py + 18, t, 30, 16, PALETTE.royal, PALETTE.gold);
    glow(c, P(2.6, 6.2, 40)[0], P(2.6, 6.2, 40)[1], 40, 'rgba(255,190,70,1)', 0.14 * flicker(t, 1));
    const fx = P(5.6, 8.0, 0);
    flame(c, fx[0], fx[1] - 27, t, 0.5, 5);
  };
  return { base, overlay };
}

const MAKERS: Record<BuildingKind, (seed: number) => AnimatedBuilding> = {
  fort,
  mill,
  smithy,
  tavern,
  market,
  mage,
  barracks,
  sawmill,
  goldmine: (seed) => mine(seed, 'gold'),
  quarry: (seed) => mine(seed, 'stone'),
  gemmine: (seed) => mine(seed, 'gems'),
  fishery,
  archertower: (seed) => watchtower(seed, false),
  stormtower: (seed) => watchtower(seed, true),
  hospital,
};

const cache = new Map<string, AnimatedBuilding | null>();

/**
 * Строит (и кэширует) постройку; null — если Canvas 2D недоступен.
 * `flat` — без земляной плиты и частокола (для городской сцены).
 */
export function getBuilding(
  kind: BuildingKind,
  seed = 7,
  flatMode = false,
): AnimatedBuilding | null {
  const key = `${kind}:${seed}:${flatMode ? 'f' : 'p'}`;
  if (cache.has(key)) return cache.get(key) ?? null;
  let b: AnimatedBuilding | null = null;
  flat = flatMode;
  try {
    b = MAKERS[kind](seed);
  } catch {
    b = null;
  } finally {
    flat = false;
  }
  cache.set(key, b);
  return b;
}
