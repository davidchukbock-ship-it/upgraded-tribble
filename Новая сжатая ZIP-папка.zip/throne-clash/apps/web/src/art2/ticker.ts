/**
 * Общий «тикер» анимации: один requestAnimationFrame на все холсты сцены вместо десятков отдельных.
 * Подписчики получают время в секундах; кадры пропускаются, пока вкладка скрыта или частота ниже целевой.
 */
type Listener = (t: number) => void;

const listeners = new Set<Listener>();
let raf = 0;
let last = 0;
let t0 = 0;
const FPS = 24;

function loop(now: number): void {
  raf = requestAnimationFrame(loop);
  if (document.hidden || now - last < 1000 / FPS) return;
  last = now;
  const t = Math.max(0, now - t0) / 1000;
  for (const l of listeners) l(t);
}

/** Подписаться на кадры; возвращает функцию отписки. Тикер останавливается без подписчиков. */
export function subscribeFrames(fn: Listener): () => void {
  if (listeners.size === 0) {
    t0 = performance.now();
    raf = requestAnimationFrame(loop);
  }
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
    if (listeners.size === 0) {
      cancelAnimationFrame(raf);
      raf = 0;
    }
  };
}

export const prefersReducedMotion = (): boolean =>
  typeof window !== 'undefined' &&
  (window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false);
