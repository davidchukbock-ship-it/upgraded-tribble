/**
 * Кэш готовых спрайтов art2: каждый рисуется один раз, дальше это обычный drawImage.
 * Если Canvas 2D недоступен (тесты в jsdom), возвращается null — вызывающий код рисует запасной вариант.
 */
import { renderFort } from './fort';
import { renderRock, renderTree, type TreeKind } from './nature';

const cache = new Map<string, HTMLCanvasElement | null>();

function memo(key: string, make: () => HTMLCanvasElement): HTMLCanvasElement | null {
  if (cache.has(key)) return cache.get(key) ?? null;
  let c: HTMLCanvasElement | null = null;
  try {
    c = make();
  } catch {
    c = null;
  }
  cache.set(key, c);
  return c;
}

/** Три вариации дерева каждого вида: карта не выглядит «штампованной». */
export function treeSprite(kind: TreeKind, seed: number): HTMLCanvasElement | null {
  const v = Math.abs(Math.floor(seed * 3)) % 3;
  return memo(`tree:${kind}:${v}`, () => renderTree(kind, v + 1));
}

export function rockSprite(seed: number): HTMLCanvasElement | null {
  const v = Math.abs(Math.floor(seed * 3)) % 3;
  return memo(`rock:${v}`, () => renderRock(v + 1));
}

export function fortSprite(mine: boolean): HTMLCanvasElement | null {
  return memo(`fort:${mine ? 1 : 2}`, () => renderFort({ seed: mine ? 7 : 3 }));
}
