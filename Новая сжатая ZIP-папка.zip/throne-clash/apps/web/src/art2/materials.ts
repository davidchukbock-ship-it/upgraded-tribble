import {
  INK,
  INK_SOFT,
  PALETTE,
  duo,
  linear,
  mix,
  radial,
  rng,
  shade,
  type Ctx,
  type Pt,
} from './kit';

/** Каменная кладка в плоской системе стены: ряды блоков разного оттенка, тёмные швы, светлая верхняя кромка. */
export function brickWall(ctx: Ctx, w: number, h: number, seed: number, light = 0): void {
  const r = rng(seed);
  const rowH = 11;
  const base = [shade(PALETTE.stone[0], light), shade(PALETTE.stone[1], light)] as const;
  ctx.fillStyle = duo(ctx, 0, 0, 0, h, base[0], base[1]);
  ctx.fillRect(0, 0, w, h);
  for (let y = 0, row = 0; y < h; y += rowH, row++) {
    let x = row % 2 ? -10 : 0;
    while (x < w) {
      const bw = 16 + r() * 14;
      const t = r();
      const c = mix(base[0], base[1], 0.15 + t * 0.6);
      const x0 = Math.max(0, x);
      const x1 = Math.min(w, x + bw);
      if (x1 > x0) {
        ctx.fillStyle = c;
        ctx.beginPath();
        ctx.roundRect(x0 + 0.8, y + 0.8, x1 - x0 - 1.6, Math.min(rowH, h - y) - 1.6, 2);
        ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.18)';
        ctx.fillRect(x0 + 1.6, y + 1, Math.max(0, x1 - x0 - 3.2), 1.6);
      }
      x += bw;
    }
  }
  // швы
  ctx.strokeStyle = 'rgba(60,54,44,0.55)';
  ctx.lineWidth = 1;
  for (let y = rowH; y < h; y += rowH) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(w, y);
    ctx.stroke();
  }
}

/** Фахверк: оштукатуренные панели и деревянный каркас с подкосами. */
export function timberWall(ctx: Ctx, w: number, h: number, seed: number, light = 0): void {
  const r = rng(seed);
  ctx.fillStyle = duo(
    ctx,
    0,
    0,
    0,
    h,
    shade(PALETTE.plaster[0], light),
    shade(PALETTE.plaster[1], light),
  );
  ctx.fillRect(0, 0, w, h);
  // лёгкая штукатурная фактура
  for (let i = 0; i < w * h * 0.004; i++) {
    ctx.fillStyle = `rgba(120,90,50,${0.04 + r() * 0.06})`;
    ctx.fillRect(r() * w, r() * h, 1 + r() * 2, 1 + r() * 2);
  }
  const beam = (x0: number, y0: number, x1: number, y1: number, t: number): void => {
    ctx.save();
    ctx.lineCap = 'butt';
    ctx.strokeStyle = INK;
    ctx.lineWidth = t + 2.4;
    ctx.beginPath();
    ctx.moveTo(x0, y0);
    ctx.lineTo(x1, y1);
    ctx.stroke();
    ctx.strokeStyle = duo(
      ctx,
      x0,
      y0,
      x1 + 0.01,
      y1 + 6,
      shade(PALETTE.wood[0], light),
      shade(PALETTE.wood[1], light),
    );
    ctx.lineWidth = t;
    ctx.beginPath();
    ctx.moveTo(x0, y0);
    ctx.lineTo(x1, y1);
    ctx.stroke();
    ctx.restore();
  };
  const cols = Math.max(2, Math.round(w / 34));
  const cw = w / cols;
  beam(0, 3, w, 3, 6);
  beam(0, h - 3, w, h - 3, 6);
  for (let i = 0; i <= cols; i++)
    beam(Math.min(w - 2, Math.max(2, i * cw)), 0, Math.min(w - 2, Math.max(2, i * cw)), h, 5);
  for (let i = 0; i < cols; i++) {
    if (i % 2 === 0) beam(i * cw + 3, h - 4, (i + 1) * cw - 3, 5, 3.4);
    else beam(i * cw + 3, 5, (i + 1) * cw - 3, h - 4, 3.4);
  }
}

/** Светящееся окно с деревянной рамой и переплётом. */
export function windowGlow(ctx: Ctx, x: number, y: number, w: number, h: number, lit = true): void {
  ctx.save();
  if (lit) {
    ctx.shadowColor = 'rgba(255,200,80,0.7)';
    ctx.shadowBlur = 10;
  }
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, Math.min(5, w / 3));
  ctx.fillStyle = lit
    ? radial(ctx, x + w / 2, y + h * 0.6, 1, Math.max(w, h), [
        [0, '#fff3b0'],
        [0.45, PALETTE.windowGlow[0]],
        [1, PALETTE.windowGlow[1]],
      ])
    : '#33485e';
  ctx.fill();
  ctx.restore();
  ctx.lineWidth = 3;
  ctx.strokeStyle = duo(ctx, x, y, x, y + h, PALETTE.wood[0], PALETTE.wood[1]);
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, Math.min(5, w / 3));
  ctx.stroke();
  ctx.lineWidth = 1.2;
  ctx.strokeStyle = INK;
  ctx.stroke();
  ctx.lineWidth = 2;
  ctx.strokeStyle = PALETTE.wood[1];
  ctx.beginPath();
  ctx.moveTo(x + w / 2, y + 2);
  ctx.lineTo(x + w / 2, y + h - 2);
  ctx.moveTo(x + 2, y + h / 2);
  ctx.lineTo(x + w - 2, y + h / 2);
  ctx.stroke();
}

/** Каменная арка ворот: тёмный проём, клинчатые камни и замковый камень. */
export function stoneArch(
  ctx: Ctx,
  x: number,
  baseY: number,
  w: number,
  h: number,
  seed: number,
): void {
  const r = rng(seed);
  const top = baseY - h;
  const rad = w / 2;
  const cx = x + rad;
  // проём
  ctx.beginPath();
  ctx.moveTo(x, baseY);
  ctx.lineTo(x, top + rad);
  ctx.arc(cx, top + rad, rad, Math.PI, 0);
  ctx.lineTo(x + w, baseY);
  ctx.closePath();
  ctx.fillStyle = linear(ctx, x, top, x, baseY, [
    [0, '#2b1d12'],
    [1, '#5b3f26'],
  ]);
  ctx.fill();
  // клинчатые камни по дуге
  const n = 9;
  for (let i = 0; i < n; i++) {
    const a0 = Math.PI + (i / n) * Math.PI;
    const a1 = Math.PI + ((i + 1) / n) * Math.PI;
    const r0 = rad;
    const r1 = rad + 9;
    ctx.beginPath();
    ctx.arc(cx, top + rad, r1, a0, a1);
    ctx.arc(cx, top + rad, r0, a1, a0, true);
    ctx.closePath();
    const key = i === Math.floor(n / 2);
    ctx.fillStyle = key
      ? shade(PALETTE.stone[0], 0.25)
      : mix(PALETTE.stone[0], PALETTE.stone[1], 0.15 + r() * 0.4);
    ctx.fill();
    ctx.lineWidth = 1.6;
    ctx.strokeStyle = INK;
    ctx.stroke();
  }
  // косяки
  for (const sx of [x - 8, x + w]) {
    ctx.fillStyle = duo(ctx, sx, 0, sx + 8, 0, PALETTE.stone[0], PALETTE.stone[1]);
    ctx.fillRect(sx, top + rad, 8, baseY - top - rad);
    ctx.lineWidth = 1.6;
    ctx.strokeStyle = INK;
    ctx.strokeRect(sx, top + rad, 8, baseY - top - rad);
  }
  // створка двери внутри
  ctx.fillStyle = 'rgba(90,54,28,0.85)';
  ctx.fillRect(x + 4, top + rad + 4, w - 8, baseY - top - rad - 4);
}

/** Соломенная крыша-плоскость: пучки, лежащие рядами, с закруглённой нижней кромкой. Точки — четырёхугольник. */
export function thatchQuad(
  ctx: Ctx,
  p00: Pt,
  p10: Pt,
  p11: Pt,
  p01: Pt,
  rows: number,
  cols: number,
  seed: number,
  light = 0,
): void {
  const r = rng(seed);
  const at = (u: number, v: number): Pt => {
    const ax = p00[0] + (p10[0] - p00[0]) * u;
    const ay = p00[1] + (p10[1] - p00[1]) * u;
    const bx = p01[0] + (p11[0] - p01[0]) * u;
    const by = p01[1] + (p11[1] - p01[1]) * u;
    return [ax + (bx - ax) * v, ay + (by - ay) * v];
  };
  // основа
  ctx.beginPath();
  [p00, p10, p11, p01].forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
  ctx.closePath();
  ctx.fillStyle = shade(PALETTE.thatch[1], light - 0.05);
  ctx.fill();
  ctx.save();
  ctx.clip();
  for (let row = 0; row < rows; row++) {
    const v0 = row / rows;
    const v1 = (row + 1) / rows + 0.04;
    for (let c = 0; c <= cols; c++) {
      const u0 = (c - 0.5 + (row % 2) * 0.5) / cols;
      const u1 = u0 + 1.0 / cols;
      const a = at(u0, v0);
      const b = at(u1, v0);
      const d = at(u0, v1);
      const e = at(u1, v1);
      const mid: Pt = [(d[0] + e[0]) / 2, (d[1] + e[1]) / 2 + 2.5];
      const tone = mix(PALETTE.thatch[0], PALETTE.thatch[1], Math.min(1, v0 * 0.55 + r() * 0.35));
      ctx.beginPath();
      ctx.moveTo(a[0], a[1]);
      ctx.lineTo(b[0], b[1]);
      ctx.lineTo(e[0], e[1]);
      ctx.quadraticCurveTo(mid[0], mid[1], d[0], d[1]);
      ctx.closePath();
      ctx.fillStyle = shade(tone, light);
      ctx.fill();
      ctx.lineWidth = 1.1;
      ctx.strokeStyle = 'rgba(120,80,20,0.55)';
      ctx.stroke();
      // блик на пучке
      ctx.strokeStyle = 'rgba(255,245,190,0.5)';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(a[0] + (b[0] - a[0]) * 0.25, a[1] + (b[1] - a[1]) * 0.25 + 2);
      ctx.lineTo(d[0] + (e[0] - d[0]) * 0.3, d[1] + (e[1] - d[1]) * 0.3 - 3);
      ctx.stroke();
    }
  }
  ctx.restore();
  ctx.beginPath();
  [p00, p10, p11, p01].forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
  ctx.closePath();
  ctx.lineWidth = 2.6;
  ctx.strokeStyle = INK;
  ctx.stroke();
}

/** Деревянное бревно-балка между двумя точками с объёмом и контуром. */
export function beam3d(ctx: Ctx, a: Pt, b: Pt, t = 7): void {
  ctx.save();
  ctx.lineCap = 'round';
  ctx.strokeStyle = INK;
  ctx.lineWidth = t + 2.6;
  ctx.beginPath();
  ctx.moveTo(a[0], a[1]);
  ctx.lineTo(b[0], b[1]);
  ctx.stroke();
  ctx.strokeStyle = duo(ctx, a[0], a[1] - t, a[0], a[1] + t, PALETTE.wood[0], PALETTE.wood[1]);
  ctx.lineWidth = t;
  ctx.beginPath();
  ctx.moveTo(a[0], a[1]);
  ctx.lineTo(b[0], b[1]);
  ctx.stroke();
  ctx.strokeStyle = 'rgba(255,230,170,0.45)';
  ctx.lineWidth = Math.max(1, t * 0.22);
  ctx.beginPath();
  ctx.moveTo(a[0], a[1] - t * 0.25);
  ctx.lineTo(b[0], b[1] - t * 0.25);
  ctx.stroke();
  ctx.restore();
}

export { INK_SOFT };
