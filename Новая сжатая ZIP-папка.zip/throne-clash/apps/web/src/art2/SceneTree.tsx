import type { ReactNode } from 'react';
import { iso } from '../iso/project';
import { roll } from '../iso/props';
import { renderBush, renderTree } from './nature';

type Kind = 'oak' | 'pine' | 'bush' | 'birch';

const hrefs = new Map<string, string | null>();

/** Картинка дерева (data-URL, рисуется один раз на вид и вариант); null, если Canvas 2D недоступен. */
function href(kind: Kind, variant: number): string | null {
  const key = `${kind}:${variant}`;
  if (hrefs.has(key)) return hrefs.get(key) ?? null;
  let url: string | null = null;
  try {
    const c =
      kind === 'bush' ? renderBush(variant + 1, variant === 1) : renderTree(kind, variant + 1);
    url = c.toDataURL('image/png');
  } catch {
    url = null;
  }
  // jsdom возвращает пустую «заглушку» вместо картинки — считаем её недоступной
  if (url === 'data:,') url = null;
  hrefs.set(key, url);
  return url;
}

/** Дерево сцены в стиле art2 (тот же размер и положение, что у прежнего SVG-дерева). */
export function SceneTree({
  x,
  y,
  s = 1,
  kind,
  fallback,
}: {
  x: number;
  y: number;
  s?: number;
  kind: Kind;
  fallback: ReactNode;
}) {
  const variant = Math.floor(roll(x, y, 'tv') * 3) % 3;
  const url = href(kind, variant);
  if (!url) return <>{fallback}</>;
  const [sx, sy] = iso(x, y, 0);
  const bush = kind === 'bush';
  const k = (bush ? 0.62 : 0.5) * s;
  const [ax, ay, w, h] = bush ? [32, 42, 64, 48] : [60, 128, 120, 140];
  return (
    <image
      href={url}
      x={sx - ax * k}
      y={sy - ay * k}
      width={w * k}
      height={h * k}
      style={{ pointerEvents: 'none' }}
    />
  );
}
