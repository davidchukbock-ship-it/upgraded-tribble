import {
  INK,
  PALETTE,
  clipPoly,
  duo,
  facePoly,
  line,
  linear,
  makeCanvas,
  mix,
  onFace,
  poly,
  project,
  rng,
  shade,
  softShadow,
  type Ctx,
  type IsoView,
  type Pt,
} from './kit';
import { beam3d, brickWall, stoneArch, thatchQuad, timberWall, windowGlow } from './materials';

/**
 * Изометрическое подворье 1-го уровня: каменно-фахверковый дом с соломенными крышами (две скрещённые кровли),
 * высокая деревянная башня с балконом и конической крышей, частокол с проходом, синий вымпел с золотой короной.
 * Всё рисуется кодом: плоская графика с мягким сел-шейдингом, верхний-левый свет, тёплый контур.
 */

export const N = 9; // сторона площадки в клетках
const SOIL = 17;
export const FORT_SIZE = { w: 480, h: 480 } as const;
export const V: IsoView = { ox: 240, oy: 196, s: 26 };

export const P = (x: number, y: number, z = 0): Pt => project(V, x, y, z);

// ── Основание ───────────────────────────────────────────────────────────────

export function drawBase(ctx: Ctx, seed: number): void {
  const r = rng(seed);
  const top: Pt[] = [P(0, 0), P(N, 0), P(N, N), P(0, N)];
  const [l, b, rr] = [P(0, N), P(N, N), P(N, 0)];
  // земляной борт
  poly(
    ctx,
    [l, b, [b[0], b[1] + SOIL], [l[0], l[1] + SOIL]],
    duo(ctx, l[0], 0, b[0], 0, '#a9743f', '#7a4f28'),
  );
  poly(
    ctx,
    [b, rr, [rr[0], rr[1] + SOIL], [b[0], b[1] + SOIL]],
    duo(ctx, b[0], 0, rr[0], 0, '#6f4623', '#4f3015'),
  );
  // прожилки почвы
  ctx.save();
  ctx.strokeStyle = 'rgba(60,35,15,0.35)';
  ctx.lineWidth = 1.4;
  for (let i = 0; i < 9; i++) {
    const t = r();
    ctx.beginPath();
    const y0 = l[1] + (b[1] - l[1]) * t + 5 + r() * 6;
    const x0 = l[0] + (b[0] - l[0]) * t;
    ctx.moveTo(x0, y0);
    ctx.lineTo(x0 + 10 + r() * 14, y0 + 4 + r() * 3);
    ctx.stroke();
  }
  ctx.restore();
  // трава
  poly(
    ctx,
    top,
    linear(ctx, P(0, 0)[0], P(0, 0)[1], P(N, N)[0], P(N, N)[1], [
      [0, PALETTE.grass[0]],
      [1, PALETTE.grass[1]],
    ]),
    2.6,
  );
  ctx.save();
  clipPoly(ctx, top);
  // светлая кромка сверху-слева и тёмная справа-снизу
  ctx.lineWidth = 7;
  ctx.strokeStyle = 'rgba(200,255,140,0.35)';
  ctx.beginPath();
  ctx.moveTo(...P(0, N));
  ctx.lineTo(...P(0, 0));
  ctx.lineTo(...P(N, 0));
  ctx.stroke();
  ctx.strokeStyle = 'rgba(30,80,20,0.28)';
  ctx.beginPath();
  ctx.moveTo(...P(N, 0));
  ctx.lineTo(...P(N, N));
  ctx.lineTo(...P(0, N));
  ctx.stroke();
  // пятна, пучки травы, цветы
  for (let i = 0; i < 70; i++) {
    const [px, py] = P(r() * N, r() * N);
    ctx.fillStyle = `rgba(${r() < 0.5 ? '40,110,30' : '150,220,90'},${0.12 + r() * 0.16})`;
    ctx.beginPath();
    ctx.ellipse(px, py, 8 + r() * 12, 3 + r() * 5, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  for (let i = 0; i < 150; i++) {
    const [px, py] = P(r() * N, r() * N);
    const hgt = 4 + r() * 6;
    ctx.strokeStyle = r() < 0.5 ? '#3f8a25' : '#9be06a';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px, py);
    ctx.lineTo(px - 2, py - hgt);
    ctx.moveTo(px, py);
    ctx.lineTo(px + 2.5, py - hgt * 0.85);
    ctx.stroke();
  }
  for (let i = 0; i < 16; i++) {
    const [px, py] = P(0.6 + r() * (N - 1.2), 0.6 + r() * (N - 1.2));
    ctx.fillStyle = ['#ffe27a', '#ffffff', '#ff9ab0'][i % 3]!;
    ctx.beginPath();
    ctx.arc(px, py, 2, 0, Math.PI * 2);
    ctx.fill();
  }
  // тропа от прохода к двери
  const path: Pt[] = [P(3.5, N), P(5.2, N), P(4.6, 6.4), P(3.6, 5.3), P(3.0, 5.3), P(3.9, 6.6)];
  ctx.fillStyle = duo(
    ctx,
    path[0]![0],
    path[0]![1],
    path[3]![0],
    path[3]![1],
    PALETTE.road[1],
    PALETTE.road[0],
  );
  ctx.beginPath();
  ctx.moveTo(...path[0]!);
  ctx.quadraticCurveTo(...P(4.6, 7.9), ...path[2]!);
  ctx.lineTo(...path[3]!);
  ctx.lineTo(...path[4]!);
  ctx.quadraticCurveTo(...P(3.6, 7.6), ...path[1]!);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = 'rgba(120,85,40,0.4)';
  ctx.lineWidth = 1.5;
  ctx.stroke();
  for (let i = 0; i < 20; i++) {
    const t = r();
    const [px, py] = P(3.8 + t * 0.6 + r() * 0.6, 5.4 + (1 - t) * 3.4);
    ctx.fillStyle = 'rgba(150,120,80,0.55)';
    ctx.beginPath();
    ctx.ellipse(px, py, 2.4, 1.3, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

// ── Стены ───────────────────────────────────────────────────────────────────

export type WallKind = 'stone' | 'timber' | 'plank';

function plankWall(ctx: Ctx, w: number, h: number, seed: number, light: number): void {
  const r = rng(seed);
  ctx.fillStyle = duo(ctx, 0, 0, w, 0, shade('#a06a32', light), shade('#6b421a', light));
  ctx.fillRect(0, 0, w, h);
  const pw = 13;
  for (let x = 0; x < w; x += pw) {
    ctx.fillStyle = `rgba(${r() < 0.5 ? '255,220,160' : '40,20,5'},${0.06 + r() * 0.08})`;
    ctx.fillRect(x, 0, pw, h);
    ctx.strokeStyle = 'rgba(42,26,14,0.55)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, h);
    ctx.stroke();
    // волокна
    ctx.strokeStyle = 'rgba(60,35,12,0.3)';
    ctx.lineWidth = 0.8;
    for (let k = 0; k < 3; k++) {
      const gx = x + 3 + r() * (pw - 6);
      ctx.beginPath();
      ctx.moveTo(gx, r() * h * 0.3);
      ctx.lineTo(gx + r() * 2 - 1, h * (0.5 + r() * 0.5));
      ctx.stroke();
    }
  }
}

/** Стенка бруса: левая (освещена) и правая (в тени) грани, с выбранным материалом и контуром. */
export function wallBox(
  ctx: Ctx,
  x: number,
  y: number,
  z: number,
  w: number,
  d: number,
  h: number,
  kind: WallKind,
  seed: number,
  decor?: { left?: (len: number, hh: number) => void; right?: (len: number, hh: number) => void },
): void {
  const faces: Array<['left' | 'right', number]> = [
    ['left', 0.06],
    ['right', -0.18],
  ];
  for (const [face, light] of faces) {
    const pts = facePoly(V, face, x, y, z, w, d, h);
    ctx.save();
    clipPoly(ctx, pts);
    onFace(ctx, V, face, x, y, z, w, d, h, (len, hh) => {
      if (kind === 'stone') brickWall(ctx, len, hh, seed + (face === 'left' ? 1 : 2), light);
      else if (kind === 'timber') timberWall(ctx, len, hh, seed + 3, light);
      else plankWall(ctx, len, hh, seed + 4, light);
      (face === 'left' ? decor?.left : decor?.right)?.(len, hh);
    });
    ctx.restore();
    ctx.lineWidth = 2.6;
    ctx.strokeStyle = INK;
    ctx.beginPath();
    pts.forEach(([px, py], i) => (i ? ctx.lineTo(px, py) : ctx.moveTo(px, py)));
    ctx.closePath();
    ctx.stroke();
  }
}

/** Тёмная полоса-тень под выступом и у земли (ambient occlusion). */
export function aoStrip(
  ctx: Ctx,
  face: 'left' | 'right',
  x: number,
  y: number,
  z: number,
  w: number,
  d: number,
  h: number,
): void {
  const pts = facePoly(V, face, x, y, z, w, d, h);
  ctx.save();
  clipPoly(ctx, pts);
  const [a, , , c] = pts;
  ctx.fillStyle = linear(ctx, 0, a![1], 0, c![1] + 1, [
    [0, 'rgba(30,18,8,0)'],
    [1, 'rgba(30,18,8,0.32)'],
  ]);
  ctx.fillRect(0, 0, 480, 480);
  ctx.restore();
}

// ── Кровли ──────────────────────────────────────────────────────────────────

export interface Gable {
  x0: number;
  x1: number;
  y0: number;
  y1: number;
  z: number;
  rise: number;
  axis: 'x' | 'y';
  over: number;
}

/** Двускатная соломенная крыша: видимый скат, торцевой фронтон и коньковая балка. */
export function gable(ctx: Ctx, g: Gable, seed: number): void {
  const { x0, x1, y0, y1, z, rise, axis, over } = g;
  if (axis === 'x') {
    const ym = (y0 + y1) / 2;
    const ex0 = x0 - over;
    const ex1 = x1 + over;
    // фронтон на торце +x
    const gp: Pt[] = [P(x1, y1, z), P(x1, y0, z), P(x1, ym, z + rise)];
    ctx.save();
    poly(ctx, gp, duo(ctx, gp[0]![0], gp[0]![1], gp[1]![0], gp[1]![1], '#c9a670', '#8f7048'));
    ctx.restore();
    // скат +y (передний левый)
    thatchQuad(
      ctx,
      P(ex0, y1 + over, z - 4),
      P(ex1, y1 + over, z - 4),
      P(ex1, ym, z + rise),
      P(ex0, ym, z + rise),
      6,
      9,
      seed,
      0.04,
    );
    // скат +x торец (козырёк)
    beam3d(ctx, P(ex0, ym, z + rise), P(ex1 + 0.1, ym, z + rise), 7);
  } else {
    const xm = (x0 + x1) / 2;
    const ey0 = y0 - over;
    const ey1 = y1 + over;
    // фронтон на торце +y
    const gp: Pt[] = [P(x0, y1, z), P(x1, y1, z), P(xm, y1, z + rise)];
    poly(ctx, gp, duo(ctx, gp[0]![0], gp[0]![1], gp[1]![0], gp[1]![1], '#d8bb86', '#a88a5a'));
    // скат +x
    thatchQuad(
      ctx,
      P(x1 + over, ey1, z - 4),
      P(x1 + over, ey0, z - 4),
      P(xm, ey0, z + rise),
      P(xm, ey1, z + rise),
      6,
      7,
      seed,
      -0.1,
    );
    beam3d(ctx, P(xm, ey0, z + rise), P(xm, ey1 + 0.1, z + rise), 7);
  }
}

// ── Частокол ────────────────────────────────────────────────────────────────

export function post(ctx: Ctx, x: number, y: number, hgt: number, seed: number): void {
  const [px, py] = P(x, y, 0);
  const w = 7.4;
  const tip = 9;
  const top = py - hgt;
  const pts: Pt[] = [
    [px - w, py + 1],
    [px - w, top + tip],
    [px - w * 0.35, top + 1.5],
    [px, top - 2],
    [px + w * 0.35, top + 1.5],
    [px + w, top + tip],
    [px + w, py + 1],
  ];
  poly(ctx, pts, duo(ctx, px - w, 0, px + w, 0, '#c58a4c', '#6d431b'), 2.2);
  ctx.save();
  clipPoly(ctx, pts);
  const r = rng(seed);
  ctx.strokeStyle = 'rgba(58,32,12,0.35)';
  ctx.lineWidth = 1;
  for (let i = 0; i < 3; i++) {
    const gx = px - w + 3 + r() * (2 * w - 6);
    line(ctx, [gx, top + 6], [gx + r() * 2 - 1, py - 2], 'rgba(58,32,12,0.35)', 1);
  }
  ctx.fillStyle = 'rgba(255,230,170,0.35)';
  ctx.fillRect(px - w + 1.5, top + tip, 2, hgt - tip - 4);
  ctx.fillStyle = linear(ctx, 0, top, 0, py, [
    [0, 'rgba(0,0,0,0)'],
    [1, 'rgba(30,18,8,0.28)'],
  ]);
  ctx.fillRect(px - w, top, 2 * w, hgt + 2);
  ctx.restore();
}

export function palisade(ctx: Ctx, which: 'back' | 'front', seed: number): void {
  const r = rng(seed);
  const step = 0.4;
  const inset = 0.28;
  const items: Array<{ x: number; y: number; h: number }> = [];
  const base = which === 'back' ? 50 : 30;
  const add = (x: number, y: number): void => {
    items.push({ x, y, h: base + r() * 8 });
  };
  if (which === 'back') {
    for (let t = inset; t <= N - inset + 0.001; t += step) add(t, inset); // задняя правая (y = const)
    for (let t = inset + step; t <= N - inset + 0.001; t += step) add(inset, t); // задняя левая (x = const)
  } else {
    for (let t = inset + step; t <= N - inset + 0.001; t += step) {
      if (!(t > 3.5 && t < 5.3)) add(t, N - inset); // передняя левая с проходом
    }
    for (let t = inset + step; t <= N - inset + 0.001; t += step) add(N - inset, t); // передняя правая
  }
  items.sort((a, b) => a.x + a.y - (b.x + b.y));
  items.forEach((it, i) => post(ctx, it.x, it.y, it.h, seed + i));
}

// ── Башня, знамёна ─────────────────────────────────────────────────────────

export function banner(ctx: Ctx, x: number, y: number, w: number, h: number): void {
  ctx.save();
  ctx.translate(x, y);
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.quadraticCurveTo(w * 0.5, -3, w, 0);
  ctx.lineTo(w, h);
  ctx.lineTo(w / 2, h - h * 0.16);
  ctx.lineTo(0, h);
  ctx.closePath();
  ctx.fillStyle = duo(ctx, 0, 0, w, h, shade(PALETTE.royal, 0.15), shade(PALETTE.royal, -0.25));
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.strokeStyle = INK;
  ctx.stroke();
  ctx.strokeStyle = PALETTE.gold;
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.moveTo(2, 4);
  ctx.lineTo(w - 2, 4);
  ctx.stroke();
  // золотая корона
  const cx = w / 2;
  const cy = h * 0.42;
  ctx.fillStyle = PALETTE.gold;
  ctx.beginPath();
  ctx.moveTo(cx - 6, cy + 5);
  ctx.lineTo(cx - 7, cy - 3);
  ctx.lineTo(cx - 3, cy + 0.5);
  ctx.lineTo(cx, cy - 5);
  ctx.lineTo(cx + 3, cy + 0.5);
  ctx.lineTo(cx + 7, cy - 3);
  ctx.lineTo(cx + 6, cy + 5);
  ctx.closePath();
  ctx.fill();
  ctx.lineWidth = 1;
  ctx.strokeStyle = '#8a6a1a';
  ctx.stroke();
  ctx.restore();
}

export function penant(ctx: Ctx, x: number, y: number): void {
  ctx.save();
  ctx.translate(x, y);
  ctx.strokeStyle = INK;
  ctx.lineWidth = 3.4;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(0, -22);
  ctx.stroke();
  ctx.strokeStyle = '#6b421a';
  ctx.lineWidth = 1.8;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(0, -22);
  ctx.stroke();
  // флаг с волной
  ctx.beginPath();
  ctx.moveTo(0, -22);
  ctx.bezierCurveTo(10, -26, 18, -18, 30, -21);
  ctx.lineTo(25, -14);
  ctx.lineTo(30, -7);
  ctx.bezierCurveTo(18, -10, 10, -2, 0, -6);
  ctx.closePath();
  ctx.fillStyle = duo(ctx, 0, -22, 30, -6, shade(PALETTE.royal, 0.2), shade(PALETTE.royal, -0.2));
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.strokeStyle = INK;
  ctx.stroke();
  ctx.fillStyle = PALETTE.gold;
  ctx.beginPath();
  ctx.moveTo(6, -10);
  ctx.lineTo(6, -16);
  ctx.lineTo(10, -13);
  ctx.lineTo(13, -18);
  ctx.lineTo(16, -13);
  ctx.lineTo(20, -16);
  ctx.lineTo(20, -10);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

/** Коническая соломенная крыша башни. */
export function cone(
  ctx: Ctx,
  cx: number,
  cy: number,
  rx: number,
  height: number,
  seed: number,
): void {
  const r = rng(seed);
  const apex: Pt = [cx, cy - height];
  const ry = rx * 0.5;
  const silhouette = (t: number): void => {
    const er = rx * t;
    const ey = cy - height + height * t;
    ctx.beginPath();
    ctx.moveTo(apex[0], apex[1]);
    ctx.lineTo(cx - er, ey);
    ctx.ellipse(cx, ey, er, ry * t, 0, Math.PI, 0, true);
    ctx.closePath();
  };
  // контур-подложка
  silhouette(1);
  ctx.fillStyle = PALETTE.thatch[1];
  ctx.fill();
  ctx.save();
  silhouette(1);
  ctx.clip();
  const rows = 9;
  for (let k = rows; k >= 1; k--) {
    const t = k / rows;
    silhouette(t);
    const tone = mix(
      PALETTE.thatch[0],
      PALETTE.thatch[1],
      Math.min(1, (1 - t) * 0.2 + t * 0.55 + r() * 0.15),
    );
    ctx.fillStyle = tone;
    ctx.fill();
    ctx.lineWidth = 1.2;
    ctx.strokeStyle = 'rgba(120,80,20,0.6)';
    ctx.stroke();
  }
  // левый блик и правая тень
  ctx.fillStyle = linear(ctx, cx - rx, 0, cx + rx, 0, [
    [0, 'rgba(255,245,190,0.4)'],
    [0.45, 'rgba(255,255,255,0)'],
    [1, 'rgba(60,35,10,0.4)'],
  ]);
  ctx.fillRect(cx - rx - 2, apex[1] - 2, 2 * rx + 4, height + ry + 6);
  ctx.restore();
  silhouette(1);
  ctx.lineWidth = 2.6;
  ctx.strokeStyle = INK;
  ctx.stroke();
}

// ── Сборка ─────────────────────────────────────────────────────────────────

export interface FortOptions {
  seed?: number;
  /** 1…3: больше бочек, фонарей и знамён. */
  level?: number;
  /** Без вымпела на башне: его рисует анимационный слой. */
  dynamic?: boolean;
  /** Без земляной плиты и частокола (городская сцена). */
  flat?: boolean;
}

export function renderFort(opts: FortOptions = {}): HTMLCanvasElement {
  const seed = opts.seed ?? 7;
  const level = opts.level ?? 1;
  const { canvas, ctx } = makeCanvas(FORT_SIZE.w, FORT_SIZE.h, 2);
  if (!opts.flat) drawBase(ctx, seed);
  // тени построек
  softShadow(
    ctx,
    [P(1.3, 1.6), P(7.0, 1.6), P(7.2, 6.8), P(1.3, 6.4)].map(([x, y]) => [x + 10, y + 6] as Pt),
    9,
  );
  if (!opts.flat) palisade(ctx, 'back', seed + 10);

  // башня (позади дома)
  const tx = 6.05;
  const ty = 1.05;
  const tw = 1.25;
  wallBox(ctx, tx - 0.1, ty - 0.1, 0, tw + 0.2, tw + 0.2, 24, 'stone', seed + 20);
  aoStrip(ctx, 'left', tx - 0.1, ty - 0.1, 0, tw + 0.2, tw + 0.2, 24);
  wallBox(ctx, tx, ty, 24, tw, tw, 104, 'plank', seed + 30, {
    left: (len, hh) => {
      ctx.strokeStyle = 'rgba(42,26,14,0.7)';
      ctx.lineWidth = 4;
      ctx.lineCap = 'butt';
      ctx.beginPath();
      ctx.moveTo(4, hh - 4);
      ctx.lineTo(len - 4, 28);
      ctx.moveTo(4, 28);
      ctx.lineTo(len - 4, hh - 4);
      ctx.stroke();
      ctx.lineCap = 'round';
      windowGlow(ctx, len / 2 - 9, 10, 18, 24);
    },
    right: () => undefined,
  });
  // балкон
  wallBox(ctx, tx - 0.25, ty - 0.25, 128, tw + 0.5, tw + 0.5, 7, 'plank', seed + 40);
  for (let i = 0; i <= 4; i++) {
    const t = -0.25 + (i / 4) * (tw + 0.5);
    for (const [px, py] of [[tx + t, ty + tw + 0.25] as const, [tx + tw + 0.25, ty + t] as const]) {
      const [sx, sy] = P(px, py, 135);
      line(ctx, [sx, sy], [sx, sy - 13], INK, 5);
      line(ctx, [sx, sy], [sx, sy - 13], '#a9743f', 2.6);
    }
  }
  beam3d(ctx, P(tx - 0.25, ty + tw + 0.25, 148), P(tx + tw + 0.25, ty + tw + 0.25, 148), 4);
  beam3d(ctx, P(tx + tw + 0.25, ty + tw + 0.25, 148), P(tx + tw + 0.25, ty - 0.25, 148), 4);
  // кабина
  wallBox(ctx, tx + 0.05, ty + 0.05, 135, tw - 0.1, tw - 0.1, 30, 'plank', seed + 50, {
    left: (len, hh) => windowGlow(ctx, len / 2 - 8, hh / 2 - 10, 16, 20),
    right: (len, hh) => windowGlow(ctx, len / 2 - 8, hh / 2 - 10, 16, 20),
  });
  const [ccx, ccy] = P(tx + tw / 2, ty + tw / 2, 165);
  cone(ctx, ccx, ccy, 40, 58, seed + 60);
  // золотой шар и вымпел
  ctx.fillStyle = PALETTE.gold;
  ctx.beginPath();
  ctx.arc(ccx, ccy - 58, 4, 0, Math.PI * 2);
  ctx.fill();
  ctx.lineWidth = 1.6;
  ctx.strokeStyle = INK;
  ctx.stroke();
  if (!opts.dynamic) penant(ctx, ccx, ccy - 62);

  // дом: каменное основание
  const hx = 1.3;
  const hy = 1.6;
  const hw = 4.0;
  const hd = 3.7;
  wallBox(ctx, hx, hy, 0, hw, hd, 42, 'stone', seed + 70, {
    left: (len, hh) => {
      stoneArch(ctx, 30, hh, 36, 34, seed + 71);
      stoneArch(ctx, 96, hh, 36, 34, seed + 72);
      windowGlow(ctx, len - 54, 10, 14, 16, true);
    },
    right: (len) => windowGlow(ctx, len / 2 - 7, 8, 14, 16, true),
  });
  aoStrip(ctx, 'left', hx, hy, 0, hw, hd, 42);
  aoStrip(ctx, 'right', hx, hy, 0, hw, hd, 42);
  // второй этаж (фахверк), выступает над основанием
  const ux = hx - 0.15;
  const uy = hy - 0.15;
  wallBox(ctx, ux, uy, 42, hw + 0.3, hd + 0.3, 40, 'timber', seed + 80, {
    left: (len) => {
      windowGlow(ctx, len * 0.22, 9, 16, 22);
      windowGlow(ctx, len * 0.62, 9, 16, 22);
    },
    right: (len) => windowGlow(ctx, len / 2 - 8, 9, 16, 22),
  });
  // опорные балки-консоли
  for (let i = 0; i < 4; i++) {
    const xx = hx + 0.25 + i * ((hw - 0.5) / 3);
    beam3d(ctx, P(xx, hy + hd + 0.12, 42), P(xx, hy + hd - 0.02, 34), 5);
  }
  // крыши
  const roof: Gable = {
    x0: ux,
    x1: ux + hw + 0.3,
    y0: uy,
    y1: uy + hd + 0.3,
    z: 82,
    rise: 50,
    axis: 'x',
    over: 0.45,
  };
  gable(ctx, roof, seed + 90);
  // скрещённая кровля (передний фронтон)
  const xm = (roof.x0 + roof.x1) / 2 + 0.3;
  gable(
    ctx,
    {
      x0: xm - 1.05,
      x1: xm + 1.05,
      y0: roof.y0 + 1.6,
      y1: roof.y1 + 0.55,
      z: 82,
      rise: 40,
      axis: 'y',
      over: 0.3,
    },
    seed + 100,
  );
  // знамя у двери и свет у входа
  onFace(ctx, V, 'left', hx, hy, 0, hw, hd, 42, (len) => banner(ctx, len - 26, 4, 22, 30));

  // бочки, ящики (детали)
  props(ctx, seed, level);
  if (!opts.flat) palisade(ctx, 'front', seed + 200);
  return canvas;
}

export function barrel(ctx: Ctx, x: number, y: number): void {
  const [px, py] = P(x, y, 0);
  ctx.beginPath();
  ctx.ellipse(px, py + 1, 10, 4, 0, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(42,26,14,0.3)';
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(px - 8, py - 14);
  ctx.quadraticCurveTo(px - 11, py - 7, px - 8, py);
  ctx.lineTo(px + 8, py);
  ctx.quadraticCurveTo(px + 11, py - 7, px + 8, py - 14);
  ctx.closePath();
  ctx.fillStyle = duo(ctx, px - 10, 0, px + 10, 0, '#c38a4a', '#6d431b');
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.strokeStyle = INK;
  ctx.stroke();
  ctx.beginPath();
  ctx.ellipse(px, py - 14, 8, 3.2, 0, 0, Math.PI * 2);
  ctx.fillStyle = '#d9a566';
  ctx.fill();
  ctx.stroke();
  ctx.strokeStyle = '#4a4a52';
  ctx.lineWidth = 2;
  for (const dy of [-10, -4]) {
    ctx.beginPath();
    ctx.moveTo(px - 9, py + dy);
    ctx.quadraticCurveTo(px, py + dy + 3, px + 9, py + dy);
    ctx.stroke();
  }
}

function props(ctx: Ctx, seed: number, level: number): void {
  barrel(ctx, 6.4, 5.6);
  barrel(ctx, 6.95, 5.9);
  if (level >= 2) barrel(ctx, 6.7, 5.1);
  // колодец-бадья и факел у тропы
  const [fx, fy] = P(5.6, 8.0, 0);
  line(ctx, [fx, fy], [fx, fy - 26], INK, 5);
  line(ctx, [fx, fy], [fx, fy - 26], '#8a5a2c', 2.6);
  ctx.beginPath();
  ctx.moveTo(fx, fy - 40);
  ctx.quadraticCurveTo(fx + 7, fy - 32, fx, fy - 25);
  ctx.quadraticCurveTo(fx - 7, fy - 32, fx, fy - 40);
  ctx.fillStyle = '#ff9a2a';
  ctx.fill();
  ctx.fillStyle = '#ffe680';
  ctx.beginPath();
  ctx.arc(fx, fy - 30, 3, 0, Math.PI * 2);
  ctx.fill();
  void seed;
}

/** Точка вымпела форта в логических координатах 480×480 (для анимационного слоя). */
export const FORT_PENNANT: Pt = (() => {
  const [x, y] = P(6.675, 1.675, 165);
  return [x, y - 62];
})();
