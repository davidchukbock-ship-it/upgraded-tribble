import { describe, expect, it } from 'vitest';
import { spriteScale } from './SceneBuilding';
import { useGfx } from '../store/gfx';

describe('spriteScale', () => {
  it('больший участок — крупнее спрайт, квадрат и прямоугольник с тем же средним равны', () => {
    expect(spriteScale(4, 4)).toBeGreaterThan(spriteScale(2, 2));
    expect(spriteScale(5, 3)).toBeCloseTo(spriteScale(4, 4));
  });
});

describe('useGfx', () => {
  it('по умолчанию «богатая» графика, выбор запоминается', () => {
    expect(useGfx.getState().mode).toBe('rich');
    useGfx.getState().set('classic');
    expect(localStorage.getItem('tc.gfx')).toBe('classic');
    useGfx.getState().set('rich');
  });
});
