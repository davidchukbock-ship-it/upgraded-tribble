import { useEffect, useRef } from 'react';

/** Монтирует готовый холст процедурной графики (art2) в DOM; перерисовка при смене `make`. */
export function Art2Canvas({
  make,
  label,
  size,
}: {
  make: () => HTMLCanvasElement;
  label: string;
  size: number;
}) {
  const host = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = host.current;
    if (!el) return;
    const c = make();
    c.style.width = `${size}px`;
    c.style.height = `${(size * c.height) / c.width}px`;
    c.setAttribute('role', 'img');
    c.setAttribute('aria-label', label);
    el.replaceChildren(c);
    return () => el.replaceChildren();
  }, [make, label, size]);
  return <div ref={host} />;
}
