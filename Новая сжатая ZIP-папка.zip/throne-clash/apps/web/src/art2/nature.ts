/**
 * Природа и тайлы: деревья, кусты, камни и изометрические плитки земли. Всё рисуется кодом
 * (Canvas 2D) и детерминированно зависит от seed.
 */
import {
  INK,
  PALETTE,
  ellipseShadow,
  linear,
  makeCanvas,
  mix,
  radial,
  rng,
  shade,
  type Ctx,
} from './kit';

export type TreeKind = 'oak' | 'pine' | 'birch' | 'autumn';
export type TileKind = 'grass' | 'road' | 'water' | 'sand' | 'snow';

interface Blob {
  x: number;
  y: number;
  r: number;
}

/** Обводка «одним силуэтом»: сначала толстый контур всех кругов, потом заливка поверх. */
function blobs(ctx: Ctx, list: ReadonlyArray<Blob>, top: string, bottom: string): void {
  ctx.fillStyle = INK;
  ctx.strokeStyle = INK;
  ctx.lineWidth = 4;
  for (const b of list) {
    ctx.beginPath();
    ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
    ctx.stroke();
  }
  for (const b of list) {
    ctx.beginPath();
    ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
    ctx.fillStyle = radial(ctx, b.x - b.r * 0.35, b.y - b.r * 0.4, 0, b.r * 1.3, [
      [0, top],
      [1, bottom],
    ]);
    ctx.fill();
  }
}

function trunk(ctx: Ctx, x: number, y: number, w: number, h: number): void {
  ctx.beginPath();
  ctx.moveTo(x - w / 2, y);
  ctx.quadraticCurveTo(x - w * 0.35, y - h * 0.5, x - w * 0.22, y - h);
  ctx.lineTo(x + w * 0.22, y - h);
  ctx.quadraticCurveTo(x + w * 0.35, y - h * 0.5, x + w / 2, y);
  ctx.closePath();
  ctx.fillStyle = linear(ctx, x - w / 2, 0, x + w / 2, 0, [
    [0, PALETTE.wood[0]],
    [1, PALETTE.woodDark[1]],
  ]);
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.strokeStyle = INK;
  ctx.stroke();
}

/** Дерево 120×140 (логические пиксели); якорь — середина низа. */
export function renderTree(kind: TreeKind, seed = 1): HTMLCanvasElement {
  const W = 120;
  const H = 140;
  const { canvas, ctx } = makeCanvas(W, H);
  const r = rng(seed * 97 + kind.length);
  ellipseShadow(ctx, 60, 128, 30, 9);
  if (kind === 'pine') {
    trunk(ctx, 60, 128, 11, 26);
    const tiers = 4;
    for (let i = 0; i < tiers; i++) {
      const y = 108 - i * 22;
      const w = 40 - i * 7 + r() * 3;
      ctx.beginPath();
      ctx.moveTo(60, y - 36);
      ctx.quadraticCurveTo(60 + w * 0.55, y - 12, 60 + w, y);
      ctx.quadraticCurveTo(60, y + 8, 60 - w, y);
      ctx.quadraticCurveTo(60 - w * 0.55, y - 12, 60, y - 36);
      ctx.closePath();
      ctx.fillStyle = linear(ctx, 60 - w, 0, 60 + w, 0, [
        [0, '#5fae5a'],
        [0.55, '#2f7a3d'],
        [1, '#1d5230'],
      ]);
      ctx.fill();
      ctx.lineWidth = 2.2;
      ctx.strokeStyle = INK;
      ctx.stroke();
    }
    return canvas;
  }
  const palette: Record<Exclude<TreeKind, 'pine'>, [string, string]> = {
    oak: ['#8fdc5e', '#2f7a2a'],
    birch: ['#b9e77a', '#4f9b3a'],
    autumn: ['#ffb347', '#b8431a'],
  };
  const [top, bottom] = palette[kind];
  if (kind === 'birch') {
    trunk(ctx, 60, 128, 9, 58);
    ctx.fillStyle = '#f4f0e6';
    ctx.fillRect(56, 76, 8, 52);
    ctx.fillStyle = '#3a2a1e';
    for (let i = 0; i < 6; i++) ctx.fillRect(56 + r() * 4, 80 + i * 8, 3 + r() * 3, 2);
  } else {
    trunk(ctx, 60, 128, 16, 40);
  }
  const list: Blob[] = [
    { x: 60, y: 54, r: 30 },
    { x: 36, y: 66, r: 22 },
    { x: 84, y: 66, r: 22 },
    { x: 48, y: 40, r: 20 },
    { x: 74, y: 40, r: 20 },
    { x: 60, y: 76, r: 20 },
  ].map((b) => ({ x: b.x + (r() - 0.5) * 4, y: b.y + (r() - 0.5) * 4, r: b.r }));
  blobs(ctx, list, top, bottom);
  // листья-блики и тёмные кластеры
  for (let i = 0; i < 18; i++) {
    const b = list[Math.floor(r() * list.length)]!;
    const a = r() * Math.PI * 2;
    const d = r() * b.r * 0.7;
    const x = b.x + Math.cos(a) * d;
    const y = b.y + Math.sin(a) * d;
    const light = y < b.y;
    ctx.beginPath();
    ctx.ellipse(x, y, 4.5, 3, a, 0, Math.PI * 2);
    ctx.fillStyle = light ? mix(top, '#ffffff', 0.35) : shade(bottom, -0.1);
    ctx.globalAlpha = 0.6;
    ctx.fill();
    ctx.globalAlpha = 1;
  }
  return canvas;
}

/** Куст 64×48. */
export function renderBush(seed = 1, berries = false): HTMLCanvasElement {
  const { canvas, ctx } = makeCanvas(64, 48);
  const r = rng(seed * 31);
  ellipseShadow(ctx, 32, 42, 24, 6);
  blobs(
    ctx,
    [
      { x: 22, y: 28, r: 14 },
      { x: 42, y: 28, r: 14 },
      { x: 32, y: 20, r: 15 },
    ],
    '#94dc62',
    '#3b8a2c',
  );
  if (berries)
    for (let i = 0; i < 6; i++) {
      ctx.beginPath();
      ctx.arc(18 + r() * 28, 18 + r() * 18, 2.2, 0, Math.PI * 2);
      ctx.fillStyle = '#d83a3a';
      ctx.fill();
      ctx.lineWidth = 1;
      ctx.strokeStyle = INK;
      ctx.stroke();
    }
  return canvas;
}

/** Валун 64×48. */
export function renderRock(seed = 1): HTMLCanvasElement {
  const { canvas, ctx } = makeCanvas(64, 48);
  const r = rng(seed * 13);
  ellipseShadow(ctx, 32, 42, 24, 6);
  ctx.beginPath();
  ctx.moveTo(8, 38);
  ctx.lineTo(12 + r() * 4, 20);
  ctx.lineTo(26, 8 + r() * 3);
  ctx.lineTo(44, 10);
  ctx.lineTo(56, 26 + r() * 4);
  ctx.lineTo(54, 38);
  ctx.closePath();
  ctx.fillStyle = linear(ctx, 10, 8, 54, 40, [
    [0, PALETTE.stone[0]],
    [1, PALETTE.stone[1]],
  ]);
  ctx.fill();
  ctx.lineWidth = 2.2;
  ctx.strokeStyle = INK;
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(26, 8);
  ctx.lineTo(30, 24);
  ctx.lineTo(54, 38);
  ctx.moveTo(30, 24);
  ctx.lineTo(10, 34);
  ctx.strokeStyle = 'rgba(42,26,14,0.35)';
  ctx.lineWidth = 1.4;
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(14, 26);
  ctx.lineTo(26, 12);
  ctx.lineTo(36, 12);
  ctx.strokeStyle = 'rgba(255,255,255,0.45)';
  ctx.lineWidth = 2;
  ctx.stroke();
  return canvas;
}

const TILE = { w: 96, h: 72, top: 48 } as const;

/** Изометрическая плитка 96×72 (ромб 2:1 + боковая толщина). */
export function renderTile(kind: TileKind, seed = 1): HTMLCanvasElement {
  const { canvas, ctx } = makeCanvas(TILE.w, TILE.h);
  const r = rng(seed * 101 + kind.charCodeAt(0));
  const cx = TILE.w / 2;
  const t = 12;
  const top = 6;
  const diamond: Array<[number, number]> = [
    [cx, top],
    [TILE.w - 2, top + TILE.top / 2],
    [cx, top + TILE.top],
    [2, top + TILE.top / 2],
  ];
  const cols: Record<TileKind, [string, string, string]> = {
    grass: [PALETTE.grass[0], PALETTE.grass[1], PALETTE.soil[0]],
    road: [PALETTE.road[0], PALETTE.road[1], PALETTE.soil[1]],
    water: [PALETTE.water[0], PALETTE.water[1], '#1f5fa0'],
    sand: ['#f0dba0', '#d2b56d', '#a98243'],
    snow: ['#ffffff', '#cfe0f0', '#8aa0b8'],
  };
  const [a, b, side] = cols[kind];
  // боковины
  ctx.beginPath();
  ctx.moveTo(2, top + TILE.top / 2);
  ctx.lineTo(cx, top + TILE.top);
  ctx.lineTo(cx, top + TILE.top + t);
  ctx.lineTo(2, top + TILE.top / 2 + t);
  ctx.closePath();
  ctx.fillStyle = side;
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(TILE.w - 2, top + TILE.top / 2);
  ctx.lineTo(cx, top + TILE.top);
  ctx.lineTo(cx, top + TILE.top + t);
  ctx.lineTo(TILE.w - 2, top + TILE.top / 2 + t);
  ctx.closePath();
  ctx.fillStyle = shade(side, -0.22);
  ctx.fill();
  // верх
  ctx.beginPath();
  diamond.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
  ctx.closePath();
  ctx.fillStyle = linear(ctx, cx, top, cx, top + TILE.top, [
    [0, a],
    [1, b],
  ]);
  ctx.fill();
  ctx.save();
  ctx.clip();
  const inside = (): [number, number] => {
    for (;;) {
      const x = 6 + r() * (TILE.w - 12);
      const y = top + 4 + r() * (TILE.top - 8);
      if (
        Math.abs(x - cx) / (TILE.w / 2) + Math.abs(y - (top + TILE.top / 2)) / (TILE.top / 2) <
        0.85
      )
        return [x, y];
    }
  };
  if (kind === 'grass' || kind === 'snow') {
    for (let i = 0; i < 26; i++) {
      const [x, y] = inside();
      ctx.strokeStyle = kind === 'grass' ? shade(PALETTE.grassDeep, r() * 0.2) : '#b7cde2';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x - 1.5, y - 4);
      ctx.moveTo(x, y);
      ctx.lineTo(x + 1.5, y - 4.5);
      ctx.stroke();
    }
    if (kind === 'grass')
      for (let i = 0; i < 3; i++) {
        const [x, y] = inside();
        ctx.beginPath();
        ctx.arc(x, y, 1.6, 0, Math.PI * 2);
        ctx.fillStyle = ['#fff3a0', '#ffffff', '#ff9bb0'][i % 3]!;
        ctx.fill();
      }
  } else if (kind === 'road' || kind === 'sand') {
    for (let i = 0; i < 34; i++) {
      const [x, y] = inside();
      ctx.beginPath();
      ctx.ellipse(x, y, 2 + r() * 2.2, 1.1 + r(), 0, 0, Math.PI * 2);
      ctx.fillStyle = r() > 0.5 ? shade(b, -0.12) : shade(a, 0.12);
      ctx.fill();
    }
  } else {
    for (let i = 0; i < 7; i++) {
      const [x, y] = inside();
      ctx.beginPath();
      ctx.ellipse(x, y, 7 + r() * 5, 1.6, 0, Math.PI, Math.PI * 2);
      ctx.strokeStyle = 'rgba(255,255,255,0.55)';
      ctx.lineWidth = 1.4;
      ctx.stroke();
    }
  }
  ctx.restore();
  ctx.beginPath();
  diamond.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
  ctx.closePath();
  ctx.lineWidth = 2;
  ctx.strokeStyle = INK;
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(2, top + TILE.top / 2 + t);
  ctx.lineTo(cx, top + TILE.top + t);
  ctx.lineTo(TILE.w - 2, top + TILE.top / 2 + t);
  ctx.stroke();
  return canvas;
}
