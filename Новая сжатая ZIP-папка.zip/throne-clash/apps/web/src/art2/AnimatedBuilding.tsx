import { useEffect, useRef } from 'react';
import { BUILDING_SIZE, getBuilding, type BuildingKind } from './buildings';

/**
 * Анимированная постройка: статичный слой + движущийся оверлей.
 * Кадры рисуются только пока компонент виден и вкладка активна; при prefers-reduced-motion — один кадр.
 */
export function AnimatedBuilding({
  kind,
  seed = 7,
  size = 360,
  fps = 30,
}: {
  kind: BuildingKind;
  seed?: number;
  size?: number;
  fps?: number;
}) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const b = getBuilding(kind, seed);
    const ctx = cv.getContext('2d');
    if (!b || !ctx) return;
    const { w, h } = BUILDING_SIZE;
    const k = cv.width / w;
    const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    let raf = 0;
    let visible = true;
    let last = 0;
    const t0 = performance.now();
    const draw = (now: number): void => {
      ctx.setTransform(k, 0, 0, k, 0, 0);
      ctx.clearRect(0, 0, w, h);
      ctx.drawImage(b.base, 0, 0, w, h);
      ctx.lineJoin = 'round';
      ctx.lineCap = 'round';
      b.overlay(ctx, reduce ? 0.5 : Math.max(0, now - t0) / 1000);
    };
    const loop = (now: number): void => {
      raf = requestAnimationFrame(loop);
      if (!visible || document.hidden || now - last < 1000 / fps) return;
      last = now;
      draw(now);
    };
    draw(t0);
    if (!reduce) raf = requestAnimationFrame(loop);
    const io =
      typeof IntersectionObserver === 'function'
        ? new IntersectionObserver((e) => (visible = e[0]?.isIntersecting ?? true))
        : null;
    io?.observe(cv);
    return () => {
      cancelAnimationFrame(raf);
      io?.disconnect();
    };
  }, [kind, seed, fps]);
  return (
    <canvas
      ref={ref}
      role="img"
      aria-label={kind}
      width={size * 2}
      height={size * 2}
      style={{ width: size, height: size }}
    />
  );
}
