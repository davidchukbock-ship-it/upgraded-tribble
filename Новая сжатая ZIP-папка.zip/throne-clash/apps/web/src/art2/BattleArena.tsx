import { useEffect, useMemo, useRef } from 'react';
import { BATTLE_SIZE, drawBattle, planBattle, type BattleSetup } from './battle';

/** Анимированный бой на холсте: кадры рисуются только пока компонент виден; при reduced-motion — один кадр. */
export function BattleArena({
  setup,
  width = 640,
  fps = 30,
  label,
  at,
}: {
  setup: BattleSetup;
  width?: number;
  fps?: number;
  label: string;
  /** Зафиксировать кадр на моменте t (секунды): для снимков и тестов. */
  at?: number;
}) {
  const ref = useRef<HTMLCanvasElement>(null);
  const plan = useMemo(() => planBattle(setup), [setup]);
  useEffect(() => {
    const cv = ref.current;
    const ctx = cv?.getContext('2d');
    if (!cv || !ctx) return;
    const k = cv.width / BATTLE_SIZE.w;
    const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    let raf = 0;
    let visible = true;
    let last = 0;
    const t0 = performance.now();
    const draw = (now: number): void => {
      ctx.setTransform(k, 0, 0, k, 0, 0);
      ctx.lineJoin = 'round';
      ctx.lineCap = 'round';
      drawBattle(
        ctx,
        setup,
        plan,
        at ?? (reduce ? plan.endFightAt - 0.3 : Math.max(0, now - t0) / 1000),
      );
    };
    const loop = (now: number): void => {
      raf = requestAnimationFrame(loop);
      if (!visible || document.hidden || now - last < 1000 / fps) return;
      last = now;
      draw(now);
    };
    draw(t0);
    if (!reduce && at === undefined) raf = requestAnimationFrame(loop);
    const io =
      typeof IntersectionObserver === 'function'
        ? new IntersectionObserver((e) => (visible = e[0]?.isIntersecting ?? true))
        : null;
    io?.observe(cv);
    return () => {
      cancelAnimationFrame(raf);
      io?.disconnect();
    };
  }, [setup, plan, fps, at]);
  const h = Math.round((width * BATTLE_SIZE.h) / BATTLE_SIZE.w);
  return (
    <canvas
      ref={ref}
      role="img"
      aria-label={label}
      width={width * 2}
      height={h * 2}
      style={{ width, height: h, maxWidth: '100%' }}
    />
  );
}
