/**
 * Примитивы анимации (чистый Canvas 2D): дым, пламя, искры, флаги, блики. Все зависят только от времени `t`
 * (секунды) и seed — без накопления состояния, поэтому кадры можно рисовать в любом порядке и ставить на паузу.
 */
import { INK, rng, shade, type Ctx } from './kit';

/** Столб дыма из трубы: круглые клубы поднимаются, растут и тают. */
export function smoke(ctx: Ctx, x: number, y: number, t: number, seed = 1, puffs = 6): void {
  const r = rng(seed);
  for (let i = 0; i < puffs; i++) {
    const a = (t * 0.32 + i / puffs + r() * 0.05) % 1;
    const px = x + a * 16 + Math.sin(t * 1.3 + i * 2) * 3 * a;
    const py = y - a * 54;
    const rad = 3.5 + a * 9;
    ctx.beginPath();
    ctx.arc(px, py, rad, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(236,236,240,${(1 - a) * 0.62})`;
    ctx.fill();
    ctx.lineWidth = 1;
    ctx.strokeStyle = `rgba(120,120,135,${(1 - a) * 0.35})`;
    ctx.stroke();
  }
}

/** Живое пламя: два вложенных языка, дрожащих вразнобой. */
export function flame(ctx: Ctx, x: number, y: number, t: number, s = 1, seed = 0): void {
  const f = 1 + Math.sin(t * 11 + seed) * 0.1 + Math.sin(t * 17 + seed * 2) * 0.06;
  const lean = Math.sin(t * 7 + seed) * 2.2 * s;
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s * f);
  const tongue = (w: number, h: number, c0: string, c1: string): void => {
    ctx.beginPath();
    ctx.moveTo(-w, 0);
    ctx.bezierCurveTo(-w * 1.2, -h * 0.4, lean - w * 0.3, -h * 0.65, lean, -h);
    ctx.bezierCurveTo(lean + w * 0.3, -h * 0.65, w * 1.2, -h * 0.4, w, 0);
    ctx.closePath();
    const g = ctx.createLinearGradient(0, 0, 0, -h);
    g.addColorStop(0, c0);
    g.addColorStop(1, c1);
    ctx.fillStyle = g;
    ctx.fill();
  };
  tongue(7, 20, '#ff8a1f', '#ffd24a');
  tongue(3.6, 12, '#fff3a0', '#ffffff');
  ctx.restore();
  // тёплое свечение
  const g = ctx.createRadialGradient(x, y - 8 * s, 1, x, y - 8 * s, 26 * s);
  g.addColorStop(0, 'rgba(255,170,60,0.35)');
  g.addColorStop(1, 'rgba(255,170,60,0)');
  ctx.fillStyle = g;
  ctx.fillRect(x - 30 * s, y - 38 * s, 60 * s, 60 * s);
}

/** Искры из-под молота: короткие баллистические дуги, циклично. */
export function sparks(ctx: Ctx, x: number, y: number, t: number, seed = 1, n = 7): void {
  const r = rng(seed);
  for (let i = 0; i < n; i++) {
    const period = 0.9 + r() * 0.5;
    const a = ((t + r() * 3) % period) / period;
    const vx = (r() - 0.5) * 46;
    const vy = 26 + r() * 26;
    const px = x + vx * a;
    const py = y - vy * a + 52 * a * a;
    ctx.beginPath();
    ctx.arc(px, py, 1.6 * (1 - a) + 0.4, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(255,${(200 - a * 90) | 0},70,${1 - a})`;
    ctx.fill();
  }
}

/** Развевающийся флаг на древке в точке (x, y) — левый верхний угол полотна. */
export function flag(
  ctx: Ctx,
  x: number,
  y: number,
  t: number,
  w: number,
  h: number,
  color: string,
  emblem?: string,
): void {
  const seg = 8;
  const top: Array<[number, number]> = [];
  const bottom: Array<[number, number]> = [];
  for (let i = 0; i <= seg; i++) {
    const u = i / seg;
    const wave = Math.sin(t * 5 - u * 4.2) * 3.4 * u;
    top.push([x + u * w, y + wave]);
    bottom.push([x + u * w, y + h * (1 - u * 0.15) + wave]);
  }
  ctx.beginPath();
  top.forEach(([px, py], i) => (i ? ctx.lineTo(px, py) : ctx.moveTo(px, py)));
  for (let i = seg; i >= 0; i--) ctx.lineTo(bottom[i]![0], bottom[i]![1]);
  ctx.closePath();
  const g = ctx.createLinearGradient(x, y, x + w, y + h);
  g.addColorStop(0, shade(color, 0.22));
  g.addColorStop(1, shade(color, -0.25));
  ctx.fillStyle = g;
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.strokeStyle = INK;
  ctx.stroke();
  if (emblem) {
    const mid = top[(seg / 2) | 0]!;
    ctx.fillStyle = emblem;
    ctx.beginPath();
    ctx.arc(mid[0], mid[1] + h * 0.45, h * 0.18, 0, Math.PI * 2);
    ctx.fill();
  }
}

/** Мерцание света окна/факела: коэффициент яркости 0.75…1.0. */
export function flicker(t: number, seed = 0): number {
  return 0.88 + Math.sin(t * 9 + seed) * 0.06 + Math.sin(t * 23 + seed * 3) * 0.05;
}

/** Мягкое световое пятно (аддитивно). */
export function glow(
  ctx: Ctx,
  x: number,
  y: number,
  r: number,
  color: string,
  alpha: number,
): void {
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.globalAlpha = Math.max(0, Math.min(1, alpha));
  const g = ctx.createRadialGradient(x, y, 0, x, y, r);
  g.addColorStop(0, color);
  g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g;
  ctx.fillRect(x - r, y - r, r * 2, r * 2);
  ctx.restore();
}
