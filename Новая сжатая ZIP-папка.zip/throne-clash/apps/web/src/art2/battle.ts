/**
 * Анимированный бой двух отрядов. `planBattle` — чистый детерминированный сценарий (тестируется без Canvas):
 * кто, когда и по кому бьёт, когда падает. `drawBattle` рисует кадр сценария на момент t.
 */
import { drawChibi, type ChibiClass, type Pose, type Rarity } from './chibi';
import { INK, linear, radial, rng, type Ctx } from './kit';
import { treeSprite } from './sprites';

export interface Fighter {
  cls: ChibiClass;
  rarity?: Rarity;
  tier?: number;
  seed?: number;
}
export interface BattleSetup {
  left: readonly Fighter[];
  right: readonly Fighter[];
  winner: 'left' | 'right';
  seed?: number;
  /** Подпись победы (локализованная); по умолчанию не рисуется. */
  victoryText?: string;
}

export const BATTLE_SIZE = { w: 640, h: 320 } as const;
export const ATTACK_TIME = 0.8;
export const HIT_AT = 0.4; // доля ATTACK_TIME, когда удар достигает цели (выстрел/замах)
const HURT_TIME = 0.4;
const DIE_TIME = 0.9;
const FLIGHT = 0.35;
const ARRIVE = 1.6;

export interface UnitPlan {
  side: 'left' | 'right';
  index: number;
  fighter: Fighter;
  ranged: boolean;
  slot: { x: number; y: number };
  from: { x: number };
  arriveAt: number;
  diesAt: number | null;
  attacks: number[];
  hurts: number[];
}
export interface HitEvent {
  t: number;
  attacker: number; // индекс в plan.units
  target: number;
  dmg: number;
  ranged: boolean;
  kind: 'melee' | 'arrow' | 'magic';
}
export interface BattlePlan {
  units: UnitPlan[];
  hits: HitEvent[];
  endFightAt: number;
  duration: number;
}

const isRanged = (c: ChibiClass): boolean => c === 'archer' || c === 'mage';

function slotsFor(
  side: 'left' | 'right',
  list: readonly Fighter[],
): Array<{ x: number; y: number }> {
  // ближний бой впереди, дальний — за спиной; два ряда по глубине
  const order = list
    .map((f, i) => ({ i, r: isRanged(f.cls) ? 1 : 0 }))
    .sort((a, b) => a.r - b.r || a.i - b.i);
  const pos: Array<{ x: number; y: number }> = Array.from({ length: list.length }, () => ({
    x: 0,
    y: 0,
  }));
  order.forEach((o, k) => {
    const col = Math.floor(k / 2);
    const row = k % 2;
    const x = 262 - col * 58 - row * 16;
    pos[o.i] = { x: side === 'left' ? x : BATTLE_SIZE.w - x, y: 236 + row * 30 };
  });
  return pos;
}

/** Строит сценарий боя. Один и тот же setup всегда даёт один и тот же ход. */
export function planBattle(setup: BattleSetup): BattlePlan {
  const r = rng((setup.seed ?? 1) * 7919 + setup.left.length * 31 + setup.right.length);
  const units: UnitPlan[] = [];
  for (const side of ['left', 'right'] as const) {
    const list = side === 'left' ? setup.left : setup.right;
    const slots = slotsFor(side, list);
    list.forEach((fighter, index) => {
      units.push({
        side,
        index,
        fighter,
        ranged: isRanged(fighter.cls),
        slot: slots[index]!,
        from: { x: side === 'left' ? -70 - index * 18 : BATTLE_SIZE.w + 70 + index * 18 },
        arriveAt: ARRIVE + index * 0.08,
        diesAt: null,
        attacks: [],
        hurts: [],
      });
    });
  }
  const loser = setup.winner === 'left' ? 'right' : 'left';
  const losers = units.filter((u) => u.side === loser);
  losers.forEach((u, k) => {
    u.diesAt = 5.4 + k * 0.55 + r() * 0.25;
  });
  const lastDeath = Math.max(5.4, ...losers.map((u) => u.diesAt ?? 0));
  const hits: HitEvent[] = [];
  const alive = (u: UnitPlan, t: number): boolean => u.diesAt === null || t < u.diesAt;
  units.forEach((u, ui) => {
    const period = 1.25 + r() * 0.3;
    let start = ARRIVE + 0.3 + r() * 0.9;
    let n = 0;
    while (start < lastDeath + 0.2) {
      const hitT = start + ATTACK_TIME * HIT_AT + (u.ranged ? FLIGHT : 0);
      if (!alive(u, start)) break;
      const foes = units
        .map((v, vi) => ({ v, vi }))
        .filter(({ v }) => v.side !== u.side && alive(v, hitT) && hitT > v.arriveAt);
      if (foes.length > 0) {
        const pick = foes[(ui + n) % foes.length]!;
        u.attacks.push(start);
        const dmg = 8 + Math.floor(r() * 30) + (u.fighter.tier ?? 1) * 3;
        hits.push({
          t: hitT,
          attacker: ui,
          target: pick.vi,
          dmg,
          ranged: u.ranged,
          kind: !u.ranged ? 'melee' : u.fighter.cls === 'mage' ? 'magic' : 'arrow',
        });
        pick.v.hurts.push(hitT);
        n++;
      }
      start += period;
    }
  });
  hits.sort((a, b) => a.t - b.t);
  return { units, hits, endFightAt: lastDeath + DIE_TIME, duration: lastDeath + DIE_TIME + 2.4 };
}

interface Placed {
  x: number;
  y: number;
  pose: Pose;
  phase: number;
  visible: boolean;
}

/** Состояние бойца на момент t (чистая функция плана). */
export function unitAt(u: UnitPlan, plan: BattlePlan, t: number): Placed {
  const place = (pose: Pose, phase: number, x = u.slot.x): Placed => ({
    x,
    y: u.slot.y,
    pose,
    phase,
    visible: true,
  });
  if (u.diesAt !== null && t >= u.diesAt) {
    const k = (t - u.diesAt) / DIE_TIME;
    return { ...place('die', Math.min(1, k)), visible: k < 1 };
  }
  if (t < u.arriveAt) {
    const k = Math.max(0, t / u.arriveAt);
    return place('walk', t * 1.7, u.from.x + (u.slot.x - u.from.x) * k);
  }
  for (const h of u.hurts)
    if (t >= h && t < h + HURT_TIME) return place('hurt', (t - h) / HURT_TIME);
  for (const a of u.attacks)
    if (t >= a && t < a + ATTACK_TIME) return place('attack', (t - a) / ATTACK_TIME);
  if (t >= plan.endFightAt) return place('cheer', (t - plan.endFightAt) * 1.1);
  return place('idle', t * 0.7 + u.index * 0.17);
}

// ── Рисование ───────────────────────────────────────────────────────────────

function backdrop(ctx: Ctx, seed: number): void {
  const { w, h } = BATTLE_SIZE;
  ctx.fillStyle = linear(ctx, 0, 0, 0, 170, [
    [0, '#8fd2f5'],
    [1, '#d9f1ff'],
  ]);
  ctx.fillRect(0, 0, w, h);
  // дальние холмы
  ctx.fillStyle = '#9fd18a';
  ctx.beginPath();
  ctx.moveTo(0, 170);
  ctx.quadraticCurveTo(120, 120, 250, 160);
  ctx.quadraticCurveTo(400, 110, w, 165);
  ctx.lineTo(w, 190);
  ctx.lineTo(0, 190);
  ctx.fill();
  // земля
  ctx.fillStyle = linear(ctx, 0, 175, 0, h, [
    [0, '#7bc954'],
    [1, '#4f9b2c'],
  ]);
  ctx.fillRect(0, 175, w, h - 175);
  const r = rng(seed);
  ctx.strokeStyle = 'rgba(40,110,30,.55)';
  ctx.lineWidth = 1.4;
  for (let i = 0; i < 90; i++) {
    const x = r() * w;
    const y = 185 + r() * 130;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x - 1.5, y - 5);
    ctx.moveTo(x, y);
    ctx.lineTo(x + 1.5, y - 5.5);
    ctx.stroke();
  }
  // деревья по краям
  for (const [x, y, k] of [
    [40, 196, 0],
    [110, 186, 1],
    [560, 192, 2],
    [610, 184, 0],
    [330, 178, 1],
  ] as const) {
    const tr = treeSprite(k === 1 ? 'pine' : 'oak', k / 3);
    if (tr) ctx.drawImage(tr, x - 30, y - 78, 60, 70);
  }
}

function chestOf(u: UnitPlan, p: Placed): { x: number; y: number } {
  return { x: p.x + (u.side === 'left' ? 4 : -4), y: p.y - 36 };
}

/** Рисует кадр боя на момент t (секунды от начала цикла). */
export function drawBattle(ctx: Ctx, setup: BattleSetup, plan: BattlePlan, tIn: number): void {
  const t = tIn % plan.duration;
  backdrop(ctx, setup.seed ?? 1);
  const placed = plan.units.map((u) => ({ u, p: unitAt(u, plan, t) }));
  // дальние раньше ближних (по y), затем по x
  const order = [...placed].sort((a, b) => a.p.y - b.p.y);
  const S = 0.62;
  for (const { u, p } of order) {
    if (!p.visible) continue;
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.scale(u.side === 'left' ? S : -S, S);
    ctx.translate(-60, -136);
    drawChibi(ctx, {
      cls: u.fighter.cls,
      rarity: u.fighter.rarity ?? 'common',
      tier: u.fighter.tier ?? 1,
      seed: u.fighter.seed ?? u.index + 1,
      pose: p.pose,
      phase: p.phase,
    });
    ctx.restore();
  }
  const by = (i: number): { u: UnitPlan; p: Placed } => placed[i]!;
  for (const h of plan.hits) {
    const a = by(h.attacker);
    const v = by(h.target);
    const since = t - h.t;
    // снаряды в полёте
    if (h.ranged && since > -FLIGHT && since < 0) {
      const k = (since + FLIGHT) / FLIGHT;
      const s = chestOf(a.u, a.p);
      const e = chestOf(v.u, v.p);
      const x = s.x + (e.x - s.x) * k;
      const y = s.y + (e.y - s.y) * k - Math.sin(k * Math.PI) * 22;
      if (h.kind === 'arrow') {
        const ang = Math.atan2(
          e.y - s.y - (Math.cos(k * Math.PI) * 22 * Math.PI) / (e.x - s.x || 1),
          e.x - s.x,
        );
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(ang);
        ctx.strokeStyle = INK;
        ctx.lineWidth = 3.4;
        ctx.beginPath();
        ctx.moveTo(-14, 0);
        ctx.lineTo(10, 0);
        ctx.stroke();
        ctx.strokeStyle = '#e8d8a8';
        ctx.lineWidth = 1.6;
        ctx.stroke();
        ctx.fillStyle = '#cfd6de';
        ctx.beginPath();
        ctx.moveTo(10, -3.5);
        ctx.lineTo(18, 0);
        ctx.lineTo(10, 3.5);
        ctx.fill();
        ctx.restore();
      } else {
        ctx.beginPath();
        ctx.arc(x, y, 9, 0, Math.PI * 2);
        ctx.fillStyle = radial(ctx, x, y, 0, 12, [
          [0, '#ffffff'],
          [0.5, '#9be8ff'],
          [1, 'rgba(58,123,213,0)'],
        ]);
        ctx.fill();
      }
    }
    // вспышка удара и всплывающий урон
    if (since >= 0 && since < 0.9) {
      const c = chestOf(v.u, v.p);
      if (since < 0.22) {
        const k = since / 0.22;
        ctx.save();
        ctx.translate(c.x, c.y);
        ctx.strokeStyle = h.kind === 'magic' ? '#9be8ff' : '#fff3a0';
        ctx.lineWidth = 3 * (1 - k) + 0.6;
        for (let i = 0; i < 8; i++) {
          const a2 = (i / 8) * Math.PI * 2 + 0.3;
          ctx.beginPath();
          ctx.moveTo(Math.cos(a2) * (6 + k * 8), Math.sin(a2) * (6 + k * 8));
          ctx.lineTo(Math.cos(a2) * (12 + k * 20), Math.sin(a2) * (12 + k * 20));
          ctx.stroke();
        }
        ctx.restore();
      }
      const k = since / 0.9;
      ctx.save();
      ctx.globalAlpha = 1 - k * k;
      ctx.font = '800 16px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.lineWidth = 4;
      ctx.strokeStyle = INK;
      ctx.fillStyle = v.u.side === 'left' ? '#ff8f7a' : '#fff06a';
      const ty = c.y - 34 - k * 34;
      ctx.strokeText(String(h.dmg), c.x, ty);
      ctx.fillText(String(h.dmg), c.x, ty);
      ctx.restore();
    }
  }
  // баннер победы в финале
  if (t > plan.endFightAt && setup.victoryText) {
    const k = Math.min(1, (t - plan.endFightAt) / 0.6);
    ctx.save();
    ctx.globalAlpha = k;
    ctx.translate(BATTLE_SIZE.w / 2, 70 - (1 - k) * 20);
    ctx.font = '900 34px system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.lineWidth = 7;
    ctx.strokeStyle = INK;
    ctx.fillStyle = '#ffd86b';
    ctx.strokeText(setup.victoryText, 0, 0);
    ctx.fillText(setup.victoryText, 0, 0);
    ctx.restore();
  }
}
