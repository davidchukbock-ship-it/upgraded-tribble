import { describe, expect, it } from 'vitest';
import { planBattle, unitAt, type BattleSetup } from './battle';
import { poseOf, POSES } from './chibi';

const setup: BattleSetup = {
  winner: 'left',
  seed: 5,
  left: [{ cls: 'knight' }, { cls: 'archer' }, { cls: 'mage' }],
  right: [{ cls: 'rogue' }, { cls: 'peasant' }, { cls: 'archer' }],
};

describe('planBattle', () => {
  it('детерминирован: один setup — один сценарий', () => {
    expect(planBattle(setup)).toEqual(planBattle(setup));
  });

  it('проигравшие погибают, победители — нет', () => {
    const plan = planBattle(setup);
    for (const u of plan.units) {
      if (u.side === 'right') expect(u.diesAt).not.toBeNull();
      else expect(u.diesAt).toBeNull();
    }
    expect(plan.duration).toBeGreaterThan(plan.endFightAt);
  });

  it('удары приходятся только по живым, бьют только живые', () => {
    const plan = planBattle(setup);
    expect(plan.hits.length).toBeGreaterThan(0);
    for (const h of plan.hits) {
      const a = plan.units[h.attacker]!;
      const v = plan.units[h.target]!;
      expect(a.side).not.toBe(v.side);
      expect(v.diesAt === null || h.t < v.diesAt).toBe(true);
      expect(h.dmg).toBeGreaterThan(0);
    }
    for (const u of plan.units)
      for (const start of u.attacks) expect(u.diesAt === null || start < u.diesAt).toBe(true);
  });

  it('дальники стреляют снарядами, ближние — нет', () => {
    const plan = planBattle(setup);
    for (const h of plan.hits) {
      const c = plan.units[h.attacker]!.fighter.cls;
      expect(h.ranged).toBe(c === 'archer' || c === 'mage');
    }
  });

  it('состояния: приход → бой → гибель/ликование', () => {
    const plan = planBattle(setup);
    const loser = plan.units.find((u) => u.side === 'right')!;
    const winner = plan.units.find((u) => u.side === 'left')!;
    expect(unitAt(loser, plan, 0.1).pose).toBe('walk');
    expect(unitAt(loser, plan, loser.diesAt! + 0.3).pose).toBe('die');
    expect(unitAt(loser, plan, plan.duration - 0.1).visible).toBe(false);
    expect(unitAt(winner, plan, plan.endFightAt + 0.2).pose).toBe('cheer');
  });
});

describe('poseOf', () => {
  it('все позы дают конечные числа на всём цикле', () => {
    for (const pose of POSES)
      for (let i = 0; i <= 20; i++) {
        const p = poseOf(pose, i / 20);
        for (const v of Object.values(p)) expect(Number.isFinite(v)).toBe(true);
        expect(p.alpha).toBeGreaterThanOrEqual(0);
        expect(p.alpha).toBeLessThanOrEqual(1);
      }
  });

  it('удар: замах → вперёд → возврат', () => {
    expect(poseOf('attack', 0).arm).toBeCloseTo(0.15);
    expect(poseOf('attack', 0.35).arm).toBeGreaterThan(2);
    expect(poseOf('attack', 0.5).arm).toBeLessThan(0);
    expect(poseOf('attack', 1).arm).toBeCloseTo(0.15);
  });
});
