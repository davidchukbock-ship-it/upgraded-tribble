import { useEffect, useRef, type ReactNode } from 'react';
import { drawChibi, type ChibiClass, type Pose, type Rarity } from './chibi';
import { prefersReducedMotion, subscribeFrames } from './ticker';

/** Какой персонаж art2 изображает жителя города (по имени прежнего NPC). */
export const RESIDENT_CHIBI: Record<string, { cls: ChibiClass; seed: number }> = {
  peasant: { cls: 'peasant', seed: 3 },
  farmer: { cls: 'peasant', seed: 11 },
  guard: { cls: 'guard', seed: 4 },
  scholar: { cls: 'scholar', seed: 6 },
  blacksmith: { cls: 'smith', seed: 2 },
  merchant: { cls: 'merchant', seed: 8 },
  captain: { cls: 'captain', seed: 5 },
  healer: { cls: 'healer', seed: 9 },
  elder: { cls: 'elder', seed: 7 },
};

let supported: boolean | undefined;
/** Есть ли рабочий Canvas 2D (в тестах jsdom его нет); проверяется один раз. */
function canvasSupported(): boolean {
  supported ??=
    typeof document !== 'undefined' && document.createElement('canvas').getContext('2d') !== null;
  return supported;
}

/**
 * Житель/рабочий города внутри SVG-сцены: маленький холст с «чиби», кадры ведёт общий тикер.
 * `(x, y)` — точка под ногами в единицах рисунка, `h` — высота фигуры. Без Canvas 2D показывает `fallback`.
 */
export function SceneChibi({
  cls,
  pose = 'walk',
  seed = 1,
  rarity = 'common',
  h = 72,
  x = 0,
  y = 0,
  speed = 1.3,
  offset = 0,
  fallback,
}: {
  cls: ChibiClass;
  pose?: Pose;
  seed?: number;
  rarity?: Rarity;
  h?: number;
  x?: number;
  y?: number;
  speed?: number;
  offset?: number;
  fallback: ReactNode;
}) {
  const ref = useRef<HTMLCanvasElement>(null);
  const ok = canvasSupported();
  useEffect(() => {
    const cv = ref.current;
    const ctx = cv?.getContext('2d');
    if (!cv || !ctx) return;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    const draw = (t: number): void => {
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, cv.width, cv.height);
      drawChibi(ctx, { cls, rarity, seed, pose, phase: (t * speed + offset) % 1 });
    };
    draw(0);
    if (prefersReducedMotion()) return;
    return subscribeFrames(draw);
  }, [cls, pose, seed, rarity, speed, offset]);
  // холст 120×150; ступни на отметке 136 из 150
  const w = (h * 120) / 150;
  if (!ok) return <>{fallback}</>;
  const feet = (136 / 150) * h;
  return (
    <foreignObject
      x={x - w / 2}
      y={y - feet}
      width={w}
      height={h}
      style={{ pointerEvents: 'none', overflow: 'visible' }}
    >
      <canvas
        ref={ref}
        width={120}
        height={150}
        style={{ width: '100%', height: '100%', display: 'block' }}
      />
    </foreignObject>
  );
}
