import { useEffect, useRef, type ReactNode } from 'react';
import { BUILDING_SIZE, getBuilding, type BuildingKind } from './buildings';
import { prefersReducedMotion, subscribeFrames } from './ticker';

/** Плоть холста в пикселях: хватает для чёткости при типичном размере здания в сцене. */
const PX = 360;

/** Отношение: 1 логическая единица спрайта → единиц рисунка сцены, исходя из размера участка. */
export function spriteScale(footprintW: number, footprintD: number, cell = 32): number {
  // участок 9×9 клеток art2 (по 26 px на клетку) накладывается на средний размер участка в сцене
  return (((footprintW + footprintD) / 2) * cell * 1.4) / (9 * 26);
}

/**
 * Анимированная постройка внутри SVG-сцены. `cx, cy` — центр участка на земле (в единицах рисунка).
 * Возвращает `fallback`, если Canvas 2D недоступен (старые браузеры, тесты).
 */
export function SceneBuilding({
  kind,
  seed,
  cx,
  cy,
  scale,
  fallback,
}: {
  kind: BuildingKind;
  seed: number;
  cx: number;
  cy: number;
  scale: number;
  fallback: ReactNode;
}) {
  const ref = useRef<HTMLCanvasElement>(null);
  const b = getBuilding(kind, seed, true);
  useEffect(() => {
    const cv = ref.current;
    const ctx = cv?.getContext('2d');
    if (!cv || !ctx || !b) return;
    // база один раз уменьшается до размера холста — дальше кадр стоит дёшево
    const baked = document.createElement('canvas');
    baked.width = PX;
    baked.height = PX;
    baked.getContext('2d')?.drawImage(b.base, 0, 0, PX, PX);
    const k = PX / BUILDING_SIZE.w;
    let visible = true;
    const draw = (t: number): void => {
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, PX, PX);
      ctx.drawImage(baked, 0, 0);
      ctx.setTransform(k, 0, 0, k, 0, 0);
      ctx.lineJoin = 'round';
      ctx.lineCap = 'round';
      b.overlay(ctx, t);
    };
    draw(0.5);
    if (prefersReducedMotion()) return;
    const off = subscribeFrames((t) => {
      if (visible) draw(t);
    });
    const io =
      typeof IntersectionObserver === 'function'
        ? new IntersectionObserver((e) => (visible = e[0]?.isIntersecting ?? true))
        : null;
    io?.observe(cv);
    return () => {
      off();
      io?.disconnect();
    };
  }, [b]);
  if (!b) return <>{fallback}</>;
  const w = BUILDING_SIZE.w * scale;
  // центр участка art2 (4,5; 4,5) лежит в логической точке (240, 313)
  return (
    <foreignObject
      x={cx - 240 * scale}
      y={cy - 313 * scale}
      width={w}
      height={w}
      style={{ pointerEvents: 'none', overflow: 'visible' }}
    >
      <canvas
        ref={ref}
        width={PX}
        height={PX}
        style={{ width: '100%', height: '100%', display: 'block' }}
      />
    </foreignObject>
  );
}
