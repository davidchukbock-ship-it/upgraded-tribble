/**
 * Набор примитивов для программного 2D-арта (Canvas 2D): палитра «библии стиля», градиенты, контуры,
 * изометрическая проекция 2:1 и «грани» — плоские системы координат на стенах, в которых можно рисовать
 * кирпич, фахверк, окна и арки обычным 2D-кодом. Всё нарисовано кодом: сторонних изображений нет.
 */

export type Ctx = CanvasRenderingContext2D;
export type Pt = readonly [number, number];

/** Тёплый тёмно-коричневый контур (никогда не чёрный). */
export const INK = 'rgba(42,26,14,0.78)';
export const INK_SOFT = 'rgba(42,26,14,0.45)';
/** Мягкая контактная тень справа-снизу. */
export const SHADOW = 'rgba(42,26,14,0.35)';

export const PALETTE = {
  grass: ['#7bc954', '#4f9b2c'],
  grassDeep: '#3f8524',
  soil: ['#9a6a3a', '#5e3b1c'],
  wood: ['#b57d42', '#6b421a'],
  woodDark: ['#8a5a2c', '#4a2d12'],
  stone: ['#b5afa3', '#6d675b'],
  stoneDark: '#57524a',
  plaster: ['#efe0b8', '#cdb88a'],
  thatch: ['#f5cf6d', '#b88628'],
  royal: '#2e5fa8',
  gold: '#f2cf6b',
  windowGlow: ['#ffe680', '#e69500'],
  water: ['#56a9e0', '#1f5fa0'],
  foam: 'rgba(255,255,255,0.85)',
  road: ['#d9c08a', '#b89a62'],
} as const;

/** Детерминированный генератор 0…1 (mulberry32): один и тот же рисунок при одном seed. */
export function rng(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Холст с повышенной плотностью пикселей: рисуем в логических координатах w × h. */
export function makeCanvas(
  w: number,
  h: number,
  scale = 2,
): { canvas: HTMLCanvasElement; ctx: Ctx } {
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(w * scale);
  canvas.height = Math.round(h * scale);
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas 2D недоступен');
  ctx.scale(scale, scale);
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';
  return { canvas, ctx };
}

// ── Цвет ─────────────────────────────────────────────────────────────────────

export function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace('#', '');
  const n = parseInt(h.length === 3 ? h.replace(/(.)/g, '$1$1') : h, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

const clamp255 = (v: number): number => Math.max(0, Math.min(255, Math.round(v)));

export function rgbToHex(r: number, g: number, b: number): string {
  return `#${[r, g, b].map((v) => clamp255(v).toString(16).padStart(2, '0')).join('')}`;
}

/** Смешивает два цвета: t = 0 — a, t = 1 — b. */
export function mix(a: string, b: string, t: number): string {
  const [ar, ag, ab] = hexToRgb(a);
  const [br, bg, bb] = hexToRgb(b);
  return rgbToHex(ar + (br - ar) * t, ag + (bg - ag) * t, ab + (bb - ab) * t);
}

/** Светлее (amt > 0) или темнее (amt < 0) к белому / к тёплой тени. */
export function shade(hex: string, amt: number): string {
  return amt >= 0 ? mix(hex, '#ffffff', amt) : mix(hex, '#2a1a0e', -amt);
}

// ── Заливки ──────────────────────────────────────────────────────────────────

export function linear(
  ctx: Ctx,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  stops: ReadonlyArray<readonly [number, string]>,
): CanvasGradient {
  const g = ctx.createLinearGradient(x0, y0, x1, y1);
  for (const [o, c] of stops) g.addColorStop(o, c);
  return g;
}

/** Градиент между двумя цветами вдоль вектора (x0,y0)→(x1,y1). */
export function duo(
  ctx: Ctx,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  a: string,
  b: string,
): CanvasGradient {
  return linear(ctx, x0, y0, x1, y1, [
    [0, a],
    [1, b],
  ]);
}

export function radial(
  ctx: Ctx,
  x: number,
  y: number,
  r0: number,
  r1: number,
  stops: ReadonlyArray<readonly [number, string]>,
): CanvasGradient {
  const g = ctx.createRadialGradient(x, y, r0, x, y, r1);
  for (const [o, c] of stops) g.addColorStop(o, c);
  return g;
}

// ── Контуры и многоугольники ────────────────────────────────────────────────

export function pathPoly(ctx: Ctx, pts: ReadonlyArray<Pt>): void {
  ctx.beginPath();
  pts.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
  ctx.closePath();
}

/** Залитый многоугольник с тёплым контуром постоянной толщины. */
export function poly(
  ctx: Ctx,
  pts: ReadonlyArray<Pt>,
  fill: string | CanvasGradient | CanvasPattern,
  lw = 2.4,
): void {
  pathPoly(ctx, pts);
  ctx.fillStyle = fill;
  ctx.fill();
  if (lw > 0) {
    ctx.lineWidth = lw;
    ctx.strokeStyle = INK;
    ctx.stroke();
  }
}

export function line(ctx: Ctx, a: Pt, b: Pt, color: string, lw: number): void {
  ctx.beginPath();
  ctx.moveTo(a[0], a[1]);
  ctx.lineTo(b[0], b[1]);
  ctx.strokeStyle = color;
  ctx.lineWidth = lw;
  ctx.stroke();
}

/** Мягкая тень под объектом: многоугольник, размытый через shadowBlur. */
export function softShadow(ctx: Ctx, pts: ReadonlyArray<Pt>, blur = 10, color = SHADOW): void {
  ctx.save();
  const sc = ctx.getTransform().a || 1;
  ctx.shadowColor = color;
  ctx.shadowBlur = blur * sc;
  ctx.fillStyle = color;
  // фигуру рисуем далеко за холстом, а тень (её смещение задано в пикселях устройства) возвращаем обратно
  const off = 4000;
  ctx.translate(-off, 0);
  ctx.shadowOffsetX = off * sc;
  pathPoly(ctx, pts);
  ctx.fill();
  ctx.restore();
}

export function ellipseShadow(ctx: Ctx, x: number, y: number, rx: number, ry = rx * 0.42): void {
  ctx.save();
  ctx.beginPath();
  ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
  ctx.fillStyle = radial(ctx, x, y, 0, rx, [
    [0, 'rgba(42,26,14,0.45)'],
    [1, 'rgba(42,26,14,0)'],
  ]);
  ctx.fill();
  ctx.restore();
}

// ── Изометрия 2:1 и грани ───────────────────────────────────────────────────

export interface IsoView {
  /** Экранная точка мирового (0, 0, 0). */
  ox: number;
  oy: number;
  /** Половина ширины единичной клетки в пикселях. */
  s: number;
}

/** Мир (x вправо-вниз, y влево-вниз, z вверх) → экран. */
export const project = (v: IsoView, x: number, y: number, z = 0): Pt => [
  v.ox + (x - y) * v.s,
  v.oy + (x + y) * v.s * 0.5 - z,
];

/**
 * Рисует в «плоской системе» стены: начало в левом верхнем углу грани, u вправо вдоль стены, v вниз,
 * единицы — пиксели. Так кирпич, окна и арки пишутся обычным 2D-кодом, а на экран ложатся с перекосом.
 * `face` — 'left' (грань +y, смотрит влево-вниз, освещена) или 'right' (грань +x, в тени).
 */
export function onFace(
  ctx: Ctx,
  v: IsoView,
  face: 'left' | 'right',
  x: number,
  y: number,
  z: number,
  w: number,
  d: number,
  h: number,
  draw: (widthPx: number, heightPx: number) => void,
  unit = 40,
): void {
  // размеры грани в пикселях плоской системы: по 1 единице мира = `unit` пикселей
  const len = (face === 'left' ? w : d) * unit;
  const [tx, ty] = face === 'left' ? project(v, x, y + d, z + h) : project(v, x + w, y + d, z + h);
  const k = v.s / unit;
  ctx.save();
  if (face === 'left') ctx.transform(k, k * 0.5, 0, 1, tx, ty);
  else ctx.transform(k, -k * 0.5, 0, 1, tx, ty);
  draw(len, h);
  ctx.restore();
}

/** Контур грани в экранных координатах (для клипа и контура). */
export function facePoly(
  v: IsoView,
  face: 'left' | 'right' | 'top',
  x: number,
  y: number,
  z: number,
  w: number,
  d: number,
  h: number,
): Pt[] {
  if (face === 'left')
    return [
      project(v, x, y + d, z),
      project(v, x + w, y + d, z),
      project(v, x + w, y + d, z + h),
      project(v, x, y + d, z + h),
    ];
  if (face === 'right')
    return [
      project(v, x + w, y + d, z),
      project(v, x + w, y, z),
      project(v, x + w, y, z + h),
      project(v, x + w, y + d, z + h),
    ];
  return [
    project(v, x, y, z + h),
    project(v, x + w, y, z + h),
    project(v, x + w, y + d, z + h),
    project(v, x, y + d, z + h),
  ];
}

/** Ограничивает рисование гранью (по многоугольнику). */
export function clipPoly(ctx: Ctx, pts: ReadonlyArray<Pt>): void {
  pathPoly(ctx, pts);
  ctx.clip();
}
