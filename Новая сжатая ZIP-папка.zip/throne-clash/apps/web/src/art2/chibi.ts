/**
 * 2D-персонажи в «чиби»-пропорциях: крупная голова, выразительные глаза, плавные формы, мягкие тени.
 * Класс, редкость и уровень задаются параметрами — никаких внешних изображений.
 */
import {
  INK,
  PALETTE,
  ellipseShadow,
  linear,
  makeCanvas,
  mix,
  radial,
  rng,
  shade,
  type Ctx,
} from './kit';

export type ChibiClass =
  | 'knight'
  | 'archer'
  | 'mage'
  | 'peasant'
  | 'king'
  | 'rogue'
  | 'guard'
  | 'captain'
  | 'smith'
  | 'merchant'
  | 'healer'
  | 'elder'
  | 'scholar';

/** Носит латы и шлем (общий облик воинов). */
const armored = (c: ChibiClass): boolean => c === 'knight' || c === 'guard' || c === 'captain';
/** Носит длинную накидку/мантию. */
const robed = (c: ChibiClass): boolean =>
  c === 'king' || c === 'mage' || c === 'healer' || c === 'elder' || c === 'scholar';
export type Rarity = 'common' | 'rare' | 'epic' | 'legendary';

export interface ChibiOptions {
  cls: ChibiClass;
  rarity?: Rarity;
  /** Ступень экипировки 1…5: влияет на цвет и украшения брони. */
  tier?: number;
  seed?: number;
  /** Поза и фаза 0…1 внутри неё (цикл для idle/walk/cheer, однократно для attack/hurt/die). */
  pose?: Pose;
  phase?: number;
}

export const CHIBI_SIZE = { w: 120, h: 150 } as const;

const SKIN = ['#f6d3b0', '#e9b98f', '#c98f63', '#9c6a44'];
const HAIR = ['#3b2a1c', '#8a4b1d', '#d9a441', '#cfcfd6', '#7a2c2c', '#2b3a5c'];
const RARITY_COL: Record<Rarity, string> = {
  common: '#cbd2da',
  rare: '#5aa6ff',
  epic: '#b56bff',
  legendary: '#ffc83d',
};
const CLASS_COL: Record<ChibiClass, [string, string]> = {
  knight: ['#9fb3c8', '#4b5d73'],
  archer: ['#6fbf5a', '#2f6a2c'],
  mage: ['#7a6bff', '#3a2f9a'],
  peasant: ['#c9a06a', '#7a5630'],
  king: ['#d8382f', '#7a1515'],
  rogue: ['#5a5f6e', '#22252f'],
  guard: ['#8f9bb0', '#3f4a5e'],
  captain: ['#b9465a', '#6a1f30'],
  smith: ['#9a7a54', '#4a3520'],
  merchant: ['#2e9a9a', '#15525a'],
  healer: ['#f4f4f4', '#b9c4d0'],
  elder: ['#8a8fa0', '#4a4f60'],
  scholar: ['#8a5a9a', '#4a2f5a'],
};

function outline(ctx: Ctx, w = 2.2): void {
  ctx.lineWidth = w;
  ctx.strokeStyle = INK;
  ctx.stroke();
}

function capsule(
  ctx: Ctx,
  x: number,
  y: number,
  w: number,
  h: number,
  fill: string | CanvasGradient,
): void {
  const r = Math.min(w, h) / 2;
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, r);
  ctx.fillStyle = fill;
  ctx.fill();
  outline(ctx);
}

/** Оружие в локальных координатах руки: начало — ладонь, «вверх» — острие. */
function weapon(ctx: Ctx, cls: ChibiClass, pull: number, charge: number): void {
  if (cls === 'knight' || cls === 'king' || cls === 'captain') {
    capsule(
      ctx,
      -2.5,
      -44,
      5,
      40,
      linear(ctx, -3, 0, 3, 0, [
        [0, '#f2f6fa'],
        [1, '#8b97a6'],
      ]),
    );
    capsule(ctx, -9, -6, 18, 5, PALETTE.gold);
    capsule(ctx, -2.5, -2, 5, 12, '#6b421a');
  } else if (cls === 'mage') {
    capsule(ctx, -2, -54, 4, 66, '#8a5a2c');
    const R = 8 + charge * 4;
    ctx.beginPath();
    ctx.arc(0, -58, R, 0, Math.PI * 2);
    ctx.fillStyle = radial(ctx, -2, -60, 0, R + 1, [
      [0, '#ffffff'],
      [0.5, '#9be8ff'],
      [1, '#3a7bd5'],
    ]);
    ctx.fill();
    outline(ctx, 1.8);
  } else if (cls === 'archer') {
    ctx.beginPath();
    ctx.moveTo(-2, -36);
    ctx.quadraticCurveTo(16, -2, -2, 32);
    ctx.strokeStyle = INK;
    ctx.lineWidth = 6;
    ctx.stroke();
    ctx.strokeStyle = '#a06a30';
    ctx.lineWidth = 3.4;
    ctx.stroke();
    // тетива с оттяжкой и стрела
    const px = -2 - pull * 16;
    ctx.beginPath();
    ctx.moveTo(-2, -36);
    ctx.lineTo(px, 0);
    ctx.lineTo(-2, 32);
    ctx.strokeStyle = '#efe6cf';
    ctx.lineWidth = 1.2;
    ctx.stroke();
    if (pull > 0.05) {
      ctx.strokeStyle = INK;
      ctx.lineWidth = 3.4;
      ctx.beginPath();
      ctx.moveTo(px, 0);
      ctx.lineTo(px + 34, 0);
      ctx.stroke();
      ctx.strokeStyle = '#d8c8a0';
      ctx.lineWidth = 1.8;
      ctx.stroke();
      ctx.fillStyle = '#cfd6de';
      ctx.beginPath();
      ctx.moveTo(px + 34, -3.5);
      ctx.lineTo(px + 42, 0);
      ctx.lineTo(px + 34, 3.5);
      ctx.closePath();
      ctx.fill();
    }
  } else if (cls === 'rogue') {
    capsule(
      ctx,
      -2,
      -24,
      4,
      26,
      linear(ctx, -2, 0, 2, 0, [
        [0, '#ffffff'],
        [1, '#8b97a6'],
      ]),
    );
    capsule(ctx, -5, 0, 10, 4, '#3a2a1e');
  } else if (cls === 'smith') {
    capsule(ctx, -2, -34, 4, 40, '#8a5a2c');
    capsule(
      ctx,
      -11,
      -46,
      22,
      14,
      linear(ctx, -11, -46, 11, -32, [
        [0, '#b9c0cc'],
        [1, '#5f6774'],
      ]),
    );
  } else if (cls === 'merchant') {
    capsule(ctx, -1.6, -34, 3.2, 44, '#6b421a');
    ctx.beginPath();
    ctx.arc(0, -36, 5, 0, Math.PI * 2);
    ctx.fillStyle = PALETTE.gold;
    ctx.fill();
    outline(ctx, 1.6);
  } else if (cls === 'healer') {
    capsule(ctx, -2, -50, 4, 62, '#e9dcc0');
    ctx.beginPath();
    ctx.arc(0, -56, 8, 0, Math.PI * 2);
    ctx.fillStyle = radial(ctx, -2, -58, 0, 9, [
      [0, '#ffffff'],
      [0.6, '#8dffa0'],
      [1, '#2fbf5a'],
    ]);
    ctx.fill();
    outline(ctx, 1.8);
  } else if (cls === 'elder') {
    capsule(ctx, -2.4, -52, 4.8, 64, '#7a5230');
    ctx.beginPath();
    ctx.arc(0, -54, 6, 0, Math.PI * 2);
    ctx.fillStyle = '#9be8ff';
    ctx.fill();
    outline(ctx, 1.8);
  } else if (cls === 'guard') {
    capsule(ctx, -1.6, -60, 3.2, 72, '#8a5a2c');
    ctx.beginPath();
    ctx.moveTo(0, -76);
    ctx.lineTo(5, -58);
    ctx.lineTo(-5, -58);
    ctx.closePath();
    ctx.fillStyle = '#dfe6ee';
    ctx.fill();
    outline(ctx, 1.8);
  } else if (cls === 'scholar') {
    ctx.beginPath();
    ctx.roundRect(-9, -22, 18, 24, 2);
    ctx.fillStyle = '#7a3a3a';
    ctx.fill();
    outline(ctx, 1.8);
    ctx.fillStyle = '#f3e8c8';
    ctx.fillRect(-7, -20, 3, 20);
  } else {
    // крестьянин: вилы
    capsule(ctx, -1.6, -40, 3.2, 54, '#8a5a2c');
    ctx.beginPath();
    ctx.moveTo(-7, -40);
    ctx.lineTo(-7, -52);
    ctx.moveTo(0, -40);
    ctx.lineTo(0, -56);
    ctx.moveTo(7, -40);
    ctx.lineTo(7, -52);
    ctx.strokeStyle = INK;
    ctx.lineWidth = 3.4;
    ctx.stroke();
    ctx.strokeStyle = '#c7ccd2';
    ctx.lineWidth = 1.6;
    ctx.stroke();
  }
}

export type Pose = 'idle' | 'walk' | 'attack' | 'hurt' | 'cheer' | 'die';
export const POSES: readonly Pose[] = ['idle', 'walk', 'attack', 'hurt', 'cheer', 'die'];

/** Параметры позы на фазе 0…1 (идле/ходьба — цикл, остальные — однократно). */
export interface PoseParams {
  dx: number;
  dy: number;
  lean: number;
  leg: number;
  arm: number; // угол ведущей руки (рад), 0 — свисает вниз, + к спине, − вперёд
  blade: number; // мировой угол оружия (0 — вверх, + вправо)
  armL: number;
  pull: number;
  charge: number;
  flash: number;
  alpha: number;
}

const ease = (u: number): number => u * u * (3 - 2 * u);
const lerp = (a: number, b: number, u: number): number => a + (b - a) * u;

export function poseOf(pose: Pose, phase: number): PoseParams {
  const p: PoseParams = {
    dx: 0,
    dy: 0,
    lean: 0,
    leg: 0,
    arm: 0.15,
    blade: 0.25,
    armL: -0.1,
    pull: 0,
    charge: 0,
    flash: 0,
    alpha: 1,
  };
  const c = Math.sin(phase * Math.PI * 2);
  if (pose === 'idle') {
    p.dy = c * 1.4;
    p.arm = 0.15 + c * 0.04;
  } else if (pose === 'walk') {
    p.leg = c;
    p.dy = -Math.abs(c) * 3;
    p.lean = 0.05;
    p.arm = 0.15 - c * 0.25;
    p.armL = -0.1 + c * 0.55;
    p.blade = 0.3 + c * 0.1;
  } else if (pose === 'attack') {
    const W = { arm: 2.4, blade: -0.9 };
    const S = { arm: -1.2, blade: 1.9 };
    let u: number;
    if (phase < 0.35) {
      u = ease(phase / 0.35);
      p.arm = lerp(0.15, W.arm, u);
      p.blade = lerp(0.25, W.blade, u);
      p.lean = -0.1 * u;
      p.pull = u;
      p.charge = u;
    } else if (phase < 0.5) {
      u = ease((phase - 0.35) / 0.15);
      p.arm = lerp(W.arm, S.arm, u);
      p.blade = lerp(W.blade, S.blade, u);
      p.lean = lerp(-0.1, 0.22, u);
      p.dx = 26 * u;
      p.charge = 1 - u * 0.5;
    } else {
      u = ease((phase - 0.5) / 0.5);
      p.arm = lerp(S.arm, 0.15, u);
      p.blade = lerp(S.blade, 0.25, u);
      p.lean = lerp(0.22, 0, u);
      p.dx = 26 * (1 - u);
      p.charge = 0.5 * (1 - u);
    }
    p.armL = -0.3;
  } else if (pose === 'hurt') {
    const k = Math.sin(Math.min(1, phase) * Math.PI);
    p.dx = -8 * k;
    p.lean = -0.25 * k;
    p.arm = 0.15 + 0.9 * k;
    p.armL = -0.1 - 0.9 * k;
    p.flash = phase < 0.45 ? 1 - phase / 0.45 : 0;
  } else if (pose === 'cheer') {
    p.dy = -Math.abs(Math.sin(phase * Math.PI * 2)) * 12;
    p.arm = 2.9 + c * 0.25;
    p.blade = 0.1 + c * 0.1;
    p.armL = -2.9 - c * 0.25;
  } else {
    const u = ease(Math.min(1, phase));
    p.lean = -1.45 * u;
    p.dx = -14 * u;
    p.dy = 14 * u;
    p.arm = 0.15 + 1.6 * u;
    p.alpha = phase < 0.6 ? 1 : 1 - (phase - 0.6) / 0.4;
    p.armL = -0.1 - 1.2 * u;
  }
  return p;
}

function eye(ctx: Ctx, x: number, y: number, iris: string): void {
  ctx.beginPath();
  ctx.ellipse(x, y, 5.4, 7, 0, 0, Math.PI * 2);
  ctx.fillStyle = '#ffffff';
  ctx.fill();
  outline(ctx, 1.6);
  ctx.beginPath();
  ctx.ellipse(x, y + 0.8, 3.8, 5.2, 0, 0, Math.PI * 2);
  ctx.fillStyle = linear(ctx, x, y - 5, x, y + 6, [
    [0, shade(iris, 0.25)],
    [1, shade(iris, -0.35)],
  ]);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(x, y + 1.6, 2, 2.8, 0, 0, Math.PI * 2);
  ctx.fillStyle = '#1a1208';
  ctx.fill();
  ctx.beginPath();
  ctx.arc(x - 1.6, y - 2, 1.6, 0, Math.PI * 2);
  ctx.fillStyle = '#fff';
  ctx.fill();
}

/** Рисует персонажа 120×150; якорь — середина ступней (60, 136). */
export function renderChibi(opts: ChibiOptions): HTMLCanvasElement {
  const { canvas, ctx } = makeCanvas(CHIBI_SIZE.w, CHIBI_SIZE.h);
  drawChibi(ctx, opts);
  return canvas;
}

/**
 * Рисует персонажа в текущей системе координат (120×150, якорь — середина ступней (60, 136)).
 * Поза и фаза задают кадр анимации; можно звать каждый кадр — рисунок детерминирован.
 */
export function drawChibi(ctx: Ctx, opts: ChibiOptions): void {
  const { cls, rarity = 'common', tier = 1, seed = 1, phase = 0, pose = 'idle' } = opts;
  const p = poseOf(pose, phase);
  ctx.save();
  ctx.globalAlpha *= p.alpha;
  if (p.flash > 0) ctx.filter = `brightness(${1 + p.flash * 1.1}) saturate(${1 + p.flash})`;
  const r = rng(seed * 57 + cls.length);
  const skin = SKIN[Math.floor(r() * SKIN.length)]!;
  const hair = cls === 'elder' ? '#ecebf2' : HAIR[Math.floor(r() * HAIR.length)]!;
  const iris = ['#3d7be0', '#3fa05a', '#8a5a2c', '#7a4bd0'][Math.floor(r() * 4)]!;
  const [c1, c2] = CLASS_COL[cls];
  const bob = p.dy;
  const step = p.leg * 8;
  const rc = RARITY_COL[rarity];

  // аура редкости
  if (rarity !== 'common') {
    ctx.beginPath();
    ctx.ellipse(60, 132, 40, 12, 0, 0, Math.PI * 2);
    ctx.fillStyle = radial(ctx, 60, 132, 2, 44, [
      [0, rc],
      [1, 'rgba(255,255,255,0)'],
    ]);
    ctx.globalAlpha = 0.85;
    ctx.fill();
    ctx.globalAlpha = 1;
  }
  ellipseShadow(ctx, 60, 136, 26, 7);

  // ноги
  const liftA = Math.max(0, p.leg) * 6;
  const liftB = Math.max(0, -p.leg) * 6;
  capsule(ctx, 41 + step * 0.4, 106 - liftA, 15, 28, shade(c2, -0.1));
  capsule(ctx, 64 - step * 0.4, 106 - liftB, 15, 28, shade(c2, -0.1));
  ctx.beginPath();
  ctx.ellipse(48 + step * 0.4, 134 - liftA, 11, 5.5, 0, 0, Math.PI * 2);
  ctx.ellipse(72 - step * 0.4, 134 - liftB, 11, 5.5, 0, 0, Math.PI * 2);
  ctx.fillStyle = '#5a3820';
  ctx.fill();
  outline(ctx, 1.8);

  ctx.save();
  ctx.translate(p.dx, bob);
  ctx.translate(60, 116);
  ctx.rotate(p.lean);
  ctx.translate(-60, -116);
  // плащ короля
  if (robed(cls)) {
    ctx.beginPath();
    ctx.moveTo(38, 74);
    ctx.quadraticCurveTo(24, 110, 34, 126);
    ctx.lineTo(86, 126);
    ctx.quadraticCurveTo(96, 110, 82, 74);
    ctx.closePath();
    ctx.fillStyle = linear(ctx, 0, 74, 0, 126, [
      [0, shade(c1, -0.1)],
      [1, shade(c2, -0.25)],
    ]);
    ctx.fill();
    outline(ctx);
  }
  // туловище
  ctx.beginPath();
  ctx.roundRect(38, 72, 44, 44, 15);
  ctx.fillStyle = linear(ctx, 38, 72, 82, 116, [
    [0, shade(c1, 0.12)],
    [1, c2],
  ]);
  ctx.fill();
  outline(ctx);
  // ремень и пряжка
  ctx.fillStyle = '#5a3820';
  ctx.fillRect(40, 100, 40, 6);
  ctx.fillStyle = PALETTE.gold;
  ctx.fillRect(56, 99, 8, 8);
  // украшения ступени
  for (let i = 0; i < Math.min(tier, 5); i++) {
    ctx.beginPath();
    ctx.arc(46 + i * 7, 88, 2.2, 0, Math.PI * 2);
    ctx.fillStyle = tier >= 4 ? rc : PALETTE.gold;
    ctx.fill();
  }
  if (armored(cls)) {
    ctx.beginPath();
    ctx.ellipse(40, 74, 12, 8, -0.3, 0, Math.PI * 2);
    ctx.ellipse(80, 74, 12, 8, 0.3, 0, Math.PI * 2);
    ctx.fillStyle = linear(ctx, 0, 66, 0, 82, [
      [0, '#dfe7ef'],
      [1, '#7e8ca0'],
    ]);
    ctx.fill();
    outline(ctx);
  }
  // свободная рука
  ctx.save();
  ctx.translate(32, 80);
  ctx.rotate(p.armL);
  capsule(ctx, -6.5, -4, 13, 28, shade(c1, -0.05));
  ctx.beginPath();
  ctx.arc(0, 26, 6, 0, Math.PI * 2);
  ctx.fillStyle = skin;
  ctx.fill();
  outline(ctx, 1.8);
  ctx.restore();

  // голова
  const hx = 60;
  const hy = 46;
  ctx.beginPath();
  ctx.ellipse(hx, hy, 29, 27, 0, 0, Math.PI * 2);
  ctx.fillStyle = radial(ctx, hx - 8, hy - 10, 2, 38, [
    [0, shade(skin, 0.12)],
    [1, shade(skin, -0.12)],
  ]);
  ctx.fill();
  outline(ctx);
  // волосы
  if (!armored(cls)) {
    ctx.beginPath();
    ctx.ellipse(hx, hy - 10, 30, 21, 0, Math.PI, Math.PI * 2);
    ctx.quadraticCurveTo(hx + 14, hy - 2, hx + 2, hy - 8);
    ctx.quadraticCurveTo(hx - 12, hy - 4, hx - 28, hy - 6);
    ctx.closePath();
    ctx.fillStyle = linear(ctx, 0, hy - 30, 0, hy, [
      [0, shade(hair, 0.2)],
      [1, shade(hair, -0.2)],
    ]);
    ctx.fill();
    outline(ctx);
  }
  // лицо
  eye(ctx, hx - 11, hy + 3, iris);
  eye(ctx, hx + 11, hy + 3, iris);
  ctx.beginPath();
  ctx.arc(hx - 19, hy + 13, 4.4, 0, Math.PI * 2);
  ctx.arc(hx + 19, hy + 13, 4.4, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(255,120,110,0.45)';
  ctx.fill();
  ctx.beginPath();
  ctx.arc(hx, hy + 14, 4.2, 0.15 * Math.PI, 0.85 * Math.PI);
  ctx.strokeStyle = INK;
  ctx.lineWidth = 1.8;
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(hx - 17, hy - 7);
  ctx.quadraticCurveTo(hx - 11, hy - 11, hx - 5, hy - 8);
  ctx.moveTo(hx + 5, hy - 8);
  ctx.quadraticCurveTo(hx + 11, hy - 11, hx + 17, hy - 7);
  ctx.strokeStyle = shade(hair, -0.25);
  ctx.lineWidth = 2;
  ctx.stroke();

  // головные уборы по классу
  if (armored(cls)) {
    ctx.beginPath();
    ctx.ellipse(hx, hy - 12, 31, 22, 0, Math.PI, Math.PI * 2);
    ctx.lineTo(hx + 31, hy - 4);
    ctx.lineTo(hx - 31, hy - 4);
    ctx.closePath();
    ctx.fillStyle = linear(ctx, hx - 30, 0, hx + 30, 0, [
      [0, '#eef3f8'],
      [0.5, '#a9b6c6'],
      [1, '#6d7b8f'],
    ]);
    ctx.fill();
    outline(ctx);
    ctx.beginPath();
    ctx.moveTo(hx, hy - 34);
    ctx.quadraticCurveTo(hx + 16, hy - 52, hx + 4, hy - 56);
    ctx.quadraticCurveTo(hx - 8, hy - 44, hx, hy - 34);
    ctx.fillStyle = tier >= 3 ? rc : '#d8382f';
    if (cls !== 'guard') {
      ctx.fill();
      outline(ctx, 1.8);
    }
  } else if (cls === 'mage') {
    ctx.beginPath();
    ctx.ellipse(hx, hy - 14, 40, 8, 0, 0, Math.PI * 2);
    ctx.fillStyle = shade(c1, -0.15);
    ctx.fill();
    outline(ctx);
    ctx.beginPath();
    ctx.moveTo(hx - 24, hy - 14);
    ctx.quadraticCurveTo(hx - 8, hy - 40, hx + 14, hy - 70);
    ctx.quadraticCurveTo(hx + 26, hy - 40, hx + 24, hy - 14);
    ctx.closePath();
    ctx.fillStyle = linear(ctx, hx - 24, 0, hx + 24, 0, [
      [0, c1],
      [1, c2],
    ]);
    ctx.fill();
    outline(ctx);
    ctx.beginPath();
    ctx.arc(hx + 2, hy - 34, 3, 0, Math.PI * 2);
    ctx.fillStyle = PALETTE.gold;
    ctx.fill();
  } else if (cls === 'archer' || cls === 'rogue') {
    ctx.beginPath();
    ctx.moveTo(hx - 31, hy + 2);
    ctx.quadraticCurveTo(hx - 34, hy - 34, hx, hy - 34);
    ctx.quadraticCurveTo(hx + 34, hy - 34, hx + 31, hy + 2);
    ctx.quadraticCurveTo(hx + 26, hy - 14, hx, hy - 16);
    ctx.quadraticCurveTo(hx - 26, hy - 14, hx - 31, hy + 2);
    ctx.fillStyle = linear(ctx, 0, hy - 34, 0, hy, [
      [0, shade(c1, 0.1)],
      [1, c2],
    ]);
    ctx.fill();
    outline(ctx);
    if (cls === 'archer') {
      ctx.beginPath();
      ctx.moveTo(hx + 16, hy - 30);
      ctx.lineTo(hx + 30, hy - 52);
      ctx.lineTo(hx + 22, hy - 28);
      ctx.fillStyle = '#ffffff';
      ctx.fill();
      outline(ctx, 1.6);
    }
  } else if (cls === 'smith') {
    ctx.beginPath();
    ctx.ellipse(hx, hy - 12, 30, 17, 0, Math.PI, Math.PI * 2);
    ctx.lineTo(hx + 30, hy - 8);
    ctx.lineTo(hx - 30, hy - 8);
    ctx.closePath();
    ctx.fillStyle = '#c0392b';
    ctx.fill();
    outline(ctx);
  } else if (cls === 'merchant') {
    ctx.beginPath();
    ctx.ellipse(hx, hy - 14, 34, 8, 0, 0, Math.PI * 2);
    ctx.fillStyle = '#1f6f78';
    ctx.fill();
    outline(ctx);
    ctx.beginPath();
    ctx.ellipse(hx, hy - 22, 20, 13, 0, Math.PI, Math.PI * 2);
    ctx.fill();
    outline(ctx);
    ctx.beginPath();
    ctx.moveTo(hx + 12, hy - 30);
    ctx.quadraticCurveTo(hx + 34, hy - 52, hx + 26, hy - 26);
    ctx.fillStyle = '#ffffff';
    ctx.fill();
    outline(ctx, 1.6);
  } else if (cls === 'healer') {
    ctx.beginPath();
    ctx.moveTo(hx - 31, hy + 6);
    ctx.quadraticCurveTo(hx - 34, hy - 36, hx, hy - 36);
    ctx.quadraticCurveTo(hx + 34, hy - 36, hx + 31, hy + 6);
    ctx.quadraticCurveTo(hx + 24, hy - 14, hx, hy - 16);
    ctx.quadraticCurveTo(hx - 24, hy - 14, hx - 31, hy + 6);
    ctx.fillStyle = '#f6f6f6';
    ctx.fill();
    outline(ctx);
    ctx.fillStyle = '#2fbf5a';
    ctx.fillRect(hx - 2.5, hy - 32, 5, 12);
    ctx.fillRect(hx - 6.5, hy - 28.5, 13, 5);
  } else if (cls === 'elder') {
    ctx.beginPath();
    ctx.moveTo(hx - 22, hy + 10);
    ctx.quadraticCurveTo(hx, hy + 52, hx + 22, hy + 10);
    ctx.quadraticCurveTo(hx, hy + 20, hx - 22, hy + 10);
    ctx.fillStyle = '#f2f2f6';
    ctx.fill();
    outline(ctx, 1.8);
  } else if (cls === 'scholar') {
    ctx.beginPath();
    ctx.ellipse(hx, hy - 20, 26, 7, 0, 0, Math.PI * 2);
    ctx.fillStyle = '#3a2a4a';
    ctx.fill();
    outline(ctx);
    ctx.fillStyle = PALETTE.gold;
    ctx.fillRect(hx + 22, hy - 20, 2, 18);
  } else if (cls === 'king') {
    ctx.beginPath();
    ctx.moveTo(hx - 20, hy - 22);
    ctx.lineTo(hx - 22, hy - 42);
    ctx.lineTo(hx - 10, hy - 32);
    ctx.lineTo(hx, hy - 46);
    ctx.lineTo(hx + 10, hy - 32);
    ctx.lineTo(hx + 22, hy - 42);
    ctx.lineTo(hx + 20, hy - 22);
    ctx.closePath();
    ctx.fillStyle = linear(ctx, 0, hy - 46, 0, hy - 22, [
      [0, '#fff2a8'],
      [1, '#d9a11f'],
    ]);
    ctx.fill();
    outline(ctx);
    ctx.beginPath();
    ctx.arc(hx, hy - 28, 2.6, 0, Math.PI * 2);
    ctx.fillStyle = '#d8382f';
    ctx.fill();
  } else {
    // соломенная шляпа
    ctx.beginPath();
    ctx.ellipse(hx, hy - 14, 38, 9, 0, 0, Math.PI * 2);
    ctx.fillStyle = mix(PALETTE.thatch[0], PALETTE.thatch[1], 0.3);
    ctx.fill();
    outline(ctx);
    ctx.beginPath();
    ctx.ellipse(hx, hy - 20, 20, 13, 0, Math.PI, Math.PI * 2);
    ctx.fillStyle = PALETTE.thatch[0];
    ctx.fill();
    outline(ctx);
  }
  // ведущая рука с оружием — поверх головы
  ctx.save();
  ctx.translate(88, 80);
  ctx.rotate(p.arm);
  capsule(ctx, -6.5, -4, 13, 28, shade(c1, -0.05));
  ctx.translate(0, 26);
  ctx.rotate(p.blade - p.arm);
  weapon(ctx, cls, p.pull, p.charge);
  ctx.beginPath();
  ctx.arc(0, 0, 6, 0, Math.PI * 2);
  ctx.fillStyle = skin;
  ctx.fill();
  outline(ctx, 1.8);
  ctx.restore();
  ctx.restore();

  // блеск легендарной редкости
  if (rarity === 'legendary' || rarity === 'epic') {
    for (let i = 0; i < 5; i++) {
      const x = 14 + r() * 92;
      const y = 14 + r() * 100;
      ctx.beginPath();
      ctx.moveTo(x, y - 5);
      ctx.lineTo(x + 1.6, y - 1.6);
      ctx.lineTo(x + 5, y);
      ctx.lineTo(x + 1.6, y + 1.6);
      ctx.lineTo(x, y + 5);
      ctx.lineTo(x - 1.6, y + 1.6);
      ctx.lineTo(x - 5, y);
      ctx.lineTo(x - 1.6, y - 1.6);
      ctx.closePath();
      ctx.fillStyle = rc;
      ctx.save();
      ctx.globalAlpha *= 0.9;
      ctx.fill();
      ctx.restore();
    }
  }
  ctx.restore();
}
