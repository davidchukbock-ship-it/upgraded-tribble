import { describe, expect, it } from 'vitest';
import { WALKERS } from '../features/castle/scene/layout';
import { RESIDENT_CHIBI } from './SceneChibi';

describe('RESIDENT_CHIBI', () => {
  it('у каждого жителя города есть чиби-образ', () => {
    for (const w of WALKERS) expect(RESIDENT_CHIBI[w.npc], w.npc).toBeDefined();
  });

  it('роли различаются: кузнец, лекарь и стражник — разные классы', () => {
    const classes = new Set(Object.values(RESIDENT_CHIBI).map((c) => c.cls));
    expect(classes.size).toBeGreaterThanOrEqual(8);
  });
});
