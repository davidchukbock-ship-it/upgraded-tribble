import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { MotionConfig } from 'framer-motion';
import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { RouterProvider } from 'react-router-dom';
import { createRouter } from './app/router';
import { bootstrapSession } from './features/auth/session';
import { initI18n } from './lib/i18n';
import './styles/index.css';

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 1, refetchOnWindowFocus: false } },
});

const rootEl = document.getElementById('root');
if (!rootEl) throw new Error('#root not found');

void initI18n().then(async () => {
  await bootstrapSession(); // восстановить вход по refresh-cookie до первого рендера маршрутов
  createRoot(rootEl).render(
    <StrictMode>
      <MotionConfig reducedMotion="user">
        <QueryClientProvider client={queryClient}>
          <RouterProvider router={createRouter()} future={{ v7_startTransition: true }} />
        </QueryClientProvider>
      </MotionConfig>
    </StrictMode>,
  );
});
