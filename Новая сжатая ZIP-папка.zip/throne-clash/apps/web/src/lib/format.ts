/** Число для интерфейса: до 9 999 — полностью, дальше компактно (12,3K · 1,2M). Детерминировано, без Intl. */
export function formatNumber(n: number): string {
  const v = Math.floor(Math.abs(n));
  const sign = n < 0 ? '-' : '';
  if (v < 10_000) return sign + String(v).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  const units: [number, string][] = [
    [1_000_000_000, 'B'],
    [1_000_000, 'M'],
    [1_000, 'K'],
  ];
  for (const [size, suffix] of units) {
    if (v >= size) {
      const x = v / size;
      const text =
        x >= 100 ? String(Math.floor(x)) : (Math.floor(x * 10) / 10).toFixed(1).replace(/\.0$/, '');
      return `${sign}${text.replace('.', ',')}${suffix}`;
    }
  }
  return sign + String(v);
}

/** Полное число с разделителями — для aria-label и подсказок. */
export const formatFull = (n: number): string =>
  String(Math.floor(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
