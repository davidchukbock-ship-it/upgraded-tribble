import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { useAuth } from '../store/auth';
import { useClock } from '../store/clock';
import { apiError, installFakeApi, json, makeAuth } from '../test-utils/fake-api';
import { ApiError, apiFetch, hasSessionHint, readCookie, refreshSession } from './api';

function setCookie(value: string) {
  document.cookie = value;
}

beforeEach(() => {
  useAuth.getState().clear();
  useClock.setState({ offsetMs: 0 });
  setCookie('tc_csrf=csrf-123; path=/');
});
afterEach(() => {
  vi.unstubAllGlobals();
  setCookie('tc_csrf=; path=/; max-age=0');
});

describe('cookie-помощники', () => {
  it('читает cookie и определяет признак сессии', () => {
    expect(readCookie('tc_csrf')).toBe('csrf-123');
    expect(hasSessionHint()).toBe(true);
    setCookie('tc_csrf=; path=/; max-age=0');
    expect(hasSessionHint()).toBe(false);
  });
});

describe('apiFetch', () => {
  it('подставляет Bearer и JSON-тело, синхронизирует серверные часы', async () => {
    useAuth.getState().setSession(makeAuth());
    const { calls } = installFakeApi({
      'PATCH /api/profile': () =>
        json(200, { ok: true }, { 'X-Server-Time': '2026-01-01T00:01:00.000Z' }),
    });
    const before = Date.now();
    await apiFetch('/api/profile', { method: 'PATCH', body: { crest: 'wolf' } });
    expect(calls[0]?.headers['Authorization']).toBe('Bearer access-1');
    expect(calls[0]?.headers['Content-Type']).toBe('application/json');
    expect(calls[0]?.body).toEqual({ crest: 'wolf' });
    // смещение = серверное время − локальное (тестовые часы «в прошлом» → отрицательное)
    expect(useClock.getState().offsetMs).toBeLessThan(before);
    expect(useClock.getState().now()).toBeCloseTo(Date.parse('2026-01-01T00:01:00.000Z'), -3);
  });

  it('anonymous: не отправляет токен', async () => {
    useAuth.getState().setSession(makeAuth());
    const { calls } = installFakeApi({ 'POST /api/auth/login': () => json(200, {}) });
    await apiFetch('/api/auth/login', { method: 'POST', body: {}, anonymous: true });
    expect(calls[0]?.headers['Authorization']).toBeUndefined();
  });

  it('разбирает ошибку API в ApiError с кодом, статусом и деталями', async () => {
    installFakeApi({
      'GET /x': () => apiError(429, 'ERR_RATE_LIMITED', { retryAfterSeconds: 30 }),
    });
    const err = await apiFetch('/x').catch((e: unknown) => e);
    expect(err).toBeInstanceOf(ApiError);
    expect(err).toMatchObject({
      code: 'ERR_RATE_LIMITED',
      status: 429,
      details: { retryAfterSeconds: 30 },
      requestId: 'req-1',
    });
  });

  it('не-JSON ответ об ошибке → ERR_INTERNAL; сеть недоступна → ERR_NETWORK', async () => {
    installFakeApi({ 'GET /html': () => new Response('<html>502</html>', { status: 502 }) });
    await expect(apiFetch('/html')).rejects.toMatchObject({ code: 'ERR_INTERNAL', status: 502 });
    vi.stubGlobal('fetch', vi.fn().mockRejectedValue(new TypeError('Failed to fetch')));
    await expect(apiFetch('/x')).rejects.toMatchObject({ code: 'ERR_NETWORK', status: 0 });
  });

  it('204 без тела возвращает undefined', async () => {
    installFakeApi({ 'POST /api/auth/logout': () => json(204, null) });
    await expect(apiFetch('/api/auth/logout', { method: 'POST' })).resolves.toBeUndefined();
  });
});

describe('обновление токена', () => {
  it('401 → refresh (cookie + CSRF-заголовок) → повтор запроса с новым токеном', async () => {
    useAuth.getState().setSession(makeAuth({ accessToken: 'old' }));
    let attempt = 0;
    const { calls } = installFakeApi({
      'GET /api/auth/me': (c) =>
        c.headers['Authorization'] === 'Bearer old'
          ? apiError(401, 'ERR_UNAUTHORIZED')
          : json(200, { fresh: ++attempt }),
      'POST /api/auth/refresh': () => json(200, makeAuth({ accessToken: 'new' })),
    });
    const res = await apiFetch<{ fresh: number }>('/api/auth/me');
    expect(res.fresh).toBe(1);
    const refresh = calls.find((c) => c.path === '/api/auth/refresh')!;
    expect(refresh.headers['X-CSRF-Token']).toBe('csrf-123');
    expect(refresh.headers['Authorization']).toBeUndefined();
    expect(useAuth.getState().accessToken).toBe('new');
    expect(calls.filter((c) => c.path === '/api/auth/me')).toHaveLength(2); // ровно один повтор
  });

  it('параллельные 401 делят один refresh (иначе это выглядело бы как кража токена)', async () => {
    useAuth.getState().setSession(makeAuth({ accessToken: 'old' }));
    const { calls } = installFakeApi({
      'GET /a': (c) =>
        c.headers['Authorization'] === 'Bearer new'
          ? json(200, 'a')
          : apiError(401, 'ERR_UNAUTHORIZED'),
      'GET /b': (c) =>
        c.headers['Authorization'] === 'Bearer new'
          ? json(200, 'b')
          : apiError(401, 'ERR_UNAUTHORIZED'),
      'GET /c': (c) =>
        c.headers['Authorization'] === 'Bearer new'
          ? json(200, 'c')
          : apiError(401, 'ERR_UNAUTHORIZED'),
      'POST /api/auth/refresh': async () => {
        await new Promise((r) => setTimeout(r, 20));
        return json(200, makeAuth({ accessToken: 'new' }));
      },
    });
    const out = await Promise.all([apiFetch('/a'), apiFetch('/b'), apiFetch('/c')]);
    expect(out).toEqual(['a', 'b', 'c']);
    expect(calls.filter((c) => c.path === '/api/auth/refresh')).toHaveLength(1);
  });

  it('refresh не удался → сессия сброшена, ошибка уходит вызывающему, без циклов', async () => {
    useAuth.getState().setSession(makeAuth({ accessToken: 'old' }));
    const { calls } = installFakeApi({
      'GET /api/auth/me': () => apiError(401, 'ERR_UNAUTHORIZED'),
      'POST /api/auth/refresh': () => apiError(401, 'ERR_UNAUTHORIZED'),
    });
    await expect(apiFetch('/api/auth/me')).rejects.toMatchObject({ status: 401 });
    expect(useAuth.getState().status).toBe('anonymous');
    expect(useAuth.getState().accessToken).toBeNull();
    expect(calls).toHaveLength(2);
  });

  it('временный сбой refresh (429, 5xx, нет связи) не разлогинивает', async () => {
    for (const fail of [
      () => apiError(429, 'ERR_RATE_LIMITED'),
      () => apiError(503, 'ERR_INTERNAL'),
    ]) {
      useAuth.getState().setSession(makeAuth({ accessToken: 'old' }));
      installFakeApi({
        'GET /api/auth/me': () => apiError(401, 'ERR_UNAUTHORIZED'),
        'POST /api/auth/refresh': fail,
      });
      await expect(apiFetch('/api/auth/me')).rejects.toBeInstanceOf(ApiError);
      expect(useAuth.getState().status).toBe('authenticated');
      vi.unstubAllGlobals();
    }
  });

  it('повторный 401 после успешного refresh не зацикливается', async () => {
    useAuth.getState().setSession(makeAuth({ accessToken: 'old' }));
    const { calls } = installFakeApi({
      'GET /x': () => apiError(401, 'ERR_UNAUTHORIZED'),
      'POST /api/auth/refresh': () => json(200, makeAuth({ accessToken: 'new' })),
    });
    await expect(apiFetch('/x')).rejects.toMatchObject({ status: 401 });
    expect(calls.filter((c) => c.path === '/x')).toHaveLength(2);
  });

  it('401 у анонимного запроса (неверный пароль) не запускает refresh', async () => {
    const { calls } = installFakeApi({
      'POST /api/auth/login': () => apiError(401, 'ERR_INVALID_CREDENTIALS'),
    });
    await expect(
      apiFetch('/api/auth/login', { method: 'POST', body: {}, anonymous: true }),
    ).rejects.toMatchObject({
      code: 'ERR_INVALID_CREDENTIALS',
    });
    expect(calls).toHaveLength(1);
  });

  it('refreshSession сохраняет пользователя и токен', async () => {
    installFakeApi({
      'POST /api/auth/refresh': () => json(200, makeAuth({ accessToken: 'fresh' })),
    });
    await refreshSession();
    expect(useAuth.getState()).toMatchObject({ status: 'authenticated', accessToken: 'fresh' });
    expect(useAuth.getState().user?.nickname).toBe('Артур');
  });
});
