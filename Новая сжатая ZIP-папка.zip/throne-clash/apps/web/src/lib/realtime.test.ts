import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { RealtimeClient } from './realtime';
import { asWebSocket, FakeSocket } from '../test-utils/fake-socket';

let token: string | null = 't1';
const events: string[] = [];
const handlers = () => ({
  getToken: () => token,
  onOpen: () => events.push('open'),
  onClose: () => events.push('close'),
  onMessage: (m: { type: string }) => events.push(`msg:${m.type}`),
});
const make = () => new RealtimeClient({ url: 'ws://x/ws', WebSocketImpl: asWebSocket }, handlers());

beforeEach(() => {
  vi.useFakeTimers();
  FakeSocket.reset();
  events.length = 0;
  token = 't1';
});
afterEach(() => vi.useRealTimers());

describe('RealtimeClient', () => {
  it('после открытия аутентифицируется токеном; готов только после ready', () => {
    const c = make();
    c.start();
    expect(c.send('world', 'hi')).toBe(false);
    FakeSocket.last.open();
    expect(FakeSocket.last.sent).toEqual([{ type: 'auth', token: 't1' }]);
    expect(c.isReady).toBe(false);
    expect(c.send('world', 'hi')).toBe(false); // ещё не ready
    FakeSocket.last.receive({ type: 'ready', userId: 'u', online: 3 });
    expect(c.isReady).toBe(true);
    expect(events).toEqual(['open', 'msg:ready']);
    expect(c.send('world', 'привет')).toBe(true);
    expect(FakeSocket.last.sent[1]).toEqual({
      type: 'chat.send',
      channel: 'world',
      text: 'привет',
    });
  });

  it('без токена не аутентифицируется и закрывает соединение', () => {
    token = null;
    const c = make();
    c.start();
    FakeSocket.last.open();
    expect(FakeSocket.last.sent).toEqual([]);
    expect(FakeSocket.last.readyState).toBe(3);
    c.stop();
  });

  it('обрыв → переподключение с нарастающей паузой 1, 2, 4 … секунд; успешный ready сбрасывает паузу', () => {
    const c = make();
    c.start();
    FakeSocket.last.close();
    expect(FakeSocket.instances).toHaveLength(1);
    vi.advanceTimersByTime(999);
    expect(FakeSocket.instances).toHaveLength(1);
    vi.advanceTimersByTime(1);
    expect(FakeSocket.instances).toHaveLength(2);
    FakeSocket.last.close();
    vi.advanceTimersByTime(1999);
    expect(FakeSocket.instances).toHaveLength(2);
    vi.advanceTimersByTime(1);
    expect(FakeSocket.instances).toHaveLength(3);

    FakeSocket.last.open();
    FakeSocket.last.receive({ type: 'ready', userId: 'u', online: 1 });
    FakeSocket.last.close();
    expect(events).toContain('close');
    vi.advanceTimersByTime(1000); // пауза снова 1 с
    expect(FakeSocket.instances).toHaveLength(4);
    c.stop();
  });

  it('пауза не растёт выше 30 секунд', () => {
    const c = make();
    c.start();
    for (let i = 0; i < 10; i++) {
      FakeSocket.last.close();
      vi.advanceTimersByTime(30_000);
    }
    const before = FakeSocket.instances.length;
    FakeSocket.last.close();
    vi.advanceTimersByTime(29_999);
    expect(FakeSocket.instances).toHaveLength(before);
    vi.advanceTimersByTime(1);
    expect(FakeSocket.instances).toHaveLength(before + 1);
    c.stop();
  });

  it('stop закрывает соединение и не даёт переподключаться', () => {
    const c = make();
    c.start();
    FakeSocket.last.open();
    c.stop();
    vi.advanceTimersByTime(60_000);
    expect(FakeSocket.instances).toHaveLength(1);
    expect(c.send('world', 'x')).toBe(false);
  });

  it('reauth шлёт свежий токен по открытому соединению', () => {
    const c = make();
    c.start();
    FakeSocket.last.open();
    token = 't2';
    c.reauth();
    expect(FakeSocket.last.sent.at(-1)).toEqual({ type: 'auth', token: 't2' });
    c.stop();
  });

  it('мусор от сервера игнорируется', () => {
    const c = make();
    c.start();
    FakeSocket.last.open();
    FakeSocket.last.onmessage?.({ data: 'не json' } as MessageEvent);
    expect(events).toEqual([]);
    c.stop();
  });
});
