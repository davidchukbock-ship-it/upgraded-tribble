import type { NotificationDto, WsClientMessage, WsServerMessage } from '@tc/shared';

export interface RealtimeHandlers {
  getToken: () => string | null;
  onOpen: () => void;
  onClose: () => void;
  onMessage: (msg: WsServerMessage) => void;
}

export interface RealtimeOptions {
  url: string;
  /** Подмена конструктора WebSocket — в тестах. */
  WebSocketImpl?: typeof WebSocket;
  minDelayMs?: number;
  maxDelayMs?: number;
}

/**
 * Клиент WebSocket: аутентификация первым сообщением, автоматическое переподключение
 * с нарастающей паузой (1 → 30 с), повторная аутентификация при смене токена.
 */
export class RealtimeClient {
  private ws: WebSocket | null = null;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private delay: number;
  private stopped = true;
  private ready = false;

  constructor(
    private readonly opts: RealtimeOptions,
    private readonly h: RealtimeHandlers,
  ) {
    this.delay = opts.minDelayMs ?? 1000;
  }

  get isReady(): boolean {
    return this.ready;
  }

  start(): void {
    if (!this.stopped) return;
    this.stopped = false;
    this.connect();
  }

  stop(): void {
    this.stopped = true;
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    this.ready = false;
    this.ws?.close();
    this.ws = null;
  }

  /** Токен обновился — сообщаем серверу, не разрывая соединение. */
  reauth(): void {
    const token = this.h.getToken();
    if (this.ws?.readyState === 1 && token) this.raw({ type: 'auth', token });
  }

  /** Отправка сообщения чата; false — соединения нет, нужен запасной путь через HTTP. */
  send(channel: string, text: string): boolean {
    if (!this.ready || this.ws?.readyState !== 1) return false;
    this.raw({ type: 'chat.send', channel, text });
    return true;
  }

  private raw(msg: WsClientMessage): void {
    this.ws?.send(JSON.stringify(msg));
  }

  private connect(): void {
    const Impl = this.opts.WebSocketImpl ?? WebSocket;
    const ws = new Impl(this.opts.url);
    this.ws = ws;
    ws.onopen = () => {
      const token = this.h.getToken();
      if (!token) return ws.close();
      this.raw({ type: 'auth', token });
    };
    ws.onmessage = (ev: MessageEvent) => {
      let msg: WsServerMessage;
      try {
        msg = JSON.parse(String(ev.data)) as WsServerMessage;
      } catch {
        return;
      }
      if (msg.type === 'ready') {
        this.ready = true;
        this.delay = this.opts.minDelayMs ?? 1000;
        this.h.onOpen();
      }
      this.h.onMessage(msg);
    };
    ws.onclose = () => {
      const wasReady = this.ready;
      this.ready = false;
      if (this.ws === ws) this.ws = null;
      if (wasReady) this.h.onClose();
      if (this.stopped) return;
      this.timer = setTimeout(() => this.connect(), this.delay);
      this.delay = Math.min(this.delay * 2, this.opts.maxDelayMs ?? 30_000);
    };
    ws.onerror = () => ws.close();
  }
}

export const isBuildKind = (n: Pick<NotificationDto, 'kind'>): boolean =>
  n.kind === 'build.done' ||
  n.kind === 'train.done' ||
  n.kind === 'research.done' ||
  n.kind === 'march.returned' ||
  n.kind === 'march.attacked';
