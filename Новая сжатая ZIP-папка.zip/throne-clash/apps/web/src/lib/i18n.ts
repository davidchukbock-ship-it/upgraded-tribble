import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import { LOCALES, type Locale } from '@tc/shared';
import en from '../locales/en.json';
import ru from '../locales/ru.json';
import uk from '../locales/uk.json';

const STORAGE_KEY = 'tc.locale';

export function detectLocale(): Locale {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved && (LOCALES as readonly string[]).includes(saved)) return saved as Locale;
  } catch {
    /* localStorage недоступен (приватный режим) */
  }
  return 'ru'; // язык по умолчанию — русский
}

export function setLocale(locale: Locale): void {
  void i18n.changeLanguage(locale);
  document.documentElement.lang = locale;
  try {
    localStorage.setItem(STORAGE_KEY, locale);
  } catch {
    /* не критично */
  }
}

export async function initI18n(locale: Locale = detectLocale()): Promise<typeof i18n> {
  if (!i18n.isInitialized) {
    await i18n.use(initReactI18next).init({
      resources: { ru: { translation: ru }, uk: { translation: uk }, en: { translation: en } },
      lng: locale,
      fallbackLng: 'ru',
      interpolation: { escapeValue: false }, // React сам экранирует
      returnNull: false,
    });
  } else {
    await i18n.changeLanguage(locale);
  }
  document.documentElement.lang = locale;
  return i18n;
}

export { i18n };
