import type { AuthResponse } from '@tc/shared';
import { useAuth } from '../store/auth';
import { useClock } from '../store/clock';

/** Ошибка API: код ERR_* стабилен, текст берётся из локализации по коду (D-12). */
export class ApiError extends Error {
  constructor(
    readonly code: string,
    readonly status: number,
    readonly details?: unknown,
    readonly requestId?: string,
  ) {
    super(code);
    this.name = 'ApiError';
  }
}

const BASE: string = import.meta.env.VITE_API_URL ?? '';
const CSRF_COOKIE = 'tc_csrf';

export function readCookie(name: string): string | undefined {
  const match = document.cookie.split('; ').find((c) => c.startsWith(`${name}=`));
  return match ? decodeURIComponent(match.slice(name.length + 1)) : undefined;
}

/** Есть ли признак сессии (CSRF-cookie читаем из JS, refresh-cookie — нет). */
export const hasSessionHint = (): boolean => readCookie(CSRF_COOKIE) !== undefined;

interface RequestOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  body?: unknown;
  /** Не подставлять Bearer (register/login/guest/refresh). */
  anonymous?: boolean;
  /** 401 не означает истёкший токен (например, нет сессии режима бога): не обновлять сессию и не повторять. */
  noRefresh?: boolean;
  /** Добавить X-CSRF-Token из cookie (refresh, logout). */
  csrf?: boolean;
  /** Дополнительные заголовки (Idempotency-Key). */
  headers?: Record<string, string>;
}

async function parseError(res: Response): Promise<ApiError> {
  try {
    const data = (await res.json()) as {
      error?: { code?: string; details?: unknown };
      requestId?: string;
    };
    return new ApiError(
      data.error?.code ?? 'ERR_INTERNAL',
      res.status,
      data.error?.details,
      data.requestId,
    );
  } catch {
    return new ApiError('ERR_INTERNAL', res.status);
  }
}

async function send<T>(path: string, opts: RequestOptions, token: string | null): Promise<T> {
  const headers: Record<string, string> = { ...opts.headers };
  if (opts.body !== undefined) headers['Content-Type'] = 'application/json';
  if (token && !opts.anonymous) headers['Authorization'] = `Bearer ${token}`;
  if (opts.csrf) {
    const csrf = readCookie(CSRF_COOKIE);
    if (csrf) headers['X-CSRF-Token'] = csrf;
  }

  let res: Response;
  try {
    res = await fetch(`${BASE}${path}`, {
      method: opts.method ?? 'GET',
      headers,
      credentials: 'include',
      ...(opts.body !== undefined ? { body: JSON.stringify(opts.body) } : {}),
    });
  } catch {
    throw new ApiError('ERR_NETWORK', 0);
  }

  // Часы клиента подстраиваются под сервер по каждому ответу (D-03)
  const serverTime = res.headers.get('X-Server-Time');
  if (serverTime) useClock.getState().syncFromServer(serverTime);

  if (!res.ok) throw await parseError(res);
  if (res.status === 204) return undefined as T;
  return (await res.json()) as T;
}

/** Временный сбой: лимит запросов, ошибка сервера, нет связи. */
export const isTransient = (err: unknown): boolean =>
  err instanceof ApiError && (err.status === 0 || err.status === 429 || err.status >= 500);

let refreshInFlight: Promise<string> | null = null;

/**
 * Обновляет access-токен по refresh-cookie. Одновременные вызовы делят один запрос:
 * иначе второй запрос с тем же refresh-токеном выглядел бы как его повторное использование.
 */
export function refreshSession(): Promise<string> {
  refreshInFlight ??= send<AuthResponse>(
    '/api/auth/refresh',
    { method: 'POST', anonymous: true, csrf: true },
    null,
  )
    .then((res) => {
      useAuth.getState().setSession(res);
      return res.accessToken;
    })
    .catch((err: unknown) => {
      // Сессию сбрасываем, только если сервер её отверг. Лимит запросов, сбой сервера или обрыв связи
      // не означают, что вход недействителен: refresh-cookie цела, повтор позже сработает
      if (!isTransient(err)) useAuth.getState().clear();
      throw err;
    })
    .finally(() => {
      refreshInFlight = null;
    });
  return refreshInFlight;
}

export async function apiFetch<T>(path: string, opts: RequestOptions = {}): Promise<T> {
  try {
    return await send<T>(path, opts, useAuth.getState().accessToken);
  } catch (err) {
    const canRetry =
      err instanceof ApiError &&
      err.status === 401 &&
      !opts.anonymous &&
      !opts.noRefresh &&
      useAuth.getState().status === 'authenticated';
    if (!canRetry) throw err;
    // access-токен истёк: обновляем и повторяем запрос один раз
    const fresh = await refreshSession();
    return send<T>(path, opts, fresh);
  }
}
