import { describe, expect, it } from 'vitest';
import { formatFull, formatNumber } from './format';

describe('formatNumber', () => {
  it.each([
    [0, '0'],
    [999, '999'],
    [9_999, '9\u00A0999'],
    [10_000, '10K'],
    [12_345, '12,3K'],
    [999_999, '999K'],
    [1_250_000, '1,2M'],
    [3_000_000_000, '3B'],
    [-1500, '-1\u00A0500'],
  ])('%d → %s', (n, expected) => expect(formatNumber(n)).toBe(expected));
});

describe('formatFull', () => {
  it('разделяет тысячи пробелами и отбрасывает дробную часть', () => {
    expect(formatFull(1234567.9)).toBe('1\u00A0234\u00A0567');
  });
});
