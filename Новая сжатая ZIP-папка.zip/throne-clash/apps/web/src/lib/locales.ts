import { LOCALES, type Locale } from '@tc/shared';

/** Название языка на нём самом. */
export const LOCALE_NAMES: Readonly<Record<Locale, string>> = {
  ru: 'Русский',
  uk: 'Українська',
  en: 'English',
};

/** Приводит код языка i18next («uk», «uk-UA», …) к поддерживаемому; по умолчанию русский. */
export function asLocale(lang: string | undefined): Locale {
  const base = (lang ?? '').slice(0, 2).toLowerCase();
  return (LOCALES as readonly string[]).includes(base) ? (base as Locale) : 'ru';
}

const DATE_LOCALES: Readonly<Record<Locale, string>> = { ru: 'ru-RU', uk: 'uk-UA', en: 'en-GB' };

/** Локаль для Intl и toLocaleString. */
export const dateLocale = (lang: string | undefined): string => DATE_LOCALES[asLocale(lang)];
