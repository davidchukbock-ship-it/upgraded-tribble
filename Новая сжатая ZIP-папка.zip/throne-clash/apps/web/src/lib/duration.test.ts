import { beforeAll, describe, expect, it } from 'vitest';
import { formatDurationT } from './duration';
import { i18n, initI18n } from './i18n';

beforeAll(async () => {
  await initI18n('ru');
});

describe('formatDurationT', () => {
  it('русские единицы и пропуск нулевых разрядов', () => {
    const t = i18n.t.bind(i18n);
    expect(formatDurationT(t, 0)).toBe('0с');
    expect(formatDurationT(t, 59)).toBe('59с');
    expect(formatDurationT(t, 3600)).toBe('1ч');
    expect(formatDurationT(t, 90061)).toBe('1д 1ч 1м 1с');
    expect(formatDurationT(t, -5)).toBe('0с');
  });
  it('английские единицы', async () => {
    await i18n.changeLanguage('en');
    expect(formatDurationT(i18n.t.bind(i18n), 3725)).toBe('1h 2m 5s');
    await i18n.changeLanguage('ru');
  });
});
