import type { TFunction } from 'i18next';

/** «1д 2ч 3м 4с» на языке интерфейса; нули старших разрядов пропускаются, 0 → «0с». */
export function formatDurationT(t: TFunction, totalSeconds: number): string {
  const s = Math.max(0, Math.floor(totalSeconds));
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const parts = [
    d && `${d}${t('time.d')}`,
    h && `${h}${t('time.h')}`,
    m && `${m}${t('time.m')}`,
    sec && `${sec}${t('time.s')}`,
  ].filter(Boolean);
  return parts.length > 0 ? parts.join(' ') : `0${t('time.s')}`;
}
