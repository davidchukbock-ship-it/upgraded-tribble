import { crestBase } from '@tc/shared';
import { cn } from '../lib/cn';

/** Гербы игроков — собственные векторные щиты. Ключи совпадают с DEFAULT_CRESTS в shared. */
const SHIELD =
  'M12 2 3.500 5v6.500c0 4.800 3.300 8.700 8.500 10.500 5.200-1.800 8.500-5.700 8.500-10.500V5Z';

type Layer = { d: string; fill: 'ink' | 'field' };
const EMBLEM: Record<string, { field: string; ink: string; layers: Layer[] }> = {
  // Лев: грива-звезда вокруг морды
  lion: {
    field: '#A61E1E',
    ink: '#F2CF6B',
    layers: [
      {
        d: 'M12 4.4L13.4 6.4L15.6 5.4L15.8 7.8L18.2 8L17.2 10.2L19.2 11.6L17.2 13L18.2 15.2L15.8 15.4L15.6 17.8L13.4 16.8L12 18.8L10.6 16.8L8.4 17.8L8.2 15.4L5.8 15.2L6.8 13L4.8 11.6L6.8 10.2L5.8 8L8.2 7.8L8.4 5.4L10.6 6.4Z',
        fill: 'ink',
      },
      { d: 'M8.6 11.6a3.4 3.4 0 1 0 6.8 0a3.4 3.4 0 1 0-6.8 0Z', fill: 'field' },
      { d: 'M10.1 10.6h1.2v1.1h-1.2ZM12.7 10.6h1.2v1.1h-1.2ZM11.2 12.5h1.6L12 13.7Z', fill: 'ink' },
    ],
  },
  // Волк: острые уши и морда
  wolf: {
    field: '#4F4841',
    ink: '#E8D6A8',
    layers: [
      {
        d: 'M7 6.500 9 9.500h6l2-3 .5 5.500-2.500 5L12 18l-3 2-2.500-5Zm2.300 5a.8.8 0 1 0 0 1.600.8.8 0 0 0 0-1.600Zm5.400 0a.8.8 0 1 0 0 1.600.8.8 0 0 0 0-1.600Z',
        fill: 'ink',
      },
    ],
  },
  // Орёл: раскинутые крылья
  eagle: {
    field: '#2F5D8C',
    ink: '#F2CF6B',
    layers: [
      {
        d: 'M12 6.500 10.500 9 5 7l1.500 4L4.500 13 10 13.500 12 18l2-4.500 5.500-.5-2-2L19 7l-5.500 2Z',
        fill: 'ink',
      },
    ],
  },
  // Олень: ветвистые рога
  stag: {
    field: '#3D7E21',
    ink: '#E8D6A8',
    layers: [
      {
        d: 'M8 5.500v4l-2-1.500v-2Zm8 0v4l2-1.500v-2Zm-6.500 3.500L12 12l2.500-3L16 13l-2 1v4l-2 1-2-1v-4l-2-1Z',
        fill: 'ink',
      },
    ],
  },
};

/** Премиум-гербы (магазин): тот же щит и рисунок, другая палитра. */
const PALETTE: Record<string, { field: string; ink: string }> = {
  'lion-gold': { field: '#C9A227', ink: '#3B1F0B' },
  'lion-azure': { field: '#2B6CB0', ink: '#F5E6B3' },
  'lion-ink': { field: '#1A1A22', ink: '#E8D6A8' },
  'wolf-night': { field: '#1B2340', ink: '#B8C4E8' },
  'wolf-frost': { field: '#9CC7E6', ink: '#1D2B3A' },
  'eagle-gold': { field: '#B8891A', ink: '#FFF3C4' },
  'eagle-crimson': { field: '#7A1230', ink: '#F2CF6B' },
  'eagle-emerald': { field: '#0F6B4A', ink: '#F2CF6B' },
  'stag-royal': { field: '#5B2A86', ink: '#F2CF6B' },
  'stag-autumn': { field: '#B5541A', ink: '#F5E6B3' },
};

interface CrestProps {
  crest: string;
  size?: number;
  className?: string;
  /** Если задан — герб озвучивается, иначе декоративный. */
  title?: string;
}

export function Crest({ crest, size = 32, className, title }: CrestProps) {
  const base = EMBLEM[crestBase(crest)] ?? EMBLEM['lion']!;
  const e = { ...base, ...PALETTE[crest] };
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      className={cn('shrink-0', className)}
      role={title ? 'img' : undefined}
      aria-label={title}
      aria-hidden={title ? undefined : true}
      focusable="false"
    >
      <path d={SHIELD} fill={e.field} stroke="#24140B" strokeWidth="1.2" strokeLinejoin="round" />
      <path
        d={SHIELD}
        fill="none"
        stroke={e.ink}
        strokeOpacity="0.55"
        strokeWidth="0.6"
        transform="translate(0 0) scale(.9) translate(1.3 1.2)"
      />
      {e.layers.map((l) => (
        <path key={l.d} d={l.d} fill={l.fill === 'ink' ? e.ink : e.field} fillRule="evenodd" />
      ))}
    </svg>
  );
}
