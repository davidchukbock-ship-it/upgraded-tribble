import type { ReactNode } from 'react';
import { OUTLINE, PAL, darken } from './color';

/**
 * Цветные значки разделов игры (меню, кнопки): круглая «медаль» цвета темы и белый/золотой знак.
 * Нарисованы кодом, сторонних значков нет (D-63).
 */
export type NavArtName =
  | 'castle'
  | 'map'
  | 'army'
  | 'quests'
  | 'shop'
  | 'donate'
  | 'reports'
  | 'chat'
  | 'notifications'
  | 'academy'
  | 'hero'
  | 'chests'
  | 'guild'
  | 'leagues'
  | 'profile'
  | 'settings'
  | 'uikit'
  | 'credits'
  | 'admin'
  | 'adventure'
  | 'login'
  | 'register';

const S = {
  stroke: OUTLINE,
  strokeWidth: 1.2,
  strokeLinejoin: 'round',
  strokeLinecap: 'round',
} as const;

function Medal({ color, children }: { color: string; children: ReactNode }) {
  return (
    <>
      <circle cx="16" cy="16" r="15" fill={darken(color, 0.4)} stroke={OUTLINE} strokeWidth="1.6" />
      <circle cx="16" cy="16" r="12.6" fill={color} />
      <path d="M5 13a11.6 11.6 0 0 1 22 0c-4-4-18-4-22 0Z" fill="#fff" opacity=".26" />
      {children}
    </>
  );
}

const C = {
  gold: '#d9a72a',
  green: '#4c9a2a',
  red: '#b9473a',
  blue: '#3f74c4',
  purple: '#8a5fd0',
  teal: '#2a9d9a',
  orange: '#e0782f',
  gray: '#6f7c86',
  cyan: '#39a9e0',
};

const GLYPH: Record<NavArtName, () => ReactNode> = {
  castle: () => (
    <Medal color={C.gray}>
      <path d="M8 22V12h2.4v2h2v-2h2.4v2h2v-2H19v2h2V12h2v10Z" fill="#f3efe6" {...S} />
      <path d="M13.500 22v-4a2.500 2.500 0 0 1 5 0v4Z" fill={PAL.woodDark} {...S} />
    </Medal>
  ),
  map: () => (
    <Medal color={C.green}>
      <path d="M8 10l5-2 6 2 5-2v14l-5 2-6-2-5 2Z" fill="#f3e6b8" {...S} />
      <path d="M13 8v14M19 10v14" stroke={OUTLINE} strokeWidth="1" />
      <path
        d="M20.500 15l2 2M22.500 15l-2 2"
        stroke={C.red}
        strokeWidth="1.800"
        strokeLinecap="round"
      />
    </Medal>
  ),
  army: () => (
    <Medal color={C.red}>
      <path
        d="M9 22 21 9M23 22 11 9"
        stroke={PAL.steel}
        strokeWidth="2.800"
        strokeLinecap="round"
      />
      <path
        d="M9 22 21 9M23 22 11 9"
        stroke={OUTLINE}
        strokeWidth=".8"
        strokeLinecap="round"
        opacity=".5"
      />
      <circle cx="16" cy="16" r="2.200" fill={PAL.gold} {...S} />
    </Medal>
  ),
  quests: () => (
    <Medal color={C.orange}>
      <path d="M10 8h11a1.500 1.500 0 0 1 1.500 1.500V22a2 2 0 0 1-2 2H10Z" fill="#f3e6b8" {...S} />
      <path d="M10 8a2 2 0 0 0-2 2v1h4V9a1 1 0 0 0-2-1Z" fill={PAL.wood} {...S} />
      <path
        d="M13 13h7M13 16h7M13 19h5"
        stroke={OUTLINE}
        strokeWidth="1.200"
        strokeLinecap="round"
      />
    </Medal>
  ),
  shop: () => (
    <Medal color={C.teal}>
      <path d="M8 13 9.500 8h13L24 13Z" fill={C.red} {...S} />
      <path
        d="M8 13a2.700 2.700 0 0 0 5.300 0 2.700 2.700 0 0 0 5.400 0 2.700 2.700 0 0 0 5.300 0Z"
        fill="#fff"
        {...S}
      />
      <path d="M9.500 15v8h13v-8" fill="#f3e6b8" {...S} />
      <rect x="14" y="18" width="4" height="5" fill={PAL.woodDark} {...S} />
    </Medal>
  ),
  donate: () => (
    <Medal color={C.cyan}>
      <path d="M16 7 8 14l8 11 8-11Z" fill={PAL.gem} {...S} />
      <path
        d="M8 14h16M12 14l4-7 4 7M12 14l4 11 4-11"
        fill="none"
        stroke="#fff"
        strokeWidth="1"
        opacity=".8"
      />
    </Medal>
  ),
  reports: () => (
    <Medal color={C.gray}>
      <path d="M10 8h9l4 4v12H10Z" fill="#f3e6b8" {...S} />
      <path d="M19 8v4h4" fill="none" stroke={OUTLINE} strokeWidth="1.200" />
      <path d="M13 17 19 23M19 17 13 23" stroke={C.red} strokeWidth="2" strokeLinecap="round" />
    </Medal>
  ),
  chat: () => (
    <Medal color={C.blue}>
      <path
        d="M7 10a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H15l-5 4v-4H9a2 2 0 0 1-2-2Z"
        fill="#fff"
        {...S}
      />
      <path d="M11 13h10M11 16.500h6" stroke={C.blue} strokeWidth="1.600" strokeLinecap="round" />
    </Medal>
  ),
  notifications: () => (
    <Medal color={C.gold}>
      <path d="M16 7a6 6 0 0 0-6 6v4l-2 3h16l-2-3v-4a6 6 0 0 0-6-6Z" fill="#fff3c2" {...S} />
      <path d="M13.500 22a2.500 2.500 0 0 0 5 0Z" fill={PAL.woodDark} {...S} />
    </Medal>
  ),
  academy: () => (
    <Medal color={C.purple}>
      <path d="M16 8 5 13l11 5 11-5Z" fill="#2a2a4a" {...S} />
      <path d="M10 16v5c0 2 12 2 12 0v-5l-6 2.800Z" fill="#3a3a66" {...S} />
      <path d="M26 14v7" stroke={PAL.gold} strokeWidth="1.600" strokeLinecap="round" />
    </Medal>
  ),
  hero: () => (
    <Medal color={C.gold}>
      <path
        d="M16 6l2.800 6 6.500.8-4.800 4.500 1.300 6.500L16 20.500 10.200 23.800l1.300-6.500-4.800-4.500L13.200 12Z"
        fill="#fff3c2"
        {...S}
      />
    </Medal>
  ),
  chests: () => (
    <Medal color={C.orange}>
      <path d="M8 14a4 4 0 0 1 4-4h8a4 4 0 0 1 4 4v2H8Z" fill={PAL.wood} {...S} />
      <rect x="8" y="16" width="16" height="8" rx="1" fill={PAL.woodDark} {...S} />
      <rect x="14.500" y="14.500" width="3" height="4.500" rx=".8" fill={PAL.gold} {...S} />
    </Medal>
  ),
  guild: () => (
    <Medal color={C.blue}>
      <path d="M16 6 8 9v6c0 5 3.500 8.500 8 10 4.500-1.500 8-5 8-10V9Z" fill="#f3efe6" {...S} />
      <path d="M16 9v14c-3.500-1.500-6-4.500-6-8V11Z" fill={C.blue} opacity=".85" />
      <path
        d="M16 12.500l1.200 2.400 2.600.3-1.900 1.800.5 2.600-2.400-1.300-2.400 1.300.5-2.600-1.900-1.800 2.600-.3Z"
        fill={PAL.gold}
      />
    </Medal>
  ),
  leagues: () => (
    <Medal color={C.gold}>
      <path d="M10 8h12v5a6 6 0 0 1-12 0Z" fill="#fff3c2" {...S} />
      <path
        d="M10 10H7c0 3 1.500 4.500 3.500 4.500M22 10h3c0 3-1.500 4.500-3.500 4.500"
        fill="none"
        stroke={OUTLINE}
        strokeWidth="1.200"
      />
      <path d="M16 19v3M12 24h8" stroke={OUTLINE} strokeWidth="2" strokeLinecap="round" />
    </Medal>
  ),
  profile: () => (
    <Medal color={C.teal}>
      <circle cx="16" cy="12.500" r="4" fill={PAL.skin} {...S} />
      <path d="M8 24c0-4.500 3.500-7 8-7s8 2.500 8 7Z" fill="#f3efe6" {...S} />
    </Medal>
  ),
  settings: () => (
    <Medal color={C.gray}>
      <path
        d="M14.500 7h3l.5 2.200 1.400.6 2-1.200 2.100 2.100-1.200 2 .6 1.400 2.200.5v3l-2.200.5-.6 1.400 1.200 2-2.100 2.100-2-1.200-1.400.6-.5 2.200h-3l-.5-2.200-1.400-.6-2 1.200-2.100-2.100 1.200-2-.6-1.400L6.800 17.500v-3l2.200-.5.6-1.400-1.200-2 2.100-2.100 2 1.200 1.400-.6Z"
        fill="#e8eef2"
        {...S}
      />
      <circle cx="16" cy="16" r="3.200" fill={C.gray} {...S} />
    </Medal>
  ),
  uikit: () => (
    <Medal color={C.purple}>
      <rect x="8" y="8" width="7" height="7" rx="1.500" fill="#fff" {...S} />
      <rect x="17" y="8" width="7" height="7" rx="1.500" fill={PAL.gold} {...S} />
      <rect x="8" y="17" width="7" height="7" rx="1.500" fill={PAL.gem} {...S} />
      <rect x="17" y="17" width="7" height="7" rx="1.500" fill={C.red} {...S} />
    </Medal>
  ),
  credits: () => (
    <Medal color={C.gray}>
      <circle cx="16" cy="16" r="8" fill="#fff" {...S} />
      <path
        d="M16 15v6M16 11.500v1.500"
        stroke={OUTLINE}
        strokeWidth="2.200"
        strokeLinecap="round"
      />
    </Medal>
  ),
  admin: () => (
    <Medal color={C.red}>
      <path d="M16 6l8 3v6c0 5-3.500 8-8 10-4.500-2-8-5-8-10V9Z" fill="#f3efe6" {...S} />
      <path
        d="M12.500 16l2.500 2.500 4.500-5"
        fill="none"
        stroke={C.red}
        strokeWidth="2.200"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </Medal>
  ),
  adventure: () => (
    <Medal color={C.orange}>
      <path d="M9 24V8" stroke={PAL.woodDark} strokeWidth="2.400" strokeLinecap="round" />
      <path d="M10 8h13l-3 4.500 3 4.500H10Z" fill={C.red} {...S} />
      <path d="M8 24h10" stroke={OUTLINE} strokeWidth="2" strokeLinecap="round" />
      <circle cx="22" cy="22" r="3" fill={PAL.gold} {...S} />
    </Medal>
  ),
  login: () => (
    <Medal color={C.green}>
      <path d="M11 8h10v16H11" fill="#f3e6b8" {...S} />
      <path
        d="M6 16h11M13.500 12.500 17 16l-3.500 3.500"
        fill="none"
        stroke={OUTLINE}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </Medal>
  ),
  register: () => (
    <Medal color={C.gold}>
      <path d="M16 8v16M8 16h16" stroke="#fff" strokeWidth="4" strokeLinecap="round" />
      <path
        d="M16 8v16M8 16h16"
        stroke={OUTLINE}
        strokeWidth="1"
        strokeLinecap="round"
        opacity=".5"
      />
    </Medal>
  ),
};

export function NavArt({
  name,
  size = 28,
  className,
}: {
  name: NavArtName;
  size?: number;
  className?: string;
}) {
  return (
    <svg
      viewBox="0 0 32 32"
      width={size}
      height={size}
      aria-hidden="true"
      focusable="false"
      className={`inline-block shrink-0 ${className ?? ''}`}
    >
      {GLYPH[name]()}
    </svg>
  );
}
