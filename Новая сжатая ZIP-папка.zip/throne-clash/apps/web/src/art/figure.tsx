import type { ReactNode } from 'react';
import { OUTLINE, PAL, darken, lighten } from './color';

/** Головные уборы и шлемы. */
export type Headgear =
  | 'none'
  | 'cap'
  | 'helm'
  | 'knight'
  | 'viking'
  | 'winged'
  | 'crest'
  | 'crown'
  | 'circlet'
  | 'hood'
  | 'hat'
  | 'wizard'
  | 'mask';
/** Оружие в правой руке. */
export type Weapon =
  | 'none'
  | 'sword'
  | 'greatsword'
  | 'flame'
  | 'dagger'
  | 'spear'
  | 'lance'
  | 'bow'
  | 'longbow'
  | 'crossbow'
  | 'staff'
  | 'wand'
  | 'axe'
  | 'club'
  | 'hammer'
  | 'flail'
  | 'torch';
/** Щит в левой руке. */
export type ShieldKind = 'none' | 'buckler' | 'round' | 'kite' | 'tower';
/** Доспех: определяет, как рисуется туловище. */
export type ArmorKind = 'cloth' | 'leather' | 'chain' | 'plate' | 'royal' | 'robe';

/** Описание человечка: из этих полей собираются солдаты, герой, жители и разбойники. */
export interface FigureSpec {
  skin: string;
  hair: string | null;
  outfit: string;
  trim: string;
  pants: string;
  armor?: ArmorKind;
  head: Headgear;
  headColor?: string;
  weapon: Weapon;
  shield: ShieldKind;
  shieldColor?: string;
  cape?: string | null;
  beard?: boolean;
  /** Плечи шире, фигура крупнее — для командиров и «тяжёлых» врагов. */
  bulk?: number;
  /** Клыки — для орков. */
  fangs?: boolean;
  /** Свечение вокруг (реликвия, легендарное оружие). */
  aura?: string | null;
  /** Наплечники (плиты). */
  pauldrons?: boolean;
  /** Длинные волосы (рисуются за головой). */
  longHair?: boolean;
}

/** Готовая анимация: включается атрибутом data-anim, стили — в index.css. */
export type FigureAnim = 'none' | 'idle' | 'walk' | 'attack' | 'cheer';

const S = {
  stroke: OUTLINE,
  strokeWidth: 1.6,
  strokeLinejoin: 'round',
  strokeLinecap: 'round',
} as const;
const S2 = { ...S, strokeWidth: 1.2 } as const;

function WeaponArt({ kind }: { kind: Weapon }): ReactNode {
  switch (kind) {
    case 'sword':
      return (
        <g>
          <rect x="45" y="20" width="4" height="29" rx="2" fill={PAL.steel} {...S} />
          <rect x="46.2" y="21" width="1" height="26" fill="#fff" opacity=".6" />
          <rect x="41" y="48" width="12" height="3.4" rx="1.7" fill={PAL.gold} {...S} />
          <rect x="45.2" y="51" width="3.6" height="6" rx="1.4" fill={PAL.woodDark} {...S} />
        </g>
      );
    case 'greatsword':
      return (
        <g>
          <path d="M44 48 44.500 8 47 2l2.500 6L50 48Z" fill={PAL.steel} {...S} />
          <path d="M47 4v44" stroke="#fff" strokeWidth="1" opacity=".55" />
          <rect x="39" y="47" width="16" height="4" rx="2" fill={PAL.gold} {...S} />
          <rect x="45.200" y="51" width="3.600" height="8" rx="1.400" fill={PAL.woodDark} {...S} />
          <circle cx="47" cy="61" r="2.200" fill={PAL.gold} {...S} strokeWidth="1" />
        </g>
      );
    case 'flame':
      return (
        <g>
          <path d="M40 4c4 5 2 8 4 10 1-3 3-4 3-8 2 3 6 6 3 12" fill="#ff8a1e" opacity=".85" />
          <rect x="45" y="12" width="4" height="37" rx="2" fill="#ffd27a" {...S} />
          <rect x="46.200" y="13" width="1" height="33" fill="#fff" opacity=".8" />
          <rect x="41" y="48" width="12" height="3.400" rx="1.700" fill={PAL.gold} {...S} />
          <rect x="45.200" y="51" width="3.600" height="6" rx="1.400" fill={PAL.red} {...S} />
        </g>
      );
    case 'dagger':
      return (
        <g>
          <path d="M45.500 50 47 32l1.500 18Z" fill={PAL.steel} {...S} />
          <rect
            x="43"
            y="49"
            width="8"
            height="2.600"
            rx="1.300"
            fill={PAL.goldDark}
            {...S}
            strokeWidth="1.200"
          />
          <rect
            x="46"
            y="51"
            width="2"
            height="4.500"
            rx="1"
            fill={PAL.woodDark}
            {...S}
            strokeWidth="1"
          />
        </g>
      );
    case 'spear':
      return (
        <g>
          <rect x="45.400" y="6" width="3" height="60" rx="1.500" fill={PAL.wood} {...S} />
          <path d="M46.900 0.500 51 10H42.800Z" fill={PAL.steel} {...S} />
        </g>
      );
    case 'lance':
      return (
        <g>
          <rect x="45.400" y="-2" width="3.200" height="66" rx="1.600" fill="#f3ead0" {...S} />
          <path d="M47 -8 51.500 4H42.500Z" fill={PAL.steel} {...S} />
          <path d="M48.500 6l9 3-9 4Z" fill={PAL.red} {...S} strokeWidth="1.200" />
        </g>
      );
    case 'bow':
    case 'longbow':
      return (
        <g>
          <path
            d={kind === 'bow' ? 'M44 14c14 10 14 34 0 44' : 'M44 4c18 14 18 44 0 62'}
            fill="none"
            stroke={OUTLINE}
            strokeWidth="5"
            strokeLinecap="round"
          />
          <path
            d={kind === 'bow' ? 'M44 14c14 10 14 34 0 44' : 'M44 4c18 14 18 44 0 62'}
            fill="none"
            stroke={kind === 'bow' ? PAL.wood : '#c9985a'}
            strokeWidth="3"
            strokeLinecap="round"
          />
          <path
            d={kind === 'bow' ? 'M44 14 44 58' : 'M44 4 44 66'}
            stroke="#f3ead0"
            strokeWidth="1"
          />
          <path d="M40 36h14" stroke={OUTLINE} strokeWidth="1.600" />
          <path d="M55 36l-4-2.600v5.200Z" fill={PAL.steel} {...S} strokeWidth="1" />
        </g>
      );
    case 'crossbow':
      return (
        <g>
          <rect x="38" y="34" width="20" height="5" rx="2" fill={PAL.wood} {...S} />
          <path
            d="M42 24c6-2 14-2 14 0v20c0 2-8 2-14 0"
            fill="none"
            stroke={OUTLINE}
            strokeWidth="4.500"
            strokeLinecap="round"
          />
          <path
            d="M44 27c5-1.500 10-1.500 10 0v14"
            fill="none"
            stroke={PAL.woodDark}
            strokeWidth="2.400"
            strokeLinecap="round"
          />
          <path d="M38 36h20" stroke={PAL.steel} strokeWidth="1.600" />
        </g>
      );
    case 'staff':
      return (
        <g>
          <rect x="45.400" y="8" width="3" height="58" rx="1.500" fill={PAL.wood} {...S} />
          <circle cx="46.900" cy="7" r="5" fill="#7fd6ff" {...S} />
          <circle cx="45.200" cy="5.400" r="1.500" fill="#fff" opacity=".8" />
        </g>
      );
    case 'wand':
      return (
        <g>
          <rect
            x="46"
            y="26"
            width="2.400"
            height="24"
            rx="1.200"
            fill="#5a3a7a"
            {...S}
            strokeWidth="1.200"
          />
          <path
            d="M47.200 14l2 5 5 .5-3.800 3.200 1.200 5-4.400-2.800-4.400 2.800 1.200-5-3.800-3.200 5-.5Z"
            fill="#ffe27a"
            {...S}
            strokeWidth="1.200"
          />
        </g>
      );
    case 'axe':
      return (
        <g>
          <rect x="45.400" y="14" width="3" height="50" rx="1.500" fill={PAL.wood} {...S} />
          <path d="M48 14c8-2 10 4 8 10-2 4-5 5-8 4Z" fill={PAL.steel} {...S} />
          <path
            d="M50 16c3-.5 4.500 1 4 4"
            fill="none"
            stroke="#fff"
            strokeWidth="1"
            opacity=".6"
          />
        </g>
      );
    case 'club':
      return (
        <g>
          <path d="M45 62 44.500 30c-1-9 1-13 3-13s4 4 3 13L49 62Z" fill={PAL.wood} {...S} />
          <path
            d="M46 24l1.200 0M46 30h2M46.500 36h1.600"
            stroke={PAL.woodDark}
            strokeWidth="1.200"
          />
        </g>
      );
    case 'hammer':
      return (
        <g>
          <rect x="45.400" y="18" width="3" height="46" rx="1.500" fill={PAL.wood} {...S} />
          <rect x="38.500" y="10" width="17" height="11" rx="2.500" fill={PAL.steelDark} {...S} />
          <rect x="40" y="11.500" width="14" height="3" rx="1.500" fill="#fff" opacity=".35" />
        </g>
      );
    case 'flail':
      return (
        <g>
          <rect x="45.400" y="30" width="3" height="30" rx="1.500" fill={PAL.wood} {...S} />
          <path
            d="M47 30c-1-8 3-12 6-14"
            fill="none"
            stroke={PAL.steelDark}
            strokeWidth="2"
            strokeDasharray="2 1.800"
          />
          <circle cx="53.500" cy="14" r="5.500" fill={PAL.steelDark} {...S} />
          <path
            d="M53.500 8v-3M53.500 20v3M48 14h-3M59 14h3"
            stroke={PAL.steel}
            strokeWidth="2"
            strokeLinecap="round"
          />
        </g>
      );
    case 'torch':
      return (
        <g>
          <rect x="45.400" y="24" width="3" height="38" rx="1.500" fill={PAL.wood} {...S} />
          <path d="M47 4c5 6 6 10 4 14a5 5 0 0 1-8 0c-2-4-1-8 4-14Z" fill="#ff9a2e" {...S} />
          <path
            d="M47 10c2.500 3 3 5 1.500 7.500a2.800 2.800 0 0 1-4.600 0C43 15 44.500 13 47 10Z"
            fill="#ffe27a"
          />
        </g>
      );
    default:
      return null;
  }
}

function ShieldArt({ kind, color }: { kind: ShieldKind; color: string }): ReactNode {
  switch (kind) {
    case 'buckler':
      return (
        <g>
          <circle cx="14" cy="44" r="8" fill={color} {...S} />
          <circle cx="14" cy="44" r="2.800" fill={PAL.steel} {...S} strokeWidth="1.200" />
        </g>
      );
    case 'round':
      return (
        <g>
          <circle cx="14" cy="42" r="12" fill={color} {...S} />
          <circle
            cx="14"
            cy="42"
            r="8.500"
            fill="none"
            stroke={darken(color, 0.3)}
            strokeWidth="1.600"
          />
          <circle cx="14" cy="42" r="3.600" fill={PAL.steel} {...S} strokeWidth="1.200" />
          <path
            d="M6 36a10 10 0 0 1 8-6"
            stroke="#fff"
            strokeWidth="1.800"
            opacity=".4"
            fill="none"
            strokeLinecap="round"
          />
        </g>
      );
    case 'kite':
      return (
        <g>
          <path d="M4 28h20v14c0 8-5 13-10 16C9 55 4 50 4 42Z" fill={color} {...S} />
          <path d="M14 28v30c-5-3-10-8-10-16V28Z" fill="#fff" opacity=".22" />
          <path d="M14 33v14M9 39h10" stroke={PAL.gold} strokeWidth="2.400" strokeLinecap="round" />
        </g>
      );
    case 'tower':
      return (
        <g>
          <rect x="2" y="24" width="20" height="38" rx="4" fill={color} {...S} />
          <rect x="2" y="24" width="10" height="38" rx="4" fill="#fff" opacity=".18" />
          <path
            d="M12 28v30M5 43h14"
            stroke={PAL.steel}
            strokeWidth="2.400"
            strokeLinecap="round"
          />
          <circle cx="12" cy="43" r="3" fill={PAL.gold} {...S} strokeWidth="1.200" />
        </g>
      );
    default:
      return null;
  }
}

function HeadArt({ spec }: { spec: FigureSpec }): ReactNode {
  const { head, hair, skin } = spec;
  const hc = spec.headColor ?? PAL.steel;
  const showHair =
    hair && (head === 'none' || head === 'crown' || head === 'circlet' || head === 'wizard');
  return (
    <g className="fg-head">
      {spec.longHair && hair && (
        <path d="M20.500 20c-2 14 0 24 5 28h13c5-4 7-14 5-28Z" fill={hair} {...S} />
      )}
      <circle cx="32" cy="21" r="10.500" fill={skin} {...S} />
      <ellipse cx="32" cy="24" rx="9" ry="6" fill={darken(skin, 0.1)} opacity=".35" />
      {head !== 'mask' && (
        <>
          <g className="fg-eyes">
            <circle cx="28.400" cy="21.500" r="1.700" fill={OUTLINE} />
            <circle cx="35.600" cy="21.500" r="1.700" fill={OUTLINE} />
            <circle cx="28.900" cy="21" r=".55" fill="#fff" />
            <circle cx="36.100" cy="21" r=".55" fill="#fff" />
          </g>
          <ellipse cx="25.500" cy="25" rx="2" ry="1.200" fill="#ff8a8a" opacity=".45" />
          <ellipse cx="38.500" cy="25" rx="2" ry="1.200" fill="#ff8a8a" opacity=".45" />
          <path
            d="M29.500 26.500q2.500 2 5 0"
            stroke={OUTLINE}
            strokeWidth="1.200"
            fill="none"
            strokeLinecap="round"
          />
        </>
      )}
      {spec.fangs && (
        <path
          d="M29.800 27l.8 2 .9-1.800M34.200 27l-.8 2-.9-1.800"
          fill="#fff"
          stroke={OUTLINE}
          strokeWidth=".8"
        />
      )}
      {spec.beard && (
        <path
          d="M22.500 24c1 8 5 11 9.500 11s8.500-3 9.500-11c-2 3-5 4.200-9.500 4.200S24.500 27 22.500 24Z"
          fill={hair ?? '#7a5a3a'}
          {...S2}
        />
      )}
      {showHair && (
        <path
          d="M21.500 20c-1-9 5-13.500 10.500-13.500S43.500 11 42.500 20c-1.500-4.500-5-6.500-10.500-6.500S23 15.500 21.500 20Z"
          fill={hair!}
          {...S}
        />
      )}
      {head === 'cap' && (
        <g>
          <path
            d="M21 19c0-8 5-12.500 11-12.500S43 11 43 19c-3-2-7-3-11-3s-8 1-11 3Z"
            fill={hc}
            {...S}
          />
          <path
            d="M30 6.800c1 0 2 0 3 .2"
            stroke="#fff"
            strokeWidth="1.400"
            opacity=".4"
            fill="none"
          />
        </g>
      )}
      {head === 'hat' && (
        <g>
          <ellipse cx="32" cy="14" rx="18" ry="4.600" fill={PAL.gold} {...S} />
          <path d="M23 14c0-8 4-10 9-10s9 2 9 10Z" fill={lighten(PAL.gold, 0.1)} {...S} />
          <path d="M23 12.500h18" stroke={PAL.red} strokeWidth="2" />
        </g>
      )}
      {head === 'wizard' && (
        <g>
          <ellipse cx="32" cy="14.500" rx="16" ry="4" fill={hc} {...S} />
          <path
            d="M22 14.500c2-6 6-10 10-16 3 2 5 4 6 7 2 3 3 6 4 9Z"
            fill={lighten(hc, 0.05)}
            {...S}
          />
          <path d="M22 13.500h20" stroke={PAL.gold} strokeWidth="2.200" />
          <path
            d="M31 6l1 2.400 2.500.2-1.900 1.600.6 2.400-2.200-1.300-2.200 1.300.6-2.400-1.900-1.600 2.500-.2Z"
            fill="#ffe27a"
          />
        </g>
      )}
      {(head === 'helm' || head === 'viking' || head === 'crest' || head === 'winged') && (
        <g>
          {head === 'viking' && (
            <>
              <path d="M22 14c-7-1-11-6-10-12 3 4 7 6 12 7Z" fill="#f3ead0" {...S} />
              <path d="M42 14c7-1 11-6 10-12-3 4-7 6-12 7Z" fill="#f3ead0" {...S} />
            </>
          )}
          {head === 'winged' && (
            <>
              <path
                d="M21 14c-4-1-9-4-10-10 5 1 9 3 13 6Zm-2 3c-4 0-8-1-10-4 3-1 7 0 11 2Z"
                fill="#fff"
                {...S2}
              />
              <path
                d="M43 14c4-1 9-4 10-10-5 1-9 3-13 6Zm2 3c4 0 8-1 10-4-3-1-7 0-11 2Z"
                fill="#fff"
                {...S2}
              />
            </>
          )}
          {head === 'crest' && (
            <path d="M32 1c6 2 10 7 9 14H23c-1-7 3-12 9-14Z" fill={PAL.red} {...S} />
          )}
          <path
            d="M20.500 22c-.5-10 4.500-16 11.500-16s12 6 11.500 16l-3 .5c-.5-4-3-6.500-8.500-6.500s-8 2.500-8.500 6.500Z"
            fill={hc}
            {...S}
          />
          <path d="M31 6.400v10.400h2V6.400" fill={darken(hc, 0.2)} />
          <path d="M31 16.500h2v8h-2Z" fill={darken(hc, 0.15)} {...S} strokeWidth="1" />
          <path
            d="M24 10.500c2-2 4-3 7-3.200"
            stroke="#fff"
            strokeWidth="1.600"
            opacity=".55"
            fill="none"
            strokeLinecap="round"
          />
        </g>
      )}
      {head === 'knight' && (
        <g>
          <path
            d="M20.500 26c-1.500-11 3.500-20 11.500-20s13 9 11.500 20l-3 3H23.500Z"
            fill={hc}
            {...S}
          />
          <path d="M23 20h18v5H23Z" fill={darken(hc, 0.55)} {...S2} />
          <path d="M26 21.500h12M26 23.500h12" stroke={PAL.steel} strokeWidth=".8" opacity=".6" />
          <path d="M32 6.500V20" stroke={darken(hc, 0.25)} strokeWidth="1.400" />
          <path d="M32 6c-4-6-2-8 0-9 2 1 4 3 0 9Z" fill={PAL.red} {...S2} />
          <path
            d="M24 12c2-2 4-3 7-3.200"
            stroke="#fff"
            strokeWidth="1.600"
            opacity=".55"
            fill="none"
            strokeLinecap="round"
          />
        </g>
      )}
      {head === 'hood' && (
        <g>
          <path
            d="M19 27c-3-12 2-21 13-21s16 9 13 21c-1-5-3-9-6-10-2 1-4 1.500-7 1.500s-5-.5-7-1.500c-3 1-5 5-6 10Z"
            fill={hc}
            {...S}
          />
          <path
            d="M23 12c3-3 6-4 9-4"
            stroke="#fff"
            strokeWidth="1.600"
            opacity=".35"
            fill="none"
            strokeLinecap="round"
          />
        </g>
      )}
      {head === 'mask' && (
        <g>
          <path d="M21.500 20c-1-9 5-14 10.500-14s11.500 5 10.500 14v3H21.500Z" fill={hc} {...S} />
          <path d="M21.500 20.500h21v6h-21Z" fill={darken(hc, 0.3)} {...S2} />
          <circle cx="28" cy="22.500" r="1.500" fill="#ffe27a" />
          <circle cx="36" cy="22.500" r="1.500" fill="#ffe27a" />
        </g>
      )}
      {head === 'circlet' && (
        <g>
          <path
            d="M22 13.500q10 -3.500 20 0"
            fill="none"
            stroke={PAL.gold}
            strokeWidth="2.400"
            strokeLinecap="round"
          />
          <circle cx="32" cy="12" r="2" fill={PAL.gem} {...S2} />
        </g>
      )}
      {head === 'crown' && (
        <g>
          <path d="M22 12 23.500 3l4.500 5 4-6 4 6 4.500-5L42 12Z" fill={PAL.gold} {...S} />
          <rect x="22" y="11" width="20" height="4" rx="1.500" fill={PAL.goldDark} {...S2} />
          <circle cx="32" cy="13" r="1.400" fill={PAL.red} />
          <circle cx="26.500" cy="13" r="1" fill={PAL.gem} />
          <circle cx="37.500" cy="13" r="1" fill={PAL.gem} />
        </g>
      )}
    </g>
  );
}

/** Рисунок доспеха на туловище: возвращает слои поверх базового силуэта. */
function ArmorOverlay({ spec, half }: { spec: FigureSpec; half: number }): ReactNode {
  const x0 = 32 - half;
  const x1 = 32 + half;
  switch (spec.armor) {
    case 'leather':
      return (
        <g>
          <path
            d={`M${x0 + 2} 28 L${x1 - 4} 52`}
            stroke={PAL.woodDark}
            strokeWidth="3.600"
            strokeLinecap="round"
          />
          <path
            d={`M${x0 + 2} 28 L${x1 - 4} 52`}
            stroke={lighten(PAL.wood, 0.15)}
            strokeWidth="1.600"
            strokeLinecap="round"
          />
          <circle cx="32" cy="40" r="1.100" fill={PAL.gold} />
          <circle cx={x0 + 4.5} cy="49" r=".9" fill={PAL.gold} />
          <circle cx={x1 - 4.5} cy="49" r=".9" fill={PAL.gold} />
        </g>
      );
    case 'chain':
      return (
        <g
          stroke={darken(spec.outfit, 0.45)}
          strokeWidth=".9"
          strokeDasharray="2 1.800"
          opacity=".85"
        >
          {[31, 34.5, 38, 41.5, 45].map((y) => (
            <path key={y} d={`M${x0 + 1} ${y}H${x1 - 1}`} />
          ))}
        </g>
      );
    case 'plate':
    case 'royal':
      return (
        <g>
          <path
            d={`M${x0 + 2} 30h${(half - 2) * 2}v14q-${half - 2} 5-${(half - 2) * 2} 0Z`}
            fill="#fff"
            opacity=".2"
          />
          <path d="M32 28v22" stroke={darken(spec.outfit, 0.4)} strokeWidth="1.200" />
          <path
            d={`M${x0 + 1} 47q${half - 1} 5 ${(half - 1) * 2} 0M${x0 + 1} 50q${half - 1} 5 ${(half - 1) * 2} 0`}
            stroke={darken(spec.outfit, 0.45)}
            strokeWidth="1.200"
            fill="none"
          />
          {spec.armor === 'royal' && (
            <>
              <path d="M28 28h8l1.500 24h-11Z" fill={PAL.red} {...S2} />
              <path d="M32 34l2 3-2 3-2-3Z" fill={PAL.gold} />
            </>
          )}
        </g>
      );
    case 'robe':
      return (
        <g>
          <path
            d={`M${x0 - 1} 50 L${x0 - 5} 64q${half + 5} 5 ${(half + 5) * 2} 0L${x1 + 5} 64 ${x1 + 1} 50Z`}
            fill={spec.outfit}
            {...S}
          />
          <path
            d={`M${x0 - 5} 62q${half + 5} 5 ${(half + 5) * 2} 0`}
            fill="none"
            stroke={spec.trim}
            strokeWidth="2"
          />
          <path d="M32 40v24" stroke={darken(spec.outfit, 0.3)} strokeWidth="1.200" />
        </g>
      );
    default:
      return null;
  }
}

/** Тело фигуры без обёртки svg: можно вставлять на коня или в сцену. Начало координат — окно 64×72. */
export function FigureBody({ spec }: { spec: FigureSpec }): ReactNode {
  const b = spec.bulk ?? 1;
  const half = 11 * b;
  const x0 = 32 - half;
  const x1 = 32 + half;
  const plated = spec.armor === 'plate' || spec.armor === 'royal';
  const torso =
    spec.armor === 'chain'
      ? mixSteel(spec.outfit)
      : spec.armor === 'plate'
        ? PAL.steel
        : spec.armor === 'royal'
          ? PAL.gold
          : spec.outfit;
  const legColor = spec.armor === 'robe' ? spec.outfit : spec.pants;
  // Центры плеч; оружие и щит нарисованы под b=1, поэтому сдвигаем их к кисти
  const lx = x0 - 2.5;
  const rx = x1 + 2.5;
  const joint = (x: number, y: number) => ({
    transformBox: 'view-box' as const,
    transformOrigin: `${x}px ${y}px`,
  });
  const sleeveL = plated ? PAL.steel : spec.outfit;
  const sleeveR = plated ? darken(PAL.steel, 0.1) : darken(spec.outfit, 0.1);
  return (
    <g className="fg-root">
      {spec.aura && (
        <>
          <circle className="fg-aura" cx="32" cy="38" r="30" fill={spec.aura} opacity=".22" />
          <circle className="fg-aura" cx="32" cy="38" r="22" fill={spec.aura} opacity=".22" />
        </>
      )}
      <g className="fg-body" style={joint(32, 64)}>
        {spec.cape && (
          <path className="fg-cape" d="M22 30q10-5 20 0l5 32q-15 6-30 0Z" fill={spec.cape} {...S} />
        )}
        {/* ноги: бедро → голень (колено), стопа с сапогом */}
        <g className="fg-thigh fg-thigh-l" style={joint(27, 49)}>
          <rect x="23.500" y="49" width="7" height="9" rx="3" fill={legColor} {...S} />
          <g className="fg-shin" style={joint(27, 57)}>
            <rect x="23.500" y="55.500" width="7" height="8.500" rx="3" fill={legColor} {...S} />
            <path d="M21.500 64.500a5 3.400 0 0 1 9.500 0Z" fill={PAL.woodDark} {...S2} />
          </g>
        </g>
        <g className="fg-thigh fg-thigh-r" style={joint(37, 49)}>
          <rect
            x="33.500"
            y="49"
            width="7"
            height="9"
            rx="3"
            fill={darken(legColor, 0.12)}
            {...S}
          />
          <g className="fg-shin" style={joint(37, 57)}>
            <rect
              x="33.500"
              y="55.500"
              width="7"
              height="8.500"
              rx="3"
              fill={darken(legColor, 0.12)}
              {...S}
            />
            <path d="M33 64.500a5 3.400 0 0 1 9.500 0Z" fill={PAL.woodDark} {...S2} />
          </g>
        </g>
        {/* грудная клетка: дышит, поворачивается; руки и голова растут из неё */}
        <g className="fg-torso" style={joint(32, 50)}>
          <path
            d={`M${x0} 33Q${x0} 27 ${x0 + 6} 26.500H${x1 - 6}Q${x1} 27 ${x1} 33L${x1 + 1} 52Q32 56 ${x0 - 1} 52Z`}
            fill={torso}
            {...S}
          />
          <path
            d={`M${x0} 33Q${x0} 27 ${x0 + 6} 26.500H32V54Q${x0 - 1} 52 ${x0 - 1} 52Z`}
            fill="#fff"
            opacity=".16"
          />
          <ArmorOverlay spec={spec} half={half} />
          <rect
            x={x0 - 0.5}
            y="47"
            width={(half + 0.5) * 2}
            height="4.500"
            fill={darken(spec.outfit, 0.45)}
            {...S2}
          />
          <rect
            x="29.500"
            y="46.500"
            width="5"
            height="5.500"
            rx="1"
            fill={PAL.gold}
            {...S}
            strokeWidth="1"
          />
          <path d="M26.500 27.500q5.500 5 11 0" fill={spec.trim} {...S2} />
          {/* левая рука со щитом: плечо → локоть */}
          <g className="fg-arm-s" style={joint(lx, 32)}>
            <rect x={lx - 3.5} y="30" width="7" height="11" rx="3.500" fill={sleeveL} {...S} />
            <g className="fg-fore-s" style={joint(lx, 40)}>
              <rect
                x={lx - 3.5}
                y="38.500"
                width="7"
                height="10"
                rx="3.500"
                fill={sleeveL}
                {...S}
              />
              <circle cx={lx} cy="48.500" r="3.400" fill={spec.skin} {...S2} />
              <g transform={`translate(${lx - 18.5} 0)`}>
                <ShieldArt kind={spec.shield} color={spec.shieldColor ?? PAL.red} />
              </g>
            </g>
          </g>
          {/* правая рука с оружием */}
          <g className="fg-arm-w" style={joint(rx, 32)}>
            <rect x={rx - 3.5} y="30" width="7" height="11" rx="3.500" fill={sleeveR} {...S} />
            <g className="fg-fore-w" style={joint(rx, 40)}>
              <rect
                x={rx - 3.5}
                y="38.500"
                width="7"
                height="10"
                rx="3.500"
                fill={sleeveR}
                {...S}
              />
              <circle cx={rx} cy="48.500" r="3.400" fill={spec.skin} {...S2} />
              <g transform={`translate(${rx - 45.5} 0)`}>
                <WeaponArt kind={spec.weapon} />
              </g>
            </g>
          </g>
          {(spec.pauldrons || plated) && (
            <g className="fg-pauldrons">
              <circle
                cx={x0 - 1}
                cy="31.500"
                r="5.600"
                fill={spec.armor === 'royal' ? PAL.gold : PAL.steel}
                {...S}
              />
              <circle
                cx={x1 + 1}
                cy="31.500"
                r="5.600"
                fill={spec.armor === 'royal' ? PAL.gold : PAL.steel}
                {...S}
              />
              <path
                d={`M${x0 - 4} 29.500a4.500 4 0 0 1 4-2.200M${x1 - 3} 27.300a4.500 4 0 0 1 4 2.200`}
                stroke="#fff"
                strokeWidth="1.400"
                opacity=".55"
                fill="none"
                strokeLinecap="round"
              />
            </g>
          )}
          <g className="fg-neck" style={joint(32, 30)}>
            <HeadArt spec={spec} />
          </g>
        </g>
      </g>
    </g>
  );
}

const mixSteel = (c: string): string =>
  `#${[0, 2, 4]
    .map((i) =>
      Math.round((Number.parseInt(c.slice(1 + i, 3 + i), 16) + 0x9a) / 2)
        .toString(16)
        .padStart(2, '0'),
    )
    .join('')}`;

/** Человечек в собственном svg. Декоративный, если не задан title. */
export function Figure({
  spec,
  size = 64,
  title,
  className,
  flip = false,
  anim = 'none',
  delay = 0,
}: {
  spec: FigureSpec;
  size?: number;
  title?: string;
  className?: string;
  flip?: boolean;
  anim?: FigureAnim;
  /** Сдвиг анимации, секунды: чтобы отряд не двигался в унисон. */
  delay?: number;
}) {
  return (
    <svg
      viewBox="0 0 64 72"
      width={size}
      height={(size * 72) / 64}
      role={title ? 'img' : undefined}
      aria-label={title}
      aria-hidden={title ? undefined : true}
      className={className}
      data-anim={anim}
      style={delay ? ({ '--fg-d': `${delay}s` } as React.CSSProperties) : undefined}
      focusable="false"
    >
      <ellipse
        className="fg-shadow"
        cx="32"
        cy="67.500"
        rx="17"
        ry="3.800"
        fill="#000"
        opacity=".28"
      />
      <g transform={flip ? 'translate(64 0) scale(-1 1)' : undefined}>
        <FigureBody spec={spec} />
      </g>
    </svg>
  );
}
