export { ArtIcon, type IconName } from './icons';
export { Figure, FigureBody, type FigureSpec } from './figure';
export {
  UnitArt,
  HeroArt,
  NpcArt,
  NPC_SPEC,
  UNIT_SPEC,
  heroSpec,
  type HeroGear,
  type NpcName,
} from './units';
export type { FigureAnim } from './figure';
export { OUTLINE, PAL, mix, lighten, darken } from './color';
export { NavArt, type NavArtName } from './navicons';
