import type { ReactNode } from 'react';
import type { SkillKey, TechKey } from '@tc/shared';
import { OUTLINE, PAL, darken, lighten } from './color';

/** Имена значков: ресурсы, технологии, навыки и служебные. */
export type IconName =
  | 'gold'
  | 'wood'
  | 'stone'
  | 'food'
  | 'gems'
  | 'lock'
  | 'heart'
  | 'shield'
  | 'hammer'
  | 'siege'
  | SkillKey
  | TechKey;

const S = {
  stroke: OUTLINE,
  strokeWidth: 1.4,
  strokeLinejoin: 'round',
  strokeLinecap: 'round',
} as const;

/** Круглая «медаль» под значок технологии/навыка: цвет задаёт тему (хозяйство, война, наука). */
function Badge({ color, children }: { color: string; children: ReactNode }) {
  return (
    <>
      <circle
        cx="12"
        cy="12"
        r="11"
        fill={darken(color, 0.35)}
        stroke={OUTLINE}
        strokeWidth="1.4"
      />
      <circle cx="12" cy="12" r="9" fill={color} />
      <path d="M4 10a8.5 8.5 0 0 1 16 0c-3-3-13-3-16 0Z" fill="#fff" opacity=".22" />
      {children}
    </>
  );
}

const ECON = '#6aa63a';
const WAR = '#b9473a';
const SCI = '#4a78c2';

const GLYPH: Record<IconName, () => ReactNode> = {
  gold: () => (
    <>
      <circle cx="12" cy="12" r="10.5" fill={PAL.goldDark} {...S} />
      <circle cx="12" cy="11.4" r="9.2" fill={PAL.gold} />
      <circle
        cx="12"
        cy="11.4"
        r="6.6"
        fill={lighten(PAL.gold, 0.25)}
        stroke={PAL.goldDark}
        strokeWidth="1"
      />
      <path
        d="M12 6.6l1.4 3 3.2.4-2.4 2.2.7 3.2L12 13.8 9.1 15.4l.7-3.2-2.4-2.2 3.2-.4Z"
        fill={PAL.goldDark}
        opacity=".75"
      />
      <path
        d="M5.4 8a8 8 0 0 1 6-4"
        stroke="#fff"
        strokeWidth="1.6"
        fill="none"
        opacity=".55"
        strokeLinecap="round"
      />
    </>
  ),
  wood: () => (
    <>
      <rect x="2" y="13.5" width="20" height="7.5" rx="3.75" fill={PAL.wood} {...S} />
      <rect x="4" y="5.5" width="16" height="7.5" rx="3.75" fill={lighten(PAL.wood, 0.1)} {...S} />
      <circle cx="19.2" cy="17.2" r="2.7" fill="#d9b27a" stroke={OUTLINE} strokeWidth="1" />
      <circle cx="19.2" cy="17.2" r="1.1" fill="none" stroke={PAL.woodDark} strokeWidth=".8" />
      <circle cx="17.2" cy="9.2" r="2.7" fill="#d9b27a" stroke={OUTLINE} strokeWidth="1" />
      <circle cx="17.2" cy="9.2" r="1.1" fill="none" stroke={PAL.woodDark} strokeWidth=".8" />
      <path
        d="M5 16.5h9M7 8.6h6"
        stroke={PAL.woodDark}
        strokeWidth=".9"
        opacity=".7"
        strokeLinecap="round"
      />
    </>
  ),
  stone: () => (
    <>
      <path d="M2.5 19.5 6 9l6-3.4 6 3.4 3.5 10.5Z" fill={PAL.stone} {...S} />
      <path d="M6 9l6-3.4V19.5H2.5Z" fill={lighten(PAL.stone, 0.22)} />
      <path d="M12 5.6 18 9l3.5 10.5H12Z" fill={darken(PAL.stone, 0.22)} />
      <path d="M2.5 19.5 6 9l6-3.4 6 3.4 3.5 10.5Z" fill="none" {...S} />
      <path
        d="M12 5.6V19.5M6 9l6 4 6-4"
        stroke={OUTLINE}
        strokeWidth=".9"
        fill="none"
        opacity=".55"
      />
    </>
  ),
  food: () => (
    <>
      <path d="M12 21.5V9" stroke={PAL.woodDark} strokeWidth="1.8" strokeLinecap="round" />
      {[6, 9.5, 13].map((y, i) => (
        <g key={y}>
          <ellipse
            cx={8.3 + i * 0.3}
            cy={y}
            rx="2.3"
            ry="3.4"
            transform={`rotate(-32 ${8.3 + i * 0.3} ${y})`}
            fill={PAL.gold}
            {...S}
          />
          <ellipse
            cx={15.7 - i * 0.3}
            cy={y}
            rx="2.3"
            ry="3.4"
            transform={`rotate(32 ${15.7 - i * 0.3} ${y})`}
            fill={lighten(PAL.gold, 0.15)}
            {...S}
          />
        </g>
      ))}
      <ellipse cx="12" cy="4.2" rx="2" ry="3" fill={PAL.gold} {...S} />
      <path d="M8 21.5h8" stroke={OUTLINE} strokeWidth="1.4" strokeLinecap="round" />
    </>
  ),
  gems: () => (
    <>
      <path d="M6 4h12l4.5 6L12 22 1.5 10Z" fill={PAL.gem} {...S} />
      <path d="M6 4l-1 6h14l-1-6Z" fill={lighten(PAL.gem, 0.4)} />
      <path d="M1.5 10h21L12 22Z" fill={darken(PAL.gem, 0.15)} />
      <path
        d="M8.2 10 12 22 15.8 10M6 4l2.2 6M18 4l-2.2 6"
        stroke={OUTLINE}
        strokeWidth=".9"
        fill="none"
        opacity=".6"
      />
      <path d="M6 4h12l4.5 6L12 22 1.5 10Z" fill="none" {...S} />
      <path d="M8 6l1-.8" stroke="#fff" strokeWidth="1.6" strokeLinecap="round" />
    </>
  ),
  lock: () => (
    <>
      <path
        d="M7.5 11V8a4.5 4.5 0 0 1 9 0v3"
        fill="none"
        stroke={PAL.steelDark}
        strokeWidth="2.4"
        strokeLinecap="round"
      />
      <rect x="4.5" y="10.5" width="15" height="11" rx="2.5" fill={PAL.gold} {...S} />
      <circle cx="12" cy="15" r="1.7" fill={OUTLINE} />
      <path d="M12 15.5v2.6" stroke={OUTLINE} strokeWidth="1.6" strokeLinecap="round" />
    </>
  ),
  heart: () => (
    <>
      <path
        d="M12 21C4 15 2 10.5 2 7.8 2 5 4.2 3 6.8 3c2 0 3.7 1 5.2 3 1.5-2 3.2-3 5.2-3C19.8 3 22 5 22 7.8 22 10.5 20 15 12 21Z"
        fill="#e04a4a"
        {...S}
      />
      <path
        d="M6 6.5c1-1 2.3-1.1 3-.4"
        stroke="#fff"
        strokeWidth="1.8"
        opacity=".6"
        fill="none"
        strokeLinecap="round"
      />
    </>
  ),
  shield: () => (
    <>
      <path
        d="M12 2.5 20.5 5v7c0 4.4-3.4 7.8-8.5 9.7C6.9 19.8 3.5 16.4 3.5 12V5Z"
        fill={PAL.blue}
        {...S}
      />
      <path d="M12 2.5V21.7C6.9 19.8 3.5 16.4 3.5 12V5Z" fill={lighten(PAL.blue, 0.2)} />
      <path
        d="M12 2.5 20.5 5v7c0 4.4-3.4 7.8-8.5 9.7C6.9 19.8 3.5 16.4 3.5 12V5Z"
        fill="none"
        {...S}
      />
      <path
        d="M12 7l1.4 3 3.3.4-2.5 2.2.7 3.3L12 14.2 9.1 15.9l.7-3.3L7.3 10.4l3.3-.4Z"
        fill={PAL.gold}
      />
    </>
  ),
  hammer: () => (
    <>
      <path d="M11 9 20.5 18.5a1.9 1.9 0 0 1-2.7 2.7L8.5 11.8" fill={PAL.wood} {...S} />
      <path d="M3 8.5 9 3l4.2 1.6 2.3 2.7-4 4.2-3.1-1.3Z" fill={PAL.steel} {...S} />
      <path d="M9 3 6.4 8.2" stroke="#fff" strokeWidth="1.2" opacity=".6" strokeLinecap="round" />
    </>
  ),
  siege: () => (
    <>
      <circle cx="7" cy="18" r="4" fill={PAL.wood} {...S} />
      <circle cx="18" cy="18" r="4" fill={PAL.wood} {...S} />
      <path d="M4 15h17v2H4Z" fill={PAL.woodDark} {...S} />
      <path d="M8 15 15 4l2 1.4L11 15" fill={PAL.wood} {...S} />
      <circle cx="16.5" cy="4" r="2.6" fill={PAL.stone} {...S} />
    </>
  ),
  // ── навыки героя ──
  combat: () => (
    <Badge color={WAR}>
      <path d="M6 6l9 9M18 6l-9 9" stroke={PAL.steel} strokeWidth="2.4" strokeLinecap="round" />
      <path
        d="M6 6l9 9M18 6l-9 9"
        stroke={OUTLINE}
        strokeWidth=".8"
        strokeLinecap="round"
        opacity=".5"
      />
      <path
        d="M5.5 16l2.5 2.5M18.5 16 16 18.5"
        stroke={PAL.gold}
        strokeWidth="2.4"
        strokeLinecap="round"
      />
    </Badge>
  ),
  defense: () => (
    <Badge color={SCI}>
      <path
        d="M12 5.5 17.5 7v4.4c0 3-2.2 5-5.5 6.2-3.3-1.2-5.5-3.2-5.5-6.2V7Z"
        fill={PAL.steel}
        stroke={OUTLINE}
        strokeWidth="1.2"
        strokeLinejoin="round"
      />
      <path d="M12 5.5V17.6c-3.3-1.2-5.5-3.2-5.5-6.2V7Z" fill="#fff" opacity=".35" />
    </Badge>
  ),
  economy: () => (
    <Badge color={ECON}>
      <circle cx="12" cy="12" r="5.4" fill={PAL.gold} stroke={OUTLINE} strokeWidth="1.2" />
      <circle cx="12" cy="12" r="3.2" fill={lighten(PAL.gold, 0.3)} />
    </Badge>
  ),
  // ── технологии ──
  farming: () => (
    <Badge color={ECON}>
      <path d="M12 18V8" stroke={PAL.woodDark} strokeWidth="1.6" strokeLinecap="round" />
      <ellipse
        cx="9.4"
        cy="9"
        rx="1.6"
        ry="2.6"
        transform="rotate(-30 9.4 9)"
        fill={PAL.gold}
        stroke={OUTLINE}
        strokeWidth=".9"
      />
      <ellipse
        cx="14.6"
        cy="9"
        rx="1.6"
        ry="2.6"
        transform="rotate(30 14.6 9)"
        fill={PAL.gold}
        stroke={OUTLINE}
        strokeWidth=".9"
      />
      <ellipse
        cx="9.4"
        cy="13"
        rx="1.6"
        ry="2.6"
        transform="rotate(-30 9.4 13)"
        fill={PAL.gold}
        stroke={OUTLINE}
        strokeWidth=".9"
      />
      <ellipse
        cx="14.6"
        cy="13"
        rx="1.6"
        ry="2.6"
        transform="rotate(30 14.6 13)"
        fill={PAL.gold}
        stroke={OUTLINE}
        strokeWidth=".9"
      />
      <ellipse
        cx="12"
        cy="6.4"
        rx="1.5"
        ry="2.2"
        fill={PAL.gold}
        stroke={OUTLINE}
        strokeWidth=".9"
      />
    </Badge>
  ),
  forestry: () => (
    <Badge color={ECON}>
      <path
        d="M12 5 17 13h-3l3.5 5h-11L10 13H7Z"
        fill={PAL.leaf}
        stroke={OUTLINE}
        strokeWidth="1.1"
        strokeLinejoin="round"
      />
      <rect x="11" y="17.5" width="2" height="3" fill={PAL.woodDark} />
    </Badge>
  ),
  masonry: () => (
    <Badge color={ECON}>
      <rect
        x="5"
        y="7"
        width="14"
        height="10"
        rx="1"
        fill="#c98a5a"
        stroke={OUTLINE}
        strokeWidth="1.1"
      />
      <path d="M5 12h14M9.5 7v5M14.5 12v5M9.5 12" stroke={OUTLINE} strokeWidth=".9" opacity=".7" />
    </Badge>
  ),
  mining: () => (
    <Badge color={ECON}>
      <path
        d="M6 8.5c3-3 9-3 12 0"
        fill="none"
        stroke={PAL.steel}
        strokeWidth="2.4"
        strokeLinecap="round"
      />
      <path d="M12 7v12" stroke={PAL.wood} strokeWidth="2.2" strokeLinecap="round" />
      <path d="M12 7v12" stroke={OUTLINE} strokeWidth=".6" opacity=".5" />
    </Badge>
  ),
  logistics: () => (
    <Badge color={ECON}>
      <circle cx="12" cy="12" r="6" fill="none" stroke={PAL.wood} strokeWidth="2" />
      <circle cx="12" cy="12" r="1.6" fill={PAL.gold} stroke={OUTLINE} strokeWidth=".8" />
      <path
        d="M12 6v12M6 12h12M7.8 7.8l8.4 8.4M16.2 7.8l-8.4 8.4"
        stroke={PAL.wood}
        strokeWidth="1.2"
      />
    </Badge>
  ),
  swordsmanship: () => (
    <Badge color={WAR}>
      <path
        d="M12 4.5 13.6 6v8.5h-3.2V6Z"
        fill={PAL.steel}
        stroke={OUTLINE}
        strokeWidth="1"
        strokeLinejoin="round"
      />
      <rect
        x="8"
        y="14"
        width="8"
        height="2"
        rx="1"
        fill={PAL.gold}
        stroke={OUTLINE}
        strokeWidth=".9"
      />
      <rect x="11" y="16" width="2" height="3.4" fill={PAL.woodDark} />
    </Badge>
  ),
  archery: () => (
    <Badge color={WAR}>
      <path
        d="M8 5.5c7 2.5 7 10.5 0 13"
        fill="none"
        stroke={PAL.wood}
        strokeWidth="2"
        strokeLinecap="round"
      />
      <path d="M8 5.5v13" stroke="#f3ead0" strokeWidth=".8" />
      <path d="M6 12h11" stroke={PAL.woodDark} strokeWidth="1.2" />
      <path d="M17 12l-2.4-1.6v3.2Z" fill={PAL.steel} stroke={OUTLINE} strokeWidth=".7" />
    </Badge>
  ),
  riding: () => (
    <Badge color={WAR}>
      <path
        d="M7 6v6.5a5 5 0 0 0 10 0V6"
        fill="none"
        stroke={PAL.steel}
        strokeWidth="2.6"
        strokeLinecap="round"
      />
      <path
        d="M7 6v6.5a5 5 0 0 0 10 0V6"
        fill="none"
        stroke={OUTLINE}
        strokeWidth=".7"
        opacity=".5"
      />
      <path d="M6.2 8.5h2.6M15.2 8.5h2.6" stroke={PAL.goldDark} strokeWidth="1" />
    </Badge>
  ),
  siegecraft: () => (
    <Badge color={WAR}>
      <circle cx="8.5" cy="16.5" r="2.4" fill={PAL.wood} stroke={OUTLINE} strokeWidth=".9" />
      <circle cx="15.5" cy="16.5" r="2.4" fill={PAL.wood} stroke={OUTLINE} strokeWidth=".9" />
      <path d="M6.5 14.5h11" stroke={PAL.woodDark} strokeWidth="1.6" />
      <path d="M9 14.5 15 6" stroke={PAL.wood} strokeWidth="1.8" strokeLinecap="round" />
      <circle cx="15.6" cy="5.8" r="1.8" fill={PAL.stone} stroke={OUTLINE} strokeWidth=".8" />
    </Badge>
  ),
  tactics: () => (
    <Badge color={SCI}>
      <path d="M8 19V5" stroke={PAL.woodDark} strokeWidth="1.6" strokeLinecap="round" />
      <path
        d="M8 5.5h9l-2 3 2 3H8Z"
        fill={PAL.red}
        stroke={OUTLINE}
        strokeWidth="1"
        strokeLinejoin="round"
      />
    </Badge>
  ),
  drill: () => (
    <Badge color={WAR}>
      <circle cx="12" cy="12" r="6.4" fill="#f3ead0" stroke={OUTLINE} strokeWidth="1" />
      <circle cx="12" cy="12" r="4.2" fill={PAL.red} />
      <circle cx="12" cy="12" r="2.2" fill="#f3ead0" />
      <circle cx="12" cy="12" r=".9" fill={PAL.red} />
    </Badge>
  ),
  fortification: () => (
    <Badge color={SCI}>
      <path
        d="M6 18.5V8h2v1.6h2V8h4v1.6h2V8h2v10.5Z"
        fill={PAL.stone}
        stroke={OUTLINE}
        strokeWidth="1"
        strokeLinejoin="round"
      />
      <path d="M10.5 18.5v-4a1.5 1.5 0 0 1 3 0v4Z" fill={PAL.woodDark} />
    </Badge>
  ),
  armor: () => (
    <Badge color={SCI}>
      <path
        d="M7 6.5 9.5 5.5c.7 1.2 1.6 1.7 2.5 1.7s1.8-.5 2.5-1.7L17 6.5l1.6 3-2.2 1.3V18H7.6v-7.2L5.4 9.5Z"
        fill={PAL.steel}
        stroke={OUTLINE}
        strokeWidth="1"
        strokeLinejoin="round"
      />
      <path
        d="M12 7.2V18H7.6v-7.2L5.4 9.5 7 6.5l2.5-1c.7 1.2 1.6 1.7 2.5 1.7Z"
        fill="#fff"
        opacity=".3"
      />
    </Badge>
  ),
  medicine: () => (
    <Badge color={SCI}>
      <rect
        x="9.8"
        y="5"
        width="4.4"
        height="14"
        rx="1.4"
        fill="#f5f0e2"
        stroke={OUTLINE}
        strokeWidth="1"
      />
      <rect
        x="5"
        y="9.8"
        width="14"
        height="4.4"
        rx="1.4"
        fill="#f5f0e2"
        stroke={OUTLINE}
        strokeWidth="1"
      />
      <rect x="10.4" y="10.4" width="3.2" height="3.2" fill={PAL.red} />
      <rect x="10.4" y="6" width="3.2" height="12" fill={PAL.red} opacity=".0" />
    </Badge>
  ),
};

/** Векторный значок. Декоративный, если не задан title. */
export function ArtIcon({
  name,
  size = 24,
  title,
  className,
}: {
  name: IconName;
  size?: number;
  title?: string;
  className?: string;
}) {
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      role={title ? 'img' : undefined}
      aria-label={title}
      aria-hidden={title ? undefined : true}
      className={`inline-block shrink-0 ${className ?? ''}`}
      focusable="false"
    >
      {GLYPH[name]()}
    </svg>
  );
}
