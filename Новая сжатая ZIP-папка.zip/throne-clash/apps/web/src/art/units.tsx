import type { ReactNode } from 'react';
import type { UnitTier, UnitType } from '@tc/shared';
import { OUTLINE, PAL, darken, lighten } from './color';
import { Figure, FigureBody, type FigureAnim, type FigureSpec } from './figure';

const S = {
  stroke: OUTLINE,
  strokeWidth: 1.6,
  strokeLinejoin: 'round',
  strokeLinecap: 'round',
} as const;

const base = (o: Partial<FigureSpec>): FigureSpec => ({
  skin: PAL.skin,
  hair: '#5a3a22',
  outfit: '#3f6fb8',
  trim: '#f2cf6b',
  pants: '#5b4636',
  armor: 'cloth',
  head: 'none',
  weapon: 'none',
  shield: 'none',
  ...o,
});

type Foot = Exclude<UnitType, 'siege'>;

/** Облик войска по роду и уровню (1–5): чем выше уровень, тем богаче доспех и оружие. */
export const UNIT_SPEC: Readonly<Record<Foot, Readonly<Record<UnitTier, FigureSpec>>>> = {
  infantry: {
    1: base({
      outfit: '#a08560',
      pants: '#6a5236',
      head: 'cap',
      headColor: '#7a5a3a',
      weapon: 'club',
      shield: 'buckler',
      shieldColor: '#8a5a34',
    }),
    2: base({
      outfit: '#3f6fb8',
      armor: 'leather',
      head: 'helm',
      weapon: 'spear',
      shield: 'round',
      shieldColor: '#8a5a34',
    }),
    3: base({
      outfit: '#3f6fb8',
      armor: 'chain',
      head: 'crest',
      headColor: '#8a95a0',
      weapon: 'sword',
      shield: 'kite',
      shieldColor: '#b32626',
    }),
    4: base({
      outfit: '#3f6fb8',
      armor: 'plate',
      head: 'knight',
      headColor: '#b8c4cc',
      weapon: 'sword',
      shield: 'kite',
      shieldColor: '#2f5fae',
      cape: '#b32626',
      pauldrons: true,
    }),
    5: base({
      outfit: '#c9a020',
      trim: '#f3ead0',
      armor: 'royal',
      head: 'winged',
      headColor: '#e0b030',
      weapon: 'greatsword',
      shield: 'tower',
      shieldColor: '#2f5fae',
      cape: '#7a1f2a',
      bulk: 1.1,
    }),
  },
  archer: {
    1: base({ outfit: '#a08a4a', pants: '#6a5236', head: 'hat', weapon: 'bow', hair: '#8a5a2a' }),
    2: base({
      outfit: '#4f8f3a',
      trim: '#e8d6a8',
      armor: 'leather',
      head: 'hood',
      headColor: '#3c6f2c',
      weapon: 'bow',
      hair: '#8a5a2a',
    }),
    3: base({
      outfit: '#3f7a3a',
      trim: '#e8d6a8',
      armor: 'leather',
      head: 'hood',
      headColor: '#2c5a2a',
      weapon: 'longbow',
      cape: '#2f5a2a',
    }),
    4: base({
      outfit: '#4a6a4a',
      armor: 'chain',
      head: 'helm',
      headColor: '#8a95a0',
      weapon: 'crossbow',
      pauldrons: true,
    }),
    5: base({
      outfit: '#2c6a5a',
      trim: '#f2cf6b',
      armor: 'plate',
      head: 'mask',
      headColor: '#2c4a3a',
      weapon: 'longbow',
      cape: '#1f4a3a',
      pauldrons: true,
    }),
  },
  cavalry: {
    1: base({ outfit: '#8a6a3a', head: 'cap', headColor: '#6a4a2a', weapon: 'spear' }),
    2: base({
      outfit: '#8a3fb0',
      armor: 'leather',
      head: 'helm',
      weapon: 'spear',
      shield: 'buckler',
      shieldColor: '#e0b030',
    }),
    3: base({
      outfit: '#8a3fb0',
      armor: 'chain',
      head: 'crest',
      headColor: '#8a95a0',
      weapon: 'lance',
      shield: 'round',
      shieldColor: '#e0b030',
      cape: '#b32626',
    }),
    4: base({
      outfit: '#6a2f90',
      armor: 'plate',
      head: 'knight',
      headColor: '#b8c4cc',
      weapon: 'lance',
      shield: 'kite',
      shieldColor: '#6a2f90',
      cape: '#b32626',
      pauldrons: true,
    }),
    5: base({
      outfit: '#c9a020',
      trim: '#f3ead0',
      armor: 'royal',
      head: 'winged',
      headColor: '#e0b030',
      weapon: 'lance',
      shield: 'kite',
      shieldColor: '#7a1f2a',
      cape: '#7a1f2a',
    }),
  },
};

const HORSE: Readonly<Record<UnitTier, { coat: string; barding: string | null }>> = {
  1: { coat: '#8a6a44', barding: null },
  2: { coat: '#7a4a2a', barding: '#b32626' },
  3: { coat: '#5a3a24', barding: '#8a3fb0' },
  4: { coat: '#3a3a44', barding: '#9aa4ad' },
  5: { coat: '#f0ece0', barding: '#e0b030' },
};

/** Конь под всадником. Рисуется в окне 96×80. */
function Horse({ coat, barding }: { coat: string; barding: string | null }): ReactNode {
  const dark = darken(coat, 0.35);
  return (
    <g className="fg-horse">
      <ellipse cx="46" cy="76" rx="30" ry="4" fill="#000" opacity=".28" />
      <rect
        className="fg-hleg fg-hleg-a"
        x="24"
        y="54"
        width="7"
        height="20"
        rx="3"
        fill={dark}
        {...S}
      />
      <rect
        className="fg-hleg fg-hleg-b"
        x="58"
        y="54"
        width="7"
        height="20"
        rx="3"
        fill={dark}
        {...S}
      />
      <path className="fg-cape" d="M22 44c-9 2-11 12-8 22 4-6 8-9 11-12Z" fill={dark} {...S} />
      <path d="M20 46c0-9 10-14 26-14s27 5 27 14-9 15-27 15-26-6-26-15Z" fill={coat} {...S} />
      <path d="M26 42c6-6 22-8 34-3-10-2-22 0-34 3Z" fill="#fff" opacity=".22" />
      <path d="M66 36c3-10 8-16 14-20l7 4c2 1 3 3 2 5l-2 4-6 1c-2 5-4 9-6 13Z" fill={coat} {...S} />
      <path
        d="M69 32c2-8 6-12 10-15"
        fill="none"
        stroke={dark}
        strokeWidth="5"
        strokeLinecap="round"
      />
      <circle cx="83" cy="22" r="1.500" fill={OUTLINE} />
      <path d="M86 27l3-1" stroke={OUTLINE} strokeWidth="1.600" strokeLinecap="round" />
      <path d="M78 14l1-6 4 5Z" fill={coat} {...S} strokeWidth="1.200" />
      {barding && (
        <>
          <path
            d="M24 38c8-6 30-7 44 0l-2 15c-14 6-28 6-40 0Z"
            fill={barding}
            {...S}
            strokeWidth="1.400"
          />
          <path d="M28 44h36M28 49h36" stroke={darken(barding, 0.35)} strokeWidth="1" />
          <path d="M80 14c3 1 5 3 6 6l-4 2Z" fill={barding} {...S} strokeWidth="1.200" />
        </>
      )}
      {!barding && (
        <path
          d="M32 36c6-3 20-3 26 0l-3 16c-6 2-14 2-20 0Z"
          fill="#b32626"
          {...S}
          strokeWidth="1.400"
        />
      )}
      <rect
        className="fg-hleg fg-hleg-b"
        x="32"
        y="54"
        width="8"
        height="21"
        rx="3.500"
        fill={coat}
        {...S}
      />
      <rect
        className="fg-hleg fg-hleg-a"
        x="50"
        y="54"
        width="8"
        height="21"
        rx="3.500"
        fill={coat}
        {...S}
      />
      <path d="M31 76h10M49 76h10" stroke={OUTLINE} strokeWidth="3.200" strokeLinecap="round" />
    </g>
  );
}

function Wide({
  children,
  size,
  title,
  anim = 'none',
  top = 0,
}: {
  children: ReactNode;
  size: number;
  title?: string;
  anim?: FigureAnim;
  /** Сколько единиц добавить сверху (всадник с копьём выше коня). */
  top?: number;
}) {
  return (
    <svg
      viewBox={`0 ${-top} 96 ${80 + top}`}
      width={size * 1.4}
      height={(size * 1.4 * (80 + top)) / 96}
      role={title ? 'img' : undefined}
      aria-label={title}
      aria-hidden={title ? undefined : true}
      data-anim={anim}
      focusable="false"
    >
      {children}
    </svg>
  );
}

function Cavalry({
  tier,
  size,
  title,
  anim,
}: {
  tier: UnitTier;
  size: number;
  title?: string;
  anim?: FigureAnim;
}) {
  const spec = UNIT_SPEC.cavalry[tier];
  return (
    <Wide size={size} title={title} anim={anim} top={22}>
      <Horse {...HORSE[tier]} />
      <g transform="translate(17 -10) scale(.88)">
        <FigureBody spec={{ ...spec, cape: tier >= 3 ? spec.cape : null }} />
      </g>
    </Wide>
  );
}

const Wheel = ({ cx, cy, r = 11 }: { cx: number; cy: number; r?: number }) => (
  <g className="fg-wheel">
    <circle cx={cx} cy={cy} r={r} fill={PAL.wood} {...S} />
    <circle cx={cx} cy={cy} r={r * 0.36} fill={PAL.woodDark} {...S} />
    <path
      d={`M${cx} ${cy - r}V${cy + r}M${cx - r} ${cy}H${cx + r}M${cx - r * 0.7} ${cy - r * 0.7}l${r * 1.4} ${r * 1.4}M${cx + r * 0.7} ${cy - r * 0.7}l${-r * 1.4} ${r * 1.4}`}
      stroke={PAL.woodDark}
      strokeWidth="1.600"
    />
  </g>
);

/** Осадные орудия по уровню: таран, катапульта, баллиста, требюше, бомбарда. */
function Siege({
  tier,
  size,
  title,
  anim,
}: {
  tier: UnitTier;
  size: number;
  title?: string;
  anim?: FigureAnim;
}) {
  const shadow = <ellipse cx="48" cy="76" rx="38" ry="4" fill="#000" opacity=".28" />;
  let body: ReactNode;
  switch (tier) {
    case 1: // таран
      body = (
        <g>
          <path d="M10 26 48 8 86 26v6H10Z" fill="#7a3a2a" {...S} />
          <path d="M10 26 48 8 86 26" fill="none" stroke="#fff" strokeWidth="1.400" opacity=".25" />
          <path d="M16 32h64v26H16Z" fill={PAL.wood} {...S} />
          <path d="M28 32v26M48 32v26M68 32v26" stroke={PAL.woodDark} strokeWidth="2" />
          <g className="fg-thrust">
            <rect
              x="6"
              y="40"
              width="70"
              height="9"
              rx="4.500"
              fill={lighten(PAL.wood, 0.1)}
              {...S}
            />
            <path d="M74 38h14l4 6.500-4 6.500H74Z" fill={PAL.steel} {...S} />
            <path d="M76 41h10" stroke="#fff" strokeWidth="1.400" opacity=".6" />
          </g>
          <Wheel cx={26} cy={64} r={9} />
          <Wheel cx={70} cy={64} r={9} />
        </g>
      );
      break;
    case 3: // баллиста
      body = (
        <g>
          <path d="M20 62 32 36h32l12 26Z" fill={PAL.wood} {...S} />
          <rect x="44" y="30" width="8" height="34" fill={PAL.woodDark} {...S} />
          <g className="fg-recoil">
            <path
              d="M10 22c22 6 54 6 76 0-4 8-10 12-14 12H24c-6 0-10-4-14-12Z"
              fill={PAL.wood}
              {...S}
            />
            <path d="M12 26c22 5 50 5 72 0" stroke="#f3ead0" strokeWidth="1.200" />
            <rect x="24" y="32" width="46" height="4.500" rx="2" fill={PAL.woodDark} {...S} />
            <path d="M22 34h58l8 2.500-8 2.500H22Z" fill={PAL.steel} {...S} strokeWidth="1.200" />
          </g>
          <Wheel cx={26} cy={66} r={9} />
          <Wheel cx={70} cy={66} r={9} />
        </g>
      );
      break;
    case 4: // требюше
      body = (
        <g>
          <path d="M14 66 34 24h12l4 42Z M84 66 62 24" fill={PAL.wood} {...S} />
          <path d="M28 66 44 36" stroke={PAL.woodDark} strokeWidth="3" />
          <rect x="6" y="66" width="86" height="8" rx="3" fill={PAL.woodDark} {...S} />
          <g className="fg-rot" style={{ transformBox: 'view-box', transformOrigin: '44px 30px' }}>
            <path d="M14 8 70 40" stroke={OUTLINE} strokeWidth="8" strokeLinecap="round" />
            <path
              d="M14 8 70 40"
              stroke={lighten(PAL.wood, 0.1)}
              strokeWidth="5"
              strokeLinecap="round"
            />
            <rect x="60" y="38" width="16" height="16" rx="3" fill={PAL.stoneDark} {...S} />
            <circle cx="14" cy="8" r="6" fill={PAL.stone} {...S} />
          </g>
          <circle cx="40" cy="30" r="4" fill={PAL.steel} {...S} />
        </g>
      );
      break;
    case 5: // бомбарда
      body = (
        <g>
          <path d="M14 58 24 40h50l10 18Z" fill={PAL.wood} {...S} />
          <g className="fg-recoil">
            <path d="M14 34c-4 4-4 12 0 16l52 4 12-4V30l-12-4Z" fill="#4a4f56" {...S} />
            <path d="M18 34l50-6M18 50l50 4" stroke="#8a95a0" strokeWidth="2" opacity=".7" />
            <ellipse cx="78" cy="42" rx="6" ry="12" fill="#1f2226" {...S} />
            <path d="M34 26v26M48 24v30M62 26v28" stroke="#8a95a0" strokeWidth="3" />
          </g>
          <circle cx="86" cy="36" r="4" fill="#ffb14a" className="fg-flash" opacity="0" />
          <Wheel cx={28} cy={64} r={10} />
          <Wheel cx={70} cy={64} r={10} />
        </g>
      );
      break;
    default: // 2 — катапульта
      body = (
        <g>
          <path d="M14 62 28 30h40l14 32Z" fill={PAL.wood} {...S} />
          <path d="M28 30h40M20 50h56" stroke={PAL.woodDark} strokeWidth="2.400" />
          <g className="fg-rot" style={{ transformBox: 'view-box', transformOrigin: '46px 60px' }}>
            <path d="M42 62 68 10l7 3-24 50Z" fill={lighten(PAL.wood, 0.1)} {...S} />
            <path d="M62 12c4-6 12-8 18-4 2 4 0 9-5 11-6 2-10 0-13-7Z" fill="#7a5a34" {...S} />
            <circle cx="80" cy="6" r="7.500" fill={PAL.stone} {...S} />
            <path
              d="M76 3c1-1 3-1.500 4-1"
              stroke="#fff"
              strokeWidth="1.600"
              opacity=".6"
              fill="none"
              strokeLinecap="round"
            />
          </g>
          <Wheel cx={26} cy={64} />
          <Wheel cx={70} cy={64} />
        </g>
      );
  }
  return (
    <Wide size={size} title={title} anim={anim}>
      {shadow}
      {body}
    </Wide>
  );
}

/** Портрет войска по роду и уровню. */
export function UnitArt({
  type,
  tier = 3,
  size = 64,
  title,
  className,
  anim = 'none',
  delay = 0,
}: {
  type: UnitType;
  tier?: UnitTier;
  size?: number;
  title?: string;
  className?: string;
  anim?: FigureAnim;
  delay?: number;
}) {
  const style = delay
    ? ({ '--fg-d': `${delay}s`, display: 'inline-flex' } as React.CSSProperties)
    : undefined;
  const art =
    type === 'siege' ? (
      <Siege tier={tier} size={size} title={title} anim={anim} />
    ) : type === 'cavalry' ? (
      <Cavalry tier={tier} size={size} title={title} anim={anim} />
    ) : (
      <Figure
        spec={UNIT_SPEC[type][tier]}
        size={size}
        title={title}
        className={className}
        anim={anim}
      />
    );
  return style ? <span style={style}>{art}</span> : art;
}

export interface HeroGear {
  /** Редкость надетого предмета в слоте, 0 — пусто. */
  weapon: number;
  armor: number;
  relic: number;
  /** Шлем открывается с ростом уровня: 0 — нет, 1–3. */
  helmet: number;
}

const WEAPON_BY_RARITY: Record<number, FigureSpec['weapon']> = {
  0: 'none',
  1: 'dagger',
  2: 'sword',
  3: 'axe',
  4: 'greatsword',
  5: 'flame',
};
const ARMOR_BY_RARITY: Record<number, NonNullable<FigureSpec['armor']>> = {
  0: 'cloth',
  1: 'cloth',
  2: 'leather',
  3: 'chain',
  4: 'plate',
  5: 'royal',
};
const AURA_BY_RARITY: Record<number, string | null> = {
  0: null,
  1: null,
  2: null,
  3: '#7fd6ff',
  4: '#c17bff',
  5: '#ffd24a',
};

/** Герой: каждый надетый предмет меняет облик (оружие, доспех, реликвия-аура, шлем — по уровню). */
export function heroSpec(gear: HeroGear): FigureSpec {
  const armorColors = ['#7a6a55', '#7a6a55', '#8a5a34', '#5a6a80', '#5a6a80', '#c9a020'];
  const armor = ARMOR_BY_RARITY[gear.armor] ?? 'cloth';
  const helm = gear.helmet;
  return base({
    outfit: armorColors[Math.min(gear.armor, 5)] ?? '#7a6a55',
    trim: gear.armor >= 4 ? PAL.gold : '#e8d6a8',
    armor,
    pauldrons: gear.armor >= 4,
    head:
      helm === 0
        ? 'none'
        : helm === 1
          ? 'cap'
          : helm === 2
            ? gear.armor >= 4
              ? 'knight'
              : 'helm'
            : 'crown',
    headColor: helm === 1 ? '#7a5a3a' : helm === 2 ? '#b8c4cc' : PAL.gold,
    weapon: WEAPON_BY_RARITY[gear.weapon] ?? 'none',
    shield:
      gear.armor >= 5 ? 'kite' : gear.armor >= 3 ? 'round' : gear.armor >= 2 ? 'buckler' : 'none',
    shieldColor: gear.armor >= 4 ? '#2f5fae' : '#8a5a34',
    cape: gear.armor >= 4 ? '#b32626' : gear.armor >= 2 ? '#6a2f2f' : null,
    aura: AURA_BY_RARITY[gear.relic] ?? null,
    hair: '#3a2416',
  });
}

/** Герой-«кукла» с экипировкой. */
export function HeroArt({
  gear,
  size = 160,
  title,
  anim = 'idle',
}: {
  gear: HeroGear;
  size?: number;
  title?: string;
  anim?: FigureAnim;
}) {
  return <Figure spec={heroSpec(gear)} size={size} title={title} anim={anim} />;
}

/** Жители, советники и враги на карте. */
export const NPC_SPEC = {
  peasant: base({
    outfit: '#a8874a',
    trim: '#e8d6a8',
    head: 'hat',
    weapon: 'hammer',
    hair: '#7a5a2a',
  }),
  farmer: base({
    outfit: '#6a8a4a',
    trim: '#e8d6a8',
    head: 'hat',
    weapon: 'torch',
    hair: '#7a5a2a',
    pants: '#6a5236',
  }),
  blacksmith: base({
    outfit: '#5a4636',
    trim: '#c98a1a',
    pants: '#3a2a20',
    head: 'none',
    weapon: 'hammer',
    hair: '#2a1a10',
    beard: true,
    bulk: 1.2,
  }),
  guard: base({
    outfit: '#2f5fae',
    armor: 'chain',
    head: 'helm',
    weapon: 'spear',
    shield: 'round',
    shieldColor: '#2f5fae',
  }),
  captain: base({
    outfit: '#2f5fae',
    armor: 'plate',
    head: 'crest',
    headColor: '#b8c4cc',
    weapon: 'sword',
    shield: 'kite',
    shieldColor: '#2f5fae',
    cape: '#b32626',
    pauldrons: true,
  }),
  scholar: base({
    outfit: '#5a4aa8',
    trim: '#f2cf6b',
    armor: 'robe',
    head: 'hood',
    headColor: '#5a4aa8',
    weapon: 'staff',
    hair: '#bcbcbc',
    beard: true,
  }),
  mage: base({
    outfit: '#3a4aa8',
    trim: '#f2cf6b',
    armor: 'robe',
    head: 'wizard',
    headColor: '#3a4aa8',
    weapon: 'staff',
    hair: '#e8e8e8',
    beard: true,
    aura: '#7fb0ff',
  }),
  healer: base({
    outfit: '#f3ead0',
    trim: '#4f9a3a',
    armor: 'robe',
    head: 'circlet',
    weapon: 'wand',
    hair: '#c98a3a',
    longHair: true,
  }),
  elder: base({
    outfit: '#7a3a3a',
    trim: '#f2cf6b',
    armor: 'robe',
    head: 'none',
    weapon: 'staff',
    hair: '#e8e8e8',
    beard: true,
    cape: '#3f6fb8',
  }),
  advisor: base({
    outfit: '#2a5a8a',
    trim: PAL.gold,
    armor: 'robe',
    head: 'cap',
    headColor: '#2a5a8a',
    hair: '#3a2416',
    cape: '#7a2a2a',
  }),
  merchant: base({
    outfit: '#c98a1a',
    trim: '#f3ead0',
    head: 'hat',
    hair: '#3a2416',
    beard: true,
    weapon: 'none',
  }),
  queen: base({
    outfit: '#7a2a8a',
    trim: '#f3ead0',
    armor: 'robe',
    head: 'crown',
    hair: '#4a2a1a',
    longHair: true,
    cape: '#5a1a6a',
    weapon: 'wand',
  }),
  king: base({
    outfit: '#8a1f2a',
    trim: '#f3ead0',
    armor: 'royal',
    head: 'crown',
    hair: '#5a3a22',
    beard: true,
    cape: '#b32626',
    weapon: 'staff',
    bulk: 1.1,
  }),
  // враги на карте
  bandit: base({
    outfit: '#6a4a3a',
    trim: '#3a2a20',
    pants: '#3a2a20',
    head: 'hood',
    headColor: '#4a3a30',
    weapon: 'club',
  }),
  thief: base({
    outfit: '#3a3a44',
    trim: '#8a95a0',
    pants: '#2a2a30',
    armor: 'leather',
    head: 'mask',
    headColor: '#3a3a44',
    weapon: 'dagger',
  }),
  banditArcher: base({
    outfit: '#5a4a2a',
    trim: '#3a2a20',
    pants: '#3a2a20',
    armor: 'leather',
    head: 'hood',
    headColor: '#4a4a2a',
    weapon: 'bow',
  }),
  raider: base({
    skin: '#7ea45a',
    hair: null,
    fangs: true,
    outfit: '#7a3a2a',
    trim: '#3a2a20',
    armor: 'chain',
    head: 'helm',
    headColor: '#6f7c86',
    weapon: 'axe',
    shield: 'round',
    shieldColor: '#5a3620',
    bulk: 1.15,
  }),
  shaman: base({
    skin: '#7ea45a',
    hair: null,
    fangs: true,
    outfit: '#4a6a2a',
    trim: '#c98a1a',
    armor: 'robe',
    head: 'wizard',
    headColor: '#3a5a2a',
    weapon: 'staff',
    aura: '#8aff6a',
  }),
  ogre: base({
    skin: '#8a9a5a',
    hair: null,
    fangs: true,
    outfit: '#6a5a3a',
    trim: '#3a2a20',
    head: 'none',
    weapon: 'club',
    bulk: 1.55,
  }),
  warlord: base({
    skin: '#6a9a4a',
    hair: null,
    fangs: true,
    outfit: '#4a1f2a',
    trim: PAL.gold,
    armor: 'plate',
    head: 'viking',
    headColor: '#4a4f56',
    weapon: 'hammer',
    cape: '#2a1418',
    shield: 'kite',
    shieldColor: '#2a1418',
    bulk: 1.3,
    pauldrons: true,
  }),
} as const satisfies Record<string, FigureSpec>;

export type NpcName = keyof typeof NPC_SPEC;

export function NpcArt({
  name,
  size = 64,
  title,
  flip,
  className,
  anim = 'idle',
  delay = 0,
}: {
  name: NpcName;
  size?: number;
  title?: string;
  flip?: boolean;
  className?: string;
  anim?: FigureAnim;
  delay?: number;
}) {
  return (
    <Figure
      spec={NPC_SPEC[name]}
      size={size}
      title={title}
      flip={flip}
      className={className}
      anim={anim}
      delay={delay}
    />
  );
}
