/** Цветовые помощники для векторной графики: два тона (свет/тень) из одного базового цвета. */

const clamp = (v: number): number => Math.max(0, Math.min(255, Math.round(v)));

function parse(hex: string): [number, number, number] {
  const h = hex.replace('#', '');
  const n = h.length === 3 ? [...h].map((c) => c + c).join('') : h;
  return [
    Number.parseInt(n.slice(0, 2), 16),
    Number.parseInt(n.slice(2, 4), 16),
    Number.parseInt(n.slice(4, 6), 16),
  ];
}

const toHex = (r: number, g: number, b: number): string =>
  `#${[r, g, b].map((v) => clamp(v).toString(16).padStart(2, '0')).join('')}`;

/** Смешивает цвет с другим: t=0 — исходный, t=1 — второй. */
export function mix(a: string, b: string, t: number): string {
  const [ar, ag, ab] = parse(a);
  const [br, bg, bb] = parse(b);
  return toHex(ar + (br - ar) * t, ag + (bg - ag) * t, ab + (bb - ab) * t);
}

export const lighten = (hex: string, t = 0.25): string => mix(hex, '#ffffff', t);
export const darken = (hex: string, t = 0.25): string => mix(hex, '#000000', t);

/** Контур всех фигур — тёмный тёплый коричневый, как у остальной темы. */
export const OUTLINE = '#2a1a0e';

export const PAL = {
  gold: '#e0b030',
  goldDark: '#9a6c12',
  wood: '#8a5a34',
  woodDark: '#5a3620',
  stone: '#9a9a9a',
  stoneDark: '#5e6066',
  steel: '#b8c4cc',
  steelDark: '#6f7c86',
  leaf: '#4f9a3a',
  leafDark: '#2f6a2a',
  gem: '#39b6f0',
  red: '#b32626',
  blue: '#2f5fae',
  cloth: '#e8d6a8',
  skin: '#f0c49a',
  skinDark: '#d69c72',
} as const;
