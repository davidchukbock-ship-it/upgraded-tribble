import { useTranslation } from 'react-i18next';
import type { ResourceKey } from '@tc/shared';
import { ArtIcon } from '../art';
import { cn } from '../lib/cn';
import { formatFull, formatNumber } from '../lib/format';

export interface ResourceAmount {
  key: ResourceKey | 'gems';
  amount: number;
  /** Ёмкость склада; для кристаллов не задаётся. */
  cap?: number;
}

const COLOR: Record<ResourceAmount['key'], string> = {
  gold: 'text-gold-light',
  wood: 'text-[#d9a066]',
  stone: 'text-[#d3ccc2]',
  food: 'text-[#9bd16f]',
  gems: 'text-[#8fd8ff]',
};

export function ResourceBar({
  items,
  className,
}: {
  items: readonly ResourceAmount[];
  className?: string;
}) {
  const { t } = useTranslation();
  return (
    <ul
      className={cn('flex flex-wrap items-center gap-1 md:gap-2', className)}
      aria-label={t('nav.castle')}
    >
      {items.map(({ key, amount, cap }) => {
        const full = cap !== undefined && amount >= cap;
        const name = t(`resource.${key}`);
        const spoken =
          cap === undefined
            ? formatFull(amount)
            : `${formatFull(amount)} ${t('common.of')} ${formatFull(cap)}`;
        return (
          <li
            key={key}
            title={`${name}: ${spoken}`}
            aria-label={`${name}: ${spoken}`}
            className={cn(
              'res-pill flex items-center gap-1 rounded-full border-2 py-0.5 pl-0.5 pr-2 text-xs font-bold md:gap-1.5 md:py-1 md:pl-1 md:pr-3 md:text-sm',
              full ? 'border-red' : 'border-gold-dark',
              COLOR[key],
            )}
          >
            <ArtIcon name={key} size={22} />
            <span aria-hidden="true">{formatNumber(amount)}</span>
            {cap !== undefined && cap > 0 && (
              <span
                aria-hidden="true"
                className="res-pill-fill"
                style={{ width: `${Math.min(100, (amount / cap) * 100)}%` }}
              />
            )}
          </li>
        );
      })}
    </ul>
  );
}
