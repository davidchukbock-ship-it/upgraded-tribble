import type { HTMLAttributes, ReactNode } from 'react';
import { cn } from '../lib/cn';

interface PanelProps extends Omit<HTMLAttributes<HTMLElement>, 'title'> {
  tone?: 'wood' | 'parchment';
  title?: ReactNode;
}

/** Деревянная панель с металлической окантовкой или пергамент; заголовок — лентой. */
export function Panel({ tone = 'wood', title, className, children, ...rest }: PanelProps) {
  return (
    <section
      className={cn(
        tone === 'wood' ? 'panel-wood' : 'panel-parchment',
        'frame-pixel',
        'relative p-4',
        title && 'pt-9',
        className,
      )}
      {...rest}
    >
      {title && (
        <h2 className="ribbon absolute -top-3 left-1/2 max-w-[calc(100%-1rem)] -translate-x-1/2 text-center text-sm sm:whitespace-nowrap sm:text-base">
          {title}
        </h2>
      )}
      {children}
    </section>
  );
}
