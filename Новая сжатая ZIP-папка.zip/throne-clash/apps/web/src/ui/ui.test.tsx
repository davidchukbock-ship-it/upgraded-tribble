import { act, render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { useState } from 'react';
import { I18nextProvider } from 'react-i18next';
import { beforeAll, describe, expect, it, vi } from 'vitest';
import { Crest } from '../icons/Crest';
import { i18n, initI18n } from '../lib/i18n';
import { useClock } from '../store/clock';
import {
  Button,
  ConfirmDialog,
  ItemCard,
  ProgressBar,
  ResourceBar,
  ScrollModal,
  Tabs,
  TextField,
  TimerProgress,
  Tooltip,
} from '.';

beforeAll(async () => {
  await initI18n('ru');
});

const wrap = (ui: React.ReactElement) =>
  render(<I18nextProvider i18n={i18n}>{ui}</I18nextProvider>);

describe('Button', () => {
  it('блокируется и помечается занятым при loading', async () => {
    const onClick = vi.fn();
    wrap(
      <Button loading onClick={onClick}>
        Go
      </Button>,
    );
    const btn = screen.getByRole('button', { name: 'Go' });
    expect(btn).toBeDisabled();
    expect(btn).toHaveAttribute('aria-busy', 'true');
    await userEvent.click(btn);
    expect(onClick).not.toHaveBeenCalled();
  });
});

describe('ProgressBar', () => {
  it('ограничивает значение диапазоном', () => {
    wrap(<ProgressBar label="p" value={50} max={10} />);
    expect(screen.getByRole('progressbar', { name: 'p' })).toHaveAttribute('aria-valuenow', '10');
  });
});

describe('TimerProgress', () => {
  it('показывает остаток по серверным часам и вызывает onDone один раз', () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date('2030-01-01T00:00:00Z'));
    useClock.setState({ offsetMs: 0 });
    const t0 = Date.now();
    const onDone = vi.fn();
    wrap(<TimerProgress label="t" startsAtMs={t0} endsAtMs={t0 + 3000} onDone={onDone} />);
    expect(screen.getByText('3с')).toBeInTheDocument();
    act(() => void vi.advanceTimersByTime(5000));
    expect(screen.getByText('0с')).toBeInTheDocument();
    expect(onDone).toHaveBeenCalledTimes(1);
    vi.useRealTimers();
  });

  it('учитывает смещение серверного времени', () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date('2030-01-01T00:00:00Z'));
    useClock.setState({ offsetMs: 60_000 }); // сервер на минуту впереди
    const t0 = Date.now() + 60_000;
    wrap(<TimerProgress label="t" startsAtMs={t0} endsAtMs={t0 + 10_000} />);
    expect(screen.getByText('10с')).toBeInTheDocument();
    useClock.setState({ offsetMs: 0 });
    vi.useRealTimers();
  });
});

describe('ResourceBar', () => {
  it('озвучивает полные значения и вместимость', () => {
    wrap(
      <ResourceBar
        items={[
          { key: 'gold', amount: 12_345, cap: 50_000 },
          { key: 'gems', amount: 5 },
        ]}
      />,
    );
    expect(screen.getByLabelText('Золото: 12 345 из 50 000')).toBeInTheDocument();
    expect(screen.getByLabelText('Кристаллы: 5')).toBeInTheDocument();
  });
});

describe('Tabs', () => {
  function Demo() {
    const [v, setV] = useState('a');
    return (
      <Tabs
        value={v}
        onChange={setV}
        items={[
          { id: 'a', label: 'A', content: <p>content-a</p> },
          { id: 'b', label: 'B', content: <p>content-b</p> },
        ]}
      />
    );
  }
  it('переключается стрелками с циклическим переходом', async () => {
    wrap(<Demo />);
    const a = screen.getByRole('tab', { name: 'A' });
    a.focus();
    await userEvent.keyboard('{ArrowRight}');
    expect(screen.getByRole('tab', { name: 'B' })).toHaveAttribute('aria-selected', 'true');
    expect(screen.getByText('content-b')).toBeInTheDocument();
    await userEvent.keyboard('{ArrowRight}');
    expect(screen.getByRole('tab', { name: 'A' })).toHaveAttribute('aria-selected', 'true');
    expect(screen.getByRole('tab', { name: 'B' })).toHaveAttribute('tabindex', '-1');
  });
});

describe('Tooltip', () => {
  it('появляется по фокусу и закрывается по Esc', async () => {
    wrap(
      <Tooltip content="hint">
        <button type="button">x</button>
      </Tooltip>,
    );
    await userEvent.tab();
    expect(screen.getByRole('tooltip')).toHaveTextContent('hint');
    expect(screen.getByRole('button', { name: 'x' })).toHaveAttribute('aria-describedby');
    await userEvent.keyboard('{Escape}');
    expect(screen.queryByRole('tooltip')).toBeNull();
  });
});

describe('ItemCard', () => {
  it('с onClick — кнопка, без — не интерактивен', async () => {
    const onClick = vi.fn();
    wrap(
      <>
        <ItemCard icon="sword" name="Меч" onClick={onClick} />
        <ItemCard icon="shield" name="Щит" />
      </>,
    );
    await userEvent.click(screen.getByRole('button', { name: /Меч/ }));
    expect(onClick).toHaveBeenCalled();
    expect(screen.queryByRole('button', { name: /Щит/ })).toBeNull();
  });
});

describe('ScrollModal', () => {
  function Demo({ onClose }: { onClose: () => void }) {
    return (
      <>
        <button type="button">opener</button>
        <ScrollModal open title="T" onClose={onClose} footer={<button type="button">last</button>}>
          <button type="button">first</button>
        </ScrollModal>
      </>
    );
  }

  it('имеет роль dialog, подпись и закрывается по Esc', async () => {
    const onClose = vi.fn();
    wrap(<Demo onClose={onClose} />);
    const dialog = screen.getByRole('dialog', { name: 'T' });
    expect(dialog).toHaveAttribute('aria-modal', 'true');
    await userEvent.keyboard('{Escape}');
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  it('удерживает Tab внутри окна', async () => {
    wrap(<Demo onClose={() => undefined} />);
    const dialog = screen.getByRole('dialog');
    const last = within(dialog).getByRole('button', { name: 'last' });
    last.focus();
    await userEvent.tab();
    expect(dialog.contains(document.activeElement)).toBe(true);
    expect(document.activeElement).not.toBe(last);
    await userEvent.tab({ shift: true });
    expect(dialog.contains(document.activeElement)).toBe(true);
  });

  it('блокирует прокрутку страницы и возвращает её при закрытии', () => {
    const { rerender } = wrap(
      <ScrollModal open title="T" onClose={() => undefined}>
        x
      </ScrollModal>,
    );
    expect(document.body.style.overflow).toBe('hidden');
    rerender(
      <I18nextProvider i18n={i18n}>
        <ScrollModal open={false} title="T" onClose={() => undefined}>
          x
        </ScrollModal>
      </I18nextProvider>,
    );
    expect(document.body.style.overflow).not.toBe('hidden');
  });
});

describe('ConfirmDialog', () => {
  it('фокус на «Отмена»; подтверждение вызывает onConfirm', async () => {
    const onConfirm = vi.fn();
    const onCancel = vi.fn();
    wrap(
      <ConfirmDialog
        open
        title="Снести?"
        message="msg"
        onConfirm={onConfirm}
        onCancel={onCancel}
      />,
    );
    expect(screen.getByRole('alertdialog', { name: 'Снести?' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Отмена' })).toHaveFocus();
    await userEvent.click(screen.getByRole('button', { name: 'Подтвердить' }));
    expect(onConfirm).toHaveBeenCalledTimes(1);
    expect(onCancel).not.toHaveBeenCalled();
  });
});

describe('Tabs tone', () => {
  it('на пергаменте неактивные вкладки тёмные (не сливаются с фоном)', () => {
    wrap(
      <Tabs
        tone="parchment"
        value="a"
        onChange={() => undefined}
        items={[
          { id: 'a', label: 'A', content: null },
          { id: 'b', label: 'B', content: null },
        ]}
      />,
    );
    const cls = screen.getByRole('tab', { name: 'B' }).className;
    expect(cls).toContain('text-ink');
    expect(cls).not.toContain('text-parchment');
  });
});

describe('TextField', () => {
  it('связывает подпись, подсказку и ошибку с полем', () => {
    wrap(<TextField label="Ник" hint="3–20 символов" error="Слишком коротко" />);
    const input = screen.getByLabelText('Ник');
    expect(input).toHaveAttribute('aria-invalid', 'true');
    // при ошибке подсказка заменяется ошибкой — скринридер читает одно, а не оба
    expect(input).toHaveAccessibleDescription('Слишком коротко');
  });

  it('без ошибки описанием служит подсказка', () => {
    wrap(<TextField label="Ник" hint="3–20 символов" />);
    expect(screen.getByLabelText('Ник')).toHaveAccessibleDescription('3–20 символов');
    expect(screen.getByLabelText('Ник')).not.toHaveAttribute('aria-invalid');
  });
});

describe('Crest', () => {
  it('декоративный по умолчанию, с title — озвучивается; неизвестный герб не ломает отрисовку', () => {
    const { container, rerender } = render(<Crest crest="wolf" />);
    expect(container.querySelector('svg')).toHaveAttribute('aria-hidden', 'true');
    rerender(<Crest crest="wolf" title="Волк" />);
    expect(screen.getByRole('img', { name: 'Волк' })).toBeInTheDocument();
    rerender(<Crest crest="dragon" />);
    expect(container.querySelector('svg path')).toBeTruthy();
  });
});
