import { forwardRef, type ButtonHTMLAttributes } from 'react';
import { cn } from '../lib/cn';

export type ButtonVariant = 'primary' | 'danger' | 'gold';

const VARIANT: Record<ButtonVariant, string> = {
  // Белый текст на #3D7E21 / #A61E1E — контраст ≥ 4.5 (D-17); на золоте — тёмный текст
  primary: 'bg-green-btn text-white',
  danger: 'bg-red text-white',
  gold: 'bg-gold text-ink',
};

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  /** Показывает спиннер и блокирует кнопку. */
  loading?: boolean;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { variant = 'primary', loading = false, className, disabled, children, type = 'button', ...rest },
  ref,
) {
  return (
    <button
      ref={ref}
      type={type}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      className={cn(
        'btn-3d inline-flex min-h-[44px] items-center justify-center gap-2 px-5 py-2 text-base',
        VARIANT[variant],
        className,
      )}
      {...rest}
    >
      {loading && (
        <span
          aria-hidden="true"
          className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"
        />
      )}
      {children}
    </button>
  );
});
