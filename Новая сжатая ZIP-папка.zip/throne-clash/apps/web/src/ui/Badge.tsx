import type { HTMLAttributes } from 'react';
import { cn } from '../lib/cn';

export type BadgeTone = 'gold' | 'green' | 'red' | 'stone';

const TONE: Record<BadgeTone, string> = {
  gold: 'bg-gold text-ink',
  green: 'bg-green-btn text-white',
  red: 'bg-red text-white',
  stone: 'bg-stone-dark text-parchment',
};

export function Badge({
  tone = 'gold',
  className,
  ...rest
}: HTMLAttributes<HTMLSpanElement> & { tone?: BadgeTone }) {
  return (
    <span
      className={cn(
        'inline-flex min-w-[1.5rem] items-center justify-center rounded-full px-2 py-0.5 text-xs font-semibold',
        TONE[tone],
        className,
      )}
      {...rest}
    />
  );
}
