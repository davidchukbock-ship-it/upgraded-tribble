import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { cn } from '../lib/cn';
import { formatDurationT } from '../lib/duration';
import { useClock } from '../store/clock';

interface ProgressBarProps {
  value: number;
  max: number;
  label: string;
  /** Текст поверх полосы (например, «5 / 10»). */
  text?: string;
  className?: string;
}

export function ProgressBar({ value, max, label, text, className }: ProgressBarProps) {
  const pct = max > 0 ? Math.min(100, Math.max(0, (value / max) * 100)) : 0;
  return (
    <div
      role="progressbar"
      aria-label={label}
      aria-valuemin={0}
      aria-valuemax={max}
      aria-valuenow={Math.min(Math.max(value, 0), max)}
      className={cn(
        'relative h-5 overflow-hidden rounded-full border-2 border-black/50 bg-black/40',
        className,
      )}
    >
      <div
        className="h-full bg-green transition-[width] duration-300"
        style={{ width: `${pct}%` }}
      />
      {text && (
        <span className="absolute inset-0 flex items-center justify-center text-xs font-semibold text-white [text-shadow:0_1px_2px_#000]">
          {text}
        </span>
      )}
    </div>
  );
}

interface TimerProgressProps {
  /** Момент старта и конца (мс, серверное время). */
  startsAtMs: number;
  endsAtMs: number;
  label: string;
  onDone?: () => void;
  className?: string;
}

/** Полоса с обратным отсчётом по серверным часам (смещение из useClock). */
export function TimerProgress({
  startsAtMs,
  endsAtMs,
  label,
  onDone,
  className,
}: TimerProgressProps) {
  const { t } = useTranslation();
  const now = useClock((s) => s.now);
  const [current, setCurrent] = useState(() => now());

  useEffect(() => {
    let done = false;
    const tick = () => {
      const t = now();
      setCurrent(t);
      if (!done && t >= endsAtMs) {
        done = true;
        onDone?.();
      }
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [now, endsAtMs, onDone]);

  const total = Math.max(1, endsAtMs - startsAtMs);
  const left = Math.max(0, Math.ceil((endsAtMs - current) / 1000));
  return (
    <ProgressBar
      className={className}
      label={label}
      value={Math.min(total, current - startsAtMs)}
      max={total}
      text={formatDurationT(t, left)}
    />
  );
}
