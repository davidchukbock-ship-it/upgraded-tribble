import type { ReactNode } from 'react';
import { Icon, type IconName } from '../icons/Icon';
import { cn } from '../lib/cn';

export type Rarity = 'common' | 'rare' | 'epic' | 'legendary';

const RARITY: Record<Rarity, string> = {
  common: 'border-stone',
  rare: 'border-[#4a8fd6]',
  epic: 'border-[#a35bd6]',
  legendary: 'border-gold',
};

interface ItemCardProps {
  icon: IconName;
  name: string;
  rarity?: Rarity;
  count?: number;
  footer?: ReactNode;
  onClick?: () => void;
  className?: string;
}

/** Карточка предмета/здания/юнита. С onClick — кнопка, без — статичный блок. */
export function ItemCard({
  icon,
  name,
  rarity = 'common',
  count,
  footer,
  onClick,
  className,
}: ItemCardProps) {
  const body = (
    <>
      <span className="relative flex h-14 w-14 items-center justify-center rounded-lg bg-black/40 text-gold-light">
        <Icon name={icon} size={32} />
        {count !== undefined && (
          <span className="absolute -bottom-1 -right-1 rounded-full bg-black px-1.5 text-xs font-semibold text-parchment">
            {count}
          </span>
        )}
      </span>
      <span className="text-center text-sm font-semibold leading-tight">{name}</span>
      {footer}
    </>
  );
  const cls = cn(
    'panel-wood flex w-28 flex-col items-center gap-2 border-2 p-3 !shadow-none',
    RARITY[rarity],
    onClick && 'cursor-pointer hover:brightness-110',
    className,
  );
  return onClick ? (
    <button type="button" onClick={onClick} className={cls}>
      {body}
    </button>
  ) : (
    <div className={cls}>{body}</div>
  );
}
