import { useTranslation } from 'react-i18next';
import { Button, type ButtonVariant } from './Button';
import { ScrollModal } from './ScrollModal';

interface ConfirmDialogProps {
  open: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  tone?: ButtonVariant;
  onConfirm: () => void;
  onCancel: () => void;
}

/** Подтверждение опасных действий. Фокус — на «Отмена», чтобы случайный Enter ничего не сносил. */
export function ConfirmDialog({
  open,
  title,
  message,
  confirmLabel,
  tone = 'danger',
  onConfirm,
  onCancel,
}: ConfirmDialogProps) {
  const { t } = useTranslation();
  return (
    <ScrollModal
      open={open}
      alert
      title={title}
      onClose={onCancel}
      footer={
        <>
          <Button variant="gold" data-autofocus onClick={onCancel}>
            {t('common.cancel')}
          </Button>
          <Button variant={tone} onClick={onConfirm}>
            {confirmLabel ?? t('common.confirm')}
          </Button>
        </>
      }
    >
      <p>{message}</p>
    </ScrollModal>
  );
}
