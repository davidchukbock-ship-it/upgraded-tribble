import { useTranslation } from 'react-i18next';
import { Icon } from '../icons/Icon';
import { useAudio } from '../store/audio';
import { Button } from './Button';

/** Кнопка «звук вкл/выкл» для оболочки: выключает и музыку, и звуки одним нажатием. */
export function SoundToggle({ className }: { className?: string }) {
  const { t } = useTranslation();
  const on = useAudio((s) => s.music || s.sfx);
  const set = useAudio((s) => s.set);
  return (
    <Button
      variant="gold"
      className={className}
      data-nosound
      aria-pressed={on}
      aria-label={on ? t('audio.toggleOn') : t('audio.toggleOff')}
      onClick={() => (on ? set({ music: false, sfx: false }) : set({ music: true, sfx: true }))}
    >
      <Icon name={on ? 'sound' : 'soundOff'} size={18} />
    </Button>
  );
}

function Slider({
  id,
  label,
  value,
  onChange,
  disabled,
}: {
  id: string;
  label: string;
  value: number;
  onChange: (v: number) => void;
  disabled: boolean;
}) {
  return (
    <label htmlFor={id} className="flex items-center gap-3 text-sm">
      <span className="w-28 shrink-0 sm:w-44">{label}</span>
      <input
        id={id}
        type="range"
        min={0}
        max={1}
        step={0.05}
        value={value}
        disabled={disabled}
        onChange={(e) => onChange(Number(e.target.value))}
        className="min-h-[32px] min-w-0 flex-1 accent-[var(--gold)]"
      />
      <span className="w-10 text-right tabular-nums">{Math.round(value * 100)}%</span>
    </label>
  );
}

/** Настройки звука для профиля: включение и громкость музыки и эффектов отдельно. */
export function SoundSettings() {
  const { t } = useTranslation();
  const s = useAudio();
  return (
    <div className="flex flex-col gap-3 pt-2">
      <p className="text-sm opacity-90">{t('audio.hint')}</p>
      <label className="flex items-center gap-2 text-sm">
        <input
          type="checkbox"
          checked={s.music}
          onChange={(e) => s.set({ music: e.target.checked })}
          className="h-5 w-5 accent-[var(--gold)]"
        />
        {t('audio.music')}
      </label>
      <Slider
        id="vol-music"
        label={t('audio.musicVolume')}
        value={s.musicVolume}
        disabled={!s.music}
        onChange={(v) => s.set({ musicVolume: v })}
      />
      <label className="flex items-center gap-2 text-sm">
        <input
          type="checkbox"
          checked={s.sfx}
          onChange={(e) => s.set({ sfx: e.target.checked })}
          className="h-5 w-5 accent-[var(--gold)]"
        />
        {t('audio.sfx')}
      </label>
      <Slider
        id="vol-sfx"
        label={t('audio.sfxVolume')}
        value={s.sfxVolume}
        disabled={!s.sfx}
        onChange={(v) => s.set({ sfxVolume: v })}
      />
    </div>
  );
}
