import { useId, useRef, type KeyboardEvent, type ReactNode } from 'react';
import { cn } from '../lib/cn';

export interface TabItem {
  id: string;
  label: string;
  content: ReactNode;
}

interface TabsProps {
  items: readonly TabItem[];
  value: string;
  onChange: (id: string) => void;
  /** Фон, на котором лежат вкладки: от него зависит цвет неактивных (контраст). */
  tone?: 'wood' | 'parchment';
}

/** ARIA-вкладки: стрелки/Home/End переключают, в Tab-порядке только активная. */
export function Tabs({ items, value, onChange, tone = 'wood' }: TabsProps) {
  const base = useId();
  const refs = useRef<Record<string, HTMLButtonElement | null>>({});

  const move = (index: number) => {
    const next = items[(index + items.length) % items.length];
    if (!next) return;
    onChange(next.id);
    refs.current[next.id]?.focus();
  };

  const onKeyDown = (e: KeyboardEvent, index: number) => {
    if (e.key === 'ArrowRight') move(index + 1);
    else if (e.key === 'ArrowLeft') move(index - 1);
    else if (e.key === 'Home') move(0);
    else if (e.key === 'End') move(items.length - 1);
    else return;
    e.preventDefault();
  };

  const active = items.find((i) => i.id === value) ?? items[0];
  return (
    <div>
      <div role="tablist" className="flex gap-1 overflow-x-auto border-b-4 border-stone pb-0">
        {items.map((item, i) => {
          const selected = item.id === active?.id;
          return (
            <button
              key={item.id}
              ref={(el) => {
                refs.current[item.id] = el;
              }}
              role="tab"
              type="button"
              id={`${base}-tab-${item.id}`}
              aria-selected={selected}
              aria-controls={`${base}-panel-${item.id}`}
              tabIndex={selected ? 0 : -1}
              onClick={() => onChange(item.id)}
              onKeyDown={(e) => onKeyDown(e, i)}
              className={cn(
                'min-h-[44px] whitespace-nowrap rounded-t-lg border-2 border-b-0 px-4 font-display text-sm font-bold',
                selected
                  ? 'border-stone bg-parchment text-ink'
                  : tone === 'parchment'
                    ? 'border-transparent text-ink hover:bg-black/10'
                    : 'border-transparent text-parchment hover:bg-black/25',
              )}
            >
              {item.label}
            </button>
          );
        })}
      </div>
      {active && (
        <div
          role="tabpanel"
          id={`${base}-panel-${active.id}`}
          aria-labelledby={`${base}-tab-${active.id}`}
          className="pt-4"
        >
          {active.content}
        </div>
      )}
    </div>
  );
}
