import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { initI18n } from '../lib/i18n';
import { useAudio } from '../store/audio';
import { SoundToggle } from './SoundControls';

beforeAll(async () => {
  await initI18n('ru');
});
beforeEach(() => useAudio.getState().set({ music: true, sfx: true }));

describe('переключатель звука', () => {
  it('одним нажатием выключает и музыку, и звуки, и включает обратно', async () => {
    render(<SoundToggle />);
    await userEvent.click(screen.getByRole('button', { name: 'Выключить звук' }));
    expect(useAudio.getState().music).toBe(false);
    expect(useAudio.getState().sfx).toBe(false);
    await userEvent.click(screen.getByRole('button', { name: 'Включить звук' }));
    expect(useAudio.getState().music).toBe(true);
    expect(useAudio.getState().sfx).toBe(true);
  });
});
