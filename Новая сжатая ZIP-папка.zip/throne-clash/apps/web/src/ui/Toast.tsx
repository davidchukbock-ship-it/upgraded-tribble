import { AnimatePresence, motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { Icon } from '../icons/Icon';
import { cn } from '../lib/cn';
import { useToasts, type ToastTone } from '../store/toast';

const TONE: Record<ToastTone, string> = {
  info: 'border-stone bg-wood-dark',
  success: 'border-green bg-wood-dark',
  error: 'border-red bg-wood-dark',
};

/** Контейнер уведомлений: aria-live, чтобы скринридер зачитывал новые сообщения. */
export function ToastHost() {
  const { t } = useTranslation();
  const items = useToasts((s) => s.items);
  const dismiss = useToasts((s) => s.dismiss);
  return (
    <div
      role="status"
      aria-live="polite"
      className="pointer-events-none fixed inset-x-0 bottom-20 z-[60] md:bottom-4 flex flex-col items-center gap-2 px-4"
    >
      <AnimatePresence>
        {items.map((toast) => (
          <motion.div
            key={toast.id}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className={cn(
              'pointer-events-auto flex max-w-md items-center gap-3 rounded-lg border-2 px-4 py-2 text-sm text-parchment shadow-panel',
              TONE[toast.tone],
            )}
          >
            <span>{toast.message}</span>
            <button
              type="button"
              aria-label={t('common.close')}
              onClick={() => dismiss(toast.id)}
              className="min-h-[32px] min-w-[32px]"
            >
              <Icon name="close" size={14} />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
